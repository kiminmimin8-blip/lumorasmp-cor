package xyz.sanz.rp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import xyz.sanz.rp.model.ResourcePackEntry;
import xyz.sanz.rp.util.BedrockUtil;
import xyz.sanz.rp.util.PackUtil;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Pusat data & logika semua resource pack yang dikelola plugin ini. Sumber data:
 * plugins/SanzResourcePack/config.yml (section "packs"). Tiap perubahan (add/remove/
 * toggle) langsung dipanggil save() supaya persisten tanpa perlu command save terpisah.
 */
public class ResourcePackManager {

    private final SanzResourcePack plugin;
    private final Map<String, ResourcePackEntry> packs = new LinkedHashMap<>();

    public ResourcePackManager(SanzResourcePack plugin) {
        this.plugin = plugin;
    }

    public void load() {
        packs.clear();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("packs");
        if (sec == null) return;

        for (String key : sec.getKeys(false)) {
            ConfigurationSection p = sec.getConfigurationSection(key);
            if (p == null) continue;

            UUID uuid;
            try {
                uuid = UUID.fromString(p.getString("id", ""));
            } catch (IllegalArgumentException ex) {
                uuid = UUID.randomUUID();
            }
            String url = p.getString("url", "");
            String sha1 = p.getString("sha1", "");
            boolean required = p.getBoolean("required", false);
            boolean enabled = p.getBoolean("enabled", true);
            String prompt = p.getString("prompt", "");

            packs.put(key, new ResourcePackEntry(key, uuid, url, sha1, required, enabled, prompt));
        }
        plugin.getLogger().info("Berhasil memuat " + packs.size() + " resource pack.");
    }

    public void save() {
        plugin.getConfig().set("packs", null);
        for (ResourcePackEntry e : packs.values()) {
            String base = "packs." + e.getKey();
            plugin.getConfig().set(base + ".id", e.getUuid().toString());
            plugin.getConfig().set(base + ".url", e.getUrl());
            plugin.getConfig().set(base + ".sha1", e.getSha1());
            plugin.getConfig().set(base + ".required", e.isRequired());
            plugin.getConfig().set(base + ".enabled", e.isEnabled());
            plugin.getConfig().set(base + ".prompt", e.getPrompt());
        }
        plugin.saveConfig();
    }

    // ---------- akses & CRUD ----------

    public Map<String, ResourcePackEntry> getPacks() {
        return packs;
    }

    public ResourcePackEntry get(String key) {
        return packs.get(key);
    }

    public boolean exists(String key) {
        return packs.containsKey(key);
    }

    public ResourcePackEntry add(String key, String url, String sha1, boolean required, String prompt) {
        ResourcePackEntry e = new ResourcePackEntry(key, UUID.randomUUID(), url, sha1, required, true, prompt);
        packs.put(key, e);
        save();
        return e;
    }

    /** Hapus dari config DAN cabut dari semua pemain online yang lagi punya pack itu. */
    public boolean remove(String key) {
        ResourcePackEntry e = packs.remove(key);
        if (e == null) return false;
        save();
        for (Player online : Bukkit.getOnlinePlayers()) {
            online.removeResourcePack(e.getUuid());
        }
        return true;
    }

    // ---------- kirim/cabut ke pemain ----------

    /** Kirim semua pack yang enabled=true ke satu pemain. Dipanggil saat join & lewat command send. */
    public void applyAll(Player player) {
        for (ResourcePackEntry e : packs.values()) {
            if (e.isEnabled()) {
                applyOne(player, e);
            }
        }
    }

    /**
     * Kirim satu resource pack ke satu pemain.
     * @return true kalau beneran dikirim, false kalau di-skip (url kosong, atau
     *         pemainnya Bedrock -- resource pack Java gak kompatibel ke Bedrock sama sekali).
     */
    public boolean applyOne(Player player, ResourcePackEntry e) {
        if (e.getUrl() == null || e.getUrl().isBlank()) return false;
        if (BedrockUtil.isBedrockPlayer(player)) return false;

        byte[] hash = PackUtil.hashFromHex(e.getSha1());
        Component prompt = (e.getPrompt() != null && !e.getPrompt().isBlank())
                ? LegacyComponentSerializer.legacyAmpersand().deserialize(e.getPrompt())
                : null;

        player.setResourcePack(e.getUuid(), e.getUrl(), hash, prompt, e.isRequired());
        return true;
    }

    public void removeFromPlayer(Player player, ResourcePackEntry e) {
        player.removeResourcePack(e.getUuid());
    }
}
