package xyz.sanz.rp.listener;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import xyz.sanz.rp.SanzResourcePack;
import xyz.sanz.rp.model.ResourcePackEntry;
import xyz.sanz.rp.util.Messages;

import java.util.EnumSet;
import java.util.Set;

public class StatusListener implements Listener {

    private static final Set<PlayerResourcePackStatusEvent.Status> FAILURE_STATUSES = EnumSet.of(
            PlayerResourcePackStatusEvent.Status.DECLINED,
            PlayerResourcePackStatusEvent.Status.FAILED_DOWNLOAD,
            PlayerResourcePackStatusEvent.Status.INVALID_URL,
            PlayerResourcePackStatusEvent.Status.FAILED_RELOAD,
            PlayerResourcePackStatusEvent.Status.DISCARDED
    );

    private final SanzResourcePack plugin;

    public StatusListener(SanzResourcePack plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onStatus(PlayerResourcePackStatusEvent e) {
        var player = e.getPlayer();
        var status = e.getStatus();
        var packId = e.getID();

        plugin.getStatusTracker().record(player.getUniqueId(), packId, status);

        ResourcePackEntry entry = findByUuid(packId);
        if (entry == null) return; // pack dari plugin/sumber lain, bukan urusan kita

        plugin.getLogger().info("[" + entry.getKey() + "] " + player.getName() + " -> " + status);

        if (!entry.isRequired()) return;
        if (!FAILURE_STATUSES.contains(status)) return;
        if (!plugin.getConfig().getBoolean("settings.kick-on-required-decline", true)) return;

        String kickMsgLegacy = Messages.color(plugin.getConfig().getString("settings.kick-message",
                "&cKamu wajib menginstall resource pack server ini untuk bisa bermain."));
        Component kickMsg = LegacyComponentSerializer.legacySection().deserialize(kickMsgLegacy);
        player.kick(kickMsg);
    }

    private ResourcePackEntry findByUuid(java.util.UUID packId) {
        for (ResourcePackEntry entry : plugin.getPackManager().getPacks().values()) {
            if (entry.getUuid().equals(packId)) return entry;
        }
        return null;
    }
}
