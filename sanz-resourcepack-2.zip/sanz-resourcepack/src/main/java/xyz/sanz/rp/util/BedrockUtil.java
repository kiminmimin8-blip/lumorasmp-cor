package xyz.sanz.rp.util;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.geysermc.floodgate.api.FloodgateApi;

/**
 * Deteksi apakah seorang pemain connect lewat Bedrock (Geyser/Floodgate).
 *
 * Kenapa ini penting: resource pack yang dikelola plugin ini format-nya Java Edition
 * (.zip berisi assets/minecraft/...). Client Bedrock secara arsitektur SAMA SEKALI
 * gak bisa baca format itu -- bukan soal "gagal download" yang bisa di-retry, tapi
 * memang gak kompatibel. Kalau tetap dipaksa kirim (apalagi dengan required=true),
 * client Bedrock bakal nolak dan generic-nya kena kick oleh listener kick-on-decline.
 * Makanya pemain Bedrock harus di-skip total dari pengiriman pack, bukan cuma
 * dibikin "opsional".
 */
public final class BedrockUtil {

    private static Boolean floodgatePresent;

    private BedrockUtil() {}

    private static boolean floodgateAvailable() {
        if (floodgatePresent == null) {
            floodgatePresent = Bukkit.getPluginManager().getPlugin("floodgate") != null;
        }
        return floodgatePresent;
    }

    /**
     * True kalau pemain ini terdeteksi sebagai pemain Bedrock. Aman dipanggil walau
     * Floodgate gak terpasang di server (langsung return false, gak lempar error).
     */
    public static boolean isBedrockPlayer(Player player) {
        if (!floodgateAvailable()) return false;
        try {
            return FloodgateApi.getInstance().isFloodgatePlayer(player.getUniqueId());
        } catch (Throwable t) {
            // Defensif: kalau API Floodgate berubah/error di versi lain, jangan sampai
            // itu bikin plugin kita ikutan crash -- anggap saja bukan pemain Bedrock.
            return false;
        }
    }
}
