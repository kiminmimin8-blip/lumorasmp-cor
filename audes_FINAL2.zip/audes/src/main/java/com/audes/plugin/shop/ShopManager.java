package com.audes.plugin.shop;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class ShopManager {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    private final VaultEconomyBridge economy;

    public ShopManager(VaultEconomyBridge economy) {
        this.economy = economy;
    }

    public void open(Player player, ShopDefinition def) {
        AudesShopHolder holder = new AudesShopHolder(def.id());
        Inventory inventory = Bukkit.createInventory(holder, def.rows() * 9, LEGACY.deserialize(def.title()));
        holder.setInventory(inventory);

        for (ShopItemDefinition item : def.items()) {
            inventory.setItem(item.slot(), buildItem(item, player));
        }

        player.openInventory(inventory);
    }

    /**
     * Lore harga DITEMPEL OTOMATIS di baris terakhir, terpisah dari lore
     * custom di config -- admin isi lore.yml cuma buat deskripsi item,
     * gak perlu nulis ulang harga manual tiap kali harga berubah (dan gak
     * bisa ke-desync kayak kalau harga di-hardcode di string lore).
     */
    private ItemStack buildItem(ShopItemDefinition item, Player viewer) {
        ItemStack stack = new ItemStack(item.material(), item.giveAmount());
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            if (item.displayName() != null && !item.displayName().isBlank()) {
                meta.displayName(LEGACY.deserialize(item.displayName()));
            }
            List<String> lore = new ArrayList<>(item.lore());
            lore.add("");
            boolean canAfford = !economy.isReady() || economy.has(viewer, item.price());
            String priceColor = canAfford ? "&a" : "&c";
            String priceText = economy.isReady() ? economy.format(item.price()) : String.valueOf(item.price());
            lore.add("&7Harga: " + priceColor + priceText);
            if (!canAfford) {
                lore.add("&cSaldo kamu tidak cukup!");
            }
            meta.lore(lore.stream().map(LEGACY::deserialize).toList());
            stack.setItemMeta(meta);
        }
        return stack;
    }
}
