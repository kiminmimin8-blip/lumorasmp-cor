package com.audes.plugin.shop;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;

/**
 * Menangani klik di shop. Pola click-cancel SAMA seperti GuiListener (lihat
 * javadoc di sana) -- shop juga murni menu beli, bukan tempat pindah item.
 *
 * ALUR BELI per klik (bukan double-click/shift buat beli banyak sekaligus --
 * disengaja, satu klik = satu transaksi, supaya gak ada ambiguitas "klik
 * sekali kepotong berapa kali" kalau lag/klik ganda kepencet gak sengaja):
 *   1. Cek VaultEconomyBridge ready (Vault + economy plugin ke-detect) --
 *      kalau tidak, tolak transaksi dengan pesan jelas (BUKAN kasih gratis).
 *   2. Cek saldo cukup (economy.has) SEBELUM withdraw -- withdraw Vault
 *      bisa gagal kalau economy plugin race condition, jadi dicek dulu di
 *      sini biar pesan errornya jelas "saldo kurang" bukan "transaksi gagal"
 *      generik.
 *   3. withdraw() -- kalau balik false (race condition/plugin lain motong
 *      saldo bersamaan), BATALKAN, JANGAN kasih item (jangan dikasih dulu
 *      baru dicek, itu celah dupe/gratis kalau withdraw gagal belakangan).
 *   4. Baru setelah withdraw sukses, kasih item ke inventory player.
 */
public class ShopListener implements Listener {

    private final ShopRegistry registry;
    private final VaultEconomyBridge economy;
    private final ShopManager manager;

    public ShopListener(ShopRegistry registry, VaultEconomyBridge economy, ShopManager manager) {
        this.registry = registry;
        this.economy = economy;
        this.manager = manager;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder topHolder = event.getView().getTopInventory().getHolder();
        if (!(topHolder instanceof AudesShopHolder holder)) return; // bukan shop Audes, biarkan normal

        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getView().getTopInventory()) {
            return;
        }

        registry.get(holder.getShopId()).ifPresent(def -> {
            int slot = event.getSlot();
            def.items().stream()
                    .filter(i -> i.slot() == slot)
                    .findFirst()
                    .ifPresent(item -> handlePurchase(player, def, item));
        });
    }

    private void handlePurchase(Player player, ShopDefinition def, ShopItemDefinition item) {
        if (!economy.isReady()) {
            player.sendMessage("§cShop tidak bisa dipakai -- Vault/economy plugin tidak ke-detect di server. Hubungi admin.");
            return;
        }
        if (!economy.has(player, item.price())) {
            player.sendMessage("§cSaldo kamu tidak cukup. Butuh §e" + economy.format(item.price())
                    + " §c, saldo kamu §e" + economy.format(economy.getBalance(player)) + "§c.");
            return;
        }
        if (!economy.withdraw(player, item.price())) {
            // Withdraw gagal PADAHAL has() bilang cukup -- race condition (mis.
            // 2 klik nyaris bersamaan, saldo kepotong transaksi lain duluan).
            // Item TIDAK dikasih, saldo TIDAK jadi kepotong (withdraw gagal),
            // jadi player aman, cuma perlu coba klik lagi.
            player.sendMessage("§cTransaksi gagal, coba lagi.");
            return;
        }

        var leftover = player.getInventory().addItem(
                new org.bukkit.inventory.ItemStack(item.material(), item.giveAmount())
        );
        if (!leftover.isEmpty()) {
            // Inventory penuh SETELAH saldo kepotong -- drop ke lantai
            // daripada item hilang percuma (uang sudah kepotong, item harus
            // tetap sampai ke player dengan cara apa pun).
            leftover.values().forEach(stack -> player.getWorld().dropItemNaturally(player.getLocation(), stack));
            player.sendMessage("§eInventory penuh, sisa item dijatuhkan di tanah.");
        }

        player.sendMessage("§aBerhasil beli " + item.giveAmount() + "x " + item.material().name()
                + " seharga §e" + economy.format(item.price()) + "§a.");

        // Refresh tampilan shop biar lore "Harga: ..." update warnanya kalau
        // saldo sekarang jadi gak cukup buat item lain di shop yang sama.
        manager.open(player, def);
    }
}
