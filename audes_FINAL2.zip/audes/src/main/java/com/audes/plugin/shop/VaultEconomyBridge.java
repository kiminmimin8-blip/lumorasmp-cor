package com.audes.plugin.shop;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Soft-dependency ke Vault (pola SAMA seperti LuckPerms di PrefixManager --
 * dicek getPlugin() dulu, TIDAK wajib ada di server saat runtime, lihat
 * pom.xml kenapa VaultAPI scope-nya "provided"). Shop TIDAK BISA jalan
 * tanpa Vault + economy plugin (mis. EssentialsX Economy/CMI) yang
 * daftarin service Economy -- kalau gak ada, ShopModule nolak enable
 * (lihat ShopModule#enable) dengan pesan jelas, BUKAN silent fail beli
 * gratis atau NPE pas klik item.
 */
public class VaultEconomyBridge {

    private Economy economy;

    public boolean setup() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> provider = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (provider == null) {
            return false; // Vault ada, tapi TIDAK ADA economy plugin yang daftarin service (mis. EssentialsX Economy belum dipasang)
        }
        economy = provider.getProvider();
        return economy != null;
    }

    public boolean isReady() {
        return economy != null;
    }

    public double getBalance(OfflinePlayer player) {
        return economy.getBalance(player);
    }

    public boolean has(OfflinePlayer player, double amount) {
        return economy.has(player, amount);
    }

    /** @return true kalau withdraw sukses (saldo cukup), false kalau gagal (saldo kurang). */
    public boolean withdraw(OfflinePlayer player, double amount) {
        return economy.withdrawPlayer(player, amount).transactionSuccess();
    }

    public String format(double amount) {
        try {
            return economy.format(amount);
        } catch (Exception e) {
            // Sebagian implementasi Economy (mis. yang minimal) bisa lempar
            // exception di format() kalau locale/currency belum disetup --
            // fallback ke angka polos daripada shop-nya error total.
            return String.valueOf(amount);
        }
    }
}
