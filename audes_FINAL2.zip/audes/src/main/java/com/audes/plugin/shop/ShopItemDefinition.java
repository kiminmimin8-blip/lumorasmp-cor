package com.audes.plugin.shop;

import org.bukkit.Material;

import java.util.List;

/**
 * Satu item yang dijual di shop. Beda dari GuiButtonDefinition (yang murni
 * command-driven) -- shop item PUNYA harga (price, dipotong dari Balance
 * lewat Vault, lihat VaultEconomyBridge) dan JUMLAH item yang dikasih
 * (giveAmount), bukan cuma command bebas. Ini disengaja: shop item beda
 * konsep dari tombol GUI generik (butuh validasi saldo SEBELUM dikasih
 * barangnya, bukan sekadar jalanin command).
 */
public record ShopItemDefinition(
        int slot,
        Material material,
        String displayName,
        List<String> lore,
        double price,
        int giveAmount
) {
}
