package com.audes.plugin.shop;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * /shop [id] — command terpisah dari /audes (bukan /audes shop ...) SAMA
 * ALASANNYA dengan EmoteCommand (lihat javadoc di sana): /audes command
 * di-gate permission "audes.admin" di plugin.yml, sedangkan shop DIPAKAI
 * PLAYER BIASA sehari-hari buat belanja, bukan admin tooling.
 *
 * /audes shop <id> [player] (di AudesCommand) TETAP ADA buat admin buka
 * shop-nya di layar player lain (mis. bantu troubleshoot) -- dua command
 * ini sama-sama manggil ShopModule.getManager().open(), gak ada logic
 * yang keduplikasi selain parsing argumen.
 *
 * Tanpa argumen: kalau cuma ada SATU menu shop di config.yml, langsung
 * dibuka (biar player gak perlu apalin id shop-nya) -- kalau lebih dari
 * satu, wajib sebutkan id (dan dikasih tau daftar id yang ada).
 */
public class ShopCommand implements CommandExecutor, TabCompleter {

    private final ShopModule module;

    public ShopCommand(ShopModule module) {
        this.module = module;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cCommand ini cuma bisa dipakai in-game.");
            return true;
        }
        if (module == null || module.getRegistry() == null || module.getManager() == null) {
            sender.sendMessage("§cShop tidak tersedia (modul 'shop' gagal enable, cek dengan admin).");
            return true;
        }

        String shopId;
        if (args.length >= 1) {
            shopId = args[0];
        } else if (module.getRegistry().getAll().size() == 1) {
            shopId = module.getRegistry().getAll().keySet().iterator().next();
        } else {
            sender.sendMessage("§cPakai: /shop <id>. Menu yang ada: "
                    + String.join(", ", module.getRegistry().getAll().keySet()));
            return true;
        }

        var defOpt = module.getRegistry().get(shopId);
        if (defOpt.isEmpty()) {
            sender.sendMessage("§cShop '" + shopId + "' tidak ditemukan. Menu yang ada: "
                    + String.join(", ", module.getRegistry().getAll().keySet()));
            return true;
        }

        module.getManager().open(player, defOpt.get());
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1 && module != null) {
            return new ArrayList<>(module.getRegistry().getAll().keySet());
        }
        return List.of();
    }
}
