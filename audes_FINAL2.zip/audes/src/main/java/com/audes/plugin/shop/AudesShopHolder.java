package com.audes.plugin.shop;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Sama persis pola AudesGuiHolder (lihat javadoc class itu) -- identifikasi "shop menu mana yang lagi diklik" lewat holder, bukan Map eksternal. */
public class AudesShopHolder implements InventoryHolder {

    private final String shopId;
    private Inventory inventory;

    public AudesShopHolder(String shopId) {
        this.shopId = shopId;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public String getShopId() {
        return shopId;
    }
}
