package xyz.sanz.shop;

import org.bukkit.plugin.java.JavaPlugin;
import xyz.sanz.shop.command.SellCommand;
import xyz.sanz.shop.command.SellEditCommand;
import xyz.sanz.shop.command.SellHandCommand;
import xyz.sanz.shop.command.SellListCommand;
import xyz.sanz.shop.command.SellRefundCommand;
import xyz.sanz.shop.command.ShopCommand;
import xyz.sanz.shop.command.ShopEditCommand;
import xyz.sanz.shop.gui.GuiListener;
import xyz.sanz.shop.input.ChatInputManager;
import xyz.sanz.shop.resourcepack.ShopResourcePackModule;
import xyz.sanz.shop.service.RefundManager;
import xyz.sanz.shop.service.ShopService;
import xyz.sanz.shop.util.Messages;

public class SanzShop extends JavaPlugin {

    private ShopManager shopManager;
    private ChatInputManager chatInputManager;
    private ShopService shopService;
    private RefundManager refundManager;
    private Messages messages;
    private ShopResourcePackModule resourcePackModule;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.messages = new Messages(this);

        if (!EconomyHook.setup(this)) {
            getLogger().warning("Vault / economy plugin tidak ditemukan! Fitur beli & jual akan gagal sampai Vault + economy plugin terpasang.");
        }

        this.shopManager = new ShopManager(this);
        this.shopManager.load();

        this.shopService = new ShopService(this);

        this.refundManager = new RefundManager(this);
        this.refundManager.load();
        this.refundManager.start();
        this.chatInputManager = new ChatInputManager(this);

        this.resourcePackModule = new ShopResourcePackModule(this);
        this.resourcePackModule.enable();

        getServer().getPluginManager().registerEvents(new GuiListener(this), this);

        var sellCmd = getCommand("sell");
        if (sellCmd != null) {
            SellCommand sellExecutor = new SellCommand(this);
            sellCmd.setExecutor(sellExecutor);
            sellCmd.setTabCompleter(sellExecutor);
        }

        var shopCmd = getCommand("shop");
        if (shopCmd != null) shopCmd.setExecutor(new ShopCommand(this));

        var editCmd = getCommand("shopedit");
        if (editCmd != null) editCmd.setExecutor(new ShopEditCommand(this));

        var sellListCmd = getCommand("sellist");
        if (sellListCmd != null) {
            SellListCommand sellListExecutor = new SellListCommand(this);
            sellListCmd.setExecutor(sellListExecutor);
            sellListCmd.setTabCompleter(sellListExecutor);
        }

        var sellEditCmd = getCommand("selledit");
        if (sellEditCmd != null) {
            SellEditCommand sellEditExecutor = new SellEditCommand(this);
            sellEditCmd.setExecutor(sellEditExecutor);
            sellEditCmd.setTabCompleter(sellEditExecutor);
        }

        var sellHandCmd = getCommand("sellhand");
        if (sellHandCmd != null) sellHandCmd.setExecutor(new SellHandCommand(this));

        var sellRefundCmd = getCommand("sellrefund");
        if (sellRefundCmd != null) sellRefundCmd.setExecutor(new SellRefundCommand(this));

        getLogger().info("SanzShop aktif — " + shopManager.getCategories().size() + " kategori, "
                + shopManager.countAllItems() + " item siap dijual di Sanz Market.");
    }

    @Override
    public void onDisable() {
        if (refundManager != null) {
            refundManager.stop();
            refundManager.save();
        }
        if (shopManager != null) shopManager.save();
    }

    public ShopManager getShopManager() {
        return shopManager;
    }

    public ChatInputManager getChatInputManager() {
        return chatInputManager;
    }

    public ShopService getShopService() {
        return shopService;
    }

    public RefundManager getRefundManager() {
        return refundManager;
    }

    public Messages getMessages() {
        return messages;
    }

    public ShopResourcePackModule getResourcePackModule() {
        return resourcePackModule;
    }
}
