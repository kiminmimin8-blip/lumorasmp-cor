package xyz.sanz.shop.command;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import xyz.sanz.shop.SanzShop;
import xyz.sanz.shop.ShopManager;
import xyz.sanz.shop.model.ShopItem;
import xyz.sanz.shop.service.ShopService;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * /sellhand -- jual SEMUA stok material yang lagi dipegang di tangan utama
 * (dihitung dari seluruh slot penyimpanan -- hotbar + tas -- bukan cuma slot tangan,
 * konsisten sama klik jual di GUI). Slot armor & offhand TIDAK ikut kejual.
 * QoL command biar gak perlu buka GUI & nyari kategori manual buat jual cepat.
 *
 * Item bagus (enchant/nama/lore/isi) dilindungi & gak ikut kejual -- lihat
 * sell.protect-valuable-items di config.yml. Kalau item di tangan itu sendiri item bagus
 * dan gak ada stok polosnya, player dikasih tau kenapa gak kejual.
 *
 * Kalau material yang dipegang kebetulan terdaftar di lebih dari 1 kategori
 * dengan harga beda (lihat catatan duplikat di ShopManager), otomatis pilih
 * harga jual yang PALING TINGGI -- paling menguntungkan buat player, dan
 * gak perlu nanya-nanya kategori mana yang dimaksud.
 *
 * Habis jual, player diingetin soal /sellrefund (jendela refund 3 menit) karena command
 * ini yang paling gampang bikin salah jual.
 */
public class SellHandCommand implements CommandExecutor {

    private final SanzShop plugin;

    public SellHandCommand(SanzShop plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }
        sellHeldItem(player, plugin);
        return true;
    }

    /**
     * Logika inti jual item di tangan -- dipisah jadi static biar bisa dipanggil dari
     * command lain (mis. /sell tanpa argumen) tanpa duplikat kode.
     */
    public static void sellHeldItem(Player player, SanzShop plugin) {
        if (!player.hasPermission("sanzshop.use")) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return;
        }

        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand.getType() == Material.AIR) {
            player.sendMessage(plugin.getMessages().prefix() + "§cGak ada item di tangan kamu.");
            return;
        }

        List<ShopManager.ItemMatch> matches = plugin.getShopManager().findItemAcrossCategories(hand.getType().name());
        List<ShopManager.ItemMatch> sellable = matches.stream().filter(m -> m.item().isSellable()).toList();
        if (sellable.isEmpty()) {
            player.sendMessage(plugin.getMessages().get("cannot-sell"));
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
            return;
        }

        ShopManager.ItemMatch best = sellable.stream()
                .max(Comparator.comparingDouble(m -> m.item().getSellPrice()))
                .orElseThrow();
        ShopItem item = best.item();

        ShopService service = plugin.getShopService();

        // qty minimal 1: kalau stok yang boleh dijual gak cukup, sell() sendiri yang balikin
        // NOT_ENOUGH_ITEMS / PROTECTED_ITEMS dengan pesan yang pas.
        int owned = service.countSellable(player, item.getMaterial());
        int qty = Math.max(1, owned / item.getAmount());

        ShopService.Result result = service.sell(player, item, qty);
        if (result != ShopService.Result.SUCCESS) {
            service.reportFailure(player, item, qty, result);
            return;
        }

        if (plugin.getRefundManager().isEnabled()) {
            Map<String, String> ph = new HashMap<>();
            ph.put("%window%", plugin.getRefundManager().windowText());
            plugin.getMessages().send(player, "refund-hint", ph);
        }
    }
}
