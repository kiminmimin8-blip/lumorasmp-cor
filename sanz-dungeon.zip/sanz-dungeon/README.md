# SanzDungeon

Plugin standalone sistem dungeon: GUI player, GUI admin, level 1-7 (default: 1-3 gratis,
4-7 bayar pakai Vault), wand seleksi region, dan world border PER-PLAYER (jadi 1 world
bisa nampung banyak dungeon sekaligus tanpa numpuk border).

## Command

| Command | Fungsi | Permission |
|---|---|---|
| `/dungeon` | Buka GUI player - pilih & masuk dungeon | `sanzdungeon.use` |
| `/dungeon leave` | Keluar dari dungeon, balik ke posisi sebelum masuk | semua |
| `/dungeon list` | List semua dungeon di chat | semua |
| `/dungeon admin` | Buka GUI admin (edit harga/premium/hapus/tambah) | `sanzdungeon.admin` |
| `/dungeon wand` | Dapet stick seleksi (klik kiri=pos1, klik kanan=pos2) | admin |
| `/dungeon create <nama> <level> <harga>` | Bikin dungeon baru lewat command | admin |
| `/dungeon setloc <id>` | Set region (dari wand) + spawn (posisi kamu sekarang) buat dungeon itu | admin |
| `/dungeon setspawn <id>` | Update titik spawn doang, region tetep | admin |
| `/dungeon delete <id>` | Hapus dungeon | admin |

Semua command ada **tab completion** (subcommand + ID dungeon buat setloc/setspawn/delete).

## Cara bikin dungeon baru (dari GUI atau command)

**Lewat GUI:** `/dungeon admin` → klik **"+ Tambah Dungeon Baru"** → ketik di chat
`<nama>;<level>;<harga>` (contoh: `Dungeon Rahasia;8;7500`) → dungeon dibuat dengan status
"belum siap" (belum ada lokasi).

**Setelah dungeon dibuat** (lewat GUI atau `/dungeon create`), set lokasinya:
1. `/dungeon wand` - dapet stick
2. Klik kiri di titik pojok 1 area dungeon, klik kanan di titik pojok 2
3. Jalan ke titik yang mau jadi tempat spawn player pas masuk
4. `/dungeon setloc <id>` - beres, dungeon otomatis aktif

## Sistem harga & premium

- Level 1-3 (default): gratis
- Level 4-7 (default): premium, харga dipotong dari Vault economy pas masuk
- Admin bisa ubah harga & toggle premium/gratis kapan aja lewat `/dungeon admin` → klik
  dungeon → **Edit Harga** (ketik angka di chat) atau **Toggle Premium**
- Dungeon baru yang dibuat abis 7 default itu **gak dibatasin jumlahnya** - bisa nambah
  terus lewat GUI atau command

## World Border per-player

Ini bagian paling penting biar "1 world bisa ada banyak dungeon (misal 10)" tanpa masalah:
plugin ini PAKAI Paper API `Player#setWorldBorder(WorldBorder)` - border yang cuma keliatan
buat 1 player itu doang, gak numpuk sama border dungeon lain atau border asli world-nya.
Border otomatis di-apply pas masuk dungeon, dan di-reset (`setWorldBorder(null)`) pas keluar
lewat `/dungeon leave` atau disconnect.

⚠️ **Kalau `Player#setWorldBorder` gak ke-compile** di versi API kamu (method ini nambahan
dari Paper, bukan Bukkit standar) - kasih tau aku, ada alternatif pakai ProtocolLib (yang
kelihatannya udah kamu install) buat kirim WorldBorder packet manual per-player.

## Anti-teleport-escape

Selama player ada di dalam sesi dungeon (`isInsideDungeon`), command-command ini
di-block otomatis: `/tpa`, `/tpahere`, `/tpaccept`, `/tpdeny`, `/tpacancel`, `/tpauto`,
`/tpyes`, `/tpno`, `/tpask` (termasuk versi prefix kayak `/essentials:tpa`).

## Cara build

Sandbox aku gak ada internet buat `mvn compile`, jadi ini **belum ke-compile beneran** -
udah di-review manual baris per baris (termasuk 1 bug serius yang ketemu & difix: konflik
nama method `success()` di record `EntryResult`). Push ke GitHub, biarin Actions CI yang
build, ambil jar dari tab Actions. Kirim log-nya ke sini kalau ada error compile lain.

**Cek dulu versi `paper-api` di `pom.xml`** - masih `1.21.11-R0.1-SNAPSHOT`, sesuaikan
kalau versi API buat 26.1.2 kamu beda.

## Data

Semua dungeon disimpan di `plugins/SanzDungeon/dungeons.yml`, auto-generate & auto-save
tiap ada perubahan (create/edit/delete/setloc).
