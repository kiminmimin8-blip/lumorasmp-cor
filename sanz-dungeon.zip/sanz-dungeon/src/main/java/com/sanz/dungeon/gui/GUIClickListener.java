package com.sanz.dungeon.gui;

import com.sanz.dungeon.SanzDungeon;
import com.sanz.dungeon.managers.DungeonManager;
import com.sanz.dungeon.model.Dungeon;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class GUIClickListener implements Listener {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzDungeon plugin;

    public GUIClickListener(SanzDungeon plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        var holder = event.getInventory().getHolder();

        if (holder instanceof DungeonMainHolder mainHolder) {
            event.setCancelled(true);
            handleMainClick(player, mainHolder, event.getSlot());
        } else if (holder instanceof DungeonAdminListHolder listHolder) {
            event.setCancelled(true);
            handleAdminListClick(player, listHolder, event.getSlot());
        } else if (holder instanceof DungeonAdminDetailHolder detailHolder) {
            event.setCancelled(true);
            handleAdminDetailClick(player, detailHolder, event.getSlot());
        }
    }

    private void handleMainClick(Player player, DungeonMainHolder holder, int slot) {
        Integer dungeonId = holder.getDungeonIdAt(slot);
        if (dungeonId == null) return;

        Dungeon dungeon = plugin.getDungeonManager().getDungeon(dungeonId);
        if (dungeon == null) return;

        player.closeInventory();
        DungeonManager.EntryResult result = plugin.getDungeonManager().enter(player, dungeon);
        if (!result.success()) {
            player.sendMessage(LEGACY.deserialize(result.message()));
        } else {
            player.sendMessage(LEGACY.deserialize("&aKamu masuk ke &f" + dungeon.getName() + "&a! Ketik &f/dungeon leave &auntuk keluar."));
        }
    }

    private void handleAdminListClick(Player player, DungeonAdminListHolder holder, int slot) {
        if (slot == DungeonAdminListHolder.ADD_BUTTON_SLOT) {
            player.closeInventory();
            player.sendMessage(LEGACY.deserialize("&eKetik di chat: &f<nama>;<level>;<harga> &e(contoh: Dungeon Baru;8;5000). Ketik &ccancel &euntuk batal."));
            plugin.getChatInputManager().awaitInput(player.getUniqueId(), input -> handleCreateInput(player, input));
            return;
        }

        Integer dungeonId = holder.getDungeonIdAt(slot);
        if (dungeonId == null) return;

        Dungeon dungeon = plugin.getDungeonManager().getDungeon(dungeonId);
        if (dungeon == null) return;

        plugin.getGui().openAdminDetail(player, dungeon);
    }

    private void handleAdminDetailClick(Player player, DungeonAdminDetailHolder holder, int slot) {
        Dungeon dungeon = plugin.getDungeonManager().getDungeon(holder.getDungeonId());
        if (dungeon == null) {
            player.closeInventory();
            return;
        }

        if (slot == DungeonAdminDetailHolder.EDIT_PRICE_SLOT) {
            player.closeInventory();
            player.sendMessage(LEGACY.deserialize("&eKetik harga baru di chat (angka). Ketik &ccancel &euntuk batal."));
            plugin.getChatInputManager().awaitInput(player.getUniqueId(), input -> handlePriceInput(player, dungeon.getId(), input));
        } else if (slot == DungeonAdminDetailHolder.TOGGLE_PREMIUM_SLOT) {
            dungeon.setPremium(!dungeon.isPremium());
            plugin.getDungeonManager().saveAll();
            plugin.getGui().openAdminDetail(player, dungeon);
        } else if (slot == DungeonAdminDetailHolder.DELETE_SLOT) {
            plugin.getDungeonManager().deleteDungeon(dungeon.getId());
            player.sendMessage(LEGACY.deserialize("&cDungeon &f" + dungeon.getName() + " &cdihapus."));
            plugin.getGui().openAdminList(player);
        } else if (slot == DungeonAdminDetailHolder.BACK_SLOT) {
            plugin.getGui().openAdminList(player);
        }
    }

    private void handlePriceInput(Player player, int dungeonId, String input) {
        if (input.equalsIgnoreCase("cancel")) {
            player.sendMessage(LEGACY.deserialize("&7Dibatalkan."));
            return;
        }
        Dungeon dungeon = plugin.getDungeonManager().getDungeon(dungeonId);
        if (dungeon == null) {
            player.sendMessage(LEGACY.deserialize("&cDungeon udah gak ada."));
            return;
        }
        try {
            double price = Double.parseDouble(input.trim());
            dungeon.setPrice(price);
            plugin.getDungeonManager().saveAll();
            player.sendMessage(LEGACY.deserialize("&aHarga &f" + dungeon.getName() + " &adiset jadi &f" + (long) price));
        } catch (NumberFormatException e) {
            player.sendMessage(LEGACY.deserialize("&cItu bukan angka valid, coba lagi lewat GUI."));
        }
    }

    private void handleCreateInput(Player player, String input) {
        if (input.equalsIgnoreCase("cancel")) {
            player.sendMessage(LEGACY.deserialize("&7Dibatalkan."));
            return;
        }
        String[] parts = input.split(";");
        if (parts.length != 3) {
            player.sendMessage(LEGACY.deserialize("&cFormat salah. Contoh: Dungeon Baru;8;5000"));
            return;
        }
        try {
            String name = parts[0].trim();
            int level = Integer.parseInt(parts[1].trim());
            double price = Double.parseDouble(parts[2].trim());
            boolean premium = price > 0;

            Dungeon dungeon = plugin.getDungeonManager().createDungeon(name, level, premium, price);
            player.sendMessage(LEGACY.deserialize("&aDungeon &f" + name + " &adibuat (ID: &f" + dungeon.getId() + "&a)."));
            player.sendMessage(LEGACY.deserialize("&eSelanjutnya: &f/dungeon wand &e-> pilih pos1/pos2 -> berdiri di titik spawn -> &f/dungeon setloc " + dungeon.getId()));
        } catch (NumberFormatException e) {
            player.sendMessage(LEGACY.deserialize("&cLevel/harga harus angka. Contoh: Dungeon Baru;8;5000"));
        }
    }
}
