package com.sanz.dungeon.gui;

import com.sanz.dungeon.SanzDungeon;
import com.sanz.dungeon.model.Dungeon;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class DungeonGUI {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzDungeon plugin;

    public DungeonGUI(SanzDungeon plugin) {
        this.plugin = plugin;
    }

    /** GUI utama - list semua dungeon, player klik buat masuk. */
    public void openMain(Player player) {
        List<Dungeon> dungeonList = plugin.getDungeonManager().getAllDungeons();
        List<Integer> slotMap = new ArrayList<>();

        DungeonMainHolder holder = new DungeonMainHolder(slotMap);
        Inventory inv = Bukkit.createInventory(holder, 54, LEGACY.deserialize("&8&lSanz Dungeon"));

        int slot = 0;
        for (Dungeon d : dungeonList) {
            if (slot >= 45) break;

            Material icon = !d.isEnabled() ? Material.BARRIER : (d.isPremium() ? Material.GOLD_BLOCK : Material.EMERALD_BLOCK);
            ItemStack item = new ItemStack(icon);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(LEGACY.deserialize((d.isPremium() ? "&6&l" : "&a&l") + d.getName()));

            List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
            lore.add(LEGACY.deserialize("&7Level: &f" + d.getLevel()));
            if (!d.isEnabled()) {
                lore.add(LEGACY.deserialize("&cBelum siap (admin belum set lokasi)"));
            } else if (d.isPremium()) {
                lore.add(LEGACY.deserialize("&7Harga masuk: &6" + (long) d.getPrice()));
                lore.add(LEGACY.deserialize("&eKlik buat masuk (uang dipotong)"));
            } else {
                lore.add(LEGACY.deserialize("&aGratis"));
                lore.add(LEGACY.deserialize("&eKlik buat masuk"));
            }
            meta.lore(lore);
            item.setItemMeta(meta);

            inv.setItem(slot, item);
            slotMap.add(d.getId());
            slot++;
        }
        // Padding sisanya biar slotMap konsisten sama slot inventory
        while (slotMap.size() < 54) {
            slotMap.add(null);
        }

        player.openInventory(inv);
    }

    /** GUI admin - list dungeon + tombol tambah baru. */
    public void openAdminList(Player player) {
        List<Dungeon> dungeonList = plugin.getDungeonManager().getAllDungeons();
        List<Integer> slotMap = new ArrayList<>();
        for (int i = 0; i < 54; i++) slotMap.add(null);

        DungeonAdminListHolder holder = new DungeonAdminListHolder(slotMap);
        Inventory inv = Bukkit.createInventory(holder, 54, LEGACY.deserialize("&8&lAdmin - Kelola Dungeon"));

        int slot = 0;
        for (Dungeon d : dungeonList) {
            if (slot >= 45) break;

            ItemStack item = new ItemStack(d.isEnabled() ? Material.CHEST : Material.BARRIER);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(LEGACY.deserialize("&e" + d.getName() + " &7(ID: " + d.getId() + ")"));
            meta.lore(List.of(
                    LEGACY.deserialize("&7Level: &f" + d.getLevel()),
                    LEGACY.deserialize("&7Premium: &f" + (d.isPremium() ? "&6Ya" : "&aTidak")),
                    LEGACY.deserialize("&7Harga: &f" + (long) d.getPrice()),
                    LEGACY.deserialize("&7Lokasi: " + (d.isLocationSet() ? "&aSudah di-set" : "&cBelum di-set")),
                    LEGACY.deserialize("&eKlik buat edit")
            ));
            item.setItemMeta(meta);

            inv.setItem(slot, item);
            slotMap.set(slot, d.getId());
            slot++;
        }

        ItemStack addButton = new ItemStack(Material.LIME_DYE);
        ItemMeta addMeta = addButton.getItemMeta();
        addMeta.displayName(LEGACY.deserialize("&a&l+ Tambah Dungeon Baru"));
        addMeta.lore(List.of(LEGACY.deserialize("&7Klik buat bikin dungeon baru")));
        addButton.setItemMeta(addMeta);
        inv.setItem(DungeonAdminListHolder.ADD_BUTTON_SLOT, addButton);

        player.openInventory(inv);
    }

    /** GUI detail edit 1 dungeon - edit harga, toggle premium, delete. */
    public void openAdminDetail(Player player, Dungeon d) {
        DungeonAdminDetailHolder holder = new DungeonAdminDetailHolder(d.getId());
        Inventory inv = Bukkit.createInventory(holder, 27, LEGACY.deserialize("&8&lEdit: " + d.getName()));

        ItemStack editName = new ItemStack(Material.NAME_TAG);
        ItemMeta nameMeta = editName.getItemMeta();
        nameMeta.displayName(LEGACY.deserialize("&bEdit Nama"));
        nameMeta.lore(List.of(
                LEGACY.deserialize("&7Nama sekarang: &f" + d.getName()),
                LEGACY.deserialize("&eKlik, terus ketik nama baru di chat")
        ));
        editName.setItemMeta(nameMeta);
        inv.setItem(DungeonAdminDetailHolder.EDIT_NAME_SLOT, editName);

        ItemStack editPrice = new ItemStack(Material.GOLD_INGOT);
        ItemMeta priceMeta = editPrice.getItemMeta();
        priceMeta.displayName(LEGACY.deserialize("&6Edit Harga"));
        priceMeta.lore(List.of(
                LEGACY.deserialize("&7Harga sekarang: &f" + (long) d.getPrice()),
                LEGACY.deserialize("&eKlik, terus ketik angka baru di chat")
        ));
        editPrice.setItemMeta(priceMeta);
        inv.setItem(DungeonAdminDetailHolder.EDIT_PRICE_SLOT, editPrice);

        ItemStack togglePremium = new ItemStack(d.isPremium() ? Material.GOLD_BLOCK : Material.EMERALD_BLOCK);
        ItemMeta premMeta = togglePremium.getItemMeta();
        premMeta.displayName(LEGACY.deserialize("&eToggle Premium"));
        premMeta.lore(List.of(
                LEGACY.deserialize("&7Status sekarang: " + (d.isPremium() ? "&6Premium (bayar)" : "&aGratis")),
                LEGACY.deserialize("&eKlik buat ganti")
        ));
        togglePremium.setItemMeta(premMeta);
        inv.setItem(DungeonAdminDetailHolder.TOGGLE_PREMIUM_SLOT, togglePremium);

        ItemStack delete = new ItemStack(Material.TNT);
        ItemMeta delMeta = delete.getItemMeta();
        delMeta.displayName(LEGACY.deserialize("&c&lHapus Dungeon"));
        delMeta.lore(List.of(LEGACY.deserialize("&7Klik buat hapus dungeon ini permanen")));
        delete.setItemMeta(delMeta);
        inv.setItem(DungeonAdminDetailHolder.DELETE_SLOT, delete);

        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta backMeta = back.getItemMeta();
        backMeta.displayName(LEGACY.deserialize("&c« Kembali"));
        back.setItemMeta(backMeta);
        inv.setItem(DungeonAdminDetailHolder.BACK_SLOT, back);

        player.openInventory(inv);
    }
}
