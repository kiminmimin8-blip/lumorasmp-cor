package com.sanz.dungeon;

import com.sanz.dungeon.commands.DungeonCommand;
import com.sanz.dungeon.data.DungeonStorage;
import com.sanz.dungeon.data.VaultHook;
import com.sanz.dungeon.gui.DungeonGUI;
import com.sanz.dungeon.gui.GUIClickListener;
import com.sanz.dungeon.listeners.ChatInputListener;
import com.sanz.dungeon.listeners.PlayerQuitListener;
import com.sanz.dungeon.listeners.TeleportGuardListener;
import com.sanz.dungeon.listeners.WandListener;
import com.sanz.dungeon.managers.ChatInputManager;
import com.sanz.dungeon.managers.DungeonManager;
import com.sanz.dungeon.managers.SelectionManager;
import com.sanz.dungeon.managers.WorldBorderManager;
import org.bukkit.plugin.java.JavaPlugin;

public class SanzDungeon extends JavaPlugin {

    private DungeonStorage storage;
    private DungeonManager dungeonManager;
    private SelectionManager selectionManager;
    private WorldBorderManager worldBorderManager;
    private VaultHook vaultHook;
    private DungeonGUI gui;
    private ChatInputManager chatInputManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        storage = new DungeonStorage(this);
        dungeonManager = new DungeonManager(this);
        selectionManager = new SelectionManager(this);
        worldBorderManager = new WorldBorderManager();
        vaultHook = new VaultHook(this);
        gui = new DungeonGUI(this);
        chatInputManager = new ChatInputManager();

        vaultHook.setup();
        dungeonManager.loadFromStorage();
        dungeonManager.createDefaultDungeonsIfEmpty();

        registerListeners();
        registerCommands();

        getLogger().info("SanzDungeon enabled - " + dungeonManager.getAllDungeons().size() + " dungeon dimuat.");
    }

    @Override
    public void onDisable() {
        if (dungeonManager != null) {
            dungeonManager.saveAll();
        }
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new WandListener(this), this);
        getServer().getPluginManager().registerEvents(new TeleportGuardListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerQuitListener(this), this);
        getServer().getPluginManager().registerEvents(new GUIClickListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatInputListener(this), this);
    }

    private void registerCommands() {
        DungeonCommand command = new DungeonCommand(this);
        getCommand("dungeon").setExecutor(command);
        getCommand("dungeon").setTabCompleter(command);
    }

    public DungeonStorage getStorage() {
        return storage;
    }

    public DungeonManager getDungeonManager() {
        return dungeonManager;
    }

    public SelectionManager getSelectionManager() {
        return selectionManager;
    }

    public WorldBorderManager getWorldBorderManager() {
        return worldBorderManager;
    }

    public VaultHook getVaultHook() {
        return vaultHook;
    }

    public DungeonGUI getGui() {
        return gui;
    }

    public ChatInputManager getChatInputManager() {
        return chatInputManager;
    }
}
