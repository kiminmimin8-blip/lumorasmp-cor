package com.sanz.dungeon.managers;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Kelola wand seleksi (stick) buat nentuin pos1/pos2 region dungeon, mirip WorldEdit
 * tapi mandiri (gak depend WorldEdit). Klik kiri = pos1, klik kanan = pos2.
 */
public class SelectionManager {

    private static final String WAND_KEY = "sanzdungeon_wand";

    private final NamespacedKey wandKey;
    private final Map<UUID, Location> pos1Map = new ConcurrentHashMap<>();
    private final Map<UUID, Location> pos2Map = new ConcurrentHashMap<>();

    public SelectionManager(org.bukkit.plugin.Plugin plugin) {
        this.wandKey = new NamespacedKey(plugin, WAND_KEY);
    }

    public ItemStack createWand() {
        ItemStack stick = new ItemStack(Material.STICK);
        ItemMeta meta = stick.getItemMeta();
        meta.displayName(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand()
                .deserialize("&d&lDungeon Selection Wand"));
        meta.lore(java.util.List.of(
                net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand()
                        .deserialize("&7Klik kiri: set pos1"),
                net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand()
                        .deserialize("&7Klik kanan: set pos2")
        ));
        meta.getPersistentDataContainer().set(wandKey, PersistentDataType.BYTE, (byte) 1);
        stick.setItemMeta(meta);
        return stick;
    }

    public boolean isWand(ItemStack item) {
        if (item == null || item.getType() != Material.STICK || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(wandKey, PersistentDataType.BYTE);
    }

    public void setPos1(UUID uuid, Location location) {
        pos1Map.put(uuid, location);
    }

    public void setPos2(UUID uuid, Location location) {
        pos2Map.put(uuid, location);
    }

    public Location getPos1(UUID uuid) {
        return pos1Map.get(uuid);
    }

    public Location getPos2(UUID uuid) {
        return pos2Map.get(uuid);
    }

    public boolean hasCompleteSelection(UUID uuid) {
        Location p1 = pos1Map.get(uuid);
        Location p2 = pos2Map.get(uuid);
        return p1 != null && p2 != null && p1.getWorld().equals(p2.getWorld());
    }
}
