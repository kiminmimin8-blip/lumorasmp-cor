package com.sanz.dungeon.model;

import org.bukkit.Location;

/**
 * Satu dungeon: punya id unik, nama, level, status premium/gratis, harga masuk,
 * dan lokasi (world, region pos1/pos2 buat world border, spawn point).
 * locationSet = false artinya dungeon ini baru dibuat lewat GUI tapi lokasinya
 * belum di-set pakai wand + /dungeon setloc, jadi belum bisa dimasukin player.
 */
public class Dungeon {

    private int id;
    private String name;
    private int level;
    private boolean premium;
    private double price;
    private boolean enabled;
    private boolean locationSet;

    private String worldName;
    private double pos1X, pos1Y, pos1Z;
    private double pos2X, pos2Y, pos2Z;
    private double spawnX, spawnY, spawnZ;
    private float spawnYaw, spawnPitch;

    public Dungeon(int id, String name, int level, boolean premium, double price) {
        this.id = id;
        this.name = name;
        this.level = level;
        this.premium = premium;
        this.price = price;
        this.enabled = false;
        this.locationSet = false;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public boolean isPremium() {
        return premium;
    }

    public void setPremium(boolean premium) {
        this.premium = premium;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean isEnabled() {
        return enabled && locationSet;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isLocationSet() {
        return locationSet;
    }

    public void setRegion(String worldName, double x1, double y1, double z1, double x2, double y2, double z2) {
        this.worldName = worldName;
        this.pos1X = Math.min(x1, x2);
        this.pos1Y = Math.min(y1, y2);
        this.pos1Z = Math.min(z1, z2);
        this.pos2X = Math.max(x1, x2);
        this.pos2Y = Math.max(y1, y2);
        this.pos2Z = Math.max(z1, z2);
    }

    public void setSpawn(Location location) {
        this.worldName = location.getWorld().getName();
        this.spawnX = location.getX();
        this.spawnY = location.getY();
        this.spawnZ = location.getZ();
        this.spawnYaw = location.getYaw();
        this.spawnPitch = location.getPitch();
    }

    public void markLocationComplete() {
        this.locationSet = true;
        this.enabled = true;
    }

    public String getWorldName() {
        return worldName;
    }

    public double getPos1X() {
        return pos1X;
    }

    public double getPos1Y() {
        return pos1Y;
    }

    public double getPos1Z() {
        return pos1Z;
    }

    public double getPos2X() {
        return pos2X;
    }

    public double getPos2Y() {
        return pos2Y;
    }

    public double getPos2Z() {
        return pos2Z;
    }

    public double getSpawnX() {
        return spawnX;
    }

    public double getSpawnY() {
        return spawnY;
    }

    public double getSpawnZ() {
        return spawnZ;
    }

    public float getSpawnYaw() {
        return spawnYaw;
    }

    public float getSpawnPitch() {
        return spawnPitch;
    }

    /** Titik tengah X/Z dari region pos1/pos2, dipakai buat center world border. */
    public double getCenterX() {
        return (pos1X + pos2X) / 2.0;
    }

    public double getCenterZ() {
        return (pos1Z + pos2Z) / 2.0;
    }

    /** Ukuran border - sisi terpanjang dari region, biar semua area ke-cover. */
    public double getBorderSize() {
        double sizeX = Math.abs(pos2X - pos1X);
        double sizeZ = Math.abs(pos2Z - pos1Z);
        return Math.max(sizeX, sizeZ) + 4; // dikasih sedikit buffer
    }
}
