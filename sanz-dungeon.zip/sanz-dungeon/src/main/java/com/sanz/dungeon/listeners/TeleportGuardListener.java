package com.sanz.dungeon.listeners;

import com.sanz.dungeon.SanzDungeon;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.Set;

/**
 * Blokir command teleport-escape (/tpa, /sethome, /setwarp, /team home, dll) pas player
 * lagi di dalam sesi dungeon. Selain itu, kalau player berhasil ke-teleport keluar dungeon
 * lewat cara LAIN yang emang diizinin (misal /home, /rtp, /spawn - bukan lewat /dungeon leave),
 * kita anggap itu keluar dungeon otomatis: reset session & world border, TANPA nge-block
 * teleport itu sendiri.
 */
public class TeleportGuardListener implements Listener {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private static final Set<String> BLOCKED_COMMANDS = Set.of(
            "tpa", "tpahere", "tpaccept", "tpdeny", "tpacancel",
            "tpauto", "tpyes", "tpno", "tpask",
            "sethome", "setwarp", "teamhome"
    );

    private final SanzDungeon plugin;

    public TeleportGuardListener(SanzDungeon plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!plugin.getDungeonManager().isInsideDungeon(event.getPlayer().getUniqueId())) return;

        String[] parts = event.getMessage().substring(1).split(" ");
        if (parts.length == 0) return;

        String base = parts[0].toLowerCase();
        int colon = base.indexOf(':'); // handle command kayak /essentials:tpa
        if (colon >= 0) {
            base = base.substring(colon + 1);
        }

        boolean blocked = BLOCKED_COMMANDS.contains(base);

        // Kasus khusus "/team home" atau "/f home" - base command-nya valid buat subcommand lain,
        // jadi cuma di-block kalau argumen pertamanya emang "home"
        if (!blocked && (base.equals("team") || base.equals("f") || base.equals("faction"))
                && parts.length >= 2 && parts[1].equalsIgnoreCase("home")) {
            blocked = true;
        }

        if (blocked) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(LEGACY.deserialize("&cGak bisa pakai command teleport/home/warp pas lagi di dalam dungeon."));
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onTeleport(PlayerTeleportEvent event) {
        if (!plugin.getDungeonManager().isInsideDungeon(event.getPlayer().getUniqueId())) return;

        // Ender pearl dipakai buat kabur dari dungeon - block total selama di dalam sesi
        if (event.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(LEGACY.deserialize("&cGak bisa pakai ender pearl pas lagi di dalam dungeon."));
            return;
        }

        // Teleport yang KITA sendiri lakuin (masuk/keluar dungeon) - biarin lewat, jangan dianggap "kabur"
        if (plugin.getDungeonManager().consumeInternalTeleportFlag(event.getPlayer().getUniqueId())) {
            return;
        }

        // Teleport lain yang lolos (misal /home, /rtp, /spawn) - anggap keluar dungeon otomatis
        plugin.getDungeonManager().handleImplicitLeave(event.getPlayer());
        event.getPlayer().sendMessage(LEGACY.deserialize("&7Kamu otomatis keluar dari dungeon karena teleport."));
    }
}
