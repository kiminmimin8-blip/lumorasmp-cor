package com.sanz.dungeon.listeners;

import com.sanz.dungeon.SanzDungeon;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.Set;

/**
 * Blokir command teleport-escape (/tpa, /tpahere, /tpaccept, /tpauto, dll) pas player
 * lagi di dalam sesi dungeon, biar gak bisa kabur/curang keluar area world border.
 */
public class TeleportGuardListener implements Listener {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private static final Set<String> BLOCKED_COMMANDS = Set.of(
            "tpa", "tpahere", "tpaccept", "tpdeny", "tpacancel",
            "tpauto", "tpyes", "tpno", "tpask"
    );

    private final SanzDungeon plugin;

    public TeleportGuardListener(SanzDungeon plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!plugin.getDungeonManager().isInsideDungeon(event.getPlayer().getUniqueId())) return;

        String[] parts = event.getMessage().substring(1).split(" ");
        if (parts.length == 0) return;

        String base = parts[0].toLowerCase();
        int slash = base.indexOf(':'); // handle command kayak /essentials:tpa
        if (slash >= 0) {
            base = base.substring(slash + 1);
        }

        if (BLOCKED_COMMANDS.contains(base)) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(LEGACY.deserialize("&cGak bisa teleport pas lagi di dalam dungeon. Ketik /dungeon leave dulu."));
        }
    }
}
