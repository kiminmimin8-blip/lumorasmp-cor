package com.sanz.dungeon.listeners;

import com.sanz.dungeon.SanzDungeon;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

public class WandListener implements Listener {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzDungeon plugin;

    public WandListener(SanzDungeon plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (!plugin.getSelectionManager().isWand(event.getItem())) return;
        if (event.getClickedBlock() == null) return;

        event.setCancelled(true);
        var player = event.getPlayer();

        if (event.getAction() == Action.LEFT_CLICK_BLOCK) {
            plugin.getSelectionManager().setPos1(player.getUniqueId(), event.getClickedBlock().getLocation());
            player.sendMessage(LEGACY.deserialize("&aPos1 diset di &f" + formatLoc(event.getClickedBlock().getLocation())));
        } else if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            plugin.getSelectionManager().setPos2(player.getUniqueId(), event.getClickedBlock().getLocation());
            player.sendMessage(LEGACY.deserialize("&aPos2 diset di &f" + formatLoc(event.getClickedBlock().getLocation())));
        }
    }

    private String formatLoc(org.bukkit.Location loc) {
        return loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ();
    }
}
