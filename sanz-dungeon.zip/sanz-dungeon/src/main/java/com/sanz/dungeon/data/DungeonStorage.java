package com.sanz.dungeon.data;

import com.sanz.dungeon.SanzDungeon;
import com.sanz.dungeon.model.Dungeon;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

/**
 * Baca/tulis semua dungeon ke dungeons.yml. Dipanggil pas plugin enable (load semua)
 * dan tiap kali ada perubahan (save semua ulang - sederhana, jumlah dungeon gak akan
 * banyak banget jadi gak masalah rewrite penuh tiap save).
 */
public class DungeonStorage {

    private final SanzDungeon plugin;
    private final File file;

    public DungeonStorage(SanzDungeon plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "dungeons.yml");
    }

    public List<Dungeon> loadAll() {
        List<Dungeon> result = new ArrayList<>();
        if (!file.exists()) {
            return result;
        }

        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yaml.getConfigurationSection("dungeons");
        if (section == null) return result;

        for (String key : section.getKeys(false)) {
            try {
                ConfigurationSection d = section.getConfigurationSection(key);
                if (d == null) continue;

                int id = Integer.parseInt(key);
                String name = d.getString("name", "Dungeon " + id);
                int level = d.getInt("level", 1);
                boolean premium = d.getBoolean("premium", false);
                double price = d.getDouble("price", 0.0);

                Dungeon dungeon = new Dungeon(id, name, level, premium, price);
                dungeon.setEnabled(d.getBoolean("enabled", false));

                if (d.contains("location.world")) {
                    dungeon.setRegion(
                            d.getString("location.world"),
                            d.getDouble("location.pos1.x"),
                            d.getDouble("location.pos1.y"),
                            d.getDouble("location.pos1.z"),
                            d.getDouble("location.pos2.x"),
                            d.getDouble("location.pos2.y"),
                            d.getDouble("location.pos2.z")
                    );

                    var world = plugin.getServer().getWorld(d.getString("location.world"));
                    if (world != null) {
                        org.bukkit.Location spawnLoc = new org.bukkit.Location(
                                world,
                                d.getDouble("location.spawn.x"),
                                d.getDouble("location.spawn.y"),
                                d.getDouble("location.spawn.z"),
                                (float) d.getDouble("location.spawn.yaw"),
                                (float) d.getDouble("location.spawn.pitch")
                        );
                        dungeon.setSpawn(spawnLoc);
                    }

                    if (d.getBoolean("location-complete", false)) {
                        dungeon.markLocationComplete();
                    }
                }

                result.add(dungeon);
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Gagal load dungeon dengan key '" + key + "'", e);
            }
        }

        return result;
    }

    public void saveAll(List<Dungeon> dungeons) {
        YamlConfiguration yaml = new YamlConfiguration();

        for (Dungeon d : dungeons) {
            String path = "dungeons." + d.getId();
            yaml.set(path + ".name", d.getName());
            yaml.set(path + ".level", d.getLevel());
            yaml.set(path + ".premium", d.isPremium());
            yaml.set(path + ".price", d.getPrice());
            yaml.set(path + ".enabled", d.isEnabled());
            yaml.set(path + ".location-complete", d.isLocationSet());

            if (d.getWorldName() != null) {
                yaml.set(path + ".location.world", d.getWorldName());
                yaml.set(path + ".location.pos1.x", d.getPos1X());
                yaml.set(path + ".location.pos1.y", d.getPos1Y());
                yaml.set(path + ".location.pos1.z", d.getPos1Z());
                yaml.set(path + ".location.pos2.x", d.getPos2X());
                yaml.set(path + ".location.pos2.y", d.getPos2Y());
                yaml.set(path + ".location.pos2.z", d.getPos2Z());
                yaml.set(path + ".location.spawn.x", d.getSpawnX());
                yaml.set(path + ".location.spawn.y", d.getSpawnY());
                yaml.set(path + ".location.spawn.z", d.getSpawnZ());
                yaml.set(path + ".location.spawn.yaw", d.getSpawnYaw());
                yaml.set(path + ".location.spawn.pitch", d.getSpawnPitch());
            }
        }

        try {
            if (!plugin.getDataFolder().exists()) {
                plugin.getDataFolder().mkdirs();
            }
            yaml.save(file);
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Gagal simpan dungeons.yml", e);
        }
    }
}
