package com.sanz.dungeon.managers;

import com.sanz.dungeon.SanzDungeon;
import com.sanz.dungeon.model.Dungeon;
import com.sanz.dungeon.model.DungeonSession;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class DungeonManager {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzDungeon plugin;
    private final Map<Integer, Dungeon> dungeons = new ConcurrentHashMap<>();
    private final Map<UUID, DungeonSession> activeSessions = new ConcurrentHashMap<>();
    private final Set<UUID> internalTeleportFlags = ConcurrentHashMap.newKeySet();
    private final AtomicInteger nextId = new AtomicInteger(1);

    public DungeonManager(SanzDungeon plugin) {
        this.plugin = plugin;
    }

    public void loadFromStorage() {
        List<Dungeon> loaded = plugin.getStorage().loadAll();
        for (Dungeon d : loaded) {
            dungeons.put(d.getId(), d);
            if (d.getId() >= nextId.get()) {
                nextId.set(d.getId() + 1);
            }
        }
    }

    public void saveAll() {
        plugin.getStorage().saveAll(new ArrayList<>(dungeons.values()));
    }

    /** Bikin 7 dungeon default (level 1-7, 1-3 gratis, 4-7 bayar) - dipanggil kalau belum ada dungeon sama sekali. */
    public void createDefaultDungeonsIfEmpty() {
        if (!dungeons.isEmpty()) return;

        for (int level = 1; level <= 7; level++) {
            boolean premium = level >= 4;
            double price = premium ? level * 1000.0 : 0.0;
            Dungeon dungeon = new Dungeon(nextId.getAndIncrement(), "Dungeon Level " + level, level, premium, price);
            dungeons.put(dungeon.getId(), dungeon);
        }
        saveAll();
        plugin.getLogger().info("7 dungeon default dibuat (level 1-7). Set lokasinya pakai /dungeon wand + /dungeon setloc <id>.");
    }

    public Dungeon createDungeon(String name, int level, boolean premium, double price) {
        Dungeon dungeon = new Dungeon(nextId.getAndIncrement(), name, level, premium, price);
        dungeons.put(dungeon.getId(), dungeon);
        saveAll();
        return dungeon;
    }

    public boolean deleteDungeon(int id) {
        Dungeon removed = dungeons.remove(id);
        if (removed != null) {
            saveAll();
            return true;
        }
        return false;
    }

    public Dungeon getDungeon(int id) {
        return dungeons.get(id);
    }

    public List<Dungeon> getAllDungeons() {
        List<Dungeon> list = new ArrayList<>(dungeons.values());
        list.sort(Comparator.comparingInt(Dungeon::getLevel).thenComparingInt(Dungeon::getId));
        return list;
    }

    public boolean isInsideDungeon(UUID uuid) {
        return activeSessions.containsKey(uuid);
    }

    public DungeonSession getSession(UUID uuid) {
        return activeSessions.get(uuid);
    }

    /** Coba masukin player ke dungeon - handle cek premium/harga, teleport, world border. */
    public EntryResult enter(Player player, Dungeon dungeon) {
        if (!dungeon.isEnabled()) {
            return EntryResult.fail("&cDungeon ini belum siap (lokasi belum di-setting admin).");
        }
        if (isInsideDungeon(player.getUniqueId())) {
            return EntryResult.fail("&cKamu udah ada di dalam dungeon lain. Keluar dulu pakai /dungeon leave.");
        }

        if (dungeon.isPremium() && dungeon.getPrice() > 0) {
            if (!plugin.getVaultHook().isEnabled()) {
                return EntryResult.fail("&cVault gak aktif, dungeon premium gak bisa diproses sekarang.");
            }
            boolean success = plugin.getVaultHook().withdraw(player, dungeon.getPrice());
            if (!success) {
                return EntryResult.fail("&cUang kamu gak cukup buat masuk dungeon ini. Butuh: &f" + (long) dungeon.getPrice());
            }
        }

        var world = plugin.getServer().getWorld(dungeon.getWorldName());
        if (world == null) {
            return EntryResult.fail("&cWorld dungeon ini gak ketemu, hubungi admin.");
        }

        org.bukkit.Location returnLocation = player.getLocation();
        org.bukkit.Location spawnLocation = new org.bukkit.Location(
                world, dungeon.getSpawnX(), dungeon.getSpawnY(), dungeon.getSpawnZ(),
                dungeon.getSpawnYaw(), dungeon.getSpawnPitch()
        );

        activeSessions.put(player.getUniqueId(), new DungeonSession(dungeon.getId(), returnLocation));
        internalTeleportFlags.add(player.getUniqueId());
        player.teleport(spawnLocation);
        plugin.getWorldBorderManager().applyDungeonBorder(player, dungeon);

        return EntryResult.ok();
    }

    /** Keluarin player dari dungeon - balikin ke lokasi asal, reset world border. */
    public boolean leave(Player player) {
        DungeonSession session = activeSessions.remove(player.getUniqueId());

        // Reset border tetep dijalanin walau session-nya gak ada (misal abis /dungeon setloc
        // doang buat preview border, belum masuk sesi resmi lewat GUI).
        plugin.getWorldBorderManager().resetBorder(player);

        if (session == null) return false;

        if (session.getReturnLocation() != null) {
            internalTeleportFlags.add(player.getUniqueId());
            player.teleport(session.getReturnLocation());
        }
        return true;
    }

    /**
     * Dipanggil listener teleport pas player yang lagi di dalam dungeon ke-teleport
     * TANPA lewat /dungeon leave (misal /home, /rtp, /spawn, warp, dll). Kita anggap
     * itu keluar dungeon otomatis - reset border & session, TANPA nge-cancel/nge-teleport
     * ulang (biar teleport aslinya - /home dsb - tetep jalan normal).
     */
    public boolean consumeInternalTeleportFlag(UUID uuid) {
        return internalTeleportFlags.remove(uuid);
    }

    public void handleImplicitLeave(Player player) {
        activeSessions.remove(player.getUniqueId());
        plugin.getWorldBorderManager().resetBorder(player);
    }

    /** Dipanggil pas player disconnect - bersihin session tanpa teleport (world lagi mau unload player anyway). */
    public void cleanupOnQuit(UUID uuid) {
        activeSessions.remove(uuid);
        internalTeleportFlags.remove(uuid);
    }

    public record EntryResult(boolean success, String message) {
        static EntryResult ok() {
            return new EntryResult(true, null);
        }

        static EntryResult fail(String message) {
            return new EntryResult(false, message);
        }
    }
}
