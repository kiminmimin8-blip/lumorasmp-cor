package com.sanz.dungeon.model;

import org.bukkit.Location;

/**
 * Nyimpen state 1 player yang lagi masuk ke dungeon: dungeon mana yang dia masukin,
 * dan lokasi asal sebelum masuk (buat dibalikin pas /dungeon leave).
 */
public class DungeonSession {

    private final int dungeonId;
    private final Location returnLocation;

    public DungeonSession(int dungeonId, Location returnLocation) {
        this.dungeonId = dungeonId;
        this.returnLocation = returnLocation;
    }

    public int getDungeonId() {
        return dungeonId;
    }

    public Location getReturnLocation() {
        return returnLocation;
    }
}
