package com.sanz.dungeon.commands;

import com.sanz.dungeon.SanzDungeon;
import com.sanz.dungeon.model.Dungeon;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class DungeonCommand implements CommandExecutor, TabCompleter {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private static final List<String> SUB_COMMANDS = List.of(
            "admin", "wand", "setloc", "setspawn", "create", "delete", "leave", "list"
    );

    private final SanzDungeon plugin;

    public DungeonCommand(SanzDungeon plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }

        if (args.length == 0) {
            if (!player.hasPermission("sanzdungeon.use")) {
                player.sendMessage(LEGACY.deserialize("&cKamu gak punya izin buat pakai command ini."));
                return true;
            }
            plugin.getGui().openMain(player);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "leave" -> {
                boolean success = plugin.getDungeonManager().leave(player);
                player.sendMessage(LEGACY.deserialize(success
                        ? "&aKamu keluar dari dungeon."
                        : "&cKamu lagi gak ada di dalam dungeon."));
            }
            case "list" -> {
                player.sendMessage(LEGACY.deserialize("&7=== Daftar Dungeon ==="));
                for (Dungeon d : plugin.getDungeonManager().getAllDungeons()) {
                    player.sendMessage(LEGACY.deserialize("&f#" + d.getId() + " &7- " + d.getName()
                            + " &7(Level " + d.getLevel() + ", " + (d.isPremium() ? "&6Premium" : "&aGratis") + "&7)"));
                }
            }
            case "admin" -> {
                if (!requireAdmin(player)) return true;
                plugin.getGui().openAdminList(player);
            }
            case "wand" -> {
                if (!requireAdmin(player)) return true;
                player.getInventory().addItem(plugin.getSelectionManager().createWand());
                player.sendMessage(LEGACY.deserialize("&aDungeon wand dikasih. Klik kiri = pos1, klik kanan = pos2."));
            }
            case "create" -> {
                if (!requireAdmin(player)) return true;
                handleCreate(player, args);
            }
            case "delete" -> {
                if (!requireAdmin(player)) return true;
                handleDelete(player, args);
            }
            case "setloc" -> {
                if (!requireAdmin(player)) return true;
                handleSetloc(player, args);
            }
            case "setspawn" -> {
                if (!requireAdmin(player)) return true;
                handleSetspawn(player, args);
            }
            default -> sendUsage(player);
        }
        return true;
    }

    private boolean requireAdmin(Player player) {
        if (!player.hasPermission("sanzdungeon.admin")) {
            player.sendMessage(LEGACY.deserialize("&cKamu gak punya izin admin buat ini."));
            return false;
        }
        return true;
    }

    private void handleCreate(Player player, String[] args) {
        if (args.length < 4) {
            player.sendMessage(LEGACY.deserialize("&cUsage: /dungeon create <nama> <level> <harga>"));
            return;
        }
        try {
            String name = args[1];
            int level = Integer.parseInt(args[2]);
            double price = Double.parseDouble(args[3]);
            Dungeon d = plugin.getDungeonManager().createDungeon(name, level, price > 0, price);
            player.sendMessage(LEGACY.deserialize("&aDungeon &f" + name + " &adibuat (ID: &f" + d.getId() + "&a)."));
        } catch (NumberFormatException e) {
            player.sendMessage(LEGACY.deserialize("&cLevel/harga harus angka."));
        }
    }

    private void handleDelete(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(LEGACY.deserialize("&cUsage: /dungeon delete <id>"));
            return;
        }
        try {
            int id = Integer.parseInt(args[1]);
            boolean success = plugin.getDungeonManager().deleteDungeon(id);
            player.sendMessage(LEGACY.deserialize(success ? "&aDungeon #" + id + " dihapus." : "&cDungeon gak ketemu."));
        } catch (NumberFormatException e) {
            player.sendMessage(LEGACY.deserialize("&cID harus angka."));
        }
    }

    private void handleSetloc(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(LEGACY.deserialize("&cUsage: /dungeon setloc <id>"));
            return;
        }
        int id;
        try {
            id = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            player.sendMessage(LEGACY.deserialize("&cID harus angka."));
            return;
        }

        Dungeon dungeon = plugin.getDungeonManager().getDungeon(id);
        if (dungeon == null) {
            player.sendMessage(LEGACY.deserialize("&cDungeon gak ketemu."));
            return;
        }

        if (!plugin.getSelectionManager().hasCompleteSelection(player.getUniqueId())) {
            player.sendMessage(LEGACY.deserialize("&cSet dulu pos1 & pos2 pakai wand (satu world yang sama)."));
            return;
        }

        Location pos1 = plugin.getSelectionManager().getPos1(player.getUniqueId());
        Location pos2 = plugin.getSelectionManager().getPos2(player.getUniqueId());
        Location spawn = player.getLocation();

        dungeon.setRegion(pos1.getWorld().getName(), pos1.getX(), pos1.getY(), pos1.getZ(),
                pos2.getX(), pos2.getY(), pos2.getZ());
        dungeon.setSpawn(spawn);
        dungeon.markLocationComplete();
        plugin.getDungeonManager().saveAll();

        player.sendMessage(LEGACY.deserialize("&aLokasi dungeon &f" + dungeon.getName() + " &aberhasil di-set! Spawn = posisi kamu sekarang."));
    }

    private void handleSetspawn(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(LEGACY.deserialize("&cUsage: /dungeon setspawn <id>"));
            return;
        }
        int id;
        try {
            id = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            player.sendMessage(LEGACY.deserialize("&cID harus angka."));
            return;
        }

        Dungeon dungeon = plugin.getDungeonManager().getDungeon(id);
        if (dungeon == null) {
            player.sendMessage(LEGACY.deserialize("&cDungeon gak ketemu."));
            return;
        }
        if (!dungeon.isLocationSet()) {
            player.sendMessage(LEGACY.deserialize("&cSet region-nya dulu pakai /dungeon setloc " + id));
            return;
        }

        dungeon.setSpawn(player.getLocation());
        plugin.getDungeonManager().saveAll();
        player.sendMessage(LEGACY.deserialize("&aTitik spawn &f" + dungeon.getName() + " &adiupdate ke posisi kamu sekarang."));
    }

    private void sendUsage(Player player) {
        player.sendMessage(LEGACY.deserialize("&cUsage: /dungeon <admin|wand|setloc|setspawn|create|delete|leave|list>"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> result = new ArrayList<>();
            for (String s : SUB_COMMANDS) {
                if (s.startsWith(args[0].toLowerCase())) result.add(s);
            }
            return result;
        }

        if (args.length == 2 && (args[0].equalsIgnoreCase("setloc")
                || args[0].equalsIgnoreCase("setspawn")
                || args[0].equalsIgnoreCase("delete"))) {
            List<String> result = new ArrayList<>();
            for (Dungeon d : plugin.getDungeonManager().getAllDungeons()) {
                String idStr = String.valueOf(d.getId());
                if (idStr.startsWith(args[1])) result.add(idStr);
            }
            return result;
        }

        return List.of();
    }
}
