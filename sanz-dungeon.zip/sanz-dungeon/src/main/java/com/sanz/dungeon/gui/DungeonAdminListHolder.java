package com.sanz.dungeon.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.List;

public class DungeonAdminListHolder implements InventoryHolder {

    private final List<Integer> dungeonIdBySlot;
    public static final int ADD_BUTTON_SLOT = 49;

    public DungeonAdminListHolder(List<Integer> dungeonIdBySlot) {
        this.dungeonIdBySlot = dungeonIdBySlot;
    }

    public Integer getDungeonIdAt(int slot) {
        if (slot < 0 || slot >= dungeonIdBySlot.size()) return null;
        return dungeonIdBySlot.get(slot);
    }

    @Override
    public Inventory getInventory() {
        return null;
    }
}
