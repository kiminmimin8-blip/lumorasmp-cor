package com.sanz.dungeon.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Holder kosong buat GUI utama player, cuma dipakai buat identifikasi jenis inventory. */
public class DungeonMainHolder implements InventoryHolder {

    private final java.util.List<Integer> dungeonIdBySlot;

    public DungeonMainHolder(java.util.List<Integer> dungeonIdBySlot) {
        this.dungeonIdBySlot = dungeonIdBySlot;
    }

    public Integer getDungeonIdAt(int slot) {
        if (slot < 0 || slot >= dungeonIdBySlot.size()) return null;
        return dungeonIdBySlot.get(slot);
    }

    @Override
    public Inventory getInventory() {
        return null; // holder ini cuma dipakai buat identifikasi jenis GUI, bukan penyimpanan
    }
}
