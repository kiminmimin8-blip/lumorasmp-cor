package com.sanz.dungeon.managers;

import com.sanz.dungeon.model.Dungeon;
import org.bukkit.Bukkit;
import org.bukkit.WorldBorder;
import org.bukkit.entity.Player;

/**
 * World border VANILLA itu cuma bisa satu per world - gak cukup kalau 1 world
 * ada banyak dungeon sekaligus. Solusinya pakai per-player world border (Paper API:
 * Player#setWorldBorder), jadi tiap player yang lagi di dalam dungeon X cuma LIHAT
 * border versi dia sendiri (gak ngaruh ke player lain atau border asli world itu).
 */
public class WorldBorderManager {

    public void applyDungeonBorder(Player player, Dungeon dungeon) {
        WorldBorder border = Bukkit.createWorldBorder();
        border.setCenter(dungeon.getCenterX(), dungeon.getCenterZ());
        border.setSize(dungeon.getBorderSize());
        border.setWarningDistance(0);
        border.setWarningTime(0);
        player.setWorldBorder(border);
    }

    public void resetBorder(Player player) {
        player.setWorldBorder(null);
    }
}
