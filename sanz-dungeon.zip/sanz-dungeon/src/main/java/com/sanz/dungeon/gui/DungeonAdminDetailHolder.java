package com.sanz.dungeon.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class DungeonAdminDetailHolder implements InventoryHolder {

    public static final int EDIT_NAME_SLOT = 10;
    public static final int EDIT_PRICE_SLOT = 12;
    public static final int TOGGLE_PREMIUM_SLOT = 14;
    public static final int DELETE_SLOT = 16;
    public static final int BACK_SLOT = 22;

    private final int dungeonId;

    public DungeonAdminDetailHolder(int dungeonId) {
        this.dungeonId = dungeonId;
    }

    public int getDungeonId() {
        return dungeonId;
    }

    @Override
    public Inventory getInventory() {
        return null;
    }
}
