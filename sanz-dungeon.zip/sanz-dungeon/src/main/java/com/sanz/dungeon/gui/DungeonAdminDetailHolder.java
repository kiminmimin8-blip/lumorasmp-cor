package com.sanz.dungeon.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class DungeonAdminDetailHolder implements InventoryHolder {

    public static final int EDIT_PRICE_SLOT = 11;
    public static final int TOGGLE_PREMIUM_SLOT = 13;
    public static final int DELETE_SLOT = 15;
    public static final int BACK_SLOT = 22;

    private final int dungeonId;

    public DungeonAdminDetailHolder(int dungeonId) {
        this.dungeonId = dungeonId;
    }

    public int getDungeonId() {
        return dungeonId;
    }

    @Override
    public Inventory getInventory() {
        return null;
    }
}
