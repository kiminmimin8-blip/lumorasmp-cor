package com.sanz.dungeon.data;

import com.sanz.dungeon.SanzDungeon;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.logging.Level;

public class VaultHook {

    private final SanzDungeon plugin;
    private Economy economy;

    public VaultHook(SanzDungeon plugin) {
        this.plugin = plugin;
    }

    public boolean setup() {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
            plugin.getLogger().warning("Vault gak ketemu, dungeon premium (bayar) gak akan bisa dipakai sampai Vault ke-install.");
            return false;
        }
        try {
            RegisteredServiceProvider<Economy> rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
            if (rsp == null) return false;
            economy = rsp.getProvider();
            return true;
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Gagal setup Vault hook", e);
            return false;
        }
    }

    public boolean isEnabled() {
        return economy != null;
    }

    public double getBalance(OfflinePlayer player) {
        if (economy == null) return 0;
        return economy.getBalance(player);
    }

    public boolean withdraw(OfflinePlayer player, double amount) {
        if (economy == null) return false;
        if (economy.getBalance(player) < amount) return false;
        return economy.withdrawPlayer(player, amount).transactionSuccess();
    }
}
