package com.sanz.dungeon.listeners;

import com.sanz.dungeon.SanzDungeon;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerQuitListener implements Listener {

    private final SanzDungeon plugin;

    public PlayerQuitListener(SanzDungeon plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getDungeonManager().cleanupOnQuit(event.getPlayer().getUniqueId());
    }
}
