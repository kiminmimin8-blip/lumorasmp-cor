package com.sanz.dungeon.listeners;

import com.sanz.dungeon.SanzDungeon;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.plain.PlainTextComponentSerializer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

public class ChatInputListener implements Listener {

    private final SanzDungeon plugin;

    public ChatInputListener(SanzDungeon plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent event) {
        var uuid = event.getPlayer().getUniqueId();
        if (!plugin.getChatInputManager().isAwaiting(uuid)) return;

        event.setCancelled(true);
        String message = PlainTextComponentSerializer.plainText().serialize(event.message());

        // Handle-nya perlu balik ke main thread karena bakal ngubah data plugin & GUI
        plugin.getServer().getScheduler().runTask(plugin, () ->
                plugin.getChatInputManager().handleInput(uuid, message)
        );
    }
}
