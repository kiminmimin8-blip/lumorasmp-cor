package com.sentinelac.punishment;

import com.sentinelac.SentinelAC;
import com.sentinelac.utils.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class PunishmentManager {

    private final SentinelAC plugin;
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public PunishmentManager(SentinelAC plugin) {
        this.plugin = plugin;
    }

    public void punish(Player player, String checkKey) {
        List<String> commands = plugin.getConfigManager().getPunishments(checkKey);

        logToFile(player, checkKey);

        if (commands.isEmpty()) {
            plugin.getLogger().warning("No punishment configured for check '" + checkKey + "' — nothing done.");
            return;
        }

        // run on the player's own region thread since these commands
        // (kick/ban/etc) target that specific player — the legacy global
        // Bukkit scheduler used here before is not supported on Folia.
        player.getScheduler().run(plugin, task -> {
            for (String cmd : commands) {
                String resolved = cmd.replace("%player%", player.getName());
                resolved = TextUtil.color(resolved);
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), resolved);
            }
        }, null);
    }

    private void logToFile(Player player, String checkKey) {
        if (!plugin.getConfigManager().getB("settings.log-to-file", true)) return;

        try {
            Path dir = plugin.getDataFolder().toPath();
            if (!Files.exists(dir)) Files.createDirectories(dir);
            Path log = dir.resolve("violations.log");

            String line = String.format("[%s] %s failed %s (punishment triggered)%n",
                    LocalDateTime.now().format(formatter), player.getName(), checkKey);

            try (FileWriter fw = new FileWriter(log.toFile(), true)) {
                fw.write(line);
            }
        } catch (IOException e) {
            plugin.getLogger().warning("Could not write to violations.log: " + e.getMessage());
        }
    }
}
