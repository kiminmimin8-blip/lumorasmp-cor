package com.sentinelac.listeners;

import com.sentinelac.SentinelAC;
import com.sentinelac.data.PlayerData;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;

public class MovementListener implements Listener {

    private final SentinelAC plugin;

    public MovementListener(SentinelAC plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null) return;

        boolean positionChanged = from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ();
        boolean rotationChanged = from.getYaw() != to.getYaw() || from.getPitch() != to.getPitch();
        // BUGFIX: the old check only looked at X/Y/Z, so a player standing
        // completely still and just turning their head (extremely common
        // mid-combat — a lot of aim-assist/killaura happens with the feet
        // planted) never reached RotationCheck/InvalidPitchCheck at all.
        // Position-only checks below (Speed/Fly/etc.) just see a 0 delta on
        // a look-only tick and no-op harmlessly, so widening this is safe.
        if (!positionChanged && !rotationChanged) return;

        PlayerData data = plugin.getPlayerDataManager().get(player);

        if (data.pendingVerification && !data.verified) {
            data.hasMovedSinceJoin = true;
        }

        plugin.getBotDetectionManager().tickVerification(player, data);

        // Manual jump detection: Paper API has no PlayerJumpEvent, so we infer
        // a jump from the ground -> air transition (matches vanilla's jump
        // impulse being applied on the first airborne tick).
        boolean onGroundNow = player.isOnGround();
        if (data.wasOnGround && !onGroundNow && to.getY() > from.getY()) {
            data.lastJumpTime = System.currentTimeMillis();
            plugin.getFlyCheck().onJump(player, data);
        }

        plugin.getSpeedCheck().handle(player, data, from, to);
        plugin.getFlyCheck().handle(player, data, from, to);
        plugin.getJesusCheck().handle(player, data, to);
        plugin.getNoSlowCheck().handle(player, data, from, to);
        plugin.getStepCheck().handle(player, data, from, to);
        plugin.getInventoryMoveCheck().handle(player, data, from, to);
        plugin.getInvalidPitchCheck().handle(player, data);
        plugin.getSpiderCheck().handle(player, data, from, to);
        plugin.getRotationCheck().handle(player, data, to.getYaw());

        data.previousLocation = data.lastLocation;
        data.lastLocation = to.clone();
        data.wasOnGround = player.isOnGround();
    }

    @EventHandler
    public void onFallDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) return;

        PlayerData data = plugin.getPlayerDataManager().get(player);
        double fallDistance = player.getFallDistance();
        double damage = event.isCancelled() ? 0 : event.getFinalDamage();

        plugin.getNoFallCheck().onFallDamageEvent(player, data, fallDistance, damage);
    }
}
