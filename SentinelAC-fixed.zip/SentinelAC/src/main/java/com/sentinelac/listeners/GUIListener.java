package com.sentinelac.listeners;

import com.sentinelac.SentinelAC;
import com.sentinelac.data.PlayerData;
import com.sentinelac.gui.WatchlistGUI;
import com.sentinelac.gui.WatchlistHolder;
import com.sentinelac.utils.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class GUIListener implements Listener {

    private final SentinelAC plugin;

    public GUIListener(SentinelAC plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof WatchlistHolder holder)) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player staff)) return;
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null) return;

        if (clicked.getType() == Material.BARRIER) {
            staff.closeInventory();
            return;
        }
        if (clicked.getType() == Material.LIME_DYE) {
            WatchlistGUI.open(staff, plugin);
            return;
        }

        UUID target = holder.get(event.getSlot());
        if (target == null) return;

        OfflinePlayer off = Bukkit.getOfflinePlayer(target);
        Player online = off.getPlayer();

        if (event.isRightClick()) {
            if (online != null && online.isOnline()) {
                // dispatch onto the target's own region thread — kicking them
                // directly from here would be a cross-thread call on Folia
                // if they're in a different region than the staff member
                online.getScheduler().run(plugin, task ->
                        online.kickPlayer(TextUtil.color("&cKicked by staff via SentinelAC watchlist.")), null);
                staff.sendMessage(TextUtil.color("&aKicked " + off.getName() + "."));
            } else {
                staff.sendMessage(TextUtil.color("&cThat player isn't online."));
            }
            WatchlistGUI.open(staff, plugin);
            return;
        }

        if (event.isShiftClick()) {
            if (online != null && online.isOnline()) {
                // same reasoning as above: mutate the target's PlayerData on
                // their own region thread, not the staff member's
                online.getScheduler().run(plugin, task -> {
                    PlayerData data = plugin.getPlayerDataManager().get(online);
                    data.frozen = !data.frozen;
                    staff.sendMessage(TextUtil.color(data.frozen ? "&bFroze " + off.getName() + "." : "&aUnfroze " + off.getName() + "."));
                }, null);
            } else {
                staff.sendMessage(TextUtil.color("&cThat player isn't online."));
            }
            WatchlistGUI.open(staff, plugin);
            return;
        }

        // plain left-click: teleport (async — the target may be in a
        // different world/region than the staff member on Folia)
        if (online != null && online.isOnline()) {
            staff.teleportAsync(online.getLocation());
            staff.sendMessage(TextUtil.color("&aTeleported to " + off.getName() + "."));
            staff.closeInventory();
        } else {
            staff.sendMessage(TextUtil.color("&cThat player isn't online."));
        }
    }
}
