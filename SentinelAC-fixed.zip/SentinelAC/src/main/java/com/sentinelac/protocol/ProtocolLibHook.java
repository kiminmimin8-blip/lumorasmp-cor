package com.sentinelac.protocol;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.ListenerPriority;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;
import com.sentinelac.SentinelAC;
import com.sentinelac.data.PlayerData;
import org.bukkit.entity.Player;

/**
 * Bridges ProtocolLib's raw packet stream into SentinelAC's check system.
 *
 * This class is ONLY ever instantiated from SentinelAC#onEnable, and only
 * after confirming the ProtocolLib plugin is actually present and enabled.
 * That guard matters: the JVM only links/verifies a class's referenced
 * types (com.comphenix.protocol.*) the first time the class is actively
 * used (instantiated, in this case) — so as long as nothing else in the
 * plugin references ProtocolLibHook directly, the server runs fine with
 * SentinelAC installed but ProtocolLib absent; this class simply never
 * gets loaded, and Timer/Blink silently sit disabled instead of crashing
 * plugin startup with a NoClassDefFoundError.
 */
public class ProtocolLibHook {

    private final SentinelAC plugin;
    private final ProtocolManager protocolManager;

    public ProtocolLibHook(SentinelAC plugin) {
        this.plugin = plugin;
        this.protocolManager = ProtocolLibrary.getProtocolManager();
    }

    public void register() {
        protocolManager.addPacketListener(new PacketAdapter(plugin, ListenerPriority.MONITOR,
                PacketType.Play.Client.POSITION,
                PacketType.Play.Client.POSITION_LOOK,
                PacketType.Play.Client.LOOK,
                PacketType.Play.Client.FLYING) {
            @Override
            public void onPacketReceiving(PacketEvent event) {
                Player player = event.getPlayer();
                if (player == null || !player.isOnline()) return;

                // PacketAdapter (superclass di sini) punya field warisan `protected Plugin plugin`
                // bertipe org.bukkit.plugin.Plugin, yang nge-shadow field `plugin` (SentinelAC)
                // milik ProtocolLibHook -- makanya harus di-qualify eksplisit pakai
                // ProtocolLibHook.this, kalau nggak javac bakal resolve ke field yang salah.
                SentinelAC sentinelAC = ProtocolLibHook.this.plugin;
                PlayerData data = sentinelAC.getPlayerDataManager().get(player);
                sentinelAC.getTimerCheck().onMovementPacket(player, data);
                sentinelAC.getBlinkCheck().onMovementPacket(player, data);
            }
        });
    }

    public void unregister() {
        protocolManager.removePacketListeners(plugin);
    }
}
