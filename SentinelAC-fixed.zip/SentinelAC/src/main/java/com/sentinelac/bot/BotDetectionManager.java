package com.sentinelac.bot;

import com.sentinelac.SentinelAC;
import com.sentinelac.data.PlayerData;
import com.sentinelac.utils.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/**
 * Handles two separate problems that people lump together as "anti bot":
 *
 *  1. Join-flood / attack-mode: when a burst of connections hits the server
 *     (the classic botnet join-flood attempt), we flip into a stricter mode
 *     for a while where verification is mandatory for everyone.
 *
 *  2. Per-player bot heuristics: suspicious username patterns, too many
 *     accounts from one IP in a short window, and "spawned but never moved
 *     or looked around" behaviour (real players almost always move their
 *     mouse within the first couple seconds; static bot clients often don't).
 */
public class BotDetectionManager {

    private final SentinelAC plugin;
    private final LinkedList<Long> recentJoinTimestamps = new LinkedList<>();
    private final Map<String, LinkedList<Long>> joinsByIp = new ConcurrentHashMap<>();
    private boolean attackMode = false;
    private long attackModeUntil = 0;
    private List<Pattern> compiledPatterns;

    public BotDetectionManager(SentinelAC plugin) {
        this.plugin = plugin;
        compilePatterns();
    }

    public void compilePatterns() {
        compiledPatterns = plugin.getConfigManager().getNamePatterns().stream()
                .map(Pattern::compile)
                .toList();
    }

    public boolean isAttackMode() {
        synchronized (this) {
            if (attackMode && System.currentTimeMillis() > attackModeUntil) {
                attackMode = false;
                Bukkit.broadcast(net.kyori.adventure.text.Component.text(
                        TextUtil.color(plugin.getConfigManager().getS("alerts.broadcast-attack-mode-end",
                                "&aAttack mode ended."))));
            }
            return attackMode;
        }
    }

    /** Call on PlayerJoinEvent (or better, AsyncPlayerPreLoginEvent) to register the join and evaluate flood state. */
    public void registerJoin(String ip) {
        if (!plugin.getConfigManager().getB("anti-bot.enabled", true)) return;

        long now = System.currentTimeMillis();
        long window = plugin.getConfigManager().getL("anti-bot.join-flood.window-ms", 4000);

        // AsyncPlayerPreLoginEvent fires off the main thread and can run
        // concurrently for multiple simultaneous connections — exactly the
        // join-flood scenario this class exists to catch — so the shared
        // recentJoinTimestamps list needs explicit synchronization, not just
        // a thread-safe map wrapper.
        int size;
        synchronized (this) {
            recentJoinTimestamps.addLast(now);
            recentJoinTimestamps.removeIf(t -> now - t > window);
            size = recentJoinTimestamps.size();

            int threshold = plugin.getConfigManager().getI("anti-bot.join-flood.joins-threshold", 6);
            if (!attackMode && size >= threshold) {
                enableAttackMode();
            }
        }

        if (ip != null) {
            LinkedList<Long> ipJoins = joinsByIp.computeIfAbsent(ip, k -> new LinkedList<>());
            synchronized (ipJoins) {
                ipJoins.addLast(now);
                ipJoins.removeIf(t -> now - t > 60000);
            }
        }
    }

    private void enableAttackMode() {
        attackMode = true;
        int seconds = plugin.getConfigManager().getI("anti-bot.join-flood.attack-mode-duration-seconds", 90);
        attackModeUntil = System.currentTimeMillis() + (seconds * 1000L);

        if (plugin.getConfigManager().getB("anti-bot.actions.on-attack-mode-start-broadcast-staff", true)) {
            String msg = TextUtil.color(plugin.getConfigManager().getS("anti-bot.join-flood.broadcast",
                    plugin.getConfigManager().getS("alerts.broadcast-attack-mode-start",
                            "&cJoin-flood detected — attack mode enabled.")));
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.hasPermission("sentinelac.alerts")) {
                    p.sendMessage(msg);
                }
            }
            plugin.getLogger().warning("Attack mode ENABLED — join flood detected.");
        }
    }

    public boolean isDuplicateIpFlood(String ip) {
        if (!plugin.getConfigManager().getB("anti-bot.duplicate-ip.enabled", true)) return false;
        LinkedList<Long> list = joinsByIp.get(ip);
        if (list == null) return false;
        int max = plugin.getConfigManager().getI("anti-bot.duplicate-ip.max-accounts-per-ip-per-minute", 4);
        synchronized (list) {
            return list.size() > max;
        }
    }

    /** True if the username itself matches a known-bot naming pattern. */
    public boolean nameLooksLikeBot(String name) {
        if (!plugin.getConfigManager().getB("anti-bot.name-patterns.enabled", true)) return false;
        for (Pattern p : compiledPatterns) {
            if (p.matcher(name).matches()) return true;
        }
        return false;
    }

    /** Called every tick for players pending verification (see PlayerData#pendingVerification). */
    public void tickVerification(Player player, PlayerData data) {
        if (!data.pendingVerification || data.verified) return;

        data.ticksSinceJoin++;

        float yawDelta = Math.abs(player.getLocation().getYaw() - data.initialYaw);
        float pitchDelta = Math.abs(player.getLocation().getPitch() - data.initialPitch);
        if (yawDelta > 2 || pitchDelta > 2) {
            data.hasLookedSinceJoin = true;
        }

        int maxTicks = plugin.getConfigManager().getI("anti-bot.verification.max-ticks-to-verify", 200);

        if (data.hasLookedSinceJoin || data.hasMovedSinceJoin) {
            data.verified = true;
            data.pendingVerification = false;
            return;
        }

        if (data.ticksSinceJoin > maxTicks) {
            data.flaggedAsBot = true;
            String action = plugin.getConfigManager().getS("anti-bot.actions.on-flagged-bot", "kick");
            String kickMsg = TextUtil.color(plugin.getConfigManager().getS(
                    "anti-bot.verification.kick-message", "&cVerification failed. Please reconnect."));

            switch (action) {
                case "ban-ip" -> {
                    Bukkit.getBanList(org.bukkit.BanList.Type.IP).addBan(
                            player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : "unknown",
                            "SentinelAC: failed bot verification", null, "SentinelAC");
                    player.kickPlayer(kickMsg);
                }
                case "freeze" -> data.frozen = true;
                default -> player.kickPlayer(kickMsg);
            }
            plugin.getLogger().info("Player " + player.getName() + " failed bot verification (" + action + ").");
        }
    }
}
