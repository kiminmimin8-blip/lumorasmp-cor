package com.sentinelac;

import com.sentinelac.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/**
 * Runs every second: decays old violation levels so a single burst of
 * flags doesn't permanently haunt a player, and re-teleports frozen
 * players back to their last known-good spot.
 *
 * Uses the Folia-safe scheduler APIs (GlobalRegionScheduler + per-entity
 * EntityScheduler) instead of the legacy BukkitScheduler, since Folia runs
 * each world region on its own thread — iterating all online players from
 * a single global tick and touching their PlayerData/teleporting them
 * directly would be a cross-thread violation there. These APIs also work
 * fine on regular (non-Folia) Paper, so this is safe either way.
 */
public class SentinelTask {

    private final SentinelAC plugin;

    public SentinelTask(SentinelAC plugin) {
        this.plugin = plugin;
    }

    /** Starts the repeating tick. Call once from onEnable(). */
    public void start() {
        Bukkit.getGlobalRegionScheduler().runAtFixedRate(plugin, task -> tick(), 20L, 20L);
    }

    private void tick() {
        double decayAmount = plugin.getConfigManager().getD("settings.violation-decay-amount", 1);
        long decayAfterMs = plugin.getConfigManager().getL("settings.violation-decay-seconds", 60) * 1000L;

        for (Player player : Bukkit.getOnlinePlayers()) {
            // Dispatch the per-player work onto that player's own region
            // thread. If the player has left/moved by the time this runs,
            // it's simply skipped (retired callback is fine to omit here).
            player.getScheduler().run(plugin, scheduledTask -> {
                PlayerData data = plugin.getPlayerDataManager().get(player);
                data.decayAll(decayAmount, decayAfterMs);

                if (data.frozen && data.lastLocation != null) {
                    player.teleportAsync(data.lastLocation);
                }
            }, null);
        }
    }
}
