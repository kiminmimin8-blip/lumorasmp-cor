package com.sanz.dungeon;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

public class DungeonMoveListener implements Listener {

    private final DungeonProtectionListener protection;

    public DungeonMoveListener(DungeonProtectionListener protection) {
        this.protection = protection;
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        // cuma cek kalau blok berubah, biar gak berat tiap tick
        if (e.getFrom().getBlockX() == e.getTo().getBlockX()
                && e.getFrom().getBlockY() == e.getTo().getBlockY()
                && e.getFrom().getBlockZ() == e.getTo().getBlockZ()) {
            return;
        }
        protection.checkRegion(e.getPlayer());
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        // Folia: pakai entity scheduler player-nya, bukan Bukkit.getScheduler() global,
        // biar task-nya jalan di thread region yg bener setelah player pindah.
        org.bukkit.plugin.Plugin plugin = org.bukkit.Bukkit.getPluginManager().getPlugin("SanzDungeon");
        org.bukkit.entity.Player p = e.getPlayer();
        p.getScheduler().run(plugin, (task) -> protection.checkRegion(p), null);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        protection.handleQuit(e.getPlayer());
    }
}
