package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ShopEditListener implements Listener {

    private static final List<String> CURRENCIES = List.of("money", "cash", "shards");

    private final DungeonShopManager shopManager;
    private final ShopEditGUI editGUI;
    private final ShopEditSession session;
    private final Map<UUID, Integer> pendingDelete = new ConcurrentHashMap<>();

    public ShopEditListener(DungeonShopManager shopManager, ShopEditGUI editGUI, ShopEditSession session) {
        this.shopManager = shopManager;
        this.editGUI = editGUI;
        this.session = session;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof ShopEditHolder holder)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;

        // klik di inventory player sendiri (bawah) dibiarin normal
        if (e.getClickedInventory() != null && !e.getClickedInventory().equals(e.getView().getTopInventory())) {
            return;
        }

        int slot = e.getRawSlot();

        if (holder.getMode() == ShopEditHolder.Mode.DETAIL
                && (slot == ShopEditHolder.INPUT_SLOT
                    || (slot == ShopEditHolder.OUTPUT_SLOT && !"noop".equals(holder.getAction(slot))))) {
            // slot editable beneran - biarin player taro/ambil item, gak di-cancel
            return;
        }

        e.setCancelled(true);
        String action = holder.getAction(slot);
        if (action == null) return;

        if (holder.getMode() == ShopEditHolder.Mode.LIST) {
            handleListClick(p, action);
            return;
        }

        handleDetailClick(p, holder, action);
    }

    private void handleListClick(Player p, String action) {
        if (action.equals("create")) {
            ShopTrade t = shopManager.create();
            p.openInventory(editGUI.buildDetail(t));
            return;
        }
        if (action.startsWith("open:")) {
            int id = Integer.parseInt(action.substring("open:".length()));
            ShopTrade t = shopManager.get(id);
            if (t != null) p.openInventory(editGUI.buildDetail(t));
        }
    }

    private void handleDetailClick(Player p, ShopEditHolder holder, String action) {
        ShopTrade t = shopManager.get(holder.getTradeId());
        if (t == null) { p.closeInventory(); return; }

        switch (action) {
            case "toggle_mode" -> {
                t.setOutputType(t.getOutputType() == ShopTrade.OutputType.ITEM ? ShopTrade.OutputType.MONEY : ShopTrade.OutputType.ITEM);
                p.openInventory(editGUI.buildDetail(t));
            }
            case "cycle_currency" -> {
                int idx = CURRENCIES.indexOf(t.getOutputCurrency().toLowerCase());
                t.setOutputCurrency(CURRENCIES.get((idx + 1) % CURRENCIES.size()));
                p.openInventory(editGUI.buildDetail(t));
            }
            case "rename" -> {
                p.closeInventory();
                session.awaitRename(p.getUniqueId(), t.getId());
                p.sendMessage(ChatColor.YELLOW + "Ketik nama trade baru di chat:");
            }
            case "save" -> {
                // ambil item yg ditaro di slot input/output pas SIMPAN diklik
                ItemStack input = p.getOpenInventory().getTopInventory().getItem(ShopEditHolder.INPUT_SLOT);
                if (input != null && input.getType() != Material.AIR) {
                    t.setInputMaterial(input.getType());
                    t.setInputAmount(input.getAmount());
                } else {
                    t.setInputMaterial(Material.AIR);
                    t.setInputAmount(0);
                }

                if (t.getOutputType() == ShopTrade.OutputType.ITEM) {
                    ItemStack output = p.getOpenInventory().getTopInventory().getItem(ShopEditHolder.OUTPUT_SLOT);
                    if (output != null && output.getType() != Material.AIR) {
                        t.setOutputMaterial(output.getType());
                        t.setOutputAmount(output.getAmount());
                    } else {
                        t.setOutputMaterial(Material.AIR);
                        t.setOutputAmount(0);
                    }
                }

                shopManager.save();
                if (t.isReady()) {
                    p.sendMessage(ChatColor.GREEN + "Trade tersimpan & langsung tampil di /dungeon shop.");
                } else {
                    p.sendMessage(ChatColor.YELLOW + "Tersimpan, tapi masih belum lengkap jadi belum tampil di /dungeon shop.");
                }
                p.openInventory(editGUI.buildList());
            }
            case "delete" -> {
                if (Integer.valueOf(t.getId()).equals(pendingDelete.get(p.getUniqueId()))) {
                    shopManager.remove(t.getId());
                    pendingDelete.remove(p.getUniqueId());
                    p.sendMessage(ChatColor.RED + "Trade dihapus.");
                    p.openInventory(editGUI.buildList());
                } else {
                    pendingDelete.put(p.getUniqueId(), t.getId());
                    p.sendMessage(ChatColor.RED + "Klik lagi buat konfirmasi hapus.");
                }
            }
            case "back" -> p.openInventory(editGUI.buildList());
            default -> {
                if (action.startsWith("money:")) {
                    double delta = Double.parseDouble(action.substring("money:".length()));
                    t.setOutputMoney(t.getOutputMoney() + delta);
                    p.openInventory(editGUI.buildDetail(t));
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        Integer tradeId = session.get(p.getUniqueId());
        if (tradeId == null) return;

        e.setCancelled(true);
        String msg = e.getMessage().trim();
        session.clear(p.getUniqueId());

        p.getScheduler().run(
                org.bukkit.Bukkit.getPluginManager().getPlugin("SanzDungeon"),
                (task) -> {
                    ShopTrade t = shopManager.get(tradeId);
                    if (t == null) return;
                    t.setLabel(msg);
                    shopManager.save();
                    p.sendMessage(ChatColor.GREEN + "Nama trade diubah.");
                    p.openInventory(editGUI.buildDetail(t));
                },
                null
        );
    }
}
