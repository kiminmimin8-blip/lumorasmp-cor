package com.sentinelac.config;

import com.sentinelac.SentinelAC;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.List;

public class ConfigManager {

    private final SentinelAC plugin;
    private FileConfiguration cfg;

    public ConfigManager(SentinelAC plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        plugin.reloadConfig();
        this.cfg = plugin.getConfig();
    }

    public FileConfiguration raw() { return cfg; }
    public boolean debug() { return cfg.getBoolean("settings.debug", false); }
    public boolean checkEnabled(String checkKey) { return cfg.getBoolean("checks." + checkKey + ".enabled", true); }
    public double getD(String path, double def) { return cfg.getDouble(path, def); }
    public int getI(String path, int def) { return cfg.getInt(path, def); }
    public long getL(String path, long def) { return cfg.getLong(path, def); }
    public boolean getB(String path, boolean def) { return cfg.getBoolean(path, def); }
    public String getS(String path, String def) { return cfg.getString(path, def); }
    public List<String> getPunishments(String checkKey) { return cfg.getStringList("punishments." + checkKey); }
    public List<String> getNamePatterns() { return cfg.getStringList("anti-bot.name-patterns.suspicious-regex"); }
}
