package com.sentinelac.watchlist;

import com.sentinelac.SentinelAC;
import com.sentinelac.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

public class WatchlistManager {

    public static class Entry {
        public final UUID uuid;
        public String name;
        public double totalVl;
        public String lastFlag;
        public long lastSeen;

        Entry(UUID uuid, String name) {
            this.uuid = uuid;
            this.name = name;
        }
    }

    private final SentinelAC plugin;
    private final Map<UUID, Entry> entries = new LinkedHashMap<>();

    public WatchlistManager(SentinelAC plugin) {
        this.plugin = plugin;
    }

    public void markFlagged(Player player, PlayerData data) {
        double threshold = plugin.getConfigManager().getD("watchlist.enter-threshold-total-vl", 3);
        if (data.totalVlEver < threshold) return;

        Entry e = entries.computeIfAbsent(player.getUniqueId(), id -> new Entry(id, player.getName()));
        e.name = player.getName();
        e.totalVl = data.totalVlEver;
        e.lastFlag = data.lastFlagSummary;
        e.lastSeen = System.currentTimeMillis();
    }

    public void touchSeen(Player player) {
        Entry e = entries.get(player.getUniqueId());
        if (e != null) e.lastSeen = System.currentTimeMillis();
    }

    public List<Entry> getSorted() {
        long keepMs = plugin.getConfigManager().getI("watchlist.keep-offline-minutes", 30) * 60_000L;
        long now = System.currentTimeMillis();

        entries.values().removeIf(e -> {
            OfflinePlayer op = Bukkit.getOfflinePlayer(e.uuid);
            boolean online = op.isOnline();
            return !online && (now - e.lastSeen) > keepMs;
        });

        return entries.values().stream()
                .sorted((a, b) -> Double.compare(b.totalVl, a.totalVl))
                .collect(Collectors.toList());
    }

    public Entry get(UUID uuid) { return entries.get(uuid); }
    public int size() { return entries.size(); }
}
