package com.sentinelac.commands;

import com.sentinelac.SentinelAC;
import com.sentinelac.data.PlayerData;
import com.sentinelac.gui.WatchlistGUI;
import com.sentinelac.utils.TextUtil;
import com.sentinelac.watchlist.WatchlistManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SentinelACCommand implements CommandExecutor, TabCompleter {

    private final SentinelAC plugin;

    public SentinelACCommand(SentinelAC plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("sentinelac.admin")) {
            sender.sendMessage(TextUtil.color("&cYou don't have permission to use this."));
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.getConfigManager().load();
                plugin.getBotDetectionManager().compilePatterns();
                sender.sendMessage(TextUtil.color("&aSentinelAC config reloaded."));
            }
            case "alerts" -> {
                boolean muted = plugin.getAlertManager().isMuted();
                plugin.getAlertManager().setMuted(!muted);
                sender.sendMessage(TextUtil.color(!muted ? "&7Alerts muted." : "&aAlerts unmuted."));
            }
            case "vl" -> {
                if (args.length < 2) { sender.sendMessage(TextUtil.color("&cUsage: /sac vl <player>")); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(TextUtil.color("&cPlayer not found.")); return true; }
                PlayerData data = plugin.getPlayerDataManager().get(target);
                sender.sendMessage(TextUtil.color("&8--- &cVL &7for &f" + target.getName() + " &8---"));
                for (String key : List.of("speed", "fly", "nofall", "jesus", "noslow", "step",
                        "killaura", "reach", "autoclicker", "fastbreak", "fastplace", "nuker", "scaffold",
                        "knockback", "inventorymove", "fastuse", "invalidpitch",
                        "spider", "airplace", "timer", "blink", "rotation", "noswing")) {
                    double vl = data.getVL(key);
                    if (vl > 0) sender.sendMessage(TextUtil.color("&7" + key + ": &f" + String.format("%.1f", vl)));
                }
                sender.sendMessage(TextUtil.color("&7Total ever: &c" + String.format("%.1f", data.totalVlEver)));
            }
            case "gui", "check", "watchlist" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage(TextUtil.color("&cIn-game only.")); return true; }
                WatchlistGUI.open(p, plugin);
            }
            case "top" -> {
                List<WatchlistManager.Entry> entries = plugin.getWatchlistManager().getSorted();
                if (entries.isEmpty()) { sender.sendMessage(TextUtil.color("&7Nobody on the watchlist right now.")); return true; }
                sender.sendMessage(TextUtil.color("&8--- &cTop flagged players &8---"));
                int rank = 1;
                for (WatchlistManager.Entry e : entries) {
                    if (rank > 10) break;
                    sender.sendMessage(TextUtil.color("&7#" + rank + " &f" + e.name + " &7- &c" + String.format("%.1f", e.totalVl) + " &7VL (" + e.lastFlag + ")"));
                    rank++;
                }
            }
            case "history" -> {
                if (args.length < 2) { sender.sendMessage(TextUtil.color("&cUsage: /sac history <player>")); return true; }
                sendHistory(sender, args[1]);
            }
            case "exempt" -> {
                sender.sendMessage(TextUtil.color("&7Use the permission node &fsentinelac.bypass &7via your permissions plugin instead of a runtime toggle — this keeps exemptions consistent across restarts."));
            }
            case "freeze" -> {
                if (args.length < 2) { sender.sendMessage(TextUtil.color("&cUsage: /sac freeze <player>")); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(TextUtil.color("&cPlayer not found.")); return true; }
                plugin.getPlayerDataManager().get(target).frozen = true;
                sender.sendMessage(TextUtil.color("&aFroze " + target.getName() + "."));
            }
            case "unfreeze" -> {
                if (args.length < 2) { sender.sendMessage(TextUtil.color("&cUsage: /sac unfreeze <player>")); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(TextUtil.color("&cPlayer not found.")); return true; }
                plugin.getPlayerDataManager().get(target).frozen = false;
                sender.sendMessage(TextUtil.color("&aUnfroze " + target.getName() + "."));
            }
            case "panic" -> {
                sender.sendMessage(TextUtil.color("&cPanic mode: kicking all unverified/flagged players..."));
                for (Player p : Bukkit.getOnlinePlayers()) {
                    PlayerData d = plugin.getPlayerDataManager().get(p);
                    if (d.flaggedAsBot || (d.pendingVerification && !d.verified)) {
                        p.kickPlayer(TextUtil.color("&cServer is under protection. Please reconnect shortly."));
                    }
                }
            }
            default -> sendHelp(sender);
        }
        return true;
    }

    private void sendHistory(CommandSender sender, String playerName) {
        try {
            Path log = plugin.getDataFolder().toPath().resolve("violations.log");
            if (!Files.exists(log)) { sender.sendMessage(TextUtil.color("&7No violation log yet.")); return; }

            List<String> lines = Files.readAllLines(log);
            List<String> matches = lines.stream()
                    .filter(l -> l.contains(" " + playerName + " "))
                    .toList();

            if (matches.isEmpty()) { sender.sendMessage(TextUtil.color("&7No recorded punishments for " + playerName + ".")); return; }

            sender.sendMessage(TextUtil.color("&8--- &cHistory &7for &f" + playerName + " &8(last 10) ---"));
            int start = Math.max(0, matches.size() - 10);
            for (String line : matches.subList(start, matches.size())) {
                sender.sendMessage(TextUtil.color("&7" + line));
            }
        } catch (IOException e) {
            sender.sendMessage(TextUtil.color("&cCouldn't read violations.log: " + e.getMessage()));
        }
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(TextUtil.color("&8--- &cSentinelAC &8---"));
        boolean protocolActive = org.bukkit.Bukkit.getPluginManager().isPluginEnabled("ProtocolLib");
        sender.sendMessage(TextUtil.color("&7Packet-level checks (Timer/Blink): "
                + (protocolActive ? "&aACTIVE" : "&cinactive &8(install ProtocolLib)")));
        sender.sendMessage(TextUtil.color("&f/sac reload &7- reload config.yml"));
        sender.sendMessage(TextUtil.color("&f/sac alerts &7- toggle alert visibility for yourself's session-wide broadcast"));
        sender.sendMessage(TextUtil.color("&f/sac vl <player> &7- show current violation levels"));
        sender.sendMessage(TextUtil.color("&f/sac gui &7- open the visual watchlist (who's been flagged)"));
        sender.sendMessage(TextUtil.color("&f/sac top &7- top 10 most-flagged players right now"));
        sender.sendMessage(TextUtil.color("&f/sac history <player> &7- past punishments from violations.log"));
        sender.sendMessage(TextUtil.color("&f/sac freeze|unfreeze <player> &7- lock/unlock a player in place"));
        sender.sendMessage(TextUtil.color("&f/sac panic &7- kick all currently flagged/unverified players"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1) {
            return List.of("reload", "alerts", "vl", "gui", "top", "history", "exempt", "freeze", "unfreeze", "panic").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length == 2 && List.of("vl", "freeze", "unfreeze", "history").contains(args[0].toLowerCase())) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(s -> s.toLowerCase().startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        }
        return new ArrayList<>();
    }
}
