package com.sentinelac;

import com.sentinelac.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Runs every second: decays old violation levels so a single burst of
 * flags doesn't permanently haunt a player, and ticks anti-bot
 * verification for anyone still pending it.
 */
public class SentinelTask extends BukkitRunnable {

    private final SentinelAC plugin;

    public SentinelTask(SentinelAC plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        double decayAmount = plugin.getConfigManager().getD("settings.violation-decay-amount", 1);
        long decayAfterMs = plugin.getConfigManager().getL("settings.violation-decay-seconds", 60) * 1000L;

        for (Player player : Bukkit.getOnlinePlayers()) {
            PlayerData data = plugin.getPlayerDataManager().get(player);
            data.decayAll(decayAmount, decayAfterMs);

            if (data.frozen) {
                // hard-lock: cancel any drift by teleporting back to last known good spot
                if (data.lastLocation != null) {
                    player.teleport(data.lastLocation);
                }
            }
        }
    }
}
