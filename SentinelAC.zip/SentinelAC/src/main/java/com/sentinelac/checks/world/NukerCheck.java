package com.sentinelac.checks.world;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

import java.util.LinkedList;

/**
 * Flags breaking many blocks in a very short window regardless of distance
 * between them (nuker hacks break blocks around the player in a radius
 * near-instantly, without the normal walk-and-mine cadence).
 */
public class NukerCheck extends Check {

    public NukerCheck(SentinelAC plugin) {
        super(plugin, "nuker", "Nuker");
    }

    public void onBreak(Player player, PlayerData data) {
        if (!isEnabled() || isExempt(player)) return;
        if (player.getGameMode() == GameMode.CREATIVE) return;

        long now = System.currentTimeMillis();
        LinkedList<Long> breaks = data.recentBlockBreaks;
        breaks.addLast(now);

        long window = plugin.getConfigManager().getL("checks.nuker.window-ms", 250);
        while (!breaks.isEmpty() && now - breaks.getFirst() > window) breaks.removeFirst();

        int max = plugin.getConfigManager().getI("checks.nuker.max-blocks-in-window", 6);
        if (breaks.size() > max) {
            flag(player, data, 2, breaks.size() + " blocks broken within " + window + "ms");
        }
    }
}
