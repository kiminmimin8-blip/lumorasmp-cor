package com.sentinelac.checks.world;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockPlaceEvent;

/**
 * "AirPlace" hack: places blocks against a face that vanilla would never
 * allow (no solid block actually supporting the placement — e.g. placing
 * straight out into open air/liquid by faking the target block). In vanilla,
 * BlockPlaceEvent#getBlockAgainst() is always solid; if it isn't, something
 * spoofed the placement packet.
 */
public class AirPlaceCheck extends Check {

    public AirPlaceCheck(SentinelAC plugin) {
        super(plugin, "airplace", "AirPlace");
    }

    public void onPlace(Player player, PlayerData data, BlockPlaceEvent event) {
        if (!isEnabled() || isExempt(player)) return;

        Block against = event.getBlockAgainst();
        if (against == null) return;

        if (!against.getType().isSolid()) {
            flag(player, data, 3, "placed against non-solid block " + against.getType());
        }
    }
}
