package com.sentinelac.checks.world;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.entity.Player;

import java.util.LinkedList;

public class FastPlaceCheck extends Check {

    public FastPlaceCheck(SentinelAC plugin) {
        super(plugin, "fastplace", "FastPlace");
    }

    public void onPlace(Player player, PlayerData data) {
        if (!isEnabled() || isExempt(player)) return;

        long now = System.currentTimeMillis();
        LinkedList<Long> places = data.recentBlockPlaces;
        places.addLast(now);
        while (!places.isEmpty() && now - places.getFirst() > 1000) places.removeFirst();

        int max = plugin.getConfigManager().getI("checks.fastplace.max-blocks-per-second", 9);
        if (places.size() > max) {
            flag(player, data, 1, places.size() + " blocks placed in the last second (max " + max + ")");
        }
    }
}
