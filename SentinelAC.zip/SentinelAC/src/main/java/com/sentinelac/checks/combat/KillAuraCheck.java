package com.sentinelac.checks.combat;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import com.sentinelac.utils.MathUtil;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.Iterator;
import java.util.UUID;

/**
 * Detects the two classic KillAura signatures:
 *  1. Attacking a target the player isn't actually looking at (angle check).
 *  2. Attacking multiple distinct entities within an impossibly short window
 *     (multi-aura / no target-switch delay).
 */
public class KillAuraCheck extends Check {

    public KillAuraCheck(SentinelAC plugin) {
        super(plugin, "killaura", "KillAura");
    }

    public void onAttack(Player player, PlayerData data, LivingEntity target) {
        if (!isEnabled() || isExempt(player)) return;

        double maxAngle = plugin.getConfigManager().getD("checks.killaura.max-attack-angle-degrees", 70);
        double angle = MathUtil.angleToTarget(player.getEyeLocation(),
                player.getLocation().getYaw(), player.getLocation().getPitch(), target.getEyeLocation());

        if (angle > maxAngle) {
            flag(player, data, 2, String.format("hit target at %.1f° off view (max %.1f°)", angle, maxAngle));
        }

        long now = System.currentTimeMillis();
        long window = plugin.getConfigManager().getL("checks.killaura.multi-target-window-ms", 300);

        data.recentAttackTargets.addLast(target.getUniqueId());
        data.recentAttackTimes.addLast(now);
        trim(data, now, window);

        long distinctTargets = data.recentAttackTargets.stream().distinct().count();
        if (distinctTargets >= 2) {
            flag(player, data, 3, "hit " + distinctTargets + " distinct entities within " + window + "ms");
        }

        data.lastAttackTime = now;
    }

    private void trim(PlayerData data, long now, long window) {
        Iterator<Long> timeIt = data.recentAttackTimes.iterator();
        Iterator<UUID> targetIt = data.recentAttackTargets.iterator();
        while (timeIt.hasNext() && targetIt.hasNext()) {
            long t = timeIt.next();
            targetIt.next();
            if (now - t > window) {
                timeIt.remove();
                targetIt.remove();
            }
        }
    }
}
