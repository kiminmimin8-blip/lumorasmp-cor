package com.sentinelac.checks.misc;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/**
 * AntiKnockback / "Velocity" detector. When a player is damaged, vanilla
 * always applies a horizontal knockback impulse. Anti-KB hack modules
 * cancel or drastically reduce the velocity the client actually reports
 * back afterward. We snapshot position at the moment of damage and compare
 * it one tick later.
 *
 * BUGFIX (v2): this used to store the "before" snapshot as a single shared
 * field on PlayerData (data.velocityBefore / data.pendingKnockbackCheck).
 * Under rapid multi-hit — two arrows landing within the 2-tick verification
 * window, or two players attacking at once — the second hit's onDamaged()
 * call overwrote the first hit's snapshot before its own delayed check ran,
 * corrupting the comparison for whichever hit's task executed against the
 * wrong baseline. The fix: the caller (CombatListener) now captures the
 * "before" Location as a local variable and passes it straight through the
 * scheduled-task closure — each hit gets its own independent snapshot with
 * no shared mutable state to clobber, however many hits land concurrently.
 *
 * Known limitation this does NOT fix: a player cornered against 2+ solid
 * blocks can legitimately show near-zero displacement after a real hit
 * (physically can't be pushed anywhere), which looks identical to an
 * anti-KB hack from a pure position-delta perspective. We skip flagging in
 * that specific geometry rather than guess.
 */
public class KnockbackCheck extends Check {

    public KnockbackCheck(SentinelAC plugin) {
        super(plugin, "knockback", "AntiKnockback");
    }

    /** Called one tick after damage, with the position captured AT the moment of damage. */
    public void verify(Player player, PlayerData data, Location before) {
        if (!isEnabled() || isExempt(player)) return;
        if (before == null) return;

        if (isCorneredByBlocks(player)) return; // can't meaningfully move regardless — see class Javadoc

        Vector delta = player.getLocation().toVector().subtract(before.toVector());
        double horizontal = Math.sqrt(delta.getX() * delta.getX() + delta.getZ() * delta.getZ());

        double min = plugin.getConfigManager().getD("checks.knockback.min-horizontal-velocity-change", 0.03);

        if (horizontal < min) {
            flag(player, data, 1, String.format("only %.4f horizontal movement after being hit (min %.4f)", horizontal, min));
        }
    }

    private boolean isCorneredByBlocks(Player player) {
        Location loc = player.getLocation();
        int solidSides = 0;
        for (org.bukkit.block.BlockFace face : new org.bukkit.block.BlockFace[]{
                org.bukkit.block.BlockFace.NORTH, org.bukkit.block.BlockFace.SOUTH,
                org.bukkit.block.BlockFace.EAST, org.bukkit.block.BlockFace.WEST}) {
            if (loc.getBlock().getRelative(face).getType().isSolid()) solidSides++;
        }
        return solidSides >= 2;
    }
}
