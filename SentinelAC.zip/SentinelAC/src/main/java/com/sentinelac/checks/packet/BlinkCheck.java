package com.sentinelac.checks.packet;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.entity.Player;

/**
 * Detects "Blink": the client withholds movement/position packets for a
 * stretch of time (during which it can act freely with the server seeing
 * nothing), then releases the queued packets all at once so the server
 * "catches up" the player's position in a sudden burst — functionally a
 * short, undetectable-by-normal-speed-checks teleport, because each
 * individual packet-to-packet delta can still look plausible.
 *
 * The tell isn't the delta between two positions — it's the packet
 * TIMING: a long silence immediately followed by an unnaturally dense
 * burst of packets.
 *
 * Called from ProtocolLibHook on every Play.Client.FLYING-family packet.
 */
public class BlinkCheck extends Check {

    public BlinkCheck(SentinelAC plugin) {
        super(plugin, "blink", "Blink");
    }

    public void onMovementPacket(Player player, PlayerData data) {
        if (!isEnabled() || isExempt(player)) return;

        long now = System.currentTimeMillis();
        long silenceThreshold = plugin.getConfigManager().getL("checks.blink.silence-threshold-ms", 350);

        if (data.lastPacketReceivedTime != 0) {
            long gap = now - data.lastPacketReceivedTime;
            if (gap > silenceThreshold) {
                data.pendingBurstCheck = true;
                data.lastPacketGapStart = now;
            }
        }

        if (data.pendingBurstCheck) {
            long burstWindow = plugin.getConfigManager().getL("checks.blink.burst-window-ms", 150);
            int burstThreshold = plugin.getConfigManager().getI("checks.blink.burst-count-threshold", 4);

            if (now - data.lastPacketGapStart <= burstWindow) {
                data.addVL("blink-burst-count", 1);
                if (data.getVL("blink-burst-count") >= burstThreshold) {
                    flag(player, data, 2, "packet burst after " + silenceThreshold + "ms+ silence");
                    data.resetVL("blink-burst-count");
                    data.pendingBurstCheck = false;
                }
            } else {
                // burst window expired without enough packets — was probably
                // just normal lag, not a deliberate queue-and-flush
                data.pendingBurstCheck = false;
                data.resetVL("blink-burst-count");
            }
        }

        data.lastPacketReceivedTime = now;
    }
}
