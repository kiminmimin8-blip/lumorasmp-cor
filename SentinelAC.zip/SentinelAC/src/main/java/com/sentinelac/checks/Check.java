package com.sentinelac.checks;

import com.sentinelac.SentinelAC;
import com.sentinelac.data.PlayerData;
import org.bukkit.entity.Player;

/**
 * Base class for every detection check.
 *
 * A check calls flag(player, data, info) when it observes suspicious
 * behaviour. flag() adds to that check's violation level (VL), fires an
 * alert to staff, and — once max-vl is reached — asks the PunishmentManager
 * to act and then resets the VL so the player gets a clean slate afterward.
 */
public abstract class Check {

    protected final SentinelAC plugin;
    protected final String key;      // matches config.yml checks.<key>
    protected final String displayName;

    protected Check(SentinelAC plugin, String key, String displayName) {
        this.plugin = plugin;
        this.key = key;
        this.displayName = displayName;
    }

    public String getKey() { return key; }
    public String getDisplayName() { return displayName; }

    public boolean isEnabled() {
        return plugin.getConfigManager().checkEnabled(key);
    }

    /** True if this player should be entirely skipped (bypass perm, creative, gamemode, etc). */
    protected boolean isExempt(Player player) {
        return plugin.getExemptionManager().isExempt(player);
    }

    protected void flag(Player player, PlayerData data, double amount, String info) {
        double buffer = plugin.getConfigManager().getD("checks." + key + ".vl-buffer", 5);
        double maxVl = plugin.getConfigManager().getD("checks." + key + ".max-vl", 10);

        data.addVL(key, amount);
        double vl = data.getVL(key);

        if (vl < buffer) {
            // below buffer: tracked silently, no alert yet, avoids spamming staff
            // with single-tick noise caused by lag.
            return;
        }

        plugin.getAlertManager().sendAlert(player, displayName, vl, info);

        data.totalVlEver += amount;
        data.lastFlagSummary = displayName + " (" + info + ")";
        plugin.getWatchlistManager().markFlagged(player, data);

        if (vl >= maxVl) {
            plugin.getPunishmentManager().punish(player, key);
            data.resetVL(key);
        }
    }

    protected void debug(String msg) {
        if (plugin.getConfigManager().debug()) {
            plugin.getLogger().info("[" + displayName + "] " + msg);
        }
    }
}
