package com.sentinelac.checks.movement;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

/**
 * Physics-prediction Fly check (v2).
 *
 * Instead of comparing each tick's deltaY against a flat cap, this runs a
 * lightweight simulation of vanilla vertical physics in parallel with the
 * real player: gravity (-0.08/tick) then drag (*0.98/tick), same as the
 * client actually computes. The simulated velocity advances independently
 * of what the player's client reports — so if a fly hack holds altitude,
 * our simulation keeps "falling" every tick it doesn't, and the gap between
 * simulated and actual position grows every single tick instead of resetting.
 * That growing, compounding divergence is a much stronger signal than any
 * single-tick threshold, and is the same core idea GrimAC/Vulcan's movement
 * prediction is built on (this is a lightweight version of it, covering the
 * vertical axis with the jump/gravity/drag formulas — not the full block-
 * type/edge-case coverage a dedicated engine like theirs has).
 */
public class FlyCheck extends Check {

    private static final double GRAVITY = 0.08;
    private static final double DRAG = 0.98;
    private static final double BASE_JUMP_VELOCITY = 0.42;

    public FlyCheck(SentinelAC plugin) {
        super(plugin, "fly", "Fly");
    }

    /** Called from PlayerJumpEvent so the simulator starts from the correct initial velocity. */
    public void onJump(Player player, PlayerData data) {
        int jumpBoost = player.hasPotionEffect(PotionEffectType.JUMP_BOOST)
                ? player.getPotionEffect(PotionEffectType.JUMP_BOOST).getAmplifier() + 1 : 0;
        data.predictedVelocityY = BASE_JUMP_VELOCITY + (0.1 * jumpBoost);
        data.physicsBaselineValid = true;
    }

    public void handle(Player player, PlayerData data, Location from, Location to) {
        boolean exemptState = player.getAllowFlight() || player.isFlying() || player.isGliding()
                || player.isInsideVehicle() || player.isRiptiding() || player.isSwimming()
                || player.hasPotionEffect(PotionEffectType.LEVITATION);

        if (exemptState) {
            // reset the simulator so it doesn't compare stale predictions
            // once the player returns to normal ground/air movement
            data.predictedVelocityY = 0;
            data.physicsBaselineValid = false;
            return;
        }

        if (!isEnabled() || isExempt(player)) {
            // BUGFIX: this used to just `return` here, leaving predictedVelocityY
            // frozen at whatever it was when the player became exempt (e.g. staff
            // froze them mid-fall). The moment they stopped being exempt, the next
            // tick compared a fresh actualDeltaY against that stale prediction and
            // could false-flag instantly. Reset on every exempt path, not just the
            // flying/gliding/vehicle one above.
            data.predictedVelocityY = 0;
            data.physicsBaselineValid = false;
            return;
        }

        double actualDeltaY = to.getY() - from.getY();
        boolean onGround = player.isOnGround();

        if (onGround) {
            data.groundTicks++;
            data.airTicks = 0;
            data.predictedVelocityY = 0;
            data.physicsBaselineValid = false;
            data.resetVL(key);
            return;
        }

        data.airTicks++;
        data.groundTicks = 0;

        // recent knockback/explosion: skip flagging (we can't cheaply model
        // exact KB velocity) but resync the simulator to the real value so
        // it doesn't accumulate false divergence across the impulse
        long sinceDamage = System.currentTimeMillis() - data.lastDamageTakenTime;
        if (sinceDamage < 600) {
            data.predictedVelocityY = actualDeltaY;
            return;
        }

        if (!data.physicsBaselineValid) {
            // we don't know their real starting velocity (e.g. plugin joined
            // mid-air, or resumed after an exemption) — resync silently once
            data.predictedVelocityY = actualDeltaY;
            data.physicsBaselineValid = true;
            return;
        }

        double epsilon = plugin.getConfigManager().getD("checks.fly.prediction-epsilon", 0.08);
        double diff = actualDeltaY - data.predictedVelocityY;

        if (diff > epsilon) {
            flag(player, data, 1.5, String.format(
                    "actualΔY=%.3f vs predicted=%.3f (diff %.3f > epsilon %.3f)",
                    actualDeltaY, data.predictedVelocityY, diff, epsilon));
        }

        // advance the simulation forward regardless, using OUR physics —
        // this is what lets the divergence compound if they keep cheating
        data.predictedVelocityY = (data.predictedVelocityY - GRAVITY) * DRAG;
    }
}
