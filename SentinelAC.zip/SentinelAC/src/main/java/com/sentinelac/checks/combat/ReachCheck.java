package com.sentinelac.checks.combat;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import com.sentinelac.utils.MathUtil;
import org.bukkit.GameMode;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

public class ReachCheck extends Check {

    public ReachCheck(SentinelAC plugin) {
        super(plugin, "reach", "Reach");
    }

    public void onAttack(Player player, PlayerData data, LivingEntity target) {
        if (!isEnabled() || isExempt(player)) return;

        double distance = player.getEyeLocation().distance(target.getBoundingBox().getCenter().toLocation(target.getWorld()));

        double base = player.getGameMode() == GameMode.CREATIVE
                ? plugin.getConfigManager().getD("checks.reach.max-reach-creative", 5.1)
                : plugin.getConfigManager().getD("checks.reach.max-reach-survival", 3.15);

        // Ping compensation: a laggier connection means the position the
        // server has for the target is slightly stale relative to what the
        // attacking client actually saw when it clicked, so a small amount
        // of extra tolerance scaled to ping avoids punishing high-ping
        // players for something that is genuinely just latency, not reach.
        // This is deliberately conservative — capped, and small per 50ms —
        // real reach hacks exceed even the compensated allowance by a wide
        // margin, so this isn't giving away meaningful headroom to cheaters.
        double max = base;
        if (plugin.getConfigManager().getB("checks.reach.ping-compensation-enabled", true)) {
            int ping = player.getPing();
            double perFiftyMs = plugin.getConfigManager().getD("checks.reach.extra-per-50ms-ping", 0.06);
            double maxExtra = plugin.getConfigManager().getD("checks.reach.max-ping-extra", 0.35);
            double extra = MathUtil.clamp((ping / 50.0) * perFiftyMs, 0, maxExtra);
            max += extra;
        }

        if (distance > max) {
            flag(player, data, 2, String.format("hit target from %.2f blocks (max %.2f, ping=%dms)", distance, max, player.getPing()));
        }
    }
}
