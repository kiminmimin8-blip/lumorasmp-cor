package com.sentinelac.checks.world;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.entity.Player;

/**
 * Heuristic scaffold detector: flags block placement, underneath/around the
 * player while bridging, that happens with (a) very short intervals between
 * placements and (b) a pitch that doesn't match "looking down to place",
 * which is the classic scaffold-hack signature of placing while looking
 * straight ahead.
 */
public class ScaffoldCheck extends Check {

    public ScaffoldCheck(SentinelAC plugin) {
        super(plugin, "scaffold", "Scaffold");
    }

    public void onPlace(Player player, PlayerData data) {
        if (!isEnabled() || isExempt(player)) return;

        long now = System.currentTimeMillis();
        long minInterval = plugin.getConfigManager().getL("checks.scaffold.min-place-interval-ms", 40);
        long sinceLast = now - data.lastBlockPlaceTime;
        data.lastBlockPlaceTime = now;

        if (sinceLast > minInterval) return; // normal pace, nothing to flag from timing alone

        float pitch = player.getLocation().getPitch();
        double maxDeviation = plugin.getConfigManager().getD("checks.scaffold.max-place-pitch-deviation", 40);

        // legit bridging: pitch is usually noticeably downward (positive pitch, toward ~30-90).
        // flag rapid placement while looking flat/upward instead.
        if (pitch < maxDeviation * -1 || pitch < 10) {
            flag(player, data, 1.5, String.format("rapid place (%dms) at pitch %.1f°", sinceLast, pitch));
        }
    }
}
