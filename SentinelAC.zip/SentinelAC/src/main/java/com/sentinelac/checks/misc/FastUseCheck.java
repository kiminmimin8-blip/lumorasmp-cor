package com.sentinelac.checks.misc;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.entity.Player;

public class FastUseCheck extends Check {

    public FastUseCheck(SentinelAC plugin) {
        super(plugin, "fastuse", "FastUse");
    }

    public void onStartUsing(Player player, PlayerData data) {
        data.itemUseStartTime = System.currentTimeMillis();
    }

    public void onFinishUsing(Player player, PlayerData data) {
        if (!isEnabled() || isExempt(player)) return;
        if (data.itemUseStartTime == 0) return;

        long took = System.currentTimeMillis() - data.itemUseStartTime;
        long min = plugin.getConfigManager().getL("checks.fastuse.min-use-time-ms", 1100);

        if (took < min) {
            flag(player, data, 1, "consumed item in " + took + "ms (expected >=" + min + "ms)");
        }
        data.itemUseStartTime = 0;
    }
}
