package com.sentinelac.checks.movement;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import com.sentinelac.utils.MathUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

/**
 * Speed check v2 — uses the actual block material under the player to look
 * up its real vanilla slipperiness instead of the old flat "groundTicks<=2"
 * approximation. This is materially more accurate: it can't be tricked by
 * standing on non-slippery ground right after leaving ice (the old
 * heuristic's blind spot), and it doesn't need a wide blanket multiplier
 * that was giving up detection headroom on every surface just to avoid
 * false-flagging ice.
 *
 * BUGFIX (v2.1): the very first version of this rewrite dropped the ice
 * bonus the instant the player left the ground (isOnGround() false → block
 * lookup samples air → default friction). But real vanilla physics carries
 * horizontal momentum built up on ice INTO a jump — "ice bhop" is a normal,
 * legitimate movement technique — so a player sliding on ice and then
 * jumping would have been flagged the moment their feet left the block.
 * We now remember the friction value from the last ground tick and apply a
 * short decaying grace period for a few ticks after becoming airborne.
 */
public class SpeedCheck extends Check {

    // vanilla slipperiness values (default ground friction is 0.6)
    private static final double DEFAULT_FRICTION = 0.6;

    public SpeedCheck(SentinelAC plugin) {
        super(plugin, "speed", "Speed");
    }

    public void handle(Player player, PlayerData data, Location from, Location to) {
        if (!isEnabled() || isExempt(player)) return;
        if (player.isFlying() || player.isGliding() || player.isInsideVehicle()) return;
        if (player.isSwimming() || player.isRiptiding()) return;

        double horizontal = MathUtil.horizontalDistance(from, to);
        double base = plugin.getConfigManager().getD("checks.speed.max-horizontal-speed", 0.42);

        int speedAmp = 0;
        if (player.hasPotionEffect(PotionEffectType.SPEED)) {
            speedAmp = player.getPotionEffect(PotionEffectType.SPEED).getAmplifier() + 1;
        }
        double allowed = base * (1 + (0.2 * speedAmp));

        double friction;
        boolean onGround = player.isOnGround();
        if (onGround) {
            friction = frictionUnderneath(player);
            data.lastGroundFriction = friction;
        } else {
            // NOTE: data.airTicks is maintained by FlyCheck, which runs
            // right before this in MovementListener — so this reads last
            // tick's value (off-by-one tick). Fine for a grace-period
            // heuristic; not worth the coupling risk of reordering checks
            // to fix a one-tick lag that has no real detection impact.
            int graceTicks = plugin.getConfigManager().getI("checks.speed.ice-momentum-grace-ticks", 3);
            friction = data.airTicks <= graceTicks ? data.lastGroundFriction : DEFAULT_FRICTION;
        }

        if (friction > DEFAULT_FRICTION) {
            // momentum scales roughly with friction ratio once built up on a
            // slippery surface (ice, blue ice, packed ice); this is still an
            // approximation of the real per-tick momentum formula, but it's
            // grounded in the actual block instead of a fixed time window
            double ratio = friction / DEFAULT_FRICTION;
            double cap = plugin.getConfigManager().getD("checks.speed.max-friction-multiplier", 3.5);
            allowed *= Math.min(ratio * ratio, cap); // squared: momentum builds over successive ticks on ice
        }

        if (horizontal > allowed) {
            flag(player, data, 1, String.format("moved %.3f (max %.3f, friction=%.3f)", horizontal, allowed, friction));
        } else {
            data.resetVL(key);
        }
    }

    private double frictionUnderneath(Player player) {
        Block below = player.getLocation().subtract(0, 0.3, 0).getBlock();
        Material type = below.getType();

        return switch (type) {
            case ICE -> 0.98;
            case PACKED_ICE -> 0.98;
            case BLUE_ICE -> 0.989;
            case SLIME_BLOCK -> 0.8;
            case SOUL_SAND, HONEY_BLOCK -> 0.4; // these SLOW you, ratio < default handled naturally (no multiplier applied since <=DEFAULT_FRICTION)
            default -> DEFAULT_FRICTION;
        };
    }
}
