package com.sentinelac.checks.world;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public class FastBreakCheck extends Check {

    public FastBreakCheck(SentinelAC plugin) {
        super(plugin, "fastbreak", "FastBreak");
    }

    public void onBreakStart(Player player, PlayerData data) {
        data.lastBlockBreakStart = System.currentTimeMillis();
    }

    public void onBreakComplete(Player player, PlayerData data, Block block) {
        if (!isEnabled() || isExempt(player)) return;
        if (player.getGameMode() == GameMode.CREATIVE) return;
        if (data.lastBlockBreakStart == 0) return;

        long took = System.currentTimeMillis() - data.lastBlockBreakStart;
        long expected = estimateBreakTimeMs(player, block);
        long tolerance = plugin.getConfigManager().getL("checks.fastbreak.tolerance-ms", 80);

        if (took + tolerance < expected) {
            flag(player, data, 2, String.format("broke %s in %dms (expected ~%dms)", block.getType(), took, expected));
        }
        data.lastBlockBreakStart = 0;
    }

    /**
     * Rough vanilla break-time estimate. This intentionally does NOT try to
     * replicate every tool/enchant/haste/hardness interaction perfectly —
     * that's a rabbit hole — it uses a conservative estimate so legitimate
     * fast mining (efficiency picks, haste) doesn't get flagged, while
     * actually-instant "breaks with no delay" hacks still get caught.
     */
    private long estimateBreakTimeMs(Player player, Block block) {
        float hardness = block.getType().getHardness();
        if (hardness <= 0) return 0; // insta-break blocks (e.g. tall grass)

        double baseSeconds = hardness * 1.5;

        boolean hasEfficiency = player.getInventory().getItemInMainHand().containsEnchantment(
                org.bukkit.enchantments.Enchantment.EFFICIENCY);
        double toolMultiplier = hasEfficiency ? 0.35 : 1.0;

        boolean haste = player.hasPotionEffect(org.bukkit.potion.PotionEffectType.HASTE);
        double hasteMultiplier = haste ? 0.7 : 1.0;

        double seconds = baseSeconds * toolMultiplier * hasteMultiplier;
        // floor it generously — this is a safety net check, not a precision one
        seconds = Math.max(seconds, 0.05);
        return (long) (seconds * 1000);
    }
}
