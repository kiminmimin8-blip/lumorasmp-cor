package com.sentinelac.checks.misc;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import com.sentinelac.utils.MathUtil;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.InventoryType;

/**
 * A vanilla client cannot meaningfully move or attack while a container GUI
 * (chest, anvil, crafting table, etc — anything other than the player's own
 * inventory) is open. Movement here is a strong signal of packet-level
 * automation/cheats bypassing client-side input locking.
 */
public class InventoryMoveCheck extends Check {

    public InventoryMoveCheck(SentinelAC plugin) {
        super(plugin, "inventorymove", "InventoryMove");
    }

    public void handle(Player player, PlayerData data, Location from, Location to) {
        if (!isEnabled() || isExempt(player)) return;

        InventoryType type = player.getOpenInventory().getType();
        boolean guiOpen = type != InventoryType.CRAFTING && type != InventoryType.CREATIVE;
        if (!guiOpen) return;

        double moved = MathUtil.horizontalDistance(from, to);
        double max = plugin.getConfigManager().getD("checks.inventorymove.max-movement-while-open", 0.03);

        if (moved > max) {
            flag(player, data, 1, String.format("moved %.3f with %s open", moved, type));
        }
    }
}
