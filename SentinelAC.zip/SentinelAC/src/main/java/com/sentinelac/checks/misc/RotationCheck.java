package com.sentinelac.checks.misc;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import com.sentinelac.utils.MathUtil;
import org.bukkit.entity.Player;

import java.util.LinkedList;

/**
 * Aim/rotation analysis — the "GCD check" real anticheats (Grim/Vulcan/
 * Matrix) use to catch aim-assist and KillAura variants that a simple
 * attack-angle check misses (because the aimbot DOES eventually point at
 * the target, just via an unnatural rotation pattern getting there).
 *
 * The protocol represents yaw as a float, but many rotation/aim-assist
 * implementations compute the turn using a fixed internal "sensitivity"
 * multiplier, which means the sequence of yaw deltas they produce tends to
 * all be exact multiples of some shared value — something a human moving a
 * physical mouse essentially never produces over a long sample, because
 * mouse movement has continuous, non-quantized micro-variance.
 *
 * We convert yaw deltas into the protocol's fixed-point angle unit
 * (256 units per 360°, matching how rotation is actually transmitted) and
 * track the running GCD of a rolling sample. A GCD that stays unnaturally
 * high across a large sample is the signal — NOT a single high-GCD reading,
 * which happens naturally sometimes and must not be over-trusted.
 *
 * Honesty note: this is an approximation built on Bukkit's PlayerMoveEvent,
 * not the raw un-batched packet stream a packet-level implementation would
 * use, so it's less precise than what GrimAC does internally. It's still a
 * meaningfully different signal than every other check in this plugin
 * (behavioural pattern vs. instantaneous threshold), which is the point.
 */
public class RotationCheck extends Check {

    public RotationCheck(SentinelAC plugin) {
        super(plugin, "rotation", "Rotation");
    }

    public void handle(Player player, PlayerData data, float newYaw) {
        if (!isEnabled() || isExempt(player)) return;

        if (data.lastYaw == null) {
            data.lastYaw = newYaw;
            return;
        }

        float rawDelta = newYaw - data.lastYaw;
        data.lastYaw = newYaw;

        // normalize to -180..180 then convert to protocol angle units (256/360)
        while (rawDelta > 180) rawDelta -= 360;
        while (rawDelta < -180) rawDelta += 360;
        int units = Math.round(rawDelta * 256f / 360f);
        if (units == 0) return; // no meaningful rotation this sample

        LinkedList<Integer> deltas = data.recentYawDeltas;
        deltas.addLast(Math.abs(units));

        int sampleSize = plugin.getConfigManager().getI("checks.rotation.sample-size", 40);
        while (deltas.size() > sampleSize) deltas.removeFirst();

        if (deltas.size() < sampleSize) return; // not enough data yet

        int runningGcd = 0;
        for (int d : deltas) runningGcd = MathUtil.gcd(runningGcd, d);

        int minSuspiciousGcd = plugin.getConfigManager().getI("checks.rotation.min-suspicious-gcd", 10);

        if (runningGcd >= minSuspiciousGcd) {
            flag(player, data, 1, "yaw-delta GCD=" + runningGcd + " over " + sampleSize + " samples (min " + minSuspiciousGcd + ")");
            // don't keep flagging on the exact same window every tick — drop
            // the oldest half so the check needs fresh sustained evidence
            for (int i = 0; i < sampleSize / 2; i++) {
                if (!deltas.isEmpty()) deltas.removeFirst();
            }
        }
    }
}
