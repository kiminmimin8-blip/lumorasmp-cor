package com.sentinelac.checks.misc;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.entity.Player;

/**
 * A vanilla client ALWAYS sends an arm-swing animation packet as part of
 * every left-click attack — it's baked into how the client handles the
 * input, not something a legit player can suppress. Several older/cruder
 * KillAura implementations attack by sending the interact/attack packet
 * directly without going through normal input handling, which skips the
 * swing. This is a cheap, high-confidence check with almost no legitimate
 * way to trigger it by accident.
 *
 * BUGFIX (v2): the original version checked lastSwingTime synchronously,
 * strictly requiring the swing to have been recorded BEFORE the attack.
 * But Bukkit doesn't guarantee cross-event-type ordering when the swing
 * and attack packets land in the same tick/network batch — a slow clicker
 * (say 3 CPS) could occasionally have Bukkit process EntityDamageByEntityEvent
 * before that same click's PlayerAnimationEvent, making the gap look like it
 * was measured against the PREVIOUS click's swing (several hundred ms ago,
 * well past any reasonable threshold) and falsely flagging a legitimate
 * player. verify() is now called one tick later with a symmetric window —
 * checking the swing landed close to the attack in EITHER direction — which
 * absorbs that ordering race entirely.
 */
public class NoSwingCheck extends Check {

    public NoSwingCheck(SentinelAC plugin) {
        super(plugin, "noswing", "NoSwing");
    }

    /** Snapshot the attack time; actual verification happens one tick later via verify(). */
    public long captureAttackTime() {
        return System.currentTimeMillis();
    }

    public void verify(Player player, PlayerData data, long attackTime) {
        if (!isEnabled() || isExempt(player)) return;

        long maxGap = plugin.getConfigManager().getL("checks.noswing.max-gap-ms", 150);

        if (data.lastSwingTime == 0) {
            flag(player, data, 3, "attacked with no arm-swing ever recorded");
            return;
        }

        long gap = Math.abs(data.lastSwingTime - attackTime);
        if (gap > maxGap) {
            flag(player, data, 3, "no swing within " + maxGap + "ms of attack (nearest gap=" + gap + "ms)");
        }
    }
}
