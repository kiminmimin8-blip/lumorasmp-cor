package com.sentinelac.checks.movement;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import com.sentinelac.utils.MathUtil;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * Flags players who move at (near) normal speed while an action that should
 * slow them down is active: eating/drinking, blocking with a shield/sword,
 * or sneaking.
 */
public class NoSlowCheck extends Check {

    public NoSlowCheck(SentinelAC plugin) {
        super(plugin, "noslow", "NoSlow");
    }

    public void handle(Player player, PlayerData data, Location from, Location to) {
        if (!isEnabled() || isExempt(player)) return;
        if (!player.isOnGround()) return;

        boolean shouldBeSlowed = isEatingOrBlocking(player) || player.isSneaking();
        if (!shouldBeSlowed) return;

        double horizontal = MathUtil.horizontalDistance(from, to);
        double max = plugin.getConfigManager().getD("checks.noslow.max-speed-while-slowed", 0.16);

        if (horizontal > max) {
            flag(player, data, 1, String.format("moved %.3f while slowed (max %.3f)", horizontal, max));
        }
    }

    private boolean isEatingOrBlocking(Player player) {
        ItemStack main = player.getInventory().getItemInMainHand();
        ItemStack off = player.getInventory().getItemInOffHand();
        return player.isHandRaised() && (isConsumableOrBlockable(main) || isConsumableOrBlockable(off));
    }

    private boolean isConsumableOrBlockable(ItemStack item) {
        if (item == null) return false;
        String name = item.getType().name();
        return name.contains("SWORD") || name.equals("SHIELD") || name.contains("APPLE")
                || name.contains("POTION") || name.contains("STEW") || name.contains("SOUP")
                || item.getType().isEdible();
    }
}
