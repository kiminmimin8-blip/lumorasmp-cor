package com.sentinelac.checks.movement;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.entity.Player;

/**
 * Flags players whose client reports zero/near-zero fall damage after a fall
 * that vanilla physics would have made costly (i.e. they silenced the fall
 * packet client-side, a very common "NoFall" hack module).
 */
public class NoFallCheck extends Check {

    public NoFallCheck(SentinelAC plugin) {
        super(plugin, "nofall", "NoFall");
    }

    public void onFallDamageEvent(Player player, PlayerData data, double actualFallDistance, double damageDealt) {
        if (!isEnabled() || isExempt(player)) return;

        double minDistance = plugin.getConfigManager().getD("checks.nofall.min-fall-distance-to-check", 3.5);
        if (actualFallDistance < minDistance) return;

        if (damageDealt <= 0) {
            flag(player, data, 3, String.format("fell %.2f blocks, took no damage", actualFallDistance));
        }
    }
}
