package com.sentinelac.checks.movement;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;

public class JesusCheck extends Check {

    public JesusCheck(SentinelAC plugin) {
        super(plugin, "jesus", "Jesus (WaterWalk)");
    }

    public void handle(Player player, PlayerData data, Location to) {
        if (!isEnabled() || isExempt(player)) return;
        if (player.isFlying() || player.isSwimming() || player.isInsideVehicle()) return;
        if (player.getVehicle() != null) return;

        Location below = to.clone().subtract(0, 0.1, 0);
        Material feet = to.getBlock().getType();
        Material underneath = below.getBlock().getType();

        boolean inLiquid = feet == Material.WATER || underneath == Material.WATER
                || feet == Material.BUBBLE_COLUMN || underneath == Material.BUBBLE_COLUMN;

        if (!inLiquid) {
            data.ticksOnWaterSurface = 0;
            return;
        }

        boolean onGround = player.isOnGround();
        // vanilla lets you stand at the very top of water briefly / swim; the giveaway
        // is standing perfectly still ON TOP of the surface (not sinking, not swimming
        // animation) for an extended period while not actually in swim state.
        if (onGround && !player.isSwimming()) {
            data.ticksOnWaterSurface++;
        } else {
            data.ticksOnWaterSurface = 0;
        }

        int maxTicks = plugin.getConfigManager().getI("checks.jesus.max-ticks-on-water-surface", 10);
        if (data.ticksOnWaterSurface > maxTicks) {
            flag(player, data, 1, "standing on water surface for " + data.ticksOnWaterSurface + " ticks");
        }
    }
}
