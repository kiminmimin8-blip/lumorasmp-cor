package com.sentinelac.checks.combat;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import com.sentinelac.utils.MathUtil;
import org.bukkit.entity.Player;

import java.util.LinkedList;

/**
 * Flags impossible click-per-second rates AND, separately, click patterns
 * that are too perfectly even in timing (real human clicking has natural
 * jitter; a lot of autoclickers/macros fire on a near-fixed interval).
 * Both signals have to make sense together to reduce false positives from
 * legitimately fast clickers with naturally uneven rhythm.
 */
public class AutoClickerCheck extends Check {

    public AutoClickerCheck(SentinelAC plugin) {
        super(plugin, "autoclicker", "AutoClicker");
    }

    public void onClick(Player player, PlayerData data) {
        if (!isEnabled() || isExempt(player)) return;

        long now = System.currentTimeMillis();
        LinkedList<Long> clicks = data.recentClicks;
        clicks.addLast(now);

        int sampleSize = plugin.getConfigManager().getI("checks.autoclicker.sample-size", 20);
        while (clicks.size() > sampleSize) clicks.removeFirst();

        // CPS over the trailing 1 second
        long oneSecondAgo = now - 1000;
        long cps = clicks.stream().filter(t -> t >= oneSecondAgo).count();

        int maxCps = plugin.getConfigManager().getI("checks.autoclicker.max-cps", 20);
        if (cps > maxCps) {
            flag(player, data, 1, cps + " CPS (max " + maxCps + ")");
        }

        if (clicks.size() >= sampleSize) {
            long[] intervals = new long[clicks.size() - 1];
            for (int i = 1; i < clicks.size(); i++) {
                intervals[i - 1] = clicks.get(i) - clicks.get(i - 1);
            }
            double stdDev = MathUtil.stdDev(intervals);
            double minVariance = plugin.getConfigManager().getD("checks.autoclicker.min-click-variance-ms", 8);

            // low variance AND a high average rate together are the actual signal;
            // low variance alone can happen naturally at low CPS.
            double avg = 0;
            for (long v : intervals) avg += v;
            avg /= intervals.length;

            if (stdDev < minVariance && avg < 90) {
                flag(player, data, 1.5, String.format("click interval stddev=%.2fms avg=%.1fms (too consistent)", stdDev, avg));
            }
        }
    }
}
