package com.sentinelac.checks.movement;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;

/**
 * "Spider" hack: climbing straight up a wall as if every block were a
 * ladder. Flags sustained upward movement while horizontally pressed
 * against a solid block that is NOT actually climbable (ladder, vine,
 * scaffolding) and the player isn't swimming/using an elytra/etc.
 */
public class SpiderCheck extends Check {

    public SpiderCheck(SentinelAC plugin) {
        super(plugin, "spider", "Spider");
    }

    public void handle(Player player, PlayerData data, Location from, Location to) {
        if (!isEnabled() || isExempt(player)) return;
        if (player.isFlying() || player.isGliding() || player.isSwimming() || player.isInsideVehicle()) return;

        double deltaY = to.getY() - from.getY();
        if (deltaY <= 0.05) return; // only care about upward movement

        if (isTouchingClimbable(player.getLocation())) { data.climbStreak = 0; return; }
        if (!isAgainstSolidWall(player.getLocation())) { data.climbStreak = 0; return; }

        data.climbStreak++;
        int required = 4;
        if (data.climbStreak > required) {
            flag(player, data, 1, String.format("climbing wall, deltaY=%.3f, no ladder/vine", deltaY));
        }
    }

    private boolean isTouchingClimbable(Location loc) {
        Material type = loc.getBlock().getType();
        return type == Material.LADDER || type == Material.VINE || type.name().contains("SCAFFOLDING");
    }

    private boolean isAgainstSolidWall(Location loc) {
        for (BlockFace face : new BlockFace[]{BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
            Block relative = loc.getBlock().getRelative(face);
            if (relative.getType().isSolid()) return true;
        }
        return false;
    }
}
