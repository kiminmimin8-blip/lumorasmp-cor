package com.sentinelac.checks.misc;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.entity.Player;

/**
 * A legitimate vanilla client can never send a pitch outside [-90, 90]
 * degrees — the client itself clamps it. Some older exploit clients and
 * raw packet-editing tools skip that clamp. This is a near-zero-false-
 * positive sanity check, kept deliberately cheap to punish (low max-vl).
 */
public class InvalidPitchCheck extends Check {

    public InvalidPitchCheck(SentinelAC plugin) {
        super(plugin, "invalidpitch", "InvalidPitch");
    }

    public void handle(Player player, PlayerData data) {
        if (!isEnabled() || isExempt(player)) return;

        float pitch = player.getLocation().getPitch();
        if (pitch > 90.5f || pitch < -90.5f) {
            flag(player, data, 2, "reported pitch " + pitch + "° (outside -90..90)");
        }
    }
}
