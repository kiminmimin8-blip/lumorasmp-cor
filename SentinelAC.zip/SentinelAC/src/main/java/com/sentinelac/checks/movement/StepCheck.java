package com.sentinelac.checks.movement;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.Location;
import org.bukkit.entity.Player;

/**
 * Flags "step"/instant-elevate cheats: gaining more than one block of height
 * in a single tick while on ground, without a jump, and without being pushed
 * (honey block climb, slime, etc. are naturally slower/gradual so they don't
 * trip this in practice; scaffolding your own blocks upward is excluded by
 * only checking while on_ground==true both before and after).
 */
public class StepCheck extends Check {

    public StepCheck(SentinelAC plugin) {
        super(plugin, "step", "Step");
    }

    public void handle(Player player, PlayerData data, Location from, Location to) {
        if (!isEnabled() || isExempt(player)) return;
        if (!player.isOnGround() || !data.wasOnGround) return;
        if (player.isFlying() || player.isGliding()) return;

        double deltaY = to.getY() - from.getY();
        double maxStep = plugin.getConfigManager().getD("checks.step.max-step-height-no-jump", 1.05);

        long now = System.currentTimeMillis();
        boolean recentJump = (now - data.lastJumpTime) < 400;

        if (deltaY > maxStep && !recentJump) {
            flag(player, data, 2, String.format("stepped up %.3f blocks instantly", deltaY));
        }
    }
}
