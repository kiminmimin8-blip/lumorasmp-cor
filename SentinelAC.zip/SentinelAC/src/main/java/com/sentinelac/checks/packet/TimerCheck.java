package com.sentinelac.checks.packet;

import com.sentinelac.SentinelAC;
import com.sentinelac.checks.Check;
import com.sentinelac.data.PlayerData;
import org.bukkit.entity.Player;

import java.util.LinkedList;

/**
 * Detects "Timer" hacks: the client runs its internal game loop faster than
 * real time (e.g. 1.5x-3x), which lets it move, mine, eat, and swing faster
 * than vanilla allows — WITHOUT necessarily breaking the speed/fastbreak/
 * fastuse checks individually, since everything scales together
 * proportionally. The only reliable tell is the raw rate of movement
 * packets hitting the server, which is why this needs ProtocolLib instead
 * of Bukkit's already-throttled PlayerMoveEvent.
 *
 * Called from ProtocolLibHook on every Play.Client.FLYING-family packet.
 */
public class TimerCheck extends Check {

    public TimerCheck(SentinelAC plugin) {
        super(plugin, "timer", "Timer");
    }

    public void onMovementPacket(Player player, PlayerData data) {
        if (!isEnabled() || isExempt(player)) return;

        long now = System.currentTimeMillis();
        LinkedList<Long> times = data.movementPacketTimes;
        times.addLast(now);

        long window = plugin.getConfigManager().getL("checks.timer.sample-window-ms", 1000);
        while (!times.isEmpty() && now - times.getFirst() > window) times.removeFirst();

        int maxPps = plugin.getConfigManager().getI("checks.timer.max-packets-per-second", 23);
        // scale the raw count to the configured window so this still makes
        // sense if someone changes sample-window-ms away from 1000
        double pps = times.size() * (1000.0 / window);

        if (pps > maxPps) {
            data.addVL("timer-sample-streak", 1);
        } else {
            data.resetVL("timer-sample-streak");
        }

        int required = plugin.getConfigManager().getI("checks.timer.sustained-samples-required", 3);
        if (data.getVL("timer-sample-streak") >= required) {
            flag(player, data, 1, String.format("%.1f packets/sec sustained (max %d)", pps, maxPps));
            data.resetVL("timer-sample-streak");
        }
    }
}
