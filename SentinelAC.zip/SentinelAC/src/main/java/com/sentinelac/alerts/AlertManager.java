package com.sentinelac.alerts;

import com.sentinelac.SentinelAC;
import com.sentinelac.utils.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class AlertManager {

    private final SentinelAC plugin;
    private final Map<String, Long> lastAlertPerPlayerCheck = new ConcurrentHashMap<>();
    private boolean alertsMuted = false;

    public AlertManager(SentinelAC plugin) {
        this.plugin = plugin;
    }

    public void sendAlert(Player player, String checkName, double vl, String info) {
        if (alertsMuted) return;

        String cooldownKey = player.getUniqueId() + ":" + checkName;
        long cooldown = plugin.getConfigManager().getL("settings.alert-cooldown-ms", 400);
        long now = System.currentTimeMillis();
        Long last = lastAlertPerPlayerCheck.get(cooldownKey);
        if (last != null && now - last < cooldown) return;
        lastAlertPerPlayerCheck.put(cooldownKey, now);

        String format = plugin.getConfigManager().getS("alerts.format",
                "&8[&cSentinelAC&8] &f%player% &7failed &c%check% &7(x%vl%) &8- %info%");

        String message = format
                .replace("%player%", player.getName())
                .replace("%check%", checkName)
                .replace("%vl%", String.format("%.1f", vl))
                .replace("%info%", info == null ? "" : info);

        message = TextUtil.color(message);

        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("sentinelac.alerts")) {
                staff.sendMessage(message);
            }
        }
        plugin.getLogger().info(org.bukkit.ChatColor.stripColor(message));
    }

    public void setMuted(boolean muted) { this.alertsMuted = muted; }
    public boolean isMuted() { return alertsMuted; }
}
