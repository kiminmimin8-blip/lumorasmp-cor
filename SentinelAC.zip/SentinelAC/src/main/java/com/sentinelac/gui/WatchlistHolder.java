package com.sentinelac.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Marker holder so GUIListener can identify our inventory reliably (instead
 * of matching on title text, which breaks the moment someone reloads with a
 * translated title). Also carries the slot -> player UUID mapping so clicks
 * know which watchlist entry was clicked.
 */
public class WatchlistHolder implements InventoryHolder {

    private Inventory inventory;
    private final Map<Integer, UUID> slotMap = new HashMap<>();

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void put(int slot, UUID uuid) {
        slotMap.put(slot, uuid);
    }

    public UUID get(int slot) {
        return slotMap.get(slot);
    }
}
