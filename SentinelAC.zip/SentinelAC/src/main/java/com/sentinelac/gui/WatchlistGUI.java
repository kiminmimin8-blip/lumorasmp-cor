package com.sentinelac.gui;

import com.sentinelac.SentinelAC;
import com.sentinelac.data.PlayerData;
import com.sentinelac.utils.TextUtil;
import com.sentinelac.watchlist.WatchlistManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.List;

/**
 * /sac gui — a visual list of every player currently flagged (or recently
 * flagged) by SentinelAC, sorted worst-first, with click actions for staff.
 *
 * Left-click  : teleport to the player (if online)
 * Shift+Left  : toggle freeze on/off
 * Right-click : kick the player (if online)
 */
public class WatchlistGUI {

    private static final int SIZE = 54;
    private static final int CONTENT_SLOTS = 45; // rows 1-5, row 6 reserved for controls

    public static void open(Player staff, SentinelAC plugin) {
        WatchlistHolder holder = new WatchlistHolder();
        List<WatchlistManager.Entry> entries = plugin.getWatchlistManager().getSorted();

        String title = TextUtil.color("&8SentinelAC &7- Watchlist (" + entries.size() + ")");
        Inventory inv = Bukkit.createInventory(holder, SIZE, title);
        holder.setInventory(inv);

        ItemStack filler = namedItem(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int i = CONTENT_SLOTS; i < SIZE; i++) inv.setItem(i, filler);

        int slot = 0;
        for (WatchlistManager.Entry entry : entries) {
            if (slot >= CONTENT_SLOTS) break;

            OfflinePlayer off = Bukkit.getOfflinePlayer(entry.uuid);
            Player online = off.getPlayer();
            boolean isOnline = online != null && online.isOnline();

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.setOwningPlayer(off);

            String statusColor = isOnline ? "&a" : "&7";
            meta.setDisplayName(TextUtil.color(statusColor + entry.name + (isOnline ? " &8(online)" : " &8(offline)")));

            java.util.List<String> lore = new java.util.ArrayList<>();
            lore.add(TextUtil.color("&7Lifetime VL: &c" + String.format("%.1f", entry.totalVl) + " &8(session total, doesn't decay)"));
            lore.add(TextUtil.color("&7Last flag: &f" + entry.lastFlag));

            if (isOnline) {
                PlayerData data = plugin.getPlayerDataManager().get(online);
                lore.add(TextUtil.color(""));
                for (String key : List.of("speed", "fly", "nofall", "jesus", "noslow", "step",
                        "killaura", "reach", "autoclicker", "fastbreak", "fastplace", "nuker",
                        "scaffold", "knockback", "inventorymove", "fastuse", "invalidpitch",
                        "spider", "airplace", "timer", "blink", "rotation", "noswing")) {
                    double vl = data.getVL(key);
                    if (vl > 0) lore.add(TextUtil.color("&8" + key + ": &7" + String.format("%.1f", vl)));
                }
                if (data.frozen) lore.add(TextUtil.color("&b[FROZEN]"));
            }

            lore.add(TextUtil.color(""));
            lore.add(TextUtil.color("&eLeft-click &7- teleport to player"));
            lore.add(TextUtil.color("&eShift+Left &7- toggle freeze"));
            lore.add(TextUtil.color("&eRight-click &7- kick player"));

            meta.setLore(lore);
            head.setItemMeta(meta);

            inv.setItem(slot, head);
            holder.put(slot, entry.uuid);
            slot++;
        }

        inv.setItem(49, namedItem(Material.LIME_DYE, "&aRefresh", List.of(TextUtil.color("&7Click to reload this list."))));
        inv.setItem(53, namedItem(Material.BARRIER, "&cClose", List.of()));

        staff.openInventory(inv);
    }

    private static ItemStack namedItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(TextUtil.color(name));
        if (!lore.isEmpty()) meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }
}
