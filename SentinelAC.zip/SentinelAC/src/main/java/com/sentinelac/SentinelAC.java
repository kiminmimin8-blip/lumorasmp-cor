package com.sentinelac;

import com.sentinelac.alerts.AlertManager;
import com.sentinelac.bot.BotDetectionManager;
import com.sentinelac.checks.combat.AutoClickerCheck;
import com.sentinelac.checks.combat.KillAuraCheck;
import com.sentinelac.checks.combat.ReachCheck;
import com.sentinelac.checks.misc.FastUseCheck;
import com.sentinelac.checks.misc.InvalidPitchCheck;
import com.sentinelac.checks.misc.InventoryMoveCheck;
import com.sentinelac.checks.misc.KnockbackCheck;
import com.sentinelac.checks.misc.NoSwingCheck;
import com.sentinelac.checks.misc.RotationCheck;
import com.sentinelac.checks.packet.BlinkCheck;
import com.sentinelac.checks.packet.TimerCheck;
import com.sentinelac.checks.movement.FlyCheck;
import com.sentinelac.checks.movement.JesusCheck;
import com.sentinelac.checks.movement.NoFallCheck;
import com.sentinelac.checks.movement.NoSlowCheck;
import com.sentinelac.checks.movement.SpeedCheck;
import com.sentinelac.checks.movement.SpiderCheck;
import com.sentinelac.checks.movement.StepCheck;
import com.sentinelac.checks.world.AirPlaceCheck;
import com.sentinelac.checks.world.FastBreakCheck;
import com.sentinelac.checks.world.FastPlaceCheck;
import com.sentinelac.checks.world.NukerCheck;
import com.sentinelac.checks.world.ScaffoldCheck;
import com.sentinelac.commands.SentinelACCommand;
import com.sentinelac.config.ConfigManager;
import com.sentinelac.data.PlayerDataManager;
import com.sentinelac.listeners.BlockListener;
import com.sentinelac.listeners.CombatListener;
import com.sentinelac.listeners.GUIListener;
import com.sentinelac.listeners.ItemListener;
import com.sentinelac.listeners.MovementListener;
import com.sentinelac.listeners.PlayerConnectionListener;
import com.sentinelac.punishment.ExemptionManager;
import com.sentinelac.punishment.PunishmentManager;
import com.sentinelac.protocol.ProtocolLibHook;
import com.sentinelac.watchlist.WatchlistManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class SentinelAC extends JavaPlugin {

    private ConfigManager configManager;
    private PlayerDataManager playerDataManager;
    private AlertManager alertManager;
    private PunishmentManager punishmentManager;
    private ExemptionManager exemptionManager;
    private BotDetectionManager botDetectionManager;
    private WatchlistManager watchlistManager;

    // checks
    private SpeedCheck speedCheck;
    private FlyCheck flyCheck;
    private NoFallCheck noFallCheck;
    private JesusCheck jesusCheck;
    private NoSlowCheck noSlowCheck;
    private StepCheck stepCheck;
    private KillAuraCheck killAuraCheck;
    private ReachCheck reachCheck;
    private AutoClickerCheck autoClickerCheck;
    private FastBreakCheck fastBreakCheck;
    private FastPlaceCheck fastPlaceCheck;
    private NukerCheck nukerCheck;
    private ScaffoldCheck scaffoldCheck;
    private KnockbackCheck knockbackCheck;
    private InventoryMoveCheck inventoryMoveCheck;
    private FastUseCheck fastUseCheck;
    private InvalidPitchCheck invalidPitchCheck;
    private SpiderCheck spiderCheck;
    private AirPlaceCheck airPlaceCheck;
    private TimerCheck timerCheck;
    private BlinkCheck blinkCheck;
    private RotationCheck rotationCheck;
    private NoSwingCheck noSwingCheck;

    // nullable — only set if ProtocolLib is installed. Never referenced
    // anywhere except inside the guarded block in onEnable/onDisable below.
    private ProtocolLibHook protocolLibHook;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.configManager = new ConfigManager(this);
        this.playerDataManager = new PlayerDataManager();
        this.alertManager = new AlertManager(this);
        this.punishmentManager = new PunishmentManager(this);
        this.exemptionManager = new ExemptionManager(this);
        this.botDetectionManager = new BotDetectionManager(this);
        this.watchlistManager = new WatchlistManager(this);

        this.speedCheck = new SpeedCheck(this);
        this.flyCheck = new FlyCheck(this);
        this.noFallCheck = new NoFallCheck(this);
        this.jesusCheck = new JesusCheck(this);
        this.noSlowCheck = new NoSlowCheck(this);
        this.stepCheck = new StepCheck(this);
        this.killAuraCheck = new KillAuraCheck(this);
        this.reachCheck = new ReachCheck(this);
        this.autoClickerCheck = new AutoClickerCheck(this);
        this.fastBreakCheck = new FastBreakCheck(this);
        this.fastPlaceCheck = new FastPlaceCheck(this);
        this.nukerCheck = new NukerCheck(this);
        this.scaffoldCheck = new ScaffoldCheck(this);
        this.knockbackCheck = new KnockbackCheck(this);
        this.inventoryMoveCheck = new InventoryMoveCheck(this);
        this.fastUseCheck = new FastUseCheck(this);
        this.invalidPitchCheck = new InvalidPitchCheck(this);
        this.spiderCheck = new SpiderCheck(this);
        this.airPlaceCheck = new AirPlaceCheck(this);
        this.timerCheck = new TimerCheck(this);
        this.blinkCheck = new BlinkCheck(this);
        this.rotationCheck = new RotationCheck(this);
        this.noSwingCheck = new NoSwingCheck(this);

        getServer().getPluginManager().registerEvents(new PlayerConnectionListener(this), this);
        getServer().getPluginManager().registerEvents(new MovementListener(this), this);
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new BlockListener(this), this);
        getServer().getPluginManager().registerEvents(new ItemListener(this), this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);

        // packet-level checks: only touch ProtocolLibHook (and therefore
        // only classload com.comphenix.protocol.*) if ProtocolLib is
        // actually installed and enabled. See ProtocolLibHook's class
        // Javadoc for why this guard is what keeps SentinelAC safe to run
        // WITHOUT ProtocolLib at all.
        if (Bukkit.getPluginManager().isPluginEnabled("ProtocolLib")) {
            this.protocolLibHook = new ProtocolLibHook(this);
            protocolLibHook.register();
            getLogger().info("ProtocolLib detected — packet-level checks (Timer, Blink) are ACTIVE.");
        } else {
            getLogger().warning("ProtocolLib not found — Timer and Blink checks are disabled.");
            getLogger().warning("Install ProtocolLib (https://www.spigotmc.org/resources/protocollib.1997/) for packet-level detection.");
        }

        SentinelACCommand cmd = new SentinelACCommand(this);
        getCommand("sentinelac").setExecutor(cmd);
        getCommand("sentinelac").setTabCompleter(cmd);

        new SentinelTask(this).runTaskTimer(this, 20L, 20L);

        getLogger().info("SentinelAC enabled — " + countChecks() + " checks active.");
    }

    @Override
    public void onDisable() {
        if (protocolLibHook != null) {
            protocolLibHook.unregister();
        }
        getLogger().info("SentinelAC disabled.");
    }

    private int countChecks() {
        return 23;
    }

    // ---- getters ----
    public ConfigManager getConfigManager() { return configManager; }
    public PlayerDataManager getPlayerDataManager() { return playerDataManager; }
    public AlertManager getAlertManager() { return alertManager; }
    public PunishmentManager getPunishmentManager() { return punishmentManager; }
    public ExemptionManager getExemptionManager() { return exemptionManager; }
    public BotDetectionManager getBotDetectionManager() { return botDetectionManager; }
    public WatchlistManager getWatchlistManager() { return watchlistManager; }

    public SpeedCheck getSpeedCheck() { return speedCheck; }
    public FlyCheck getFlyCheck() { return flyCheck; }
    public NoFallCheck getNoFallCheck() { return noFallCheck; }
    public JesusCheck getJesusCheck() { return jesusCheck; }
    public NoSlowCheck getNoSlowCheck() { return noSlowCheck; }
    public StepCheck getStepCheck() { return stepCheck; }
    public KillAuraCheck getKillAuraCheck() { return killAuraCheck; }
    public ReachCheck getReachCheck() { return reachCheck; }
    public AutoClickerCheck getAutoClickerCheck() { return autoClickerCheck; }
    public FastBreakCheck getFastBreakCheck() { return fastBreakCheck; }
    public FastPlaceCheck getFastPlaceCheck() { return fastPlaceCheck; }
    public NukerCheck getNukerCheck() { return nukerCheck; }
    public ScaffoldCheck getScaffoldCheck() { return scaffoldCheck; }
    public KnockbackCheck getKnockbackCheck() { return knockbackCheck; }
    public InventoryMoveCheck getInventoryMoveCheck() { return inventoryMoveCheck; }
    public FastUseCheck getFastUseCheck() { return fastUseCheck; }
    public InvalidPitchCheck getInvalidPitchCheck() { return invalidPitchCheck; }
    public SpiderCheck getSpiderCheck() { return spiderCheck; }
    public AirPlaceCheck getAirPlaceCheck() { return airPlaceCheck; }
    public TimerCheck getTimerCheck() { return timerCheck; }
    public BlinkCheck getBlinkCheck() { return blinkCheck; }
    public RotationCheck getRotationCheck() { return rotationCheck; }
    public NoSwingCheck getNoSwingCheck() { return noSwingCheck; }
}
