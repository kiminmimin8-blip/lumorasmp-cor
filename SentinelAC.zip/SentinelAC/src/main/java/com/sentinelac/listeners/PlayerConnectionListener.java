package com.sentinelac.listeners;

import com.sentinelac.SentinelAC;
import com.sentinelac.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerConnectionListener implements Listener {

    private final SentinelAC plugin;

    public PlayerConnectionListener(SentinelAC plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onPreLogin(AsyncPlayerPreLoginEvent event) {
        String ip = event.getAddress().getHostAddress();
        plugin.getBotDetectionManager().registerJoin(ip);

        if (plugin.getBotDetectionManager().isDuplicateIpFlood(ip)) {
            plugin.getLogger().warning("Blocked login from " + event.getName() + " (" + ip + "): too many accounts from this IP recently.");
            event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER,
                    org.bukkit.ChatColor.RED + "Too many connections from your network. Try again shortly.");
            return;
        }

        if (plugin.getBotDetectionManager().nameLooksLikeBot(event.getName())
                && plugin.getBotDetectionManager().isAttackMode()) {
            plugin.getLogger().warning("Blocked login from " + event.getName() + " (" + ip + "): name pattern + active attack mode.");
            event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER,
                    org.bukkit.ChatColor.RED + "Verification required. Please try again.");
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (player.hasPermission("sentinelac.bypass.antibot")) return;

        PlayerData data = plugin.getPlayerDataManager().get(player);
        plugin.getWatchlistManager().touchSeen(player);
        data.initialYaw = player.getLocation().getYaw();
        data.initialPitch = player.getLocation().getPitch();
        data.joinIp = player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : "";

        boolean requireVerification = plugin.getConfigManager().getB("anti-bot.verification.require-on-attack-mode", true);
        boolean shouldVerify = requireVerification && plugin.getBotDetectionManager().isAttackMode();

        if (shouldVerify) {
            data.pendingVerification = true;
            data.verified = false;
        } else {
            data.verified = true;
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getPlayerDataManager().remove(event.getPlayer());
    }
}
