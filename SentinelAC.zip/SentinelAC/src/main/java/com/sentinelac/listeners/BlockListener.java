package com.sentinelac.listeners;

import com.sentinelac.SentinelAC;
import com.sentinelac.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockPlaceEvent;

public class BlockListener implements Listener {

    private final SentinelAC plugin;

    public BlockListener(SentinelAC plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockDamage(BlockDamageEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        plugin.getFastBreakCheck().onBreakStart(player, data);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        plugin.getFastBreakCheck().onBreakComplete(player, data, event.getBlock());
        plugin.getNukerCheck().onBreak(player, data);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        plugin.getFastPlaceCheck().onPlace(player, data);
        plugin.getScaffoldCheck().onPlace(player, data);
        plugin.getAirPlaceCheck().onPlace(player, data, event);
    }
}
