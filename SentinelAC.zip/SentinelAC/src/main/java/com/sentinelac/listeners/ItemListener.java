package com.sentinelac.listeners;

import com.sentinelac.SentinelAC;
import com.sentinelac.data.PlayerData;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.ItemStack;

public class ItemListener implements Listener {

    private final SentinelAC plugin;

    public ItemListener(SentinelAC plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_AIR
                && event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null) return;
        if (!item.getType().isEdible() && item.getType() != Material.POTION
                && item.getType() != Material.MILK_BUCKET) return;

        Player player = event.getPlayer();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        plugin.getFastUseCheck().onStartUsing(player, data);
    }

    @EventHandler(ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        plugin.getFastUseCheck().onFinishUsing(player, data);
    }
}
