package com.sentinelac.listeners;

import com.sentinelac.SentinelAC;
import com.sentinelac.data.PlayerData;
import com.sentinelac.gui.WatchlistGUI;
import com.sentinelac.gui.WatchlistHolder;
import com.sentinelac.utils.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class GUIListener implements Listener {

    private final SentinelAC plugin;

    public GUIListener(SentinelAC plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof WatchlistHolder holder)) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player staff)) return;
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null) return;

        if (clicked.getType() == Material.BARRIER) {
            staff.closeInventory();
            return;
        }
        if (clicked.getType() == Material.LIME_DYE) {
            WatchlistGUI.open(staff, plugin);
            return;
        }

        UUID target = holder.get(event.getSlot());
        if (target == null) return;

        OfflinePlayer off = Bukkit.getOfflinePlayer(target);
        Player online = off.getPlayer();

        if (event.isRightClick()) {
            if (online != null && online.isOnline()) {
                online.kickPlayer(TextUtil.color("&cKicked by staff via SentinelAC watchlist."));
                staff.sendMessage(TextUtil.color("&aKicked " + off.getName() + "."));
            } else {
                staff.sendMessage(TextUtil.color("&cThat player isn't online."));
            }
            WatchlistGUI.open(staff, plugin);
            return;
        }

        if (event.isShiftClick()) {
            if (online != null && online.isOnline()) {
                PlayerData data = plugin.getPlayerDataManager().get(online);
                data.frozen = !data.frozen;
                staff.sendMessage(TextUtil.color(data.frozen ? "&bFroze " + off.getName() + "." : "&aUnfroze " + off.getName() + "."));
            } else {
                staff.sendMessage(TextUtil.color("&cThat player isn't online."));
            }
            WatchlistGUI.open(staff, plugin);
            return;
        }

        // plain left-click: teleport
        if (online != null && online.isOnline()) {
            staff.teleport(online.getLocation());
            staff.sendMessage(TextUtil.color("&aTeleported to " + off.getName() + "."));
            staff.closeInventory();
        } else {
            staff.sendMessage(TextUtil.color("&cThat player isn't online."));
        }
    }
}
