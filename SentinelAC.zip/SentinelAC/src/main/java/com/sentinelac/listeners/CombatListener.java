package com.sentinelac.listeners;

import com.sentinelac.SentinelAC;
import com.sentinelac.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerAnimationEvent;

public class CombatListener implements Listener {

    private final SentinelAC plugin;

    public CombatListener(SentinelAC plugin) {
        this.plugin = plugin;
    }

    // Arm swing fires on every left-click (attack or air-swing), which is
    // exactly what we need to sample click rate for the autoclicker check
    // without requiring a packet-level dependency.
    @EventHandler(ignoreCancelled = true)
    public void onSwing(PlayerAnimationEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        data.lastSwingTime = System.currentTimeMillis();
        plugin.getAutoClickerCheck().onClick(player, data);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof LivingEntity target)) return;

        PlayerData data = plugin.getPlayerDataManager().get(attacker);
        plugin.getKillAuraCheck().onAttack(attacker, data, target);
        plugin.getReachCheck().onAttack(attacker, data, target);

        // one tick later so a same-tick swing packet that Bukkit happened to
        // process AFTER this damage event still counts (see NoSwingCheck's
        // Javadoc for why this avoids a packet-ordering false-positive race)
        long attackTime = plugin.getNoSwingCheck().captureAttackTime();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (attacker.isOnline()) {
                plugin.getNoSwingCheck().verify(attacker, data, attackTime);
            }
        }, 1L);
    }

    // fires for ANY damage cause on a player, which is exactly what we want
    // for the knockback check (arrows, other players, etc. all apply KB)
    @EventHandler(ignoreCancelled = true)
    public void onAnyDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;

        PlayerData data = plugin.getPlayerDataManager().get(victim);
        data.lastDamageTakenTime = System.currentTimeMillis(); // used by FlyCheck's knockback-grace window

        // BUGFIX: snapshot captured as a LOCAL variable here, not written to
        // shared PlayerData — each hit's closure carries its own independent
        // "before" position, so rapid multi-hit (two arrows, two attackers)
        // can never clobber another pending check's baseline. See
        // KnockbackCheck's class Javadoc for the full story.
        Location before = victim.getLocation().clone();

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (victim.isOnline()) {
                plugin.getKnockbackCheck().verify(victim, data, before);
            }
        }, 2L);
    }
}
