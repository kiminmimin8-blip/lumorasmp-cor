package com.sentinelac.utils;

import org.bukkit.ChatColor;

public class TextUtil {
    public static String color(String s) {
        if (s == null) return "";
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}
