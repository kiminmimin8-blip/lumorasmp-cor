package com.sentinelac.utils;

import org.bukkit.Location;
import org.bukkit.util.Vector;

public class MathUtil {

    /** Angle in degrees between a player's view direction and the direction to a target location. */
    public static double angleToTarget(Location eye, float yaw, float pitch, Location target) {
        Vector view = getDirection(yaw, pitch);
        Vector toTarget = target.toVector().subtract(eye.toVector()).normalize();
        double dot = view.normalize().dot(toTarget);
        dot = Math.max(-1.0, Math.min(1.0, dot));
        return Math.toDegrees(Math.acos(dot));
    }

    public static Vector getDirection(float yaw, float pitch) {
        double yawRad = Math.toRadians(yaw);
        double pitchRad = Math.toRadians(pitch);
        double x = -Math.sin(yawRad) * Math.cos(pitchRad);
        double y = -Math.sin(pitchRad);
        double z = Math.cos(yawRad) * Math.cos(pitchRad);
        return new Vector(x, y, z);
    }

    public static double horizontalDistance(Location a, Location b) {
        double dx = a.getX() - b.getX();
        double dz = a.getZ() - b.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    public static double distance3D(Location a, Location b) {
        return a.distance(b);
    }

    /** Simple population standard deviation, used for autoclicker interval-variance checks. */
    public static double stdDev(long[] values) {
        if (values.length == 0) return 0;
        double mean = 0;
        for (long v : values) mean += v;
        mean /= values.length;
        double sumSq = 0;
        for (long v : values) sumSq += (v - mean) * (v - mean);
        return Math.sqrt(sumSq / values.length);
    }

    public static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    public static int gcd(int a, int b) {
        a = Math.abs(a);
        b = Math.abs(b);
        while (b != 0) {
            int t = b;
            b = a % b;
            a = t;
        }
        return a;
    }
}
