package com.sentinelac.punishment;

import com.sentinelac.SentinelAC;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

public class ExemptionManager {

    private final SentinelAC plugin;

    public ExemptionManager(SentinelAC plugin) {
        this.plugin = plugin;
    }

    public boolean isExempt(Player player) {
        String perm = plugin.getConfigManager().getS("exemptions.bypass-permission", "sentinelac.bypass");
        if (player.hasPermission(perm)) return true;

        if (plugin.getConfigManager().getB("exemptions.exempt-ops", true) && player.isOp()) return true;

        if (plugin.getConfigManager().getB("exemptions.exempt-creative", true)
                && player.getGameMode() == GameMode.CREATIVE) return true;

        if (plugin.getConfigManager().getB("exemptions.exempt-spectator", true)
                && player.getGameMode() == GameMode.SPECTATOR) return true;

        var data = plugin.getPlayerDataManager().get(player);
        if (data.frozen) return true;

        // players still pending anti-bot verification shouldn't also be run through
        // gameplay checks yet — avoids double-flagging on the same suspicious signal.
        if (data.pendingVerification && !data.verified) return true;

        return false;
    }
}
