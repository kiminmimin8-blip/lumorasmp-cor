package com.sentinelac.data;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.UUID;

/**
 * Per-player runtime state used by every check. One instance per online
 * player, created on join and discarded on quit.
 */
public class PlayerData {

    public final UUID uuid;
    public final String lastKnownName;

    // ---- violation levels, per check key ----
    private final Map<String, Double> violationLevels = new HashMap<>();
    private final Map<String, Long> lastViolationTime = new HashMap<>();

    // ---- movement state ----
    public Location lastLocation;
    public Location previousLocation;
    public double lastDeltaY = 0;
    public int airTicks = 0;
    public int climbStreak = 0;
    public int groundTicks = 0;
    public boolean wasOnGround = true;
    public double fallDistanceTracked = 0;
    public int ticksOnWaterSurface = 0;
    public long lastJumpTime = 0;

    // ---- combat state ----
    public final LinkedList<Long> recentClicks = new LinkedList<>();
    public final LinkedList<UUID> recentAttackTargets = new LinkedList<>();
    public final LinkedList<Long> recentAttackTimes = new LinkedList<>();
    public float lastYawBeforeHit = 0;
    public float lastPitchBeforeHit = 0;
    public long lastAttackTime = 0;

    // ---- block interaction state ----
    public long lastBlockBreakStart = 0;
    public long lastBlockBreakTime = 0;
    public long lastBlockPlaceTime = 0;
    public final LinkedList<Long> recentBlockBreaks = new LinkedList<>();
    public final LinkedList<Long> recentBlockPlaces = new LinkedList<>();

    // ---- anti-bot / verification state ----
    public boolean verified = false;
    public boolean pendingVerification = false;
    public long joinTime = 0;
    public int ticksSinceJoin = 0;
    public float initialYaw = 0;
    public float initialPitch = 0;
    public boolean hasMovedSinceJoin = false;
    public boolean hasLookedSinceJoin = false;
    public String joinIp = "";
    public boolean flaggedAsBot = false;

    // frozen (e.g. while under review)
    public boolean frozen = false;

    // ---- knockback check state ----
    // (the "before" position snapshot is now a local var in CombatListener's
    // closure per-hit, not stored here — see KnockbackCheck's Javadoc for why)
    public long lastDamageTakenTime = 0;

    // ---- item-use (fastuse) state ----
    public long itemUseStartTime = 0;

    // ---- watchlist state ----
    public double totalVlEver = 0;
    public long lastSeenMillis = System.currentTimeMillis();
    public String lastFlagSummary = "";

    // ---- packet-level state (only populated if ProtocolLib is present) ----
    public final LinkedList<Long> movementPacketTimes = new LinkedList<>();
    public long lastPacketReceivedTime = 0;
    public long lastPacketGapStart = 0;
    public boolean pendingBurstCheck = false;

    // ---- combat hardening ----
    public long lastSwingTime = 0;

    // ---- rotation / aim analysis ----
    public Float lastYaw = null;
    public final LinkedList<Integer> recentYawDeltas = new LinkedList<>();

    // ---- physics-prediction (Fly/Speed v2) ----
    public double predictedVelocityY = 0;
    public boolean physicsBaselineValid = false;
    public double lastGroundFriction = 0.6;

    public PlayerData(Player player) {
        this.uuid = player.getUniqueId();
        this.lastKnownName = player.getName();
        this.lastLocation = player.getLocation();
        this.previousLocation = player.getLocation();
        this.joinTime = System.currentTimeMillis();
    }

    public double getVL(String checkKey) {
        return violationLevels.getOrDefault(checkKey, 0.0);
    }

    public void addVL(String checkKey, double amount) {
        double current = getVL(checkKey);
        violationLevels.put(checkKey, current + amount);
        lastViolationTime.put(checkKey, System.currentTimeMillis());
    }

    public void resetVL(String checkKey) {
        violationLevels.put(checkKey, 0.0);
    }

    public void decayAll(double amount, long olderThanMs) {
        long now = System.currentTimeMillis();
        for (String key : new HashMap<>(violationLevels).keySet()) {
            Long last = lastViolationTime.get(key);
            if (last == null) continue;
            if (now - last >= olderThanMs) {
                double v = violationLevels.get(key);
                double nv = Math.max(0, v - amount);
                violationLevels.put(key, nv);
                lastViolationTime.put(key, now);
            }
        }
    }
}
