# SentinelAC

Anticheat + anti-bot plugin for Paper 1.21.x.

## Bug fixes in this revision (v2.1)

Found by deliberately tracing edge cases through the v2 checks before
shipping — these were real, not hypothetical:

1. **Movement dedup was skipping look-only ticks.** `MovementListener` used
   to ignore any PlayerMoveEvent where X/Y/Z didn't change, which meant a
   player standing still and just turning their head — extremely common
   mid-combat — never reached RotationCheck or InvalidPitchCheck at all.
   Fixed to also fire on yaw/pitch changes.
2. **FlyCheck could false-flag a player right after being un-frozen or
   finishing anti-bot verification.** The physics simulator wasn't reset on
   every exemption path, only some of them, so it could compare a fresh
   tick against a stale prediction from minutes earlier. Fixed to reset
   consistently on every exempt/disabled path.
3. **NoSwingCheck had a packet-ordering race that could flag legitimate
   slow-clickers.** Bukkit doesn't guarantee EntityDamageByEntityEvent
   fires after PlayerAnimationEvent when both land in the same tick.
   Rewritten to verify one tick later with a symmetric time window instead
   of a strict "swing must come first" check.
4. **KnockbackCheck's before/after snapshot was a single shared field that
   rapid multi-hit (two arrows, two attackers) could clobber**, corrupting
   whichever pending check ran against the wrong baseline. Rewritten so
   each hit's snapshot lives in its own closure, not shared player state.
   Also added a cornered-by-blocks exemption (a player boxed in by 2+ solid
   blocks can't be knocked anywhere even with knockback working correctly).
5. **SpeedCheck's friction bonus vanished the instant a player left an icy
   surface**, which would have flagged the completely legitimate "ice bhop"
   technique (jumping while sliding carries real vanilla momentum into the
   air). Added a short configurable grace period.

None of these needed a live server to find — they're the kind of bug that
only shows up by mentally running the concurrent/edge-case timeline, which
is exactly why they're called out explicitly here instead of silently
patched. There will be more; this plugin has not been run against a real
player base yet (see the testing advice throughout this README).

## Build

Requires Java 21 and Maven, with internet access to resolve the Paper API
from https://repo.papermc.io.

```
mvn clean package
```

Output jar: `target/SentinelAC-1.0.0.jar`

**Important:** the pom.xml pins `paper-api` to `1.21.4-R0.1-SNAPSHOT`. If your
exact 1.21.11 API artifact isn't available under that coordinate when you
build, check https://repo.papermc.io/#browse/browse:maven-public for the
closest available version string and update `<version>` in pom.xml
accordingly — the events/API this plugin uses (PlayerMoveEvent,
EntityDamageByEntityEvent, BlockBreakEvent, etc.) have been stable across
recent 1.21.x releases, so a nearby version will work.

## What's included

**Movement:** Speed (v2 — real per-block friction lookup, not a flat
heuristic), Fly (v2 — physics-prediction: simulates gravity/drag per tick
and flags compounding divergence instead of single-tick thresholds), NoFall,
Jesus/water-walk, NoSlow (eating/blocking/sneaking speed), Step (instant
elevation), Spider (wall-climbing without ladder/vine), InventoryMove
(moving with a GUI open), InvalidPitch (protocol-impossible view angle).

**Combat:** KillAura (attack-angle + multi-target-switch detection), Reach
(ping-compensated), AutoClicker (CPS + click-interval-variance analysis),
AntiKnockback (velocity-response check after taking damage), **Rotation**
(aim-pattern GCD analysis — catches aim-assist/killaura variants that pass
the angle check but turn in an unnaturally quantized way), **NoSwing**
(attacks without a preceding arm-swing animation — a classic raw-packet
KillAura tell).

**World:** FastBreak (vs. estimated vanilla break time), FastPlace, Nuker
(many blocks broken in a tiny time window), Scaffold (rapid placement while
not looking down), AirPlace (placing against a non-solid "phantom" block).

**Protocol (requires ProtocolLib, optional):** Timer (client tick-rate
manipulation), Blink (withheld-then-flushed movement packets).

**Items:** FastUse (eating/drinking faster than the vanilla animation allows).

**Anti-bot:**
- Join-flood detection → temporary server-wide "attack mode"
- Username pattern matching (regex list in config.yml)
- Duplicate-IP-in-short-window blocking
- Spawn-and-freeze bot detection: players who never move/look after joining
  (during attack mode) get kicked/banned/frozen per config

**Staff tools:**
- **`/sac gui`** — visual watchlist (chest GUI) of every flagged player, sorted
  worst-first. Shows per-check VL breakdown, last flag reason, online status.
  Left-click a head to teleport to that player, Shift+Left to freeze/unfreeze,
  Right-click to kick — all without leaving the GUI.
- `/sac top` — top 10 most-flagged players right now
- `/sac history <player>` — past punishments pulled from violations.log
- `/sac vl <player>` — live per-check violation levels
- `/sac freeze|unfreeze <player>` — lock a player in place instantly
- `/sac panic` — kick everyone currently flagged/unverified in one command
- Per-check violation levels with time-based decay (reduces false positives
  from single lag spikes)
- Configurable punishment commands per check
- Staff alert stream (`sentinelac.alerts` permission) with cooldown
- violations.log file

**Exemptions:**
- `sentinelac.bypass` permission
- **Server operators (OP) are bypassed by default** (`exemptions.exempt-ops:
  true` in config.yml — set to `false` if you want ops checked too, e.g. on a
  staff-testing server)
- Creative / Spectator gamemode
- Frozen players and players still completing anti-bot verification are
  exempted from gameplay checks (so they aren't double-flagged for the same
  signal)

## Honesty about limits — please read before deploying

1. **This is heuristic-based**, not packet-analysis-based like GrimAC/Vulcan/
   Matrix. It uses Bukkit/Paper events (PlayerMoveEvent, etc.), which is
   easier to build/maintain but structurally weaker against a cheat that
   spoofs client-reported state cleverly (e.g. some NoFall variants) — see
   the comment in `NoFallCheck`/`MovementListener` for the specific gap.
2. **Packet-timing hacks (Blink, Timer) now HAVE real detection — if you
   install ProtocolLib.** SentinelAC ships with a ProtocolLib soft-dependency
   (`softdepend` in plugin.yml). Drop [ProtocolLib](https://www.spigotmc.org/resources/protocollib.1997/)
   into your `plugins/` folder alongside SentinelAC and two extra checks
   activate automatically on startup (you'll see a log line confirming it):
   - **Timer** — flags clients running their internal tick loop faster than
     real time (used to mine/eat/attack faster without tripping the
     per-action checks, since everything scales together). Detected by
     sustained movement-packet rate, not by Bukkit's already-throttled
     PlayerMoveEvent.
   - **Blink** — flags clients that withhold movement packets for a stretch,
     then flush them all at once (a "teleport" that looks fine
     packet-to-packet but is timed impossibly).

   **Without ProtocolLib installed, SentinelAC still runs completely
   normally** — it just logs a warning and those two checks stay inactive.
   Nothing else is affected; this was built so a missing/incompatible
   ProtocolLib version can never crash plugin startup (see the Javadoc on
   `ProtocolLibHook` for exactly how that's guaranteed).
3. **"90% no false positives" is a tuning outcome, not a guarantee any
   anticheat can ship with out of the box.** All the real thresholds live in
   `config.yml` on purpose. Start on a test server with a few real players
   doing normal things (elytra, boats, ice, honey blocks, bows, shields,
   fast miners with efficiency picks), watch `/sac gui` and `/sac vl
   <player>`, and loosen whichever check fires on legitimate play before you
   ever point this at your live player base.
4. Lag compensation is intentionally conservative (buffers + decay) but a
   badly performing server (low TPS) will still cause more false positives
   across every check — that's true of every tick/event-based anticheat.
5. KillAura's angle check, Scaffold's pitch check, and Spider's wall check
   are the three most likely to need retuning per your playerbase's average
   latency and build style.
6. **The Fly physics-prediction model is intentionally partial.** It
   correctly simulates gravity+drag for normal jumps and free-fall, but it
   does NOT model every vanilla surface (powder snow, cobwebs, lily pads,
   bubble columns, dolphin's grace, slow-falling stacking with other
   effects). It exempts the big/obvious cases (elytra, riptide, swimming,
   levitation, vehicles) outright rather than trying to simulate them
   badly. If your server uses a lot of the unmodeled surfaces, watch that
   specific traffic in `/sac gui` after deploying.
7. **Rotation's GCD check is deliberately conservative** (high sample size,
   high GCD threshold) because a false positive here — flagging a real
   player's mouse/controller sensitivity setup as an aimbot — is more
   damaging to trust than most other checks. If you have players on
   controller/Bedrock-via-Geyser with fixed-increment look input, consider
   raising `min-suspicious-gcd` further or disabling this check for them
   specifically via a bypass permission group.
