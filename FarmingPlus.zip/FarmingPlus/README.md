# FarmingPlus 1.3.1 (Paper 1.21.11)

## Build
Butuh JDK 21 + Maven:

    mvn clean package

Hasil: `target/FarmingPlus-1.3.1.jar` -> taruh di `plugins/`.

## Setup cepat
1. Bangun farm di world khusus (farmland + air + crop udah ditanam admin).
2. Berdiri di titik spawn farm -> `/farmingplus setspawn` (world itu otomatis jadi farm world).
3. Kasih permission rank di LuckPerms, contoh: `farmingplus.rank.vip`.
4. Member masuk pakai `/farmings`. Admin masuk buat setting pakai `/farmingplus tp` (tanpa timer, cooldown, bebas build), keluar pakai `/farmingplus exit`.
5. (Opsional) isi `rewards.commands` di config biar member dapat uang, contoh: `eco give %player% %money%`.

## Cara kerja
- Crop di farm world punya timer sendiri (default 5 detik) dan gak bisa matang sebelum itu.
- Member `/farmings` -> teleport ke spawn farm, sesi mulai (default 3 menit, rank bisa lebih).
- Member cuma bisa break crop yang udah matang; crop otomatis ditanam ulang (gratis).
- Admin/OP juga kena auto tanam ulang; sneak waktu break kalau mau bongkar farm tanpa ditanam ulang.
- Bossbar hitung mundur + jumlah panen + peringatan di 30/10/5/3/2/1 detik.
- Waktu habis -> dibalikin ke lokasi semula (kalau hilang, ke spawn world utama).
- Setelah sesi ada cooldown (default 12 jam), disimpan di `players.yml` jadi aman walau restart.
- Teleport lain ke farm (/back, /home, /tpa, /warp) diblok; masuk cuma lewat /farmings.

## Fitur
- Rank: lama sesi, pengali drop, pengali uang
- Hasil panen langsung masuk inventory (auto-pickup)
- Hadiah uang tiap sesi lewat command console (bebas plugin ekonomi)
- Statistik + leaderboard (`/farmings stats`, `/farmings top`)
- Batas pemain barengan (`session.max-players`)
- Title saat masuk, bossbar, peringatan waktu
- Farm world: tanpa mob spawn, tanpa lapar, tanpa PvP
- `world.restrict-build` (default MATI): kalau mau plugin ini yang ngatur siapa boleh build/break
  di farm world (bukan region plugin sendiri), nyalain manual di config.

## Command
- `/farmings` masuk | `leave` | `time` (sisa waktu / cooldown) | `stats` | `top`
- `/farmingplus reload|info|setspawn|tp|exit|extend|end|resetcd|mature`

## Permission
- `farmingplus.use` (semua) - pakai /farmings
- `farmingplus.rank.<nama>` - rank sesuai `session.ranks` di config
- `farmingplus.bypass.time` / `.cooldown` / `.build` (op) - tanpa batas waktu / tanpa cooldown / build bebas
- `farmingplus.admin` (op) - command admin
