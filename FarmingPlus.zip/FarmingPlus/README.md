# FarmingPlus 1.1.0 (Paper 1.21.11)

## Build
Butuh JDK 21 + Maven:

    mvn clean package

Hasil: `target/FarmingPlus-1.1.0.jar` -> taruh di `plugins/`.

## Setup cepat
1. Siapin farm world (farmland + air udah dibangun admin).
2. Berdiri di titik spawn farm -> `/farmingplus setspawn` (world itu otomatis jadi farm world).
3. Kasih permission rank di LuckPerms, contoh: `farmingplus.rank.vip`.
4. Member masuk pakai `/farmings`.

## Cara kerja
- Member `/farmings` -> teleport ke spawn farm, sesi mulai (default 5 menit, rank bisa lebih).
- Member cuma bisa break crop yang udah matang; crop otomatis ditanam ulang (gratis) dan tumbuh lagi 60 detik.
- Teleport lain ke farm (/back, /home, /tpa, /warp) diblok; masuk cuma lewat /farmings.
- Member gak bisa naruh block / nanam sendiri.
- Bossbar hitung mundur + peringatan di 30/10/5/3/2/1 detik.
- Waktu habis -> dibalikin ke lokasi semula (kalau hilang, ke spawn world utama).
- Setelah sesi ada cooldown (default 12 jam, 0 = mati).
- Crop di farm world punya timer sendiri (60 detik) dan gak bisa matang sebelum itu.

## Command
- `/farmings` masuk | `/farmings leave` keluar | `/farmings time` sisa waktu
- `/farmingplus reload|info|setspawn|extend|end|mature`

## Permission
- `farmingplus.use` (semua) - pakai /farmings
- `farmingplus.rank.<nama>` - waktu sesi lebih lama, sesuai `session.ranks` di config
- `farmingplus.bypass.time` / `.cooldown` / `.build` (op) - tanpa batas waktu / tanpa cooldown / build bebas
- `farmingplus.admin` (op) - command admin
