package com.farmingplus;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;

/** /farmings -> masuk farm | /farmings leave -> keluar | /farmings time -> sisa waktu */
public final class FarmingsCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBS = List.of("leave", "time");

    private final FarmingPlus plugin;

    public FarmingsCommand(FarmingPlus plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Command ini cuma buat pemain.");
            return true;
        }
        SessionManager sessions = plugin.sessions();
        if (args.length == 0) {
            sessions.enter(p);
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "leave", "keluar" -> sessions.leave(p);
            case "time", "waktu" -> {
                long remaining = sessions.remainingSeconds(p);
                if (remaining < 0) {
                    p.sendMessage(plugin.settings().message("not-in-farm"));
                } else {
                    p.sendMessage(plugin.settings().message("time-left", "%time%", SessionManager.formatLong(remaining)));
                }
            }
            default -> p.sendMessage(plugin.settings().message("farmings-usage"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            return SUBS.stream().filter(x -> x.startsWith(prefix)).toList();
        }
        return List.of();
    }
}
