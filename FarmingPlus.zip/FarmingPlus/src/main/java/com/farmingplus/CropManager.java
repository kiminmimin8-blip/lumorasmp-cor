package com.farmingplus;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Nyimpen "kapan crop ditanam" per crop. Data disimpan di PDC chunk (long array
 * berisi pasangan [posisi, waktuTanamMillis]) jadi tetap aman waktu restart.
 * Waktu pakai jam sistem, jadi crop tetap "tumbuh" walau chunk-nya lagi unload.
 */
public final class CropManager {

    private record ChunkKey(UUID world, long key) {}

    private static final class ChunkCrops {
        final UUID world;
        final int cx;
        final int cz;
        final Map<Long, Long> crops = new HashMap<>();
        boolean dirty;

        ChunkCrops(UUID world, int cx, int cz) {
            this.world = world;
            this.cx = cx;
            this.cz = cz;
        }
    }

    private final FarmingPlus plugin;
    private final NamespacedKey dataKey;
    private final Map<ChunkKey, ChunkCrops> chunks = new HashMap<>();

    CropManager(FarmingPlus plugin) {
        this.plugin = plugin;
        this.dataKey = new NamespacedKey(plugin, "crops");
    }

    // ---------------------------------------------------------------- key helpers

    private static long chunkKey(int cx, int cz) {
        return ((long) cx & 0xFFFFFFFFL) | (((long) cz & 0xFFFFFFFFL) << 32);
    }

    private static long pack(Block b) {
        return ((long) b.getY() << 8) | ((b.getX() & 15) << 4) | (b.getZ() & 15);
    }

    private static ChunkKey keyOf(Block b) {
        return new ChunkKey(b.getWorld().getUID(), chunkKey(b.getX() >> 4, b.getZ() >> 4));
    }

    // ---------------------------------------------------------------- tracking API

    public void track(Block b, long plantedAtMillis) {
        ChunkKey k = keyOf(b);
        ChunkCrops cc = chunks.get(k);
        if (cc == null) {
            cc = new ChunkCrops(b.getWorld().getUID(), b.getX() >> 4, b.getZ() >> 4);
            chunks.put(k, cc);
        }
        cc.crops.put(pack(b), plantedAtMillis);
        cc.dirty = true;
    }

    public Long getPlantedAt(Block b) {
        ChunkCrops cc = chunks.get(keyOf(b));
        return cc == null ? null : cc.crops.get(pack(b));
    }

    public boolean isTracked(Block b) {
        return getPlantedAt(b) != null;
    }

    public void untrack(Block b) {
        ChunkCrops cc = chunks.get(keyOf(b));
        if (cc != null && cc.crops.remove(pack(b)) != null) {
            cc.dirty = true;
        }
    }

    public int trackedCount() {
        int total = 0;
        for (ChunkCrops cc : chunks.values()) total += cc.crops.size();
        return total;
    }

    /** Langsung matangin crop (dipakai command admin). */
    public boolean forceMature(Block b) {
        if (!plugin.settings().crops.contains(b.getType())) return false;
        if (!(b.getBlockData() instanceof Ageable ageable)) return false;
        if (ageable.getAge() >= ageable.getMaximumAge()) return false;
        ageable.setAge(ageable.getMaximumAge());
        b.setBlockData(ageable, false);
        untrack(b);
        return true;
    }

    // ---------------------------------------------------------------- persistence

    public void loadChunk(Chunk chunk) {
        long[] data = chunk.getPersistentDataContainer().get(dataKey, PersistentDataType.LONG_ARRAY);
        if (data == null || data.length < 2) return;

        ChunkCrops cc = new ChunkCrops(chunk.getWorld().getUID(), chunk.getX(), chunk.getZ());
        for (int i = 0; i + 1 < data.length; i += 2) {
            cc.crops.put(data[i], data[i + 1]);
        }
        chunks.put(new ChunkKey(chunk.getWorld().getUID(), chunkKey(chunk.getX(), chunk.getZ())), cc);
    }

    public void unloadChunk(Chunk chunk) {
        ChunkCrops cc = chunks.remove(new ChunkKey(chunk.getWorld().getUID(), chunkKey(chunk.getX(), chunk.getZ())));
        if (cc != null && cc.dirty) {
            write(chunk, cc);
        }
    }

    public void saveDirty() {
        for (ChunkCrops cc : chunks.values()) {
            if (!cc.dirty) continue;
            World world = Bukkit.getWorld(cc.world);
            if (world == null || !world.isChunkLoaded(cc.cx, cc.cz)) continue;
            write(world.getChunkAt(cc.cx, cc.cz), cc);
        }
    }

    private void write(Chunk chunk, ChunkCrops cc) {
        PersistentDataContainer pdc = chunk.getPersistentDataContainer();
        if (cc.crops.isEmpty()) {
            pdc.remove(dataKey);
        } else {
            long[] data = new long[cc.crops.size() * 2];
            int i = 0;
            for (Map.Entry<Long, Long> e : cc.crops.entrySet()) {
                data[i++] = e.getKey();
                data[i++] = e.getValue();
            }
            pdc.set(dataKey, PersistentDataType.LONG_ARRAY, data);
        }
        cc.dirty = false;
    }

    // ---------------------------------------------------------------- ticker

    /** Dipanggil tiap tick-interval: naikin stage crop sesuai umur, matangin kalau waktunya habis. */
    public void tick() {
        Settings s = plugin.settings();
        long now = System.currentTimeMillis();

        for (ChunkCrops cc : chunks.values()) {
            if (cc.crops.isEmpty()) continue;
            World world = Bukkit.getWorld(cc.world);
            if (world == null || !world.isChunkLoaded(cc.cx, cc.cz)) continue;
            if (!plugin.farmData().isFarmWorld(world)) continue;

            Iterator<Map.Entry<Long, Long>> it = cc.crops.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<Long, Long> entry = it.next();
                long pos = entry.getKey();
                int x = (cc.cx << 4) + (int) ((pos >> 4) & 15);
                int z = (cc.cz << 4) + (int) (pos & 15);
                int y = (int) (pos >> 8);

                Block block = world.getBlockAt(x, y, z);
                Material type = block.getType();

                // crop sudah hilang / diganti -> hapus dari tracking
                if (!s.crops.contains(type) || !(block.getBlockData() instanceof Ageable ageable)) {
                    it.remove();
                    cc.dirty = true;
                    continue;
                }

                int max = ageable.getMaximumAge();
                int age = ageable.getAge();
                if (age >= max) { // sudah matang (dari sumber lain)
                    it.remove();
                    cc.dirty = true;
                    continue;
                }

                long total = s.growMs(type);
                long elapsed = now - entry.getValue();
                if (elapsed < 0) { // jam sistem mundur
                    entry.setValue(now);
                    cc.dirty = true;
                    continue;
                }

                if (elapsed >= total) {
                    ageable.setAge(max);
                    block.setBlockData(ageable, false);
                    matureEffects(world, block, s);
                    it.remove();
                    cc.dirty = true;
                } else if (s.visualStages) {
                    int target = (int) (elapsed * max / total); // selalu < max sebelum waktunya habis
                    if (target > age) {
                        ageable.setAge(target);
                        block.setBlockData(ageable, false);
                    }
                }
            }
        }
    }

    private void matureEffects(World world, Block block, Settings s) {
        Location loc = block.getLocation().add(0.5, 0.4, 0.5);
        if (s.particles) {
            world.spawnParticle(Particle.HAPPY_VILLAGER, loc, 3, 0.25, 0.2, 0.25, 0);
        }
        if (s.sound) {
            world.playSound(loc, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.3f, 1.4f);
        }
    }
}
