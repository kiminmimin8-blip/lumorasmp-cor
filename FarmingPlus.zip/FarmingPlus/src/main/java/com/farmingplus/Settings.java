package com.farmingplus;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.block.data.Ageable;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class Settings {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    // crop
    final Set<Material> crops = EnumSet.noneOf(Material.class);
    final long defaultGrowMs;
    final int tickInterval;
    final boolean visualStages;
    final boolean blockBonemeal;
    final boolean protectFarmland;
    final boolean particles;
    final boolean sound;

    // sesi
    final int defaultSessionSeconds;
    final int cooldownSeconds;
    final boolean bossbar;
    final Map<String, Integer> ranks = new LinkedHashMap<>();
    final Set<Integer> warnAt = new HashSet<>();

    // aturan world
    final boolean restrictBuild;
    final boolean disablePvp;
    final Set<Material> allowedBreak = EnumSet.noneOf(Material.class);
    final Set<Material> autoReplant = EnumSet.noneOf(Material.class);
    final boolean onlyBreakMature;
    final boolean blockOutsideTeleport;

    private final Map<Material, Long> growMs = new EnumMap<>(Material.class);
    private final FileConfiguration cfg;

    Settings(FarmingPlus plugin) {
        FileConfiguration c = plugin.getConfig();
        this.cfg = c;

        defaultGrowMs = Math.max(1L, c.getLong("grow-time-seconds", 60L)) * 1000L;
        tickInterval = Math.max(1, c.getInt("tick-interval-ticks", 20));
        visualStages = c.getBoolean("visual-stages", true);
        blockBonemeal = c.getBoolean("block-bonemeal", true);
        protectFarmland = c.getBoolean("protect-farmland", true);
        particles = c.getBoolean("effects.particles", true);
        sound = c.getBoolean("effects.sound", false);

        defaultSessionSeconds = Math.max(1, c.getInt("session.default-seconds", 300));
        cooldownSeconds = Math.max(0, c.getInt("session.cooldown-seconds", 43200));
        bossbar = c.getBoolean("session.bossbar", true);
        warnAt.addAll(c.getIntegerList("session.warn-at-seconds"));

        ConfigurationSection rankSection = c.getConfigurationSection("session.ranks");
        if (rankSection != null) {
            for (String key : rankSection.getKeys(false)) {
                ranks.put(key, Math.max(1, rankSection.getInt(key)));
            }
        }

        restrictBuild = c.getBoolean("world.restrict-build", true);
        disablePvp = c.getBoolean("world.disable-pvp", true);
        onlyBreakMature = c.getBoolean("world.only-break-mature", true);
        blockOutsideTeleport = c.getBoolean("world.block-outside-teleport", true);

        loadMaterials(plugin, c.getStringList("crops"), crops, true);
        loadMaterials(plugin, c.getStringList("world.allowed-break"), allowedBreak, false);
        loadMaterials(plugin, c.getStringList("world.auto-replant"), autoReplant, true);

        ConfigurationSection per = c.getConfigurationSection("per-crop-seconds");
        if (per != null) {
            for (String key : per.getKeys(false)) {
                Material m = Material.matchMaterial(key);
                if (m != null && crops.contains(m)) {
                    growMs.put(m, Math.max(1L, per.getLong(key)) * 1000L);
                }
            }
        }
    }

    private static void loadMaterials(FarmingPlus plugin, List<String> names, Set<Material> out, boolean requireAgeable) {
        for (String name : names) {
            Material m = Material.matchMaterial(name);
            if (m == null || !m.isBlock() || (requireAgeable && !(m.createBlockData() instanceof Ageable))) {
                plugin.getLogger().warning("Material gak valid di config.yml: " + name);
                continue;
            }
            out.add(m);
        }
    }

    long growMs(Material type) {
        return growMs.getOrDefault(type, defaultGrowMs);
    }

    /** Ambil pesan dari config (MiniMessage). Replacement berupa pasangan key, value. */
    Component message(String key, String... replacements) {
        String raw = cfg.getString("messages." + key, "");
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            raw = raw.replace(replacements[i], replacements[i + 1]);
        }
        return MM.deserialize(raw);
    }
}
