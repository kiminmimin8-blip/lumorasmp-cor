package com.farmingplus;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.World;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public final class FarmingPlus extends JavaPlugin {

    private Settings settings;
    private FarmData farmData;
    private CropManager cropManager;
    private SessionManager sessionManager;

    private BukkitTask growTask;
    private BukkitTask saveTask;
    private BukkitTask sessionTask;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        settings = new Settings(this);
        farmData = new FarmData(this);
        cropManager = new CropManager(this);
        sessionManager = new SessionManager(this);

        getServer().getPluginManager().registerEvents(new FarmListener(this), this);
        getServer().getPluginManager().registerEvents(new WorldListener(this), this);

        FarmCommand admin = new FarmCommand(this);
        PluginCommand adminCmd = getCommand("farmingplus");
        if (adminCmd != null) {
            adminCmd.setExecutor(admin);
            adminCmd.setTabCompleter(admin);
        }

        FarmingsCommand member = new FarmingsCommand(this);
        PluginCommand memberCmd = getCommand("farmings");
        if (memberCmd != null) {
            memberCmd.setExecutor(member);
            memberCmd.setTabCompleter(member);
        }

        // Chunk yang sudah termuat sebelum plugin nyala
        for (World world : Bukkit.getWorlds()) {
            for (Chunk chunk : world.getLoadedChunks()) {
                cropManager.loadChunk(chunk);
            }
        }

        startTasks();

        if (!farmData.hasSpawn()) {
            getLogger().info("Spawn farm belum di-set. Berdiri di farm world lalu jalankan /farmingplus setspawn");
        }
    }

    @Override
    public void onDisable() {
        stopTasks();
        if (sessionManager != null) sessionManager.shutdown();
        if (cropManager != null) cropManager.saveDirty();
    }

    public void reloadAll() {
        reloadConfig();
        settings = new Settings(this);
        stopTasks();
        startTasks();
    }

    private void startTasks() {
        long interval = settings.tickInterval;
        growTask = getServer().getScheduler().runTaskTimer(this, cropManager::tick, interval, interval);
        saveTask = getServer().getScheduler().runTaskTimer(this, cropManager::saveDirty, 600L, 600L);
        sessionTask = getServer().getScheduler().runTaskTimer(this, sessionManager::tick, 20L, 20L);
    }

    private void stopTasks() {
        if (growTask != null) growTask.cancel();
        if (saveTask != null) saveTask.cancel();
        if (sessionTask != null) sessionTask.cancel();
        growTask = null;
        saveTask = null;
        sessionTask = null;
    }

    public Settings settings() {
        return settings;
    }

    public FarmData farmData() {
        return farmData;
    }

    public CropManager crops() {
        return cropManager;
    }

    public SessionManager sessions() {
        return sessionManager;
    }
}
