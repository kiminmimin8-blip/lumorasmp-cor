package com.farmingplus;

import net.kyori.adventure.bossbar.BossBar;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Ngatur sesi farm tiap member: masuk lewat /farmings, ada hitung mundur,
 * habis waktu -> dibalikin ke lokasi semula. Rank (permission) bisa dapat waktu lebih.
 */
public final class SessionManager {

    private static final class Session {
        final Location returnLoc;
        final BossBar bar; // bisa null kalau bossbar dimatiin
        long totalMs;
        long endMillis;
        int lastWarn = -1;

        Session(Location returnLoc, BossBar bar, long totalMs, long endMillis) {
            this.returnLoc = returnLoc;
            this.bar = bar;
            this.totalMs = totalMs;
            this.endMillis = endMillis;
        }
    }

    private final FarmingPlus plugin;
    private final Map<UUID, Session> sessions = new HashMap<>();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    /** Pemain yang lagi diteleport plugin ini ke farm (biar gak diblok listener teleport). */
    private final Set<UUID> entering = new HashSet<>();

    SessionManager(FarmingPlus plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------- query

    public boolean inSession(Player p) {
        return sessions.containsKey(p.getUniqueId());
    }

    /** Boleh berada di farm world: lagi sesi, lagi proses masuk lewat /farmings, atau punya bypass. */
    public boolean canBeInFarm(Player p) {
        return sessions.containsKey(p.getUniqueId())
                || entering.contains(p.getUniqueId())
                || p.hasPermission("farmingplus.bypass.time");
    }

    public int activeCount() {
        return sessions.size();
    }

    /** Sisa waktu (detik), atau -1 kalau lagi gak di sesi. */
    public long remainingSeconds(Player p) {
        Session ses = sessions.get(p.getUniqueId());
        if (ses == null) return -1;
        return Math.max(0L, (ses.endMillis - System.currentTimeMillis() + 999L) / 1000L);
    }

    /** Durasi sesi buat pemain ini (detik): default atau rank terlama. */
    public int durationSeconds(Player p) {
        Settings s = plugin.settings();
        int best = s.defaultSessionSeconds;
        for (Map.Entry<String, Integer> rank : s.ranks.entrySet()) {
            if (rank.getValue() > best && p.hasPermission("farmingplus.rank." + rank.getKey())) {
                best = rank.getValue();
            }
        }
        return best;
    }

    // ---------------------------------------------------------------- actions

    public void enter(Player p) {
        Settings s = plugin.settings();
        FarmData data = plugin.farmData();

        Location spawn = data.spawn();
        if (spawn == null) {
            p.sendMessage(s.message("no-spawn"));
            return;
        }
        if (sessions.containsKey(p.getUniqueId())) {
            p.sendMessage(s.message("already-in"));
            return;
        }

        long now = System.currentTimeMillis();
        if (!p.hasPermission("farmingplus.bypass.cooldown")) {
            Long until = cooldowns.get(p.getUniqueId());
            if (until != null && until > now) {
                p.sendMessage(s.message("cooldown", "%time%", formatLong((until - now + 999L) / 1000L)));
                return;
            }
        }

        boolean unlimited = p.hasPermission("farmingplus.bypass.time");
        boolean wasInFarm = data.isFarmWorld(p.getWorld());
        Location from = p.getLocation().clone();

        boolean teleported;
        entering.add(p.getUniqueId());
        try {
            teleported = p.teleport(spawn);
        } finally {
            entering.remove(p.getUniqueId());
        }
        if (!teleported) {
            return; // dibatalin plugin lain
        }

        if (unlimited) {
            p.sendMessage(s.message("entered-unlimited"));
            return;
        }

        long seconds = durationSeconds(p);
        long totalMs = seconds * 1000L;

        BossBar bar = null;
        if (s.bossbar) {
            bar = BossBar.bossBar(
                    s.message("bossbar", "%time%", formatClock(totalMs)),
                    1f, BossBar.Color.GREEN, BossBar.Overlay.PROGRESS);
            p.showBossBar(bar);
        }

        sessions.put(p.getUniqueId(), new Session(wasInFarm ? fallback() : from, bar, totalMs, now + totalMs));
        p.sendMessage(s.message("entered", "%time%", formatLong(seconds)));
    }

    /** Keluar dari farm secara sukarela (/farmings leave). */
    public void leave(Player p) {
        Session ses = sessions.remove(p.getUniqueId());
        if (ses != null) {
            finish(p.getUniqueId(), p, ses, false);
            return;
        }
        // gak ada sesi, tapi lagi di farm world (mis. staff) -> tetap dikeluarin
        if (plugin.farmData().isFarmWorld(p.getWorld())) {
            p.teleport(fallback());
            p.sendMessage(plugin.settings().message("left"));
        } else {
            p.sendMessage(plugin.settings().message("not-in-farm"));
        }
    }

    /** Admin nendang pemain dari sesi. */
    public boolean adminEnd(Player target) {
        Session ses = sessions.remove(target.getUniqueId());
        if (ses == null) return false;
        finish(target.getUniqueId(), target, ses, false);
        return true;
    }

    /** Admin nambah waktu. */
    public boolean extend(Player target, long seconds) {
        Session ses = sessions.get(target.getUniqueId());
        if (ses == null) return false;
        ses.endMillis += seconds * 1000L;
        ses.totalMs += seconds * 1000L;
        ses.lastWarn = -1;
        return true;
    }

    // ---------------------------------------------------------------- ticker

    public void tick() {
        if (sessions.isEmpty()) return;
        Settings s = plugin.settings();
        long now = System.currentTimeMillis();
        List<UUID> expired = new ArrayList<>();

        for (Map.Entry<UUID, Session> entry : sessions.entrySet()) {
            Player p = Bukkit.getPlayer(entry.getKey());
            Session ses = entry.getValue();
            if (p == null || !p.isOnline()) {
                expired.add(entry.getKey());
                continue;
            }

            long remaining = ses.endMillis - now;
            if (remaining <= 0L) {
                expired.add(entry.getKey());
                continue;
            }

            if (ses.bar != null) {
                ses.bar.name(s.message("bossbar", "%time%", formatClock(remaining)));
                ses.bar.progress((float) Math.max(0.0, Math.min(1.0, remaining / (double) ses.totalMs)));
                ses.bar.color(remaining <= 10_000L ? BossBar.Color.RED
                        : remaining <= 30_000L ? BossBar.Color.YELLOW : BossBar.Color.GREEN);
            }

            int secLeft = (int) ((remaining + 999L) / 1000L);
            if (secLeft != ses.lastWarn && s.warnAt.contains(secLeft)) {
                ses.lastWarn = secLeft;
                p.sendActionBar(s.message("warn", "%seconds%", String.valueOf(secLeft)));
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.7f, 1.2f);
            }
        }

        for (UUID id : expired) {
            Session ses = sessions.remove(id);
            if (ses != null) {
                finish(id, Bukkit.getPlayer(id), ses, true);
            }
        }
    }

    // ---------------------------------------------------------------- events

    public void handleQuit(Player p) {
        Session ses = sessions.remove(p.getUniqueId());
        if (ses == null) return;
        startCooldown(p.getUniqueId());
        if (ses.bar != null) p.hideBossBar(ses.bar);
        p.teleport(safeReturn(ses.returnLoc));
    }

    public void handleJoin(Player p) {
        if (!plugin.farmData().isFarmWorld(p.getWorld())) return;
        if (p.hasPermission("farmingplus.bypass.time")) return;
        // masuk server langsung di farm world tanpa sesi -> pindahin keluar
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline() && plugin.farmData().isFarmWorld(p.getWorld()) && !sessions.containsKey(p.getUniqueId())) {
                p.teleport(fallback());
            }
        });
    }

    /** Pemain pindah dari farm world lewat cara lain (/spawn, /home, dll) -> sesi selesai. */
    public void handleWorldChange(Player p, World from) {
        if (!plugin.farmData().isFarmWorld(from)) return;
        Session ses = sessions.remove(p.getUniqueId());
        if (ses == null) return;
        startCooldown(p.getUniqueId());
        if (ses.bar != null) p.hideBossBar(ses.bar);
    }

    public void shutdown() {
        for (Map.Entry<UUID, Session> entry : sessions.entrySet()) {
            Player p = Bukkit.getPlayer(entry.getKey());
            if (p != null && entry.getValue().bar != null) {
                p.hideBossBar(entry.getValue().bar);
            }
        }
        sessions.clear();
    }

    // ---------------------------------------------------------------- internals

    private void finish(UUID id, Player p, Session ses, boolean expired) {
        startCooldown(id);
        if (p == null) return;
        if (ses.bar != null) p.hideBossBar(ses.bar);
        p.teleport(safeReturn(ses.returnLoc));
        p.sendMessage(plugin.settings().message(expired ? "expired" : "left"));
    }

    private void startCooldown(UUID id) {
        int seconds = plugin.settings().cooldownSeconds;
        if (seconds > 0) {
            cooldowns.put(id, System.currentTimeMillis() + seconds * 1000L);
        }
    }

    private Location safeReturn(Location loc) {
        if (loc == null || loc.getWorld() == null || plugin.farmData().isFarmWorld(loc.getWorld())) {
            return fallback();
        }
        return loc;
    }

    private Location fallback() {
        return Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    // ---------------------------------------------------------------- format

    public static String formatLong(long seconds) {
        long h = seconds / 3600L;
        long m = (seconds % 3600L) / 60L;
        long s = seconds % 60L;
        StringBuilder sb = new StringBuilder();
        if (h > 0) sb.append(h).append(" jam ");
        if (m > 0) sb.append(m).append(" menit ");
        if (s > 0 || sb.length() == 0) sb.append(s).append(" detik ");
        return sb.toString().trim();
    }

    public static String formatClock(long millis) {
        long total = (millis + 999L) / 1000L;
        return String.format(Locale.ROOT, "%d:%02d", total / 60L, total % 60L);
    }
}
