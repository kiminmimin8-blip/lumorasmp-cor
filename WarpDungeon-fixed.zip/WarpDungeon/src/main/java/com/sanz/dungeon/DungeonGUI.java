package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class DungeonGUI {

    private final DungeonManager manager;

    public DungeonGUI(DungeonManager manager) {
        this.manager = manager;
    }

    public Inventory build() {
        List<Dungeon> all = new ArrayList<>(manager.getAll());
        all.sort(Comparator.comparing(Dungeon::getId));

        // auto-assign slot buat dungeon yg belum punya slot
        int nextFree = 0;
        List<Integer> usedSlots = all.stream()
                .map(Dungeon::getGuiSlot)
                .filter(s -> s >= 0)
                .toList();

        int maxSlot = 8; // minimal 1 baris
        for (Dungeon d : all) {
            if (d.getGuiSlot() >= 0) {
                maxSlot = Math.max(maxSlot, d.getGuiSlot());
            }
        }
        int size = ((maxSlot / 9) + 1) * 9;
        if (size < 27) size = 27;
        if (size > 54) size = 54;

        DungeonGUIHolder holder = new DungeonGUIHolder();
        Inventory inv = Bukkit.createInventory(holder, size, ChatColor.DARK_PURPLE + "Dungeon");
        holder.setInventory(inv);

        for (Dungeon d : all) {
            int slot = d.getGuiSlot();
            if (slot < 0 || slot >= size || inv.getItem(slot) != null) {
                while (nextFree < size && (inv.getItem(nextFree) != null || usedSlots.contains(nextFree))) nextFree++;
                slot = nextFree;
                if (slot >= size) continue; // GUI penuh
            }

            inv.setItem(slot, buildIcon(d));
            holder.map(slot, d.getId());
        }

        return inv;
    }

    private ItemStack buildIcon(Dungeon d) {
        ItemStack item = new ItemStack(d.getDisplayItem());
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + d.getDisplayName());

        List<String> lore = new ArrayList<>();
        for (String line : d.getDescription()) {
            lore.add(ChatColor.GRAY + line);
        }
        lore.add("");
        if (d.isPremium()) {
            lore.add(ChatColor.GOLD + "Premium - " + d.getPrice() + " " + d.getCurrency() + " / masuk");
        } else {
            lore.add(ChatColor.GREEN + "Gratis");
        }
        if (!d.isRegionSet() || !d.isSpawnSet()) {
            lore.add(ChatColor.RED + "(belum siap - hubungi admin)");
        } else {
            lore.add(ChatColor.YELLOW + "Klik buat teleport");
        }
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }
}
