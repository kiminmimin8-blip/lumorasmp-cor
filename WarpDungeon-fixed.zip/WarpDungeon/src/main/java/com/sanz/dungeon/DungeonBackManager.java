package com.sanz.dungeon;

import org.bukkit.Location;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class DungeonBackManager {

    private static final long WINDOW_MILLIS = 2 * 60 * 1000L; // 2 menit

    private static class ExitRecord {
        final String dungeonId;
        final Location locationBefore; // lokasi player SEBELUM balik ke dungeon (dipulihin kalau back lagi dipakai nanti)
        final long timestamp;

        ExitRecord(String dungeonId, Location locationBefore, long timestamp) {
            this.dungeonId = dungeonId;
            this.locationBefore = locationBefore;
            this.timestamp = timestamp;
        }
    }

    private final Map<UUID, ExitRecord> records = new ConcurrentHashMap<>();
    private final DungeonManager manager;

    public DungeonBackManager(DungeonManager manager) {
        this.manager = manager;
    }

    /** Dipanggil pas player kedeteksi keluar dari region dungeon. */
    public void recordExit(UUID uuid, String dungeonId, Location leftAt) {
        records.put(uuid, new ExitRecord(dungeonId, leftAt, System.currentTimeMillis()));
    }

    /** Cek apakah player ini masih dalam window 2 menit buat /back ke dungeon. */
    public boolean canBackToDungeon(UUID uuid) {
        ExitRecord r = records.get(uuid);
        if (r == null) return false;
        return (System.currentTimeMillis() - r.timestamp) <= WINDOW_MILLIS;
    }

    /** Lokasi spawn dungeon yang mau di-back-in. Null kalau window abis / gak ada record. */
    public Location getBackLocation(UUID uuid) {
        if (!canBackToDungeon(uuid)) return null;
        ExitRecord r = records.get(uuid);
        Dungeon d = manager.get(r.dungeonId);
        return d != null ? d.getSpawnLocation() : null;
    }

    /** Hapus record setelah dipakai / kadaluarsa, biar gak numpuk. */
    public void clear(UUID uuid) {
        records.remove(uuid);
    }
}
