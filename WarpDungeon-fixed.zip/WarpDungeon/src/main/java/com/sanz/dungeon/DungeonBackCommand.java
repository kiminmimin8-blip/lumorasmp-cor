package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * NOTE: kalau SanzCore udah/nanti punya /back sendiri (back ke lokasi mati/teleport biasa),
 * gabungin logic ini di situ: cek dulu canBackToDungeon(), baru fallback ke /back normal.
 * Di sini dibuat berdiri sendiri biar gampang di-tempel.
 */
public class DungeonBackCommand implements CommandExecutor {

    private final DungeonBackManager backManager;

    public DungeonBackCommand(DungeonBackManager backManager) {
        this.backManager = backManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }

        if (!backManager.canBackToDungeon(p.getUniqueId())) {
            p.sendMessage(ChatColor.RED + "Gak ada dungeon buat di-back-in (udah lewat 2 menit atau emang belum pernah keluar dungeon).");
            return true;
        }

        Location backLoc = backManager.getBackLocation(p.getUniqueId());
        if (backLoc == null) {
            p.sendMessage(ChatColor.RED + "Titik spawn dungeon-nya belum diset, gak bisa di-back-in.");
            return true;
        }

        p.teleportAsync(backLoc).thenAccept(success -> {
            if (success) {
                backManager.clear(p.getUniqueId());
                p.sendMessage(ChatColor.GREEN + "Balik ke dungeon.");
            }
        });
        return true;
    }
}
