package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Shop sekarang PER-DUNGEON, dan tiap dungeon bisa punya BANYAK KATEGORI
 * (misal "Armor", "Senjata", "Tukar Fragmen"). Sebelumnya cuma 1 daftar trade
 * global buat semua dungeon - sekarang dungeonId -> DungeonShop -> kategori -> trade.
 */
public class DungeonShopManager {

    private final Plugin plugin;
    private final File file;
    private final Map<String, DungeonShop> shops = new LinkedHashMap<>();

    public DungeonShopManager(Plugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "shop.yml");
        load();
    }

    public Collection<DungeonShop> getAllShops() { return shops.values(); }

    public DungeonShop get(String dungeonId) { return shops.get(dungeonId); }

    /** Kalau dungeon itu belum punya shop sama sekali, otomatis dibikinin 1 kategori "Umum" isi trade contoh. */
    public DungeonShop getOrCreate(String dungeonId) {
        DungeonShop shop = shops.get(dungeonId);
        if (shop == null) {
            shop = new DungeonShop(dungeonId);
            seedDefaults(shop);
            shops.put(dungeonId, shop);
            save();
        }
        return shop;
    }

    /** Reload dari disk - dipanggil dari /dungeon shopreload. Data yg belum di-SIMPAN di GUI akan ilang, tapi itu emang perilaku reload yg wajar. */
    public void reload() {
        load();
    }

    public int countTotalReadyTrades() {
        int total = 0;
        for (DungeonShop shop : shops.values())
            for (ShopCategory cat : shop.getCategoriesRaw().values())
                total += cat.readyCount();
        return total;
    }

    // ======================================================================
    // PERSISTENCE
    // ======================================================================

    public void load() {
        shops.clear();
        if (!file.exists()) return; // dungeon baru bakal auto-seed pas getOrCreate() dipanggil

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection dungeonsSec = yml.getConfigurationSection("dungeons");
        if (dungeonsSec == null) return;

        for (String dungeonId : dungeonsSec.getKeys(false)) {
            DungeonShop shop = new DungeonShop(dungeonId);
            ConfigurationSection catsSec = dungeonsSec.getConfigurationSection(dungeonId + ".categories");
            if (catsSec != null) {
                for (String catId : catsSec.getKeys(false)) {
                    String catBase = "dungeons." + dungeonId + ".categories." + catId + ".";
                    ShopCategory cat = new ShopCategory(catId, yml.getString(catBase + "label", catId));
                    cat.setIcon(yml.getItemStack(catBase + "icon"));
                    cat.setSelectSlot(yml.getInt(catBase + "selectSlot", -1));

                    ConfigurationSection tradesSec = yml.getConfigurationSection(catBase + "trades");
                    if (tradesSec != null) {
                        for (String tradeKey : tradesSec.getKeys(false)) {
                            int tradeId = Integer.parseInt(tradeKey);
                            String tBase = catBase + "trades." + tradeKey + ".";
                            ShopTrade t = new ShopTrade(tradeId);
                            t.setLabel(yml.getString(tBase + "label", "Trade #" + tradeId));
                            t.setSlot(yml.getInt(tBase + "slot", tradeId));
                            t.setInput1(yml.getItemStack(tBase + "input1"));
                            t.setInput2(yml.getItemStack(tBase + "input2"));
                            t.setOutputType(ShopTrade.OutputType.valueOf(yml.getString(tBase + "outputType", "MONEY")));
                            t.setOutputMoney(yml.getDouble(tBase + "outputMoney", 0));
                            t.setOutputCurrency(yml.getString(tBase + "outputCurrency", "money"));
                            t.setOutput(yml.getItemStack(tBase + "output"));
                            cat.putLoadedTrade(t);
                        }
                    }
                    shop.putLoadedCategory(cat);
                }
            }
            shops.put(dungeonId, shop);
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (DungeonShop shop : shops.values()) {
            String dBase = "dungeons." + shop.getDungeonId() + ".categories.";
            for (ShopCategory cat : shop.getCategoriesRaw().values()) {
                String catBase = dBase + cat.getId() + ".";
                yml.set(catBase + "label", cat.getLabel());
                yml.set(catBase + "icon", cat.getIcon());
                yml.set(catBase + "selectSlot", cat.getSelectSlot());

                for (ShopTrade t : cat.getTradesRaw().values()) {
                    String tBase = catBase + "trades." + t.getId() + ".";
                    yml.set(tBase + "label", t.getLabel());
                    yml.set(tBase + "slot", t.getSlot());
                    yml.set(tBase + "input1", t.getInput1());
                    yml.set(tBase + "input2", t.getInput2());
                    yml.set(tBase + "outputType", t.getOutputType().name());
                    yml.set(tBase + "outputMoney", t.getOutputMoney());
                    yml.set(tBase + "outputCurrency", t.getOutputCurrency());
                    yml.set(tBase + "output", t.getOutput());
                }
            }
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal save shop.yml: " + e.getMessage());
        }
    }

    // ======================================================================
    // SEED DEFAULT - dibuat 1x doang pas 1 dungeon belum pernah punya shop
    // sama sekali (pertama kali /dungeon shop atau /dungeon shopedit dipake
    // di dungeon itu). Diisi kategori "Umum" isi trade CONTOH pake item
    // vanilla mirip-mirip drop MythicMobs (nama/lore/model data disamain ke
    // item asli yg lagi dipake shopkeeper), tinggal diganti admin lewat
    // /dungeon shopedit -> taro item /mm item give asli -> SIMPAN.
    // ======================================================================

    private void seedDefaults(DungeonShop shop) {
        ItemStack tanahRelic = mmCurrency(Material.CLAY_BALL, 1,
                ChatColor.DARK_GREEN, true, "✦ Fragmen Relik Tanah", 30001, "TanahRelicFragment",
                ChatColor.GRAY + "Serpihan tanah purba dari tubuh",
                ChatColor.DARK_GREEN + "Penjaga Tanah Tua",
                ChatColor.RED + "[CONTOH - ganti pake item MythicMobs asli]");

        ItemStack intiBara = mmCurrency(Material.BLAZE_POWDER, 1,
                ChatColor.GOLD, true, "✦ Inti Bara Nyala", 30002, "BaraCoreEssence",
                ChatColor.GRAY + "Bubuk api yang masih membara,",
                ChatColor.GRAY + "diambil dari " + ChatColor.GOLD + "Pemburu Bara Nyala",
                ChatColor.RED + "[CONTOH - ganti pake item MythicMobs asli]");

        ItemStack debuAbyssal = mmCurrency(Material.GUNPOWDER, 1,
                ChatColor.GRAY, false, "✦ Debu Abyssal Crawler", 30038, "AbyssalCrawlerDust",
                ChatColor.GRAY + "Debu gelap yang tersisa dari",
                ChatColor.GRAY + "Abyssal Crawler.",
                ChatColor.RED + "[CONTOH - ganti pake item MythicMobs asli]");

        ItemStack kelenjarRacun = mmCurrency(Material.SPIDER_EYE, 1,
                ChatColor.DARK_GREEN, true, "✦ Kelenjar Racun Purba", 30004, "RacunKelenjarPurba",
                ChatColor.GRAY + "Kelenjar racun mematikan milik",
                ChatColor.DARK_GREEN + "Induk Racun Purba",
                ChatColor.RED + "[CONTOH - ganti pake item MythicMobs asli]");
        ItemMeta krMeta = kelenjarRacun.getItemMeta();
        krMeta.setUnbreakable(true);
        kelenjarRacun.setItemMeta(krMeta);

        ShopCategory umum = shop.createCategory("Umum");
        umum.setIcon(withAmount(tanahRelic, 1));

        addSimple(umum, "Tukar Fragmen Relik Tanah -> Arrow", withAmount(tanahRelic, 4), null, new ItemStack(Material.ARROW, 5));
        addSimple(umum, "Tukar Fragmen Relik Tanah -> Door", withAmount(tanahRelic, 4), null, new ItemStack(Material.OAK_DOOR, 1));
        addSimple(umum, "Tukar Fragmen Relik Tanah -> Hay Bale", withAmount(tanahRelic, 4), null, new ItemStack(Material.HAY_BLOCK, 1));
        addSimple(umum, "Tukar jadi Golden Carrot", withAmount(tanahRelic, 10), withAmount(intiBara, 2), new ItemStack(Material.GOLDEN_CARROT, 5));
        addSimple(umum, "Tukar jadi Wind Charge", withAmount(tanahRelic, 10), withAmount(debuAbyssal, 2), new ItemStack(Material.WIND_CHARGE, 1));
        addSimple(umum, "Tukar jadi Diamond", withAmount(intiBara, 8), withAmount(debuAbyssal, 2), new ItemStack(Material.DIAMOND, 1));
        addSimple(umum, "Tukar jadi Kelenjar Racun Purba", withAmount(intiBara, 10), withAmount(debuAbyssal, 8), withAmount(kelenjarRacun, 3));

        ShopCategory armor = shop.createCategory("Armor");
        armor.setIcon(fullEnchantDiamond(Material.DIAMOND_HELMET, "Helm Legenda"));
        addSimple(armor, "[ARMOR] Diamond Helmet (Full Enchant)", withAmount(kelenjarRacun, 5), null, fullEnchantDiamond(Material.DIAMOND_HELMET, "Helm Legenda"));
        addSimple(armor, "[ARMOR] Diamond Chestplate (Full Enchant)", withAmount(kelenjarRacun, 6), null, fullEnchantDiamond(Material.DIAMOND_CHESTPLATE, "Zirah Legenda"));
        addSimple(armor, "[ARMOR] Diamond Leggings (Full Enchant)", withAmount(kelenjarRacun, 6), null, fullEnchantDiamond(Material.DIAMOND_LEGGINGS, "Celana Legenda"));
        addSimple(armor, "[ARMOR] Diamond Boots (Full Enchant)", withAmount(kelenjarRacun, 5), null, fullEnchantDiamond(Material.DIAMOND_BOOTS, "Sepatu Legenda"));
    }

    private void addSimple(ShopCategory cat, String label, ItemStack in1, ItemStack in2, ItemStack out) {
        ShopTrade t = cat.createTrade();
        t.setLabel(label);
        t.setInput1(in1);
        t.setInput2(in2);
        t.setOutputType(ShopTrade.OutputType.ITEM);
        t.setOutput(out);
    }

    private ItemStack withAmount(ItemStack base, int amount) {
        ItemStack copy = base.clone();
        copy.setAmount(amount);
        return copy;
    }

    /** Item currency ala drop MythicMobs: custom name, lore, custom model data, PDC mythicmobs:type. */
    private ItemStack mmCurrency(Material material, int amount, ChatColor nameColor, boolean bold, String name,
                                  int customModelData, String mmType, String loreLine1, String loreLine2, String loreWarn) {
        ItemStack item = new ItemStack(material, amount);
        ItemMeta meta = item.getItemMeta();

        String prefix = bold ? ChatColor.BOLD.toString() : "";
        meta.setDisplayName(nameColor.toString() + prefix + name);

        List<String> lore = new ArrayList<>();
        lore.add(loreLine1);
        lore.add(loreLine2);
        lore.add("");
        lore.add(ChatColor.YELLOW + "" + ChatColor.ITALIC + "Tukarkan barang ini ke Shopkeeper!");
        lore.add(loreWarn);
        meta.setLore(lore);

        meta.setCustomModelData(customModelData);

        meta.getPersistentDataContainer().set(new NamespacedKey("mythicmobs", "type"), PersistentDataType.STRING, mmType);
        meta.getPersistentDataContainer().set(new NamespacedKey("mythicmobs", "prevent_crafting_with"), PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(new NamespacedKey("mythicmobs", "prevent_repairing_with"), PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(new NamespacedKey("mythicmobs", "prevent_smithing_with"), PersistentDataType.BYTE, (byte) 1);

        item.setItemMeta(meta);
        return item;
    }

    private ItemStack fullEnchantDiamond(Material armorPiece, String displayName) {
        ItemStack item = new ItemStack(armorPiece, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + "" + ChatColor.BOLD + displayName);
        meta.setLore(List.of(ChatColor.GRAY + "Hasil tukar dungeon shop"));

        meta.addEnchant(org.bukkit.enchantments.Enchantment.PROTECTION, 4, true);
        meta.addEnchant(org.bukkit.enchantments.Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(org.bukkit.enchantments.Enchantment.MENDING, 1, true);

        if (armorPiece == Material.DIAMOND_HELMET) {
            meta.addEnchant(org.bukkit.enchantments.Enchantment.RESPIRATION, 3, true);
            meta.addEnchant(org.bukkit.enchantments.Enchantment.AQUA_AFFINITY, 1, true);
        } else if (armorPiece == Material.DIAMOND_BOOTS) {
            meta.addEnchant(org.bukkit.enchantments.Enchantment.FEATHER_FALLING, 4, true);
            meta.addEnchant(org.bukkit.enchantments.Enchantment.DEPTH_STRIDER, 3, true);
        } else if (armorPiece == Material.DIAMOND_LEGGINGS) {
            meta.addEnchant(org.bukkit.enchantments.Enchantment.SWIFT_SNEAK, 3, true);
        }

        item.setItemMeta(meta);
        return item;
    }
}
