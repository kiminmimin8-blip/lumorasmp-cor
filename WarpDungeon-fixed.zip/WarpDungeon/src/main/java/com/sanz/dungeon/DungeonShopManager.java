package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class DungeonShopManager {

    private final Plugin plugin;
    private final File file;
    private final Map<Integer, ShopTrade> trades = new LinkedHashMap<>();
    private int nextId = 1;

    public DungeonShopManager(Plugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "shop.yml");
        load();
    }

    public Collection<ShopTrade> getAll() { return trades.values(); }
    public ShopTrade get(int id) { return trades.get(id); }

    /** Bikin trade kosong (belum siap dipajang sampai di-setting lewat GUI). */
    public ShopTrade create() {
        ShopTrade t = new ShopTrade(nextId++);
        trades.put(t.getId(), t);
        save();
        return t;
    }

    public boolean remove(int id) {
        boolean removed = trades.remove(id) != null;
        if (removed) save();
        return removed;
    }

    public void load() {
        trades.clear();
        nextId = 1;

        if (!file.exists()) {
            // fresh install - isi shop dengan trade contoh (samain kayak Shopkeeper
            // villager admin yg udah jalan di server + tambahan armor full-enchant)
            seedDefaults();
            save();
            return;
        }

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        if (yml.getConfigurationSection("trades") == null) return;

        for (String key : yml.getConfigurationSection("trades").getKeys(false)) {
            int id = Integer.parseInt(key);
            String base = "trades." + key + ".";
            ShopTrade t = new ShopTrade(id);
            t.setLabel(yml.getString(base + "label", "Trade #" + id));

            t.setInput1(yml.getItemStack(base + "input1"));
            t.setInput2(yml.getItemStack(base + "input2"));

            ShopTrade.OutputType type = ShopTrade.OutputType.valueOf(yml.getString(base + "outputType", "MONEY"));
            t.setOutputType(type);
            t.setOutputMoney(yml.getDouble(base + "outputMoney", 0));
            t.setOutputCurrency(yml.getString(base + "outputCurrency", "money"));
            t.setOutput(yml.getItemStack(base + "output"));

            trades.put(id, t);
            nextId = Math.max(nextId, id + 1);
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (ShopTrade t : trades.values()) {
            String base = "trades." + t.getId() + ".";
            yml.set(base + "label", t.getLabel());
            yml.set(base + "input1", t.getInput1());
            yml.set(base + "input2", t.getInput2());
            yml.set(base + "outputType", t.getOutputType().name());
            yml.set(base + "outputMoney", t.getOutputMoney());
            yml.set(base + "outputCurrency", t.getOutputCurrency());
            yml.set(base + "output", t.getOutput());
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal save shop.yml: " + e.getMessage());
        }
    }

    // ======================================================================
    // SEED DEFAULT - dibuat 1x doang pas shop.yml belum ada sama sekali.
    // Urutan & tampilan disamain kayak GUI Shopkeeper villager admin yang
    // udah jalan (item1/item2 -> resultItem), plus trade tambahan armor
    // diamond full-enchant di paling akhir (respiration 3, unbreaking 3,
    // mending, aqua affinity - contoh persis yang diminta).
    //
    // Item mata uang di sini (Fragmen Relik Tanah / Inti Bara Nyala / Debu
    // Abyssal Crawler / Kelenjar Racun Purba) dibikin cocok byte-per-byte
    // sama drop asli MythicMobs (custom model data + PDC mythicmobs:type),
    // jadi item hasil drop mob beneran otomatis kebaca valid di sini. Tetep
    // bisa diedit ulang kapan aja lewat /dungeon shopedit in-game.
    // ======================================================================

    private void seedDefaults() {
        ItemStack tanahRelic = mmCurrency(Material.CLAY_BALL, 1,
                ChatColor.DARK_GREEN, true, "✦ Fragmen Relik Tanah", 30001, "TanahRelicFragment",
                ChatColor.GRAY + "Serpihan tanah purba dari tubuh",
                ChatColor.DARK_GREEN + "Penjaga Tanah Tua");

        ItemStack intiBara = mmCurrency(Material.BLAZE_POWDER, 1,
                ChatColor.GOLD, true, "✦ Inti Bara Nyala", 30002, "BaraCoreEssence",
                ChatColor.GRAY + "Bubuk api yang masih membara,",
                ChatColor.GRAY + "diambil dari " + ChatColor.GOLD + "Pemburu Bara Nyala");

        ItemStack debuAbyssal = mmCurrency(Material.GUNPOWDER, 1,
                ChatColor.GRAY, false, "✦ Debu Abyssal Crawler", 30038, "AbyssalCrawlerDust",
                ChatColor.GRAY + "Debu gelap yang tersisa dari",
                ChatColor.GRAY + "Abyssal Crawler.");

        ItemStack kelenjarRacun = mmCurrency(Material.SPIDER_EYE, 1,
                ChatColor.DARK_GREEN, true, "✦ Kelenjar Racun Purba", 30004, "RacunKelenjarPurba",
                ChatColor.GRAY + "Kelenjar racun mematikan milik",
                ChatColor.DARK_GREEN + "Induk Racun Purba");
        ItemMeta krMeta = kelenjarRacun.getItemMeta();
        krMeta.setUnbreakable(true);
        kelenjarRacun.setItemMeta(krMeta);

        // trade 1-4 : Fragmen Relik Tanah doang (item2 kosong)
        addSimple("Tukar Fragmen Relik Tanah -> Arrow", withAmount(tanahRelic, 4), null, new ItemStack(Material.ARROW, 5));
        addSimple("Tukar Fragmen Relik Tanah -> Door", withAmount(tanahRelic, 4), null, new ItemStack(Material.OAK_DOOR, 1));
        addSimple("Tukar Fragmen Relik Tanah -> Hay Bale", withAmount(tanahRelic, 4), null, new ItemStack(Material.HAY_BLOCK, 1));

        // trade 5 : Fragmen Relik Tanah + Inti Bara Nyala -> Golden Carrot
        addSimple("Tukar jadi Golden Carrot", withAmount(tanahRelic, 10), withAmount(intiBara, 2), new ItemStack(Material.GOLDEN_CARROT, 5));

        // trade 6 : Fragmen Relik Tanah + Debu Abyssal Crawler -> Wind Charge
        addSimple("Tukar jadi Wind Charge", withAmount(tanahRelic, 10), withAmount(debuAbyssal, 2), new ItemStack(Material.WIND_CHARGE, 1));

        // trade 7 : Inti Bara Nyala + Debu Abyssal Crawler -> Diamond
        addSimple("Tukar jadi Diamond", withAmount(intiBara, 8), withAmount(debuAbyssal, 2), new ItemStack(Material.DIAMOND, 1));

        // trade 8 : Inti Bara Nyala + Debu Abyssal Crawler (lebih banyak) -> Kelenjar Racun Purba
        addSimple("Tukar jadi Kelenjar Racun Purba", withAmount(intiBara, 10), withAmount(debuAbyssal, 8), withAmount(kelenjarRacun, 3));

        // ---------- Trade tambahan: armor DIAMOND full-enchant ----------
        // Contoh sesuai request: helmet respiration 3, unbreaking 3, mending, aqua affinity.
        // Harga pake mata uang tertinggi (Kelenjar Racun Purba) biar sepadan sama kualitas gear-nya.
        addSimple("[ARMOR] Diamond Helmet (Full Enchant)",
                withAmount(kelenjarRacun, 5), null, fullEnchantDiamond(Material.DIAMOND_HELMET, "Helm Legenda"));
        addSimple("[ARMOR] Diamond Chestplate (Full Enchant)",
                withAmount(kelenjarRacun, 6), null, fullEnchantDiamond(Material.DIAMOND_CHESTPLATE, "Zirah Legenda"));
        addSimple("[ARMOR] Diamond Leggings (Full Enchant)",
                withAmount(kelenjarRacun, 6), null, fullEnchantDiamond(Material.DIAMOND_LEGGINGS, "Celana Legenda"));
        addSimple("[ARMOR] Diamond Boots (Full Enchant)",
                withAmount(kelenjarRacun, 5), null, fullEnchantDiamond(Material.DIAMOND_BOOTS, "Sepatu Legenda"));
    }

    private void addSimple(String label, ItemStack in1, ItemStack in2, ItemStack out) {
        ShopTrade t = new ShopTrade(nextId++);
        t.setLabel(label);
        t.setInput1(in1);
        t.setInput2(in2);
        t.setOutputType(ShopTrade.OutputType.ITEM);
        t.setOutput(out);
        trades.put(t.getId(), t);
    }

    private ItemStack withAmount(ItemStack base, int amount) {
        ItemStack copy = base.clone();
        copy.setAmount(amount);
        return copy;
    }

    /** Item currency ala drop MythicMobs: custom name, 2 baris lore + footer standar, custom model data, PDC mythicmobs:type. */
    private ItemStack mmCurrency(Material material, int amount, ChatColor nameColor, boolean bold, String name,
                                  int customModelData, String mmType, String loreLine1, String loreLine2) {
        ItemStack item = new ItemStack(material, amount);
        ItemMeta meta = item.getItemMeta();

        String prefix = bold ? ChatColor.BOLD.toString() : "";
        meta.setDisplayName(nameColor.toString() + prefix + name);

        List<String> lore = new ArrayList<>();
        lore.add(loreLine1);
        lore.add(loreLine2);
        lore.add("");
        lore.add(ChatColor.YELLOW + "" + ChatColor.ITALIC + "Tukarkan barang ini ke Shopkeeper!");
        meta.setLore(lore);

        meta.setCustomModelData(customModelData);

        meta.getPersistentDataContainer().set(NamespacedKey.fromString("mythicmobs:type"), PersistentDataType.STRING, mmType);
        meta.getPersistentDataContainer().set(NamespacedKey.fromString("mythicmobs:prevent_crafting_with"), PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(NamespacedKey.fromString("mythicmobs:prevent_repairing_with"), PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(NamespacedKey.fromString("mythicmobs:prevent_smithing_with"), PersistentDataType.BYTE, (byte) 1);

        item.setItemMeta(meta);
        return item;
    }

    private ItemStack fullEnchantDiamond(Material armorPiece, String displayName) {
        ItemStack item = new ItemStack(armorPiece, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + "" + ChatColor.BOLD + displayName);
        meta.setLore(List.of(ChatColor.GRAY + "Hasil tukar dungeon shop"));

        meta.addEnchant(org.bukkit.enchantments.Enchantment.PROTECTION, 4, true);
        meta.addEnchant(org.bukkit.enchantments.Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(org.bukkit.enchantments.Enchantment.MENDING, 1, true);

        if (armorPiece == Material.DIAMOND_HELMET) {
            meta.addEnchant(org.bukkit.enchantments.Enchantment.RESPIRATION, 3, true);
            meta.addEnchant(org.bukkit.enchantments.Enchantment.AQUA_AFFINITY, 1, true);
        } else if (armorPiece == Material.DIAMOND_BOOTS) {
            meta.addEnchant(org.bukkit.enchantments.Enchantment.FEATHER_FALLING, 4, true);
            meta.addEnchant(org.bukkit.enchantments.Enchantment.DEPTH_STRIDER, 3, true);
        } else if (armorPiece == Material.DIAMOND_LEGGINGS) {
            meta.addEnchant(org.bukkit.enchantments.Enchantment.SWIFT_SNEAK, 3, true);
        }

        item.setItemMeta(meta);
        return item;
    }
}
