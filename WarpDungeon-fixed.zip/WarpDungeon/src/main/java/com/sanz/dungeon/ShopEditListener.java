package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ShopEditListener implements Listener {

    private static final List<String> CURRENCIES = List.of("money", "cash", "shards");

    private final DungeonShopManager shopManager;
    private final ShopEditGUI editGUI;
    private final ShopEditSession session;
    private final Map<UUID, Integer> pendingDelete = new ConcurrentHashMap<>();

    public ShopEditListener(DungeonShopManager shopManager, ShopEditGUI editGUI, ShopEditSession session) {
        this.shopManager = shopManager;
        this.editGUI = editGUI;
        this.session = session;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof ShopEditHolder holder)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;

        // klik di inventory player sendiri (bawah) dibiarin normal
        if (e.getClickedInventory() != null && !e.getClickedInventory().equals(e.getView().getTopInventory())) {
            return;
        }

        int slot = e.getRawSlot();

        boolean editableSlot = holder.getMode() == ShopEditHolder.Mode.DETAIL
                && (slot == ShopEditHolder.INPUT_SLOT
                    || slot == ShopEditHolder.INPUT2_SLOT
                    || (slot == ShopEditHolder.OUTPUT_SLOT && !"noop".equals(holder.getAction(slot))));

        if (editableSlot) {
            // slot editable beneran - biarin player taro/ambil item, gak di-cancel
            return;
        }

        e.setCancelled(true);
        String action = holder.getAction(slot);
        if (action == null) return;

        if (holder.getMode() == ShopEditHolder.Mode.LIST) {
            handleListClick(p, action);
            return;
        }

        handleDetailClick(p, holder, action);
    }

    private void handleListClick(Player p, String action) {
        if (action.equals("create")) {
            ShopTrade t = shopManager.create();
            p.openInventory(editGUI.buildDetail(t));
            return;
        }
        if (action.startsWith("open:")) {
            int id = Integer.parseInt(action.substring("open:".length()));
            ShopTrade t = shopManager.get(id);
            if (t != null) p.openInventory(editGUI.buildDetail(t));
        }
    }

    private void handleDetailClick(Player p, ShopEditHolder holder, String action) {
        ShopTrade t = shopManager.get(holder.getTradeId());
        if (t == null) { p.closeInventory(); return; }

        switch (action) {
            case "toggle_mode" -> {
                t.setOutputType(t.getOutputType() == ShopTrade.OutputType.ITEM ? ShopTrade.OutputType.MONEY : ShopTrade.OutputType.ITEM);
                p.openInventory(editGUI.buildDetail(t));
            }
            case "cycle_currency" -> {
                int idx = CURRENCIES.indexOf(t.getOutputCurrency().toLowerCase());
                t.setOutputCurrency(CURRENCIES.get((idx + 1) % CURRENCIES.size()));
                p.openInventory(editGUI.buildDetail(t));
            }
            case "rename" -> {
                p.closeInventory();
                session.awaitRename(p.getUniqueId(), t.getId());
                p.sendMessage(ChatColor.YELLOW + "Ketik nama trade baru di chat:");
            }
            case "save" -> {
                // ambil item PERSIS (termasuk enchant/nama/lore/NBT) yg ditaro
                // di slot input1/input2/output pas SIMPAN diklik
                ItemStack input1 = p.getOpenInventory().getTopInventory().getItem(ShopEditHolder.INPUT_SLOT);
                t.setInput1(clone(input1));

                ItemStack input2 = p.getOpenInventory().getTopInventory().getItem(ShopEditHolder.INPUT2_SLOT);
                t.setInput2(clone(input2));

                if (t.getOutputType() == ShopTrade.OutputType.ITEM) {
                    ItemStack output = p.getOpenInventory().getTopInventory().getItem(ShopEditHolder.OUTPUT_SLOT);
                    t.setOutput(clone(output));
                }

                shopManager.save();
                if (t.isReady()) {
                    p.sendMessage(ChatColor.GREEN + "Trade tersimpan & langsung tampil di /dungeon shop.");
                } else {
                    p.sendMessage(ChatColor.YELLOW + "Tersimpan, tapi masih belum lengkap jadi belum tampil di /dungeon shop.");
                }
                p.openInventory(editGUI.buildList());
            }
            case "delete" -> {
                if (Integer.valueOf(t.getId()).equals(pendingDelete.get(p.getUniqueId()))) {
                    shopManager.remove(t.getId());
                    pendingDelete.remove(p.getUniqueId());
                    p.sendMessage(ChatColor.RED + "Trade dihapus.");
                    p.openInventory(editGUI.buildList());
                } else {
                    pendingDelete.put(p.getUniqueId(), t.getId());
                    p.sendMessage(ChatColor.RED + "Klik lagi buat konfirmasi hapus.");
                }
            }
            case "back" -> p.openInventory(editGUI.buildList());
            default -> {
                if (action.startsWith("money:")) {
                    double delta = Double.parseDouble(action.substring("money:".length()));
                    t.setOutputMoney(t.getOutputMoney() + delta);
                    p.openInventory(editGUI.buildDetail(t));
                }
            }
        }
    }

    private ItemStack clone(ItemStack item) {
        return (item == null || item.getType() == Material.AIR) ? null : item.clone();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        Integer tradeId = session.get(p.getUniqueId());
        if (tradeId == null) return;

        e.setCancelled(true);
        String msg = e.getMessage().trim();
        session.clear(p.getUniqueId());

        p.getScheduler().run(
                org.bukkit.Bukkit.getPluginManager().getPlugin("WarpDungeon"),
                (task) -> {
                    ShopTrade t = shopManager.get(tradeId);
                    if (t == null) return;
                    t.setLabel(msg);
                    shopManager.save();
                    p.sendMessage(ChatColor.GREEN + "Nama trade diubah.");
                    p.openInventory(editGUI.buildDetail(t));
                },
                null
        );
    }
}
