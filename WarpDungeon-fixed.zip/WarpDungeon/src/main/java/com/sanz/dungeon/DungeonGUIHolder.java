package com.sanz.dungeon;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;

public class DungeonGUIHolder implements InventoryHolder {

    private final Map<Integer, String> slotToDungeonId = new HashMap<>();
    private Inventory inventory;

    public void setInventory(Inventory inventory) { this.inventory = inventory; }

    @Override
    public Inventory getInventory() { return inventory; }

    public void map(int slot, String dungeonId) { slotToDungeonId.put(slot, dungeonId); }

    public String getDungeonId(int slot) { return slotToDungeonId.get(slot); }
}
