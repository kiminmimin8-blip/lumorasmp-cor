package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class DungeonGUIListener implements Listener {

    private final DungeonManager manager;
    private final DungeonCurrencyProvider currency;

    public DungeonGUIListener(DungeonManager manager, DungeonCurrencyProvider currency) {
        this.manager = manager;
        this.currency = currency;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof DungeonGUIHolder holder)) return;
        e.setCancelled(true);

        if (!(e.getWhoClicked() instanceof Player p)) return;
        String dungeonId = holder.getDungeonId(e.getRawSlot());
        if (dungeonId == null) return;

        Dungeon d = manager.get(dungeonId);
        if (d == null) return;

        if (!d.isRegionSet() || !d.isSpawnSet()) {
            p.sendMessage(ChatColor.RED + "Dungeon ini belum siap.");
            return;
        }

        boolean freeAccess = p.isOp() || p.hasPermission("dungeon.free") || !d.isPremium();

        if (!freeAccess) {
            if (!currency.has(p, d.getCurrency(), d.getPrice())) {
                p.sendMessage(ChatColor.RED + "Uang kamu gak cukup. Butuh " + currency.format(d.getCurrency(), d.getPrice()) + ".");
                return;
            }
            if (!currency.withdraw(p, d.getCurrency(), d.getPrice())) {
                p.sendMessage(ChatColor.RED + "Gagal charge tiket, coba lagi.");
                return;
            }
            p.sendMessage(ChatColor.GREEN + "Tiket " + currency.format(d.getCurrency(), d.getPrice()) + " kepotong.");
        }

        p.closeInventory();
        p.teleportAsync(d.getSpawnLocation()).thenAccept(success -> {
            if (success) p.sendMessage(ChatColor.GREEN + "Teleport ke dungeon " + d.getDisplayName() + ".");
        });
    }
}
