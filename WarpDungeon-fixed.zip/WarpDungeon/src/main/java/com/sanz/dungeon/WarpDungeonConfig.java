package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Bungkus config.yml - semua yang sebelumnya ke-hardcode di kode Java
 * (waktu dungeon, setting world border, proteksi mana yang nyala, daftar
 * command yang diblokir, currency shop, pesan-pesan) sekarang diambil dari
 * sini, jadi bisa diedit lewat panel tanpa compile ulang.
 */
public class WarpDungeonConfig {

    private final Plugin plugin;

    private long dungeonTime;

    private int borderWarningDistance;
    private int borderWarningTime;
    private double borderDamageAmount;
    private double borderDamageBuffer;

    private boolean protectBlockBreak;
    private boolean protectBlockPlace;
    private boolean allowPvp;
    private boolean protectExplosion;
    private boolean blockEnderpearl;
    private boolean blockElytra;
    private boolean blockFirework;
    private boolean onlyMythicMobsSpawn;

    private Set<String> blockedCommands;
    private Set<String> blockedTeamSubcommands;
    private List<String> shopCurrencies;

    private String msgCommandBlocked;
    private String msgNoPermission;
    private String msgShopNotInDungeon;
    private String msgShopEmpty;

    public WarpDungeonConfig(Plugin plugin) {
        this.plugin = plugin;
        plugin.saveDefaultConfig();
        load();
    }

    /** Dipanggil dari /dungeon reload - baca ulang config.yml dari disk. */
    public void reload() {
        plugin.reloadConfig();
        load();
    }

    private void load() {
        FileConfiguration c = plugin.getConfig();

        dungeonTime = c.getLong("dungeon-time", 1000L);

        borderWarningDistance = c.getInt("world-border.warning-distance", 0);
        borderWarningTime = c.getInt("world-border.warning-time", 0);
        borderDamageAmount = c.getDouble("world-border.damage-amount", 0.0);
        borderDamageBuffer = c.getDouble("world-border.damage-buffer", 0.0);

        protectBlockBreak = c.getBoolean("protection.block-break", true);
        protectBlockPlace = c.getBoolean("protection.block-place", true);
        allowPvp = c.getBoolean("protection.allow-pvp", false);
        protectExplosion = c.getBoolean("protection.explosion-damage-block", true);
        blockEnderpearl = c.getBoolean("protection.block-enderpearl", true);
        blockElytra = c.getBoolean("protection.block-elytra", true);
        blockFirework = c.getBoolean("protection.block-firework", true);
        onlyMythicMobsSpawn = c.getBoolean("protection.only-mythicmobs-spawn", true);

        blockedCommands = lowerSet(c.getStringList("blocked-commands"));
        blockedTeamSubcommands = lowerSet(c.getStringList("blocked-team-subcommands"));

        shopCurrencies = c.getStringList("shop-currencies").stream()
                .map(String::toLowerCase)
                .collect(Collectors.toList());
        if (shopCurrencies.isEmpty()) shopCurrencies = List.of("money");

        msgCommandBlocked = color(c.getString("messages.command-blocked", "&cCommand itu gak bisa dipakai di dalam dungeon."));
        msgNoPermission = color(c.getString("messages.no-permission", "&cKamu gak punya izin buat command ini."));
        msgShopNotInDungeon = color(c.getString("messages.shop-not-in-dungeon", "&cKamu harus di dalam dungeon dulu buat buka shopnya."));
        msgShopEmpty = color(c.getString("messages.shop-empty", "&cDungeon ini belum ada shop-nya."));
    }

    private Set<String> lowerSet(List<String> raw) {
        return new HashSet<>(raw.stream().map(String::toLowerCase).collect(Collectors.toList()));
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    public long getDungeonTime() { return dungeonTime; }

    public int getBorderWarningDistance() { return borderWarningDistance; }
    public int getBorderWarningTime() { return borderWarningTime; }
    public double getBorderDamageAmount() { return borderDamageAmount; }
    public double getBorderDamageBuffer() { return borderDamageBuffer; }

    public boolean isProtectBlockBreak() { return protectBlockBreak; }
    public boolean isProtectBlockPlace() { return protectBlockPlace; }
    public boolean isAllowPvp() { return allowPvp; }
    public boolean isProtectExplosion() { return protectExplosion; }
    public boolean isBlockEnderpearl() { return blockEnderpearl; }
    public boolean isBlockElytra() { return blockElytra; }
    public boolean isBlockFirework() { return blockFirework; }
    public boolean isOnlyMythicMobsSpawn() { return onlyMythicMobsSpawn; }

    public Set<String> getBlockedCommands() { return blockedCommands; }
    public Set<String> getBlockedTeamSubcommands() { return blockedTeamSubcommands; }
    public List<String> getShopCurrencies() { return shopCurrencies; }

    public String getMsgCommandBlocked() { return msgCommandBlocked; }
    public String getMsgNoPermission() { return msgNoPermission; }
    public String getMsgShopNotInDungeon() { return msgShopNotInDungeon; }
    public String getMsgShopEmpty() { return msgShopEmpty; }
}
