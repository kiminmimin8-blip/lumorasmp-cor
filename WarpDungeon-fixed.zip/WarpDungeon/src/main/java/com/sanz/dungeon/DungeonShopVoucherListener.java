package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Merchant;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.plugin.Plugin;

/**
 * Item trade (ITEM output) sekarang ditangani otomatis sama vanilla trading
 * (Merchant API di DungeonShopGUI) - ingredient kepotong & hasil dikasih
 * sendiri sama client/server, gak perlu listener manual lagi.
 *
 * Listener ini cuma nangkep 1 kasus sisa: trade mode MONEY, yang hasilnya
 * berupa item "voucher" kertas (lihat DungeonShopGUI#buildVoucher). Begitu
 * player ngeklik slot hasil di window trading & dapet voucher itu, listener
 * ini nukerin vouchernya jadi saldo asli sedetik kemudian.
 */
public class DungeonShopVoucherListener implements Listener {

    private final DungeonCurrencyProvider currency;
    private final Plugin plugin;

    public DungeonShopVoucherListener(DungeonCurrencyProvider currency, Plugin plugin) {
        this.currency = currency;
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onMerchantClick(InventoryClickEvent e) {
        if (e.isCancelled()) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!(e.getInventory().getHolder() instanceof Merchant)) return;

        // slot 2 = slot HASIL di window trading vanilla (0 & 1 itu slot bahan)
        if (e.getRawSlot() != 2) return;

        // tunggu 1 tick, biar item vouchernya beneran udah masuk inventory/cursor
        // player dulu (server ngasih hasil trade setelah event ini kelar diproses).
        p.getScheduler().runDelayed(plugin, (task) -> redeemVouchers(p), null, 1L);
    }

    private void redeemVouchers(Player p) {
        double totalByCurrency = 0;
        String currencyName = null;
        int redeemedCount = 0;

        // Dikumpulin dulu SLOT-nya doang, item-nya belum dihapus - baru
        // dihapus abis deposit() dipastiin berhasil. Sebelumnya item
        // vouchernya langsung dihapus duluan sebelum ngecek hasil deposit,
        // jadi kalau deposit gagal (misal currency belum kesambung), player
        // kehilangan vouchernya tapi gak dapet saldo apa-apa.
        java.util.List<Integer> slotsToClear = new java.util.ArrayList<>();
        boolean cursorIsVoucher = false;

        ItemStack[] contents = p.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (item == null || item.getType() != Material.PAPER || !item.hasItemMeta()) continue;

            ItemMeta meta = item.getItemMeta();
            PersistentDataContainer pdc = meta.getPersistentDataContainer();
            if (!pdc.has(DungeonShopGUI.VOUCHER_KEY, org.bukkit.persistence.PersistentDataType.BYTE)) continue;

            Double amount = pdc.get(DungeonShopGUI.VOUCHER_AMOUNT_KEY, org.bukkit.persistence.PersistentDataType.DOUBLE);
            String curr = pdc.get(DungeonShopGUI.VOUCHER_CURRENCY_KEY, org.bukkit.persistence.PersistentDataType.STRING);
            if (amount == null || curr == null) continue;

            currencyName = curr;
            totalByCurrency += amount * item.getAmount();
            redeemedCount += item.getAmount();
            slotsToClear.add(i);
        }

        // cursor item (lagi dipegang/dragged) juga dicek, kadang hasil trade
        // nyangkut di sini kalau slot inventory pas lagi penuh pas trading.
        ItemStack cursor = p.getItemOnCursor();
        Double cursorAmount = null;
        String cursorCurrency = null;
        if (cursor != null && cursor.getType() == Material.PAPER && cursor.hasItemMeta()) {
            PersistentDataContainer pdc = cursor.getItemMeta().getPersistentDataContainer();
            if (pdc.has(DungeonShopGUI.VOUCHER_KEY, org.bukkit.persistence.PersistentDataType.BYTE)) {
                cursorAmount = pdc.get(DungeonShopGUI.VOUCHER_AMOUNT_KEY, org.bukkit.persistence.PersistentDataType.DOUBLE);
                cursorCurrency = pdc.get(DungeonShopGUI.VOUCHER_CURRENCY_KEY, org.bukkit.persistence.PersistentDataType.STRING);
                if (cursorAmount != null && cursorCurrency != null) {
                    currencyName = cursorCurrency;
                    totalByCurrency += cursorAmount * cursor.getAmount();
                    redeemedCount += cursor.getAmount();
                    cursorIsVoucher = true;
                }
            }
        }

        if (redeemedCount == 0 || currencyName == null) return;

        if (currency.deposit(p, currencyName, totalByCurrency)) {
            for (int slot : slotsToClear) p.getInventory().setItem(slot, null);
            if (cursorIsVoucher) p.setItemOnCursor(null);
            p.sendMessage(ChatColor.GREEN + "Voucher ditukar jadi " + currency.format(currencyName, totalByCurrency) + ".");
        } else {
            // deposit gagal - voucher SENGAJA dibiarin di inventory, biar player
            // gak rugi item dan bisa coba lagi (misal buka/tutup inventory) nanti.
            p.sendMessage(ChatColor.RED + "Gagal nuker voucher (currency '" + currencyName + "' error). Voucher-nya aman di inventory, coba lagi nanti atau hubungi admin.");
        }
    }
}
