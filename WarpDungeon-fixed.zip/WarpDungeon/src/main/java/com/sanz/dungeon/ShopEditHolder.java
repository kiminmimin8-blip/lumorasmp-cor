package com.sanz.dungeon;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;

public class ShopEditHolder implements InventoryHolder {

    public enum Mode {
        CATEGORY_LIST,   // daftar kategori dalam 1 dungeon
        CATEGORY_DETAIL, // rename/hapus/icon 1 kategori + tombol masuk ke trade list-nya
        TRADE_LIST,      // daftar trade dalam 1 kategori
        TRADE_DETAIL     // edit 1 trade (input1/input2/output/money/slot/label)
    }

    public static final int INPUT_SLOT = 10;
    public static final int INPUT2_SLOT = 11;
    public static final int OUTPUT_SLOT = 16;
    public static final int ICON_SLOT = 13; // buat CATEGORY_DETAIL

    private final Mode mode;
    private final String dungeonId;
    private final String categoryId; // null kalau mode CATEGORY_LIST
    private final Integer tradeId;   // null kalau bukan TRADE_DETAIL
    private final Map<Integer, String> action = new HashMap<>();
    private Inventory inventory;

    public ShopEditHolder(Mode mode, String dungeonId, String categoryId, Integer tradeId) {
        this.mode = mode;
        this.dungeonId = dungeonId;
        this.categoryId = categoryId;
        this.tradeId = tradeId;
    }

    public Mode getMode() { return mode; }
    public String getDungeonId() { return dungeonId; }
    public String getCategoryId() { return categoryId; }
    public Integer getTradeId() { return tradeId; }

    public void setInventory(Inventory inventory) { this.inventory = inventory; }
    @Override
    public Inventory getInventory() { return inventory; }

    public void mapAction(int slot, String key) { action.put(slot, key); }
    public String getAction(int slot) { return action.get(slot); }
}
