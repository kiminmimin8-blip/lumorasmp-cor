package com.sanz.dungeon;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.WorldBorder;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.*;
import org.bukkit.plugin.Plugin;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

/**
 * Semua proteksi jalan selama player fisik ada di dalam region dungeon.
 * Bypass: OP atau permission dungeon.bypass.
 */
public class DungeonProtectionListener implements Listener {

    private static final int MORNING_TIME = 1000; // pagi

    // command yg diblok kalau lagi di dalam dungeon (tanpa slash, lowercase).
    // "back" sengaja dimasukin juga - WarpDungeon gak punya /back sendiri lagi
    // (fitur back-timer 2 menit udah dihapus), tapi kalau ada plugin lain yang
    // punya /back (misal Essentials), tetep diblokir selama di dalam dungeon.
    private static final Set<String> BLOCKED_COMMANDS = Set.of(
            "teleport", "tp", "tpa", "tpaccept", "tpahere",
            "sethome", "setwarp", "warp",
            "teamwarp", "tw",
            "tpauto",
            "claim", "trade", "back"
    );

    private final Plugin plugin;
    private final DungeonManager manager;

    // player yg lagi tercatat di dalam dungeon tertentu, buat deteksi enter/exit.
    // ConcurrentHashMap (bukan HashMap biasa) -- kalau server jalan di Folia,
    // checkRegion() bisa kepanggil bareng dari beberapa region thread berbeda
    // buat player yang beda-beda pula, HashMap biasa gak aman dipakai gitu.
    private final java.util.Map<UUID, String> insideDungeon = new java.util.concurrent.ConcurrentHashMap<>();

    public DungeonProtectionListener(Plugin plugin, DungeonManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    private boolean bypass(Player p) {
        return p.isOp() || p.hasPermission("dungeon.bypass");
    }

    // ---------- Deteksi masuk / keluar region (dipanggil dari PlayerMoveListener terpisah,
    // biar gak dobel logic move handler) ----------

    /** Dipanggil tiap kali player pindah block. Return true kalau ada perubahan status. */
    public void checkRegion(Player p) {
        Dungeon current = manager.getDungeonAt(p.getLocation());
        String prevId = insideDungeon.get(p.getUniqueId());
        String currId = current != null ? current.getId() : null;

        if (java.util.Objects.equals(prevId, currId)) return; // gak ada perubahan

        // exit dari dungeon sebelumnya
        if (prevId != null) {
            onLeaveDungeon(p, prevId);
        }
        // masuk dungeon baru
        if (currId != null) {
            onEnterDungeon(p, current);
        }

        if (currId != null) insideDungeon.put(p.getUniqueId(), currId);
        else insideDungeon.remove(p.getUniqueId());
    }

    private void onEnterDungeon(Player p, Dungeon d) {
        p.setPlayerTime(MORNING_TIME, false);
        applyBorder(p, d);
    }

    private void onLeaveDungeon(Player p, String dungeonId) {
        p.resetPlayerTime();
        clearBorder(p);
        // dianggap "keluar" otomatis, gak perlu /dungeon leave.
    }

    // ---------- World border per-player buat nampilin batas dungeon ----------
    // Sebelumnya region cuma dipakai buat proteksi (block break/place, pvp, dll),
    // gak pernah beneran dipasang jadi WorldBorder visual, makanya garis merah
    // di edge dungeon gak pernah muncul. Border di sini murni visual (warning
    // distance & damage 0) - proteksi "keluar dungeon" sendiri udah ditangani
    // checkRegion() di atas, jadi border gak perlu nahan/nge-damage player.

    private void applyBorder(Player p, Dungeon d) {
        if (!d.isRegionSet()) return;

        double centerX = (d.getX1() + d.getX2() + 1) / 2.0;
        double centerZ = (d.getZ1() + d.getZ2() + 1) / 2.0;
        double sizeX = (d.getX2() - d.getX1()) + 1;
        double sizeZ = (d.getZ2() - d.getZ1()) + 1;
        double size = Math.max(sizeX, sizeZ);

        WorldBorder border = Bukkit.createWorldBorder();
        border.setCenter(centerX, centerZ);
        border.setSize(size);
        border.setWarningDistance(0);
        border.setWarningTime(0);
        border.setDamageAmount(0);
        border.setDamageBuffer(0);

        p.setWorldBorder(border);
    }

    private void clearBorder(Player p) {
        // null = balik ke world border global server (kalau ada)
        p.setWorldBorder(null);
    }

    public boolean isInsideDungeon(Player p) {
        return insideDungeon.containsKey(p.getUniqueId());
    }

    public void handleQuit(Player p) {
        insideDungeon.remove(p.getUniqueId());
    }

    // ---------- Block break / place ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent e) {
        if (bypass(e.getPlayer())) return;
        if (manager.getDungeonAt(e.getBlock().getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlace(BlockPlaceEvent e) {
        if (bypass(e.getPlayer())) return;
        if (manager.getDungeonAt(e.getBlock().getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    // ---------- Ledakan gak hancurin block, tapi damage tetap jalan ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onExplode(EntityExplodeEvent e) {
        if (manager.getDungeonAt(e.getLocation()) != null) {
            e.blockList().clear();
        }
    }

    // ---------- Fly / Elytra ----------

    @EventHandler
    public void onFlightToggle(PlayerToggleFlightEvent e) {
        Player p = e.getPlayer();
        if (bypass(p)) return;
        if (manager.getDungeonAt(p.getLocation()) != null && p.isFlying()) {
            e.setCancelled(true);
            p.setAllowFlight(false);
        }
    }

    @EventHandler
    public void onGlideToggle(EntityToggleGlideEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (bypass(p)) return;
        if (e.isGliding() && manager.getDungeonAt(p.getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    // ---------- PvP off ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;

        Entity damagerEnt = e.getDamager();
        Player damager = null;
        if (damagerEnt instanceof Player dp) {
            damager = dp;
        } else if (damagerEnt instanceof Projectile proj && proj.getShooter() instanceof Player sp) {
            damager = sp;
        }
        if (damager == null) return;
        if (bypass(damager)) return;

        if (manager.getDungeonAt(victim.getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    // ---------- Enderpearl & Firework (elytra boost) ----------

    @EventHandler
    public void onProjectileLaunch(ProjectileLaunchEvent e) {
        EntityType type = e.getEntityType();
        if (type != EntityType.ENDER_PEARL && type != EntityType.FIREWORK_ROCKET) return;

        // firework dari dispenser dll gak punya shooter Player - tetep diblok
        // asal posisinya di dalam dungeon, biar gak dipake buat boost elytra
        // lewat cara aneh-aneh.
        if (e.getEntity().getShooter() instanceof Player p && bypass(p)) return;

        if (manager.getDungeonAt(e.getEntity().getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onFireworkUse(PlayerInteractEvent e) {
        if (e.getItem() == null || e.getItem().getType() != Material.FIREWORK_ROCKET) return;
        Player p = e.getPlayer();
        if (bypass(p)) return;
        if (manager.getDungeonAt(p.getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    // ---------- Mob spawn - cuma mob dari MythicMobs yang boleh spawn ----------
    // MythicMobs nandain entity hasil spawn-nya sendiri pake metadata key
    // "MythicMobs" (dipasang otomatis sama plugin itu di semua mob custom-nya).
    // Spawn vanilla/plugin lain (natural, spawner, egg, dll) di dalam region
    // dungeon langsung dibatalin.

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCreatureSpawn(CreatureSpawnEvent e) {
        if (e.getEntity().hasMetadata("MythicMobs")) return;
        if (manager.getDungeonAt(e.getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    // ---------- Chorus fruit (makanan yg efeknya teleport) ----------

    @EventHandler
    public void onConsume(PlayerItemConsumeEvent e) {
        if (e.getItem().getType() != Material.CHORUS_FRUIT) return;
        Player p = e.getPlayer();
        if (bypass(p)) return;
        if (manager.getDungeonAt(p.getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    // ---------- Command yg diblok ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (bypass(p)) return;
        if (manager.getDungeonAt(p.getLocation()) == null) return;

        String msg = e.getMessage().substring(1); // buang "/"
        String[] parts = msg.split(" ");
        String cmdLabel = parts[0].toLowerCase();
        // buang prefix plugin kalau ada, misal "sanzcore:tp" -> "tp"
        if (cmdLabel.contains(":")) cmdLabel = cmdLabel.substring(cmdLabel.indexOf(":") + 1);

        boolean blocked = BLOCKED_COMMANDS.contains(cmdLabel);

        // "/team sethome" & "/team setwarp" - cuma 2 subcommand /team ini yang
        // diblok, subcommand /team lain (invite, chat, dll) tetep boleh.
        if (!blocked && cmdLabel.equals("team") && parts.length >= 2) {
            String sub = parts[1].toLowerCase();
            if (sub.equals("sethome") || sub.equals("setwarp")) blocked = true;
        }

        if (blocked) {
            e.setCancelled(true);
            p.sendMessage(ChatColor.RED + "Command itu gak bisa dipakai di dalam dungeon.");
        }
        // note: /rtp dan /home (bukan /sethome) sengaja gak masuk daftar blokir - dianggap jalur keluar yg sah
    }
}
