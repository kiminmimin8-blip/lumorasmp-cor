package com.sanz.dungeon;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class DungeonManager {

    private final Plugin plugin;
    private final File file;
    private final Map<String, Dungeon> dungeons = new LinkedHashMap<>();

    // titik 1 wand per player (titik 2 langsung dari lokasi klik kanan pas /dungeon save)
    private final Map<UUID, Location> pendingPoint1 = new HashMap<>();
    private final Map<UUID, Location> pendingPoint2 = new HashMap<>();

    public DungeonManager(Plugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "dungeons.yml");
        load();
    }

    public Collection<Dungeon> getAll() { return dungeons.values(); }

    public Dungeon get(String id) { return dungeons.get(id.toLowerCase()); }

    public boolean exists(String id) { return dungeons.containsKey(id.toLowerCase()); }

    public Dungeon createDungeon(String id) {
        Dungeon d = new Dungeon(id.toLowerCase());
        dungeons.put(id.toLowerCase(), d);
        save();
        return d;
    }

    public void deleteDungeon(String id) {
        dungeons.remove(id.toLowerCase());
        save();
    }

    /** Cari dungeon yang region-nya mencakup lokasi ini. Null kalau gak ada / di luar semua dungeon. */
    public Dungeon getDungeonAt(Location loc) {
        for (Dungeon d : dungeons.values()) {
            if (d.isRegionSet() && d.contains(loc)) return d;
        }
        return null;
    }

    // ---------- Wand selection ----------

    public void setPoint1(Player p, Location loc) { pendingPoint1.put(p.getUniqueId(), loc); }
    public void setPoint2(Player p, Location loc) { pendingPoint2.put(p.getUniqueId(), loc); }
    public Location getPoint1(Player p) { return pendingPoint1.get(p.getUniqueId()); }
    public Location getPoint2(Player p) { return pendingPoint2.get(p.getUniqueId()); }

    public boolean hasBothPoints(Player p) {
        return pendingPoint1.containsKey(p.getUniqueId()) && pendingPoint2.containsKey(p.getUniqueId());
    }

    public void clearSelection(Player p) {
        pendingPoint1.remove(p.getUniqueId());
        pendingPoint2.remove(p.getUniqueId());
    }

    // ---------- Persistence ----------

    public void load() {
        dungeons.clear();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        if (yml.getConfigurationSection("dungeons") == null) return;

        for (String id : yml.getConfigurationSection("dungeons").getKeys(false)) {
            String base = "dungeons." + id + ".";
            Dungeon d = new Dungeon(id);
            d.setDisplayName(yml.getString(base + "displayName", id));
            d.setDescription(yml.getStringList(base + "description"));
            d.setPremium(yml.getBoolean(base + "premium", false));
            d.setPrice(yml.getDouble(base + "price", 0.0));
            d.setCurrency(yml.getString(base + "currency", "money"));
            d.setGuiSlot(yml.getInt(base + "guiSlot", -1));

            String matName = yml.getString(base + "displayItem", "CHEST");
            Material mat = Material.matchMaterial(matName);
            d.setDisplayItem(mat != null ? mat : Material.CHEST);

            if (yml.contains(base + "region.world")) {
                World w = Bukkit.getWorld(yml.getString(base + "region.world"));
                if (w != null) {
                    d.setRegion(w,
                            yml.getInt(base + "region.x1"), yml.getInt(base + "region.y1"), yml.getInt(base + "region.z1"),
                            yml.getInt(base + "region.x2"), yml.getInt(base + "region.y2"), yml.getInt(base + "region.z2"));
                }
            }

            if (yml.contains(base + "spawn.world")) {
                World w = Bukkit.getWorld(yml.getString(base + "spawn.world"));
                if (w != null) {
                    Location loc = new Location(w,
                            yml.getDouble(base + "spawn.x"), yml.getDouble(base + "spawn.y"), yml.getDouble(base + "spawn.z"),
                            (float) yml.getDouble(base + "spawn.yaw"), (float) yml.getDouble(base + "spawn.pitch"));
                    d.setSpawn(loc);
                }
            }

            dungeons.put(id, d);
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Dungeon d : dungeons.values()) {
            String base = "dungeons." + d.getId() + ".";
            yml.set(base + "displayName", d.getDisplayName());
            yml.set(base + "description", d.getDescription());
            yml.set(base + "premium", d.isPremium());
            yml.set(base + "price", d.getPrice());
            yml.set(base + "currency", d.getCurrency());
            yml.set(base + "guiSlot", d.getGuiSlot());
            yml.set(base + "displayItem", d.getDisplayItem().name());

            if (d.isRegionSet()) {
                yml.set(base + "region.world", d.getWorldName());
                yml.set(base + "region.x1", d.getX1());
                yml.set(base + "region.y1", d.getY1());
                yml.set(base + "region.z1", d.getZ1());
                yml.set(base + "region.x2", d.getX2());
                yml.set(base + "region.y2", d.getY2());
                yml.set(base + "region.z2", d.getZ2());
            }

            if (d.isSpawnSet()) {
                yml.set(base + "spawn.world", d.getSpawnWorld());
                yml.set(base + "spawn.x", d.getSpawnX());
                yml.set(base + "spawn.y", d.getSpawnY());
                yml.set(base + "spawn.z", d.getSpawnZ());
                yml.set(base + "spawn.yaw", d.getSpawnYaw());
                yml.set(base + "spawn.pitch", d.getSpawnPitch());
            }
        }

        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal save dungeons.yml: " + e.getMessage());
        }
    }
}
