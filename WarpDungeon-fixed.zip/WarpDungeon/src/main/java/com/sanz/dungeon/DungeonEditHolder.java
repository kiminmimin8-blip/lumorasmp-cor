package com.sanz.dungeon;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;

/** Dipakai buat 2 jenis GUI: list semua dungeon (mode=LIST) dan detail 1 dungeon (mode=DETAIL). */
public class DungeonEditHolder implements InventoryHolder {

    public enum Mode { LIST, DETAIL }

    private final Mode mode;
    private final String dungeonId; // null kalau mode LIST
    private final Map<Integer, String> slotAction = new HashMap<>(); // slot -> action key
    private Inventory inventory;

    public DungeonEditHolder(Mode mode, String dungeonId) {
        this.mode = mode;
        this.dungeonId = dungeonId;
    }

    public Mode getMode() { return mode; }
    public String getDungeonId() { return dungeonId; }

    public void setInventory(Inventory inventory) { this.inventory = inventory; }
    @Override
    public Inventory getInventory() { return inventory; }

    public void mapAction(int slot, String actionKey) { slotAction.put(slot, actionKey); }
    public String getAction(int slot) { return slotAction.get(slot); }
}
