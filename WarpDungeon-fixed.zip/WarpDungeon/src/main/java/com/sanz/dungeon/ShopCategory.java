package com.sanz.dungeon;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 1 kategori shop di dalam 1 dungeon. Contoh: "Armor", "Senjata", "Tukar Fragmen".
 * Tiap dungeon bisa punya banyak kategori, tiap kategori punya banyak trade
 * sendiri-sendiri.
 */
public class ShopCategory {

    private final String id; // slug, misal "armor", "senjata"
    private String label;
    private ItemStack icon;
    private int selectSlot = -1; // -1 = auto (kepasang urut pas GUI dibangun)

    private final Map<Integer, ShopTrade> trades = new LinkedHashMap<>();
    private int nextTradeId = 1;

    public ShopCategory(String id, String label) {
        this.id = id;
        this.label = label;
        this.icon = new ItemStack(Material.CHEST);
    }

    public String getId() { return id; }

    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }

    public ItemStack getIcon() { return icon; }
    public void setIcon(ItemStack icon) {
        this.icon = (icon == null || icon.getType() == Material.AIR) ? new ItemStack(Material.CHEST) : icon.clone();
    }

    public int getSelectSlot() { return selectSlot; }
    public void setSelectSlot(int selectSlot) { this.selectSlot = selectSlot; }

    public Map<Integer, ShopTrade> getTradesRaw() { return trades; }

    public List<ShopTrade> getTradesSorted() {
        return trades.values().stream()
                .sorted(Comparator.comparingInt(ShopTrade::getSlot).thenComparingInt(ShopTrade::getId))
                .collect(Collectors.toList());
    }

    public ShopTrade get(int tradeId) { return trades.get(tradeId); }

    public ShopTrade createTrade() {
        ShopTrade t = new ShopTrade(nextTradeId++);
        trades.put(t.getId(), t);
        return t;
    }

    /** Dipakai pas load dari yml, biar id lama kepake lagi (bukan re-generate). */
    public void putLoadedTrade(ShopTrade t) {
        trades.put(t.getId(), t);
        if (t.getId() >= nextTradeId) nextTradeId = t.getId() + 1;
    }

    public boolean removeTrade(int tradeId) { return trades.remove(tradeId) != null; }

    public int readyCount() {
        return (int) trades.values().stream().filter(ShopTrade::isReady).count();
    }
}
