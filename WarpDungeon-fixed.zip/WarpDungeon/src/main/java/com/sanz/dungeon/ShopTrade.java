package com.sanz.dungeon;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

/**
 * 1 trade di dungeon shop.
 *
 * PENTING: input1/input2/output disimpan sebagai ItemStack UTUH (bukan cuma
 * Material + amount kayak versi lama), jadi enchant, custom name, lore, sampai
 * custom model data/NBT dari item MythicMobs ikut kesimpen persis kayak item
 * aslinya. Ini yang bikin shop bisa "diedit in-game" tanpa kehilangan detail
 * item pas admin naro item asli (misal hasil /mm item give) ke slot GUI.
 *
 * input2 boleh null/AIR kalau tradenya cuma butuh 1 macam item (kayak trade
 * biasa), atau diisi kalau butuh 2 macam item sekaligus (kayak GUI villager
 * di shopkeeper: item1 + item2 -> result).
 */
public class ShopTrade {

    public enum OutputType { MONEY, ITEM }

    private final int id;
    private String label; // nama trade, buat identifikasi di list

    private ItemStack input1;
    private ItemStack input2; // nullable

    private OutputType outputType = OutputType.MONEY;
    private double outputMoney = 0;
    private String outputCurrency = "money";
    private ItemStack output; // dipakai kalau outputType == ITEM, full ItemStack (enchant dll ikut)

    public ShopTrade(int id) { this.id = id; this.label = "Trade #" + id; }

    public int getId() { return id; }

    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }

    public ItemStack getInput1() { return input1; }
    public void setInput1(ItemStack input1) { this.input1 = clean(input1); }

    public ItemStack getInput2() { return input2; }
    public void setInput2(ItemStack input2) { this.input2 = clean(input2); }

    public OutputType getOutputType() { return outputType; }
    public void setOutputType(OutputType outputType) { this.outputType = outputType; }

    public double getOutputMoney() { return outputMoney; }
    public void setOutputMoney(double outputMoney) { this.outputMoney = Math.max(0, outputMoney); }

    public String getOutputCurrency() { return outputCurrency; }
    public void setOutputCurrency(String outputCurrency) { this.outputCurrency = outputCurrency; }

    public ItemStack getOutput() { return output; }
    public void setOutput(ItemStack output) { this.output = clean(output); }

    private ItemStack clean(ItemStack item) {
        if (item == null || item.getType() == Material.AIR || item.getAmount() <= 0) return null;
        return item.clone();
    }

    /** Trade dianggap siap dipajang di /dungeon shop kalau minimal input1 & output-nya kesetting. */
    public boolean isReady() {
        if (input1 == null) return false;
        if (outputType == OutputType.ITEM) return output != null;
        return outputMoney > 0;
    }

    public ItemStack buildInput1() { return input1 == null ? null : input1.clone(); }
    public ItemStack buildInput2() { return input2 == null ? null : input2.clone(); }
    public ItemStack buildOutputItem() { return output == null ? null : output.clone(); }
}
