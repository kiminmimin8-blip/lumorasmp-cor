package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class DungeonShopCategorySelectListener implements Listener {

    private final DungeonShopManager shopManager;
    private final DungeonShopGUI shopGUI;

    public DungeonShopCategorySelectListener(DungeonShopManager shopManager, DungeonShopGUI shopGUI) {
        this.shopManager = shopManager;
        this.shopGUI = shopGUI;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof DungeonShopGUI.CategorySelectHolder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;

        String categoryId = holder.getCategoryId(e.getRawSlot());
        if (categoryId == null) return;

        DungeonShop shop = shopManager.get(holder.getDungeonId());
        if (shop == null) return;
        ShopCategory category = shop.get(categoryId);
        if (category == null) return;

        if (category.readyCount() == 0) {
            p.sendMessage(ChatColor.RED + "Kategori ini belum ada trade yang siap.");
            return;
        }

        p.openMerchant(shopGUI.buildMerchant(category), true);
    }
}
