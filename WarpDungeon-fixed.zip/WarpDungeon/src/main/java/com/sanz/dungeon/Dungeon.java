package com.sanz.dungeon;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import java.util.ArrayList;
import java.util.List;

/**
 * Data 1 dungeon: region (world border), titik spawn, status premium,
 * display buat GUI, dan pengaturan shop-nya sendiri kalau nanti dibutuhkan.
 * Semua koordinat disimpan sbg block coordinate (int) biar gampang di-save YAML.
 */
public class Dungeon {

    private final String id;
    private String displayName;
    private List<String> description = new ArrayList<>();
    private boolean premium = false;
    private double price = 0.0; // harga tiket, dicharge tiap kali masuk kalau premium
    private String currency = "money"; // money/cash/shards, sesuai economy SanzCore

    private Material displayItem = Material.CHEST;
    private int guiSlot = -1; // -1 = belum diatur, auto-assign slot kosong

    private String worldName;
    private int x1, y1, z1;
    private int x2, y2, z2;
    private boolean regionSet = false;

    // titik teleport masuk dungeon (beda dari region corner)
    private String spawnWorld;
    private double spawnX, spawnY, spawnZ;
    private float spawnYaw, spawnPitch;
    private boolean spawnSet = false;

    public Dungeon(String id) {
        this.id = id;
        this.displayName = id;
    }

    public String getId() { return id; }

    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }

    public List<String> getDescription() { return description; }
    public void setDescription(List<String> description) { this.description = description; }

    public boolean isPremium() { return premium; }
    public void setPremium(boolean premium) { this.premium = premium; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public Material getDisplayItem() { return displayItem; }
    public void setDisplayItem(Material displayItem) { this.displayItem = displayItem; }

    public int getGuiSlot() { return guiSlot; }
    public void setGuiSlot(int guiSlot) { this.guiSlot = guiSlot; }

    public boolean isRegionSet() { return regionSet; }

    public void setRegion(World world, int x1, int y1, int z1, int x2, int y2, int z2) {
        this.worldName = world.getName();
        this.x1 = Math.min(x1, x2);
        this.x2 = Math.max(x1, x2);
        this.y1 = Math.min(y1, y2);
        this.y2 = Math.max(y1, y2);
        this.z1 = Math.min(z1, z2);
        this.z2 = Math.max(z1, z2);
        this.regionSet = true;
    }

    public String getWorldName() { return worldName; }
    public int getX1() { return x1; }
    public int getY1() { return y1; }
    public int getZ1() { return z1; }
    public int getX2() { return x2; }
    public int getY2() { return y2; }
    public int getZ2() { return z2; }

    /** Cek apakah sebuah lokasi ada di dalam region dungeon ini. */
    public boolean contains(Location loc) {
        if (!regionSet || loc == null || loc.getWorld() == null) return false;
        if (!loc.getWorld().getName().equals(worldName)) return false;
        double x = loc.getX(), y = loc.getY(), z = loc.getZ();
        return x >= x1 && x <= x2 + 1 && y >= y1 && y <= y2 + 1 && z >= z1 && z <= z2 + 1;
    }

    public boolean isSpawnSet() { return spawnSet; }

    public void setSpawn(Location loc) {
        this.spawnWorld = loc.getWorld().getName();
        this.spawnX = loc.getX();
        this.spawnY = loc.getY();
        this.spawnZ = loc.getZ();
        this.spawnYaw = loc.getYaw();
        this.spawnPitch = loc.getPitch();
        this.spawnSet = true;
    }

    public Location getSpawnLocation() {
        if (!spawnSet) return null;
        World w = org.bukkit.Bukkit.getWorld(spawnWorld);
        if (w == null) return null;
        return new Location(w, spawnX, spawnY, spawnZ, spawnYaw, spawnPitch);
    }

    public String getSpawnWorld() { return spawnWorld; }
    public double getSpawnX() { return spawnX; }
    public double getSpawnY() { return spawnY; }
    public double getSpawnZ() { return spawnZ; }
    public float getSpawnYaw() { return spawnYaw; }
    public float getSpawnPitch() { return spawnPitch; }
}
