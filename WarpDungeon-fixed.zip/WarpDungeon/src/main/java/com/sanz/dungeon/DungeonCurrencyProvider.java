package com.sanz.dungeon;

import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Abstraksi currency buat charge tiket dungeon premium.
 * "money" udah kesambung ke Vault (economy plugin apapun yg lo pasang, misal EssentialsX Economy).
 * "cash" & "shards" masih stub - tinggal sambungin ke sistem multi-currency SanzCore
 * begitu itu jadi (liat catatan CoinsEngine/ExcellentEconomy/PlayerPoints di planning lo).
 */
public class DungeonCurrencyProvider {

    private net.milkbowl.vault.economy.Economy vaultEconomy;

    public DungeonCurrencyProvider(JavaPlugin plugin) {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") != null) {
            RegisteredServiceProvider<net.milkbowl.vault.economy.Economy> rsp =
                    plugin.getServer().getServicesManager().getRegistration(net.milkbowl.vault.economy.Economy.class);
            if (rsp != null) vaultEconomy = rsp.getProvider();
        }
    }

    public boolean has(Player p, String currency, double amount) {
        return switch (currency.toLowerCase()) {
            case "money" -> vaultEconomy != null && vaultEconomy.has(p, amount);
            case "cash" -> hasCash(p, amount);     // TODO: sambungin ke currency Cash SanzCore
            case "shards" -> hasShards(p, amount); // TODO: sambungin ke currency Shards SanzCore
            default -> false;
        };
    }

    /** Return true kalau berhasil charge. */
    public boolean withdraw(Player p, String currency, double amount) {
        return switch (currency.toLowerCase()) {
            case "money" -> vaultEconomy != null && vaultEconomy.withdrawPlayer(p, amount).transactionSuccess();
            case "cash" -> withdrawCash(p, amount);     // TODO
            case "shards" -> withdrawShards(p, amount); // TODO
            default -> false;
        };
    }

    /** Nambahin saldo, dipakai buat hasil tukar shop (bukan buat charge). */
    public boolean deposit(Player p, String currency, double amount) {
        return switch (currency.toLowerCase()) {
            case "money" -> vaultEconomy != null && vaultEconomy.depositPlayer(p, amount).transactionSuccess();
            case "cash" -> depositCash(p, amount);     // TODO
            case "shards" -> depositShards(p, amount); // TODO
            default -> false;
        };
    }

    public String format(String currency, double amount) {
        if (currency.equalsIgnoreCase("money") && vaultEconomy != null) {
            return vaultEconomy.format(amount);
        }
        return amount + " " + currency;
    }

    // ---- stub, tinggal isi pas currency Cash/Shards SanzCore udah jadi ----
    private boolean hasCash(Player p, double amount) { return false; }
    private boolean withdrawCash(Player p, double amount) { return false; }
    private boolean depositCash(Player p, double amount) { return false; }
    private boolean hasShards(Player p, double amount) { return false; }
    private boolean withdrawShards(Player p, double amount) { return false; }
    private boolean depositShards(Player p, double amount) { return false; }
}
