package com.sanz.dungeon;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ShopEditSession {
    private final Map<UUID, Integer> awaitingRename = new HashMap<>();

    public void awaitRename(UUID uuid, int tradeId) { awaitingRename.put(uuid, tradeId); }
    public Integer get(UUID uuid) { return awaitingRename.get(uuid); }
    public void clear(UUID uuid) { awaitingRename.remove(uuid); }
}
