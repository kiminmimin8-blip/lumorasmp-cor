package com.sanz.dungeon;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ShopEditSession {

    public enum Type { RENAME_TRADE, RENAME_CATEGORY, CREATE_CATEGORY }

    public static class Pending {
        public final Type type;
        public final String dungeonId;
        public final String categoryId; // null kalau CREATE_CATEGORY
        public final Integer tradeId;   // null kalau bukan RENAME_TRADE

        public Pending(Type type, String dungeonId, String categoryId, Integer tradeId) {
            this.type = type;
            this.dungeonId = dungeonId;
            this.categoryId = categoryId;
            this.tradeId = tradeId;
        }
    }

    // ConcurrentHashMap (bukan HashMap biasa) - ditulis dari main thread (klik GUI)
    // tapi dibaca/dihapus dari thread AsyncPlayerChatEvent, HashMap biasa gak aman
    // dipakai bareng dari 2 thread beda kayak gitu.
    private final Map<UUID, Pending> pending = new ConcurrentHashMap<>();

    public void awaitRenameTrade(UUID uuid, String dungeonId, String categoryId, int tradeId) {
        pending.put(uuid, new Pending(Type.RENAME_TRADE, dungeonId, categoryId, tradeId));
    }

    public void awaitRenameCategory(UUID uuid, String dungeonId, String categoryId) {
        pending.put(uuid, new Pending(Type.RENAME_CATEGORY, dungeonId, categoryId, null));
    }

    public void awaitCreateCategory(UUID uuid, String dungeonId) {
        pending.put(uuid, new Pending(Type.CREATE_CATEGORY, dungeonId, null, null));
    }

    public Pending get(UUID uuid) { return pending.get(uuid); }
    public void clear(UUID uuid) { pending.remove(uuid); }
}
