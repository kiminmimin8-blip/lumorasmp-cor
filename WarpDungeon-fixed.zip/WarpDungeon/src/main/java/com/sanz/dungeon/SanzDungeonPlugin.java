package com.sanz.dungeon;

import org.bukkit.plugin.java.JavaPlugin;

public class SanzDungeonPlugin extends JavaPlugin {

    private DungeonManager dungeonManager;
    private DungeonShopManager shopManager;
    private WarpDungeonConfig warpConfig;

    @Override
    public void onEnable() {
        warpConfig = new WarpDungeonConfig(this);

        dungeonManager = new DungeonManager(this);
        DungeonCurrencyProvider currency = new DungeonCurrencyProvider(this);

        shopManager = new DungeonShopManager(this);

        DungeonWandListener wandListener = new DungeonWandListener(this, dungeonManager);
        DungeonProtectionListener protectionListener = new DungeonProtectionListener(this, dungeonManager, warpConfig);
        DungeonMoveListener moveListener = new DungeonMoveListener(protectionListener);

        DungeonGUI dungeonGUI = new DungeonGUI(dungeonManager);
        DungeonGUIListener guiListener = new DungeonGUIListener(dungeonManager, currency);

        DungeonEditSession editSession = new DungeonEditSession();
        DungeonEditGUI editGUI = new DungeonEditGUI(dungeonManager);
        DungeonEditListener editListener = new DungeonEditListener(dungeonManager, editGUI, editSession);

        DungeonShopGUI shopGUI = new DungeonShopGUI();
        DungeonShopVoucherListener shopVoucherListener = new DungeonShopVoucherListener(currency, this);
        DungeonShopCategorySelectListener categorySelectListener = new DungeonShopCategorySelectListener(shopManager, shopGUI);

        ShopEditSession shopEditSession = new ShopEditSession();
        ShopEditGUI shopEditGUI = new ShopEditGUI();
        ShopEditListener shopEditListener = new ShopEditListener(shopManager, shopEditGUI, shopEditSession, this, warpConfig);

        getServer().getPluginManager().registerEvents(wandListener, this);
        getServer().getPluginManager().registerEvents(protectionListener, this);
        getServer().getPluginManager().registerEvents(moveListener, this);
        getServer().getPluginManager().registerEvents(guiListener, this);
        getServer().getPluginManager().registerEvents(editListener, this);
        getServer().getPluginManager().registerEvents(shopVoucherListener, this);
        getServer().getPluginManager().registerEvents(categorySelectListener, this);
        getServer().getPluginManager().registerEvents(shopEditListener, this);

        DungeonCommand dungeonCommand = new DungeonCommand(dungeonManager, wandListener, dungeonGUI, editGUI, shopGUI, shopEditGUI, shopManager, warpConfig);
        getCommand("dungeon").setExecutor(dungeonCommand);
        getCommand("dungeon").setTabCompleter(dungeonCommand);
        // /back udah dihapus - dulu WarpDungeon punya /back sendiri (window 2 menit
        // buat balik ke dungeon), sekarang gak ada lagi, dan /back dari plugin lain
        // (misal Essentials) tetep diblokir selagi player di dalam dungeon
        // (lihat blocked-commands di config.yml).

        getLogger().info("SanzDungeon jalan. " + dungeonManager.getAll().size() + " dungeon, " + shopManager.countTotalReadyTrades() + " trade shop siap ke-load.");
    }

    @Override
    public void onDisable() {
        if (dungeonManager != null) dungeonManager.save();
        if (shopManager != null) shopManager.save();
    }
}
