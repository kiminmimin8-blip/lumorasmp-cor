package com.sanz.dungeon;

import org.bukkit.plugin.java.JavaPlugin;

public class SanzDungeonPlugin extends JavaPlugin {

    private DungeonManager dungeonManager;
    private DungeonShopManager shopManager;

    @Override
    public void onEnable() {
        dungeonManager = new DungeonManager(this);
        DungeonBackManager backManager = new DungeonBackManager(dungeonManager);
        DungeonCurrencyProvider currency = new DungeonCurrencyProvider(this);

        shopManager = new DungeonShopManager(this);

        DungeonWandListener wandListener = new DungeonWandListener(this, dungeonManager);
        DungeonProtectionListener protectionListener = new DungeonProtectionListener(this, dungeonManager, backManager);
        DungeonMoveListener moveListener = new DungeonMoveListener(protectionListener);

        DungeonGUI dungeonGUI = new DungeonGUI(dungeonManager);
        DungeonGUIListener guiListener = new DungeonGUIListener(dungeonManager, currency);

        DungeonEditSession editSession = new DungeonEditSession();
        DungeonEditGUI editGUI = new DungeonEditGUI(dungeonManager);
        DungeonEditListener editListener = new DungeonEditListener(dungeonManager, editGUI, editSession);

        DungeonShopGUI shopGUI = new DungeonShopGUI(shopManager);
        DungeonShopListener shopListener = new DungeonShopListener(shopManager, currency);

        ShopEditSession shopEditSession = new ShopEditSession();
        ShopEditGUI shopEditGUI = new ShopEditGUI(shopManager);
        ShopEditListener shopEditListener = new ShopEditListener(shopManager, shopEditGUI, shopEditSession);

        getServer().getPluginManager().registerEvents(wandListener, this);
        getServer().getPluginManager().registerEvents(protectionListener, this);
        getServer().getPluginManager().registerEvents(moveListener, this);
        getServer().getPluginManager().registerEvents(guiListener, this);
        getServer().getPluginManager().registerEvents(editListener, this);
        getServer().getPluginManager().registerEvents(shopListener, this);
        getServer().getPluginManager().registerEvents(shopEditListener, this);

        DungeonCommand dungeonCommand = new DungeonCommand(dungeonManager, wandListener, dungeonGUI, editGUI, shopGUI, shopEditGUI);
        getCommand("dungeon").setExecutor(dungeonCommand);
        getCommand("dungeon").setTabCompleter(dungeonCommand);
        getCommand("back").setExecutor(new DungeonBackCommand(backManager));

        getLogger().info("SanzDungeon jalan. " + dungeonManager.getAll().size() + " dungeon, " + shopManager.getAll().size() + " trade shop ke-load.");
    }

    @Override
    public void onDisable() {
        if (dungeonManager != null) dungeonManager.save();
        if (shopManager != null) shopManager.save();
    }
}
