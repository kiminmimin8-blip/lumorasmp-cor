package com.sanz.dungeon;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/** Shop 1 dungeon - bisa punya banyak kategori. */
public class DungeonShop {

    private final String dungeonId;
    private final Map<String, ShopCategory> categories = new LinkedHashMap<>();
    private int nextCategoryNum = 1;

    public DungeonShop(String dungeonId) {
        this.dungeonId = dungeonId;
    }

    public String getDungeonId() { return dungeonId; }

    public Map<String, ShopCategory> getCategoriesRaw() { return categories; }

    public List<ShopCategory> getCategories() {
        return categories.values().stream()
                .sorted((a, b) -> {
                    int sa = a.getSelectSlot() < 0 ? Integer.MAX_VALUE : a.getSelectSlot();
                    int sb = b.getSelectSlot() < 0 ? Integer.MAX_VALUE : b.getSelectSlot();
                    return Integer.compare(sa, sb);
                })
                .collect(Collectors.toList());
    }

    public ShopCategory get(String categoryId) { return categoryId == null ? null : categories.get(categoryId); }

    public ShopCategory createCategory(String label) {
        String id = "kategori" + (nextCategoryNum++);
        while (categories.containsKey(id)) id = "kategori" + (nextCategoryNum++);
        ShopCategory cat = new ShopCategory(id, label);
        categories.put(id, cat);
        return cat;
    }

    /** Dipakai pas load dari yml, biar id lama kepake lagi. */
    public void putLoadedCategory(ShopCategory cat) {
        categories.put(cat.getId(), cat);
    }

    public boolean removeCategory(String categoryId) { return categories.remove(categoryId) != null; }

    public boolean isEmpty() { return categories.isEmpty(); }
}
