package com.sanz.dungeon;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class DungeonEditSession {

    public enum Field { NAME, PRICE, DESCRIPTION, SLOT, CREATE_ID, CURRENCY }

    public static class Pending {
        public final String dungeonId; // null kalau lagi CREATE_ID
        public final Field field;
        public Pending(String dungeonId, Field field) { this.dungeonId = dungeonId; this.field = field; }
    }

    private final Map<UUID, Pending> pending = new HashMap<>();

    public void await(UUID uuid, String dungeonId, Field field) { pending.put(uuid, new Pending(dungeonId, field)); }
    public Pending get(UUID uuid) { return pending.get(uuid); }
    public void clear(UUID uuid) { pending.remove(uuid); }
}
