package com.sanz.dungeon;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class DungeonEditSession {

    public enum Field { NAME, PRICE, DESCRIPTION, SLOT, CREATE_ID, CURRENCY }

    public static class Pending {
        public final String dungeonId; // null kalau lagi CREATE_ID
        public final Field field;
        public Pending(String dungeonId, Field field) { this.dungeonId = dungeonId; this.field = field; }
    }

    // ConcurrentHashMap - ditulis dari main thread (klik GUI), dibaca/dihapus
    // dari thread AsyncPlayerChatEvent. HashMap biasa gak aman dipakai bareng
    // dari 2 thread beda kayak gitu.
    private final Map<UUID, Pending> pending = new ConcurrentHashMap<>();

    public void await(UUID uuid, String dungeonId, Field field) { pending.put(uuid, new Pending(dungeonId, field)); }
    public Pending get(UUID uuid) { return pending.get(uuid); }
    public void clear(UUID uuid) { pending.remove(uuid); }
}
