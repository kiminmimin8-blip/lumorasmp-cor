package com.sanz.dungeon;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class ShopEditGUI {

    // ==========================================================
    // LEVEL 1: daftar kategori dalam 1 dungeon
    // ==========================================================

    public Inventory buildCategoryList(DungeonShop shop) {
        List<ShopCategory> cats = shop.getCategories();
        int size = Math.max(27, ((cats.size() / 9) + 2) * 9);
        if (size > 54) size = 54;

        ShopEditHolder holder = new ShopEditHolder(ShopEditHolder.Mode.CATEGORY_LIST, shop.getDungeonId(), null, null);
        Inventory inv = Bukkit.createInventory(holder, size, ChatColor.DARK_GREEN + "Shop: " + shop.getDungeonId() + " - Kategori");
        holder.setInventory(inv);

        int slot = 0;
        for (ShopCategory cat : cats) {
            if (slot >= size - 9) break;
            ItemStack icon = cat.getIcon().clone();
            ItemMeta meta = icon.getItemMeta();
            meta.setDisplayName(ChatColor.YELLOW + "" + ChatColor.BOLD + cat.getLabel());
            meta.setLore(List.of(
                    ChatColor.GRAY + "ID: " + cat.getId(),
                    ChatColor.GRAY + cat.getTradesRaw().size() + " trade (" + cat.readyCount() + " siap)",
                    ChatColor.GRAY + "Slot pilih: " + (cat.getSelectSlot() < 0 ? "auto" : cat.getSelectSlot()),
                    "",
                    ChatColor.YELLOW + "Klik buat buka daftar trade"
            ));
            icon.setItemMeta(meta);
            inv.setItem(slot, icon);
            holder.mapAction(slot, "open_category:" + cat.getId());
            slot++;
        }

        inv.setItem(size - 9, named(Material.EMERALD, ChatColor.GREEN + "+ Kategori baru"));
        holder.mapAction(size - 9, "create_category");

        inv.setItem(size - 1, named(Material.PAPER, ChatColor.AQUA + "Reload shop.yml dari disk"));
        holder.mapAction(size - 1, "reload");

        return inv;
    }

    // ==========================================================
    // LEVEL 2: detail 1 kategori - rename / hapus / ganti icon
    // ==========================================================

    public Inventory buildCategoryDetail(String dungeonId, ShopCategory cat) {
        ShopEditHolder holder = new ShopEditHolder(ShopEditHolder.Mode.CATEGORY_DETAIL, dungeonId, cat.getId(), null);
        Inventory inv = Bukkit.createInventory(holder, 27, ChatColor.DARK_GREEN + "Kategori: " + cat.getLabel());
        holder.setInventory(inv);

        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        inv.setItem(11, named(Material.HOPPER, ChatColor.YELLOW + "Taro icon kategori di sini ->"));
        inv.setItem(ShopEditHolder.ICON_SLOT, cat.getIcon() != null ? cat.getIcon().clone() : null);

        inv.setItem(4, named(Material.NAME_TAG, ChatColor.AQUA + "Nama: " + cat.getLabel() + ChatColor.GRAY + " (klik ubah)"));
        holder.mapAction(4, "rename_category");

        // slot pemilihan kategori (custom slot) di GUI player - -1 = auto
        int selSlot = cat.getSelectSlot();
        inv.setItem(6, named(Material.RED_DYE, ChatColor.RED + "-1 slot"));
        holder.mapAction(6, "selectslot:-1");
        inv.setItem(7, named(Material.PAPER, ChatColor.WHITE + "Slot pilih: " + (selSlot < 0 ? "auto" : String.valueOf(selSlot))));
        holder.mapAction(7, "noop");
        inv.setItem(8, named(Material.LIME_DYE, ChatColor.GREEN + "+1 slot"));
        holder.mapAction(8, "selectslot:1");

        inv.setItem(15, named(Material.CHEST, ChatColor.AQUA + "" + ChatColor.BOLD + "Buka daftar trade" + ChatColor.GRAY + " (" + cat.getTradesRaw().size() + " trade)"));
        holder.mapAction(15, "open_trades");

        inv.setItem(22, named(Material.EMERALD_BLOCK, ChatColor.GREEN + "SIMPAN icon & slot"));
        holder.mapAction(22, "save_category");

        inv.setItem(26, named(Material.TNT, ChatColor.RED + "Hapus kategori ini (klik 2x)"));
        holder.mapAction(26, "delete_category");

        inv.setItem(18, named(Material.ARROW, ChatColor.GRAY + "<- Kembali ke daftar kategori"));
        holder.mapAction(18, "back_to_categories");

        return inv;
    }

    // ==========================================================
    // LEVEL 3: daftar trade dalam 1 kategori
    // ==========================================================

    public Inventory buildTradeList(String dungeonId, ShopCategory cat) {
        List<ShopTrade> trades = cat.getTradesSorted();

        int size = Math.max(27, ((trades.size() / 9) + 2) * 9);
        if (size > 54) size = 54;

        ShopEditHolder holder = new ShopEditHolder(ShopEditHolder.Mode.TRADE_LIST, dungeonId, cat.getId(), null);
        Inventory inv = Bukkit.createInventory(holder, size, ChatColor.DARK_GREEN + "Trade: " + cat.getLabel());
        holder.setInventory(inv);

        int slot = 0;
        for (ShopTrade t : trades) {
            if (slot >= size - 9) break;
            ItemStack icon = t.getInput1() != null ? t.getInput1().clone() : new ItemStack(Material.BARRIER);
            ItemMeta meta = icon.getItemMeta();
            meta.setDisplayName(ChatColor.AQUA + t.getLabel());

            List<String> lore = new ArrayList<>();
            lore.add(t.isReady() ? ChatColor.GREEN + "Siap dipajang" : ChatColor.RED + "Belum lengkap");
            lore.add(ChatColor.GRAY + "Urutan/slot: " + t.getSlot());
            lore.add("");
            lore.add(ChatColor.GRAY + "Butuh: " + describe(t.getInput1()));
            if (t.getInput2() != null) lore.add(ChatColor.GRAY + "     + " + describe(t.getInput2()));
            if (t.getOutputType() == ShopTrade.OutputType.MONEY) {
                lore.add(ChatColor.GOLD + "-> " + t.getOutputMoney() + " " + t.getOutputCurrency());
            } else {
                lore.add(ChatColor.AQUA + "-> " + describe(t.getOutput()));
            }
            lore.add("");
            lore.add(ChatColor.YELLOW + "Klik buat edit");
            meta.setLore(lore);
            icon.setItemMeta(meta);

            inv.setItem(slot, icon);
            holder.mapAction(slot, "open_trade:" + t.getId());
            slot++;
        }

        inv.setItem(size - 9, named(Material.EMERALD, ChatColor.GREEN + "+ Trade baru"));
        holder.mapAction(size - 9, "create_trade");

        inv.setItem(size - 5, named(Material.COMPARATOR, ChatColor.LIGHT_PURPLE + "⚙ Edit kategori ini (rename/hapus/icon)"));
        holder.mapAction(size - 5, "edit_category");

        inv.setItem(size - 1, named(Material.ARROW, ChatColor.GRAY + "<- Kembali ke daftar kategori"));
        holder.mapAction(size - 1, "back_to_categories");

        return inv;
    }

    // ==========================================================
    // LEVEL 4: detail 1 trade, kayak GUI villager (item1 + item2 -> hasil)
    // ==========================================================

    public Inventory buildTradeDetail(String dungeonId, ShopCategory cat, ShopTrade t) {
        ShopEditHolder holder = new ShopEditHolder(ShopEditHolder.Mode.TRADE_DETAIL, dungeonId, cat.getId(), t.getId());
        Inventory inv = Bukkit.createInventory(holder, 27, ChatColor.DARK_GREEN + "Edit: " + t.getLabel());
        holder.setInventory(inv);

        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        // slot 10 & 11 = INPUT 1 & 2 (editable beneran, taro item drop-nya di sini)
        inv.setItem(ShopEditHolder.INPUT_SLOT, t.getInput1() != null ? t.getInput1().clone() : null);
        inv.setItem(ShopEditHolder.INPUT2_SLOT, t.getInput2() != null ? t.getInput2().clone() : null);
        inv.setItem(9, named(Material.HOPPER, ChatColor.YELLOW + "Taro item drop 1 & 2 di sini ->"));

        inv.setItem(13, named(Material.ARROW, ChatColor.WHITE + "Ditukar jadi"));

        if (t.getOutputType() == ShopTrade.OutputType.ITEM) {
            inv.setItem(ShopEditHolder.OUTPUT_SLOT, t.getOutput() != null ? t.getOutput().clone() : null);
            inv.setItem(17, named(Material.HOPPER, ChatColor.YELLOW + "<- Taro item hasil tukar di sini"));
        } else {
            ItemStack moneyIcon = named(Material.GOLD_INGOT, ChatColor.GOLD.toString() + t.getOutputMoney() + " " + t.getOutputCurrency());
            inv.setItem(ShopEditHolder.OUTPUT_SLOT, moneyIcon);
            holder.mapAction(ShopEditHolder.OUTPUT_SLOT, "noop");

            inv.setItem(19, named(Material.RED_DYE, ChatColor.RED + "-100"));
            holder.mapAction(19, "money:-100");
            inv.setItem(20, named(Material.RED_DYE, ChatColor.RED + "-10"));
            holder.mapAction(20, "money:-10");
            inv.setItem(21, named(Material.RED_DYE, ChatColor.RED + "-1"));
            holder.mapAction(21, "money:-1");
            inv.setItem(23, named(Material.LIME_DYE, ChatColor.GREEN + "+1"));
            holder.mapAction(23, "money:1");
            inv.setItem(24, named(Material.LIME_DYE, ChatColor.GREEN + "+10"));
            holder.mapAction(24, "money:10");
            inv.setItem(25, named(Material.LIME_DYE, ChatColor.GREEN + "+100"));
            holder.mapAction(25, "money:100");
        }

        // baris atas: 0/1/2 = custom slot/urutan, 3 = currency, 4 = toggle mode, 5 = rename
        inv.setItem(0, named(Material.RED_DYE, ChatColor.RED + "-1 urutan"));
        holder.mapAction(0, "slot:-1");
        inv.setItem(1, named(Material.PAPER, ChatColor.WHITE + "Urutan/slot: " + t.getSlot()));
        holder.mapAction(1, "noop");
        inv.setItem(2, named(Material.LIME_DYE, ChatColor.GREEN + "+1 urutan"));
        holder.mapAction(2, "slot:1");

        inv.setItem(3, named(Material.NETHER_STAR, ChatColor.AQUA + "Currency: " + t.getOutputCurrency() + ChatColor.GRAY + " (klik ganti)"));
        holder.mapAction(3, "cycle_currency");

        inv.setItem(4, named(Material.COMPARATOR, ChatColor.LIGHT_PURPLE + "Mode: " + t.getOutputType() + ChatColor.GRAY + " (klik ganti)"));
        holder.mapAction(4, "toggle_mode");

        inv.setItem(5, named(Material.NAME_TAG, ChatColor.AQUA + "Nama: " + t.getLabel() + ChatColor.GRAY + " (klik ubah)"));
        holder.mapAction(5, "rename_trade");

        inv.setItem(22, named(Material.EMERALD_BLOCK, ChatColor.GREEN + "SIMPAN"));
        holder.mapAction(22, "save_trade");

        inv.setItem(26, named(Material.TNT, ChatColor.RED + "Hapus trade ini (klik 2x)"));
        holder.mapAction(26, "delete_trade");

        inv.setItem(18, named(Material.ARROW, ChatColor.GRAY + "<- Kembali (tanpa simpan)"));
        holder.mapAction(18, "back_to_trades");

        return inv;
    }

    private String describe(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return ChatColor.DARK_GRAY + "(kosong)";
        String name = item.hasItemMeta() && item.getItemMeta().hasDisplayName()
                ? ChatColor.stripColor(item.getItemMeta().getDisplayName())
                : prettify(item.getType().name());
        return item.getAmount() + "x " + name;
    }

    private String prettify(String matName) {
        return matName.replace("_", " ").toLowerCase();
    }

    private ItemStack named(Material mat, String name) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        item.setItemMeta(meta);
        return item;
    }
}
