package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /dungeon                -> GUI teleport (semua player)
 * /dungeon shop           -> GUI belanja tukar drop (semua player)
 * /dungeon wand|save|setspawn|create|delete|list|edit -> khusus admin
 * /dungeon shopedit       -> khusus admin, GUI setting trade shop (kayak villager)
 */
public class DungeonCommand implements CommandExecutor, TabCompleter {

    private static final List<String> ADMIN_SUBCOMMANDS = List.of(
            "wand", "save", "setspawn", "create", "delete", "list", "edit", "shopedit"
    );

    private final DungeonManager manager;
    private final DungeonWandListener wandListener;
    private final DungeonGUI gui;
    private final DungeonEditGUI editGUI;
    private final DungeonShopGUI shopGUI;
    private final ShopEditGUI shopEditGUI;

    public DungeonCommand(DungeonManager manager, DungeonWandListener wandListener, DungeonGUI gui,
                           DungeonEditGUI editGUI, DungeonShopGUI shopGUI, ShopEditGUI shopEditGUI) {
        this.manager = manager;
        this.wandListener = wandListener;
        this.gui = gui;
        this.editGUI = editGUI;
        this.shopGUI = shopGUI;
        this.shopEditGUI = shopEditGUI;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }

        // tanpa argumen = buka GUI teleport, kebuka buat semua player
        if (args.length == 0) {
            p.openInventory(gui.build());
            return true;
        }

        String sub = args[0].toLowerCase();

        // /dungeon shop kebuka buat semua player, bukan cuma admin
        if (sub.equals("shop")) {
            p.openInventory(shopGUI.build());
            return true;
        }

        // subcommand di bawah ini semua khusus admin
        if (!p.hasPermission("dungeon.admin")) {
            p.sendMessage(ChatColor.RED + "Kamu gak punya izin buat command ini.");
            return true;
        }

        switch (sub) {
            case "wand" -> {
                p.getInventory().addItem(wandListener.createWand());
                p.sendMessage(ChatColor.GREEN + "Dungeon wand dikasih. Klik kiri = titik 1, klik kanan = titik 2.");
            }
            case "create" -> {
                if (args.length < 2) { p.sendMessage(ChatColor.RED + "Pakai: /dungeon create <id>"); return true; }
                String id = args[1];
                if (manager.exists(id)) { p.sendMessage(ChatColor.RED + "Dungeon '" + id + "' udah ada."); return true; }
                manager.createDungeon(id);
                p.sendMessage(ChatColor.GREEN + "Dungeon '" + id + "' dibuat. Lanjut /dungeon wand -> /dungeon save " + id + " buat set region-nya.");
            }
            case "delete" -> {
                if (args.length < 2) { p.sendMessage(ChatColor.RED + "Pakai: /dungeon delete <id>"); return true; }
                String id = args[1];
                if (!manager.exists(id)) { p.sendMessage(ChatColor.RED + "Dungeon '" + id + "' gak ketemu."); return true; }
                manager.deleteDungeon(id);
                p.sendMessage(ChatColor.GREEN + "Dungeon '" + id + "' dihapus.");
            }
            case "save" -> {
                if (args.length < 2) { p.sendMessage(ChatColor.RED + "Pakai: /dungeon save <id>"); return true; }
                String id = args[1];
                Dungeon d = manager.get(id);
                if (d == null) { p.sendMessage(ChatColor.RED + "Dungeon '" + id + "' gak ketemu, /dungeon create dulu."); return true; }

                Location p1 = manager.getPoint1(p);
                Location p2 = manager.getPoint2(p);
                if (p1 == null || p2 == null) {
                    p.sendMessage(ChatColor.RED + "Set titik 1 & 2 dulu pakai /dungeon wand.");
                    return true;
                }
                if (!p1.getWorld().equals(p2.getWorld())) {
                    p.sendMessage(ChatColor.RED + "Titik 1 & 2 harus di world yang sama.");
                    return true;
                }

                d.setRegion(p1.getWorld(),
                        p1.getBlockX(), p1.getBlockY(), p1.getBlockZ(),
                        p2.getBlockX(), p2.getBlockY(), p2.getBlockZ());
                manager.save();
                manager.clearSelection(p);
                p.sendMessage(ChatColor.GREEN + "Region dungeon '" + id + "' disimpan & langsung ke-protect.");
            }
            case "setspawn" -> {
                if (args.length < 2) { p.sendMessage(ChatColor.RED + "Pakai: /dungeon setspawn <id>"); return true; }
                String id = args[1];
                Dungeon d = manager.get(id);
                if (d == null) { p.sendMessage(ChatColor.RED + "Dungeon '" + id + "' gak ketemu."); return true; }
                d.setSpawn(p.getLocation());
                manager.save();
                p.sendMessage(ChatColor.GREEN + "Titik teleport masuk dungeon '" + id + "' diset ke posisi kamu sekarang.");
            }
            case "list" -> {
                if (manager.getAll().isEmpty()) {
                    p.sendMessage(ChatColor.YELLOW + "Belum ada dungeon.");
                    return true;
                }
                p.sendMessage(ChatColor.YELLOW + "Daftar dungeon:");
                for (Dungeon d : manager.getAll()) {
                    String status = d.isPremium() ? ChatColor.GOLD + "premium (" + d.getPrice() + " " + d.getCurrency() + ")" : ChatColor.GREEN + "free";
                    String region = d.isRegionSet() ? ChatColor.GREEN + "region OK" : ChatColor.RED + "region belum diset";
                    String spawn = d.isSpawnSet() ? ChatColor.GREEN + "spawn OK" : ChatColor.RED + "spawn belum diset";
                    p.sendMessage(" - " + ChatColor.WHITE + d.getId() + ChatColor.GRAY + " | " + status + ChatColor.GRAY + " | " + region + ChatColor.GRAY + " | " + spawn);
                }
            }
            case "edit" -> p.openInventory(editGUI.buildList());
            case "shopedit" -> p.openInventory(shopEditGUI.buildList());
            default -> p.sendMessage(ChatColor.RED + "Subcommand gak dikenal. Pakai: /dungeon <wand|save|setspawn|create|delete|list|edit|shopedit>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        boolean isAdmin = sender.hasPermission("dungeon.admin");

        if (args.length == 1) {
            List<String> options = new ArrayList<>(List.of("shop"));
            if (isAdmin) options.addAll(ADMIN_SUBCOMMANDS);
            return options.stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (!isAdmin) return new ArrayList<>();

        if (args.length == 2 && List.of("save", "setspawn", "delete").contains(args[0].toLowerCase())) {
            return manager.getAll().stream()
                    .map(Dungeon::getId)
                    .filter(id -> id.startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
        }
        return new ArrayList<>();
    }
}
