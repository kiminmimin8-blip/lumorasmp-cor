package com.sanz.dungeon;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class DungeonEditGUI {

    private final DungeonManager manager;

    public DungeonEditGUI(DungeonManager manager) {
        this.manager = manager;
    }

    // ---------- LIST: semua dungeon + tombol create ----------

    public Inventory buildList() {
        List<Dungeon> all = new ArrayList<>(manager.getAll());
        all.sort(Comparator.comparing(Dungeon::getId));

        int size = Math.max(27, ((all.size() / 9) + 2) * 9);
        if (size > 54) size = 54;

        DungeonEditHolder holder = new DungeonEditHolder(DungeonEditHolder.Mode.LIST, null);
        Inventory inv = Bukkit.createInventory(holder, size, ChatColor.DARK_RED + "Edit Dungeon");
        holder.setInventory(inv);

        int slot = 0;
        for (Dungeon d : all) {
            if (slot >= size - 9) break;
            ItemStack item = new ItemStack(d.getDisplayItem());
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(ChatColor.AQUA + d.getDisplayName() + ChatColor.GRAY + " (" + d.getId() + ")");
            meta.setLore(List.of(
                    ChatColor.GRAY + (d.isPremium() ? "Premium - " + d.getPrice() + " " + d.getCurrency() : "Free"),
                    ChatColor.GRAY + "Region: " + (d.isRegionSet() ? "OK" : "belum"),
                    ChatColor.GRAY + "Spawn: " + (d.isSpawnSet() ? "OK" : "belum"),
                    "",
                    ChatColor.YELLOW + "Klik buat edit"
            ));
            item.setItemMeta(meta);
            inv.setItem(slot, item);
            holder.mapAction(slot, "open:" + d.getId());
            slot++;
        }

        // tombol create di slot terakhir
        ItemStack create = new ItemStack(Material.EMERALD);
        ItemMeta cm = create.getItemMeta();
        cm.setDisplayName(ChatColor.GREEN + "+ Buat dungeon baru");
        create.setItemMeta(cm);
        inv.setItem(size - 1, create);
        holder.mapAction(size - 1, "create");

        return inv;
    }

    // ---------- DETAIL: settings 1 dungeon ----------

    public Inventory buildDetail(Dungeon d) {
        DungeonEditHolder holder = new DungeonEditHolder(DungeonEditHolder.Mode.DETAIL, d.getId());
        Inventory inv = Bukkit.createInventory(holder, 27, ChatColor.DARK_RED + "Edit: " + d.getId());
        holder.setInventory(inv);

        // slot 10: toggle premium/free
        inv.setItem(10, named(
                d.isPremium() ? Material.GOLD_INGOT : Material.IRON_INGOT,
                d.isPremium() ? ChatColor.GOLD + "Premium (klik = jadi Free)" : ChatColor.GREEN + "Free (klik = jadi Premium)"
        ));
        holder.mapAction(10, "toggle_premium");

        // slot 11: harga (cuma relevan kalau premium)
        inv.setItem(11, named(Material.SUNFLOWER, ChatColor.YELLOW + "Harga: " + d.getPrice() + " " + d.getCurrency() + ChatColor.GRAY + " (klik utk ubah)"));
        holder.mapAction(11, "price");

        // slot 12: currency (cycle money -> cash -> shards)
        inv.setItem(12, named(Material.NETHER_STAR, ChatColor.LIGHT_PURPLE + "Currency: " + d.getCurrency() + ChatColor.GRAY + " (klik utk ganti)"));
        holder.mapAction(12, "cycle_currency");

        // slot 13: nama display
        inv.setItem(13, named(Material.NAME_TAG, ChatColor.AQUA + "Nama: " + d.getDisplayName() + ChatColor.GRAY + " (klik utk ubah)"));
        holder.mapAction(13, "name");

        // slot 14: deskripsi
        inv.setItem(14, named(Material.WRITABLE_BOOK, ChatColor.WHITE + "Deskripsi (klik utk ubah)"));
        holder.mapAction(14, "description");

        // slot 15: slot GUI teleport
        inv.setItem(15, named(Material.COMPASS, ChatColor.GRAY + "GUI slot: " + (d.getGuiSlot() < 0 ? "auto" : d.getGuiSlot()) + " (klik utk ubah)"));
        holder.mapAction(15, "slot");

        // slot 16: display item - klik sambil pegang item di cursor buat ganti
        ItemStack displayIcon = new ItemStack(d.getDisplayItem());
        ItemMeta dm = displayIcon.getItemMeta();
        dm.setDisplayName(ChatColor.GOLD + "Display item: " + d.getDisplayItem().name());
        dm.setLore(List.of(ChatColor.GRAY + "Pegang item di cursor lalu klik ini", ChatColor.GRAY + "buat ganti icon-nya"));
        displayIcon.setItemMeta(dm);
        inv.setItem(16, displayIcon);
        holder.mapAction(16, "display_item");

        // slot 22: delete
        inv.setItem(22, named(Material.TNT, ChatColor.RED + "Hapus dungeon ini" + ChatColor.GRAY + " (klik 2x)"));
        holder.mapAction(22, "delete");

        // slot 26: back
        inv.setItem(26, named(Material.ARROW, ChatColor.GRAY + "<- Kembali"));
        holder.mapAction(26, "back");

        return inv;
    }

    private ItemStack named(Material mat, String name) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        item.setItemMeta(meta);
        return item;
    }
}
