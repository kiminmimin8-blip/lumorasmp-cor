package com.sanz.dungeon;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DungeonShopGUI {

    public static class Holder implements InventoryHolder {
        private final Map<Integer, Integer> slotToTradeId = new HashMap<>();
        private Inventory inventory;
        public void setInventory(Inventory inv) { this.inventory = inv; }
        @Override public Inventory getInventory() { return inventory; }
        public void map(int slot, int tradeId) { slotToTradeId.put(slot, tradeId); }
        public Integer getTradeId(int slot) { return slotToTradeId.get(slot); }
    }

    private final DungeonShopManager shopManager;

    public DungeonShopGUI(DungeonShopManager shopManager) {
        this.shopManager = shopManager;
    }

    public Inventory build() {
        List<ShopTrade> ready = new ArrayList<>();
        for (ShopTrade t : shopManager.getAll()) if (t.isReady()) ready.add(t);

        int size = Math.max(27, ((ready.size() / 9) + 1) * 9);
        if (size > 54) size = 54;

        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, size, ChatColor.DARK_GREEN + "Dungeon Shop");
        holder.setInventory(inv);

        int slot = 0;
        for (ShopTrade t : ready) {
            if (slot >= size) break;

            // icon dipajang = item input1 asli (nama/lore/model data ikutan tampil persis kayak drop-nya)
            ItemStack icon = t.getInput1().clone();
            ItemMeta meta = icon.getItemMeta();

            String originalName = meta.hasDisplayName() ? meta.getDisplayName() : prettify(icon.getType().name());
            meta.setDisplayName(ChatColor.YELLOW + t.getLabel());

            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + "Butuh: " + t.getInput1().getAmount() + "x " + ChatColor.RESET + originalName);
            if (t.getInput2() != null) {
                String name2 = t.getInput2().hasItemMeta() && t.getInput2().getItemMeta().hasDisplayName()
                        ? t.getInput2().getItemMeta().getDisplayName()
                        : prettify(t.getInput2().getType().name());
                lore.add(ChatColor.GRAY + "         + " + t.getInput2().getAmount() + "x " + ChatColor.RESET + name2);
            }
            lore.add("");
            if (t.getOutputType() == ShopTrade.OutputType.MONEY) {
                lore.add(ChatColor.GREEN + "Dapat: " + t.getOutputMoney() + " " + t.getOutputCurrency());
            } else {
                ItemStack out = t.getOutput();
                String outName = out.hasItemMeta() && out.getItemMeta().hasDisplayName()
                        ? out.getItemMeta().getDisplayName()
                        : prettify(out.getType().name());
                lore.add(ChatColor.AQUA + "Dapat: " + out.getAmount() + "x " + ChatColor.RESET + outName);
                if (out.hasItemMeta() && !out.getItemMeta().getEnchants().isEmpty()) {
                    lore.add(ChatColor.LIGHT_PURPLE + "(full enchant)");
                }
            }
            lore.add("");
            lore.add(ChatColor.YELLOW + "Klik buat tukar");
            meta.setLore(lore);
            icon.setItemMeta(meta);

            inv.setItem(slot, icon);
            holder.map(slot, t.getId());
            slot++;
        }
        return inv;
    }

    private String prettify(String matName) {
        return matName.replace("_", " ").toLowerCase();
    }
}
