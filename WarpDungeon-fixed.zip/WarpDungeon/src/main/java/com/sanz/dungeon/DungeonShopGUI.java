package com.sanz.dungeon;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Merchant;
import org.bukkit.inventory.MerchantRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * GUI shop yang dibuka PLAYER.
 *
 * 1 dungeon bisa punya banyak kategori shop sekarang, jadi alurnya:
 * - kalau dungeon cuma punya 1 kategori -> langsung loncat ke window
 *   trading vanilla (Merchant) buat kategori itu.
 * - kalau lebih dari 1 -> muncul dulu GUI pemilihan kategori (custom
 *   inventory biasa, item-nya bisa dipasang di slot custom lewat
 *   /dungeon shopedit), klik salah satu baru masuk ke window trading-nya.
 */
public class DungeonShopGUI {

    public static final NamespacedKey VOUCHER_KEY = new NamespacedKey("audesdungeon", "money_voucher");
    public static final NamespacedKey VOUCHER_AMOUNT_KEY = new NamespacedKey("audesdungeon", "money_voucher_amount");
    public static final NamespacedKey VOUCHER_CURRENCY_KEY = new NamespacedKey("audesdungeon", "money_voucher_currency");

    public static class CategorySelectHolder implements InventoryHolder {
        private final String dungeonId;
        private final Map<Integer, String> slotToCategoryId = new HashMap<>();
        private Inventory inventory;

        public CategorySelectHolder(String dungeonId) { this.dungeonId = dungeonId; }
        public void setInventory(Inventory inv) { this.inventory = inv; }
        @Override public Inventory getInventory() { return inventory; }
        public String getDungeonId() { return dungeonId; }
        public void map(int slot, String categoryId) { slotToCategoryId.put(slot, categoryId); }
        public String getCategoryId(int slot) { return slotToCategoryId.get(slot); }
    }

    public DungeonShopGUI() {
    }

    /** null artinya: langsung dibukain Merchant kategori tunggal (gak perlu GUI pemilihan kategori). */
    public Inventory buildCategorySelect(DungeonShop shop) {
        List<ShopCategory> cats = shop.getCategories();
        int size = Math.max(9, ((cats.size() / 9) + 1) * 9);
        if (size > 54) size = 54;

        CategorySelectHolder holder = new CategorySelectHolder(shop.getDungeonId());
        Inventory inv = Bukkit.createInventory(holder, size, ChatColor.DARK_GREEN + "Dungeon Shop - Pilih Kategori");
        holder.setInventory(inv);

        int autoSlot = 0;
        for (ShopCategory cat : cats) {
            int slot = cat.getSelectSlot();
            if (slot < 0 || slot >= size || inv.getItem(slot) != null) {
                while (autoSlot < size && inv.getItem(autoSlot) != null) autoSlot++;
                slot = autoSlot;
            }
            if (slot >= size) continue;

            ItemStack icon = cat.getIcon().clone();
            ItemMeta meta = icon.getItemMeta();
            meta.setDisplayName(ChatColor.YELLOW + "" + ChatColor.BOLD + cat.getLabel());
            meta.setLore(List.of(
                    ChatColor.GRAY + "" + cat.readyCount() + " trade tersedia",
                    "",
                    ChatColor.YELLOW + "Klik buat buka"
            ));
            icon.setItemMeta(meta);

            inv.setItem(slot, icon);
            holder.map(slot, cat.getId());
        }
        return inv;
    }

    public Merchant buildMerchant(ShopCategory category) {
        Merchant merchant = Bukkit.createMerchant(ChatColor.DARK_GREEN + category.getLabel());

        List<MerchantRecipe> recipes = new ArrayList<>();
        for (ShopTrade t : category.getTradesSorted()) {
            if (!t.isReady()) continue;

            ItemStack result = t.getOutputType() == ShopTrade.OutputType.ITEM
                    ? t.buildOutputItem()
                    : buildVoucher(t.getOutputMoney(), t.getOutputCurrency());

            MerchantRecipe recipe = new MerchantRecipe(result, 0, 999999, false, 0, 0f);

            List<ItemStack> ingredients = new ArrayList<>();
            ingredients.add(t.buildInput1());
            if (t.buildInput2() != null) ingredients.add(t.buildInput2());
            recipe.setIngredients(ingredients);

            recipes.add(recipe);
        }

        merchant.setRecipes(recipes);
        return merchant;
    }

    /**
     * Item "voucher" buat trade mode MONEY. Vanilla trading cuma bisa
     * nukerin item ke item, gak bisa langsung nambahin saldo - jadi hasil
     * trade-nya berupa kertas voucher, terus DungeonShopVoucherListener yang
     * nangkep pas voucher ini kesentuh di inventory & otomatis nuker jadi
     * saldo asli + ilangin vouchernya.
     */
    private ItemStack buildVoucher(double amount, String currency) {
        ItemStack item = new ItemStack(Material.PAPER, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "Voucher " + amount + " " + currency);
        meta.setLore(List.of(
                ChatColor.GRAY + "Otomatis ketuker jadi saldo",
                ChatColor.GRAY + "begitu masuk inventory kamu."
        ));
        meta.getPersistentDataContainer().set(VOUCHER_KEY, PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(VOUCHER_AMOUNT_KEY, PersistentDataType.DOUBLE, amount);
        meta.getPersistentDataContainer().set(VOUCHER_CURRENCY_KEY, PersistentDataType.STRING, currency);
        item.setItemMeta(meta);
        return item;
    }
}
