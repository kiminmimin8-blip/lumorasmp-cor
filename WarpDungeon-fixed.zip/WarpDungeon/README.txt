SanzDungeon - plugin standalone (BUKAN bagian dari SanzCore, jar sendiri)
============================================================

CARA PAKAI:
1. Push folder ini ke repo GitHub baru (terpisah dari SanzCore), workflow di
   .github/workflows/build.yml otomatis compile tiap push ke branch main.
2. Ambil jar hasil build dari tab Actions -> artifact "SanzDungeon".
3. Taro SanzDungeon.jar + Vault.jar di folder plugins/ server.
4. Restart server. File data (dungeons.yml, shop.yml) otomatis dibuat di
   plugins/SanzDungeon/.

COMMAND:
  /dungeon              -> GUI teleport (semua player, free & premium)
  /dungeon shop         -> shop dungeon tempat kamu berdiri (semua player)
  /dungeon wand         -> [admin] ambil axe buat select region
  /dungeon save <id>    -> [admin] simpen region jadi world border dungeon itu
  /dungeon setspawn <id>-> [admin] set titik teleport masuk dungeon
  /dungeon create <id>  -> [admin] bikin dungeon baru
  /dungeon delete <id>  -> [admin] hapus dungeon
  /dungeon list         -> [admin] daftar semua dungeon + status
  /dungeon edit         -> [admin] GUI setting dungeon (nama, harga, premium, dll)
  /dungeon shopedit [id]-> [admin] GUI kategori+trade shop 1 dungeon (tanpa id
                            = dungeon tempat kamu berdiri)
  /dungeon shopreload   -> [admin] reload shop.yml dari disk tanpa restart

PERMISSION:
  dungeon.admin  -> akses semua command admin di atas (default: op)
  dungeon.bypass -> bypass proteksi region (default: op)
  dungeon.free   -> teleport gratis walau dungeon premium (default: op)

CATATAN PENTING:
- Ini JAR TERPISAH dari SanzCore. Kalau ternyata lebih enak digabung jadi satu
  modul di dalam SanzCore lagi, source-nya sama persis, tinggal pindahin
  folder src/main/java/com/sanz/dungeon ke dalam project SanzCore dan panggil
  bagian onEnable() di SanzDungeonPlugin.java dari onEnable() SanzCore.
- Currency "cash" & "shards" masih stub di DungeonCurrencyProvider.java,
  nunggu sistem multi-currency SanzCore beneran jadi baru disambungin.
- Shop editor pake slot inventory beneran (bukan command) - keterbatasan:
  drag-multi-slot ke slot input/output belum ditangani khusus, disaranin
  taro item satu-satu / pake klik biasa aja biar aman.
- Belum ada integrasi otomatis ke drop table MythicMobs - trade shop diisi
  manual lewat /dungeon shopedit.

UPDATE (fix border + shop) - 2026-08-20:
- Target server disamain ke Paper 1.21.11 (pom.xml).
- FIX: world border dungeon sebelumnya emang gak pernah beneran dipasang -
  region cuma dipakai buat proteksi block break/place/pvp/dll, gak pernah
  di-apply jadi WorldBorder asli. Sekarang tiap player masuk dungeon otomatis
  dikasih per-player WorldBorder (Bukkit.createWorldBorder()) sesuai ukuran
  region, dan direset balik pas keluar/quit/relog. Border ini murni visual
  (warning distance & damage 0), gak nahan/nge-damage - proteksi keluar-masuk
  dungeon tetep dari checkRegion() kayak sebelumnya.
- SHOP DIROMBAK TOTAL: trade sekarang nyimpen ItemStack UTUH (bukan cuma
  Material+jumlah), jadi enchant/nama custom/lore/custom-model-data ikut
  kesimpen persis. Slot input sekarang ADA 2 (item1 + item2), sama kayak GUI
  trade Shopkeeper villager admin yang lagi jalan sekarang.
- shop.yml default (dibuat sekali doang pas belum ada file-nya) diisi 8 trade
  yang samain persis (nama, lore, custom model data, tag mythicmobs:type di
  PDC) sama shopkeeper admin: Fragmen Relik Tanah / Inti Bara Nyala / Debu
  Abyssal Crawler -> Arrow/Door/Hay Bale/Golden Carrot/Wind Charge/Diamond/
  Kelenjar Racun Purba, plus 4 trade tambahan armor DIAMOND full-enchant
  (protection 4, unbreaking 3, mending; helm +respiration 3 +aqua affinity;
  boots +feather falling 4 +depth strider 3; leggings +swift sneak 3).
- Karena item drop MythicMobs punya NBT sendiri-sendiri, buat exact-match
  100% ke drop asli tinggal ambil barangnya di game (misal /mm item give)
  terus taro ke slot lewat /dungeon shopedit, klik SIMPAN - gak perlu edit
  kode lagi. Begitu juga kalau mau ganti hadiah/harga trade apa aja, semua
  bisa diedit langsung in-game dari GUI itu.

UPDATE 2 (GUI shop disamain PERSIS ke Shopkeeper) - 2026-08-22:
- FIX: /dungeon shop sebelumnya buka custom GUI grid biasa (klik icon =
  langsung kebeli) - makanya tampilannya beda sama GUI Shopkeeper walau
  fungsinya udah mirip. Sekarang dipakein Bukkit Merchant API ASLI
  (Bukkit.createMerchant + MerchantRecipe, dibuka lewat player.openMerchant),
  jadi window yang kebuka itu PERSIS window trading vanilla - sama kayak
  yang dipake Shopkeeper (list trade + panel item1+item2 -> panah -> hasil,
  drag item lalu klik slot hasil). Bukan tiruan/mirip-mirip lagi, beneran
  GUI bawaan game.
- Konsekuensinya: DungeonShopListener (yang dulu manual ngurusin ambil
  item & kasih hasil) UDAH GAK DIPAKE buat trade item - itu semua sekarang
  otomatis ditangani vanilla (server yang motong ingredient & ngasih hasil,
  gak ada logic custom lagi, jadi lebih ringan & gak mungkin ada bug urutan
  ambil-item-vs-kasih-hasil kayak sebelumnya).
- Trade mode MONEY (bukan ITEM) masih butuh sedikit trik, soalnya trading
  vanilla cuma bisa nuker item ke item, gak bisa langsung nambah saldo.
  Buat itu, hasil trade-nya berupa item "voucher" kertas, dan listener baru
  (DungeonShopVoucherListener) otomatis nangkep begitu voucher itu masuk
  inventory pemain, langsung ilangin vouchernya & nambahin saldo asli.
  Voucher gak akan pernah nyangkut lama di inventory pemain.
- ShopEditGUI (/dungeon shopedit, punya admin) TETEP custom GUI kayak
  sebelumnya - gak dipindah ke Merchant API, soalnya Merchant API gak
  ngedukung mode "edit ingredient/hasil sambil liat preview" yang dibutuhin
  admin. Cuma tampilan buat PLAYER yang belanja (/dungeon shop) yang diganti.

UPDATE 3 (shop dirombak jadi per-dungeon + kategori, full CRUD) - 2026-08-25:
- Shop SEBELUMNYA cuma 1 daftar trade GLOBAL buat semua dungeon. Sekarang
  PER-DUNGEON, dan 1 dungeon bisa punya BANYAK KATEGORI (misal "Armor",
  "Senjata", "Tukar Fragmen") - tiap kategori punya daftar trade sendiri.
- Command:
    /dungeon shop            -> shop dungeon TEMPAT KAMU BERDIRI SEKARANG.
                                 Kalau cuma 1 kategori, langsung ke window
                                 trading. Kalau lebih, muncul GUI pilih
                                 kategori dulu.
    /dungeon shopedit [id]   -> tanpa id = edit shop dungeon tempat kamu
                                 berdiri, atau kasih id manual buat edit
                                 dungeon lain dari mana aja.
    /dungeon shopreload      -> reload shop.yml dari disk tanpa restart
                                 server (buat kalau edit manual file-nya).
- ShopEditGUI sekarang 4 tingkat: daftar kategori -> detail kategori
  (rename/hapus/ganti icon/atur slot pilih) -> daftar trade dalam kategori
  itu -> detail 1 trade (persis kayak sebelumnya, + kontrol urutan/slot).
- FITUR BARU shopedit:
  - Kategori: buat baru (+ Kategori baru), RENAME (klik nametag, ketik di
    chat), HAPUS (klik TNT 2x buat konfirmasi, semua trade di dalamnya ikut
    kehapus), ganti ICON (taro item apa aja di slot icon + SIMPAN), atur
    SLOT tampil di GUI pemilihan kategori pemain (custom slot, -1 = auto).
  - Trade: RENAME & HAPUS udah ada dari sebelumnya, sekarang ditambah
    kontrol "urutan/slot" (+1/-1) buat ngatur posisi tampil trade itu di
    dalam window trading kategorinya.
  - /dungeon shopreload buat reload tanpa restart.
- Tiap dungeon yang belum pernah punya shop bakal otomatis di-seed 2
  kategori pas pertama kali /dungeon shop atau /dungeon shopedit dipake di
  situ: "Umum" (7 trade fragmen -> item biasa) dan "Armor" (4 trade armor
  diamond full-enchant). Semua itemnya masih PLACEHOLDER (nama/lore/model
  data mirip item MythicMobs tapi bukan clone byte-perfect) - dikasih lore
  merah "[CONTOH - ganti pake item MythicMobs asli]" biar keliatan mana yg
  masih perlu diganti. Tinggal /mm item give barang aslinya, taro ke slot
  input/output lewat shopedit, klik SIMPAN.

UPDATE 4 (/back dihapus, command & fitur dibatasi di dalam dungeon) - 2026-08-25:
- /back DIHAPUS TOTAL. DungeonBackManager.java & DungeonBackCommand.java
  ikut kehapus, command "back" gak ke-register lagi dari plugin ini. Kalau
  ada plugin lain (Essentials dll) yang punya /back sendiri, itu tetap
  DIBLOKIR selama player masih di dalam dungeon (masuk BLOCKED_COMMANDS).
- Command yang diblokir sekarang selama di dalam dungeon (BLOCKED_COMMANDS
  di DungeonProtectionListener): teleport/tp/tpa/tpaccept/tpahere,
  sethome/setwarp/warp, teamwarp/tw, tpauto, claim, trade, back.
- KHUSUS /team - cuma subcommand "/team sethome" & "/team setwarp" yang
  diblok, subcommand /team lainnya (invite/chat/dll) tetep bisa dipakai
  normal.
- Enderpearl: udah diblok dari sebelumnya (ProjectileLaunchEvent), sekarang
  aturannya diperketat - kalau shooter-nya BUKAN player (misal dispenser),
  tetep diblok juga selama posisinya di dalam dungeon (sebelumnya cuma
  ngeblok lemparan dari player).
- Elytra: udah diblok dari sebelumnya (EntityToggleGlideEvent, gliding
  dibatalin begitu masuk dungeon).
- Firework BARU diblok - baik make firework rocket di tangan (buat boost
  elytra) maupun firework yang di-launch dari sumber lain (dispenser dll)
  selama di dalam dungeon, dua-duanya dicegah.
- Mob spawn BARU dibatasin - CreatureSpawnEvent dicek metadata "MythicMobs"
  (metadata bawaan yang dipasang MythicMobs ke semua mob custom-nya). Kalau
  metadata itu gak ada DAN lokasinya di dalam region dungeon, spawn-nya
  dibatalin. Jadi mob vanilla/natural/spawner/egg biasa gak bisa muncul di
  dalam dungeon, cuma mob dari MythicMobs yang boleh.

UPDATE 5 (bug spawner MythicMobs + config.yml) - 2026-08-27:
- FIX BUG: mob dari MythicMobs gak keluar sama sekali dari spawner. Root
  cause: metadata "MythicMobs" itu dipasang MythicMobs SETELAH
  World.spawn(...) yang ngasilin CreatureSpawnEvent kelar - bukan pas
  event-nya masih berjalan. Kode lama ngecek metadata itu & langsung cancel
  DI DALAM event yang sama, jadi mob MythicMobs asli pun ikut kebatalin
  (belum sempet ke-tag). Fix: onCreatureSpawn sekarang GAK cancel langsung -
  ditunda 1 tick (pake entity.getScheduler().runDelayed, Folia-safe), baru
  dicek ulang metadata-nya; kalau di titik itu masih belum ke-tag, baru
  entity-nya di-remove().
- CONFIG.YML BARU - sebelumnya SEMUA setting (waktu dungeon, world border,
  proteksi mana yang nyala, daftar command yang diblokir, currency shop,
  pesan-pesan) ke-hardcode di kode Java, jadi harus compile ulang tiap mau
  ubah apa-apa. Sekarang semua itu ada di src/main/resources/config.yml,
  diedit dari panel langsung, terus tinggal /dungeon reload (gak perlu
  restart server). Yang bisa diatur dari config.yml:
    dungeon-time              - waktu yg diset pas masuk dungeon
    world-border.*            - warning-distance/time, damage-amount/buffer
    protection.block-break/place, allow-pvp, explosion-damage-block,
      block-enderpearl, block-elytra, block-firework, only-mythicmobs-spawn
    blocked-commands          - list command yg diblok di dalam dungeon
    blocked-team-subcommands  - subcommand /team yg diblok (sethome, setwarp)
    shop-currencies           - pilihan currency buat trade mode MONEY
    messages.*                - semua pesan ke player, pake kode warna &
- Command baru: /dungeon reload -> reload config.yml dari disk. Beda sama
  /dungeon shopreload yang reload shop.yml - dua-duanya independen, bisa
  dipake sendiri-sendiri.
- WarpDungeonConfig.java (kelas baru) yang baca/cache config.yml, dipass ke
  DungeonProtectionListener, DungeonCommand, dan ShopEditListener - jadi
  semua bagian yg tadinya hardcode sekarang narik dari 1 sumber yang sama.
