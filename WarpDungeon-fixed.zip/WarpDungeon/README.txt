SanzDungeon - plugin standalone (BUKAN bagian dari SanzCore, jar sendiri)
============================================================

CARA PAKAI:
1. Push folder ini ke repo GitHub baru (terpisah dari SanzCore), workflow di
   .github/workflows/build.yml otomatis compile tiap push ke branch main.
2. Ambil jar hasil build dari tab Actions -> artifact "SanzDungeon".
3. Taro SanzDungeon.jar + Vault.jar di folder plugins/ server.
4. Restart server. File data (dungeons.yml, shop.yml) otomatis dibuat di
   plugins/SanzDungeon/.

COMMAND:
  /dungeon              -> GUI teleport (semua player, free & premium)
  /dungeon shop         -> GUI belanja tukar drop item (semua player)
  /dungeon wand         -> [admin] ambil axe buat select region
  /dungeon save <id>    -> [admin] simpen region jadi world border dungeon itu
  /dungeon setspawn <id>-> [admin] set titik teleport masuk dungeon
  /dungeon create <id>  -> [admin] bikin dungeon baru
  /dungeon delete <id>  -> [admin] hapus dungeon
  /dungeon list         -> [admin] daftar semua dungeon + status
  /dungeon edit         -> [admin] GUI setting dungeon (nama, harga, premium, dll)
  /dungeon shopedit     -> [admin] GUI setting trade shop, kayak GUI villager -
                            taro item request di slot kiri, item/uang hasil di
                            slot kanan, klik SIMPAN
  /back                 -> balik ke dungeon dalam window 2 menit setelah keluar

PERMISSION:
  dungeon.admin  -> akses semua command admin di atas (default: op)
  dungeon.bypass -> bypass proteksi region (default: op)
  dungeon.free   -> teleport gratis walau dungeon premium (default: op)

CATATAN PENTING:
- Ini JAR TERPISAH dari SanzCore. Kalau ternyata lebih enak digabung jadi satu
  modul di dalam SanzCore lagi, source-nya sama persis, tinggal pindahin
  folder src/main/java/com/sanz/dungeon ke dalam project SanzCore dan panggil
  bagian onEnable() di SanzDungeonPlugin.java dari onEnable() SanzCore.
- Currency "cash" & "shards" masih stub di DungeonCurrencyProvider.java,
  nunggu sistem multi-currency SanzCore beneran jadi baru disambungin.
- Shop editor pake slot inventory beneran (bukan command) - keterbatasan:
  drag-multi-slot ke slot input/output belum ditangani khusus, disaranin
  taro item satu-satu / pake klik biasa aja biar aman.
- Belum ada integrasi otomatis ke drop table MythicMobs - trade shop diisi
  manual lewat /dungeon shopedit.

UPDATE (fix border + shop) - 2026-08-20:
- Target server disamain ke Paper 1.21.11 (pom.xml).
- FIX: world border dungeon sebelumnya emang gak pernah beneran dipasang -
  region cuma dipakai buat proteksi block break/place/pvp/dll, gak pernah
  di-apply jadi WorldBorder asli. Sekarang tiap player masuk dungeon otomatis
  dikasih per-player WorldBorder (Bukkit.createWorldBorder()) sesuai ukuran
  region, dan direset balik pas keluar/quit/relog. Border ini murni visual
  (warning distance & damage 0), gak nahan/nge-damage - proteksi keluar-masuk
  dungeon tetep dari checkRegion() kayak sebelumnya.
- SHOP DIROMBAK TOTAL: trade sekarang nyimpen ItemStack UTUH (bukan cuma
  Material+jumlah), jadi enchant/nama custom/lore/custom-model-data ikut
  kesimpen persis. Slot input sekarang ADA 2 (item1 + item2), sama kayak GUI
  trade Shopkeeper villager admin yang lagi jalan sekarang.
- shop.yml default (dibuat sekali doang pas belum ada file-nya) diisi 8 trade
  yang samain persis (nama, lore, custom model data, tag mythicmobs:type di
  PDC) sama shopkeeper admin: Fragmen Relik Tanah / Inti Bara Nyala / Debu
  Abyssal Crawler -> Arrow/Door/Hay Bale/Golden Carrot/Wind Charge/Diamond/
  Kelenjar Racun Purba, plus 4 trade tambahan armor DIAMOND full-enchant
  (protection 4, unbreaking 3, mending; helm +respiration 3 +aqua affinity;
  boots +feather falling 4 +depth strider 3; leggings +swift sneak 3).
- Karena item drop MythicMobs punya NBT sendiri-sendiri, buat exact-match
  100% ke drop asli tinggal ambil barangnya di game (misal /mm item give)
  terus taro ke slot lewat /dungeon shopedit, klik SIMPAN - gak perlu edit
  kode lagi. Begitu juga kalau mau ganti hadiah/harga trade apa aja, semua
  bisa diedit langsung in-game dari GUI itu.
