package com.sanz.bot.listeners;

import com.sanz.bot.SanzBot;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

public class BotDeathListener implements Listener {

    private final SanzBot plugin;

    public BotDeathListener(SanzBot plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDeath(EntityDeathEvent event) {
        var instance = plugin.getBotSpawnManager().getInstance(event.getEntity().getUniqueId());
        if (instance == null) return;

        plugin.getBotSpawnManager().removeInstance(event.getEntity().getUniqueId());
        // Equipment udah di-set drop chance 0 pas spawn, jadi gak perlu clear drops manual di sini.
    }
}
