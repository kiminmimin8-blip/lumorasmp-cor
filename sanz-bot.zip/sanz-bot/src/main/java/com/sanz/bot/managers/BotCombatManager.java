package com.sanz.bot.managers;

import com.sanz.bot.SanzBot;
import com.sanz.bot.model.BotDefinition;
import com.sanz.bot.model.BotInstance;
import com.sanz.bot.model.BotSkill;
import com.sanz.bot.model.BotType;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.List;
import java.util.Map;
import java.util.logging.Level;

/**
 * Loop AI berkala buat semua bot aktif: nyari target terdekat (real vanilla AI
 * yang ngurus gerak/serang begitu target di-set), plus behavior tambahan sesuai
 * jenis bot (CPvP crystal combo, MYTHIC skill list).
 */
public class BotCombatManager {

    private final SanzBot plugin;
    private BukkitRunnable task;

    public BotCombatManager(SanzBot plugin) {
        this.plugin = plugin;
    }

    public void start() {
        long interval = plugin.getConfig().getLong("combat-tick-interval", 4);

        task = new BukkitRunnable() {
            @Override
            public void run() {
                tickAll();
            }
        };
        task.runTaskTimer(plugin, interval, interval);
    }

    public void stop() {
        if (task != null) {
            task.cancel();
        }
    }

    private void tickAll() {
        long currentTick = plugin.getServer().getCurrentTick();
        double detectionRadius = plugin.getConfig().getDouble("detection-radius", 16.0);

        for (Map.Entry<java.util.UUID, BotInstance> entry : plugin.getBotSpawnManager().getActiveBots().entrySet()) {
            try {
                Entity entity = plugin.getServer().getEntity(entry.getKey());
                if (!(entity instanceof LivingEntity living) || living.isDead()) {
                    plugin.getBotSpawnManager().removeInstance(entry.getKey());
                    continue;
                }

                BotInstance instance = entry.getValue();
                BotDefinition def = plugin.getBotDefinitionManager().get(instance.getDefinitionName());
                if (def == null) continue;

                Player target = findNearestPlayer(living.getLocation(), detectionRadius);

                if (living instanceof Mob mob) {
                    mob.setTarget(target);
                }

                if (target == null) continue;

                if (def.getType() == BotType.CPVP) {
                    handleCrystalCombo(living, instance, target, currentTick);
                } else if (def.getType() == BotType.MYTHIC) {
                    handleMythicSkills(living, instance, def, target, currentTick);
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Error di combat loop bot", e);
            }
        }
    }

    private Player findNearestPlayer(Location loc, double radius) {
        Player nearest = null;
        double nearestDistSq = radius * radius;
        for (Player p : loc.getWorld().getPlayers()) {
            if (p.getGameMode() == org.bukkit.GameMode.CREATIVE || p.getGameMode() == org.bukkit.GameMode.SPECTATOR) continue;
            double distSq = p.getLocation().distanceSquared(loc);
            if (distSq <= nearestDistSq) {
                nearest = p;
                nearestDistSq = distSq;
            }
        }
        return nearest;
    }

    /** CPvP bot: kalau target udah deket, taruh end crystal & langsung ledakin buat burst damage. */
    private void handleCrystalCombo(LivingEntity bot, BotInstance instance, Player target, long currentTick) {
        double triggerRange = plugin.getConfig().getDouble("cpvp.trigger-range", 4.0);
        if (bot.getLocation().distance(target.getLocation()) > triggerRange) return;
        if (!instance.isCrystalComboReady(currentTick)) return;

        long cooldown = plugin.getConfig().getLong("cpvp.cooldown-ticks", 60);
        double damage = plugin.getConfig().getDouble("cpvp.damage", 24.0);

        Location crystalLoc = target.getLocation().clone().add(0, 0.5, 0);
        EnderCrystal crystal = target.getWorld().spawn(crystalLoc, EnderCrystal.class);
        crystal.setInvulnerable(true);
        crystal.setShowingBottom(false);

        // "Ledakin" langsung di tick berikutnya - efek visual + damage manual ke player dalam radius kecil
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (crystal.isValid()) {
                crystal.remove();
            }
            target.getWorld().spawnParticle(Particle.EXPLOSION, crystalLoc, 1);
            target.getWorld().playSound(crystalLoc, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);

            for (Entity nearby : target.getWorld().getNearbyEntities(crystalLoc, 3, 3, 3)) {
                if (nearby instanceof Player p) {
                    p.damage(damage, bot);
                }
            }
        }, 4L);

        instance.setNextCrystalCombo(currentTick + cooldown);
    }

    private void handleMythicSkills(LivingEntity bot, BotInstance instance, BotDefinition def, Player target, long currentTick) {
        List<BotSkill> skills = def.getSkills();
        for (int i = 0; i < skills.size(); i++) {
            BotSkill skill = skills.get(i);
            if (skill.getTrigger() != BotSkill.Trigger.ON_TIMER) continue;
            if (instance.isSkillOnCooldown(i, currentTick)) continue;

            executeSkill(bot, target, skill);
            instance.setSkillCooldown(i, currentTick + skill.getCooldownTicks());
        }
    }

    /** Dipanggil listener luar (attack/damaged event) buat skill trigger ON_ATTACK/ON_DAMAGED. */
    public void tryTriggerSkills(LivingEntity bot, BotInstance instance, BotDefinition def, Player target, BotSkill.Trigger trigger) {
        long currentTick = plugin.getServer().getCurrentTick();
        List<BotSkill> skills = def.getSkills();
        for (int i = 0; i < skills.size(); i++) {
            BotSkill skill = skills.get(i);
            if (skill.getTrigger() != trigger) continue;
            if (instance.isSkillOnCooldown(i, currentTick)) continue;

            executeSkill(bot, target, skill);
            instance.setSkillCooldown(i, currentTick + skill.getCooldownTicks());
        }
    }

    private void executeSkill(LivingEntity bot, Player target, BotSkill skill) {
        switch (skill.getEffect()) {
            case DAMAGE -> {
                if (target != null) target.damage(skill.getAmount(), bot);
            }
            case HEAL -> {
                var maxHealthAttr = bot.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH);
                double maxHealth = maxHealthAttr != null ? maxHealthAttr.getValue() : bot.getHealth();
                double newHealth = Math.min(bot.getHealth() + skill.getAmount(), maxHealth);
                bot.setHealth(newHealth);
            }
            case POTION -> {
                if (target != null) {
                    try {
                        PotionEffectType type = PotionEffectType.getByName(skill.getPotionType());
                        if (type != null) {
                            target.addPotionEffect(new PotionEffect(type, skill.getPotionDuration(), skill.getPotionAmplifier()));
                        }
                    } catch (Exception ignored) {
                    }
                }
            }
            case PARTICLE_SOUND -> {
                try {
                    Particle particle = Particle.valueOf(skill.getParticleName());
                    bot.getWorld().spawnParticle(particle, bot.getLocation().add(0, 1, 0), 20);
                } catch (Exception ignored) {
                }
                try {
                    Sound sound = Sound.valueOf(skill.getSoundName());
                    bot.getWorld().playSound(bot.getLocation(), sound, 1f, 1f);
                } catch (Exception ignored) {
                }
            }
        }
    }
}
