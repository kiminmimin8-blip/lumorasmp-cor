package com.sanz.bot.model;

public enum BotType {
    PVP,
    CPVP,
    MYTHIC;

    public static BotType fromString(String s) {
        for (BotType t : values()) {
            if (t.name().equalsIgnoreCase(s)) return t;
        }
        return null;
    }
}
