package com.sanz.bot.model;

/**
 * Satu skill sederhana buat bot tipe MYTHIC. Mirip konsep skill MythicMobs tapi
 * versi ringkas, effect terbatas ke beberapa tipe yang paling sering dipakai.
 */
public class BotSkill {

    public enum Trigger {
        ON_ATTACK, ON_TIMER, ON_DAMAGED, ON_DEATH
    }

    public enum Effect {
        DAMAGE, HEAL, POTION, PARTICLE_SOUND
    }

    private final Trigger trigger;
    private final Effect effect;
    private final int cooldownTicks;
    private final double amount;      // dipakai buat DAMAGE/HEAL
    private final String potionType;  // dipakai buat POTION (nama PotionEffectType)
    private final int potionDuration; // ticks
    private final int potionAmplifier;
    private final String particleName; // dipakai buat PARTICLE_SOUND
    private final String soundName;

    public BotSkill(Trigger trigger, Effect effect, int cooldownTicks, double amount,
                     String potionType, int potionDuration, int potionAmplifier,
                     String particleName, String soundName) {
        this.trigger = trigger;
        this.effect = effect;
        this.cooldownTicks = cooldownTicks;
        this.amount = amount;
        this.potionType = potionType;
        this.potionDuration = potionDuration;
        this.potionAmplifier = potionAmplifier;
        this.particleName = particleName;
        this.soundName = soundName;
    }

    public Trigger getTrigger() {
        return trigger;
    }

    public Effect getEffect() {
        return effect;
    }

    public int getCooldownTicks() {
        return cooldownTicks;
    }

    public double getAmount() {
        return amount;
    }

    public String getPotionType() {
        return potionType;
    }

    public int getPotionDuration() {
        return potionDuration;
    }

    public int getPotionAmplifier() {
        return potionAmplifier;
    }

    public String getParticleName() {
        return particleName;
    }

    public String getSoundName() {
        return soundName;
    }
}
