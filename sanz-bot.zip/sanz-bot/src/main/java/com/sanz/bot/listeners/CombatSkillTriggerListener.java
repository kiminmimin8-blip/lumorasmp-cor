package com.sanz.bot.listeners;

import com.sanz.bot.SanzBot;
import com.sanz.bot.model.BotDefinition;
import com.sanz.bot.model.BotInstance;
import com.sanz.bot.model.BotSkill;
import com.sanz.bot.model.BotType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

/**
 * Trigger skill MYTHIC yang tipe ON_ATTACK (bot yang mukul) dan ON_DAMAGED (bot yang kena hit).
 * Skill ON_TIMER ditangani terpisah di BotCombatManager (loop berkala).
 */
public class CombatSkillTriggerListener implements Listener {

    private final SanzBot plugin;

    public CombatSkillTriggerListener(SanzBot plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDamage(EntityDamageByEntityEvent event) {
        // Bot yang MUKUL player -> trigger ON_ATTACK
        if (event.getDamager() instanceof LivingEntity damager && event.getEntity() instanceof Player victim) {
            BotInstance instance = plugin.getBotSpawnManager().getInstance(damager.getUniqueId());
            if (instance != null) {
                BotDefinition def = plugin.getBotDefinitionManager().get(instance.getDefinitionName());
                if (def != null && def.getType() == BotType.MYTHIC) {
                    plugin.getBotCombatManager().tryTriggerSkills(damager, instance, def, victim, BotSkill.Trigger.ON_ATTACK);
                }
            }
        }

        // Bot yang KENA HIT sama player -> trigger ON_DAMAGED
        if (event.getEntity() instanceof LivingEntity victimEntity && event.getDamager() instanceof Player attacker) {
            BotInstance instance = plugin.getBotSpawnManager().getInstance(victimEntity.getUniqueId());
            if (instance != null) {
                BotDefinition def = plugin.getBotDefinitionManager().get(instance.getDefinitionName());
                if (def != null && def.getType() == BotType.MYTHIC) {
                    plugin.getBotCombatManager().tryTriggerSkills(victimEntity, instance, def, attacker, BotSkill.Trigger.ON_DAMAGED);
                }
            }
        }
    }
}
