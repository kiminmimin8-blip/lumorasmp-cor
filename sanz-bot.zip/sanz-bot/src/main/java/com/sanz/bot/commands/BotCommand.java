package com.sanz.bot.commands;

import com.sanz.bot.SanzBot;
import com.sanz.bot.model.BotDefinition;
import com.sanz.bot.model.BotType;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class BotCommand implements CommandExecutor, TabCompleter {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private static final List<String> SUB_COMMANDS = List.of(
            "spawn", "spawner", "edit", "rename", "skin", "list", "remove"
    );
    private static final List<String> TYPES = List.of("pvp", "cpvp", "mythic");

    private final SanzBot plugin;

    public BotCommand(SanzBot plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (!player.hasPermission("sanzbot.admin")) {
            player.sendMessage(LEGACY.deserialize("&cKamu gak punya izin buat command ini."));
            return true;
        }

        if (args.length == 0) {
            plugin.getBotGUI().openList(player);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "spawn" -> handleSpawn(player, args);
            case "spawner" -> handleSpawner(player, args);
            case "edit" -> handleEdit(player, args);
            case "rename" -> handleRename(player, args);
            case "skin" -> handleSkin(player, args);
            case "list" -> handleList(player);
            case "remove" -> handleRemove(player, args);
            default -> sendUsage(player);
        }
        return true;
    }

    private void handleSpawn(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(LEGACY.deserialize("&cUsage: /bot spawn <name_bot>"));
            return;
        }
        BotDefinition def = plugin.getBotDefinitionManager().get(args[1]);
        if (def == null) {
            player.sendMessage(LEGACY.deserialize("&cBot &f" + args[1] + " &cgak ketemu. Bikin dulu pakai /bot spawner create."));
            return;
        }
        plugin.getBotSpawnManager().spawn(def, player.getLocation());
        player.sendMessage(LEGACY.deserialize("&aBot &f" + def.getDisplayName() + " &adi-spawn di posisi kamu."));
    }

    private void handleSpawner(Player player, String[] args) {
        // /bot spawner create <tier> <name_bot> [tipe]  (tipe default pvp kalau gak dikasih)
        if (args.length < 4 || !args[1].equalsIgnoreCase("create")) {
            player.sendMessage(LEGACY.deserialize("&cUsage: /bot spawner create <tier> <name_bot> [pvp|cpvp|mythic]"));
            return;
        }

        int tier;
        try {
            tier = Integer.parseInt(args[2]);
        } catch (NumberFormatException e) {
            player.sendMessage(LEGACY.deserialize("&cTier harus angka (1/2/3)."));
            return;
        }

        String name = args[3];
        if (plugin.getBotDefinitionManager().get(name) != null) {
            player.sendMessage(LEGACY.deserialize("&cNama bot itu udah dipakai."));
            return;
        }

        BotType type = args.length >= 5 ? BotType.fromString(args[4]) : BotType.PVP;
        if (type == null) {
            player.sendMessage(LEGACY.deserialize("&cTipe gak valid. Pilihan: pvp, cpvp, mythic"));
            return;
        }

        EntityType baseEntity;
        try {
            String configKey = switch (type) {
                case PVP -> "base-entity.pvp";
                case CPVP -> "base-entity.cpvp";
                case MYTHIC -> "base-entity.mythic";
            };
            baseEntity = EntityType.valueOf(plugin.getConfig().getString(configKey, "ZOMBIE"));
        } catch (IllegalArgumentException e) {
            baseEntity = EntityType.ZOMBIE;
        }

        BotDefinition def = plugin.getBotDefinitionManager().create(name, type, tier, baseEntity, 20.0 * tier);
        player.sendMessage(LEGACY.deserialize("&aBot spawner &f" + name + " &adibuat (tier " + tier + ", tipe " + type + "). Pakai &f/bot edit " + name + " &auntuk atur lebih lanjut."));
    }

    private void handleEdit(Player player, String[] args) {
        if (args.length < 2) {
            plugin.getBotGUI().openList(player);
            return;
        }
        BotDefinition def = plugin.getBotDefinitionManager().get(args[1]);
        if (def == null) {
            player.sendMessage(LEGACY.deserialize("&cBot gak ketemu."));
            return;
        }
        plugin.getBotGUI().openEdit(player, def);
    }

    private void handleRename(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(LEGACY.deserialize("&cUsage: /bot rename <name_bot> <nama_baru>"));
            return;
        }
        BotDefinition def = plugin.getBotDefinitionManager().get(args[1]);
        if (def == null) {
            player.sendMessage(LEGACY.deserialize("&cBot gak ketemu."));
            return;
        }
        String newName = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
        def.setDisplayName(newName);
        plugin.getBotDefinitionManager().saveAll();
        player.sendMessage(LEGACY.deserialize("&aNama bot &f" + def.getName() + " &adiganti jadi &f" + newName));
    }

    private void handleSkin(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(LEGACY.deserialize("&cUsage: /bot skin <name_bot> <nama_player>"));
            return;
        }
        BotDefinition def = plugin.getBotDefinitionManager().get(args[1]);
        if (def == null) {
            player.sendMessage(LEGACY.deserialize("&cBot gak ketemu."));
            return;
        }
        def.setSkinPlayerName(args[2]);
        plugin.getBotDefinitionManager().saveAll();
        player.sendMessage(LEGACY.deserialize("&aSkin bot &f" + def.getName() + " &adiganti pakai wajah &f" + args[2]));
    }

    private void handleList(Player player) {
        player.sendMessage(LEGACY.deserialize("&7=== Daftar Bot ==="));
        for (BotDefinition def : plugin.getBotDefinitionManager().getAll()) {
            player.sendMessage(LEGACY.deserialize("&f" + def.getName() + " &7- " + def.getType()
                    + " &7Tier " + def.getTier() + " &7| HP: &f" + def.getHealth() + " &7| DMG: &f" + def.getDamage()));
        }
    }

    private void handleRemove(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(LEGACY.deserialize("&cUsage: /bot remove <name_bot>"));
            return;
        }
        boolean success = plugin.getBotDefinitionManager().remove(args[1]);
        player.sendMessage(LEGACY.deserialize(success ? "&aBot &f" + args[1] + " &adihapus." : "&cBot gak ketemu."));
    }

    private void sendUsage(Player player) {
        player.sendMessage(LEGACY.deserialize("&cUsage: /bot <spawn|spawner|edit|rename|skin|list|remove>"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> result = new ArrayList<>();
            for (String s : SUB_COMMANDS) {
                if (s.startsWith(args[0].toLowerCase())) result.add(s);
            }
            return result;
        }

        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (sub.equals("spawner")) {
                return List.of("create").stream().filter(s -> s.startsWith(args[1].toLowerCase())).toList();
            }
            if (sub.equals("spawn") || sub.equals("edit") || sub.equals("rename") || sub.equals("skin") || sub.equals("remove")) {
                List<String> result = new ArrayList<>();
                for (BotDefinition def : plugin.getBotDefinitionManager().getAll()) {
                    if (def.getName().toLowerCase().startsWith(args[1].toLowerCase())) result.add(def.getName());
                }
                return result;
            }
        }

        if (args.length == 3 && args[0].equalsIgnoreCase("spawner") && args[1].equalsIgnoreCase("create")) {
            return List.of("1", "2", "3").stream().filter(s -> s.startsWith(args[2])).toList();
        }

        if (args.length == 5 && args[0].equalsIgnoreCase("spawner") && args[1].equalsIgnoreCase("create")) {
            return TYPES.stream().filter(s -> s.startsWith(args[4].toLowerCase())).toList();
        }

        if (args.length == 3 && args[0].equalsIgnoreCase("skin")) {
            List<String> result = new ArrayList<>();
            for (Player p : plugin.getServer().getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(args[2].toLowerCase())) result.add(p.getName());
            }
            return result;
        }

        return List.of();
    }
}
