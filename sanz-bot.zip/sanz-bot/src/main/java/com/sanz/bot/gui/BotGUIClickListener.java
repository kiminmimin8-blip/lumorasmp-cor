package com.sanz.bot.gui;

import com.sanz.bot.SanzBot;
import com.sanz.bot.model.BotDefinition;
import com.sanz.bot.model.BotType;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;

public class BotGUIClickListener implements Listener {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzBot plugin;

    public BotGUIClickListener(SanzBot plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        var holder = event.getInventory().getHolder();
        if (!(event.getWhoClicked() instanceof Player player)) return;

        if (holder instanceof BotListHolder listHolder) {
            event.setCancelled(true);
            handleListClick(player, listHolder, event.getSlot());
        } else if (holder instanceof BotEditHolder editHolder) {
            // Slot equipment BENERAN - biarin item ditaruh/diambil normal, gak di-cancel
            boolean clickedTop = event.getClickedInventory() != null
                    && event.getClickedInventory().getHolder() == editHolder;

            if (clickedTop && BotEditHolder.isEquipmentSlot(event.getSlot())) {
                return; // biarin default behavior - taruh/ambil item
            }

            event.setCancelled(true);
            if (clickedTop) {
                handleEditClick(player, editHolder, event.getSlot());
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof BotEditHolder holder)) return;

        BotDefinition def = plugin.getBotDefinitionManager().get(holder.getBotName());
        if (def == null) return;

        // Baca ulang slot equipment beneran, simpen ke definisi (skip kalau isinya placeholder kaca)
        def.setHelmet(readEquipSlot(event.getInventory().getItem(BotEditHolder.EQUIP_HELMET_SLOT)));
        def.setChestplate(readEquipSlot(event.getInventory().getItem(BotEditHolder.EQUIP_CHEST_SLOT)));
        def.setLeggings(readEquipSlot(event.getInventory().getItem(BotEditHolder.EQUIP_LEGS_SLOT)));
        def.setBoots(readEquipSlot(event.getInventory().getItem(BotEditHolder.EQUIP_BOOTS_SLOT)));
        def.setWeapon(readEquipSlot(event.getInventory().getItem(BotEditHolder.EQUIP_WEAPON_SLOT)));
        def.setOffhand(readEquipSlot(event.getInventory().getItem(BotEditHolder.EQUIP_OFFHAND_SLOT)));

        plugin.getBotDefinitionManager().saveAll();
    }

    private org.bukkit.inventory.ItemStack readEquipSlot(org.bukkit.inventory.ItemStack item) {
        if (item == null) return null;
        if (item.getType() == org.bukkit.Material.GRAY_STAINED_GLASS_PANE) return null; // placeholder, bukan item asli
        return item.clone();
    }

    private void handleListClick(Player player, BotListHolder holder, int slot) {
        if (slot == BotListHolder.CREATE_BUTTON_SLOT) {
            player.closeInventory();
            player.sendMessage(LEGACY.deserialize("&eKetik di chat: &f<nama>;<tipe>;<tier> &e(tipe: pvp/cpvp/mythic, contoh: BotArena1;pvp;2). Ketik &ccancel &euntuk batal."));
            plugin.getChatInputManager().awaitInput(player.getUniqueId(), input -> handleCreateInput(player, input));
            return;
        }

        String name = holder.getNameAt(slot);
        if (name == null) return;

        BotDefinition def = plugin.getBotDefinitionManager().get(name);
        if (def == null) return;

        plugin.getBotGUI().openEdit(player, def);
    }

    private void handleEditClick(Player player, BotEditHolder holder, int slot) {
        BotDefinition def = plugin.getBotDefinitionManager().get(holder.getBotName());
        if (def == null) {
            player.closeInventory();
            return;
        }

        if (slot == BotEditHolder.NAME_SLOT) {
            player.closeInventory();
            player.sendMessage(LEGACY.deserialize("&eKetik nama baru di chat. Ketik &ccancel &euntuk batal."));
            plugin.getChatInputManager().awaitInput(player.getUniqueId(), input -> {
                if (!input.equalsIgnoreCase("cancel")) {
                    def.setDisplayName(input.trim());
                    plugin.getBotDefinitionManager().saveAll();
                    player.sendMessage(LEGACY.deserialize("&aNama bot diganti jadi &f" + input.trim()));
                }
            });
        } else if (slot == BotEditHolder.SKIN_SLOT) {
            player.closeInventory();
            player.sendMessage(LEGACY.deserialize("&eKetik nama player (buat skin) di chat. Ketik &ccancel &euntuk batal."));
            plugin.getChatInputManager().awaitInput(player.getUniqueId(), input -> {
                if (!input.equalsIgnoreCase("cancel")) {
                    def.setSkinPlayerName(input.trim());
                    plugin.getBotDefinitionManager().saveAll();
                    player.sendMessage(LEGACY.deserialize("&aSkin bot diganti pakai wajah &f" + input.trim()));
                }
            });
        } else if (slot == BotEditHolder.HEALTH_SLOT) {
            player.closeInventory();
            player.sendMessage(LEGACY.deserialize("&eKetik HP baru (angka) di chat. Ketik &ccancel &euntuk batal."));
            plugin.getChatInputManager().awaitInput(player.getUniqueId(), input -> handleNumberInput(player, input, def::setHealth, "HP"));
        } else if (slot == BotEditHolder.DAMAGE_SLOT) {
            player.closeInventory();
            player.sendMessage(LEGACY.deserialize("&eKetik damage baru (angka) di chat. Ketik &ccancel &euntuk batal."));
            plugin.getChatInputManager().awaitInput(player.getUniqueId(), input -> handleNumberInput(player, input, def::setDamage, "Damage"));
        } else if (slot == BotEditHolder.TIER_SLOT) {
            int newTier = (def.getTier() % 3) + 1;
            def.setTier(newTier);
            plugin.getBotDefinitionManager().saveAll();
            plugin.getBotGUI().openEdit(player, def);
        } else if (slot == BotEditHolder.DELETE_SLOT) {
            plugin.getBotDefinitionManager().remove(def.getName());
            player.sendMessage(LEGACY.deserialize("&cBot &f" + def.getName() + " &cdihapus."));
            plugin.getBotGUI().openList(player);
        } else if (slot == BotEditHolder.BACK_SLOT) {
            plugin.getBotGUI().openList(player);
        }
    }

    private void handleNumberInput(Player player, String input, java.util.function.DoubleConsumer setter, String label) {
        if (input.equalsIgnoreCase("cancel")) {
            player.sendMessage(LEGACY.deserialize("&7Dibatalkan."));
            return;
        }
        try {
            double value = Double.parseDouble(input.trim());
            setter.accept(value);
            plugin.getBotDefinitionManager().saveAll();
            player.sendMessage(LEGACY.deserialize("&a" + label + " diganti jadi &f" + value));
        } catch (NumberFormatException e) {
            player.sendMessage(LEGACY.deserialize("&cItu bukan angka valid."));
        }
    }

    private void handleCreateInput(Player player, String input) {
        if (input.equalsIgnoreCase("cancel")) {
            player.sendMessage(LEGACY.deserialize("&7Dibatalkan."));
            return;
        }
        String[] parts = input.split(";");
        if (parts.length != 3) {
            player.sendMessage(LEGACY.deserialize("&cFormat salah. Contoh: BotArena1;pvp;2"));
            return;
        }

        String name = parts[0].trim();
        if (plugin.getBotDefinitionManager().get(name) != null) {
            player.sendMessage(LEGACY.deserialize("&cNama bot itu udah dipakai."));
            return;
        }

        BotType type = BotType.fromString(parts[1].trim());
        if (type == null) {
            player.sendMessage(LEGACY.deserialize("&cTipe gak valid. Pilihan: pvp, cpvp, mythic"));
            return;
        }

        int tier;
        try {
            tier = Integer.parseInt(parts[2].trim());
        } catch (NumberFormatException e) {
            player.sendMessage(LEGACY.deserialize("&cTier harus angka (1/2/3)."));
            return;
        }

        EntityType baseEntity = defaultEntityFor(type);
        BotDefinition def = plugin.getBotDefinitionManager().create(name, type, tier, baseEntity, 20.0);
        player.sendMessage(LEGACY.deserialize("&aBot &f" + name + " &adibuat! Ketik &f/bot edit " + name + " &auntuk atur lebih lanjut."));
        plugin.getBotGUI().openEdit(player, def);
    }

    private EntityType defaultEntityFor(BotType type) {
        String configKey = switch (type) {
            case PVP -> "base-entity.pvp";
            case CPVP -> "base-entity.cpvp";
            case MYTHIC -> "base-entity.mythic";
        };
        try {
            return EntityType.valueOf(plugin.getConfig().getString(configKey, "ZOMBIE"));
        } catch (IllegalArgumentException e) {
            return EntityType.ZOMBIE;
        }
    }
}
