package com.sanz.bot.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/**
 * GUI edit 1 bot. Ada 2 jenis slot di sini:
 * - Slot KONTROL (tombol): klik selalu di-cancel, cuma trigger aksi (edit nama, dll)
 * - Slot EQUIPMENT: ini slot inventory BENERAN, admin taruh item asli dari inventory-nya
 *   sendiri (drag/shift-click), gak di-cancel. Pas GUI ditutup, isi slot ini dibaca dan
 *   disimpen sebagai equipment bot.
 */
public class BotEditHolder implements InventoryHolder {

    public static final int NAME_SLOT = 10;
    public static final int SKIN_SLOT = 11;
    public static final int HEALTH_SLOT = 12;
    public static final int DAMAGE_SLOT = 13;
    public static final int TIER_SLOT = 14;
    public static final int DELETE_SLOT = 16;
    public static final int BACK_SLOT = 45;

    public static final int EQUIP_HELMET_SLOT = 28;
    public static final int EQUIP_CHEST_SLOT = 29;
    public static final int EQUIP_LEGS_SLOT = 30;
    public static final int EQUIP_BOOTS_SLOT = 31;
    public static final int EQUIP_WEAPON_SLOT = 32;
    public static final int EQUIP_OFFHAND_SLOT = 33;

    public static final int[] EQUIPMENT_SLOTS = {
            EQUIP_HELMET_SLOT, EQUIP_CHEST_SLOT, EQUIP_LEGS_SLOT,
            EQUIP_BOOTS_SLOT, EQUIP_WEAPON_SLOT, EQUIP_OFFHAND_SLOT
    };

    private final String botName;

    public BotEditHolder(String botName) {
        this.botName = botName;
    }

    public String getBotName() {
        return botName;
    }

    public static boolean isEquipmentSlot(int slot) {
        for (int s : EQUIPMENT_SLOTS) {
            if (s == slot) return true;
        }
        return false;
    }

    @Override
    public Inventory getInventory() {
        return null;
    }
}
