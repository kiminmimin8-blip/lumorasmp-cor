package com.sanz.bot.data;

import com.sanz.bot.SanzBot;
import com.sanz.bot.model.BotDefinition;
import com.sanz.bot.model.BotSkill;
import com.sanz.bot.model.BotType;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

/**
 * Baca/tulis semua BotDefinition ke bots.yml. ItemStack disimpan pakai native
 * YamlConfiguration#set(path, ItemStack) - Bukkit udah support ini bawaan
 * (ItemStack implements ConfigurationSerializable), jadi enchant/lore/dll aman kesave.
 */
public class BotStorage {

    private final SanzBot plugin;
    private final File file;

    public BotStorage(SanzBot plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "bots.yml");
    }

    public List<BotDefinition> loadAll() {
        List<BotDefinition> result = new ArrayList<>();
        if (!file.exists()) return result;

        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yaml.getConfigurationSection("bots");
        if (section == null) return result;

        for (String name : section.getKeys(false)) {
            try {
                ConfigurationSection b = section.getConfigurationSection(name);
                if (b == null) continue;

                BotType type = BotType.fromString(b.getString("type", "PVP"));
                int tier = b.getInt("tier", 1);
                EntityType baseEntity = EntityType.valueOf(b.getString("base-entity", "ZOMBIE"));
                double health = b.getDouble("health", 20.0);

                BotDefinition def = new BotDefinition(name, type, tier, baseEntity, health);
                def.setDamage(b.getDouble("damage", 4.0));
                def.setDisplayName(b.getString("display-name", name));
                def.setSkinPlayerName(b.getString("skin-player", null));

                if (b.contains("equipment.helmet")) def.setHelmet(b.getItemStack("equipment.helmet"));
                if (b.contains("equipment.chestplate")) def.setChestplate(b.getItemStack("equipment.chestplate"));
                if (b.contains("equipment.leggings")) def.setLeggings(b.getItemStack("equipment.leggings"));
                if (b.contains("equipment.boots")) def.setBoots(b.getItemStack("equipment.boots"));
                if (b.contains("equipment.weapon")) def.setWeapon(b.getItemStack("equipment.weapon"));
                if (b.contains("equipment.offhand")) def.setOffhand(b.getItemStack("equipment.offhand"));

                ConfigurationSection skillsSection = b.getConfigurationSection("skills");
                if (skillsSection != null) {
                    for (String key : skillsSection.getKeys(false)) {
                        ConfigurationSection s = skillsSection.getConfigurationSection(key);
                        if (s == null) continue;
                        BotSkill.Trigger trigger = BotSkill.Trigger.valueOf(s.getString("trigger", "ON_TIMER"));
                        BotSkill.Effect effect = BotSkill.Effect.valueOf(s.getString("effect", "DAMAGE"));
                        BotSkill skill = new BotSkill(
                                trigger, effect,
                                s.getInt("cooldown-ticks", 60),
                                s.getDouble("amount", 5.0),
                                s.getString("potion-type", "POISON"),
                                s.getInt("potion-duration", 60),
                                s.getInt("potion-amplifier", 0),
                                s.getString("particle", "FLAME"),
                                s.getString("sound", "ENTITY_WITHER_HURT")
                        );
                        def.addSkill(skill);
                    }
                }

                result.add(def);
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Gagal load bot definition '" + name + "'", e);
            }
        }

        return result;
    }

    public void saveAll(List<BotDefinition> definitions) {
        YamlConfiguration yaml = new YamlConfiguration();

        for (BotDefinition d : definitions) {
            String path = "bots." + d.getName();
            yaml.set(path + ".type", d.getType().name());
            yaml.set(path + ".tier", d.getTier());
            yaml.set(path + ".base-entity", d.getBaseEntity().name());
            yaml.set(path + ".health", d.getHealth());
            yaml.set(path + ".damage", d.getDamage());
            yaml.set(path + ".display-name", d.getDisplayName());
            if (d.getSkinPlayerName() != null) {
                yaml.set(path + ".skin-player", d.getSkinPlayerName());
            }

            if (d.getHelmet() != null) yaml.set(path + ".equipment.helmet", d.getHelmet());
            if (d.getChestplate() != null) yaml.set(path + ".equipment.chestplate", d.getChestplate());
            if (d.getLeggings() != null) yaml.set(path + ".equipment.leggings", d.getLeggings());
            if (d.getBoots() != null) yaml.set(path + ".equipment.boots", d.getBoots());
            if (d.getWeapon() != null) yaml.set(path + ".equipment.weapon", d.getWeapon());
            if (d.getOffhand() != null) yaml.set(path + ".equipment.offhand", d.getOffhand());

            int i = 0;
            for (BotSkill skill : d.getSkills()) {
                String skillPath = path + ".skills.skill" + i;
                yaml.set(skillPath + ".trigger", skill.getTrigger().name());
                yaml.set(skillPath + ".effect", skill.getEffect().name());
                yaml.set(skillPath + ".cooldown-ticks", skill.getCooldownTicks());
                yaml.set(skillPath + ".amount", skill.getAmount());
                yaml.set(skillPath + ".potion-type", skill.getPotionType());
                yaml.set(skillPath + ".potion-duration", skill.getPotionDuration());
                yaml.set(skillPath + ".potion-amplifier", skill.getPotionAmplifier());
                yaml.set(skillPath + ".particle", skill.getParticleName());
                yaml.set(skillPath + ".sound", skill.getSoundName());
                i++;
            }
        }

        try {
            if (!plugin.getDataFolder().exists()) {
                plugin.getDataFolder().mkdirs();
            }
            yaml.save(file);
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Gagal simpan bots.yml", e);
        }
    }
}
