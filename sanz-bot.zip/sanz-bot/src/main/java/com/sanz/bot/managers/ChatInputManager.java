package com.sanz.bot.managers;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public class ChatInputManager {

    private final Map<UUID, Consumer<String>> pending = new ConcurrentHashMap<>();

    public void awaitInput(UUID uuid, Consumer<String> onInput) {
        pending.put(uuid, onInput);
    }

    public boolean isAwaiting(UUID uuid) {
        return pending.containsKey(uuid);
    }

    public void handleInput(UUID uuid, String message) {
        Consumer<String> handler = pending.remove(uuid);
        if (handler != null) {
            handler.accept(message);
        }
    }
}
