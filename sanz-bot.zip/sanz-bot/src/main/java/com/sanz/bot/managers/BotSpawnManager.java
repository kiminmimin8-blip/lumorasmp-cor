package com.sanz.bot.managers;

import com.sanz.bot.SanzBot;
import com.sanz.bot.model.BotDefinition;
import com.sanz.bot.model.BotInstance;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class BotSpawnManager {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzBot plugin;
    private final Map<UUID, BotInstance> activeBots = new ConcurrentHashMap<>();

    public BotSpawnManager(SanzBot plugin) {
        this.plugin = plugin;
    }

    /** Spawn 1 instance hidup dari BotDefinition di lokasi tertentu. */
    public LivingEntity spawn(BotDefinition def, Location location) {
        LivingEntity entity = (LivingEntity) location.getWorld().spawnEntity(location, def.getBaseEntity());

        double multiplier = plugin.getConfig().getDouble("tier-multiplier." + def.getTier(), 1.0);
        double finalHealth = def.getHealth() * multiplier;

        AttributeInstance maxHealthAttr = entity.getAttribute(Attribute.MAX_HEALTH);
        double effectiveMaxHealth = finalHealth;
        if (maxHealthAttr != null) {
            maxHealthAttr.setBaseValue(finalHealth);
            effectiveMaxHealth = maxHealthAttr.getValue();
        }
        entity.setHealth(Math.min(finalHealth, effectiveMaxHealth));

        entity.customName(LEGACY.deserialize("&e" + def.getDisplayName() + " &7[T" + def.getTier() + "]"));
        entity.setCustomNameVisible(true);
        if (entity instanceof Mob mobEntity) {
            mobEntity.setRemoveWhenFarAway(false);
        }

        AttributeInstance damageAttr = entity.getAttribute(Attribute.ATTACK_DAMAGE);
        if (damageAttr != null) {
            damageAttr.setBaseValue(def.getDamage() * multiplier);
        }

        applyEquipment(entity, def);

        if (entity instanceof Mob mob) {
            mob.setTarget(null); // biar combat manager yang atur target secara berkala
        }

        BotInstance instance = new BotInstance(entity.getUniqueId(), def.getName());
        activeBots.put(entity.getUniqueId(), instance);

        return entity;
    }

    private void applyEquipment(LivingEntity entity, BotDefinition def) {
        EntityEquipment eq = entity.getEquipment();
        if (eq == null) return;

        ItemStack helmet = def.getHelmet();
        // Kalau ada skin player yang di-set DAN gak ada helmet custom, pasang skull texture player itu
        if (helmet == null && def.getSkinPlayerName() != null) {
            helmet = createPlayerSkull(def.getSkinPlayerName());
        }

        if (helmet != null) eq.setHelmet(helmet);
        if (def.getChestplate() != null) eq.setChestplate(def.getChestplate());
        if (def.getLeggings() != null) eq.setLeggings(def.getLeggings());
        if (def.getBoots() != null) eq.setBoots(def.getBoots());
        if (def.getWeapon() != null) eq.setItemInMainHand(def.getWeapon());
        if (def.getOffhand() != null) eq.setItemInOffHand(def.getOffhand());

        // Jangan drop equipment vanilla pas mati / kena damage - equipment ini bagian dari "kostum" bot
        eq.setHelmetDropChance(0);
        eq.setChestplateDropChance(0);
        eq.setLeggingsDropChance(0);
        eq.setBootsDropChance(0);
        eq.setItemInMainHandDropChance(0);
        eq.setItemInOffHandDropChance(0);
    }

    private ItemStack createPlayerSkull(String playerName) {
        ItemStack skull = new ItemStack(org.bukkit.Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        OfflinePlayer target = plugin.getServer().getOfflinePlayer(playerName);
        meta.setOwningPlayer(target);
        skull.setItemMeta(meta);
        return skull;
    }

    public BotInstance getInstance(UUID entityUuid) {
        return activeBots.get(entityUuid);
    }

    public void removeInstance(UUID entityUuid) {
        activeBots.remove(entityUuid);
    }

    public Map<UUID, BotInstance> getActiveBots() {
        return activeBots;
    }

    public BotDefinition getDefinitionOf(BotInstance instance) {
        return plugin.getBotDefinitionManager().get(instance.getDefinitionName());
    }
}
