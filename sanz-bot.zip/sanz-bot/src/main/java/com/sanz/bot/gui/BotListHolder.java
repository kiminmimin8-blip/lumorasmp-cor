package com.sanz.bot.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.List;

public class BotListHolder implements InventoryHolder {

    public static final int CREATE_BUTTON_SLOT = 49;

    private final List<String> nameBySlot;

    public BotListHolder(List<String> nameBySlot) {
        this.nameBySlot = nameBySlot;
    }

    public String getNameAt(int slot) {
        if (slot < 0 || slot >= nameBySlot.size()) return null;
        return nameBySlot.get(slot);
    }

    @Override
    public Inventory getInventory() {
        return null;
    }
}
