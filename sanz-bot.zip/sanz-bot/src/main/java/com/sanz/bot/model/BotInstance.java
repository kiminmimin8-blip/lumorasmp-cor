package com.sanz.bot.model;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Satu bot yang lagi hidup di dunia - nge-link entity Bukkit asli (lewat UUID)
 * ke template BotDefinition asalnya, plus nyimpen cooldown skill per instance.
 */
public class BotInstance {

    private final UUID entityUuid;
    private final String definitionName;
    private final Map<Integer, Long> skillCooldowns = new HashMap<>(); // index skill -> tick terakhir dipakai
    private long nextCrystalComboTick = 0;

    public BotInstance(UUID entityUuid, String definitionName) {
        this.entityUuid = entityUuid;
        this.definitionName = definitionName;
    }

    public UUID getEntityUuid() {
        return entityUuid;
    }

    public String getDefinitionName() {
        return definitionName;
    }

    public boolean isSkillOnCooldown(int skillIndex, long currentTick) {
        Long last = skillCooldowns.get(skillIndex);
        return last != null && currentTick < last;
    }

    public void setSkillCooldown(int skillIndex, long readyAtTick) {
        skillCooldowns.put(skillIndex, readyAtTick);
    }

    public boolean isCrystalComboReady(long currentTick) {
        return currentTick >= nextCrystalComboTick;
    }

    public void setNextCrystalCombo(long readyAtTick) {
        this.nextCrystalComboTick = readyAtTick;
    }
}
