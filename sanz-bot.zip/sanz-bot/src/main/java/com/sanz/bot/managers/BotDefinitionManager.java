package com.sanz.bot.managers;

import com.sanz.bot.SanzBot;
import com.sanz.bot.model.BotDefinition;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BotDefinitionManager {

    private final SanzBot plugin;
    private final Map<String, BotDefinition> definitions = new ConcurrentHashMap<>();

    public BotDefinitionManager(SanzBot plugin) {
        this.plugin = plugin;
    }

    public void loadFromStorage() {
        for (BotDefinition def : plugin.getBotStorage().loadAll()) {
            definitions.put(def.getName().toLowerCase(), def);
        }
    }

    public void saveAll() {
        plugin.getBotStorage().saveAll(new ArrayList<>(definitions.values()));
    }

    public BotDefinition create(String name, com.sanz.bot.model.BotType type, int tier,
                                 org.bukkit.entity.EntityType baseEntity, double health) {
        BotDefinition def = new BotDefinition(name, type, tier, baseEntity, health);
        definitions.put(name.toLowerCase(), def);
        saveAll();
        return def;
    }

    public BotDefinition get(String name) {
        return definitions.get(name.toLowerCase());
    }

    public boolean remove(String name) {
        boolean removed = definitions.remove(name.toLowerCase()) != null;
        if (removed) saveAll();
        return removed;
    }

    public List<BotDefinition> getAll() {
        return new ArrayList<>(definitions.values());
    }
}
