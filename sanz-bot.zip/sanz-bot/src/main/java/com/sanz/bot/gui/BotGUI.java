package com.sanz.bot.gui;

import com.sanz.bot.SanzBot;
import com.sanz.bot.model.BotDefinition;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;

public class BotGUI {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzBot plugin;

    public BotGUI(SanzBot plugin) {
        this.plugin = plugin;
    }

    public void openList(Player player) {
        List<BotDefinition> all = plugin.getBotDefinitionManager().getAll();
        List<String> slotMap = new ArrayList<>();
        for (int i = 0; i < 54; i++) slotMap.add(null);

        BotListHolder holder = new BotListHolder(slotMap);
        Inventory inv = Bukkit.createInventory(holder, 54, LEGACY.deserialize("&8&lSanz Bot - Daftar (" + all.size() + ")"));

        int slot = 0;
        for (BotDefinition def : all) {
            if (slot >= 45) break;

            ItemStack item = new ItemStack(iconFor(def));
            ItemMeta meta = item.getItemMeta();
            meta.displayName(LEGACY.deserialize("&e" + def.getDisplayName()));
            meta.lore(List.of(
                    LEGACY.deserialize("&7ID: &f" + def.getName()),
                    LEGACY.deserialize("&7Tipe: &f" + def.getType()),
                    LEGACY.deserialize("&7Tier: &f" + def.getTier()),
                    LEGACY.deserialize("&7HP: &f" + def.getHealth() + " &7| Damage: &f" + def.getDamage()),
                    LEGACY.deserialize("&eKlik buat edit")
            ));
            item.setItemMeta(meta);

            inv.setItem(slot, item);
            slotMap.set(slot, def.getName());
            slot++;
        }

        ItemStack create = new ItemStack(Material.LIME_DYE);
        ItemMeta createMeta = create.getItemMeta();
        createMeta.displayName(LEGACY.deserialize("&a&l+ Buat Bot Baru"));
        createMeta.lore(List.of(LEGACY.deserialize("&7Klik buat bikin bot baru")));
        create.setItemMeta(createMeta);
        inv.setItem(BotListHolder.CREATE_BUTTON_SLOT, create);

        player.openInventory(inv);
    }

    public void openEdit(Player player, BotDefinition def) {
        BotEditHolder holder = new BotEditHolder(def.getName());
        Inventory inv = Bukkit.createInventory(holder, 54, LEGACY.deserialize("&8&lEdit Bot: " + def.getName()));

        setButton(inv, BotEditHolder.NAME_SLOT, Material.NAME_TAG, "&bEdit Nama",
                "&7Sekarang: &f" + def.getDisplayName(), "&eKlik, ketik nama baru di chat");

        setButton(inv, BotEditHolder.SKIN_SLOT, skullFor(def), "&dEdit Skin",
                "&7Sekarang: &f" + (def.getSkinPlayerName() != null ? def.getSkinPlayerName() : "(belum diset)"),
                "&eKlik, ketik nama player di chat");

        setButton(inv, BotEditHolder.HEALTH_SLOT, Material.GOLDEN_APPLE, "&cEdit Darah (HP)",
                "&7Sekarang: &f" + def.getHealth(), "&eKlik, ketik angka baru di chat");

        setButton(inv, BotEditHolder.DAMAGE_SLOT, Material.IRON_SWORD, "&6Edit Damage",
                "&7Sekarang: &f" + def.getDamage(), "&eKlik, ketik angka baru di chat");

        setButton(inv, BotEditHolder.TIER_SLOT, Material.NETHER_STAR, "&5Tier: " + def.getTier(),
                "&7Klik buat naikin tier (1 -> 2 -> 3 -> 1)", "");

        setButton(inv, BotEditHolder.DELETE_SLOT, Material.TNT, "&c&lHapus Bot",
                "&7Klik buat hapus bot ini permanen", "");

        setButton(inv, BotEditHolder.BACK_SLOT, Material.ARROW, "&c« Kembali", "", "");

        if (def.getHelmet() != null) inv.setItem(BotEditHolder.EQUIP_HELMET_SLOT, def.getHelmet());
        if (def.getChestplate() != null) inv.setItem(BotEditHolder.EQUIP_CHEST_SLOT, def.getChestplate());
        if (def.getLeggings() != null) inv.setItem(BotEditHolder.EQUIP_LEGS_SLOT, def.getLeggings());
        if (def.getBoots() != null) inv.setItem(BotEditHolder.EQUIP_BOOTS_SLOT, def.getBoots());
        if (def.getWeapon() != null) inv.setItem(BotEditHolder.EQUIP_WEAPON_SLOT, def.getWeapon());
        if (def.getOffhand() != null) inv.setItem(BotEditHolder.EQUIP_OFFHAND_SLOT, def.getOffhand());

        placeholderIfEmpty(inv, BotEditHolder.EQUIP_HELMET_SLOT, "&7Taruh Helm di sini");
        placeholderIfEmpty(inv, BotEditHolder.EQUIP_CHEST_SLOT, "&7Taruh Chestplate di sini");
        placeholderIfEmpty(inv, BotEditHolder.EQUIP_LEGS_SLOT, "&7Taruh Legging di sini");
        placeholderIfEmpty(inv, BotEditHolder.EQUIP_BOOTS_SLOT, "&7Taruh Sepatu di sini");
        placeholderIfEmpty(inv, BotEditHolder.EQUIP_WEAPON_SLOT, "&7Taruh Senjata di sini");
        placeholderIfEmpty(inv, BotEditHolder.EQUIP_OFFHAND_SLOT, "&7Taruh Item Offhand (Totem dll) di sini");

        player.openInventory(inv);
    }

    private void placeholderIfEmpty(Inventory inv, int slot, String label) {
        if (inv.getItem(slot) != null) return;
        ItemStack placeholder = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = placeholder.getItemMeta();
        meta.displayName(LEGACY.deserialize(label));
        placeholder.setItemMeta(meta);
        inv.setItem(slot, placeholder);
    }

    private void setButton(Inventory inv, int slot, Material material, String name, String lore1, String lore2) {
        ItemStack item = new ItemStack(material);
        applyButtonMeta(item, name, lore1, lore2);
        inv.setItem(slot, item);
    }

    private void setButton(Inventory inv, int slot, ItemStack baseItem, String name, String lore1, String lore2) {
        ItemStack item = baseItem.clone();
        applyButtonMeta(item, name, lore1, lore2);
        inv.setItem(slot, item);
    }

    private void applyButtonMeta(ItemStack item, String name, String lore1, String lore2) {
        ItemMeta meta = item.getItemMeta();
        meta.displayName(LEGACY.deserialize(name));
        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
        if (!lore1.isEmpty()) lore.add(LEGACY.deserialize(lore1));
        if (!lore2.isEmpty()) lore.add(LEGACY.deserialize(lore2));
        meta.lore(lore);
        item.setItemMeta(meta);
    }

    private ItemStack skullFor(BotDefinition def) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        if (def.getSkinPlayerName() != null) {
            SkullMeta meta = (SkullMeta) skull.getItemMeta();
            meta.setOwningPlayer(Bukkit.getOfflinePlayer(def.getSkinPlayerName()));
            skull.setItemMeta(meta);
        }
        return skull;
    }

    private Material iconFor(BotDefinition def) {
        return switch (def.getType()) {
            case PVP -> Material.IRON_SWORD;
            case CPVP -> Material.END_CRYSTAL;
            case MYTHIC -> Material.DRAGON_HEAD;
        };
    }
}
