package com.sanz.bot;

import com.sanz.bot.commands.BotCommand;
import com.sanz.bot.data.BotStorage;
import com.sanz.bot.gui.BotGUI;
import com.sanz.bot.gui.BotGUIClickListener;
import com.sanz.bot.listeners.BotDeathListener;
import com.sanz.bot.listeners.ChatInputListener;
import com.sanz.bot.listeners.CombatSkillTriggerListener;
import com.sanz.bot.managers.BotCombatManager;
import com.sanz.bot.managers.BotDefinitionManager;
import com.sanz.bot.managers.BotSpawnManager;
import com.sanz.bot.managers.ChatInputManager;
import org.bukkit.plugin.java.JavaPlugin;

public class SanzBot extends JavaPlugin {

    private BotStorage botStorage;
    private BotDefinitionManager botDefinitionManager;
    private BotSpawnManager botSpawnManager;
    private BotCombatManager botCombatManager;
    private BotGUI botGUI;
    private ChatInputManager chatInputManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        botStorage = new BotStorage(this);
        botDefinitionManager = new BotDefinitionManager(this);
        botSpawnManager = new BotSpawnManager(this);
        botCombatManager = new BotCombatManager(this);
        botGUI = new BotGUI(this);
        chatInputManager = new ChatInputManager();

        botDefinitionManager.loadFromStorage();

        registerListeners();
        registerCommands();

        botCombatManager.start();

        getLogger().info("SanzBot enabled - " + botDefinitionManager.getAll().size() + " bot definition dimuat.");
    }

    @Override
    public void onDisable() {
        if (botCombatManager != null) {
            botCombatManager.stop();
        }
        if (botDefinitionManager != null) {
            botDefinitionManager.saveAll();
        }
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new BotGUIClickListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatInputListener(this), this);
        getServer().getPluginManager().registerEvents(new BotDeathListener(this), this);
        getServer().getPluginManager().registerEvents(new CombatSkillTriggerListener(this), this);
    }

    private void registerCommands() {
        BotCommand command = new BotCommand(this);
        getCommand("bot").setExecutor(command);
        getCommand("bot").setTabCompleter(command);
    }

    public BotStorage getBotStorage() {
        return botStorage;
    }

    public BotDefinitionManager getBotDefinitionManager() {
        return botDefinitionManager;
    }

    public BotSpawnManager getBotSpawnManager() {
        return botSpawnManager;
    }

    public BotCombatManager getBotCombatManager() {
        return botCombatManager;
    }

    public BotGUI getBotGUI() {
        return botGUI;
    }

    public ChatInputManager getChatInputManager() {
        return chatInputManager;
    }
}
