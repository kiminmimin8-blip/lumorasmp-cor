package com.sanz.bot.model;

import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Template/spawner bot - mirip konsep "mob type" di MythicMobs. Disimpan sekali,
 * dipakai buat spawn banyak instance lewat /bot spawn <name>.
 */
public class BotDefinition {

    private String name;
    private BotType type;
    private int tier;
    private EntityType baseEntity;
    private String displayName;
    private double health;
    private double damage;
    private String skinPlayerName; // dipasang di skull helm buat wajah mirip skin player itu

    private ItemStack helmet;
    private ItemStack chestplate;
    private ItemStack leggings;
    private ItemStack boots;
    private ItemStack weapon;
    private ItemStack offhand; // totem, dll

    private final List<BotSkill> skills = new ArrayList<>();

    public BotDefinition(String name, BotType type, int tier, EntityType baseEntity, double health) {
        this.name = name;
        this.type = type;
        this.tier = tier;
        this.baseEntity = baseEntity;
        this.health = health;
        this.damage = 4.0;
        this.displayName = name;
    }

    public String getName() {
        return name;
    }

    public BotType getType() {
        return type;
    }

    public int getTier() {
        return tier;
    }

    public void setTier(int tier) {
        this.tier = tier;
    }

    public EntityType getBaseEntity() {
        return baseEntity;
    }

    public void setBaseEntity(EntityType baseEntity) {
        this.baseEntity = baseEntity;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public double getHealth() {
        return health;
    }

    public void setHealth(double health) {
        this.health = health;
    }

    public double getDamage() {
        return damage;
    }

    public void setDamage(double damage) {
        this.damage = damage;
    }

    public String getSkinPlayerName() {
        return skinPlayerName;
    }

    public void setSkinPlayerName(String skinPlayerName) {
        this.skinPlayerName = skinPlayerName;
    }

    public ItemStack getHelmet() {
        return helmet;
    }

    public void setHelmet(ItemStack helmet) {
        this.helmet = helmet;
    }

    public ItemStack getChestplate() {
        return chestplate;
    }

    public void setChestplate(ItemStack chestplate) {
        this.chestplate = chestplate;
    }

    public ItemStack getLeggings() {
        return leggings;
    }

    public void setLeggings(ItemStack leggings) {
        this.leggings = leggings;
    }

    public ItemStack getBoots() {
        return boots;
    }

    public void setBoots(ItemStack boots) {
        this.boots = boots;
    }

    public ItemStack getWeapon() {
        return weapon;
    }

    public void setWeapon(ItemStack weapon) {
        this.weapon = weapon;
    }

    public ItemStack getOffhand() {
        return offhand;
    }

    public void setOffhand(ItemStack offhand) {
        this.offhand = offhand;
    }

    public List<BotSkill> getSkills() {
        return skills;
    }

    public void addSkill(BotSkill skill) {
        skills.add(skill);
    }
}
