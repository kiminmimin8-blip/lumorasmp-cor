package com.sanz.bot.listeners;

import com.sanz.bot.SanzBot;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

public class ChatInputListener implements Listener {

    private final SanzBot plugin;

    public ChatInputListener(SanzBot plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent event) {
        var uuid = event.getPlayer().getUniqueId();
        if (!plugin.getChatInputManager().isAwaiting(uuid)) return;

        event.setCancelled(true);
        String message = PlainTextComponentSerializer.plainText().serialize(event.message());

        plugin.getServer().getScheduler().runTask(plugin, () ->
                plugin.getChatInputManager().handleInput(uuid, message)
        );
    }
}
