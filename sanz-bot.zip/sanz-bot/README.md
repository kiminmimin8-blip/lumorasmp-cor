# SanzBot

Plugin standalone bot/mob custom: PvP, CrystalPvP, dan MythicMob-style dengan skill,
tier 1-3, GUI create/edit lengkap.

## Kenapa bukan full-body player skin?

NPC visual full-body pakai skin player asli (kayak Citizens/FancyNpcs) itu entity PALSU
berbasis packet - gak punya hitbox/AI beneran, jadi gak reliable buat combat sungguhan.
Bot di plugin ini pakai **mob asli** (Zombie/Piglin/dll) yang beneran punya AI, hitbox,
dan damage vanilla - biar "jago"-nya nyata. Skin dipasang di **kepala** (skull texture
player, `SkullMeta.setOwningPlayer`) - nunjukin wajah sesuai skin, real & reliable, tapi
bukan full body. Kalau butuh full-body NPC yang jalan-jalan berantem, itu perlu kerjaan
level NMS (kayak Citizens) - bisa digarap terpisah biar bisa ditest bertahap.

## Command

| Command | Fungsi |
|---|---|
| `/bot` | Buka GUI list semua bot |
| `/bot spawn <name_bot>` | Spawn bot di posisi kamu |
| `/bot spawner create <tier> <name_bot> [pvp\|cpvp\|mythic]` | Bikin definisi bot baru (tipe default: pvp) |
| `/bot edit <name_bot>` | Buka GUI edit bot itu |
| `/bot rename <name_bot> <nama_baru>` | Ganti display name |
| `/bot skin <name_bot> <nama_player>` | Ganti skin (wajah skull) |
| `/bot list` | List semua bot di chat |
| `/bot remove <name_bot>` | Hapus definisi bot |

Semua ada **tab completion** (subcommand, nama bot, tier, tipe, nama player online).

## GUI Edit (`/bot edit <name>` atau klik dari `/bot`)

- **Edit Nama** - klik, ketik di chat
- **Edit Skin** - klik, ketik nama player di chat (pasang wajah skin itu ke helm bot)
- **Edit Darah (HP)** - klik, ketik angka
- **Edit Damage** - klik, ketik angka
- **Tier** - klik buat siklus 1 → 2 → 3 → 1 (ngaruh ke multiplier HP/damage, lihat `config.yml`)
- **Hapus Bot** - hapus definisi
- **Slot equipment BENERAN** (helm/chestplate/legging/boots/senjata/offhand) - taruh item
  asli dari inventory kamu langsung ke situ (drag/shift-click), otomatis kesave pas GUI ditutup

## 3 Jenis Bot

1. **PVP** - combat biasa, murni damage + gear (vanilla AI + equipment beneran)
2. **CPVP** - selain combat biasa, kalau target udah deket (`cpvp.trigger-range` di config)
   bot bakal taruh & ledakin End Crystal buat burst damage tambahan (cooldown diatur di config)
3. **MYTHIC** - bisa dikasih skill custom (ON_ATTACK/ON_TIMER/ON_DAMAGED), efek: DAMAGE,
   HEAL, POTION, PARTICLE_SOUND. Skill belum ada editor GUI-nya (edit manual di `bots.yml`
   bagian `skills:` - format ada contohnya otomatis kalau kamu isi manual, tanya aku kalau
   mau dibikinin GUI-nya juga)

## Kenapa bot-nya "jago"

Bot pakai **AI vanilla asli** (bukan hand-coded pathfinding) - begitu target di-set
(`Mob#setTarget`), goal selector bawaan Minecraft yang ngurus gerak & nyerang. Equipment
asli yang di-pasang (pedang/armor) otomatis ngaruh ke damage vanilla juga - jadi "jago"-nya
dari kombinasi AI asli + gear bagus, bukan gimmick buatan yang gampang ketauan aneh.

## Cara build

Sandbox aku gak ada internet buat `mvn compile` - udah direview manual baris per baris,
termasuk 1 bug yang ketemu & difix (`setRemoveWhenFarAway` itu method di interface `Mob`,
bukan `LivingEntity` - butuh instanceof check dulu). Push ke GitHub, biarin Actions CI yang
build, kirim log error ke sini kalau masih ada yang kelewat.

**Cek dulu versi `paper-api` di `pom.xml`** - masih `1.21.11-R0.1-SNAPSHOT`.

## Config penting (`config.yml`)

```yaml
detection-radius: 16.0       # radius bot nyari target
tier-multiplier:              # dikali ke health/damage base
  1: 1.0
  2: 1.5
  3: 2.2
cpvp:
  trigger-range: 4.0
  damage: 24.0
base-entity:                  # base mob per jenis, bisa diganti
  pvp: ZOMBIE
  cpvp: PIGLIN
  mythic: PIGLIN_BRUTE
```
