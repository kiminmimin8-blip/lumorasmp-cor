package com.sanz.leaderboard.listeners;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.StatType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Track lama sesi tiap player (dari join sampai quit), dan sync balance Vault
 * ke kolom money_cache pas join biar leaderboard money selalu update tanpa
 * perlu polling semua player terus-terusan.
 */
public class PlaytimeListener implements Listener {

    private final SanzLeaderboard plugin;
    private final Map<UUID, Long> sessionStart = new ConcurrentHashMap<>();

    public PlaytimeListener(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        sessionStart.put(player.getUniqueId(), System.currentTimeMillis());

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            plugin.getDatabase().ensurePlayer(player.getUniqueId(), player.getName());

            if (plugin.getVaultHook().isEnabled()) {
                double balance = plugin.getVaultHook().getBalance(player);
                plugin.getDatabase().setValue(player.getUniqueId(), player.getName(), StatType.MONEY, balance);
            }
        });
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        Long start = sessionStart.remove(player.getUniqueId());
        if (start == null) return;

        long seconds = (System.currentTimeMillis() - start) / 1000L;
        if (seconds <= 0) return;

        // Sinkron balance final juga pas quit
        double balance = plugin.getVaultHook().isEnabled() ? plugin.getVaultHook().getBalance(player) : -1;

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            plugin.getDatabase().increment(player.getUniqueId(), player.getName(), StatType.PLAYTIME, seconds);
            if (balance >= 0) {
                plugin.getDatabase().setValue(player.getUniqueId(), player.getName(), StatType.MONEY, balance);
            }
        });
    }

    /** Dipanggil dari repeating task, buat flush playtime player yang masih online tanpa nunggu quit. */
    public void flushOnlineSessions() {
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Long> entry : sessionStart.entrySet()) {
            UUID uuid = entry.getKey();
            Player player = plugin.getServer().getPlayer(uuid);
            if (player == null) continue;

            long seconds = (now - entry.getValue()) / 1000L;
            if (seconds <= 0) continue;

            String name = player.getName();
            plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () ->
                    plugin.getDatabase().increment(uuid, name, StatType.PLAYTIME, seconds)
            );
            sessionStart.put(uuid, now);
        }
    }
}
