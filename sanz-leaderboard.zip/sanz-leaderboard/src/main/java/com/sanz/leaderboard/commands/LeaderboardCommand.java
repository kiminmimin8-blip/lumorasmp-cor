package com.sanz.leaderboard.commands;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.StatType;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class LeaderboardCommand implements CommandExecutor {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzLeaderboard plugin;

    public LeaderboardCommand(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }

        if (!player.hasPermission("sanzleaderboard.use")) {
            player.sendMessage(LEGACY.deserialize("&cKamu gak punya izin buat pakai command ini."));
            return true;
        }

        if (args.length == 0) {
            plugin.getGui().openMainMenu(player);
            return true;
        }

        StatType type = StatType.fromConfigKey(args[0]);
        if (type == null) {
            player.sendMessage(LEGACY.deserialize("&cKategori gak valid. Pilihan: " + validCategories()));
            return true;
        }

        if (!plugin.getLeaderboardManager().isEnabled(type)) {
            player.sendMessage(LEGACY.deserialize("&cKategori itu lagi dimatiin di config."));
            return true;
        }

        plugin.getGui().openCategory(player, type);
        return true;
    }

    private String validCategories() {
        List<String> keys = new ArrayList<>();
        for (StatType type : StatType.values()) {
            keys.add(type.configKey());
        }
        return String.join(", ", keys);
    }
}
