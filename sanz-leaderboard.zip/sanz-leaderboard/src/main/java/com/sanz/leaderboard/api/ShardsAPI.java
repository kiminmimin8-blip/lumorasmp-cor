package com.sanz.leaderboard.api;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.StatType;
import org.bukkit.OfflinePlayer;

import java.util.UUID;

/**
 * API publik buat plugin lain (misal sanz-core / sanz-market) yang mau
 * nambah/kurang/cek shards player tanpa perlu tau soal internal database.
 *
 * Cara pakai dari plugin lain:
 *   ShardsAPI.add(player.getUniqueId(), player.getName(), 50);
 *   double balance = ShardsAPI.getBalance(player.getUniqueId());
 *
 * Pastikan depend/softdepend "SanzLeaderboard" di plugin.yml plugin lain
 * dan cek Bukkit.getPluginManager().isPluginEnabled("SanzLeaderboard") dulu
 * sebelum manggil, biar gak NPE kalau plugin ini gak aktif.
 */
public final class ShardsAPI {

    private ShardsAPI() {
    }

    public static double getBalance(UUID uuid) {
        SanzLeaderboard plugin = SanzLeaderboard.getInstance();
        if (plugin == null) return 0;
        return plugin.getDatabase().getValue(uuid, StatType.SHARDS);
    }

    public static double getBalance(OfflinePlayer player) {
        return getBalance(player.getUniqueId());
    }

    public static void add(UUID uuid, String playerName, double amount) {
        SanzLeaderboard plugin = SanzLeaderboard.getInstance();
        if (plugin == null) return;
        plugin.getDatabase().increment(uuid, playerName, StatType.SHARDS, amount);
    }

    /** Return false kalau balance gak cukup (gak jadi dikurangin). */
    public static boolean take(UUID uuid, String playerName, double amount) {
        SanzLeaderboard plugin = SanzLeaderboard.getInstance();
        if (plugin == null) return false;
        double current = getBalance(uuid);
        if (current < amount) {
            return false;
        }
        plugin.getDatabase().increment(uuid, playerName, StatType.SHARDS, -amount);
        return true;
    }

    public static void set(UUID uuid, String playerName, double amount) {
        SanzLeaderboard plugin = SanzLeaderboard.getInstance();
        if (plugin == null) return;
        plugin.getDatabase().setValue(uuid, playerName, StatType.SHARDS, amount);
    }
}
