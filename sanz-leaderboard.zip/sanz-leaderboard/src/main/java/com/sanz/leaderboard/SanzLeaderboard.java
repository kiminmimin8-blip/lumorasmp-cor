package com.sanz.leaderboard;

import com.sanz.leaderboard.commands.HologramCommand;
import com.sanz.leaderboard.commands.LeaderboardCommand;
import com.sanz.leaderboard.commands.ShardsCommand;
import com.sanz.leaderboard.data.Database;
import com.sanz.leaderboard.gui.GUIClickListener;
import com.sanz.leaderboard.gui.LeaderboardGUI;
import com.sanz.leaderboard.hook.VaultHook;
import com.sanz.leaderboard.leaderboard.LeaderboardHologram;
import com.sanz.leaderboard.leaderboard.LeaderboardManager;
import com.sanz.leaderboard.listeners.BlockListener;
import com.sanz.leaderboard.listeners.BlockStatsBuffer;
import com.sanz.leaderboard.listeners.CombatListener;
import com.sanz.leaderboard.listeners.PlaytimeListener;
import org.bukkit.plugin.java.JavaPlugin;

public class SanzLeaderboard extends JavaPlugin {

    private static SanzLeaderboard instance;

    private Database database;
    private VaultHook vaultHook;
    private LeaderboardManager leaderboardManager;
    private LeaderboardHologram hologram;
    private LeaderboardGUI gui;
    private BlockStatsBuffer blockStatsBuffer;
    private PlaytimeListener playtimeListener;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        database = new Database(this);
        if (!database.connect()) {
            getLogger().severe("Gagal konek ke database, plugin dimatiin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        vaultHook = new VaultHook(this);
        vaultHook.setup();

        leaderboardManager = new LeaderboardManager(this);
        hologram = new LeaderboardHologram(this);
        gui = new LeaderboardGUI(this);
        blockStatsBuffer = new BlockStatsBuffer(this);
        playtimeListener = new PlaytimeListener(this);

        registerListeners();
        registerCommands();

        // Refresh pertama kali langsung, terus baru mulai task berkala
        getServer().getScheduler().runTaskAsynchronously(this, () -> {
            leaderboardManager.refresh();
            getServer().getScheduler().runTask(this, () -> {
                hologram.restoreAll();
                hologram.updateAll();
            });
        });

        startTasks();

        getLogger().info("SanzLeaderboard enabled - kills, deaths, playtime, money, blocks, shards siap ditrack.");
    }

    @Override
    public void onDisable() {
        if (blockStatsBuffer != null) {
            blockStatsBuffer.flush();
        }
        if (playtimeListener != null) {
            playtimeListener.flushOnlineSessions();
        }
        if (database != null) {
            database.disconnect();
        }
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new BlockListener(blockStatsBuffer), this);
        getServer().getPluginManager().registerEvents(playtimeListener, this);
        getServer().getPluginManager().registerEvents(new GUIClickListener(this), this);
    }

    private void registerCommands() {
        getCommand("leaderboard").setExecutor(new LeaderboardCommand(this));
        getCommand("shards").setExecutor(new ShardsCommand(this));
        getCommand("lbhologram").setExecutor(new HologramCommand(this));
    }

    private void startTasks() {
        long refreshTicks = getConfig().getLong("refresh-interval-seconds", 30) * 20L;

        // Task async: flush buffer block stats + refresh cache leaderboard
        getServer().getScheduler().runTaskTimerAsynchronously(this, () -> {
            blockStatsBuffer.flush();
            playtimeListener.flushOnlineSessions();
            leaderboardManager.refresh();

            // Update hologram harus di main thread (interaksi entity)
            getServer().getScheduler().runTask(this, () -> hologram.updateAll());
        }, refreshTicks, refreshTicks);
    }

    public static SanzLeaderboard getInstance() {
        return instance;
    }

    public Database getDatabase() {
        return database;
    }

    public VaultHook getVaultHook() {
        return vaultHook;
    }

    public LeaderboardManager getLeaderboardManager() {
        return leaderboardManager;
    }

    public LeaderboardHologram getHologram() {
        return hologram;
    }

    public LeaderboardGUI getGui() {
        return gui;
    }
}
