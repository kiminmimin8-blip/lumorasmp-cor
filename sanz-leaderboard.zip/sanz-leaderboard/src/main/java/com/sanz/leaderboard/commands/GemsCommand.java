package com.sanz.leaderboard.commands;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.api.GemsAPI;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class GemsCommand implements CommandExecutor {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzLeaderboard plugin;

    public GemsCommand(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(LEGACY.deserialize("&cUsage: /gems <give|take|set|balance> <player> [jumlah]"));
            return true;
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("balance")) {
            if (args.length < 2) {
                sender.sendMessage(LEGACY.deserialize("&cUsage: /gems balance <player>"));
                return true;
            }
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
            double balance = GemsAPI.getBalance(target.getUniqueId());
            sender.sendMessage(LEGACY.deserialize("&a" + target.getName() + " &7punya &a" + (long) balance + " gems"));
            return true;
        }

        if (!sender.hasPermission("sanzleaderboard.admin")) {
            sender.sendMessage(LEGACY.deserialize("&cKamu gak punya izin buat command ini."));
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage(LEGACY.deserialize("&cUsage: /gems <give|take|set> <player> <jumlah>"));
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        double amount;
        try {
            amount = Double.parseDouble(args[2]);
        } catch (NumberFormatException e) {
            sender.sendMessage(LEGACY.deserialize("&cJumlah harus angka."));
            return true;
        }

        switch (sub) {
            case "give" -> {
                GemsAPI.add(target.getUniqueId(), target.getName(), amount);
                sender.sendMessage(LEGACY.deserialize("&aNambahin &a" + (long) amount + " gems &ake " + target.getName()));
            }
            case "take" -> {
                boolean success = GemsAPI.take(target.getUniqueId(), target.getName(), amount);
                if (success) {
                    sender.sendMessage(LEGACY.deserialize("&aNgurangin &a" + (long) amount + " gems &adari " + target.getName()));
                } else {
                    sender.sendMessage(LEGACY.deserialize("&cBalance " + target.getName() + " gak cukup."));
                }
            }
            case "set" -> {
                GemsAPI.set(target.getUniqueId(), target.getName(), amount);
                sender.sendMessage(LEGACY.deserialize("&aSet gems " + target.getName() + " jadi &a" + (long) amount));
            }
            default -> sender.sendMessage(LEGACY.deserialize("&cSub-command gak dikenal. Pakai: give, take, set, balance"));
        }
        return true;
    }
}
