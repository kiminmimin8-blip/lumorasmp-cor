package com.sanz.leaderboard.leaderboard;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.LeaderboardEntry;
import com.sanz.leaderboard.data.StatType;

import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Nyimpen cache top-N tiap kategori di memory. Di-refresh berkala lewat task async
 * (interval diatur dari config.yml: refresh-interval-seconds).
 * GUI dan hologram baca dari cache ini, bukan query DB langsung, jadi ringan.
 */
public class LeaderboardManager {

    private final SanzLeaderboard plugin;
    private final Map<StatType, List<LeaderboardEntry>> cache = new ConcurrentHashMap<>(new EnumMap<>(StatType.class));

    public LeaderboardManager(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    /** Dipanggil dari task async - query semua kategori aktif dan update cache. */
    public void refresh() {
        int topSize = plugin.getConfig().getInt("top-size", 10);

        for (StatType type : StatType.values()) {
            if (!plugin.getConfig().getBoolean("categories." + type.configKey() + ".enabled", true)) {
                continue;
            }
            List<LeaderboardEntry> top = plugin.getDatabase().getTop(type, topSize);
            cache.put(type, top);
        }
    }

    public List<LeaderboardEntry> getTop(StatType type) {
        return cache.getOrDefault(type, Collections.emptyList());
    }

    public String getDisplayName(StatType type) {
        return plugin.getConfig().getString("categories." + type.configKey() + ".display-name", type.name());
    }

    public String getFormat(StatType type) {
        return plugin.getConfig().getString("categories." + type.configKey() + ".format", "&7#{rank}. &f{player} &7- {value}");
    }

    public boolean isEnabled(StatType type) {
        return plugin.getConfig().getBoolean("categories." + type.configKey() + ".enabled", true);
    }
}
