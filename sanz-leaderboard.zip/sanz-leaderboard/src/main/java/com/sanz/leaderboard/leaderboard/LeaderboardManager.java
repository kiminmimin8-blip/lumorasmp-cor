package com.sanz.leaderboard.leaderboard;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.LeaderboardEntry;
import com.sanz.leaderboard.data.StatType;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Nyimpen cache top-N tiap kategori di memory. Di-refresh berkala lewat task async
 * (interval diatur dari config.yml: refresh-interval-seconds).
 * GUI dan hologram baca dari cache ini, bukan query DB langsung, jadi ringan.
 *
 * Admin/OP di-exclude dari leaderboard manapun (kalau exclude-admins: true di config).
 * Cache-nya nyimpen sejumlah "cacheSize" (= max dari top-size.gui dan top-size.hologram),
 * GUI baca semuanya, hologram cuma ambil beberapa baris pertama.
 */
public class LeaderboardManager {

    private final SanzLeaderboard plugin;
    private final Map<StatType, List<LeaderboardEntry>> cache = new ConcurrentHashMap<>(new EnumMap<>(StatType.class));

    public LeaderboardManager(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    /** Dipanggil dari task async - query semua kategori aktif dan update cache. */
    public void refresh() {
        boolean excludeAdmins = plugin.getConfig().getBoolean("exclude-admins", true);
        int cacheSize = getCacheSize();
        // Ambil buffer lebih banyak dari DB biar setelah difilter admin/OP tetep cukup buat cacheSize
        int fetchBuffer = cacheSize + 25;

        for (StatType type : StatType.values()) {
            if (!plugin.getConfig().getBoolean("categories." + type.configKey() + ".enabled", true)) {
                continue;
            }
            List<LeaderboardEntry> raw = plugin.getDatabase().getTop(type, fetchBuffer);

            List<LeaderboardEntry> filtered = raw.stream()
                    .filter(entry -> !excludeAdmins || !isExcluded(entry.getUuid()))
                    .limit(cacheSize)
                    .collect(Collectors.toList());

            cache.put(type, filtered);
        }
    }

    private boolean isExcluded(UUID uuid) {
        Player online = Bukkit.getPlayer(uuid);
        if (online != null) {
            return online.isOp() || online.hasPermission("sanzleaderboard.exclude");
        }
        try {
            OfflinePlayer offline = Bukkit.getOfflinePlayer(uuid);
            return offline.isOp();
        } catch (Exception e) {
            return false;
        }
    }

    public int getGuiTopSize() {
        return plugin.getConfig().getInt("top-size.gui", 20);
    }

    public int getHologramTopSize() {
        return plugin.getConfig().getInt("top-size.hologram", 10);
    }

    private int getCacheSize() {
        return Math.max(getGuiTopSize(), getHologramTopSize());
    }

    /** Dipakai GUI - list lengkap sampai top-size.gui. */
    public List<LeaderboardEntry> getTop(StatType type) {
        return cache.getOrDefault(type, Collections.emptyList());
    }

    /** Dipakai hologram - cuma sebagian depan sampai top-size.hologram. */
    public List<LeaderboardEntry> getTopForHologram(StatType type) {
        List<LeaderboardEntry> full = getTop(type);
        int limit = getHologramTopSize();
        if (full.size() <= limit) return full;
        return full.subList(0, limit);
    }

    public String getDisplayName(StatType type) {
        return plugin.getConfig().getString("categories." + type.configKey() + ".display-name", type.name());
    }

    public String getFormat(StatType type) {
        return plugin.getConfig().getString("categories." + type.configKey() + ".format", "&7#{rank}. &f{player} &7- {value}");
    }

    public boolean isEnabled(StatType type) {
        return plugin.getConfig().getBoolean("categories." + type.configKey() + ".enabled", true);
    }
}
