package com.sanz.leaderboard.commands;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.api.ShardsAPI;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class ShardsCommand implements CommandExecutor {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzLeaderboard plugin;

    public ShardsCommand(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(LEGACY.deserialize("&cUsage: /shards <give|take|set|balance> <player> [jumlah]"));
            return true;
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("balance")) {
            if (args.length < 2) {
                sender.sendMessage(LEGACY.deserialize("&cUsage: /shards balance <player>"));
                return true;
            }
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
            double balance = ShardsAPI.getBalance(target.getUniqueId());
            sender.sendMessage(LEGACY.deserialize("&d" + target.getName() + " &7punya &d" + (long) balance + " shards"));
            return true;
        }

        if (!sender.hasPermission("sanzleaderboard.admin")) {
            sender.sendMessage(LEGACY.deserialize("&cKamu gak punya izin buat command ini."));
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage(LEGACY.deserialize("&cUsage: /shards <give|take|set> <player> <jumlah>"));
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        double amount;
        try {
            amount = Double.parseDouble(args[2]);
        } catch (NumberFormatException e) {
            sender.sendMessage(LEGACY.deserialize("&cJumlah harus angka."));
            return true;
        }

        switch (sub) {
            case "give" -> {
                ShardsAPI.add(target.getUniqueId(), target.getName(), amount);
                sender.sendMessage(LEGACY.deserialize("&aNambahin &d" + (long) amount + " shards &ake " + target.getName()));
            }
            case "take" -> {
                boolean success = ShardsAPI.take(target.getUniqueId(), target.getName(), amount);
                if (success) {
                    sender.sendMessage(LEGACY.deserialize("&aNgurangin &d" + (long) amount + " shards &adari " + target.getName()));
                } else {
                    sender.sendMessage(LEGACY.deserialize("&cBalance " + target.getName() + " gak cukup."));
                }
            }
            case "set" -> {
                ShardsAPI.set(target.getUniqueId(), target.getName(), amount);
                sender.sendMessage(LEGACY.deserialize("&aSet shards " + target.getName() + " jadi &d" + (long) amount));
            }
            default -> sender.sendMessage(LEGACY.deserialize("&cSub-command gak dikenal. Pakai: give, take, set, balance"));
        }
        return true;
    }
}
