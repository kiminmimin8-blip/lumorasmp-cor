# SanzLeaderboard

Plugin leaderboard standalone buat Sanz SMP — **terpisah dari sanz-core**, gak nyampur.

Ngetrack: **kills, deaths, playtime, money (via Vault), blocks mined/placed, shards (custom currency built-in)**.

## Cara build

Sandbox ini gak ada akses internet buat download dependency Maven, jadi belum ke-compile/tes di sini.
Karena kamu udah pakai GitHub Actions CI buat plugin lain (sanz-core, sanz-market, dll), cara paling gampang:

1. Push folder ini ke repo GitHub baru (`sanz-leaderboard`)
2. Workflow `.github/workflows/build.yml` udah disiapin, auto-build tiap push ke `main`
3. Ambil jar hasil build dari tab **Actions** → artifact `sanz-leaderboard`

Atau build lokal (kalau ada Maven + internet):
```bash
mvn clean package
```
Jar hasil ada di `target/sanz-leaderboard-1.0.0.jar`

## PENTING sebelum build — cek versi API

Di `pom.xml`, dependency `paper-api` masih di-set ke `1.21.11-R0.1-SNAPSHOT` karena aku gak bisa cek
langsung versi API yang tersedia buat Purpur 26.1.2 kamu (gak ada akses internet dari sandbox ini).

**Cek dulu** di https://repo.papermc.io/service/rest/repository/browse/maven-public/io/papermc/paper/paper-api/
versi API mana yang paling deket sama 26.1.2, terus update baris ini di `pom.xml`:
```xml
<artifactId>paper-api</artifactId>
<version>GANTI_SESUAI_VERSI_TERSEDIA</version>
```
Bukkit/Paper API biasanya source-compatible antar minor version yang deket, jadi kemungkinan besar
gak perlu ubah kode lain walau versi API-nya beda dari versi server kamu persis.

## Install

1. Taruh jar di `plugins/`
2. Pastiin **Vault** ke-install kalau mau kategori `money` jalan (opsional, softdepend)
3. Restart server
4. Edit `plugins/SanzLeaderboard/config.yml` kalau mau ubah format/kategori

## Commands

| Command | Fungsi | Permission |
|---|---|---|
| `/leaderboard` atau `/lb` atau `/top` | Buka GUI menu leaderboard | `sanzleaderboard.use` (default: semua) |
| `/leaderboard <kategori>` | Langsung buka detail satu kategori | `sanzleaderboard.use` |
| `/shards balance <player>` | Cek shards player | semua |
| `/shards give\|take\|set <player> <jumlah>` | Kelola shards | `sanzleaderboard.admin` (default: op) |
| `/lbhologram create <kategori>` | Bikin hologram di posisi kamu | `sanzleaderboard.admin` |
| `/lbhologram remove <kategori>` | Hapus hologram | `sanzleaderboard.admin` |
| `/lbhologram list` | List hologram yang aktif | `sanzleaderboard.admin` |

Kategori valid: `kills`, `deaths`, `playtime`, `money`, `blocks_mined`, `blocks_placed`, `shards`

## Integrasi ke plugin lain (sanz-core / sanz-market)

Ada `ShardsAPI` publik buat plugin lain manggil shards tanpa depend ke internal database:

```java
// di plugin lain, tambahin di plugin.yml: softdepend: [SanzLeaderboard]
import com.sanz.leaderboard.api.ShardsAPI;

// cek dulu plugin-nya aktif
if (Bukkit.getPluginManager().isPluginEnabled("SanzLeaderboard")) {
    ShardsAPI.add(player.getUniqueId(), player.getName(), 50);
    double balance = ShardsAPI.getBalance(player.getUniqueId());
    boolean success = ShardsAPI.take(player.getUniqueId(), player.getName(), 20);
}
```

Tambahin dependency ke `pom.xml` plugin lain (scope `provided`, jar-nya ada di classpath server pas runtime):
```xml
<dependency>
    <groupId>com.sanz</groupId>
    <artifactId>sanz-leaderboard</artifactId>
    <version>1.0.0</version>
    <scope>provided</scope>
</dependency>
```

## Arsitektur singkat

- **Storage**: SQLite lokal (`plugins/SanzLeaderboard/database.db`), gak butuh setup database eksternal
- **Performa**: block mine/place di-buffer di memory dulu (bukan query per block), di-flush tiap `refresh-interval-seconds`
- **Cache**: leaderboard top-N di-cache di memory, GUI/hologram baca dari cache bukan query DB langsung
- **Hologram**: pakai `TextDisplay` native Paper API, gak nambah dependency ke DecentHolograms atau library luar
- **Money**: sync dari Vault pas player join & quit, jadi gak polling semua player terus-terusan

## Belum ke-tes end-to-end

Karena keterbatasan sandbox (gak ada Maven + internet), plugin ini **belum pernah di-compile beneran**.
Kemungkinan ada typo/import error kecil yang baru ketauan pas build asli. Kalau ada error compile
pas kamu build, kirim log error-nya ke sini, aku bantu benerin.
