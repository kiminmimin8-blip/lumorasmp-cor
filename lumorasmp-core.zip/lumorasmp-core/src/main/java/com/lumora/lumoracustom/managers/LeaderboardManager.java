package com.lumora.lumoracustom.managers;

import com.lumora.lumoracustom.util.ConfigFile;
import com.lumora.lumoracustom.util.PlaceholderUtil;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Nge-cache top player per board secara berkala. Cuma player yang lagi
 * online yang bisa keupdate datanya tiap refresh (placeholder offline
 * player gak selalu reliable), tapi data lama tetep disimpen di cache
 * sampai player itu online lagi dan keupdate ulang.
 */
public class LeaderboardManager {

    private final JavaPlugin plugin;
    private final ConfigFile configFile;
    // boardName -> (playerName -> value)
    private final Map<String, Map<String, Double>> cache = new ConcurrentHashMap<>();

    public LeaderboardManager(JavaPlugin plugin, ConfigFile configFile) {
        this.plugin = plugin;
        this.configFile = configFile;
    }

    public void start() {
        long intervalTicks = configFile.get().getLong("refresh-interval-seconds", 60) * 20L;
        Bukkit.getGlobalRegionScheduler().runAtFixedRate(plugin, task -> refresh(), 100L, intervalTicks);
    }

    private void refresh() {
        ConfigurationSection boards = configFile.get().getConfigurationSection("boards");
        if (boards == null) return;

        for (String boardName : boards.getKeys(false)) {
            String placeholder = boards.getString(boardName + ".placeholder");
            if (placeholder == null) continue;

            Map<String, Double> boardData = cache.computeIfAbsent(boardName, k -> new ConcurrentHashMap<>());
            for (Player player : Bukkit.getOnlinePlayers()) {
                double value = PlaceholderUtil.getBalance(player, placeholder);
                if (value >= 0) {
                    boardData.put(player.getName(), value);
                }
            }
        }
    }

    public List<Map.Entry<String, Double>> getTop(String boardName, int count) {
        Map<String, Double> boardData = cache.getOrDefault(boardName, Map.of());
        List<Map.Entry<String, Double>> sorted = new ArrayList<>(boardData.entrySet());
        sorted.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
        if (sorted.size() > count) {
            return sorted.subList(0, count);
        }
        return sorted;
    }

    public String getDisplayName(String boardName) {
        return configFile.get().getString("boards." + boardName + ".display-name", boardName);
    }

    public boolean boardExists(String boardName) {
        ConfigurationSection boards = configFile.get().getConfigurationSection("boards");
        return boards != null && boards.contains(boardName);
    }
}
