package com.lumora.lumoracustom.managers;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Crate Blocks - link 1 block di dunia ke 1 crate (gaya ExcellentCrates).
 * Player tinggal klik block itu buat buka crate, gak perlu command.
 * Data disimpan di crates/blocks.yml.
 */
public class CrateBlockManager {

    private final JavaPlugin plugin;
    private final File file;
    private final YamlConfiguration data;
    // "world,x,y,z" -> nama crate, di-cache di memori biar cepet dicek tiap klik
    private final Map<String, String> blockCache = new HashMap<>();

    public CrateBlockManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "crates/blocks.yml");
        if (!file.exists()) {
            try {
                file.getParentFile().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("Gagal bikin crates/blocks.yml: " + e.getMessage());
            }
        }
        this.data = YamlConfiguration.loadConfiguration(file);
        loadCache();
    }

    private String keyOf(Location loc) {
        return loc.getWorld().getName() + "," + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ();
    }

    private void loadCache() {
        var section = data.getConfigurationSection("blocks");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            blockCache.put(key.replace(';', ','), section.getString(key));
        }
    }

    public void linkBlock(Location loc, String crateName) {
        String key = keyOf(loc);
        blockCache.put(key, crateName);
        data.set("blocks." + key.replace(',', ';'), crateName);
        save();
    }

    public void unlinkBlock(Location loc) {
        String key = keyOf(loc);
        blockCache.remove(key);
        data.set("blocks." + key.replace(',', ';'), null);
        save();
    }

    public String getCrateAt(Location loc) {
        return blockCache.get(keyOf(loc));
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal simpan crates/blocks.yml: " + e.getMessage());
        }
    }
}
