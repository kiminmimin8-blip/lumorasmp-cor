package com.lumora.lumoracustom.managers;

import com.lumora.lumoracustom.LumoraCustomPlugin;
import com.lumora.lumoracustom.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Kelola home per player. Data disimpan SATU FILE PER PLAYER di folder
 * userdata/<uuid>.yml — gaya EssentialsX, bukan satu file gede isi
 * semua player (lebih scalable + gak ada resiko 1 file korup ngerusak
 * data semua orang).
 *
 * Format tiap file userdata/<uuid>.yml:
 * homes:
 *   <namahome>:
 *     world/x/y/z/yaw/pitch: ...
 */
public class HomeManager {

    private final LumoraCustomPlugin plugin;
    private final File userdataFolder;
    private final ConfigFile settings;

    public HomeManager(LumoraCustomPlugin plugin) {
        this.plugin = plugin;
        this.settings = new ConfigFile(plugin, "home/config.yml");
        this.userdataFolder = new File(plugin.getDataFolder(), "home/userdata");
        if (!userdataFolder.exists()) {
            userdataFolder.mkdirs();
        }
    }

    private File getPlayerFile(UUID uuid) {
        return new File(userdataFolder, uuid.toString() + ".yml");
    }

    private YamlConfiguration loadPlayerData(UUID uuid) {
        File file = getPlayerFile(uuid);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("Gagal bikin userdata buat " + uuid + ": " + e.getMessage());
            }
        }
        return YamlConfiguration.loadConfiguration(file);
    }

    private void savePlayerData(UUID uuid, YamlConfiguration data) {
        try {
            data.save(getPlayerFile(uuid));
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal simpan userdata buat " + uuid + ": " + e.getMessage());
        }
    }

    public List<String> getHomeNames(UUID uuid) {
        YamlConfiguration data = loadPlayerData(uuid);
        if (data.getConfigurationSection("homes") == null) {
            return new ArrayList<>();
        }
        return new ArrayList<>(data.getConfigurationSection("homes").getKeys(false));
    }

    public int getMaxHomes(Player player) {
        int max = settings.get().getInt("default-max-homes", 2);
        for (int i = 1; i <= 50; i++) {
            if (player.hasPermission("lumora.homes." + i) && i > max) {
                max = i;
            }
        }
        if (player.hasPermission("lumora.homes.unlimited")) {
            return Integer.MAX_VALUE;
        }
        return max;
    }

    public boolean hasHome(UUID uuid, String name) {
        YamlConfiguration data = loadPlayerData(uuid);
        return data.contains("homes." + name.toLowerCase());
    }

    public Location getHome(UUID uuid, String name) {
        YamlConfiguration data = loadPlayerData(uuid);
        String path = "homes." + name.toLowerCase();
        if (!data.contains(path)) return null;

        String worldName = data.getString(path + ".world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;

        double x = data.getDouble(path + ".x");
        double y = data.getDouble(path + ".y");
        double z = data.getDouble(path + ".z");
        float yaw = (float) data.getDouble(path + ".yaw");
        float pitch = (float) data.getDouble(path + ".pitch");
        return new Location(world, x, y, z, yaw, pitch);
    }

    public void setHome(UUID uuid, String name, Location location) {
        YamlConfiguration data = loadPlayerData(uuid);
        String path = "homes." + name.toLowerCase();
        data.set(path + ".world", location.getWorld().getName());
        data.set(path + ".x", location.getX());
        data.set(path + ".y", location.getY());
        data.set(path + ".z", location.getZ());
        data.set(path + ".yaw", (double) location.getYaw());
        data.set(path + ".pitch", (double) location.getPitch());
        savePlayerData(uuid, data);
    }

    public boolean deleteHome(UUID uuid, String name) {
        YamlConfiguration data = loadPlayerData(uuid);
        String path = "homes." + name.toLowerCase();
        if (!data.contains(path)) return false;
        data.set(path, null);
        savePlayerData(uuid, data);
        return true;
    }
}
