package com.lumora.lumoracustom.listeners;

import com.lumora.lumoracustom.managers.WorldsManager;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.world.WorldLoadEvent;

/**
 * Deteksi player jalan masuk ke region portal (Worlds module, fitur lanjutan
 * "Multiverse-lite"). Kalau ketemu, teleport ke destinasi yang udah
 * dikonfigurasi lewat /worldadmin portal create.
 */
public class WorldPortalListener implements Listener {

    private final WorldsManager worldsManager;

    public WorldPortalListener(WorldsManager worldsManager) {
        this.worldsManager = worldsManager;
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Location to = event.getTo();
        if (to == null) return;

        // Optimisasi kecil: skip kalau cuma noleh doang (koordinat blok gak berubah)
        Location from = event.getFrom();
        if (from.getBlockX() == to.getBlockX() && from.getBlockY() == to.getBlockY()
                && from.getBlockZ() == to.getBlockZ() && from.getWorld().equals(to.getWorld())) {
            return;
        }

        Player player = event.getPlayer();
        if (worldsManager.isOnPortalCooldown(player.getUniqueId())) return;

        String portalName = worldsManager.findPortalAt(to);
        if (portalName == null) return;

        Location destination = worldsManager.getPortalDestination(portalName);
        if (destination == null) return;

        worldsManager.setPortalCooldown(player.getUniqueId());
        player.teleportAsync(destination);
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent event) {
        // Auto-apply gamerules per-world yang udah dikonfigurasi, tiap kali world
        // ke-load (server start, world baru dibuat plugin lain, dll).
        worldsManager.applyGameRules(event.getWorld());
    }
}
