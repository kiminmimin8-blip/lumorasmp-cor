package com.lumora.lumoracustom.commands;

import com.lumora.lumoracustom.managers.ArenaManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ArenaCommand implements CommandExecutor {

    private final ArenaManager manager;

    public ArenaCommand(ArenaManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("lumora.arena.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /arena <setpos1|setpos2|save|reset> [nama]");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "setpos1" -> {
                manager.setPos1(player.getUniqueId(), player.getLocation());
                player.sendMessage(ChatColor.GREEN + "Pos1 diset di posisi kamu sekarang.");
            }
            case "setpos2" -> {
                manager.setPos2(player.getUniqueId(), player.getLocation());
                player.sendMessage(ChatColor.GREEN + "Pos2 diset di posisi kamu sekarang.");
            }
            case "save" -> {
                if (args.length < 2) {
                    player.sendMessage(ChatColor.RED + "Gunakan: /arena save <nama>");
                    return true;
                }
                player.sendMessage(ChatColor.YELLOW + "Menyimpan snapshot arena... (bisa makan waktu buat area besar)");
                boolean success = manager.saveArena(args[1], player.getUniqueId());
                player.sendMessage(success
                        ? ChatColor.GREEN + "Arena " + args[1] + " berhasil disimpan!"
                        : ChatColor.RED + "Gagal simpan arena. Pastikan pos1 & pos2 udah di-set.");
            }
            case "reset" -> {
                if (args.length < 2) {
                    player.sendMessage(ChatColor.RED + "Gunakan: /arena reset <nama>");
                    return true;
                }
                if (!manager.arenaExists(args[1])) {
                    player.sendMessage(ChatColor.RED + "Arena " + args[1] + " gak ditemukan.");
                    return true;
                }
                player.sendMessage(ChatColor.YELLOW + "Mereset arena... (bisa makan waktu buat area besar)");
                boolean success = manager.resetArena(args[1]);
                player.sendMessage(success
                        ? ChatColor.GREEN + "Arena " + args[1] + " berhasil direset!"
                        : ChatColor.RED + "Gagal reset arena.");
            }
            default -> player.sendMessage(ChatColor.RED + "Gunakan: /arena <setpos1|setpos2|save|reset> [nama]");
        }
        return true;
    }
}
