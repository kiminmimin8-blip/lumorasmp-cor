package com.lumora.lumoracustom.commands;

import com.lumora.lumoracustom.managers.SellManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Fitur lanjutan modul Shop: instant sell gaya EssentialsX.
 * /sell hand -> jual 1 stack item yang lagi dipegang
 * /sell all  -> jual semua item yang bisa dijual di seluruh inventory
 */
public class SellCommand implements CommandExecutor {

    private final SellManager sellManager;

    public SellCommand(SellManager sellManager) {
        this.sellManager = sellManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (!player.hasPermission("lumora.sell.use")) {
            player.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk pakai command ini.");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(ChatColor.RED + "Gunakan: /sell <hand|all>");
            return true;
        }

        SellManager.SellResult result;
        if (args[0].equalsIgnoreCase("hand")) {
            result = sellManager.sellHand(player);
        } else if (args[0].equalsIgnoreCase("all")) {
            result = sellManager.sellAll(player);
        } else {
            player.sendMessage(ChatColor.RED + "Gunakan: /sell <hand|all>");
            return true;
        }

        if (result.success) {
            player.sendMessage(ChatColor.GREEN + "Berhasil jual " + ChatColor.YELLOW + result.amount
                    + ChatColor.GREEN + " item, dapat " + ChatColor.YELLOW + (long) result.total + ChatColor.GREEN + "!");
        } else {
            player.sendMessage(ChatColor.RED + result.message);
        }
        return true;
    }
}
