package com.lumora.lumoracustom.commands;

import com.lumora.lumoracustom.LumoraCustomPlugin;
import com.lumora.lumoracustom.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class RtpCommand implements CommandExecutor {

    private final LumoraCustomPlugin plugin;
    private final ConfigFile configFile;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public RtpCommand(LumoraCustomPlugin plugin) {
        this.plugin = plugin;
        this.configFile = new ConfigFile(plugin, "rtp/config.yml");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }

        if (!player.hasPermission("lumora.rtp.use")) {
            player.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk ini.");
            return true;
        }

        if (!player.hasPermission("lumora.rtp.bypasscooldown")) {
            long cooldownSeconds = configFile.get().getLong("cooldown-seconds", 30);
            long now = System.currentTimeMillis();
            Long last = cooldowns.get(player.getUniqueId());
            if (last != null) {
                long remaining = (last + cooldownSeconds * 1000L - now) / 1000L;
                if (remaining > 0) {
                    player.sendMessage(ChatColor.RED + "Tunggu " + remaining + " detik lagi buat RTP lagi.");
                    return true;
                }
            }
            cooldowns.put(player.getUniqueId(), now);
        }

        String worldName = configFile.get().getString("world", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            world = player.getWorld();
        }

        int minRadius = configFile.get().getInt("min-radius", 100);
        int maxRadius = configFile.get().getInt("max-radius", 2000);
        int maxAttempts = configFile.get().getInt("max-attempts", 20);

        Set<Material> unsafe = new HashSet<>();
        for (String matName : configFile.get().getStringList("unsafe-materials")) {
            Material mat = Material.matchMaterial(matName);
            if (mat != null) unsafe.add(mat);
        }

        player.sendMessage(ChatColor.YELLOW + "Mencari lokasi aman...");
        findSafeLocationAsync(world, minRadius, maxRadius, maxAttempts, unsafe, player);
        return true;
    }

    /**
     * Cari lokasi aman. FIX FOLIA: lokasi target RTP bisa ratusan/ribuan
     * block jauhnya dari posisi player sekarang, yang berarti hampir pasti
     * beda region thread. Baca block (getHighestBlockYAt/getBlockAt) gak
     * boleh dipanggil langsung dari thread player buat koordinat sejauh
     * itu — makanya dibungkus RegionScheduler.execute() di chunk target
     * biar dieksekusi di thread yang bener-bener "punya" region itu.
     * Attempt dijalanin rekursif (bukan for-loop) karena tiap attempt
     * koordinatnya beda, jadi region thread yang dipake juga bisa beda.
     */
    private void findSafeLocationAsync(World world, int minRadius, int maxRadius,
                                        int maxAttempts, Set<Material> unsafe, Player player) {
        attemptFind(world, minRadius, maxRadius, unsafe, player, 0, maxAttempts);
    }

    private void attemptFind(World world, int minRadius, int maxRadius, Set<Material> unsafe,
                              Player player, int attempt, int maxAttempts) {
        if (attempt >= maxAttempts) {
            player.sendMessage(ChatColor.RED + "Gagal nemu lokasi aman, coba lagi.");
            return;
        }

        ThreadLocalRandom rand = ThreadLocalRandom.current();
        double angle = rand.nextDouble() * 2 * Math.PI;
        int distance = rand.nextInt(minRadius, maxRadius + 1);
        int x = (int) (Math.cos(angle) * distance);
        int z = (int) (Math.sin(angle) * distance);

        Bukkit.getRegionScheduler().execute(plugin, world, x >> 4, z >> 4, () -> {
            int y = world.getHighestBlockYAt(x, z);
            Block block = world.getBlockAt(x, y, z);

            if (!unsafe.contains(block.getType()) && block.getType().isSolid()) {
                Location safeLoc = new Location(world, x + 0.5, y + 1, z + 0.5);
                player.teleportAsync(safeLoc);
                player.sendMessage(ChatColor.GREEN + "Berhasil teleport ke lokasi random!");
            } else {
                attemptFind(world, minRadius, maxRadius, unsafe, player, attempt + 1, maxAttempts);
            }
        });
    }
}
