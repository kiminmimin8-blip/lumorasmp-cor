package com.lumora.lumoracustom.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class CrateEditorHolder implements InventoryHolder {

    private final String crateName;
    private Inventory inventory;

    public CrateEditorHolder(String crateName) {
        this.crateName = crateName;
    }

    public String getCrateName() {
        return crateName;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
