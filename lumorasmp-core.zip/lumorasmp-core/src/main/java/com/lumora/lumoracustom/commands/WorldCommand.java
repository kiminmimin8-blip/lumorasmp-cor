package com.lumora.lumoracustom.commands;

import com.lumora.lumoracustom.generators.VoidChunkGenerator;
import com.lumora.lumoracustom.managers.WorldsManager;
import com.lumora.lumoracustom.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Modul Worlds - "Multiverse-lite" + fitur lanjutan.
 * Fitur dasar: list world, teleport antar world, buat world baru, unload world.
 * Fitur lanjutan:
 *  - Portal antar-world (region kotak pos1/pos2, jalan masuk = teleport)
 *  - Game rule per-world (persist ke gamerules.yml, auto-apply pas world di-load)
 *  - Custom world generator ("void" bawaan, atau nama plugin generator lain)
 *
 * CATATAN FOLIA: create/unload world WAJIB dijalanin di Global Region
 * Thread (bukan thread command biasa), makanya dibungkus
 * Bukkit.getGlobalRegionScheduler(). Di server non-Folia (Paper/Purpur
 * biasa), API ini tetap aman dipakai — otomatis jalan di main thread.
 */
public class WorldCommand implements CommandExecutor {

    private final ConfigFile configFile;
    private final JavaPlugin plugin;
    private final WorldsManager worldsManager;

    public WorldCommand(ConfigFile configFile, JavaPlugin plugin, WorldsManager worldsManager) {
        this.configFile = configFile;
        this.plugin = plugin;
        this.worldsManager = worldsManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("worldadmin")) {
            return handleAdmin(sender, args);
        }
        return handleWorld(sender, args);
    }

    // /world [list|tp <nama>]
    private boolean handleWorld(CommandSender sender, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            List<String> names = Bukkit.getWorlds().stream().map(World::getName).collect(Collectors.toList());
            sender.sendMessage(ChatColor.GRAY + "World yang ke-load: " + ChatColor.WHITE + String.join(", ", names));
            return true;
        }

        if (args[0].equalsIgnoreCase("tp")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
                return true;
            }
            if (args.length < 2) {
                player.sendMessage(ChatColor.RED + "Gunakan: /world tp <nama>");
                return true;
            }

            String worldName = args[1];
            String requiredPerm = configFile.get().getString("world-permissions." + worldName, null);
            if (requiredPerm != null && !player.hasPermission(requiredPerm)) {
                player.sendMessage(ChatColor.RED + "Kamu tidak punya izin ke world ini.");
                return true;
            }

            World world = Bukkit.getWorld(worldName);
            if (world == null) {
                player.sendMessage(ChatColor.RED + "World " + worldName + " gak ditemukan atau belum ke-load.");
                return true;
            }

            player.teleportAsync(world.getSpawnLocation());
            player.sendMessage(ChatColor.GREEN + "Teleport ke world " + ChatColor.YELLOW + worldName + "...");
            return true;
        }

        sender.sendMessage(ChatColor.RED + "Gunakan: /world <list|tp> [nama]");
        return true;
    }

    // /worldadmin <create|unload|portal|gamerule> ...
    private boolean handleAdmin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("lumora.world.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }

        if (args.length < 1) {
            sendAdminUsage(sender);
            return true;
        }

        String action = args[0].toLowerCase();
        switch (action) {
            case "create":
                return handleCreate(sender, args);
            case "unload":
                return handleUnload(sender, args);
            case "portal":
                return handlePortal(sender, args);
            case "gamerule":
                return handleGameRule(sender, args);
            default:
                sendAdminUsage(sender);
                return true;
        }
    }

    private void sendAdminUsage(CommandSender sender) {
        sender.sendMessage(ChatColor.RED + "Gunakan salah satu:");
        sender.sendMessage(ChatColor.GRAY + "/worldadmin create <nama> [NORMAL|NETHER|THE_END] [void|<generator-plugin>]");
        sender.sendMessage(ChatColor.GRAY + "/worldadmin unload <nama>");
        sender.sendMessage(ChatColor.GRAY + "/worldadmin portal pos1|pos2");
        sender.sendMessage(ChatColor.GRAY + "/worldadmin portal create <nama> <destWorld> <x> <y> <z> [yaw] [pitch]");
        sender.sendMessage(ChatColor.GRAY + "/worldadmin portal delete <nama>");
        sender.sendMessage(ChatColor.GRAY + "/worldadmin portal list");
        sender.sendMessage(ChatColor.GRAY + "/worldadmin gamerule <world> <rule> <value>");
    }

    // /worldadmin create <nama> [environment] [void|generator-plugin]
    private boolean handleCreate(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /worldadmin create <nama> [NORMAL|NETHER|THE_END] [void|<generator-plugin>]");
            return true;
        }

        String worldName = args[1];
        if (Bukkit.getWorld(worldName) != null) {
            sender.sendMessage(ChatColor.RED + "World " + worldName + " udah ada/ke-load.");
            return true;
        }

        World.Environment env = World.Environment.NORMAL;
        if (args.length >= 3) {
            try {
                env = World.Environment.valueOf(args[2].toUpperCase());
            } catch (IllegalArgumentException e) {
                sender.sendMessage(ChatColor.RED + "Environment tidak valid. Pakai NORMAL/NETHER/THE_END.");
                return true;
            }
        }

        String generatorArg = args.length >= 4 ? args[3] : null;
        World.Environment finalEnv = env;

        sender.sendMessage(ChatColor.YELLOW + "Membuat world " + worldName + "... ini bisa makan waktu.");
        Bukkit.getGlobalRegionScheduler().execute(plugin, () -> {
            WorldCreator creator = new WorldCreator(worldName).environment(finalEnv);

            if (generatorArg != null) {
                if (generatorArg.equalsIgnoreCase("void")) {
                    creator.generator(new VoidChunkGenerator());
                } else {
                    // Nama plugin lain yang nyediain ChunkGenerator (mis. plugin void/skyblock generator).
                    creator.generator(generatorArg);
                }
            }

            World created = creator.createWorld();
            if (created != null) {
                worldsManager.applyGameRules(created);
            }
            sender.sendMessage(ChatColor.GREEN + "World " + worldName + " berhasil dibuat!"
                    + (generatorArg != null ? ChatColor.GRAY + " (generator: " + generatorArg + ")" : ""));
        });
        return true;
    }

    // /worldadmin unload <nama>
    private boolean handleUnload(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /worldadmin unload <nama>");
            return true;
        }
        String worldName = args[1];
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            sender.sendMessage(ChatColor.RED + "World " + worldName + " gak ke-load.");
            return true;
        }
        Bukkit.getGlobalRegionScheduler().execute(plugin, () -> {
            boolean success = Bukkit.unloadWorld(world, true);
            sender.sendMessage(success
                    ? ChatColor.GREEN + "World " + worldName + " berhasil di-unload."
                    : ChatColor.RED + "Gagal unload (mungkin masih ada player di dalamnya).");
        });
        return true;
    }

    // /worldadmin portal <pos1|pos2|create|delete|list> ...
    private boolean handlePortal(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /worldadmin portal <pos1|pos2|create|delete|list>");
            return true;
        }

        String sub = args[1].toLowerCase();

        if (sub.equals("pos1") || sub.equals("pos2")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
                return true;
            }
            worldsManager.setPos(player.getUniqueId(), sub.equals("pos1") ? 1 : 2, player.getLocation());
            player.sendMessage(ChatColor.GREEN + (sub.equals("pos1") ? "Pos1" : "Pos2")
                    + " portal di-set ke posisi kamu sekarang.");
            return true;
        }

        if (sub.equals("list")) {
            List<String> portals = worldsManager.listPortals();
            sender.sendMessage(ChatColor.GRAY + "Portal terdaftar: " + ChatColor.WHITE
                    + (portals.isEmpty() ? "(belum ada)" : String.join(", ", portals)));
            return true;
        }

        if (sub.equals("delete")) {
            if (args.length < 3) {
                sender.sendMessage(ChatColor.RED + "Gunakan: /worldadmin portal delete <nama>");
                return true;
            }
            boolean deleted = worldsManager.deletePortal(args[2]);
            sender.sendMessage(deleted
                    ? ChatColor.GREEN + "Portal " + args[2] + " berhasil dihapus."
                    : ChatColor.RED + "Portal " + args[2] + " gak ditemukan.");
            return true;
        }

        if (sub.equals("create")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
                return true;
            }
            // /worldadmin portal create <nama> <destWorld> <x> <y> <z> [yaw] [pitch]
            if (args.length < 7) {
                player.sendMessage(ChatColor.RED + "Gunakan: /worldadmin portal create <nama> <destWorld> <x> <y> <z> [yaw] [pitch]");
                return true;
            }

            Location pos1 = worldsManager.getPos1(player.getUniqueId());
            Location pos2 = worldsManager.getPos2(player.getUniqueId());
            if (pos1 == null || pos2 == null) {
                player.sendMessage(ChatColor.RED + "Set pos1 & pos2 dulu (berdiri di sudut region, "
                        + "/worldadmin portal pos1, pindah ke sudut lain, /worldadmin portal pos2).");
                return true;
            }

            String portalName = args[2];
            String destWorldName = args[3];
            World destWorld = Bukkit.getWorld(destWorldName);
            if (destWorld == null) {
                player.sendMessage(ChatColor.RED + "World tujuan " + destWorldName + " gak ditemukan/belum ke-load.");
                return true;
            }

            try {
                double x = Double.parseDouble(args[4]);
                double y = Double.parseDouble(args[5]);
                double z = Double.parseDouble(args[6]);
                float yaw = args.length >= 8 ? Float.parseFloat(args[7]) : 0f;
                float pitch = args.length >= 9 ? Float.parseFloat(args[8]) : 0f;

                Location destination = new Location(destWorld, x, y, z, yaw, pitch);
                boolean created = worldsManager.createPortal(portalName, pos1, pos2, destination);
                if (created) {
                    player.sendMessage(ChatColor.GREEN + "Portal " + ChatColor.YELLOW + portalName
                            + ChatColor.GREEN + " berhasil dibuat!");
                } else {
                    player.sendMessage(ChatColor.RED + "Gagal bikin portal, pastikan pos1 & pos2 di world yang sama.");
                }
            } catch (NumberFormatException e) {
                player.sendMessage(ChatColor.RED + "Koordinat/yaw/pitch harus berupa angka.");
            }
            return true;
        }

        sender.sendMessage(ChatColor.RED + "Gunakan: /worldadmin portal <pos1|pos2|create|delete|list>");
        return true;
    }

    // /worldadmin gamerule <world> <rule> <value>
    private boolean handleGameRule(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /worldadmin gamerule <world> <rule> <value>");
            return true;
        }

        String worldName = args[1];
        String ruleName = args[2];
        String value = args[3];

        String error = worldsManager.setGameRule(worldName, ruleName, value);
        if (error != null) {
            sender.sendMessage(ChatColor.RED + error);
        } else {
            sender.sendMessage(ChatColor.GREEN + "Game rule " + ChatColor.YELLOW + ruleName
                    + ChatColor.GREEN + " di world " + ChatColor.YELLOW + worldName
                    + ChatColor.GREEN + " di-set ke " + ChatColor.YELLOW + value + ChatColor.GREEN + ".");
        }
        return true;
    }
}
