package com.lumora.lumoracustom.managers;

import com.lumora.lumoracustom.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Otak dari modul Worlds versi lanjutan:
 *  - Portal antar-world (region kotak, jalan masuk = teleport)
 *  - Game rule per-world (persist + apply otomatis pas world di-load)
 *  - (Custom generator ditangani langsung di WorldCommand pas createWorld)
 */
public class WorldsManager {

    private final JavaPlugin plugin;
    private final ConfigFile portalsFile;
    private final ConfigFile gamerulesFile;

    // Selection sementara buat bikin portal, gaya WorldEdit pos1/pos2 (in-memory, ilang kalau restart)
    private final Map<UUID, Location> pos1Selection = new HashMap<>();
    private final Map<UUID, Location> pos2Selection = new HashMap<>();

    // Cooldown biar player gak ke-teleport berkali-kali pas masih berdiri di dalam portal
    private final Map<UUID, Long> portalCooldown = new HashMap<>();
    private static final long PORTAL_COOLDOWN_MS = 3000;

    public WorldsManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.portalsFile = new ConfigFile(plugin, "worlds/portals.yml");
        this.gamerulesFile = new ConfigFile(plugin, "worlds/gamerules.yml");
    }

    // ================= Selection (buat bikin portal) =================

    public void setPos(UUID player, int index, Location loc) {
        if (index == 1) pos1Selection.put(player, loc);
        else pos2Selection.put(player, loc);
    }

    public Location getPos1(UUID player) {
        return pos1Selection.get(player);
    }

    public Location getPos2(UUID player) {
        return pos2Selection.get(player);
    }

    // ================= Portal =================

    public boolean createPortal(String name, Location pos1, Location pos2, Location destination) {
        if (pos1.getWorld() == null || !pos1.getWorld().equals(pos2.getWorld())) return false;

        String path = "portals." + name.toLowerCase();
        var cfg = portalsFile.get();
        cfg.set(path + ".world", pos1.getWorld().getName());
        cfg.set(path + ".pos1.x", pos1.getX());
        cfg.set(path + ".pos1.y", pos1.getY());
        cfg.set(path + ".pos1.z", pos1.getZ());
        cfg.set(path + ".pos2.x", pos2.getX());
        cfg.set(path + ".pos2.y", pos2.getY());
        cfg.set(path + ".pos2.z", pos2.getZ());
        cfg.set(path + ".destination.world", destination.getWorld().getName());
        cfg.set(path + ".destination.x", destination.getX());
        cfg.set(path + ".destination.y", destination.getY());
        cfg.set(path + ".destination.z", destination.getZ());
        cfg.set(path + ".destination.yaw", (double) destination.getYaw());
        cfg.set(path + ".destination.pitch", (double) destination.getPitch());
        portalsFile.save();
        return true;
    }

    public boolean deletePortal(String name) {
        String path = "portals." + name.toLowerCase();
        var cfg = portalsFile.get();
        if (!cfg.contains(path)) return false;
        cfg.set(path, null);
        portalsFile.save();
        return true;
    }

    public List<String> listPortals() {
        var section = portalsFile.get().getConfigurationSection("portals");
        if (section == null) return new ArrayList<>();
        return new ArrayList<>(section.getKeys(false));
    }

    /**
     * Cek apakah lokasi ini masuk ke dalam salah satu region portal.
     * Return nama portal kalau ketemu, null kalau enggak.
     */
    public String findPortalAt(Location loc) {
        ConfigurationSection portals = portalsFile.get().getConfigurationSection("portals");
        if (portals == null || loc.getWorld() == null) return null;

        for (String name : portals.getKeys(false)) {
            ConfigurationSection portal = portals.getConfigurationSection(name);
            if (portal == null) continue;
            if (!loc.getWorld().getName().equals(portal.getString("world"))) continue;

            double x1 = portal.getDouble("pos1.x");
            double y1 = portal.getDouble("pos1.y");
            double z1 = portal.getDouble("pos1.z");
            double x2 = portal.getDouble("pos2.x");
            double y2 = portal.getDouble("pos2.y");
            double z2 = portal.getDouble("pos2.z");

            double minX = Math.min(x1, x2), maxX = Math.max(x1, x2);
            double minY = Math.min(y1, y2), maxY = Math.max(y1, y2);
            double minZ = Math.min(z1, z2), maxZ = Math.max(z1, z2);

            if (loc.getX() >= minX && loc.getX() <= maxX
                    && loc.getY() >= minY && loc.getY() <= maxY
                    && loc.getZ() >= minZ && loc.getZ() <= maxZ) {
                return name;
            }
        }
        return null;
    }

    public Location getPortalDestination(String name) {
        ConfigurationSection portal = portalsFile.get().getConfigurationSection("portals." + name.toLowerCase());
        if (portal == null) return null;
        ConfigurationSection dest = portal.getConfigurationSection("destination");
        if (dest == null) return null;

        World world = Bukkit.getWorld(dest.getString("world", ""));
        if (world == null) return null;

        return new Location(world, dest.getDouble("x"), dest.getDouble("y"), dest.getDouble("z"),
                (float) dest.getDouble("yaw"), (float) dest.getDouble("pitch"));
    }

    public boolean isOnPortalCooldown(UUID player) {
        Long last = portalCooldown.get(player);
        return last != null && (System.currentTimeMillis() - last) < PORTAL_COOLDOWN_MS;
    }

    public void setPortalCooldown(UUID player) {
        portalCooldown.put(player, System.currentTimeMillis());
    }

    // ================= Game rule per-world =================

    /**
     * Set + persist 1 game rule buat 1 world, dan langsung apply kalau world-nya lagi ke-load.
     * Return null kalau berhasil, atau pesan error kalau gagal (rule invalid / value invalid).
     */
    public String setGameRule(String worldName, String ruleName, String value) {
        GameRule<?> rule = GameRule.getByName(ruleName);
        if (rule == null) {
            return "Game rule '" + ruleName + "' gak dikenal.";
        }

        Object parsed = parseValue(rule, value);
        if (parsed == null) {
            return "Value '" + value + "' gak valid buat rule '" + ruleName + "' (tipe: " + rule.getType().getSimpleName() + ").";
        }

        gamerulesFile.get().set("worlds." + worldName + "." + ruleName, value);
        gamerulesFile.save();

        World world = Bukkit.getWorld(worldName);
        if (world != null) {
            applyGameRule(world, rule, parsed);
        }
        return null;
    }

    /**
     * Apply semua game rule yang udah dikonfigurasi buat 1 world. Dipanggil pas world
     * di-load (termasuk pas plugin enable, buat semua world yang udah ke-load duluan).
     */
    public void applyGameRules(World world) {
        ConfigurationSection section = gamerulesFile.get().getConfigurationSection("worlds." + world.getName());
        if (section == null) return;

        for (String ruleName : section.getKeys(false)) {
            GameRule<?> rule = GameRule.getByName(ruleName);
            if (rule == null) {
                plugin.getLogger().warning("Game rule '" + ruleName + "' di gamerules.yml (world " + world.getName() + ") gak dikenal, di-skip.");
                continue;
            }
            String rawValue = section.getString(ruleName);
            Object parsed = parseValue(rule, rawValue);
            if (parsed == null) {
                plugin.getLogger().warning("Value '" + rawValue + "' buat rule '" + ruleName + "' (world " + world.getName() + ") gak valid, di-skip.");
                continue;
            }
            applyGameRule(world, rule, parsed);
        }
    }

    @SuppressWarnings("unchecked")
    private void applyGameRule(World world, GameRule<?> rule, Object value) {
        if (rule.getType() == Boolean.class) {
            world.setGameRule((GameRule<Boolean>) rule, (Boolean) value);
        } else if (rule.getType() == Integer.class) {
            world.setGameRule((GameRule<Integer>) rule, (Integer) value);
        }
    }

    private Object parseValue(GameRule<?> rule, String value) {
        try {
            if (rule.getType() == Boolean.class) {
                if (!value.equalsIgnoreCase("true") && !value.equalsIgnoreCase("false")) return null;
                return Boolean.parseBoolean(value);
            } else if (rule.getType() == Integer.class) {
                return Integer.parseInt(value);
            }
        } catch (NumberFormatException e) {
            return null;
        }
        return null;
    }
}
