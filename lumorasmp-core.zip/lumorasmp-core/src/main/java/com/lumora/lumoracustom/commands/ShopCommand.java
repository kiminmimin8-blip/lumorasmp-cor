package com.lumora.lumoracustom.commands;

import com.lumora.lumoracustom.gui.ShopListener;
import com.lumora.lumoracustom.util.ConfigFile;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ShopCommand implements CommandExecutor {

    private final ConfigFile configFile;
    private final ConfigFile guiFile;

    public ShopCommand(ConfigFile configFile, ConfigFile guiFile) {
        this.configFile = configFile;
        this.guiFile = guiFile;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }
        ShopListener.openShop(configFile, guiFile, player);
        return true;
    }
}
