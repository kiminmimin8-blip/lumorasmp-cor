package com.lumora.lumoracustom;

import com.lumora.lumoracustom.commands.ArenaCommand;
import com.lumora.lumoracustom.commands.BillfordCommand;
import com.lumora.lumoracustom.commands.ClearLagCommand;
import com.lumora.lumoracustom.commands.CrateCommand;
import com.lumora.lumoracustom.commands.DuelCommand;
import com.lumora.lumoracustom.commands.EventCommand;
import com.lumora.lumoracustom.commands.HomeCommand;
import com.lumora.lumoracustom.commands.LeaderboardCommand;
import com.lumora.lumoracustom.commands.MaintenanceCommand;
import com.lumora.lumoracustom.commands.MobRadiusCommand;
import com.lumora.lumoracustom.commands.RankShopCommand;
import com.lumora.lumoracustom.commands.RtpCommand;
import com.lumora.lumoracustom.commands.SellCommand;
import com.lumora.lumoracustom.commands.ShopCommand;
import com.lumora.lumoracustom.commands.SpawnCommand;
import com.lumora.lumoracustom.commands.WorldCommand;
import com.lumora.lumoracustom.gui.BillfordListener;
import com.lumora.lumoracustom.gui.CrateEditorListener;
import com.lumora.lumoracustom.gui.RankShopListener;
import com.lumora.lumoracustom.gui.ShopListener;
import com.lumora.lumoracustom.listeners.DuelListener;
import com.lumora.lumoracustom.listeners.JoinLeaveListener;
import com.lumora.lumoracustom.listeners.MaintenanceListener;
import com.lumora.lumoracustom.listeners.MobSpawnListener;
import com.lumora.lumoracustom.listeners.MotdListener;
import com.lumora.lumoracustom.listeners.WorldPortalListener;
import com.lumora.lumoracustom.managers.ArenaManager;
import com.lumora.lumoracustom.managers.CrateManager;
import com.lumora.lumoracustom.managers.CrateBlockManager;
import com.lumora.lumoracustom.managers.CrateKeyManager;
import com.lumora.lumoracustom.listeners.CrateBlockListener;
import com.lumora.lumoracustom.managers.DuelManager;
import com.lumora.lumoracustom.managers.EventManager;
import com.lumora.lumoracustom.managers.HomeManager;
import com.lumora.lumoracustom.managers.LeaderboardManager;
import com.lumora.lumoracustom.managers.SellManager;
import com.lumora.lumoracustom.managers.SpawnManager;
import com.lumora.lumoracustom.managers.WorldsManager;
import com.lumora.lumoracustom.tasks.ClearLagTask;
import com.lumora.lumoracustom.util.ConfigFile;
import org.bukkit.World;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * LumoraSMP-Core - plugin inti gabungan buat Lumora SMP (Folia 1.21.11).
 *
 * Struktur folder MODULAR (kayak EssentialsX) - tiap fitur punya folder
 * & config.yml sendiri di plugins/LumoraSMPCore/<fitur>/config.yml.
 *
 * 16 Modul:
 *  1. Mob Spawn Radius Blocker      9. Clearlag
 *  2. RankShop                     10. Worlds (portal, gamerule, generator)
 *  3. Spawn                        11. Shop (buy/sell item)
 *  4. Home                         12. Leaderboard
 *  5. RTP                          13. Event (tp lokasi event)
 *  6. Join/Leave message           14. Arena Regen/Reset
 *  7. MOTD                         15. Duel
 *  8. Maintenance mode             16. Billford (barter item)
 */
public final class LumoraCustomPlugin extends JavaPlugin {

    private static LumoraCustomPlugin instance;

    private SpawnManager spawnManager;
    private HomeManager homeManager;

    @Override
    public void onEnable() {
        instance = this;

        // ===== Init manager berbasis config folder sendiri =====
        this.spawnManager = new SpawnManager(this);
        this.homeManager = new HomeManager(this);

        ConfigFile mobSpawnConfig = new ConfigFile(this, "mobspawn/config.yml");
        ConfigFile rankShopConfig = new ConfigFile(this, "rankshop/config.yml");
        ConfigFile rankShopGui = new ConfigFile(this, "rankshop/gui.yml");
        ConfigFile joinMessagesConfig = new ConfigFile(this, "joinmessages/config.yml");
        ConfigFile motdConfig = new ConfigFile(this, "motd/config.yml");
        ConfigFile maintenanceConfig = new ConfigFile(this, "maintenance/config.yml");
        ConfigFile clearLagConfig = new ConfigFile(this, "clearlag/config.yml");
        ConfigFile worldsConfig = new ConfigFile(this, "worlds/config.yml");
        ConfigFile shopConfig = new ConfigFile(this, "shop/config.yml");
        ConfigFile shopGui = new ConfigFile(this, "shop/gui.yml");
        ConfigFile leaderboardConfig = new ConfigFile(this, "leaderboard/config.yml");
        ConfigFile eventConfig = new ConfigFile(this, "event/config.yml");
        ConfigFile arenaConfig = new ConfigFile(this, "arena/config.yml");
        ConfigFile duelConfig = new ConfigFile(this, "duel/config.yml");
        ConfigFile billfordConfig = new ConfigFile(this, "billford/config.yml");
        ConfigFile billfordGui = new ConfigFile(this, "billford/gui.yml");
        ConfigFile cratesConfig = new ConfigFile(this, "crates/config.yml");
        ConfigFile cratesGui = new ConfigFile(this, "crates/gui.yml");
        CrateManager crateManager = new CrateManager(this, cratesConfig, cratesGui);
        CrateBlockManager crateBlockManager = new CrateBlockManager(this);
        CrateKeyManager crateKeyManager = new CrateKeyManager(this);
        getServer().getPluginManager().registerEvents(
                new CrateBlockListener(crateBlockManager, crateManager, crateKeyManager), this);

        EventManager eventManager = new EventManager(eventConfig);
        ArenaManager arenaManager = new ArenaManager(this, arenaConfig);
        DuelManager duelManager = new DuelManager(duelConfig);
        LeaderboardManager leaderboardManager = new LeaderboardManager(this, leaderboardConfig);
        leaderboardManager.start();

        WorldsManager worldsManager = new WorldsManager(this);
        // Apply gamerule yang udah dikonfigurasi ke semua world yang udah ke-load
        // duluan (world yang di-load pas server start, sebelum plugin ini enable).
        for (World world : getServer().getWorlds()) {
            worldsManager.applyGameRules(world);
        }

        // ===== Daftarin listener =====
        getServer().getPluginManager().registerEvents(new MobSpawnListener(mobSpawnConfig), this);
        getServer().getPluginManager().registerEvents(new RankShopListener(rankShopConfig, rankShopGui), this);
        getServer().getPluginManager().registerEvents(new JoinLeaveListener(joinMessagesConfig), this);
        getServer().getPluginManager().registerEvents(new MotdListener(motdConfig), this);
        getServer().getPluginManager().registerEvents(new MaintenanceListener(maintenanceConfig), this);
        getServer().getPluginManager().registerEvents(new ShopListener(shopConfig, shopGui), this);
        getServer().getPluginManager().registerEvents(new DuelListener(duelManager), this);
        getServer().getPluginManager().registerEvents(new BillfordListener(billfordConfig, billfordGui), this);
        getServer().getPluginManager().registerEvents(new WorldPortalListener(worldsManager), this);

        // ===== Daftarin command =====
        if (getCommand("mobradius") != null) getCommand("mobradius").setExecutor(new MobRadiusCommand(mobSpawnConfig));
        if (getCommand("rankshop") != null) getCommand("rankshop").setExecutor(new RankShopCommand(rankShopConfig, rankShopGui));

        SpawnCommand spawnCommand = new SpawnCommand(this);
        if (getCommand("spawn") != null) getCommand("spawn").setExecutor(spawnCommand);
        if (getCommand("setspawn") != null) getCommand("setspawn").setExecutor(spawnCommand);

        HomeCommand homeCommand = new HomeCommand(this);
        if (getCommand("home") != null) getCommand("home").setExecutor(homeCommand);
        if (getCommand("sethome") != null) getCommand("sethome").setExecutor(homeCommand);
        if (getCommand("delhome") != null) getCommand("delhome").setExecutor(homeCommand);
        if (getCommand("homes") != null) getCommand("homes").setExecutor(homeCommand);

        if (getCommand("rtp") != null) getCommand("rtp").setExecutor(new RtpCommand(this));
        if (getCommand("maintenance") != null) getCommand("maintenance").setExecutor(new MaintenanceCommand(maintenanceConfig));

        ClearLagTask clearLagTask = new ClearLagTask(this, clearLagConfig);
        clearLagTask.start();
        if (getCommand("clearlag") != null) getCommand("clearlag").setExecutor(new ClearLagCommand(clearLagTask));

        WorldCommand worldCommand = new WorldCommand(worldsConfig, this, worldsManager);
        if (getCommand("world") != null) getCommand("world").setExecutor(worldCommand);
        if (getCommand("worldadmin") != null) getCommand("worldadmin").setExecutor(worldCommand);

        if (getCommand("shop") != null) getCommand("shop").setExecutor(new ShopCommand(shopConfig, shopGui));

        SellManager sellManager = new SellManager(shopConfig, shopGui);
        if (getCommand("sell") != null) getCommand("sell").setExecutor(new SellCommand(sellManager));
        if (getCommand("leaderboard") != null) getCommand("leaderboard").setExecutor(new LeaderboardCommand(leaderboardManager, leaderboardConfig));

        EventCommand eventCommand = new EventCommand(eventManager);
        if (getCommand("event") != null) getCommand("event").setExecutor(eventCommand);
        if (getCommand("setevent") != null) getCommand("setevent").setExecutor(eventCommand);

        if (getCommand("arena") != null) getCommand("arena").setExecutor(new ArenaCommand(arenaManager));
        if (getCommand("duel") != null) getCommand("duel").setExecutor(new DuelCommand(duelManager));
        if (getCommand("billford") != null) getCommand("billford").setExecutor(new BillfordCommand(billfordConfig, billfordGui));

        CrateCommand crateCommand = new CrateCommand(crateManager, crateBlockManager, crateKeyManager);
        if (getCommand("crate") != null) getCommand("crate").setExecutor(crateCommand);
        if (getCommand("cratekey") != null) getCommand("cratekey").setExecutor(crateCommand);
        getServer().getPluginManager().registerEvents(new CrateEditorListener(crateManager), this);

        boolean papiFound = getServer().getPluginManager().getPlugin("PlaceholderAPI") != null;
        if (!papiFound) {
            getLogger().warning("PlaceholderAPI tidak ditemukan! Fitur RankShop/Shop/Leaderboard butuh " +
                    "PlaceholderAPI buat baca saldo/statistik player. Silakan install PlaceholderAPI.");
        }

        getLogger().info("LumoraSMP-Core aktif! 16 modul terpasang.");
    }

    @Override
    public void onDisable() {
        getLogger().info("LumoraSMP-Core dimatikan.");
    }

    public static LumoraCustomPlugin getInstance() {
        return instance;
    }

    public SpawnManager getSpawnManager() {
        return spawnManager;
    }

    public HomeManager getHomeManager() {
        return homeManager;
    }
}
