package com.lumora.lumoracustom.managers;

import com.lumora.lumoracustom.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Snapshot & restore block dalam sebuah cuboid region TANPA WorldEdit
 * (biar gak nambah dependency). Cocok buat arena kecil-menengah.
 *
 * CATATAN buat dev yang optimasi: kalau server kamu udah ada WorldEdit
 * terpasang, jauh lebih efisien pakai WorldEdit API (EditSession +
 * clipboard) buat area yang lebih besar. Versi ini pola paling
 * sederhana yang gak butuh dependency tambahan.
 *
 * Snapshot disimpan sebagai file teks di folder arena/data/<nama>.snapshot
 * format per baris: relX,relY,relZ,blockDataString
 */
public class ArenaManager {

    private final JavaPlugin plugin;
    private final ConfigFile configFile;
    private final File dataFolder;

    // player -> pos1/pos2 sementara buat proses setpos
    private final Map<UUID, Location> pos1Map = new HashMap<>();
    private final Map<UUID, Location> pos2Map = new HashMap<>();

    public ArenaManager(JavaPlugin plugin, ConfigFile configFile) {
        this.plugin = plugin;
        this.configFile = configFile;
        this.dataFolder = new File(plugin.getDataFolder(), "arena/data");
        if (!dataFolder.exists()) dataFolder.mkdirs();
    }

    public void setPos1(UUID uuid, Location loc) {
        pos1Map.put(uuid, loc);
    }

    public void setPos2(UUID uuid, Location loc) {
        pos2Map.put(uuid, loc);
    }

    public Location getPos1(UUID uuid) {
        return pos1Map.get(uuid);
    }

    public Location getPos2(UUID uuid) {
        return pos2Map.get(uuid);
    }

    /**
     * Simpan region antara pos1-pos2 sebagai arena baru + snapshot block-nya.
     */
    public boolean saveArena(String name, UUID uuid) {
        Location pos1 = pos1Map.get(uuid);
        Location pos2 = pos2Map.get(uuid);
        if (pos1 == null || pos2 == null || pos1.getWorld() == null) return false;

        int minX = Math.min(pos1.getBlockX(), pos2.getBlockX());
        int minY = Math.min(pos1.getBlockY(), pos2.getBlockY());
        int minZ = Math.min(pos1.getBlockZ(), pos2.getBlockZ());
        int maxX = Math.max(pos1.getBlockX(), pos2.getBlockX());
        int maxY = Math.max(pos1.getBlockY(), pos2.getBlockY());
        int maxZ = Math.max(pos1.getBlockZ(), pos2.getBlockZ());

        // simpan metadata arena ke config
        String path = "arenas." + name;
        var cfg = configFile.get();
        cfg.set(path + ".world", pos1.getWorld().getName());
        cfg.set(path + ".minX", minX);
        cfg.set(path + ".minY", minY);
        cfg.set(path + ".minZ", minZ);
        cfg.set(path + ".maxX", maxX);
        cfg.set(path + ".maxY", maxY);
        cfg.set(path + ".maxZ", maxZ);
        configFile.save();

        // snapshot block
        World world = pos1.getWorld();
        File snapshotFile = new File(dataFolder, name + ".snapshot");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(snapshotFile))) {
            for (int x = minX; x <= maxX; x++) {
                for (int y = minY; y <= maxY; y++) {
                    for (int z = minZ; z <= maxZ; z++) {
                        Block block = world.getBlockAt(x, y, z);
                        String data = block.getBlockData().getAsString();
                        writer.write((x - minX) + "," + (y - minY) + "," + (z - minZ) + "," + data);
                        writer.newLine();
                    }
                }
            }
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal simpan snapshot arena " + name + ": " + e.getMessage());
            return false;
        }
        return true;
    }

    /**
     * Reset arena ke kondisi snapshot terakhir. Dijalankan sync (bisa berat
     * buat arena besar) — dev sebaiknya pecah jadi batch per-tick kalau
     * arena-nya gede biar gak nge-freeze server.
     */
    public boolean resetArena(String name) {
        String path = "arenas." + name;
        var cfg = configFile.get();
        if (!cfg.contains(path)) return false;

        String worldName = cfg.getString(path + ".world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) return false;

        int minX = cfg.getInt(path + ".minX");
        int minY = cfg.getInt(path + ".minY");
        int minZ = cfg.getInt(path + ".minZ");

        File snapshotFile = new File(dataFolder, name + ".snapshot");
        if (!snapshotFile.exists()) return false;

        try (BufferedReader reader = new BufferedReader(new FileReader(snapshotFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", 4);
                if (parts.length < 4) continue;
                int relX = Integer.parseInt(parts[0]);
                int relY = Integer.parseInt(parts[1]);
                int relZ = Integer.parseInt(parts[2]);
                String blockDataString = parts[3];

                Block block = world.getBlockAt(minX + relX, minY + relY, minZ + relZ);
                BlockData data = Bukkit.createBlockData(blockDataString);
                block.setBlockData(data, false);
            }
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal reset arena " + name + ": " + e.getMessage());
            return false;
        }
        return true;
    }

    public boolean arenaExists(String name) {
        return configFile.get().contains("arenas." + name);
    }
}
