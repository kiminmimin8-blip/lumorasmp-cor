package com.lumora.lumoracustom.managers;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

/**
 * Virtual Keys - simpan jumlah key sebagai ANGKA di data player, bukan
 * item fisik di inventory. Gunanya biar key gak bisa di-trade/jual/drop
 * sama player (gaya ExcellentCrates "Virtual Keys").
 *
 * Data disimpan per-player di crates/keydata/<uuid>.yml, konsisten sama
 * pola userdata/ folder yang dipakai modul Home.
 */
public class CrateKeyManager {

    private final JavaPlugin plugin;
    private final File folder;

    public CrateKeyManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.folder = new File(plugin.getDataFolder(), "crates/keydata");
        if (!folder.exists()) folder.mkdirs();
    }

    private File fileFor(UUID uuid) {
        return new File(folder, uuid.toString() + ".yml");
    }

    private YamlConfiguration load(UUID uuid) {
        File f = fileFor(uuid);
        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("Gagal bikin key data buat " + uuid + ": " + e.getMessage());
            }
        }
        return YamlConfiguration.loadConfiguration(f);
    }

    private void save(UUID uuid, YamlConfiguration data) {
        try {
            data.save(fileFor(uuid));
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal simpan key data buat " + uuid + ": " + e.getMessage());
        }
    }

    public int getVirtualKeys(UUID uuid, String crateName) {
        return load(uuid).getInt("keys." + crateName, 0);
    }

    public void addVirtualKeys(UUID uuid, String crateName, int amount) {
        YamlConfiguration data = load(uuid);
        int current = data.getInt("keys." + crateName, 0);
        data.set("keys." + crateName, current + amount);
        save(uuid, data);
    }

    public boolean removeOneVirtualKey(UUID uuid, String crateName) {
        YamlConfiguration data = load(uuid);
        int current = data.getInt("keys." + crateName, 0);
        if (current <= 0) return false;
        data.set("keys." + crateName, current - 1);
        save(uuid, data);
        return true;
    }

    public boolean hasVirtualKey(Player player, String crateName) {
        return getVirtualKeys(player.getUniqueId(), crateName) > 0;
    }
}
