package com.lumora.lumoracustom.managers;

import com.lumora.lumoracustom.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.ArrayList;
import java.util.List;

public class EventManager {

    private final ConfigFile configFile;

    public EventManager(ConfigFile configFile) {
        this.configFile = configFile;
    }

    public List<String> getEventNames() {
        var section = configFile.get().getConfigurationSection("locations");
        if (section == null) return new ArrayList<>();
        return new ArrayList<>(section.getKeys(false));
    }

    public boolean hasEvent(String name) {
        return configFile.get().contains("locations." + name.toLowerCase());
    }

    public Location getEvent(String name) {
        String path = "locations." + name.toLowerCase();
        var cfg = configFile.get();
        if (!cfg.contains(path)) return null;

        String worldName = cfg.getString(path + ".world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;

        double x = cfg.getDouble(path + ".x");
        double y = cfg.getDouble(path + ".y");
        double z = cfg.getDouble(path + ".z");
        float yaw = (float) cfg.getDouble(path + ".yaw");
        float pitch = (float) cfg.getDouble(path + ".pitch");
        return new Location(world, x, y, z, yaw, pitch);
    }

    public void setEvent(String name, Location location) {
        String path = "locations." + name.toLowerCase();
        var cfg = configFile.get();
        cfg.set(path + ".world", location.getWorld().getName());
        cfg.set(path + ".x", location.getX());
        cfg.set(path + ".y", location.getY());
        cfg.set(path + ".z", location.getZ());
        cfg.set(path + ".yaw", (double) location.getYaw());
        cfg.set(path + ".pitch", (double) location.getPitch());
        configFile.save();
    }
}
