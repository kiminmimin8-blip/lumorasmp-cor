package com.lumora.lumoracustom.commands;

import com.lumora.lumoracustom.managers.DuelManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class DuelCommand implements CommandExecutor {

    private final DuelManager manager;

    public DuelCommand(DuelManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(ChatColor.RED + "Gunakan: /duel <nama player> ATAU /duel accept ATAU /duel deny");
            return true;
        }

        if (args[0].equalsIgnoreCase("accept")) {
            UUID requesterId = manager.getRequester(player.getUniqueId());
            if (requesterId == null) {
                player.sendMessage(ChatColor.RED + "Gak ada request duel buat kamu.");
                return true;
            }
            Player requester = Bukkit.getPlayer(requesterId);
            if (requester == null || !requester.isOnline()) {
                player.sendMessage(ChatColor.RED + "Player yang ngajak duel udah offline.");
                manager.clearRequest(player.getUniqueId());
                return true;
            }
            manager.clearRequest(player.getUniqueId());
            manager.startDuel(requester, player);
            requester.sendMessage(ChatColor.GREEN + player.getName() + " menerima duel! Bersiap...");
            player.sendMessage(ChatColor.GREEN + "Kamu menerima duel dari " + requester.getName() + "! Bersiap...");
            return true;
        }

        if (args[0].equalsIgnoreCase("deny")) {
            manager.clearRequest(player.getUniqueId());
            player.sendMessage(ChatColor.YELLOW + "Request duel ditolak.");
            return true;
        }

        // /duel <nama player>
        if (manager.isInDuel(player.getUniqueId())) {
            player.sendMessage(ChatColor.RED + "Kamu lagi duel sekarang, gak bisa ngajak duel lain.");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null || !target.isOnline()) {
            player.sendMessage(ChatColor.RED + "Player " + args[0] + " gak ditemukan/offline.");
            return true;
        }
        if (target.equals(player)) {
            player.sendMessage(ChatColor.RED + "Gak bisa ngajak diri sendiri duel.");
            return true;
        }
        if (manager.isInDuel(target.getUniqueId())) {
            player.sendMessage(ChatColor.RED + target.getName() + " lagi duel sama orang lain.");
            return true;
        }

        manager.sendRequest(player, target);
        player.sendMessage(ChatColor.GREEN + "Request duel dikirim ke " + target.getName() + "!");
        target.sendMessage(ChatColor.YELLOW + player.getName() + " ngajak kamu duel! " +
                ChatColor.GREEN + "/duel accept" + ChatColor.YELLOW + " buat terima, " +
                ChatColor.RED + "/duel deny" + ChatColor.YELLOW + " buat tolak.");
        return true;
    }
}
