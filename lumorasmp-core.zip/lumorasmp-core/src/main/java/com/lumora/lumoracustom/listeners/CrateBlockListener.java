package com.lumora.lumoracustom.listeners;

import com.lumora.lumoracustom.managers.CrateBlockManager;
import com.lumora.lumoracustom.managers.CrateKeyManager;
import com.lumora.lumoracustom.managers.CrateManager;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

/**
 * Crate Blocks (gaya ExcellentCrates): klik kanan block yang udah
 * di-link ke crate lewat /crate setblock -> otomatis coba buka crate
 * itu (pakai physical key di tangan ATAU virtual key kalau
 * "virtual-keys: true" di config crate-nya).
 */
public class CrateBlockListener implements Listener {

    private final CrateBlockManager blockManager;
    private final CrateManager crateManager;
    private final CrateKeyManager keyManager;

    public CrateBlockListener(CrateBlockManager blockManager, CrateManager crateManager, CrateKeyManager keyManager) {
        this.blockManager = blockManager;
        this.crateManager = crateManager;
        this.keyManager = keyManager;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;

        String crateName = blockManager.getCrateAt(event.getClickedBlock().getLocation());
        if (crateName == null) return;

        event.setCancelled(true);
        Player player = event.getPlayer();

        if (!crateManager.crateExists(crateName)) {
            player.sendMessage(ChatColor.RED + "Crate " + crateName + " udah gak ada lagi (mungkin dihapus dari config).");
            return;
        }

        boolean virtual = crateManager.isVirtualKeyMode(crateName);

        if (virtual) {
            if (!keyManager.hasVirtualKey(player, crateName)) {
                player.sendMessage(ChatColor.RED + "Kamu gak punya virtual key buat " +
                        crateManager.getDisplayName(crateName) + "!");
                return;
            }
            keyManager.removeOneVirtualKey(player.getUniqueId(), crateName);
        } else {
            if (!crateManager.isHoldingKey(player, crateName)) {
                player.sendMessage(ChatColor.RED + "Kamu harus pegang " + crateManager.getDisplayName(crateName) +
                        " Key di tangan buat buka crate ini!");
                return;
            }
            crateManager.removeOneKey(player);
        }

        crateManager.openCrate(player, crateName);
    }
}
