package com.sanz.sanzcore.commands;

import com.sanz.sanzcore.gui.CrateEditorListener;
import com.sanz.sanzcore.gui.CratePreviewListener;
import com.sanz.sanzcore.managers.CrateBlockManager;
import com.sanz.sanzcore.managers.CrateKeyManager;
import com.sanz.sanzcore.managers.CrateManager;
import com.sanz.sanzcore.managers.CrateHologramManager;
import org.bukkit.ChatColor;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /crate open <nama>                          -> buka 1 crate (butuh key)
 * /crate edit <nama>                          -> editor GUI (admin)
 * /crate preview <nama>                       -> lihat reward + peluang (read-only)
 * /crate setweight <nama> <rewardId> <angka>  -> ubah peluang reward (admin)
 * /crate setblock <nama>                      -> link block yang lagi diliat ke crate (admin)
 * /crate removeblock                          -> unlink block yang lagi diliat (admin)
 * /crate list                                 -> lihat semua crate
 * /crate reload                               -> reload config dari disk
 * /cratekey give <player> <crate> <jumlah>    -> admin kasih key (fisik/virtual otomatis)
 */
public class CrateCommand implements CommandExecutor {

    private final CrateManager manager;
    private final CrateBlockManager blockManager;
    private final CrateKeyManager keyManager;
    private final CrateHologramManager hologramManager;

    public CrateCommand(CrateManager manager, CrateBlockManager blockManager, CrateKeyManager keyManager,
                         CrateHologramManager hologramManager) {
        this.manager = manager;
        this.blockManager = blockManager;
        this.keyManager = keyManager;
        this.hologramManager = hologramManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("cratekey")) {
            return handleGiveKey(sender, args);
        }

        if (args.length == 0) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /crate <open|edit|preview|setweight|setblock|removeblock|list|reload> ...");
            return true;
        }

        return switch (args[0].toLowerCase()) {
            case "open" -> handleOpen(sender, args);
            case "edit" -> handleEdit(sender, args);
            case "preview" -> handlePreview(sender, args);
            case "setweight" -> handleSetWeight(sender, args);
            case "setblock" -> handleSetBlock(sender, args);
            case "removeblock" -> handleRemoveBlock(sender);
            case "list" -> handleList(sender);
            case "reload" -> handleReload(sender);
            default -> {
                sender.sendMessage(ChatColor.RED + "Gunakan: /crate <open|edit|preview|setweight|setblock|removeblock|list|reload> ...");
                yield true;
            }
        };
    }

    private boolean handleOpen(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Gunakan: /crate open <nama crate>");
            return true;
        }

        String crateName = args[1];
        if (!manager.crateExists(crateName)) {
            player.sendMessage(ChatColor.RED + "Crate " + crateName + " gak ditemukan.");
            return true;
        }

        boolean virtual = manager.isVirtualKeyMode(crateName);
        if (virtual) {
            if (!keyManager.hasVirtualKey(player, crateName)) {
                player.sendMessage(ChatColor.RED + "Kamu gak punya virtual key buat crate ini!");
                return true;
            }
            keyManager.removeOneVirtualKey(player.getUniqueId(), crateName);
        } else {
            if (!manager.isHoldingKey(player, crateName)) {
                player.sendMessage(ChatColor.RED + "Kamu harus pegang " + manager.getDisplayName(crateName) +
                        " Key di tangan buat buka crate ini!");
                return true;
            }
            manager.removeOneKey(player);
        }

        manager.openCrate(player, crateName);
        return true;
    }

    private boolean handleEdit(CommandSender sender, String[] args) {
        if (!sender.hasPermission("lumora.crate.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Gunakan: /crate edit <nama crate>");
            return true;
        }
        String crateName = args[1];
        if (!manager.crateExists(crateName)) {
            player.sendMessage(ChatColor.RED + "Crate " + crateName + " gak ditemukan.");
            return true;
        }
        CrateEditorListener.openEditor(manager, player, crateName);
        return true;
    }

    private boolean handlePreview(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Gunakan: /crate preview <nama crate>");
            return true;
        }
        String crateName = args[1];
        if (!manager.crateExists(crateName)) {
            player.sendMessage(ChatColor.RED + "Crate " + crateName + " gak ditemukan.");
            return true;
        }
        CratePreviewListener.openPreview(manager, player, crateName);
        return true;
    }

    private boolean handleSetWeight(CommandSender sender, String[] args) {
        if (!sender.hasPermission("lumora.crate.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }
        if (args.length < 4) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /crate setweight <crate> <rewardId> <angka>");
            return true;
        }
        try {
            int weight = Integer.parseInt(args[3]);
            boolean success = manager.setWeight(args[1], args[2], weight);
            sender.sendMessage(success
                    ? ChatColor.GREEN + "Weight reward " + args[2] + " diset ke " + weight
                    : ChatColor.RED + "Reward " + args[2] + " gak ditemukan di crate " + args[1]);
        } catch (NumberFormatException e) {
            sender.sendMessage(ChatColor.RED + "Angka weight tidak valid.");
        }
        return true;
    }

    private boolean handleSetBlock(CommandSender sender, String[] args) {
        if (!sender.hasPermission("lumora.crate.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Gunakan: /crate setblock <nama crate> (liat ke block yang mau di-link)");
            return true;
        }
        String crateName = args[1];
        if (!manager.crateExists(crateName)) {
            player.sendMessage(ChatColor.RED + "Crate " + crateName + " gak ditemukan.");
            return true;
        }

        Block target = player.getTargetBlockExact(5);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "Gak ada block dalam jangkauan 5 blok. Liat ke block yang mau di-link.");
            return true;
        }

        blockManager.linkBlock(target.getLocation(), crateName);
        hologramManager.createHologram(target.getLocation(), crateName, manager.getDisplayName(crateName));
        player.sendMessage(ChatColor.GREEN + "Block di " + target.getX() + "," + target.getY() + "," + target.getZ() +
                " berhasil di-link ke crate " + crateName + "! Klik kanan block itu buat buka crate.");
        return true;
    }

    private boolean handleRemoveBlock(CommandSender sender) {
        if (!sender.hasPermission("lumora.crate.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }
        Block target = player.getTargetBlockExact(5);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "Gak ada block dalam jangkauan 5 blok.");
            return true;
        }
        blockManager.unlinkBlock(target.getLocation());
        hologramManager.removeHologram(target.getLocation());
        player.sendMessage(ChatColor.GREEN + "Link crate block berhasil dihapus.");
        return true;
    }

    private boolean handleList(CommandSender sender) {
        var names = manager.getCrateNames();
        sender.sendMessage(ChatColor.GRAY + "Crate tersedia: " + ChatColor.WHITE + String.join(", ", names));
        return true;
    }

    private boolean handleReload(CommandSender sender) {
        if (!sender.hasPermission("lumora.crate.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }
        manager.reload();
        sender.sendMessage(ChatColor.GREEN + "Config crate berhasil di-reload.");
        return true;
    }

    private boolean handleGiveKey(CommandSender sender, String[] args) {
        if (!sender.hasPermission("lumora.crate.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }
        if (args.length < 3 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /cratekey give <player> <crate> [jumlah]");
            return true;
        }

        Player target = sender.getServer().getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player " + args[1] + " gak ditemukan/offline.");
            return true;
        }

        String crateName = args[2];
        if (!manager.crateExists(crateName)) {
            sender.sendMessage(ChatColor.RED + "Crate " + crateName + " gak ditemukan.");
            return true;
        }

        int amount = 1;
        if (args.length >= 4) {
            try {
                amount = Integer.parseInt(args[3]);
            } catch (NumberFormatException ignored) {}
        }

        if (manager.isVirtualKeyMode(crateName)) {
            keyManager.addVirtualKeys(target.getUniqueId(), crateName, amount);
            sender.sendMessage(ChatColor.GREEN + "Berhasil kasih " + amount + "x VIRTUAL key " + crateName + " ke " + target.getName());
            target.sendMessage(ChatColor.GREEN + "Kamu dapet " + amount + "x virtual key " + manager.getDisplayName(crateName) + "!");
        } else {
            target.getInventory().addItem(manager.createKey(crateName, amount));
            sender.sendMessage(ChatColor.GREEN + "Berhasil kasih " + amount + "x key " + crateName + " ke " + target.getName());
            target.sendMessage(ChatColor.GREEN + "Kamu dapet " + amount + "x " + manager.getDisplayName(crateName) + " Key!");
        }
        return true;
    }
}
