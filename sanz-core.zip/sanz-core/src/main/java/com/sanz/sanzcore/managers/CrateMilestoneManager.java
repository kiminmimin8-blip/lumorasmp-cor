package com.sanz.sanzcore.managers;

import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Milestone: reward tambahan tiap player nyampe kelipatan N kali buka
 * crate tertentu (misal tiap 10x buka Legendary Crate, dapet bonus).
 * Diatur di gui.yml per-crate, field "milestones":
 *   milestones:
 *     - count: 10
 *       commands: ["eco give %player% 10000"]
 *       broadcast-message: "&6%player% udah buka Legendary Crate 10x!"
 */
public class CrateMilestoneManager {

    private final JavaPlugin plugin;
    private final ConfigFile guiFile;
    private final File folder;

    public CrateMilestoneManager(JavaPlugin plugin, ConfigFile guiFile) {
        this.plugin = plugin;
        this.guiFile = guiFile;
        this.folder = new File(plugin.getDataFolder(), "crates/milestones");
        if (!folder.exists()) folder.mkdirs();
    }

    private File fileFor(UUID uuid) {
        return new File(folder, uuid.toString() + ".yml");
    }

    private YamlConfiguration load(UUID uuid) {
        File f = fileFor(uuid);
        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("Gagal bikin milestone data: " + e.getMessage());
            }
        }
        return YamlConfiguration.loadConfiguration(f);
    }

    private void save(UUID uuid, YamlConfiguration data) {
        try {
            data.save(fileFor(uuid));
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal simpan milestone data: " + e.getMessage());
        }
    }

    /**
     * Dipanggil tiap kali player buka crate. Nambah counter, dan kalau
     * counter-nya pas kena angka milestone, kasih reward tambahan.
     */
    @SuppressWarnings("unchecked")
    public void trackOpen(Player player, String crateName) {
        YamlConfiguration data = load(player.getUniqueId());
        int totalOpens = data.getInt("opens." + crateName, 0) + 1;
        data.set("opens." + crateName, totalOpens);
        save(player.getUniqueId(), data);

        List<Map<?, ?>> milestones = guiFile.get().getMapList("crates." + crateName + ".milestones");
        for (Map<?, ?> milestone : milestones) {
            int count = (int) milestone.get("count");
            if (totalOpens == count) {
                giveMilestoneReward(player, milestone, crateName);
            }
        }
    }

    private void giveMilestoneReward(Player player, Map<?, ?> milestone, String crateName) {
        List<String> commands = (List<String>) milestone.get("commands");
        if (commands != null) {
            for (String cmd : commands) {
                String finalCmd = cmd.replace("%player%", player.getName());
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), finalCmd);
            }
        }

        player.sendMessage(ChatColor.GOLD + "★ Milestone! Kamu udah buka crate " + crateName +
                " sebanyak " + milestone.get("count") + "x!");

        Object broadcastMsg = milestone.get("broadcast-message");
        if (broadcastMsg != null) {
            String msg = ChatColor.translateAlternateColorCodes('&',
                    String.valueOf(broadcastMsg).replace("%player%", player.getName()));
            Bukkit.broadcastMessage(msg);
        }
    }

    public int getOpenCount(UUID uuid, String crateName) {
        return load(uuid).getInt("opens." + crateName, 0);
    }
}
