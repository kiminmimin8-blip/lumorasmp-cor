package com.sanz.sanzcore.commands;

import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class MobRadiusCommand implements CommandExecutor {

    private final ConfigFile configFile;

    public MobRadiusCommand(ConfigFile configFile) {
        this.configFile = configFile;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("server.mobradius")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /mobradius <set|toggle|status> [angka]");
            return true;
        }

        var cfg = configFile.get();

        switch (args[0].toLowerCase()) {
            case "set" -> {
                if (args.length < 2) {
                    sender.sendMessage(ChatColor.RED + "Gunakan: /mobradius set <angka>");
                    return true;
                }
                try {
                    int radius = Integer.parseInt(args[1]);
                    cfg.set("radius", radius);
                    configFile.save();
                    sender.sendMessage(ChatColor.GREEN + "Radius mob spawn diset ke " +
                            ChatColor.YELLOW + radius + ChatColor.GREEN + " blok.");
                } catch (NumberFormatException e) {
                    sender.sendMessage(ChatColor.RED + "Angka tidak valid.");
                }
            }
            case "toggle" -> {
                boolean current = cfg.getBoolean("enabled", true);
                cfg.set("enabled", !current);
                configFile.save();
                sender.sendMessage(!current
                        ? ChatColor.GREEN + "Mob spawn blocking diaktifkan."
                        : ChatColor.RED + "Mob spawn blocking dimatikan.");
            }
            case "status" -> {
                boolean enabled = cfg.getBoolean("enabled", true);
                int radius = cfg.getInt("radius", 16);
                sender.sendMessage(ChatColor.GRAY + "Status: " + ChatColor.WHITE + enabled +
                        ChatColor.GRAY + " | Radius: " + ChatColor.WHITE + radius + " blok");
            }
            default -> sender.sendMessage(ChatColor.RED + "Gunakan: /mobradius <set|toggle|status> [angka]");
        }
        return true;
    }
}
