package com.sanz.sanzcore.gui;

import com.sanz.sanzcore.managers.LeaderboardManager;
import com.sanz.sanzcore.util.ChatInputManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * /leaderboard admin -> GUI kelola kategori leaderboard.
 * - Klik icon board = cycle jenis statistik (Kill -> Death -> Playtime -> ...)
 * - Shift-klik = hapus board itu
 * - Slot "+ Tambah Board" = ketik ID board baru lewat chat (lihat
 *   ChatInputManager), abis itu board langsung jadi (statistik default
 *   Player Kills, tinggal klik buat cycle ke yang diinginkan)
 */
public class LeaderboardAdminListener implements Listener {

    private static final int ADD_SLOT = 26;

    private final LeaderboardManager manager;

    public LeaderboardAdminListener(LeaderboardManager manager) {
        this.manager = manager;
    }

    public static void openAdmin(LeaderboardManager manager, Player admin) {
        LeaderboardAdminHolder holder = new LeaderboardAdminHolder();
        String title = ChatColor.translateAlternateColorCodes('&', "&8&lKelola Leaderboard");
        Inventory inv = Bukkit.createInventory(holder, 27, title);
        holder.setInventory(inv);

        List<String> boards = manager.getBoardNames();
        int slot = 0;
        for (String boardName : boards) {
            if (slot >= 25) break;

            Material icon = Material.matchMaterial(manager.getIcon(boardName));
            if (icon == null) icon = Material.PAPER;

            ItemStack item = new ItemStack(icon);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', manager.getDisplayName(boardName)));
                meta.setLore(List.of(
                        ChatColor.GRAY + "ID: " + ChatColor.WHITE + boardName,
                        ChatColor.GRAY + "Klik = ganti jenis statistik",
                        ChatColor.RED + "Shift-klik = hapus board ini"
                ));
                item.setItemMeta(meta);
            }
            inv.setItem(slot, item);
            slot++;
        }

        ItemStack addButton = new ItemStack(Material.EMERALD);
        ItemMeta addMeta = addButton.getItemMeta();
        if (addMeta != null) {
            addMeta.setDisplayName(ChatColor.GREEN + "+ Tambah Board Baru");
            addMeta.setLore(List.of(ChatColor.GRAY + "Klik, lalu ketik ID board di chat"));
            addButton.setItemMeta(addMeta);
        }
        inv.setItem(ADD_SLOT, addButton);

        admin.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof LeaderboardAdminHolder)) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player admin)) return;
        if (!admin.hasPermission("lumora.leaderboard.admin")) {
            admin.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk ini.");
            return;
        }

        int slot = event.getRawSlot();

        if (slot == ADD_SLOT) {
            admin.closeInventory();
            ChatInputManager.await(admin, (input) -> {
                String id = input.toLowerCase().replaceAll("[^a-z0-9_]", "");
                if (id.isBlank()) {
                    admin.sendMessage(ChatColor.RED + "ID gak valid, coba lagi.");
                    return;
                }
                manager.addStatisticBoard(id, "&f&lTop " + input);
                admin.sendMessage(ChatColor.GREEN + "Board '" + id + "' berhasil dibuat! " +
                        "Klik icon-nya di menu admin buat ganti jenis statistik.");
                openAdmin(manager, admin);
            });
            return;
        }

        List<String> boards = manager.getBoardNames();
        if (slot < 0 || slot >= boards.size()) return;
        String boardName = boards.get(slot);

        if (event.getClick() == ClickType.SHIFT_LEFT || event.getClick() == ClickType.SHIFT_RIGHT) {
            manager.removeBoard(boardName);
            admin.sendMessage(ChatColor.RED + "Board '" + boardName + "' dihapus.");
        } else {
            String newStat = manager.cycleStatistic(boardName);
            admin.sendMessage(ChatColor.GREEN + "Board '" + boardName + "' sekarang pakai statistik: " +
                    ChatColor.YELLOW + newStat);
        }
        openAdmin(manager, admin); // refresh
    }
}
