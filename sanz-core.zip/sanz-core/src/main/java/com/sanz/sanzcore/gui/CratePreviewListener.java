package com.sanz.sanzcore.gui;

import com.sanz.sanzcore.managers.CrateManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * /crate preview <nama> — nunjukin semua reward + persen peluangnya,
 * TANPA make key / benar-benar ngundi. Read-only, gaya ExcellentCrates
 * "Custom Previews".
 */
public class CratePreviewListener implements Listener {

    public static void openPreview(CrateManager manager, Player player, String crateName) {
        CratePreviewHolder holder = new CratePreviewHolder();
        String title = ChatColor.translateAlternateColorCodes('&',
                "&8Preview: &e" + manager.getDisplayName(crateName));
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        List<Map<?, ?>> rewards = manager.getRewards(crateName);
        Map<String, Double> chances = manager.getChancePercentages(crateName);

        int slot = 0;
        for (Map<?, ?> reward : rewards) {
            if (slot >= 54) break;
            String type = String.valueOf(reward.get("type"));
            Material material = Material.PAPER;

            if ("ITEM".equalsIgnoreCase(type)) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> items = (List<Map<String, Object>>) reward.get("items");
                if (items != null && !items.isEmpty()) {
                    Material matched = Material.matchMaterial(String.valueOf(items.get(0).get("material")));
                    if (matched != null) material = matched;
                }
            } else if ("COMMAND".equalsIgnoreCase(type)) {
                material = Material.COMMAND_BLOCK;
            }

            ItemStack icon = new ItemStack(material);
            ItemMeta meta = icon.getItemMeta();
            if (meta != null) {
                String displayName = ChatColor.translateAlternateColorCodes('&', String.valueOf(reward.get("display-name")));
                meta.setDisplayName(displayName);

                String rewardId = String.valueOf(reward.get("id"));
                double percent = chances.getOrDefault(rewardId, 0.0);

                List<String> lore = new ArrayList<>();
                lore.add(ChatColor.GRAY + "Peluang: " + ChatColor.YELLOW +
                        String.format("%.2f%%", percent));
                if (reward.containsKey("max-wins")) {
                    lore.add(ChatColor.GRAY + "Maks. dimenangkan: " + ChatColor.WHITE + reward.get("max-wins") + "x");
                }
                if (reward.containsKey("cooldown-seconds")) {
                    lore.add(ChatColor.GRAY + "Cooldown: " + ChatColor.WHITE + reward.get("cooldown-seconds") + " detik");
                }
                meta.setLore(lore);
                icon.setItemMeta(meta);
            }
            inv.setItem(slot, icon);
            slot++;
        }

        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getInventory().getHolder() instanceof CratePreviewHolder) {
            event.setCancelled(true); // read-only, gak bisa diapa-apain
        }
    }
}
