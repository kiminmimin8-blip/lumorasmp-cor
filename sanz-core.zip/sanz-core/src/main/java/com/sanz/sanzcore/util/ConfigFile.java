package com.sanz.sanzcore.util;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;

/**
 * Wrapper file config terpisah per modul, gaya EssentialsX
 * (config.yml, worth.yml, kits.yml -> masing-masing file sendiri).
 *
 * Tiap fitur (spawn, home, rtp, mobspawn, rankshop) punya file-nya
 * sendiri di folder data plugin, defaultnya di-copy dari
 * src/main/resources/<namafile>.yml pas pertama kali dijalankan.
 */
public class ConfigFile {

    private final JavaPlugin plugin;
    private final String fileName;
    private final File file;
    private YamlConfiguration config;

    public ConfigFile(JavaPlugin plugin, String fileName) {
        this.plugin = plugin;
        this.fileName = fileName;
        this.file = new File(plugin.getDataFolder(), fileName);

        if (!file.exists()) {
            plugin.getDataFolder().mkdirs();
            // copy default dari resources kalau ada, kalau gak ada bikin file kosong
            if (plugin.getResource(fileName) != null) {
                plugin.saveResource(fileName, false);
            } else {
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    plugin.getLogger().warning("Gagal bikin " + fileName + ": " + e.getMessage());
                }
            }
        }

        this.config = YamlConfiguration.loadConfiguration(file);
    }

    public YamlConfiguration get() {
        return config;
    }

    public void save() {
        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal simpan " + fileName + ": " + e.getMessage());
        }
    }

    public void reload() {
        this.config = YamlConfiguration.loadConfiguration(file);
    }
}
