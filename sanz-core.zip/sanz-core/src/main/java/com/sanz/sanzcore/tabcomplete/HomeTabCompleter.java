package com.sanz.sanzcore.tabcomplete;

import com.sanz.sanzcore.managers.HomeManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Buat /home dan /delhome: nunjukin nama home yang beneran dipunya
 * player itu (dinamis, gak hardcode).
 */
public class HomeTabCompleter implements TabCompleter {

    private final HomeManager homeManager;

    public HomeTabCompleter(HomeManager homeManager) {
        this.homeManager = homeManager;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1 || !(sender instanceof Player player)) return new ArrayList<>();

        String current = args[0].toLowerCase();
        return homeManager.getHomeNames(player.getUniqueId()).stream()
                .filter(name -> name.toLowerCase().startsWith(current))
                .collect(Collectors.toList());
    }
}
