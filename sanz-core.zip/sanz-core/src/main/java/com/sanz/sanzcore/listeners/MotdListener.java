package com.sanz.sanzcore.listeners;

import com.sanz.sanzcore.util.ConfigFile;
import com.destroystokyo.paper.event.server.PaperServerListPingEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class MotdListener implements Listener {

    private final ConfigFile configFile;

    public MotdListener(ConfigFile configFile) {
        this.configFile = configFile;
    }

    @EventHandler
    public void onServerListPing(PaperServerListPingEvent event) {
        var cfg = configFile.get();
        if (!cfg.getBoolean("enabled", true)) return;

        String line1 = cfg.getString("line1", "&5Lumora SMP");
        String line2 = cfg.getString("line2", "&aOnline!");

        Component motd = LegacyComponentSerializer.legacyAmpersand()
                .deserialize(line1 + "\n" + line2);
        event.motd(motd);
    }
}
