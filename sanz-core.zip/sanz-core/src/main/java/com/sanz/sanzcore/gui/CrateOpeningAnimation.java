package com.sanz.sanzcore.gui;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Animasi roulette buat buka crate (gaya "Custom Openings"
 * ExcellentCrates): item di slot tengah muter random makin lama makin
 * pelan, terus berhenti di reward asli yang udah ditentuin duluan
 * (rewardnya udah di-roll SEBELUM animasi, animasi cuma visual).
 */
public class CrateOpeningAnimation {

    private static final int CENTER_SLOT = 13; // baris tengah GUI 27 slot
    private static final Random random = new Random();

    public interface OnFinish {
        void run();
    }

    public static void play(JavaPlugin plugin, Player player, String crateTitle,
                             List<Map<?, ?>> allRewards, Map<?, ?> finalReward, OnFinish onFinish) {

        Inventory inv = Bukkit.createInventory(null, 27,
                ChatColor.translateAlternateColorCodes('&', "&8Membuka " + crateTitle + "..."));

        // Border item biar keliatan kayak mesin gacha
        ItemStack border = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta borderMeta = border.getItemMeta();
        if (borderMeta != null) {
            borderMeta.setDisplayName(" ");
            border.setItemMeta(borderMeta);
        }
        for (int i = 0; i < 27; i++) {
            if (i != CENTER_SLOT) inv.setItem(i, border);
        }

        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, 1f, 1f);

        // Total ~2.5 detik, makin lama makin pelan (deselerasi)
        int[] delays = {2, 2, 2, 2, 3, 3, 3, 4, 4, 5, 5, 6, 7, 8, 10, 12};
        runStep(plugin, player, inv, allRewards, finalReward, delays, 0, onFinish);
    }

    private static void runStep(JavaPlugin plugin, Player player, Inventory inv,
                                 List<Map<?, ?>> allRewards, Map<?, ?> finalReward,
                                 int[] delays, int step, OnFinish onFinish) {

        if (!player.getOpenInventory().getTopInventory().equals(inv)) {
            return; // player nutup inventory di tengah animasi, batalin sisa step
        }

        boolean isLastStep = step >= delays.length;
        Map<?, ?> rewardToShow = isLastStep ? finalReward : allRewards.get(random.nextInt(allRewards.size()));

        inv.setItem(CENTER_SLOT, buildIcon(rewardToShow));
        player.playSound(player.getLocation(),
                isLastStep ? Sound.ENTITY_PLAYER_LEVELUP : Sound.UI_BUTTON_CLICK, 1f, isLastStep ? 1f : 1.5f);

        if (isLastStep) {
            Bukkit.getGlobalRegionScheduler().runDelayed(plugin, task -> {
                player.closeInventory();
                onFinish.run();
            }, 20L); // kasih waktu 1 detik liat hasil sebelum nutup
            return;
        }

        Bukkit.getGlobalRegionScheduler().runDelayed(plugin, task ->
                runStep(plugin, player, inv, allRewards, finalReward, delays, step + 1, onFinish), delays[step]);
    }

    private static ItemStack buildIcon(Map<?, ?> reward) {
        String type = String.valueOf(reward.get("type"));
        Material material = Material.PAPER;

        if ("ITEM".equalsIgnoreCase(type)) {
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> items = (List<Map<String, Object>>) reward.get("items");
            if (items != null && !items.isEmpty()) {
                Material matched = Material.matchMaterial(String.valueOf(items.get(0).get("material")));
                if (matched != null) material = matched;
            }
        } else if ("COMMAND".equalsIgnoreCase(type)) {
            material = Material.COMMAND_BLOCK;
        }

        ItemStack icon = new ItemStack(material);
        ItemMeta meta = icon.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', String.valueOf(reward.get("display-name"))));
            icon.setItemMeta(meta);
        }
        return icon;
    }
}
