package com.sanz.sanzcore.tabcomplete;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;

/**
 * TabCompleter generic berbasis "peta" subcommand per kedalaman argumen.
 * Biar semua command kita muncul dropdown-nya pas diketik "/", kayak
 * FastAsyncWorldEdit.
 *
 * Cara pakai: kasih array of String[] buat tiap level argumen.
 * argOptions[0] = pilihan buat args[0], argOptions[1] = pilihan args[1], dst.
 * Kalau butuh dinamis (misal nama player online), override lewat subclass.
 */
public class SimpleTabCompleter implements TabCompleter {

    private final String[][] argOptions;

    public SimpleTabCompleter(String[]... argOptions) {
        this.argOptions = argOptions;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        int index = args.length - 1;
        if (index < 0 || index >= argOptions.length) return new ArrayList<>();

        String current = args[index].toLowerCase();
        List<String> result = new ArrayList<>();
        for (String option : argOptions[index]) {
            if (option.toLowerCase().startsWith(current)) {
                result.add(option);
            }
        }
        return result;
    }
}
