package com.sanz.sanzcore.commands;

import com.sanz.sanzcore.managers.EventManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class EventCommand implements CommandExecutor {

    private final EventManager manager;

    public EventCommand(EventManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("setevent")) {
            if (!sender.hasPermission("sanz.event.admin")) {
                sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk ini.");
                return true;
            }
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
                return true;
            }
            if (args.length == 0) {
                sender.sendMessage(ChatColor.RED + "Gunakan: /setevent <nama>");
                return true;
            }
            manager.setEvent(args[0], player.getLocation());
            player.sendMessage(ChatColor.GREEN + "Lokasi event " + ChatColor.YELLOW + args[0] +
                    ChatColor.GREEN + " berhasil diset.");
            return true;
        }

        // /event [nama]
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }

        if (args.length == 0) {
            var names = manager.getEventNames();
            if (names.isEmpty()) {
                player.sendMessage(ChatColor.RED + "Belum ada lokasi event yang di-set.");
                return true;
            }
            player.sendMessage(ChatColor.GRAY + "Event tersedia: " + ChatColor.WHITE + String.join(", ", names));
            return true;
        }

        String name = args[0];
        if (!manager.hasEvent(name)) {
            player.sendMessage(ChatColor.RED + "Event " + name + " gak ditemukan.");
            return true;
        }

        var location = manager.getEvent(name);
        if (location == null) {
            player.sendMessage(ChatColor.RED + "Gagal teleport, world event ini gak ketemu.");
            return true;
        }

        player.teleportAsync(location);
        player.sendMessage(ChatColor.GREEN + "Teleport ke event " + ChatColor.YELLOW + name + ChatColor.GREEN + "...");
        return true;
    }
}
