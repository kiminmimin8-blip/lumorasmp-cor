package com.sanz.sanzcore.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class LeaderboardPageHolder implements InventoryHolder {

    private final String boardName;
    private final int page;
    private Inventory inventory;

    public LeaderboardPageHolder(String boardName, int page) {
        this.boardName = boardName;
        this.page = page;
    }

    public String getBoardName() {
        return boardName;
    }

    public int getPage() {
        return page;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
