package com.sanz.sanzcore.gui;

import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Billford: barter item-ke-item (BUKAN currency). Player nyerahin item
 * yang di-config di "required", dapet "reward" balik.
 */
public class BillfordListener implements Listener {

    private final ConfigFile configFile;
    private final ConfigFile guiFile;

    public BillfordListener(ConfigFile configFile, ConfigFile guiFile) {
        this.configFile = configFile;
        this.guiFile = guiFile;
    }

    public static void openBillford(ConfigFile configFile, ConfigFile guiFile, Player player) {
        var cfg = configFile.get();
        String title = ChatColor.translateAlternateColorCodes('&',
                cfg.getString("gui-title", "&6&lBillford"));
        int rows = cfg.getInt("gui-rows", 3);

        BillfordHolder holder = new BillfordHolder();
        Inventory inv = Bukkit.createInventory(holder, rows * 9, title);
        holder.setInventory(inv);

        ConfigurationSection trades = guiFile.get().getConfigurationSection("trades");
        if (trades == null) {
            player.sendMessage(ChatColor.RED + "Billford belum dikonfigurasi.");
            return;
        }

        for (String key : trades.getKeys(false)) {
            ConfigurationSection trade = trades.getConfigurationSection(key);
            if (trade == null) continue;

            int slot = trade.getInt("slot", 0);
            Material material = Material.matchMaterial(trade.getString("display-material", "STONE"));
            if (material == null) material = Material.STONE;

            String name = ChatColor.translateAlternateColorCodes('&', trade.getString("display-name", key));
            List<String> lore = new ArrayList<>();
            for (String line : trade.getStringList("lore")) {
                lore.add(ChatColor.translateAlternateColorCodes('&', line));
            }

            ItemStack stack = new ItemStack(material);
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(name);
                meta.setLore(lore);
                stack.setItemMeta(meta);
            }
            inv.setItem(slot, stack);
        }

        player.openInventory(inv);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof BillfordHolder)) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;

        var cfg = configFile.get();
        ConfigurationSection trades = guiFile.get().getConfigurationSection("trades");
        if (trades == null) return;

        int clickedSlot = event.getRawSlot();
        for (String key : trades.getKeys(false)) {
            ConfigurationSection trade = trades.getConfigurationSection(key);
            if (trade == null || trade.getInt("slot", -1) != clickedSlot) continue;
            handleTrade(player, trade);
            return;
        }
    }

    private void handleTrade(Player player, ConfigurationSection trade) {
        List<Map<String, Object>> required = (List<Map<String, Object>>) (List<?>) trade.getMapList("required");
        List<Map<String, Object>> reward = (List<Map<String, Object>>) (List<?>) trade.getMapList("reward");

        // cek player punya semua required item dalam jumlah cukup
        for (Map<String, Object> req : required) {
            Material mat = Material.matchMaterial(String.valueOf(req.get("material")));
            int amount = (int) req.get("amount");
            if (mat == null || !hasEnough(player, mat, amount)) {
                player.sendMessage(ChatColor.RED + "Item kamu gak cukup buat trade ini.");
                return;
            }
        }

        // ambil semua required item
        for (Map<String, Object> req : required) {
            Material mat = Material.matchMaterial(String.valueOf(req.get("material")));
            int amount = (int) req.get("amount");
            player.getInventory().removeItem(new ItemStack(mat, amount));
        }

        // kasih reward
        for (Map<String, Object> rew : reward) {
            Material mat = Material.matchMaterial(String.valueOf(rew.get("material")));
            int amount = (int) rew.get("amount");
            if (mat != null) {
                player.getInventory().addItem(new ItemStack(mat, amount));
            }
        }

        player.sendMessage(ChatColor.GREEN + "Trade berhasil!");
    }

    private boolean hasEnough(Player player, Material material, int amount) {
        int count = 0;
        for (ItemStack stack : player.getInventory().getContents()) {
            if (stack != null && stack.getType() == material) {
                count += stack.getAmount();
            }
        }
        return count >= amount;
    }
}
