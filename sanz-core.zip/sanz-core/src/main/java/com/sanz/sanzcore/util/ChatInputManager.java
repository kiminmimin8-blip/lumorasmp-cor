package com.sanz.sanzcore.util;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Utility generic: tangkep 1 baris chat berikutnya dari player sebagai
 * "input teks", dipakai buat alur GUI yang butuh ketikan (misal nama
 * board baru di Leaderboard admin). Dipakai karena Anvil GUI text-input
 * butuh trik NMS yang beresiko kalau gak dites langsung.
 *
 * Cara pakai:
 *   ChatInputManager.await(player, (text) -> { ...proses input... });
 * Chat asli player OTOMATIS di-cancel selama nunggu input (gak keliatan
 * di chat publik).
 */
public class ChatInputManager implements Listener {

    private static final Map<UUID, Consumer<String>> pending = new ConcurrentHashMap<>();
    private static JavaPlugin pluginInstance;

    public ChatInputManager(JavaPlugin plugin) {
        pluginInstance = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    public static void await(Player player, Consumer<String> callback) {
        pending.put(player.getUniqueId(), callback);
        player.sendMessage(org.bukkit.ChatColor.YELLOW + "Ketik di chat sekarang (atau ketik 'batal' buat batalin):");
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        Consumer<String> callback = pending.remove(uuid);
        if (callback == null) return;

        event.setCancelled(true);
        String message = event.getMessage();

        // jalanin callback di main thread (chat event ini async)
        org.bukkit.Bukkit.getGlobalRegionScheduler().run(pluginInstance, task -> {
            if (message.equalsIgnoreCase("batal")) {
                event.getPlayer().sendMessage(org.bukkit.ChatColor.RED + "Dibatalin.");
                return;
            }
            callback.accept(message);
        });
    }
}
