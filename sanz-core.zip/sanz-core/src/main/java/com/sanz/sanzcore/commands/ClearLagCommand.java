package com.sanz.sanzcore.commands;

import com.sanz.sanzcore.tasks.ClearLagTask;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class ClearLagCommand implements CommandExecutor {

    private final ClearLagTask task;

    public ClearLagCommand(ClearLagTask task) {
        this.task = task;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("sanzcore.clearlag.use")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }
        task.executeClear();
        return true;
    }
}
