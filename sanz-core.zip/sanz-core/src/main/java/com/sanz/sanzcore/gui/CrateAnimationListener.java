package com.sanz.sanzcore.gui;

import com.sanz.sanzcore.managers.CrateManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Animasi buka crate gaya ExcellentCrates: icon reward "ngescroll" cepet
 * di 1 baris tengah, terus pelan-pelan melambat (deselerasi) sampai
 * berhenti tepat di slot indikator (tengah) = reward yang beneran
 * kepilih. Reward-nya udah di-roll DULUAN sebelum animasi mulai
 * (lewat CrateManager.rollReward), animasi cuma nunjukin hasilnya
 * secara visual — jadi hasil akhirnya selalu konsisten sama peluang
 * weight yang udah dihitung.
 *
 * Layout inventory 27 slot (3 baris):
 *  - Baris tengah (slot 9-17)  = reel yang ngescroll, slot 13 = titik landing.
 *  - Slot 4 & 22               = penanda kuning nunjuk ke slot 13.
 *  - Sisanya                   = border kaca hitam (dekorasi doang).
 */
public class CrateAnimationListener implements Listener {

    private static final Random RANDOM = new Random();
    private static final int TOTAL_STEPS = 26; // makin gede makin lama animasinya

    public static void openAnimation(JavaPlugin plugin, CrateManager manager, Player player, String crateName) {
        Map<?, ?> chosen = manager.rollReward(player, crateName);
        if (chosen == null) return; // pesan error udah dikirim rollReward

        ItemStack chosenIcon = manager.getRewardIcon(chosen);

        List<ItemStack> pool = new ArrayList<>();
        for (Map<?, ?> reward : manager.getRewards(crateName)) {
            pool.add(manager.getRewardIcon(reward));
        }
        if (pool.isEmpty()) pool.add(chosenIcon);

        CrateAnimationHolder holder = new CrateAnimationHolder();
        String title = ChatColor.translateAlternateColorCodes('&',
                "&8Membuka: &e" + manager.getDisplayName(crateName));
        Inventory inv = Bukkit.createInventory(holder, 27, title);
        holder.setInventory(inv);

        buildBorder(inv);
        // Isi reel awal dengan icon random biar gak kosong pas GUI kebuka
        for (int slot = 9; slot <= 17; slot++) {
            inv.setItem(slot, pool.get(RANDOM.nextInt(pool.size())));
        }

        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, 1f, 1f);

        scheduleStep(plugin, manager, player, inv, pool, chosenIcon, chosen, crateName, 1);
    }

    private static void buildBorder(Inventory inv) {
        ItemStack border = namedGlass(Material.BLACK_STAINED_GLASS_PANE, " ");
        ItemStack markerTop = namedGlass(Material.YELLOW_STAINED_GLASS_PANE, "&e&l▼ HASIL ▼");
        ItemStack markerBottom = namedGlass(Material.YELLOW_STAINED_GLASS_PANE, "&e&l▲ HASIL ▲");

        for (int slot = 0; slot < 9; slot++) {
            inv.setItem(slot, slot == 4 ? markerTop : border);
        }
        for (int slot = 18; slot < 27; slot++) {
            inv.setItem(slot, slot == 22 ? markerBottom : border);
        }
    }

    private static ItemStack namedGlass(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
            item.setItemMeta(meta);
        }
        return item;
    }

    /**
     * Geser reel 1 langkah ke kiri, isi slot paling kanan (17) dengan icon
     * baru. Dijadwalin rekursif lewat entity scheduler player (aman buat
     * Folia), dengan delay makin gede di langkah-langkah terakhir biar
     * animasinya berasa "melambat" kayak roulette asli.
     */
    private static void scheduleStep(JavaPlugin plugin, CrateManager manager, Player player, Inventory inv,
                                      List<ItemStack> pool, ItemStack chosenIcon, Map<?, ?> chosenReward,
                                      String crateName, int step) {
        long delay = tickDelayFor(step);

        player.getScheduler().runDelayed(plugin, scheduledTask -> {
            // Kalau player udah keluar dari GUI animasi (misal disconnect), stop aja.
            if (!(player.getOpenInventory().getTopInventory().getHolder() instanceof CrateAnimationHolder)) {
                return;
            }

            for (int slot = 9; slot <= 16; slot++) {
                inv.setItem(slot, inv.getItem(slot + 1));
            }

            boolean isLandingFeed = step == TOTAL_STEPS - 4;
            ItemStack newIcon = isLandingFeed ? chosenIcon : pool.get(RANDOM.nextInt(pool.size()));
            inv.setItem(17, newIcon);

            float pitch = 1.0f + (step / (float) TOTAL_STEPS) * 0.8f;
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, pitch);

            if (step >= TOTAL_STEPS) {
                // Animasi selesai, reward udah "landing" di slot 13.
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
                player.getScheduler().runDelayed(plugin, finishTask -> {
                    manager.applyRoll(player, crateName, chosenReward);
                    player.closeInventory();
                }, null, 25L); // jeda ~1.25 detik biar player sempet liat hasilnya
                return;
            }

            scheduleStep(plugin, manager, player, inv, pool, chosenIcon, chosenReward, crateName, step + 1);
        }, null, delay);
    }

    private static long tickDelayFor(int step) {
        int stepsFromEnd = TOTAL_STEPS - step;
        if (stepsFromEnd >= 10) return 1L;
        return Math.max(1L, 10L - stepsFromEnd);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getInventory().getHolder() instanceof CrateAnimationHolder) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof CrateAnimationHolder) {
            event.setCancelled(true);
        }
    }
}
