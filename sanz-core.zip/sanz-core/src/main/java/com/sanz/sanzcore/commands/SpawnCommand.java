package com.sanz.sanzcore.commands;

import com.sanz.sanzcore.SanzCorePlugin;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpawnCommand implements CommandExecutor {

    private final SanzCorePlugin plugin;

    public SpawnCommand(SanzCorePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }

        if (label.equalsIgnoreCase("setspawn")) {
            if (!player.hasPermission("sanzcore.spawn.set")) {
                player.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk ini.");
                return true;
            }
            plugin.getSpawnManager().setSpawn(player.getLocation());
            player.sendMessage(ChatColor.GREEN + "Lokasi spawn diset ke posisi kamu sekarang.");
            return true;
        }

        // /spawn
        if (!player.hasPermission("sanzcore.spawn.use")) {
            player.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk ini.");
            return true;
        }
        player.teleportAsync(plugin.getSpawnManager().getSpawn());
        player.sendMessage(ChatColor.GREEN + "Teleport ke spawn...");
        return true;
    }
}
