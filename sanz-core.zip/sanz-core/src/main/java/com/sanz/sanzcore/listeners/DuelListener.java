package com.sanz.sanzcore.listeners;

import com.sanz.sanzcore.managers.DuelManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Handle akhir duel: kalau salah satu mati atau disconnect pas lagi
 * duel, duel otomatis selesai & kedua player dibalikin ke lokasi asal.
 */
public class DuelListener implements Listener {

    private final DuelManager manager;

    public DuelListener(DuelManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (!manager.isInDuel(player.getUniqueId())) return;

        var opponentId = manager.getOpponent(player.getUniqueId());
        Player opponent = opponentId != null ? Bukkit.getPlayer(opponentId) : null;

        manager.endDuel(player.getUniqueId());

        player.sendMessage(ChatColor.RED + "Kamu kalah duel!");
        if (opponent != null) {
            opponent.sendMessage(ChatColor.GREEN + "Kamu menang duel lawan " + player.getName() + "!");
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (manager.isInDuel(player.getUniqueId())) {
            manager.endDuel(player.getUniqueId());
        }
    }
}
