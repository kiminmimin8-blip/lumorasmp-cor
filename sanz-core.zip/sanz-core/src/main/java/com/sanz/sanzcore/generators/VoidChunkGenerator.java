package com.sanz.sanzcore.generators;

import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;

/**
 * Generator kosong (void) — chunk yang dihasilkan gak ada block sama sekali.
 * Dipakai buat "/worldadmin create <nama> <env> void", biasanya buat world
 * arena/event/lobby yang emang gak butuh terrain.
 *
 * Sengaja gak override method generate apa pun: base class ChunkGenerator
 * default-nya sudah menghasilkan chunk kosong (tanpa block), jadi ini
 * cukup buat void generator sederhana tanpa perlu isi chunk manual.
 */
public class VoidChunkGenerator extends ChunkGenerator {

    @Override
    public BiomeProvider getDefaultBiomeProvider(WorldInfo worldInfo) {
        return new BiomeProvider() {
            @Override
            public org.bukkit.block.Biome getBiome(WorldInfo worldInfo, int x, int y, int z) {
                return org.bukkit.block.Biome.PLAINS;
            }

            @Override
            public java.util.List<org.bukkit.block.Biome> getBiomes(WorldInfo worldInfo) {
                return java.util.List.of(org.bukkit.block.Biome.PLAINS);
            }
        };
    }

    @Override
    public boolean shouldGenerateNoise() {
        return false;
    }

    @Override
    public boolean shouldGenerateSurface() {
        return false;
    }

    @Override
    public boolean shouldGenerateCaves() {
        return false;
    }

    @Override
    public boolean shouldGenerateDecorations() {
        return false;
    }

    @Override
    public boolean shouldGenerateMobs() {
        return false;
    }

    @Override
    public boolean shouldGenerateStructures() {
        return false;
    }
}
