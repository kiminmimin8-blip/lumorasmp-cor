package com.sanz.sanzcore.managers;

import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Integrasi ke DecentHolograms (udah kepasang di server) lewat COMMAND,
 * bukan API langsung — biar gak perlu nambah dependency compile-time
 * yang gak bisa dites di sini. DecentHolograms commands:
 *   /dh create <name> <world>,<x>,<y>,<z>
 *   /dh addline <name> <text>
 *   /dh remove <name>
 *
 * Kalau DecentHolograms gak ke-install, method ini otomatis no-op
 * (gak jalanin command apapun) biar gak spam error di console.
 */
public class CrateHologramManager {

    private final JavaPlugin plugin;
    private final ConfigFile configFile;

    public CrateHologramManager(JavaPlugin plugin, ConfigFile configFile) {
        this.plugin = plugin;
        this.configFile = configFile;
    }

    private boolean isEnabled() {
        boolean dhPresent = Bukkit.getPluginManager().getPlugin("DecentHolograms") != null;
        boolean configEnabled = configFile.get().getBoolean("holograms.enabled", true);
        return dhPresent && configEnabled;
    }

    private String hologramId(Location loc) {
        return "lumoracrate_" + loc.getWorld().getName() + "_" +
                loc.getBlockX() + "_" + loc.getBlockY() + "_" + loc.getBlockZ();
    }

    public void createHologram(Location blockLoc, String crateName, String crateDisplayName) {
        if (!isEnabled()) return;

        Location holoLoc = blockLoc.clone().add(0.5, 1.3, 0.5);
        String id = hologramId(blockLoc);
        String coords = holoLoc.getWorld().getName() + "," + holoLoc.getX() + "," + holoLoc.getY() + "," + holoLoc.getZ();

        runConsole("dh remove " + id); // bersihin dulu kalau kebetulan udah ada (re-link)
        runConsole("dh create " + id + " " + coords);

        var lines = configFile.get().getStringList("holograms.lines");
        if (lines.isEmpty()) {
            lines = java.util.List.of("&e&l" + crateDisplayName, "&7Klik kanan buat buka!");
        }
        for (String line : lines) {
            String parsed = line.replace("%crate%", crateDisplayName);
            runConsole("dh addline " + id + " " + parsed);
        }
    }

    public void removeHologram(Location blockLoc) {
        if (!isEnabled()) return;
        runConsole("dh remove " + hologramId(blockLoc));
    }

    private void runConsole(String cmd) {
        Bukkit.getGlobalRegionScheduler().run(plugin, task ->
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd));
    }
}
