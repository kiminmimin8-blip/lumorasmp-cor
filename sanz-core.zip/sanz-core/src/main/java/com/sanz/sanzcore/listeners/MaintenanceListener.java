package com.sanz.sanzcore.listeners;

import com.sanz.sanzcore.managers.MaintenanceManager;
import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;

public class MaintenanceListener implements Listener {

    private final ConfigFile configFile;
    private final MaintenanceManager manager;

    public MaintenanceListener(ConfigFile configFile, MaintenanceManager manager) {
        this.configFile = configFile;
        this.manager = manager;
    }

    @EventHandler
    public void onLogin(PlayerLoginEvent event) {
        if (!manager.isEnabled()) return;

        // Boleh masuk kalau ada di whitelist ATAU punya permission bypass
        if (manager.canBypass(event.getPlayer())) {
            return;
        }

        String kickMessage = configFile.get().getString("kick-message", "&cServer sedang maintenance.");
        event.disallow(PlayerLoginEvent.Result.KICK_OTHER,
                ChatColor.translateAlternateColorCodes('&', kickMessage));
    }
}
