package com.sanz.sanzcore.listeners;

import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;

public class MaintenanceListener implements Listener {

    private final ConfigFile configFile;

    public MaintenanceListener(ConfigFile configFile) {
        this.configFile = configFile;
    }

    @EventHandler
    public void onLogin(PlayerLoginEvent event) {
        var cfg = configFile.get();
        if (!cfg.getBoolean("enabled", false)) return;

        if (event.getPlayer().hasPermission("lumora.maintenance.bypass")) {
            return; // staff tetap bisa masuk
        }

        String kickMessage = cfg.getString("kick-message", "&cServer sedang maintenance.");
        event.disallow(PlayerLoginEvent.Result.KICK_OTHER,
                ChatColor.translateAlternateColorCodes('&', kickMessage));
    }
}
