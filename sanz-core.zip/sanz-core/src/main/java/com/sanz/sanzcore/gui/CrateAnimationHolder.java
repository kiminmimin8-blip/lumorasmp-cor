package com.sanz.sanzcore.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/**
 * Marker holder buat GUI animasi buka crate (roulette/scroll style,
 * gaya ExcellentCrates). Read-only selama animasi jalan.
 */
public class CrateAnimationHolder implements InventoryHolder {
    private Inventory inventory;

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
