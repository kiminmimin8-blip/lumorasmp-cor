package com.sanz.sanzcore.util;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/**
 * Wrapper aman buat baca placeholder dari PlaceholderAPI.
 * Kalau PlaceholderAPI gak ke-install, method ini return -1
 * (dianggap gagal baca saldo) daripada bikin server crash.
 */
public final class PlaceholderUtil {

    private PlaceholderUtil() {}

    private static Boolean papiPresentCache = null;

    public static boolean isPapiPresent() {
        if (papiPresentCache == null) {
            papiPresentCache = Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null;
        }
        return papiPresentCache;
    }

    /**
     * Ambil saldo player dari placeholder yang ditentukan di config.
     * Contoh placeholder: "%vault_eco_balance%", "%playerpoints_points%"
     *
     * @return saldo dalam double, atau -1 kalau gagal parse / PAPI gak ada
     */
    public static double getBalance(Player player, String placeholder) {
        if (!isPapiPresent()) {
            return -1;
        }
        try {
            String parsed = me.clip.placeholderapi.PlaceholderAPI.setPlaceholders(player, placeholder);
            // buang karakter selain angka, titik, dan minus (misal ada "Rp" atau "$" di format)
            String cleaned = parsed.replaceAll("[^0-9.\\-]", "");
            if (cleaned.isEmpty()) {
                return -1;
            }
            return Double.parseDouble(cleaned);
        } catch (Exception e) {
            return -1;
        }
    }
}
