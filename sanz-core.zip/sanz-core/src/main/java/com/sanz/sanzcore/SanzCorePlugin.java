package com.sanz.sanzcore;

import com.sanz.sanzcore.commands.ArenaCommand;
import com.sanz.sanzcore.commands.BillfordCommand;
import com.sanz.sanzcore.commands.ClearLagCommand;
import com.sanz.sanzcore.commands.CrateCommand;
import com.sanz.sanzcore.commands.DuelCommand;
import com.sanz.sanzcore.commands.EventCommand;
import com.sanz.sanzcore.commands.HomeCommand;
import com.sanz.sanzcore.commands.LeaderboardCommand;
import com.sanz.sanzcore.commands.MaintenanceCommand;
import com.sanz.sanzcore.managers.MaintenanceManager;
import com.sanz.sanzcore.commands.MobRadiusCommand;
import com.sanz.sanzcore.commands.RankShopCommand;
import com.sanz.sanzcore.commands.RtpCommand;
import com.sanz.sanzcore.commands.SellCommand;
import com.sanz.sanzcore.commands.ShopCommand;
import com.sanz.sanzcore.commands.SpawnCommand;
import com.sanz.sanzcore.commands.WorldCommand;
import com.sanz.sanzcore.gui.BillfordListener;
import com.sanz.sanzcore.gui.CrateEditorListener;
import com.sanz.sanzcore.gui.RankShopListener;
import com.sanz.sanzcore.gui.ShopListener;
import com.sanz.sanzcore.listeners.DuelListener;
import com.sanz.sanzcore.commands.HomeAdminCommand;
import com.sanz.sanzcore.util.ChatInputManager;
import com.sanz.sanzcore.gui.LeaderboardHubListener;
import com.sanz.sanzcore.gui.LeaderboardPageListener;
import com.sanz.sanzcore.gui.LeaderboardAdminListener;
import com.sanz.sanzcore.gui.HomeGuiListener;
import com.sanz.sanzcore.gui.HomeAdminGuiListener;
import com.sanz.sanzcore.listeners.JoinLeaveListener;
import com.sanz.sanzcore.listeners.MaintenanceListener;
import com.sanz.sanzcore.listeners.MobSpawnListener;
import com.sanz.sanzcore.listeners.MotdListener;
import com.sanz.sanzcore.listeners.WorldPortalListener;
import com.sanz.sanzcore.managers.ArenaManager;
import com.sanz.sanzcore.managers.CrateManager;
import com.sanz.sanzcore.managers.CrateBlockManager;
import com.sanz.sanzcore.managers.CrateKeyManager;
import com.sanz.sanzcore.managers.CrateHologramManager;
import com.sanz.sanzcore.managers.CrateMilestoneManager;
import com.sanz.sanzcore.tasks.CrateParticleTask;
import com.sanz.sanzcore.listeners.CrateBlockListener;
import com.sanz.sanzcore.managers.DuelManager;
import com.sanz.sanzcore.managers.EventManager;
import com.sanz.sanzcore.managers.HomeManager;
import com.sanz.sanzcore.managers.LeaderboardManager;
import com.sanz.sanzcore.managers.SellManager;
import com.sanz.sanzcore.managers.SpawnManager;
import com.sanz.sanzcore.managers.WorldsManager;
import com.sanz.sanzcore.tasks.ClearLagTask;
import com.sanz.sanzcore.tabcomplete.SimpleTabCompleter;
import com.sanz.sanzcore.tabcomplete.WorldTabCompleter;
import com.sanz.sanzcore.tabcomplete.MaintenanceTabCompleter;
import com.sanz.sanzcore.tabcomplete.DuelTabCompleter;
import com.sanz.sanzcore.tabcomplete.HomeTabCompleter;
import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.World;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * SanzCore - plugin inti gabungan buat Lumora SMP (Folia 1.21.11).
 *
 * Struktur folder MODULAR (kayak EssentialsX) - tiap fitur punya folder
 * & config.yml sendiri di plugins/SanzCore/<fitur>/config.yml.
 *
 * Semua modul bisa dimatiin lewat plugins/SanzCore/modules.yml tanpa
 * compile ulang - tinggal set false, RESTART server (bukan /reload).
 *
 * 17 Modul: Mob Spawn Radius, RankShop, Spawn, Home, RTP, Join/Leave,
 * MOTD, Maintenance, Clearlag, Worlds, Shop, Leaderboard, Event,
 * Arena, Duel, Billford, Crates.
 */
public final class SanzCorePlugin extends JavaPlugin {

    private static SanzCorePlugin instance;

    private SpawnManager spawnManager;
    private HomeManager homeManager;
    private ConfigFile modulesConfig;

    @Override
    public void onEnable() {
        instance = this;

        this.modulesConfig = new ConfigFile(this, "modules.yml");

        // ===== MOB SPAWN RADIUS =====
        if (isModuleEnabled("mob-spawn-radius")) {
            ConfigFile mobSpawnConfig = new ConfigFile(this, "mobspawn/config.yml");
            getServer().getPluginManager().registerEvents(new MobSpawnListener(mobSpawnConfig), this);
            if (getCommand("mobradius") != null) {
                getCommand("mobradius").setExecutor(new MobRadiusCommand(mobSpawnConfig));
                getCommand("mobradius").setTabCompleter(new SimpleTabCompleter(new String[]{"set", "toggle", "status"}));
            }
        }

        // ===== RANKSHOP =====
        if (isModuleEnabled("rankshop")) {
            ConfigFile rankShopConfig = new ConfigFile(this, "rankshop/config.yml");
            ConfigFile rankShopGui = new ConfigFile(this, "rankshop/gui.yml");
            getServer().getPluginManager().registerEvents(new RankShopListener(rankShopConfig, rankShopGui), this);
            if (getCommand("rankshop") != null) getCommand("rankshop").setExecutor(new RankShopCommand(rankShopConfig, rankShopGui));
        }

        // ===== SPAWN =====
        if (isModuleEnabled("spawn")) {
            this.spawnManager = new SpawnManager(this);
            SpawnCommand spawnCommand = new SpawnCommand(this);
            if (getCommand("spawn") != null) getCommand("spawn").setExecutor(spawnCommand);
            if (getCommand("setspawn") != null) getCommand("setspawn").setExecutor(spawnCommand);
        }

        // ===== HOME =====
        if (isModuleEnabled("home")) {
            this.homeManager = new HomeManager(this);
            HomeCommand homeCommand = new HomeCommand(this);
            if (getCommand("home") != null) getCommand("home").setExecutor(homeCommand);
            if (getCommand("sethome") != null) getCommand("sethome").setExecutor(homeCommand);
            if (getCommand("delhome") != null) getCommand("delhome").setExecutor(homeCommand);
            if (getCommand("homes") != null) getCommand("homes").setExecutor(homeCommand);
            getServer().getPluginManager().registerEvents(new HomeGuiListener(homeManager), this);
            getServer().getPluginManager().registerEvents(new HomeAdminGuiListener(homeManager), this);
            if (getCommand("homeadmin") != null) getCommand("homeadmin").setExecutor(new HomeAdminCommand(this));
            HomeTabCompleter homeTabCompleter = new HomeTabCompleter(homeManager);
            if (getCommand("home") != null) getCommand("home").setTabCompleter(homeTabCompleter);
            if (getCommand("delhome") != null) getCommand("delhome").setTabCompleter(homeTabCompleter);
        }

        // ===== RTP =====
        if (isModuleEnabled("rtp")) {
            if (getCommand("rtp") != null) getCommand("rtp").setExecutor(new RtpCommand(this));
        }

        // ===== JOIN/LEAVE MESSAGE =====
        if (isModuleEnabled("join-leave-message")) {
            ConfigFile joinMessagesConfig = new ConfigFile(this, "joinmessages/config.yml");
            getServer().getPluginManager().registerEvents(new JoinLeaveListener(joinMessagesConfig), this);
        }

        // ===== MOTD =====
        if (isModuleEnabled("motd")) {
            ConfigFile motdConfig = new ConfigFile(this, "motd/config.yml");
            getServer().getPluginManager().registerEvents(new MotdListener(motdConfig), this);
        }

        // ===== MAINTENANCE =====
        if (isModuleEnabled("maintenance")) {
            ConfigFile maintenanceConfig = new ConfigFile(this, "maintenance/config.yml");
            MaintenanceManager maintenanceManager = new MaintenanceManager(maintenanceConfig);
            getServer().getPluginManager().registerEvents(new MaintenanceListener(maintenanceConfig, maintenanceManager), this);
            if (getCommand("maintenance") != null) {
                getCommand("maintenance").setExecutor(new MaintenanceCommand(maintenanceManager));
                getCommand("maintenance").setTabCompleter(new MaintenanceTabCompleter());
            }
        }

        // ===== CLEARLAG =====
        if (isModuleEnabled("clearlag")) {
            ConfigFile clearLagConfig = new ConfigFile(this, "clearlag/config.yml");
            ClearLagTask clearLagTask = new ClearLagTask(this, clearLagConfig);
            clearLagTask.start();
            if (getCommand("clearlag") != null) getCommand("clearlag").setExecutor(new ClearLagCommand(clearLagTask));
        }

        // ===== WORLDS =====
        if (isModuleEnabled("worlds")) {
            ConfigFile worldsConfig = new ConfigFile(this, "worlds/config.yml");
            WorldsManager worldsManager = new WorldsManager(this);
            for (World world : getServer().getWorlds()) {
                worldsManager.applyGameRules(world);
            }
            getServer().getPluginManager().registerEvents(new WorldPortalListener(worldsManager), this);
            WorldCommand worldCommand = new WorldCommand(worldsConfig, this, worldsManager);
            WorldTabCompleter worldTabCompleter = new WorldTabCompleter();
            if (getCommand("world") != null) {
                getCommand("world").setExecutor(worldCommand);
                getCommand("world").setTabCompleter(worldTabCompleter);
            }
            if (getCommand("worldadmin") != null) {
                getCommand("worldadmin").setExecutor(worldCommand);
                getCommand("worldadmin").setTabCompleter(worldTabCompleter);
            }
        }

        // ===== SHOP (+ SELL) =====
        ConfigFile shopConfig = null;
        ConfigFile shopGui = null;
        if (isModuleEnabled("shop")) {
            shopConfig = new ConfigFile(this, "shop/config.yml");
            shopGui = new ConfigFile(this, "shop/gui.yml");
            getServer().getPluginManager().registerEvents(new ShopListener(shopConfig, shopGui), this);
            if (getCommand("shop") != null) getCommand("shop").setExecutor(new ShopCommand(shopConfig, shopGui));

            SellManager sellManager = new SellManager(shopConfig, shopGui);
            if (getCommand("sell") != null) getCommand("sell").setExecutor(new SellCommand(sellManager));
        }

        // ===== LEADERBOARD =====
        if (isModuleEnabled("leaderboard")) {
            ConfigFile leaderboardConfig = new ConfigFile(this, "leaderboard/config.yml");
            LeaderboardManager leaderboardManager = new LeaderboardManager(this, leaderboardConfig);
            leaderboardManager.start();
            getServer().getPluginManager().registerEvents(new LeaderboardHubListener(leaderboardManager), this);
            getServer().getPluginManager().registerEvents(new LeaderboardPageListener(leaderboardManager), this);
            getServer().getPluginManager().registerEvents(new LeaderboardAdminListener(leaderboardManager), this);
            if (getCommand("leaderboard") != null) {
                getCommand("leaderboard").setExecutor(new LeaderboardCommand(leaderboardManager, leaderboardConfig));
                getCommand("leaderboard").setTabCompleter(new SimpleTabCompleter(new String[]{"admin"}));
            }
        }

        // ===== EVENT =====
        if (isModuleEnabled("event")) {
            ConfigFile eventConfig = new ConfigFile(this, "event/config.yml");
            EventManager eventManager = new EventManager(eventConfig);
            EventCommand eventCommand = new EventCommand(eventManager);
            if (getCommand("event") != null) getCommand("event").setExecutor(eventCommand);
            if (getCommand("setevent") != null) getCommand("setevent").setExecutor(eventCommand);
        }

        // ===== ARENA =====
        if (isModuleEnabled("arena")) {
            ConfigFile arenaConfig = new ConfigFile(this, "arena/config.yml");
            ArenaManager arenaManager = new ArenaManager(this, arenaConfig);
            if (getCommand("arena") != null) {
                getCommand("arena").setExecutor(new ArenaCommand(arenaManager));
                getCommand("arena").setTabCompleter(new SimpleTabCompleter(
                        new String[]{"setpos1", "setpos2", "save", "reset"}));
            }
        }

        // ===== DUEL =====
        if (isModuleEnabled("duel")) {
            ConfigFile duelConfig = new ConfigFile(this, "duel/config.yml");
            DuelManager duelManager = new DuelManager(duelConfig);
            getServer().getPluginManager().registerEvents(new DuelListener(duelManager), this);
            if (getCommand("duel") != null) {
                getCommand("duel").setExecutor(new DuelCommand(duelManager));
                getCommand("duel").setTabCompleter(new DuelTabCompleter());
            }
        }

        // ===== BILLFORD =====
        if (isModuleEnabled("billford")) {
            ConfigFile billfordConfig = new ConfigFile(this, "billford/config.yml");
            ConfigFile billfordGui = new ConfigFile(this, "billford/gui.yml");
            getServer().getPluginManager().registerEvents(new BillfordListener(billfordConfig, billfordGui), this);
            if (getCommand("billford") != null) getCommand("billford").setExecutor(new BillfordCommand(billfordConfig, billfordGui));
        }

        // ===== CRATES =====
        if (isModuleEnabled("crates")) {
            ConfigFile cratesConfig = new ConfigFile(this, "crates/config.yml");
            ConfigFile cratesGui = new ConfigFile(this, "crates/gui.yml");
            CrateManager crateManager = new CrateManager(this, cratesConfig, cratesGui);
            CrateBlockManager crateBlockManager = new CrateBlockManager(this);
            CrateKeyManager crateKeyManager = new CrateKeyManager(this);
            CrateHologramManager crateHologramManager = new CrateHologramManager(this, cratesConfig);
            CrateMilestoneManager crateMilestoneManager = new CrateMilestoneManager(this, cratesGui);
            crateManager.setMilestoneManager(crateMilestoneManager);
            new CrateParticleTask(this, cratesConfig, crateBlockManager).start();
            getServer().getPluginManager().registerEvents(
                    new CrateBlockListener(crateBlockManager, crateManager, crateKeyManager), this);
            getServer().getPluginManager().registerEvents(new CrateEditorListener(crateManager), this);

            CrateCommand crateCommand = new CrateCommand(crateManager, crateBlockManager, crateKeyManager, crateHologramManager);
            if (getCommand("crate") != null) {
                getCommand("crate").setExecutor(crateCommand);
                getCommand("crate").setTabCompleter(new SimpleTabCompleter(
                        new String[]{"open", "edit", "preview", "setweight", "setblock", "removeblock", "list", "reload"}));
            }
            if (getCommand("cratekey") != null) {
                getCommand("cratekey").setExecutor(crateCommand);
                getCommand("cratekey").setTabCompleter(new SimpleTabCompleter(new String[]{"give"}));
            }
        }

        // ChatInputManager dipake bareng sama beberapa modul (Leaderboard admin,
        // dan modul lain nanti), jadi selalu di-init biar gak NPE kalau salah
        // satu modul yang butuh chat-input nyala tapi yang lain enggak.
        new ChatInputManager(this);

        boolean papiFound = getServer().getPluginManager().getPlugin("PlaceholderAPI") != null;
        if (!papiFound) {
            getLogger().warning("PlaceholderAPI tidak ditemukan! Fitur RankShop/Shop/Leaderboard butuh " +
                    "PlaceholderAPI buat baca saldo/statistik player. Silakan install PlaceholderAPI.");
        }

        getLogger().info("SanzCore aktif! Cek plugins/SanzCore/modules.yml buat lihat modul mana yang nyala.");
    }

    private boolean isModuleEnabled(String moduleKey) {
        return modulesConfig.get().getBoolean("modules." + moduleKey, true);
    }

    @Override
    public void onDisable() {
        getLogger().info("SanzCore dimatikan.");
    }

    public static SanzCorePlugin getInstance() {
        return instance;
    }

    public SpawnManager getSpawnManager() {
        return spawnManager;
    }

    public HomeManager getHomeManager() {
        return homeManager;
    }
}
