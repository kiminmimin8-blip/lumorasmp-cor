package com.sanz.sanzcore.tabcomplete;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Tab-complete khusus /world dan /worldadmin, karena pilihan args[1]
 * beda-beda tergantung args[0] (misal /worldadmin portal punya
 * subcommand sendiri: create/delete/list).
 */
public class WorldTabCompleter implements TabCompleter {

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> options = new ArrayList<>();

        if (alias.equalsIgnoreCase("world")) {
            if (args.length == 1) {
                options.addAll(List.of("list", "tp"));
            } else if (args.length == 2 && args[0].equalsIgnoreCase("tp")) {
                options.addAll(Bukkit.getWorlds().stream().map(World::getName).collect(Collectors.toList()));
            }
        } else if (alias.equalsIgnoreCase("worldadmin")) {
            if (args.length == 1) {
                options.addAll(List.of("create", "unload", "portal", "gamerule"));
            } else if (args.length == 2) {
                if (args[0].equalsIgnoreCase("portal")) {
                    options.addAll(List.of("create", "delete", "list"));
                } else if (args[0].equalsIgnoreCase("unload") || args[0].equalsIgnoreCase("gamerule")) {
                    options.addAll(Bukkit.getWorlds().stream().map(World::getName).collect(Collectors.toList()));
                }
            } else if (args.length == 3 && args[0].equalsIgnoreCase("create")) {
                options.addAll(List.of("NORMAL", "NETHER", "THE_END"));
            }
        }

        String current = args.length > 0 ? args[args.length - 1].toLowerCase() : "";
        return options.stream().filter(o -> o.toLowerCase().startsWith(current)).collect(Collectors.toList());
    }
}
