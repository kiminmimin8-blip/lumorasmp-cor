package com.sanz.sanzcore.gui;

import com.sanz.sanzcore.managers.HomeManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.UUID;

/**
 * Admin version dari Home GUI: /homeadmin <player> buat liat home
 * player lain. Klik = TELEPORT ADMIN ke situ (bukan target). Shift-klik
 * = hapus home itu dari data player target.
 */
public class HomeAdminGuiListener implements Listener {

    private final HomeManager homeManager;

    public HomeAdminGuiListener(HomeManager homeManager) {
        this.homeManager = homeManager;
    }

    public static void openAdminGui(HomeManager homeManager, Player admin, OfflinePlayer target) {
        UUID targetUuid = target.getUniqueId();
        String targetName = target.getName() != null ? target.getName() : targetUuid.toString();

        HomeAdminGuiHolder holder = new HomeAdminGuiHolder(targetUuid, targetName);
        String title = ChatColor.translateAlternateColorCodes('&', "&c&lHome milik " + targetName);
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        List<String> homes = homeManager.getHomeNames(targetUuid);
        if (homes.isEmpty()) {
            ItemStack empty = new ItemStack(Material.BARRIER);
            ItemMeta meta = empty.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ChatColor.RED + targetName + " belum punya home.");
                empty.setItemMeta(meta);
            }
            inv.setItem(22, empty);
        } else {
            int slot = 0;
            for (String homeName : homes) {
                if (slot >= 45) break;
                ItemStack item = new ItemStack(Material.RED_BED);
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    meta.setDisplayName(ChatColor.YELLOW + "" + ChatColor.BOLD + homeName);
                    meta.setLore(List.of(
                            ChatColor.GRAY + "Klik = teleport KAMU (admin) ke sini",
                            ChatColor.RED + "Shift-klik = hapus home ini dari " + targetName
                    ));
                    item.setItemMeta(meta);
                }
                inv.setItem(slot, item);
                slot++;
            }
        }

        admin.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof HomeAdminGuiHolder holder)) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player admin)) return;
        if (!admin.hasPermission("sanzcore.home.admin")) return;

        UUID targetUuid = holder.getTargetUuid();
        List<String> homes = homeManager.getHomeNames(targetUuid);
        int slot = event.getRawSlot();
        if (slot < 0 || slot >= homes.size()) return;

        String homeName = homes.get(slot);

        if (event.getClick() == ClickType.SHIFT_LEFT || event.getClick() == ClickType.SHIFT_RIGHT) {
            homeManager.deleteHome(targetUuid, homeName);
            admin.sendMessage(ChatColor.RED + "Home " + homeName + " milik " + holder.getTargetName() + " dihapus.");
            OfflinePlayer target = Bukkit.getOfflinePlayer(targetUuid);
            openAdminGui(homeManager, admin, target); // refresh
            return;
        }

        var loc = homeManager.getHome(targetUuid, homeName);
        if (loc == null) {
            admin.sendMessage(ChatColor.RED + "Gagal teleport, world home ini gak ketemu.");
            return;
        }
        admin.closeInventory();
        admin.teleportAsync(loc);
        admin.sendMessage(ChatColor.GREEN + "Teleport ke home " + homeName + " milik " + holder.getTargetName() + "...");
    }
}
