package com.sanz.sanzcore.listeners;

import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class JoinLeaveListener implements Listener {

    private final ConfigFile configFile;

    public JoinLeaveListener(ConfigFile configFile) {
        this.configFile = configFile;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        var cfg = configFile.get();
        if (!cfg.getBoolean("enabled", true)) return;

        String message;
        if (cfg.getBoolean("first-join-enabled", true) && !event.getPlayer().hasPlayedBefore()) {
            message = cfg.getString("first-join-message", "&6Welcome %player%!");
        } else {
            message = cfg.getString("join-message", "&a+ %player%");
        }
        message = message.replace("%player%", event.getPlayer().getName());
        event.setJoinMessage(ChatColor.translateAlternateColorCodes('&', message));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        var cfg = configFile.get();
        if (!cfg.getBoolean("enabled", true)) return;

        String message = cfg.getString("quit-message", "&c- %player%")
                .replace("%player%", event.getPlayer().getName());
        event.setQuitMessage(ChatColor.translateAlternateColorCodes('&', message));
    }
}
