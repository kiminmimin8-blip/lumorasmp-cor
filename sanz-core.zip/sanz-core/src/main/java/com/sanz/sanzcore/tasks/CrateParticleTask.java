package com.sanz.sanzcore.tasks;

import com.sanz.sanzcore.managers.CrateBlockManager;
import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Spawn particle muter-muter (Helix/Vortex sederhana) di atas semua
 * crate block yang ke-link. Dijalanin berkala pakai Folia region
 * scheduler biar aman per-lokasi.
 */
public class CrateParticleTask {

    private final JavaPlugin plugin;
    private final ConfigFile configFile;
    private final CrateBlockManager blockManager;
    private double angle = 0;

    public CrateParticleTask(JavaPlugin plugin, ConfigFile configFile, CrateBlockManager blockManager) {
        this.plugin = plugin;
        this.configFile = configFile;
        this.blockManager = blockManager;
    }

    public void start() {
        if (!configFile.get().getBoolean("particles.enabled", true)) return;

        long periodTicks = configFile.get().getLong("particles.interval-ticks", 5);
        Bukkit.getGlobalRegionScheduler().runAtFixedRate(plugin, task -> tick(), periodTicks, periodTicks);
    }

    private void tick() {
        angle += 0.3;
        String particleName = configFile.get().getString("particles.type", "PORTAL");
        Particle particle;
        try {
            particle = Particle.valueOf(particleName);
        } catch (IllegalArgumentException e) {
            particle = Particle.PORTAL;
        }

        for (Location loc : blockManager.getAllLinkedLocations()) {
            if (loc.getWorld() == null) continue;
            // pola "Helix": 2 titik muter berlawanan arah, naik turun pelan
            double radius = 0.6;
            double height = 1.0 + Math.sin(angle) * 0.3;

            double x1 = loc.getBlockX() + 0.5 + Math.cos(angle) * radius;
            double z1 = loc.getBlockZ() + 0.5 + Math.sin(angle) * radius;
            double x2 = loc.getBlockX() + 0.5 + Math.cos(angle + Math.PI) * radius;
            double z2 = loc.getBlockZ() + 0.5 + Math.sin(angle + Math.PI) * radius;

            loc.getWorld().spawnParticle(particle, x1, loc.getBlockY() + height, z1, 1, 0, 0, 0, 0);
            loc.getWorld().spawnParticle(particle, x2, loc.getBlockY() + height, z2, 1, 0, 0, 0, 0);
        }
    }
}
