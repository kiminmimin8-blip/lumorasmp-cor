package com.sanz.sanzcore.gui;

import com.sanz.sanzcore.managers.LeaderboardManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.List;
import java.util.Map;

/**
 * Nampilin peringkat 1-500 (atau sesuai top-count di config) buat 1
 * kategori, dipecah per halaman (default 45 slot/halaman). Slot bawah
 * buat navigasi: kembali ke hub, halaman sebelumnya/berikutnya.
 */
public class LeaderboardPageListener implements Listener {

    private static final int BACK_SLOT = 45;
    private static final int PREV_SLOT = 48;
    private static final int NEXT_SLOT = 50;

    private final LeaderboardManager manager;

    public LeaderboardPageListener(LeaderboardManager manager) {
        this.manager = manager;
    }

    public static void openPage(LeaderboardManager manager, Player player, String boardName, int page) {
        LeaderboardPageHolder holder = new LeaderboardPageHolder(boardName, page);
        String title = ChatColor.translateAlternateColorCodes('&',
                manager.getDisplayName(boardName) + " &8- Hal " + (page + 1));
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        int itemsPerPage = 45;
        int topCount = 500;
        List<Map.Entry<String, Double>> top = manager.getTop(boardName, topCount);

        int startIndex = page * itemsPerPage;
        int endIndex = Math.min(startIndex + itemsPerPage, top.size());

        int slot = 0;
        for (int i = startIndex; i < endIndex; i++) {
            Map.Entry<String, Double> entry = top.get(i);
            int rank = i + 1;

            ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) skull.getItemMeta();
            if (meta != null) {
                meta.setOwningPlayer(Bukkit.getOfflinePlayer(entry.getKey()));
                ChatColor rankColor = rank == 1 ? ChatColor.GOLD : rank <= 3 ? ChatColor.YELLOW : ChatColor.WHITE;
                meta.setDisplayName(rankColor + "#" + rank + " " + ChatColor.WHITE + entry.getKey());

                String valueDisplay = manager.isPlaytimeBoard(boardName)
                        ? String.format("%.1f jam", entry.getValue() / 20.0 / 3600.0)
                        : String.valueOf(entry.getValue().longValue());

                meta.setLore(List.of(ChatColor.GRAY + "Nilai: " + ChatColor.GREEN + valueDisplay));
                skull.setItemMeta(meta);
            }
            inv.setItem(slot, skull);
            slot++;
        }

        // navigasi
        ItemStack back = namedItem(Material.BARRIER, ChatColor.RED + "Kembali ke Menu");
        inv.setItem(BACK_SLOT, back);

        if (page > 0) {
            inv.setItem(PREV_SLOT, namedItem(Material.ARROW, ChatColor.YELLOW + "<< Halaman Sebelumnya"));
        }
        if (endIndex < top.size()) {
            inv.setItem(NEXT_SLOT, namedItem(Material.ARROW, ChatColor.YELLOW + "Halaman Berikutnya >>"));
        }

        ItemStack info = namedItem(Material.BOOK, ChatColor.AQUA + "Menampilkan #" + (startIndex + 1) +
                " - #" + endIndex + " dari " + top.size());
        inv.setItem(49, info);

        player.openInventory(inv);
    }

    private static ItemStack namedItem(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            item.setItemMeta(meta);
        }
        return item;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof LeaderboardPageHolder holder)) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        int slot = event.getRawSlot();

        if (slot == BACK_SLOT) {
            LeaderboardHubListener.openHub(manager, player);
        } else if (slot == PREV_SLOT && holder.getPage() > 0) {
            openPage(manager, player, holder.getBoardName(), holder.getPage() - 1);
        } else if (slot == NEXT_SLOT) {
            openPage(manager, player, holder.getBoardName(), holder.getPage() + 1);
        }
    }
}
