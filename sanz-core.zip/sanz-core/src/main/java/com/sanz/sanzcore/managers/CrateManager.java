package com.sanz.sanzcore.managers;

import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Sistem crate/gacha gaya ExcellentCrates: player pegang key item,
 * /crate open <nama> buat ngundi reward berdasarkan weight (bobot).
 * Makin gede weight, makin sering keluar.
 */
public class CrateManager {

    private final JavaPlugin plugin;
    private final ConfigFile configFile;
    private final ConfigFile guiFile;
    private final File winLimitFolder;
    private final Random random = new Random();

    public CrateManager(JavaPlugin plugin, ConfigFile configFile, ConfigFile guiFile) {
        this.plugin = plugin;
        this.configFile = configFile;
        this.guiFile = guiFile;
        this.winLimitFolder = new File(plugin.getDataFolder(), "crates/winlimits");
        if (!winLimitFolder.exists()) winLimitFolder.mkdirs();
    }

    public boolean crateExists(String crateName) {
        var crates = guiFile.get().getConfigurationSection("crates");
        return crates != null && crates.contains(crateName);
    }

    /**
     * Kalau true, crate ini pakai Virtual Keys (data angka, gak bisa
     * di-trade). Kalau false, pakai Physical Keys (item beneran).
     * Diatur lewat "virtual-keys: true" di gui.yml per-crate.
     */
    public boolean isVirtualKeyMode(String crateName) {
        return guiFile.get().getBoolean("crates." + crateName + ".virtual-keys", false);
    }

    public String getDisplayName(String crateName) {
        return guiFile.get().getString("crates." + crateName + ".display-name", crateName);
    }

    /**
     * Cek apakah item yang dipegang player itu key buat crate ini
     * (dicek dari material + display name, biar bisa bikin custom key).
     */
    public boolean isHoldingKey(Player player, String crateName) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        String path = "crates." + crateName;
        var cfg = guiFile.get();

        Material keyMaterial = Material.matchMaterial(cfg.getString(path + ".key-material", "TRIPWIRE_HOOK"));
        String keyName = ChatColor.translateAlternateColorCodes('&', cfg.getString(path + ".key-name", "Key"));

        if (hand.getType() != keyMaterial) return false;
        ItemMeta meta = hand.getItemMeta();
        return meta != null && keyName.equals(meta.getDisplayName());
    }

    public void removeOneKey(Player player) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        hand.setAmount(hand.getAmount() - 1);
    }

    public ItemStack createKey(String crateName, int amount) {
        String path = "crates." + crateName;
        var cfg = guiFile.get();
        Material keyMaterial = Material.matchMaterial(cfg.getString(path + ".key-material", "TRIPWIRE_HOOK"));
        String keyName = ChatColor.translateAlternateColorCodes('&', cfg.getString(path + ".key-name", "Key"));

        ItemStack key = new ItemStack(keyMaterial, amount);
        ItemMeta meta = key.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(keyName);
            key.setItemMeta(meta);
        }
        return key;
    }

    /**
     * Undi reward berdasarkan weight, kasih ke player, dan broadcast
     * kalau reward-nya ditandai "broadcast: true". Ini jalur INSTAN
     * (tanpa animasi) — dipakai kalau animasi crate di-disable di config.
     */
    public void openCrate(Player player, String crateName) {
        Map<?, ?> chosen = rollReward(player, crateName);
        if (chosen == null) return; // pesan error udah dikirim di rollReward

        trackWin(player, crateName, String.valueOf(chosen.get("id")));
        giveReward(player, chosen, crateName);
    }

    /**
     * Cuma undi reward-nya aja (weight-based), TANPA langsung kasih ke player.
     * Dipakai sama animasi crate (CrateAnimationListener) buat nentuin dulu
     * reward pemenangnya sebelum animasi scroll dimulai, baru di-apply
     * (trackWin + giveReward) pas animasi selesai lewat applyRoll().
     * Return null kalau gagal (pesan error udah dikirim ke player).
     */
    public Map<?, ?> rollReward(Player player, String crateName) {
        String path = "crates." + crateName + ".rewards";
        List<Map<?, ?>> allRewards = guiFile.get().getMapList(path);
        if (allRewards.isEmpty()) {
            player.sendMessage(ChatColor.RED + "Crate ini belum ada reward-nya, hubungi admin.");
            return null;
        }

        // Buang reward yang udah kena limit (max-wins / cooldown) buat player ini
        List<Map<?, ?>> rewards = new ArrayList<>();
        for (Map<?, ?> reward : allRewards) {
            if (isRewardAvailable(player, crateName, reward)) {
                rewards.add(reward);
            }
        }
        if (rewards.isEmpty()) {
            player.sendMessage(ChatColor.RED + "Semua reward di crate ini lagi kena limit buat kamu, coba lagi nanti.");
            return null;
        }

        int totalWeight = 0;
        for (Map<?, ?> reward : rewards) {
            totalWeight += (int) reward.get("weight");
        }

        int roll = random.nextInt(totalWeight);
        int cumulative = 0;
        Map<?, ?> chosen = rewards.get(rewards.size() - 1); // fallback

        for (Map<?, ?> reward : rewards) {
            cumulative += (int) reward.get("weight");
            if (roll < cumulative) {
                chosen = reward;
                break;
            }
        }
        return chosen;
    }

    /**
     * Apply reward yang udah kepilih dari rollReward() — dipanggil animasi
     * crate pas landing selesai. Kalau chosen null, gak ngapa-ngapain.
     */
    public void applyRoll(Player player, String crateName, Map<?, ?> chosen) {
        if (chosen == null) return;
        trackWin(player, crateName, String.valueOf(chosen.get("id")));
        giveReward(player, chosen, crateName);
    }

    /**
     * Bikin ItemStack icon buat 1 reward (dipakai animasi & preview GUI),
     * material-nya nyesuain type reward: ITEM pakai material item pertama,
     * COMMAND pakai COMMAND_BLOCK, fallback PAPER.
     */
    public ItemStack getRewardIcon(Map<?, ?> reward) {
        String type = String.valueOf(reward.get("type"));
        Material material = Material.PAPER;

        if ("ITEM".equalsIgnoreCase(type)) {
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> items = (List<Map<String, Object>>) reward.get("items");
            if (items != null && !items.isEmpty()) {
                Material matched = Material.matchMaterial(String.valueOf(items.get(0).get("material")));
                if (matched != null) material = matched;
            }
        } else if ("COMMAND".equalsIgnoreCase(type)) {
            material = Material.COMMAND_BLOCK;
        }

        ItemStack icon = new ItemStack(material);
        ItemMeta meta = icon.getItemMeta();
        if (meta != null) {
            String displayName = ChatColor.translateAlternateColorCodes('&', String.valueOf(reward.get("display-name")));
            meta.setDisplayName(displayName);
            icon.setItemMeta(meta);
        }
        return icon;
    }

    /**
     * Apakah fitur animasi buka crate di-enable (crates/config.yml).
     */
    public boolean isAnimationEnabled() {
        return configFile.get().getBoolean("animation.enabled", true);
    }

    /**
     * Cek apakah reward ini masih boleh keluar buat player (belum
     * ke-mentok max-wins, dan cooldown-nya udah lewat).
     * Field opsional di reward: max-wins, cooldown-seconds.
     */
    private boolean isRewardAvailable(Player player, String crateName, Map<?, ?> reward) {
        if (!reward.containsKey("max-wins") && !reward.containsKey("cooldown-seconds")) {
            return true; // gak ada limit sama sekali, selalu available
        }
        String rewardId = String.valueOf(reward.get("id"));
        YamlConfiguration winData = loadWinData(player.getUniqueId());
        String base = crateName + "." + rewardId;

        if (reward.containsKey("max-wins")) {
            int maxWins = (int) reward.get("max-wins");
            int currentWins = winData.getInt(base + ".count", 0);
            if (currentWins >= maxWins) return false;
        }
        if (reward.containsKey("cooldown-seconds")) {
            long cooldownMs = ((Number) reward.get("cooldown-seconds")).longValue() * 1000L;
            long lastWin = winData.getLong(base + ".last", 0);
            if (System.currentTimeMillis() - lastWin < cooldownMs) return false;
        }
        return true;
    }

    private void trackWin(Player player, String crateName, String rewardId) {
        YamlConfiguration winData = loadWinData(player.getUniqueId());
        String base = crateName + "." + rewardId;
        int currentWins = winData.getInt(base + ".count", 0);
        winData.set(base + ".count", currentWins + 1);
        winData.set(base + ".last", System.currentTimeMillis());
        saveWinData(player.getUniqueId(), winData);
    }

    private File winFileFor(UUID uuid) {
        return new File(winLimitFolder, uuid.toString() + ".yml");
    }

    private YamlConfiguration loadWinData(UUID uuid) {
        File f = winFileFor(uuid);
        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("Gagal bikin win-limit data: " + e.getMessage());
            }
        }
        return YamlConfiguration.loadConfiguration(f);
    }

    private void saveWinData(UUID uuid, YamlConfiguration data) {
        try {
            data.save(winFileFor(uuid));
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal simpan win-limit data: " + e.getMessage());
        }
    }

    /**
     * Hitung persen peluang tiap reward (buat ditampilin di /crate preview).
     */
    public Map<String, Double> getChancePercentages(String crateName) {
        List<Map<?, ?>> rewards = getRewards(crateName);
        int totalWeight = 0;
        for (Map<?, ?> reward : rewards) {
            totalWeight += (int) reward.get("weight");
        }
        Map<String, Double> result = new java.util.LinkedHashMap<>();
        for (Map<?, ?> reward : rewards) {
            String id = String.valueOf(reward.get("id"));
            double percent = totalWeight == 0 ? 0 : ((int) reward.get("weight") * 100.0 / totalWeight);
            result.put(id, percent);
        }
        return result;
    }

    // ===================== EDITOR SUPPORT =====================

    public List<String> getCrateNames() {
        var crates = guiFile.get().getConfigurationSection("crates");
        if (crates == null) return new ArrayList<>();
        return new ArrayList<>(crates.getKeys(false));
    }

    /**
     * Ambil semua reward suatu crate sebagai list Map mentah (dari YAML),
     * dipakai buat render item di editor GUI.
     */
    public List<Map<?, ?>> getRewards(String crateName) {
        return guiFile.get().getMapList("crates." + crateName + ".rewards");
    }

    /**
     * Hapus 1 reward dari crate berdasarkan id-nya.
     */
    public boolean removeReward(String crateName, String rewardId) {
        List<Map<?, ?>> rewards = new ArrayList<>(getRewards(crateName));
        boolean removed = rewards.removeIf(r -> rewardId.equals(String.valueOf(r.get("id"))));
        if (removed) {
            guiFile.get().set("crates." + crateName + ".rewards", rewards);
            guiFile.save();
        }
        return removed;
    }

    /**
     * Tambah reward baru bertipe ITEM, diambil dari item yang lagi
     * dipegang admin di tangan. Weight default 10, broadcast false.
     */
    public String addItemReward(String crateName, ItemStack heldItem, int weight) {
        List<Map<?, ?>> rewards = new ArrayList<>(getRewards(crateName));

        String newId = "reward_" + UUID.randomUUID().toString().substring(0, 6);
        String displayName = heldItem.hasItemMeta() && heldItem.getItemMeta().hasDisplayName()
                ? heldItem.getItemMeta().getDisplayName()
                : "&f" + heldItem.getAmount() + "x " + heldItem.getType().name();

        Map<String, Object> newReward = new java.util.HashMap<>();
        newReward.put("id", newId);
        newReward.put("display-name", displayName);
        newReward.put("weight", weight);
        newReward.put("broadcast", false);
        newReward.put("type", "ITEM");

        List<Map<String, Object>> items = new ArrayList<>();
        Map<String, Object> itemDef = new java.util.HashMap<>();
        itemDef.put("material", heldItem.getType().name());
        itemDef.put("amount", heldItem.getAmount());
        items.add(itemDef);
        newReward.put("items", items);

        rewards.add(newReward);
        guiFile.get().set("crates." + crateName + ".rewards", rewards);
        guiFile.save();
        return newId;
    }

    /**
     * Ubah weight (bobot peluang) reward yang udah ada.
     */
    public boolean setWeight(String crateName, String rewardId, int newWeight) {
        List<Map<?, ?>> rewards = getRewards(crateName);
        for (int i = 0; i < rewards.size(); i++) {
            Map<?, ?> r = rewards.get(i);
            if (rewardId.equals(String.valueOf(r.get("id")))) {
                Map<Object, Object> mutable = new java.util.HashMap<>(r);
                mutable.put("weight", newWeight);
                List<Map<?, ?>> updated = new ArrayList<>(rewards);
                updated.set(i, mutable);
                guiFile.get().set("crates." + crateName + ".rewards", updated);
                guiFile.save();
                return true;
            }
        }
        return false;
    }

    /**
     * Reload config dari disk — dipanggil kalau ada yang edit YAML manual
     * dan mau apply tanpa restart server.
     */
    public void reload() {
        configFile.reload();
        guiFile.reload();
    }

    /**
     * Kasih reward yang udah kepilih ke player: item, command, broadcast, dll.
     */
    @SuppressWarnings("unchecked")
    private void giveReward(Player player, Map<?, ?> reward, String crateName) {
        String type = String.valueOf(reward.get("type"));
        String displayName = ChatColor.translateAlternateColorCodes('&', String.valueOf(reward.get("display-name")));

        if (type.equalsIgnoreCase("COMMAND")) {
            List<String> commands = (List<String>) reward.get("commands");
            if (commands != null) {
                for (String cmd : commands) {
                    String finalCmd = cmd.replace("%player%", player.getName());
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), finalCmd);
                }
            }
        } else if (type.equalsIgnoreCase("ITEM")) {
            List<Map<String, Object>> items = (List<Map<String, Object>>) reward.get("items");
            if (items != null) {
                for (Map<String, Object> itemDef : items) {
                    Material mat = Material.matchMaterial(String.valueOf(itemDef.get("material")));
                    int amount = (int) itemDef.get("amount");
                    if (mat != null) {
                        player.getInventory().addItem(new ItemStack(mat, amount));
                    }
                }
            }
        }

        player.sendMessage(ChatColor.GREEN + "Kamu dapet: " + displayName + ChatColor.GREEN + "!");

        boolean broadcast = reward.get("broadcast") != null && (boolean) reward.get("broadcast");
        if (broadcast && configFile.get().getBoolean("broadcast-rare-rewards", true)) {
            String msg = configFile.get().getString("broadcast-message",
                            "&6[Crate] %player% dapet %reward%!")
                    .replace("%player%", player.getName())
                    .replace("%crate%", getDisplayName(crateName))
                    .replace("%reward%", displayName);
            Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', msg));
        }
    }
}
