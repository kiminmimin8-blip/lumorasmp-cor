package com.sanz.sanzcore.commands;

import com.sanz.sanzcore.SanzCorePlugin;
import com.sanz.sanzcore.gui.HomeAdminGuiListener;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HomeAdminCommand implements CommandExecutor {

    private final SanzCorePlugin plugin;

    public HomeAdminCommand(SanzCorePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("sanzcore.home.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }
        if (!(sender instanceof Player admin)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (args.length == 0) {
            admin.sendMessage(ChatColor.RED + "Gunakan: /homeadmin <nama player>");
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if (!target.hasPlayedBefore() && !target.isOnline()) {
            admin.sendMessage(ChatColor.RED + "Player " + args[0] + " gak pernah main di server ini.");
            return true;
        }

        HomeAdminGuiListener.openAdminGui(plugin.getHomeManager(), admin, target);
        return true;
    }
}
