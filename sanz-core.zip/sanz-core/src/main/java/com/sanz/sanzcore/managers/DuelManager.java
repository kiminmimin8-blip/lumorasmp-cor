package com.sanz.sanzcore.managers;

import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class DuelManager {

    private final ConfigFile configFile;

    // target UUID -> requester UUID
    private final Map<UUID, UUID> pendingRequests = new ConcurrentHashMap<>();
    // player UUID -> lawan duel (kalau lagi duel)
    private final Map<UUID, UUID> activeDuels = new ConcurrentHashMap<>();
    // player UUID -> lokasi sebelum duel (buat balikin)
    private final Map<UUID, Location> returnLocations = new ConcurrentHashMap<>();

    public DuelManager(ConfigFile configFile) {
        this.configFile = configFile;
    }

    public void sendRequest(Player from, Player to) {
        pendingRequests.put(to.getUniqueId(), from.getUniqueId());
    }

    public UUID getRequester(UUID target) {
        return pendingRequests.get(target);
    }

    public void clearRequest(UUID target) {
        pendingRequests.remove(target);
    }

    public boolean isInDuel(UUID uuid) {
        return activeDuels.containsKey(uuid);
    }

    public UUID getOpponent(UUID uuid) {
        return activeDuels.get(uuid);
    }

    /**
     * Mulai duel: catat lokasi asal, teleport keduanya ke arena random.
     */
    public void startDuel(Player p1, Player p2) {
        activeDuels.put(p1.getUniqueId(), p2.getUniqueId());
        activeDuels.put(p2.getUniqueId(), p1.getUniqueId());
        returnLocations.put(p1.getUniqueId(), p1.getLocation());
        returnLocations.put(p2.getUniqueId(), p2.getLocation());

        Location arenaLoc = getRandomArena();
        if (arenaLoc != null) {
            p1.teleportAsync(arenaLoc);
            p2.teleportAsync(arenaLoc);
        }
    }

    /**
     * Selesai duel (salah satu kalah/disconnect). Balikin lokasi kalau
     * diset di config.
     */
    public void endDuel(UUID loserOrEnder) {
        UUID opponent = activeDuels.remove(loserOrEnder);
        if (opponent != null) activeDuels.remove(opponent);

        boolean teleportBack = configFile.get().getBoolean("teleport-back-after-duel", true);
        if (teleportBack) {
            teleportBackIfPossible(loserOrEnder);
            if (opponent != null) teleportBackIfPossible(opponent);
        }
        returnLocations.remove(loserOrEnder);
        if (opponent != null) returnLocations.remove(opponent);
    }

    private void teleportBackIfPossible(UUID uuid) {
        Player player = Bukkit.getPlayer(uuid);
        Location loc = returnLocations.get(uuid);
        if (player != null && loc != null) {
            player.teleportAsync(loc);
        }
    }

    private Location getRandomArena() {
        var arenas = configFile.get().getConfigurationSection("arenas");
        if (arenas == null) return null;
        List<String> keys = new ArrayList<>(arenas.getKeys(false));
        if (keys.isEmpty()) return null;

        String chosen = keys.get(new Random().nextInt(keys.size()));
        String worldName = configFile.get().getString("world", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;

        double x = arenas.getDouble(chosen + ".x");
        double y = arenas.getDouble(chosen + ".y");
        double z = arenas.getDouble(chosen + ".z");
        float yaw = (float) arenas.getDouble(chosen + ".yaw");
        float pitch = (float) arenas.getDouble(chosen + ".pitch");
        return new Location(world, x, y, z, yaw, pitch);
    }
}
