package com.sanz.sanzcore.listeners;

import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.Location;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;

/**
 * Blokir monster spawn kalau ada player dalam radius tertentu.
 * Radius diambil dari mobspawn.yml, satuan blok.
 *
 * Catatan Folia: CreatureSpawnEvent otomatis dipanggil di region thread
 * yang benar sesuai lokasi entity, jadi listener sederhana ini aman
 * dipakai langsung tanpa perlu scheduler manual.
 */
public class MobSpawnListener implements Listener {

    private final ConfigFile configFile;

    public MobSpawnListener(ConfigFile configFile) {
        this.configFile = configFile;
    }

    @EventHandler
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        if (!(event.getEntity() instanceof Monster)) {
            return; // cuma block monster, bukan animal/passive mob
        }

        if (!configFile.get().getBoolean("enabled", true)) {
            return;
        }

        int radius = configFile.get().getInt("radius", 16);
        double radiusSquared = (double) radius * radius;
        Location spawnLoc = event.getLocation();

        for (Player player : spawnLoc.getWorld().getPlayers()) {
            if (player.getLocation().distanceSquared(spawnLoc) < radiusSquared) {
                event.setCancelled(true);
                return;
            }
        }
    }
}
