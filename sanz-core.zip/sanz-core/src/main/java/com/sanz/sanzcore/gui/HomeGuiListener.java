package com.sanz.sanzcore.gui;

import com.sanz.sanzcore.managers.HomeManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * GUI Home gaya DonutSMP: /home tanpa argumen -> buka menu list semua
 * home kamu, klik buat teleport, shift-klik buat hapus. Slot kosong di
 * bawah = "+ Bikin Home Baru" (kalau belum kena limit).
 */
public class HomeGuiListener implements Listener {

    private static final int NEW_HOME_SLOT = 49;

    private final HomeManager homeManager;

    public HomeGuiListener(HomeManager homeManager) {
        this.homeManager = homeManager;
    }

    public static void openHomeGui(HomeManager homeManager, Player player) {
        HomeGuiHolder holder = new HomeGuiHolder();
        String title = ChatColor.translateAlternateColorCodes('&', "&5&lHome Kamu");
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        List<String> homes = homeManager.getHomeNames(player.getUniqueId());
        int maxHomes = homeManager.getMaxHomes(player);

        int slot = 0;
        for (String homeName : homes) {
            if (slot >= 45) break;
            ItemStack item = new ItemStack(Material.RED_BED);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ChatColor.GREEN + "" + ChatColor.BOLD + homeName);
                meta.setLore(List.of(
                        ChatColor.GRAY + "Klik buat teleport",
                        ChatColor.RED + "Shift-klik buat hapus"
                ));
                item.setItemMeta(meta);
            }
            inv.setItem(slot, item);
            slot++;
        }

        // slot "bikin home baru" kalau belum kena limit
        boolean canAddMore = homes.size() < maxHomes;
        ItemStack newHomeItem = new ItemStack(canAddMore ? Material.EMERALD : Material.BARRIER);
        ItemMeta newMeta = newHomeItem.getItemMeta();
        if (newMeta != null) {
            if (canAddMore) {
                newMeta.setDisplayName(ChatColor.GREEN + "+ Bikin Home Baru di Sini");
                newMeta.setLore(List.of(
                        ChatColor.GRAY + "Home kamu: " + homes.size() + "/" + (maxHomes == Integer.MAX_VALUE ? "∞" : maxHomes),
                        ChatColor.GRAY + "Klik buat simpan home baru di posisi kamu sekarang",
                        ChatColor.YELLOW + "(nama otomatis: home1, home2, dst)"
                ));
            } else {
                newMeta.setDisplayName(ChatColor.RED + "Home Kamu Udah Penuh");
                newMeta.setLore(List.of(
                        ChatColor.GRAY + "Home kamu: " + homes.size() + "/" + maxHomes,
                        ChatColor.GRAY + "Hapus salah satu home dulu (shift-klik)"
                ));
            }
            newHomeItem.setItemMeta(newMeta);
        }
        inv.setItem(NEW_HOME_SLOT, newHomeItem);

        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof HomeGuiHolder)) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;

        int slot = event.getRawSlot();
        List<String> homes = homeManager.getHomeNames(player.getUniqueId());

        if (slot == NEW_HOME_SLOT) {
            int maxHomes = homeManager.getMaxHomes(player);
            if (homes.size() >= maxHomes) {
                player.sendMessage(ChatColor.RED + "Home kamu udah penuh! Hapus salah satu dulu.");
                return;
            }
            String newName = "home" + (homes.size() + 1);
            while (homeManager.hasHome(player.getUniqueId(), newName)) {
                newName = "home" + (Integer.parseInt(newName.replace("home", "")) + 1);
            }
            homeManager.setHome(player.getUniqueId(), newName, player.getLocation());
            player.sendMessage(ChatColor.GREEN + "Home " + ChatColor.YELLOW + newName + ChatColor.GREEN + " berhasil dibuat!");
            player.closeInventory();
            return;
        }

        if (slot < 0 || slot >= homes.size()) return;
        String homeName = homes.get(slot);

        if (event.getClick() == ClickType.SHIFT_LEFT || event.getClick() == ClickType.SHIFT_RIGHT) {
            homeManager.deleteHome(player.getUniqueId(), homeName);
            player.sendMessage(ChatColor.RED + "Home " + homeName + " dihapus.");
            openHomeGui(homeManager, player); // refresh GUI
            return;
        }

        var loc = homeManager.getHome(player.getUniqueId(), homeName);
        if (loc == null) {
            player.sendMessage(ChatColor.RED + "Gagal teleport, world home ini gak ketemu.");
            return;
        }
        player.closeInventory();
        player.teleportAsync(loc);
        player.sendMessage(ChatColor.GREEN + "Teleport ke home " + homeName + "...");
    }
}
