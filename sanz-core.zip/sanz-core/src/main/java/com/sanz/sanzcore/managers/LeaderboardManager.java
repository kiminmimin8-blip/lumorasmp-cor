package com.sanz.sanzcore.managers;

import com.sanz.sanzcore.util.ConfigFile;
import com.sanz.sanzcore.util.PlaceholderUtil;
import org.bukkit.Bukkit;
import org.bukkit.Statistic;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Nge-cache top player per board secara berkala. Support 2 sumber data:
 *  - PLACEHOLDER: baca dari PlaceholderAPI (buat Money, Coin, dll)
 *  - STATISTIC: baca dari statistik native Bukkit (buat Kill, Playtime,
 *    dll) — gak butuh PlaceholderAPI sama sekali.
 *
 * Cuma player yang lagi online yang bisa keupdate datanya tiap refresh,
 * tapi data lama tetep disimpen di cache sampai player itu online lagi.
 */
public class LeaderboardManager {

    private final JavaPlugin plugin;
    private final ConfigFile configFile;
    // boardName -> (playerName -> value)
    private final Map<String, Map<String, Double>> cache = new ConcurrentHashMap<>();

    public LeaderboardManager(JavaPlugin plugin, ConfigFile configFile) {
        this.plugin = plugin;
        this.configFile = configFile;
    }

    public void start() {
        long intervalTicks = configFile.get().getLong("refresh-interval-seconds", 60) * 20L;
        Bukkit.getGlobalRegionScheduler().runAtFixedRate(plugin, task -> refresh(), 100L, intervalTicks);
    }

    private void refresh() {
        ConfigurationSection boards = configFile.get().getConfigurationSection("boards");
        if (boards == null) return;

        for (String boardName : boards.getKeys(false)) {
            String source = boards.getString(boardName + ".source", "PLACEHOLDER");
            Map<String, Double> boardData = cache.computeIfAbsent(boardName, k -> new ConcurrentHashMap<>());

            if (source.equalsIgnoreCase("STATISTIC")) {
                String statName = boards.getString(boardName + ".statistic");
                if (statName == null) continue;
                Statistic statistic;
                try {
                    statistic = Statistic.valueOf(statName);
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().warning("Statistic '" + statName + "' gak valid buat board " + boardName);
                    continue;
                }
                for (Player player : Bukkit.getOnlinePlayers()) {
                    boardData.put(player.getName(), (double) player.getStatistic(statistic));
                }
            } else {
                String placeholder = boards.getString(boardName + ".placeholder");
                if (placeholder == null) continue;
                for (Player player : Bukkit.getOnlinePlayers()) {
                    double value = PlaceholderUtil.getBalance(player, placeholder);
                    if (value >= 0) {
                        boardData.put(player.getName(), value);
                    }
                }
            }
        }
    }

    public List<Map.Entry<String, Double>> getTop(String boardName, int count) {
        Map<String, Double> boardData = cache.getOrDefault(boardName, Map.of());
        List<Map.Entry<String, Double>> sorted = new ArrayList<>(boardData.entrySet());
        sorted.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
        if (sorted.size() > count) {
            return sorted.subList(0, count);
        }
        return sorted;
    }

    public String getDisplayName(String boardName) {
        return configFile.get().getString("boards." + boardName + ".display-name", boardName);
    }

    public String getIcon(String boardName) {
        return configFile.get().getString("boards." + boardName + ".icon", "PAPER");
    }

    public boolean isPlaytimeBoard(String boardName) {
        return "PLAY_ONE_MINUTE".equalsIgnoreCase(
                configFile.get().getString("boards." + boardName + ".statistic", ""));
    }

    public boolean boardExists(String boardName) {
        ConfigurationSection boards = configFile.get().getConfigurationSection("boards");
        return boards != null && boards.contains(boardName);
    }

    public List<String> getBoardNames() {
        ConfigurationSection boards = configFile.get().getConfigurationSection("boards");
        if (boards == null) return new ArrayList<>();
        return new ArrayList<>(boards.getKeys(false));
    }

    // ===================== ADMIN EDIT SUPPORT =====================

    private static final String[] STATISTIC_PRESETS = {
            "PLAYER_KILLS", "MOB_KILLS", "DEATHS", "PLAY_ONE_MINUTE",
            "DAMAGE_DEALT", "FISH_CAUGHT", "JUMP", "TIME_SINCE_DEATH"
    };

    /**
     * Bikin board baru pakai statistik native Bukkit (default aman
     * karena gak butuh PlaceholderAPI). Admin bisa "cycleStatistic"
     * abis itu buat ganti-ganti jenis statistiknya lewat klik GUI.
     */
    public void addStatisticBoard(String id, String displayName) {
        String path = "boards." + id;
        configFile.get().set(path + ".display-name", displayName);
        configFile.get().set(path + ".icon", "PAPER");
        configFile.get().set(path + ".source", "STATISTIC");
        configFile.get().set(path + ".statistic", STATISTIC_PRESETS[0]);
        configFile.save();
        cache.put(id, new java.util.concurrent.ConcurrentHashMap<>());
    }

    public void removeBoard(String id) {
        configFile.get().set("boards." + id, null);
        configFile.save();
        cache.remove(id);
    }

    /**
     * Geser ke statistik berikutnya di daftar preset (dipanggil tiap
     * admin klik icon board di menu admin).
     */
    public String cycleStatistic(String id) {
        String current = configFile.get().getString("boards." + id + ".statistic", STATISTIC_PRESETS[0]);
        int index = 0;
        for (int i = 0; i < STATISTIC_PRESETS.length; i++) {
            if (STATISTIC_PRESETS[i].equals(current)) {
                index = (i + 1) % STATISTIC_PRESETS.length;
                break;
            }
        }
        String next = STATISTIC_PRESETS[index];
        configFile.get().set("boards." + id + ".statistic", next);
        configFile.get().set("boards." + id + ".source", "STATISTIC");
        configFile.save();
        return next;
    }
}
