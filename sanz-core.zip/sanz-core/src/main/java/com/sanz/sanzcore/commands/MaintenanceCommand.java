package com.sanz.sanzcore.commands;

import com.sanz.sanzcore.managers.MaintenanceManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

/**
 * /maintenance on           -> nyalain + KICK SEMUA player online yang
 *                               gak ada di whitelist / gak punya bypass
 * /maintenance off          -> matiin
 * /maintenance status       -> cek status
 * /maintenance whitelist add <player>
 * /maintenance whitelist remove <player>
 * /maintenance whitelist list
 */
public class MaintenanceCommand implements CommandExecutor {

    private final MaintenanceManager manager;

    public MaintenanceCommand(MaintenanceManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("sanzcore.maintenance.toggle")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /maintenance <on|off|status|whitelist>");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "on" -> {
                manager.setEnabled(true);
                int kicked = manager.kickAllExceptWhitelisted();
                sender.sendMessage(ChatColor.GREEN + "Mode maintenance diaktifkan. " +
                        ChatColor.YELLOW + kicked + ChatColor.GREEN + " player di-kick (yang whitelist/bypass tetap online).");
            }
            case "off" -> {
                manager.setEnabled(false);
                sender.sendMessage(ChatColor.GREEN + "Mode maintenance dimatikan. Semua orang bisa join lagi.");
            }
            case "status" -> {
                boolean enabled = manager.isEnabled();
                sender.sendMessage(ChatColor.GRAY + "Status maintenance: " +
                        (enabled ? ChatColor.RED + "AKTIF" : ChatColor.GREEN + "NONAKTIF"));
                sender.sendMessage(ChatColor.GRAY + "Whitelist: " + ChatColor.WHITE + String.join(", ", manager.getWhitelist()));
            }
            case "whitelist" -> handleWhitelist(sender, args);
            default -> sender.sendMessage(ChatColor.RED + "Gunakan: /maintenance <on|off|status|whitelist>");
        }
        return true;
    }

    private void handleWhitelist(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /maintenance whitelist <add|remove|list> [player]");
            return;
        }

        switch (args[1].toLowerCase()) {
            case "add" -> {
                if (args.length < 3) {
                    sender.sendMessage(ChatColor.RED + "Gunakan: /maintenance whitelist add <player>");
                    return;
                }
                boolean added = manager.addToWhitelist(args[2]);
                sender.sendMessage(added
                        ? ChatColor.GREEN + args[2] + " berhasil ditambahin ke whitelist maintenance."
                        : ChatColor.RED + args[2] + " udah ada di whitelist.");
            }
            case "remove" -> {
                if (args.length < 3) {
                    sender.sendMessage(ChatColor.RED + "Gunakan: /maintenance whitelist remove <player>");
                    return;
                }
                boolean removed = manager.removeFromWhitelist(args[2]);
                sender.sendMessage(removed
                        ? ChatColor.GREEN + args[2] + " berhasil dihapus dari whitelist."
                        : ChatColor.RED + args[2] + " gak ada di whitelist.");
            }
            case "list" -> sender.sendMessage(ChatColor.GRAY + "Whitelist maintenance: " +
                    ChatColor.WHITE + String.join(", ", manager.getWhitelist()));
            default -> sender.sendMessage(ChatColor.RED + "Gunakan: /maintenance whitelist <add|remove|list> [player]");
        }
    }
}
