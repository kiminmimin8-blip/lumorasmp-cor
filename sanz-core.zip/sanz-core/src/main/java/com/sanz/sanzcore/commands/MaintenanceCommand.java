package com.sanz.sanzcore.commands;

import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class MaintenanceCommand implements CommandExecutor {

    private final ConfigFile configFile;

    public MaintenanceCommand(ConfigFile configFile) {
        this.configFile = configFile;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("sanz.maintenance.toggle")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }

        var cfg = configFile.get();

        if (args.length == 0) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /maintenance <on|off|status>");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "on" -> {
                cfg.set("enabled", true);
                configFile.save();
                sender.sendMessage(ChatColor.GREEN + "Mode maintenance diaktifkan. " +
                        "Player tanpa izin bypass gak bisa join.");
            }
            case "off" -> {
                cfg.set("enabled", false);
                configFile.save();
                sender.sendMessage(ChatColor.GREEN + "Mode maintenance dimatikan.");
            }
            case "status" -> {
                boolean enabled = cfg.getBoolean("enabled", false);
                sender.sendMessage(ChatColor.GRAY + "Status maintenance: " +
                        (enabled ? ChatColor.RED + "AKTIF" : ChatColor.GREEN + "NONAKTIF"));
            }
            default -> sender.sendMessage(ChatColor.RED + "Gunakan: /maintenance <on|off|status>");
        }
        return true;
    }
}
