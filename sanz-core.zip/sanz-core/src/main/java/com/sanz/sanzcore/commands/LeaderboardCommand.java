package com.sanz.sanzcore.commands;

import com.sanz.sanzcore.gui.LeaderboardHubListener;
import com.sanz.sanzcore.managers.LeaderboardManager;
import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /leaderboard tanpa argumen -> buka GUI hub (pilih kategori).
 * /leaderboard <nama board> -> tetep bisa langsung liat versi chat/text
 * (buat non-GUI / konsol / dipanggil dari command block).
 */
public class LeaderboardCommand implements CommandExecutor {

    private final LeaderboardManager manager;
    private final ConfigFile configFile;

    public LeaderboardCommand(LeaderboardManager manager, ConfigFile configFile) {
        this.manager = manager;
        this.configFile = configFile;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("admin")) {
            if (!sender.hasPermission("lumora.leaderboard.admin")) {
                sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk ini.");
                return true;
            }
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
                return true;
            }
            com.sanz.sanzcore.gui.LeaderboardAdminListener.openAdmin(manager, player);
            return true;
        }

        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Gunakan: /leaderboard <nama board> (dari konsol wajib sebutkan board)");
                return true;
            }
            LeaderboardHubListener.openHub(manager, player);
            return true;
        }

        String boardName = args[0];
        if (!manager.boardExists(boardName)) {
            sender.sendMessage(ChatColor.RED + "Board '" + boardName + "' gak ditemukan.");
            return true;
        }

        int topCount = configFile.get().getInt("top-count", 10);
        var top = manager.getTop(boardName, Math.min(topCount, 20)); // versi chat dibatasin 20 biar gak spam

        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', manager.getDisplayName(boardName)));
        if (top.isEmpty()) {
            sender.sendMessage(ChatColor.GRAY + "Belum ada data.");
            return true;
        }

        int rank = 1;
        for (var entry : top) {
            sender.sendMessage(ChatColor.YELLOW + "#" + rank + " " + ChatColor.WHITE + entry.getKey() +
                    ChatColor.GRAY + " - " + ChatColor.GREEN + entry.getValue());
            rank++;
        }
        return true;
    }
}
