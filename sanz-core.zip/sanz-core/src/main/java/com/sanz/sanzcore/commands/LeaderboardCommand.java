package com.sanz.sanzcore.commands;

import com.sanz.sanzcore.managers.LeaderboardManager;
import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import java.util.List;
import java.util.Map;

public class LeaderboardCommand implements CommandExecutor {

    private final LeaderboardManager manager;
    private final ConfigFile configFile;

    public LeaderboardCommand(LeaderboardManager manager, ConfigFile configFile) {
        this.manager = manager;
        this.configFile = configFile;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /leaderboard <nama board>");
            return true;
        }

        String boardName = args[0];
        if (!manager.boardExists(boardName)) {
            sender.sendMessage(ChatColor.RED + "Board '" + boardName + "' gak ditemukan.");
            return true;
        }

        int topCount = configFile.get().getInt("top-count", 10);
        List<Map.Entry<String, Double>> top = manager.getTop(boardName, topCount);

        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', manager.getDisplayName(boardName)));
        if (top.isEmpty()) {
            sender.sendMessage(ChatColor.GRAY + "Belum ada data.");
            return true;
        }

        int rank = 1;
        for (Map.Entry<String, Double> entry : top) {
            sender.sendMessage(ChatColor.YELLOW + "#" + rank + " " + ChatColor.WHITE + entry.getKey() +
                    ChatColor.GRAY + " - " + ChatColor.GREEN + entry.getValue());
            rank++;
        }
        return true;
    }
}
