package com.sanz.sanzcore.commands;

import com.sanz.sanzcore.gui.RankShopListener;
import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RankShopCommand implements CommandExecutor {

    private final ConfigFile configFile;
    private final ConfigFile guiFile;

    public RankShopCommand(ConfigFile configFile, ConfigFile guiFile) {
        this.configFile = configFile;
        this.guiFile = guiFile;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (!player.hasPermission("sanzcore.rankshop.use")) {
            player.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk membuka RankShop.");
            return true;
        }
        RankShopListener.openShop(configFile, guiFile, player);
        return true;
    }
}
