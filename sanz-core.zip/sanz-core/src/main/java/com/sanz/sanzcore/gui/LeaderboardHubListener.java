package com.sanz.sanzcore.gui;

import com.sanz.sanzcore.managers.LeaderboardManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * /leaderboard tanpa argumen -> buka menu hub. Tiap kategori (Money,
 * Coin, Kill, Playtime, dst — dari leaderboard/config.yml) ditampilin
 * sebagai 1 item. Klik salah satu -> buka LeaderboardPageListener
 * yang isinya top 1-500 kategori itu.
 */
public class LeaderboardHubListener implements Listener {

    private final LeaderboardManager manager;

    public LeaderboardHubListener(LeaderboardManager manager) {
        this.manager = manager;
    }

    public static void openHub(LeaderboardManager manager, Player player) {
        LeaderboardHubHolder holder = new LeaderboardHubHolder();
        String title = ChatColor.translateAlternateColorCodes('&', "&8&lLeaderboard");
        Inventory inv = Bukkit.createInventory(holder, 27, title);
        holder.setInventory(inv);

        List<String> boards = manager.getBoardNames();
        int slot = 10;
        for (String boardName : boards) {
            if (slot > 16) break; // muat maksimal 7 kategori di 1 baris tengah

            Material icon = Material.matchMaterial(manager.getIcon(boardName));
            if (icon == null) icon = Material.PAPER;

            ItemStack item = new ItemStack(icon);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', manager.getDisplayName(boardName)));
                meta.setLore(List.of(ChatColor.GRAY + "Klik buat lihat top 500 - 1"));
                item.setItemMeta(meta);
            }
            inv.setItem(slot, item);
            slot++;
        }

        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof LeaderboardHubHolder)) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;

        String displayName = clicked.getItemMeta().getDisplayName();
        for (String boardName : manager.getBoardNames()) {
            String expected = ChatColor.translateAlternateColorCodes('&', manager.getDisplayName(boardName));
            if (expected.equals(displayName)) {
                LeaderboardPageListener.openPage(manager, player, boardName, 0);
                return;
            }
        }
    }
}
