package com.sanz.sanzcore.commands;

import com.sanz.sanzcore.SanzCorePlugin;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;

public class HomeCommand implements CommandExecutor {

    private static final String DEFAULT_HOME_NAME = "home";

    private final SanzCorePlugin plugin;

    public HomeCommand(SanzCorePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }

        if (!player.hasPermission("sanz.home.use")) {
            player.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk ini.");
            return true;
        }

        switch (label.toLowerCase()) {
            case "sethome" -> handleSetHome(player, args);
            case "home" -> handleHome(player, args);
            case "delhome" -> handleDelHome(player, args);
            case "homes" -> handleListHomes(player);
        }
        return true;
    }

    private void handleSetHome(Player player, String[] args) {
        String name = args.length > 0 ? args[0] : DEFAULT_HOME_NAME;
        var manager = plugin.getHomeManager();

        int currentCount = manager.getHomeNames(player.getUniqueId()).size();
        boolean alreadyExists = manager.hasHome(player.getUniqueId(), name);
        int maxHomes = manager.getMaxHomes(player);

        if (!alreadyExists && currentCount >= maxHomes) {
            player.sendMessage(ChatColor.RED + "Kamu udah punya " + maxHomes + " home (maksimal). " +
                    "Hapus salah satu pakai /delhome <nama> dulu.");
            return;
        }

        manager.setHome(player.getUniqueId(), name, player.getLocation());
        player.sendMessage(ChatColor.GREEN + "Home " + ChatColor.YELLOW + name +
                ChatColor.GREEN + " berhasil disimpan di posisi kamu sekarang.");
    }

    private void handleHome(Player player, String[] args) {
        String name = args.length > 0 ? args[0] : DEFAULT_HOME_NAME;
        var manager = plugin.getHomeManager();

        if (!manager.hasHome(player.getUniqueId(), name)) {
            player.sendMessage(ChatColor.RED + "Home " + ChatColor.YELLOW + name +
                    ChatColor.RED + " gak ditemukan. Cek /homes buat lihat daftar home kamu.");
            return;
        }

        Location home = manager.getHome(player.getUniqueId(), name);
        if (home == null || home.getWorld() == null) {
            player.sendMessage(ChatColor.RED + "Gagal teleport, world home ini gak ketemu (mungkin world dihapus).");
            return;
        }

        player.teleportAsync(home);
        player.sendMessage(ChatColor.GREEN + "Teleport ke home " + ChatColor.YELLOW + name + ChatColor.GREEN + "...");
    }

    private void handleDelHome(Player player, String[] args) {
        if (args.length == 0) {
            player.sendMessage(ChatColor.RED + "Gunakan: /delhome <nama>");
            return;
        }
        String name = args[0];
        boolean deleted = plugin.getHomeManager().deleteHome(player.getUniqueId(), name);
        if (deleted) {
            player.sendMessage(ChatColor.GREEN + "Home " + ChatColor.YELLOW + name +
                    ChatColor.GREEN + " berhasil dihapus.");
        } else {
            player.sendMessage(ChatColor.RED + "Home " + ChatColor.YELLOW + name + ChatColor.RED + " gak ditemukan.");
        }
    }

    private void handleListHomes(Player player) {
        List<String> homes = plugin.getHomeManager().getHomeNames(player.getUniqueId());
        int max = plugin.getHomeManager().getMaxHomes(player);

        if (homes.isEmpty()) {
            player.sendMessage(ChatColor.YELLOW + "Kamu belum punya home. Pakai /sethome <nama> buat bikin.");
            return;
        }

        player.sendMessage(ChatColor.GRAY + "Home kamu (" + homes.size() + "/" +
                (max == Integer.MAX_VALUE ? "∞" : max) + "): " + ChatColor.WHITE + String.join(", ", homes));
    }
}
