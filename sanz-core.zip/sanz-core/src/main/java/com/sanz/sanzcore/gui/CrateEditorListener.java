package com.sanz.sanzcore.gui;

import com.sanz.sanzcore.managers.CrateManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Editor GUI buat crate: /crate edit <nama>
 * - Klik kiri reward yang udah ada -> HAPUS reward itu.
 * - Klik slot "+ Tambah Reward" (item EMERALD di slot terakhir) sambil
 *   pegang item apapun di tangan -> nambah item itu jadi reward baru
 *   (weight default 10, tipe ITEM). Atur ulang weight-nya lewat
 *   /crate setweight <crate> <rewardId> <angka>.
 */
public class CrateEditorListener implements Listener {

    private static final int ADD_BUTTON_SLOT = 53;
    private static final int INFO_SLOT = 45;

    private final CrateManager manager;

    public CrateEditorListener(CrateManager manager) {
        this.manager = manager;
    }

    public static void openEditor(CrateManager manager, Player admin, String crateName) {
        CrateEditorHolder holder = new CrateEditorHolder(crateName);
        String title = ChatColor.translateAlternateColorCodes('&',
                "&8Edit Crate: &e" + manager.getDisplayName(crateName));
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        List<Map<?, ?>> rewards = manager.getRewards(crateName);
        int slot = 0;
        for (Map<?, ?> reward : rewards) {
            if (slot >= 45) break; // sisain baris terakhir buat tombol
            inv.setItem(slot, buildRewardIcon(reward));
            slot++;
        }

        // info panel
        ItemStack info = new ItemStack(Material.BOOK);
        ItemMeta infoMeta = info.getItemMeta();
        if (infoMeta != null) {
            infoMeta.setDisplayName(ChatColor.YELLOW + "Cara pakai");
            infoMeta.setLore(List.of(
                    ChatColor.GRAY + "Klik kiri reward = hapus",
                    ChatColor.GRAY + "Pegang item + klik tombol hijau",
                    ChatColor.GRAY + "= tambah reward baru",
                    ChatColor.GRAY + "Atur weight: /crate setweight"
            ));
            info.setItemMeta(infoMeta);
        }
        inv.setItem(INFO_SLOT, info);

        // tombol tambah
        ItemStack addButton = new ItemStack(Material.EMERALD);
        ItemMeta addMeta = addButton.getItemMeta();
        if (addMeta != null) {
            addMeta.setDisplayName(ChatColor.GREEN + "+ Tambah Reward");
            addMeta.setLore(List.of(ChatColor.GRAY + "Pegang item di tangan, lalu klik ini"));
            addButton.setItemMeta(addMeta);
        }
        inv.setItem(ADD_BUTTON_SLOT, addButton);

        admin.openInventory(inv);
    }

    private static ItemStack buildRewardIcon(Map<?, ?> reward) {
        String type = String.valueOf(reward.get("type"));
        Material material = Material.PAPER;

        if ("ITEM".equalsIgnoreCase(type)) {
            List<Map<String, Object>> items = (List<Map<String, Object>>) reward.get("items");
            if (items != null && !items.isEmpty()) {
                Material matched = Material.matchMaterial(String.valueOf(items.get(0).get("material")));
                if (matched != null) material = matched;
            }
        } else if ("COMMAND".equalsIgnoreCase(type)) {
            material = Material.COMMAND_BLOCK;
        }

        ItemStack icon = new ItemStack(material);
        ItemMeta meta = icon.getItemMeta();
        if (meta != null) {
            String displayName = ChatColor.translateAlternateColorCodes('&', String.valueOf(reward.get("display-name")));
            meta.setDisplayName(displayName);

            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + "ID: " + ChatColor.WHITE + reward.get("id"));
            lore.add(ChatColor.GRAY + "Weight: " + ChatColor.WHITE + reward.get("weight"));
            lore.add(ChatColor.GRAY + "Broadcast: " + ChatColor.WHITE + reward.get("broadcast"));
            lore.add("");
            lore.add(ChatColor.RED + "Klik kiri buat hapus");
            meta.setLore(lore);
            icon.setItemMeta(meta);
        }
        return icon;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof CrateEditorHolder holder)) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        String crateName = holder.getCrateName();
        int slot = event.getRawSlot();

        if (slot == ADD_BUTTON_SLOT) {
            ItemStack held = player.getInventory().getItemInMainHand();
            if (held.getType() == Material.AIR) {
                player.sendMessage(ChatColor.RED + "Pegang item di tangan dulu sebelum klik tombol tambah!");
                return;
            }
            String newId = manager.addItemReward(crateName, held.clone(), 10);
            player.sendMessage(ChatColor.GREEN + "Reward baru ditambahin! ID: " + ChatColor.YELLOW + newId +
                    ChatColor.GREEN + " (weight default 10, atur pakai /crate setweight " + crateName + " " + newId + " <angka>)");
            openEditor(manager, player, crateName); // refresh GUI
            return;
        }

        if (slot == INFO_SLOT || slot >= 45) return;

        List<Map<?, ?>> rewards = manager.getRewards(crateName);
        if (slot >= rewards.size()) return;

        if (event.getClick() == ClickType.LEFT) {
            Map<?, ?> reward = rewards.get(slot);
            String rewardId = String.valueOf(reward.get("id"));
            manager.removeReward(crateName, rewardId);
            player.sendMessage(ChatColor.RED + "Reward " + rewardId + " dihapus.");
            openEditor(manager, player, crateName); // refresh GUI
        }
    }
}
