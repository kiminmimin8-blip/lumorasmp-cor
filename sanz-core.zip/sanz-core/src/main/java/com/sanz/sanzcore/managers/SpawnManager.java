package com.sanz.sanzcore.managers;

import com.sanz.sanzcore.SanzCorePlugin;
import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public class SpawnManager {

    private final ConfigFile configFile;

    public SpawnManager(SanzCorePlugin plugin) {
        this.configFile = new ConfigFile(plugin, "spawn/config.yml");
    }

    public Location getSpawn() {
        var cfg = configFile.get();
        String worldName = cfg.getString("world", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            world = Bukkit.getWorlds().get(0); // fallback ke world pertama
        }
        double x = cfg.getDouble("x", 0.5);
        double y = cfg.getDouble("y", 100.0);
        double z = cfg.getDouble("z", 0.5);
        float yaw = (float) cfg.getDouble("yaw", 0.0);
        float pitch = (float) cfg.getDouble("pitch", 0.0);
        return new Location(world, x, y, z, yaw, pitch);
    }

    public void setSpawn(Location location) {
        var cfg = configFile.get();
        cfg.set("world", location.getWorld().getName());
        cfg.set("x", location.getX());
        cfg.set("y", location.getY());
        cfg.set("z", location.getZ());
        cfg.set("yaw", (double) location.getYaw());
        cfg.set("pitch", (double) location.getPitch());
        configFile.save();
    }
}
