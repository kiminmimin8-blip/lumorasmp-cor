package com.sanz.sanzcore.managers;

import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * Maintenance Mode dengan whitelist eksplisit (bukan cuma permission).
 * Player yang namanya udah didaftarin lewat /maintenance whitelist add
 * tetap bisa masuk & tetap online pas maintenance nyala, meskipun dia
 * bukan staff/OP.
 */
public class MaintenanceManager {

    private final ConfigFile configFile;

    public MaintenanceManager(ConfigFile configFile) {
        this.configFile = configFile;
    }

    public boolean isEnabled() {
        return configFile.get().getBoolean("enabled", false);
    }

    public void setEnabled(boolean enabled) {
        configFile.get().set("enabled", enabled);
        configFile.save();
    }

    public List<String> getWhitelist() {
        return configFile.get().getStringList("whitelist");
    }

    public boolean isWhitelisted(String playerName) {
        for (String name : getWhitelist()) {
            if (name.equalsIgnoreCase(playerName)) return true;
        }
        return false;
    }

    public boolean addToWhitelist(String playerName) {
        List<String> whitelist = new ArrayList<>(getWhitelist());
        if (isWhitelisted(playerName)) return false;
        whitelist.add(playerName);
        configFile.get().set("whitelist", whitelist);
        configFile.save();
        return true;
    }

    public boolean removeFromWhitelist(String playerName) {
        List<String> whitelist = new ArrayList<>(getWhitelist());
        boolean removed = whitelist.removeIf(name -> name.equalsIgnoreCase(playerName));
        if (removed) {
            configFile.get().set("whitelist", whitelist);
            configFile.save();
        }
        return removed;
    }

    /**
     * Boleh tetap online/masuk kalau: ada di whitelist ATAU punya
     * permission bypass.
     */
    public boolean canBypass(Player player) {
        return isWhitelisted(player.getName()) || player.hasPermission("lumora.maintenance.bypass");
    }

    /**
     * Dipanggil pas /maintenance on — kick SEMUA player yang lagi
     * online, KECUALI yang whitelist/punya permission bypass.
     */
    public int kickAllExceptWhitelisted() {
        String kickMsg = ChatColor.translateAlternateColorCodes('&',
                configFile.get().getString("kick-message-when-enabling",
                        configFile.get().getString("kick-message", "&cServer maintenance.")));

        int kicked = 0;
        for (Player player : new ArrayList<>(Bukkit.getOnlinePlayers())) {
            if (!canBypass(player)) {
                player.kickPlayer(kickMsg);
                kicked++;
            }
        }
        return kicked;
    }
}
