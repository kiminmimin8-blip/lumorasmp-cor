package com.sanz.sanzcore.managers;

import com.sanz.sanzcore.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.HashMap;
import java.util.Map;

/**
 * Fitur lanjutan modul Shop: instant sell ("/sell hand", "/sell all")
 * gaya EssentialsX. Harga jual diambil dari shop/gui.yml (item yang sama
 * dengan yang muncul di GUI /shop), jadi gak perlu config harga terpisah.
 */
public class SellManager {

    private final ConfigFile shopConfig;
    private final ConfigFile shopGui;

    public SellManager(ConfigFile shopConfig, ConfigFile shopGui) {
        this.shopConfig = shopConfig;
        this.shopGui = shopGui;
    }

    /**
     * Ambil peta Material -> sell-price dari shop/gui.yml. Item dengan
     * sell-price <= 0 (atau gak di-set) dianggap gak bisa dijual instant.
     */
    private Map<Material, Double> getSellPrices() {
        Map<Material, Double> prices = new HashMap<>();
        ConfigurationSection items = shopGui.get().getConfigurationSection("items");
        if (items == null) return prices;

        for (String key : items.getKeys(false)) {
            ConfigurationSection item = items.getConfigurationSection(key);
            if (item == null) continue;

            double sellPrice = item.getDouble("sell-price", 0);
            if (sellPrice <= 0) continue;

            Material material = Material.matchMaterial(item.getString("material", ""));
            if (material == null) continue;

            prices.put(material, sellPrice);
        }
        return prices;
    }

    /**
     * Jual 1 stack item yang lagi dipegang player (main hand).
     * Return pesan hasil (sukses/gagal) buat ditampilkan ke player.
     */
    public SellResult sellHand(Player player) {
        PlayerInventory inv = player.getInventory();
        ItemStack hand = inv.getItemInMainHand();
        if (hand == null || hand.getType() == Material.AIR) {
            return SellResult.failure("Tangan kamu kosong, gak ada yang bisa dijual.");
        }

        Map<Material, Double> prices = getSellPrices();
        Double pricePerItem = prices.get(hand.getType());
        if (pricePerItem == null) {
            return SellResult.failure("Item " + hand.getType().name() + " gak bisa dijual instant.");
        }

        int amount = hand.getAmount();
        double total = pricePerItem * amount;

        inv.setItemInMainHand(new ItemStack(Material.AIR));
        giveMoney(player, total);

        return SellResult.success(amount, total);
    }

    /**
     * Jual semua item yang bisa dijual di seluruh inventory player.
     */
    public SellResult sellAll(Player player) {
        Map<Material, Double> prices = getSellPrices();
        if (prices.isEmpty()) {
            return SellResult.failure("Belum ada item yang dikonfigurasi buat dijual instant.");
        }

        PlayerInventory inv = player.getInventory();
        int totalAmount = 0;
        double totalPrice = 0;

        ItemStack[] contents = inv.getStorageContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack stack = contents[i];
            if (stack == null || stack.getType() == Material.AIR) continue;

            Double pricePerItem = prices.get(stack.getType());
            if (pricePerItem == null) continue;

            totalAmount += stack.getAmount();
            totalPrice += pricePerItem * stack.getAmount();
            contents[i] = null;
        }
        inv.setStorageContents(contents);

        if (totalAmount == 0) {
            return SellResult.failure("Kamu gak punya item yang bisa dijual instant.");
        }

        giveMoney(player, totalPrice);
        return SellResult.success(totalAmount, totalPrice);
    }

    private void giveMoney(Player player, double amount) {
        String addTemplate = shopConfig.get().getString("add-command", "");
        if (addTemplate.isBlank()) return;

        String cmd = addTemplate.replace("%player%", player.getName())
                .replace("%amount%", String.valueOf((long) amount));
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
    }

    /**
     * Hasil operasi sell, biar command tinggal tampilin pesannya tanpa
     * perlu tau detail logic di manager ini.
     */
    public static class SellResult {
        public final boolean success;
        public final String message;
        public final int amount;
        public final double total;

        private SellResult(boolean success, String message, int amount, double total) {
            this.success = success;
            this.message = message;
            this.amount = amount;
            this.total = total;
        }

        public static SellResult success(int amount, double total) {
            return new SellResult(true, null, amount, total);
        }

        public static SellResult failure(String message) {
            return new SellResult(false, message, 0, 0);
        }
    }
}
