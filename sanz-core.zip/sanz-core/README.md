# SanzCore

Plugin inti gabungan buat Sanz SMP (Folia 1.21.11) — 16 modul.

## Struktur file — nested per fitur (kayak plugin resmi)
Tiap fitur punya FOLDER sendiri. Di dalamnya `config.yml` (setting/logic)
DIPISAH dari `gui.yml` (tampilan menu/item, khusus modul yang ada GUI-nya).
Folder data (userdata, snapshot) juga ditaruh DI DALAM folder fiturnya:

```
plugins/SanzCore/
├── spawn/
│   └── config.yml
├── home/
│   ├── config.yml        <- setting (max home dll)
│   └── userdata/         <- 1 file per player
│       ├── <uuid1>.yml
│       └── <uuid2>.yml
├── rtp/
│   └── config.yml
├── mobspawn/
│   └── config.yml
├── rankshop/
│   ├── config.yml        <- currency/logic
│   └── gui.yml            <- item, harga, slot, lore
├── joinmessages/
│   └── config.yml
├── motd/
│   └── config.yml
├── maintenance/
│   └── config.yml
├── clearlag/
│   └── config.yml
├── worlds/
│   └── config.yml
├── shop/
│   ├── config.yml
│   └── gui.yml
├── leaderboard/
│   └── config.yml
├── event/
│   └── config.yml
├── arena/
│   ├── config.yml
│   └── data/              <- snapshot block per arena
│       └── <nama>.snapshot
├── duel/
│   └── config.yml
└── billford/
    ├── config.yml
    └── gui.yml            <- daftar trade barter
```

Ini persis pola yang di screenshot Essentials kamu: folder per fitur,
isinya beberapa file beda fungsi (bukan cuma satu `config.yml`), plus
folder data (userdata/warps-equivalent) nempel di dalam folder fiturnya.

## ⚠️ CHANGELOG — fix dari hasil compile beneran (thanks Zhuvax!)
Zhuvax nyoba compile & jalanin di server Folia asli, nemu + benerin
beberapa bug nyata yang gak ketauan tanpa testing langsung:

1. **`EntityType.DROPPED_ITEM` → `EntityType.ITEM`** (ClearLagTask) —
   nama enum salah, bakal gagal compile.
2. **`Bukkit.getScheduler()` → `Bukkit.getGlobalRegionScheduler()`**
   (ClearLagTask, LeaderboardManager) — scheduler lama gak thread-aware
   di Folia.
3. **`entity.remove()` langsung → `entity.getScheduler().run(...)`**
   (ClearLagTask) — entity di Folia "dimiliki" region thread tertentu,
   gak boleh diutak-atik dari thread lain.
4. **RTP dibungkus `RegionScheduler.execute()`** (RtpCommand) — baca
   block di lokasi jauh dari player = beda region thread, harus
   dieksekusi di thread yang bener-bener punya region itu. Loop diganti
   jadi rekursif karena tiap attempt koordinatnya beda region.
5. **World create/unload dibungkus `GlobalRegionScheduler`** (WorldCommand).
6. **Import `PaperServerListPingEvent` dibenerin** ke
   `com.destroystokyo.paper.event.server` (MotdListener).

Ini fix yang BENERAN penting — bukan kosmetik. Kalau kamu nemu lebih
banyak lagi pas compile, kirim balik file yang udah di-fix, nanti aku
serap ke project utama kayak yang barusan.

## Modul lengkap (16)
1. Mob Spawn Radius — `/mobradius`
2. RankShop — `/rankshop`
3. Spawn — `/spawn`, `/setspawn`
4. Home — `/home`, `/sethome`, `/delhome`, `/homes`
5. RTP — `/rtp`
6. Join/Leave Message — otomatis
7. MOTD — otomatis
8. Maintenance Mode — `/maintenance <on|off|status>`
9. Clearlag — otomatis + `/clearlag`
10. Worlds (Multiverse-lite) — `/world`, `/worldadmin`
11. Shop — `/shop`
12. Leaderboard — `/leaderboard <board>`
13. Event — `/event [nama]`, `/setevent <nama>`
14. Arena Regen/Reset — `/arena <setpos1|setpos2|save|reset> <nama>`
15. Duel — `/duel <player>`, `/duel accept`, `/duel deny`
16. Billford — `/billford`
17. **Crates (Gacha)** — riset lengkap dari ExcellentCrates, fitur:
    - `/crate open <nama>` — buka pakai key (fisik/virtual)
    - `/crate edit <nama>` — **editor GUI in-game**, klik buat hapus reward,
      pegang item + klik tombol buat nambah reward baru
    - `/crate preview <nama>` — liat semua reward + **persen peluang**
      tanpa buka beneran (read-only)
    - `/crate setblock <nama>` — **link block di dunia** ke crate (gaya
      "Crate Blocks" ExcellentCrates) — klik kanan block itu buat buka
    - `/crate setweight`, `/crate list`, `/crate reload`
    - `/cratekey give <player> <crate> [jumlah]` — kasih key
    - **Virtual Keys** — set `virtual-keys: true` per crate di
      `crates/gui.yml` biar key gak bisa di-trade/drop/jual (disimpan
      sebagai angka di data player, bukan item)
    - **Reward Win Limits** — opsional `max-wins` (maks berapa kali reward
      itu bisa dimenangin) dan `cooldown-seconds` (jeda sebelum reward
      itu bisa keluar lagi) per reward

## Fitur ExcellentCrates yang SENGAJA belum termasuk
- **Holograms & Particle Effects** di atas crate block — butuh integrasi
  ke DecentHolograms (udah kepasang di server kamu), bisa nyusul.
- **Custom Openings** (animasi roulette) — reward sekarang langsung keluar
  instan, belum ada animasi buka peti.
- **Milestones** (reward buka N kali berturut-turut) — belum ada.
- **Custom item plugin support** (Nexo/ItemsAdder/Oraxen) — di luar
  scope, sama alasannya kayak ItemsAdder yang udah dibahas sebelumnya.

## Java Version
Project ini pakai **Java 21** (`maven.compiler.source/target`), sesuai
kebutuhan Paper 1.20.5+ / Folia 1.21.x terbaru.

## ⚠️ Plugin lama yang jadi DOUBLE — matiin/uninstall salah satu
| Modul | Plugin lama |
|---|---|
| Mob Spawn Radius | PerfToggleMobSpawning |
| RTP | CoderRTP |
| Spawn | DonutSpawn |
| Home | DonutHomes |
| Shop | DonutShop |
| Billford | DonutBillford |
| Clearlag | Clearlag.jar, ClearLagTimer.jar |
| Worlds | Multiverse-core (kalau cuma butuh list/tp) |
| Leaderboard | ajLeaderboards |

## Cara compile
```bash
mvn clean package
```

## Belum sempat dites/masih perlu dicek dev
- Sisa 10 modul lain (selain 5 yang barusan di-fix) belum pernah
  di-compile & dites langsung di server — mungkin masih ada bug nyata
  kayak yang di atas.
- ArenaManager reset block sync (bisa freeze server buat area gede).
- messages.yml belum dipisah dari config — semua pesan masih hardcode
  di kode Java (belum sempet, next kalau ada waktu).
