package com.sanz.duel.manager;

import com.sanz.duel.SanzDuel;
import com.sanz.duel.model.Arena;
import com.sanz.duel.util.ErrorLogger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.*;
import java.util.*;

public class ArenaManager {

    private final SanzDuel plugin;
    private final Map<String, Arena> arenas = new HashMap<>();
    private final File arenasFile;
    private final File backupRoot;

    public ArenaManager(SanzDuel plugin) {
        this.plugin = plugin;
        this.arenasFile = new File(plugin.getDataFolder(), "arenas.yml");
        this.backupRoot = new File(plugin.getDataFolder(), "world-backups");
        if (!backupRoot.exists()) backupRoot.mkdirs();
        load();
    }

    public Collection<Arena> getArenas() {
        return arenas.values();
    }

    public Arena getArena(String name) {
        return arenas.get(name.toLowerCase());
    }

    public void addArena(Arena arena) {
        arenas.put(arena.getName().toLowerCase(), arena);
    }

    public void removeArena(String name) {
        arenas.remove(name.toLowerCase());
        deleteRecursively(getBackupFolder(name).toPath());
    }

    /** Cari arena yang lagi kosong (gak dipake duel & gak lagi di-reset). */
    public Arena findFreeArena() {
        for (Arena arena : arenas.values()) {
            if (arena.isReady() && arena.getState() == Arena.State.AVAILABLE) {
                return arena;
            }
        }
        return null;
    }

    private File getBackupFolder(String arenaName) {
        return new File(backupRoot, arenaName.toLowerCase());
    }

    /**
     * Backup folder world arena ke world-backups/<nama>/. Dipanggil sekali
     * pas admin nge-save arena baru (world harus kondisi "bersih"/template
     * sebelum dipake duel pertama kali). Ini gantiin snapshot block lama —
     * satu-satunya cara reset sekarang adalah copy ulang folder ini balik
     * ke world aslinya, jadi PASTIKAN world sudah dalam kondisi yang mau
     * dijadiin patokan tiap reset sebelum jalanin /duelarena save.
     *
     * Copy file dijalanin async karena bisa banyak file & lumayan berat IO,
     * tapi world TIDAK di-unload di sini (beda dari pas reset) — cukup aman
     * selama gak ada yang lagi ngedit world itu bersamaan.
     */
    public void backupWorldFolder(Arena arena, Runnable onSuccess, java.util.function.Consumer<String> onError) throws IllegalStateException {
        World world = arena.getWorld();
        if (world == null) {
            throw new IllegalStateException("World '" + arena.getWorldName() + "' gak lagi ke-load.");
        }
        File worldFolder = world.getWorldFolder();
        File backupFolder = getBackupFolder(arena.getName());

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                deleteRecursively(backupFolder.toPath());
                copyWorldFolder(worldFolder.toPath(), backupFolder.toPath());
                Bukkit.getScheduler().runTask(plugin, onSuccess);
            } catch (IOException e) {
                String code = ErrorLogger.logError(plugin, "backup world buat arena '" + arena.getName()
                        + "' (world: " + arena.getWorldName() + ")", e);
                Bukkit.getScheduler().runTask(plugin, () -> onError.accept(
                        "Gagal backup world (kode: " + code + "). Kasih tau admin kode ini biar gampang dicek."));
            }
        });
    }

    public boolean hasBackup(Arena arena) {
        File backupFolder = getBackupFolder(arena.getName());
        return backupFolder.exists() && backupFolder.isDirectory() && backupFolder.list() != null
                && Objects.requireNonNull(backupFolder.list()).length > 0;
    }

    /**
     * Reset arena: unload world (tanpa save), copy ulang folder world dari
     * backup, terus load lagi world-nya. Ganti total dari cara lama
     * (restore block satu-satu per-tick) karena sekarang arena = 1 world
     * utuh, bukan region kecil di world bersama.
     *
     * Player yang masih nyangkut di world ini (harusnya gak ada, karena
     * endDuel udah teleport kedua duelist keluar duluan sebelum manggil
     * method ini) dikeluarin dulu ke world default server sebagai jaga-jaga,
     * biar unloadWorld gak gagal/nge-drop mereka ke limbo.
     */
    public void resetArenaWorld(Arena arena, Runnable onComplete) {
        World world = arena.getWorld();
        String worldName = arena.getWorldName();
        File backupFolder = getBackupFolder(arena.getName());

        if (!backupFolder.exists() || Objects.requireNonNull(backupFolder.list()).length == 0) {
            ErrorLogger.logIssue(plugin, "reset arena '" + arena.getName() + "'",
                    "Gak ada backup world (folder '" + backupFolder + "' kosong/gak ada), reset di-skip.");
            arena.setState(Arena.State.AVAILABLE);
            if (onComplete != null) onComplete.run();
            return;
        }

        arena.setState(Arena.State.RESETTING);

        if (world != null) {
            World fallback = Bukkit.getWorlds().get(0);
            for (Player p : world.getPlayers()) {
                p.teleport(fallback.getSpawnLocation());
                p.sendMessage(net.kyori.adventure.text.Component.text(
                        "Arena lagi di-reset, lu dipindah sementara.",
                        net.kyori.adventure.text.format.NamedTextColor.YELLOW));
            }
            boolean unloaded = Bukkit.unloadWorld(world, false);
            if (!unloaded) {
                String code = ErrorLogger.logIssue(plugin, "reset arena '" + arena.getName() + "'",
                        "Bukkit.unloadWorld('" + worldName + "') balikin false — kemungkinan masih ada entity/chunk yang nge-block unload.");
                plugin.getLogger().severe("[" + code + "] Arena '" + arena.getName() + "' GAGAL di-reset, dibiarin AVAILABLE tapi kondisi world mungkin masih bekas match sebelumnya — cek manual.");
                arena.setState(Arena.State.AVAILABLE);
                if (onComplete != null) onComplete.run();
                return;
            }
        }

        File worldFolder = new File(Bukkit.getWorldContainer(), worldName);

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            IOException error = null;
            try {
                deleteRecursively(worldFolder.toPath());
                copyWorldFolder(backupFolder.toPath(), worldFolder.toPath());
            } catch (IOException e) {
                error = e;
            }
            final IOException finalError = error;
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (finalError != null) {
                    String code = ErrorLogger.logError(plugin, "copy balik world '" + worldName
                            + "' pas reset arena '" + arena.getName() + "'", finalError);
                    plugin.getLogger().severe("[" + code + "] Arena '" + arena.getName()
                            + "' kemungkinan RUSAK/gak konsisten sekarang (world folder ke-hapus tapi copy balik gagal) — cek manual, mungkin perlu restore manual dari '" + backupFolder + "'.");
                    arena.setState(Arena.State.AVAILABLE);
                    if (onComplete != null) onComplete.run();
                    return;
                }
                World reloaded = Bukkit.createWorld(new WorldCreator(worldName));
                if (reloaded == null) {
                    ErrorLogger.logIssue(plugin, "reset arena '" + arena.getName() + "'",
                            "Bukkit.createWorld('" + worldName + "') balikin null abis file di-copy — world gagal ke-load ulang.");
                } else {
                    // Location lama nunjuk ke instance World yang udah di-unload —
                    // rebuild spawn1/spawn2 ke instance World yang baru biar gak stale.
                    rebindLocation(arena.getSpawn1(), reloaded).ifPresent(arena::setSpawn1);
                    rebindLocation(arena.getSpawn2(), reloaded).ifPresent(arena::setSpawn2);
                }
                arena.setState(Arena.State.AVAILABLE);
                if (onComplete != null) onComplete.run();
            });
        });
    }

    private Optional<Location> rebindLocation(Location old, World newWorld) {
        if (old == null) return Optional.empty();
        return Optional.of(new Location(newWorld, old.getX(), old.getY(), old.getZ(), old.getYaw(), old.getPitch()));
    }

    /**
     * Copy folder world tapi skip file yang lagi dipegang server / gak
     * perlu ikut ke-copy (session.lock bikin error kalau world lagi
     * ke-load pas backup, uid.dat mending biarin apa adanya).
     */
    private void copyWorldFolder(Path source, Path target) throws IOException {
        if (!Files.exists(source)) {
            throw new IOException("Folder sumber '" + source + "' gak ada.");
        }
        try {
            Files.walk(source).forEach(sourcePath -> {
                try {
                    if (sourcePath.getFileName() != null && sourcePath.getFileName().toString().equals("session.lock")) {
                        return;
                    }
                    Path targetPath = target.resolve(source.relativize(sourcePath));
                    if (Files.isDirectory(sourcePath)) {
                        Files.createDirectories(targetPath);
                    } else {
                        Files.createDirectories(targetPath.getParent());
                        Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
                    }
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            });
        } catch (UncheckedIOException e) {
            throw (IOException) e.getCause();
        }
    }

    private void deleteRecursively(Path path) {
        if (!Files.exists(path)) return;
        try {
            Files.walk(path)
                    .sorted(Comparator.reverseOrder())
                    .forEach(p -> {
                        try {
                            Files.delete(p);
                        } catch (IOException ignored) {
                            // File lagi dipake (mis. lock OS) — dilewatin, biasanya gak fatal buat sisa proses.
                        }
                    });
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal hapus folder '" + path + "': " + e.getMessage());
        }
    }

    public void load() {
        arenas.clear();
        if (!arenasFile.exists()) return;

        FileConfiguration config = YamlConfiguration.loadConfiguration(arenasFile);
        if (config.getConfigurationSection("arenas") == null) return;

        for (String name : config.getConfigurationSection("arenas").getKeys(false)) {
            String path = "arenas." + name + ".";
            String worldName = config.getString(path + "world");
            if (worldName == null) {
                plugin.getLogger().warning("Arena '" + name + "' gak punya world di config, di-skip.");
                continue;
            }
            if (Bukkit.getWorld(worldName) == null) {
                plugin.getLogger().warning("Arena '" + name + "' nunjuk ke world '" + worldName
                        + "' yang belum/gak ke-load, arena tetep didaftarin tapi gak bakal 'ready' sampe world-nya ada.");
            }

            Location spawn1 = null;
            Location spawn2 = null;
            World world = Bukkit.getWorld(worldName);
            if (world != null && config.contains(path + "spawn1")) {
                spawn1 = new Location(world,
                        config.getDouble(path + "spawn1.x"),
                        config.getDouble(path + "spawn1.y"),
                        config.getDouble(path + "spawn1.z"),
                        (float) config.getDouble(path + "spawn1.yaw"),
                        (float) config.getDouble(path + "spawn1.pitch"));
            }
            if (world != null && config.contains(path + "spawn2")) {
                spawn2 = new Location(world,
                        config.getDouble(path + "spawn2.x"),
                        config.getDouble(path + "spawn2.y"),
                        config.getDouble(path + "spawn2.z"),
                        (float) config.getDouble(path + "spawn2.yaw"),
                        (float) config.getDouble(path + "spawn2.pitch"));
            }

            Arena arena = new Arena(name, worldName, spawn1, spawn2);
            arenas.put(name.toLowerCase(), arena);
        }
    }

    public void save() {
        FileConfiguration config = new YamlConfiguration();
        for (Arena arena : arenas.values()) {
            String path = "arenas." + arena.getName() + ".";
            config.set(path + "world", arena.getWorldName());

            if (arena.getSpawn1() != null) {
                Location s1 = arena.getSpawn1();
                config.set(path + "spawn1.x", s1.getX());
                config.set(path + "spawn1.y", s1.getY());
                config.set(path + "spawn1.z", s1.getZ());
                config.set(path + "spawn1.yaw", s1.getYaw());
                config.set(path + "spawn1.pitch", s1.getPitch());
            }
            if (arena.getSpawn2() != null) {
                Location s2 = arena.getSpawn2();
                config.set(path + "spawn2.x", s2.getX());
                config.set(path + "spawn2.y", s2.getY());
                config.set(path + "spawn2.z", s2.getZ());
                config.set(path + "spawn2.yaw", s2.getYaw());
                config.set(path + "spawn2.pitch", s2.getPitch());
            }
        }
        try {
            config.save(arenasFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Gagal nyimpen arenas.yml: " + e.getMessage());
        }
    }
}
