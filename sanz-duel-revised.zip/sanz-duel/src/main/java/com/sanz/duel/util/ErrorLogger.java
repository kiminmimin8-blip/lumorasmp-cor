package com.sanz.duel.util;

import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Nyatet error ke file plugins/SanzDuel/logs/errors.log, terpisah dari
 * console log server yang cepet ke-scroll/ilang.
 *
 * Tiap error dikasih "kode insiden" pendek (mis. E-143022-7) yang juga
 * dikirim ke player yang kena dampaknya. Alurnya: member ngalamin
 * error -> lapor ke admin sambil nyebutin kode itu -> admin tinggal
 * cari kode itu di errors.log, ketemu detail lengkapnya (waktu,
 * konteks apa yang lagi dikerjain, stack trace) tanpa perlu nebak
 * dari cerita member doang.
 */
public final class ErrorLogger {

    private static final DateTimeFormatter FILE_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final DateTimeFormatter CODE_TIME = DateTimeFormatter.ofPattern("HHmmss");
    private static final AtomicInteger COUNTER = new AtomicInteger(0);

    private ErrorLogger() {}

    /**
     * @param context penjelasan singkat lagi ngapain pas error terjadi
     *                (mis. "reset arena 'arena1'", "startDuel p1=Steve p2=Alex")
     * @return kode insiden buat ditunjukin ke player/admin
     */
    public static String logError(Plugin plugin, String context, Throwable error) {
        String code = "E-" + LocalDateTime.now().format(CODE_TIME) + "-" + COUNTER.incrementAndGet();

        // Selalu print ke console juga biar kelihatan real-time pas admin lagi mantengin log server.
        plugin.getLogger().severe("[" + code + "] " + context + " -> " + error);

        File logFolder = new File(plugin.getDataFolder(), "logs");
        if (!logFolder.exists()) logFolder.mkdirs();
        File logFile = new File(logFolder, "errors.log");

        try (PrintWriter out = new PrintWriter(new FileWriter(logFile, true))) {
            out.println("==================================================");
            out.println("Kode insiden : " + code);
            out.println("Waktu        : " + LocalDateTime.now().format(FILE_TIME));
            out.println("Konteks      : " + context);
            out.println("Error        : " + error);

            StringWriter sw = new StringWriter();
            error.printStackTrace(new PrintWriter(sw));
            out.println("Stack trace  :");
            out.println(sw);
        } catch (IOException e) {
            plugin.getLogger().severe("Gagal nulis ke errors.log: " + e.getMessage());
        }

        return code;
    }

    /** Versi tanpa Throwable, buat kondisi gagal yang bukan exception (mis. hasil null/false yang gak diduga). */
    public static String logIssue(Plugin plugin, String context, String detail) {
        String code = "E-" + LocalDateTime.now().format(CODE_TIME) + "-" + COUNTER.incrementAndGet();

        plugin.getLogger().severe("[" + code + "] " + context + " -> " + detail);

        File logFolder = new File(plugin.getDataFolder(), "logs");
        if (!logFolder.exists()) logFolder.mkdirs();
        File logFile = new File(logFolder, "errors.log");

        try (PrintWriter out = new PrintWriter(new FileWriter(logFile, true))) {
            out.println("==================================================");
            out.println("Kode insiden : " + code);
            out.println("Waktu        : " + LocalDateTime.now().format(FILE_TIME));
            out.println("Konteks      : " + context);
            out.println("Detail       : " + detail);
        } catch (IOException e) {
            plugin.getLogger().severe("Gagal nulis ke errors.log: " + e.getMessage());
        }

        return code;
    }
}
