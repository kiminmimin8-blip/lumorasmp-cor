package com.sanz.duel.model;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

/**
 * Satu arena duel = satu world utuh (bukan region pos1/pos2 di dalem
 * world bersama). Reset arena dilakukan dengan copy ulang folder world
 * dari backup, bukan snapshot block satu-satu — lihat ArenaManager.
 *
 * World disimpen sebagai nama (String), bukan objek World langsung,
 * karena pas reset arena world-nya di-unload lalu di-load ulang —
 * objek World lama jadi basi (stale) begitu itu kejadian. getWorld()
 * selalu ambil instance terbaru dari Bukkit.
 */
public class Arena {

    public enum State {
        AVAILABLE,
        IN_USE,
        RESETTING
    }

    private final String name;
    private final String worldName;
    private Location spawn1;
    private Location spawn2;
    private State state = State.AVAILABLE;

    public Arena(String name, String worldName, Location spawn1, Location spawn2) {
        this.name = name;
        this.worldName = worldName;
        this.spawn1 = spawn1;
        this.spawn2 = spawn2;
    }

    public String getName() {
        return name;
    }

    public String getWorldName() {
        return worldName;
    }

    /** Bisa null kalau world lagi di-unload (mis. pas RESETTING). */
    public World getWorld() {
        return Bukkit.getWorld(worldName);
    }

    public Location getSpawn1() {
        return spawn1;
    }

    public void setSpawn1(Location spawn1) {
        this.spawn1 = spawn1;
    }

    public Location getSpawn2() {
        return spawn2;
    }

    public void setSpawn2(Location spawn2) {
        this.spawn2 = spawn2;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public boolean isReady() {
        return worldName != null && getWorld() != null && spawn1 != null && spawn2 != null;
    }

    /** Arena sekarang = seluruh world, jadi tinggal cek world-nya sama. */
    public boolean contains(Location loc) {
        World world = getWorld();
        return world != null && loc.getWorld() != null && loc.getWorld().equals(world);
    }
}
