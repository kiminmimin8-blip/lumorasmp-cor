package com.sanz.duel.command;

import com.sanz.duel.SanzDuel;
import com.sanz.duel.manager.ArenaManager;
import com.sanz.duel.model.Arena;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DuelArenaCommand implements CommandExecutor, TabCompleter {

    private final SanzDuel plugin;
    private final ArenaManager arenaManager;

    public DuelArenaCommand(SanzDuel plugin, ArenaManager arenaManager) {
        this.plugin = plugin;
        this.arenaManager = arenaManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }

        if (args.length < 1) {
            sendHelp(player);
            return true;
        }

        try {
            switch (args[0].toLowerCase()) {
                case "create" -> handleCreate(player, args);
                case "setspawn1" -> handleSetSpawn1(player);
                case "setspawn2" -> handleSetSpawn2(player);
                case "save" -> handleSave(player);
                case "list" -> handleList(player);
                case "delete" -> handleDelete(player, args);
                case "errors" -> handleErrors(player, args);
                default -> sendHelp(player);
            }
        } catch (Exception e) {
            String code = com.sanz.duel.util.ErrorLogger.logError(plugin, "command /duelarena " + String.join(" ", args)
                    + " (dari " + player.getName() + ")", e);
            player.sendMessage(Component.text("Ada error internal (kode: " + code + "). Laporin kode ini ke admin.", NamedTextColor.RED));
        }
        return true;
    }

    private void sendHelp(Player player) {
        player.sendMessage(Component.text("=== SanzDuel Arena Setup ===", NamedTextColor.GOLD));
        player.sendMessage(Component.text("/duelarena create <nama> <world>  - daftarin world yang udah ada jadi arena", NamedTextColor.YELLOW));
        player.sendMessage(Component.text("/duelarena setspawn1  - set titik spawn player 1 (posisi kamu sekarang)", NamedTextColor.YELLOW));
        player.sendMessage(Component.text("/duelarena setspawn2  - set titik spawn player 2 (posisi kamu sekarang)", NamedTextColor.YELLOW));
        player.sendMessage(Component.text("/duelarena save  - simpen arena + backup folder world buat reset nanti", NamedTextColor.YELLOW));
        player.sendMessage(Component.text("/duelarena list", NamedTextColor.YELLOW));
        player.sendMessage(Component.text("/duelarena delete <nama>", NamedTextColor.YELLOW));
        player.sendMessage(Component.text("/duelarena errors [jumlah]  - liat kode insiden error terbaru (default 5)", NamedTextColor.YELLOW));
        player.sendMessage(Component.text("Catatan: world yang dipake harus sudah dalam kondisi 'bersih' (siap dipake duel) sebelum /duelarena save, karena kondisi itu yang bakal jadi acuan tiap kali arena di-reset abis match.", NamedTextColor.GRAY));
    }

    private void handleCreate(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(Component.text("Pakai: /duelarena create <nama> <world>", NamedTextColor.RED));
            return;
        }
        String name = args[1];
        String worldName = args[2];

        if (arenaManager.getArena(name) != null) {
            player.sendMessage(Component.text("Arena '" + name + "' udah ada.", NamedTextColor.RED));
            return;
        }
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            player.sendMessage(Component.text("World '" + worldName + "' gak ketemu/belum ke-load.", NamedTextColor.RED));
            return;
        }

        SanzDuel.PendingArenaSetup setup = new SanzDuel.PendingArenaSetup();
        setup.name = name;
        setup.worldName = worldName;
        plugin.getPendingSetups().put(player.getUniqueId(), setup);

        player.sendMessage(Component.text("Mulai setup arena '" + name + "' di world '" + worldName
                + "'. Sekarang jalanin /duelarena setspawn1 dan /duelarena setspawn2 (harus di world itu), lalu /duelarena save.", NamedTextColor.GREEN));
    }

    private void handleSetSpawn1(Player player) {
        SanzDuel.PendingArenaSetup setup = plugin.getPendingSetups().get(player.getUniqueId());
        if (setup == null) {
            player.sendMessage(Component.text("Jalanin /duelarena create <nama> <world> dulu.", NamedTextColor.RED));
            return;
        }
        if (!player.getWorld().getName().equals(setup.worldName)) {
            player.sendMessage(Component.text("Lu harus ada di world '" + setup.worldName + "' buat set spawn ini.", NamedTextColor.RED));
            return;
        }
        setup.spawn1 = player.getLocation().clone();
        player.sendMessage(Component.text("Spawn 1 di-set ke " + fmt(setup.spawn1), NamedTextColor.GREEN));
    }

    private void handleSetSpawn2(Player player) {
        SanzDuel.PendingArenaSetup setup = plugin.getPendingSetups().get(player.getUniqueId());
        if (setup == null) {
            player.sendMessage(Component.text("Jalanin /duelarena create <nama> <world> dulu.", NamedTextColor.RED));
            return;
        }
        if (!player.getWorld().getName().equals(setup.worldName)) {
            player.sendMessage(Component.text("Lu harus ada di world '" + setup.worldName + "' buat set spawn ini.", NamedTextColor.RED));
            return;
        }
        setup.spawn2 = player.getLocation().clone();
        player.sendMessage(Component.text("Spawn 2 di-set ke " + fmt(setup.spawn2), NamedTextColor.GREEN));
    }

    private void handleSave(Player player) {
        SanzDuel.PendingArenaSetup setup = plugin.getPendingSetups().get(player.getUniqueId());
        if (setup == null) {
            player.sendMessage(Component.text("Jalanin /duelarena create <nama> <world> dulu.", NamedTextColor.RED));
            return;
        }
        if (setup.spawn1 == null || setup.spawn2 == null) {
            player.sendMessage(Component.text("Set setspawn1 dan setspawn2 dulu sebelum save.", NamedTextColor.RED));
            return;
        }

        Arena arena = new Arena(setup.name, setup.worldName, setup.spawn1, setup.spawn2);

        player.sendMessage(Component.text("Nge-backup world '" + setup.worldName + "', mohon tunggu (bisa makan waktu buat world gede)...", NamedTextColor.GRAY));

        try {
            arenaManager.backupWorldFolder(arena,
                    () -> {
                        arenaManager.addArena(arena);
                        arenaManager.save();
                        plugin.getPendingSetups().remove(player.getUniqueId());
                        player.sendMessage(Component.text("Arena '" + setup.name + "' berhasil disimpen.", NamedTextColor.GREEN));
                    },
                    error -> player.sendMessage(Component.text(error, NamedTextColor.RED)));
        } catch (IllegalStateException e) {
            String code = com.sanz.duel.util.ErrorLogger.logError(plugin, "save arena '" + setup.name + "'", e);
            player.sendMessage(Component.text("Gagal backup world (kode: " + code + "): " + e.getMessage(), NamedTextColor.RED));
        }
    }

    private void handleList(Player player) {
        if (arenaManager.getArenas().isEmpty()) {
            player.sendMessage(Component.text("Belum ada arena duel.", NamedTextColor.GRAY));
            return;
        }
        player.sendMessage(Component.text("=== Arena Duel ===", NamedTextColor.GOLD));
        for (Arena arena : arenaManager.getArenas()) {
            player.sendMessage(Component.text("- " + arena.getName() + " (world: " + arena.getWorldName()
                    + ", " + arena.getState() + ")", NamedTextColor.YELLOW));
        }
    }

    private void handleDelete(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(Component.text("Pakai: /duelarena delete <nama>", NamedTextColor.RED));
            return;
        }
        Arena arena = arenaManager.getArena(args[1]);
        if (arena == null) {
            player.sendMessage(Component.text("Arena '" + args[1] + "' gak ketemu.", NamedTextColor.RED));
            return;
        }
        arenaManager.removeArena(args[1]);
        arenaManager.save();
        player.sendMessage(Component.text("Arena '" + args[1] + "' dihapus (world aslinya TIDAK dihapus, cuma referensi & backup-nya).", NamedTextColor.GREEN));
    }

    /**
     * Tampilin ringkasan insiden terbaru dari logs/errors.log langsung
     * in-game, biar admin gak perlu buka file manual pas member baru
     * aja lapor "kok bug". Cuma nampilin kode+waktu+konteks (bukan
     * stack trace penuh, itu tetep di file kalau perlu didalemin).
     */
    private void handleErrors(Player player, String[] args) {
        int limit = 5;
        if (args.length >= 2) {
            try {
                limit = Math.max(1, Math.min(20, Integer.parseInt(args[1])));
            } catch (NumberFormatException ignored) {
                // biarin default 5 kalau argumennya bukan angka valid.
            }
        }

        java.io.File logFile = new java.io.File(plugin.getDataFolder(), "logs/errors.log");
        if (!logFile.exists()) {
            player.sendMessage(Component.text("Belum ada insiden error tercatat.", NamedTextColor.GRAY));
            return;
        }

        List<String> codes = new ArrayList<>();
        List<String> times = new ArrayList<>();
        List<String> contexts = new ArrayList<>();

        try (java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.FileReader(logFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Kode insiden : ")) codes.add(line.substring("Kode insiden : ".length()));
                else if (line.startsWith("Waktu        : ")) times.add(line.substring("Waktu        : ".length()));
                else if (line.startsWith("Konteks      : ")) contexts.add(line.substring("Konteks      : ".length()));
            }
        } catch (IOException e) {
            player.sendMessage(Component.text("Gagal baca errors.log: " + e.getMessage(), NamedTextColor.RED));
            return;
        }

        if (codes.isEmpty()) {
            player.sendMessage(Component.text("Belum ada insiden error tercatat.", NamedTextColor.GRAY));
            return;
        }

        player.sendMessage(Component.text("=== " + Math.min(limit, codes.size()) + " insiden error terbaru ===", NamedTextColor.GOLD));
        int start = Math.max(0, codes.size() - limit);
        for (int i = codes.size() - 1; i >= start; i--) {
            player.sendMessage(Component.text(codes.get(i) + " ", NamedTextColor.RED)
                    .append(Component.text("(" + (i < times.size() ? times.get(i) : "?") + ") ", NamedTextColor.GRAY))
                    .append(Component.text(i < contexts.size() ? contexts.get(i) : "", NamedTextColor.YELLOW)));
        }
        player.sendMessage(Component.text("Detail lengkap (stack trace) ada di plugins/SanzDuel/logs/errors.log", NamedTextColor.GRAY));
    }

    private String fmt(Location loc) {
        return loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ();
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> subcommands = List.of("create", "setspawn1", "setspawn2", "save", "list", "delete", "errors");
            String prefix = args[0].toLowerCase();
            return subcommands.stream()
                    .filter(s -> s.startsWith(prefix))
                    .collect(Collectors.toList());
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("delete")) {
            String prefix = args[1].toLowerCase();
            return arenaManager.getArenas().stream()
                    .map(Arena::getName)
                    .filter(name -> name.toLowerCase().startsWith(prefix))
                    .collect(Collectors.toList());
        }

        if (args.length == 3 && args[0].equalsIgnoreCase("create")) {
            String prefix = args[2].toLowerCase();
            return Bukkit.getWorlds().stream()
                    .map(World::getName)
                    .filter(name -> name.toLowerCase().startsWith(prefix))
                    .collect(Collectors.toList());
        }

        return new ArrayList<>();
    }
}
