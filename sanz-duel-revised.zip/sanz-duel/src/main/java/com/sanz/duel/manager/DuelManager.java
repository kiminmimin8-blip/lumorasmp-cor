package com.sanz.duel.manager;

import com.sanz.duel.SanzDuel;
import com.sanz.duel.model.ActiveDuel;
import com.sanz.duel.model.Arena;
import com.sanz.duel.model.DuelRequest;
import com.sanz.duel.model.PlayerSnapshot;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.UUID;

public class DuelManager {

    private final SanzDuel plugin;
    private final ArenaManager arenaManager;
    private final Map<UUID, DuelRequest> pendingRequests = new HashMap<>(); // key = target
    private final Map<UUID, ActiveDuel> activeDuels = new HashMap<>(); // key = participant uuid, both point to same ActiveDuel
    // LinkedHashSet biar urutan masuk antrian kepake pas matching FIFO.
    private final LinkedHashSet<UUID> randomQueue = new LinkedHashSet<>();
    private final File statsFile;
    private FileConfiguration statsConfig;

    public DuelManager(SanzDuel plugin, ArenaManager arenaManager) {
        this.plugin = plugin;
        this.arenaManager = arenaManager;
        this.statsFile = new File(plugin.getDataFolder(), "stats.yml");
        loadStats();
    }

    // ---------- Request handling ----------

    public void sendRequest(Player challenger, Player target) {
        long timeoutSeconds = plugin.getConfig().getLong("duel.request-timeout-seconds", 30);
        DuelRequest request = new DuelRequest(challenger.getUniqueId(), target.getUniqueId(),
                System.currentTimeMillis() + timeoutSeconds * 1000L);
        pendingRequests.put(target.getUniqueId(), request);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            DuelRequest current = pendingRequests.get(target.getUniqueId());
            if (current == request && current.isExpired()) {
                pendingRequests.remove(target.getUniqueId());
                Player c = Bukkit.getPlayer(challenger.getUniqueId());
                Player t = Bukkit.getPlayer(target.getUniqueId());
                if (c != null) c.sendMessage(Component.text("Tantangan duel ke " + target.getName() + " expired.", NamedTextColor.GRAY));
                if (t != null) t.sendMessage(Component.text("Tantangan duel dari " + challenger.getName() + " expired.", NamedTextColor.GRAY));
            }
        }, timeoutSeconds * 20L);
    }

    public DuelRequest getPendingRequest(UUID target) {
        DuelRequest request = pendingRequests.get(target);
        if (request != null && request.isExpired()) {
            pendingRequests.remove(target);
            return null;
        }
        return request;
    }

    public void clearRequest(UUID target) {
        pendingRequests.remove(target);
    }

    public boolean hasPendingRequestFrom(UUID challenger, UUID target) {
        DuelRequest request = getPendingRequest(target);
        return request != null && request.getChallenger().equals(challenger);
    }

    // ---------- Random matchmaking ----------

    public enum RandomQueueResult {
        JOINED, LEFT, ALREADY_IN_DUEL
    }

    /**
     * Toggle: player yang belum di antrian -> masuk antrian & langsung
     * dicoba di-match. Player yang udah di antrian -> keluar antrian.
     * Beda dari /duel <player>, di sini gak ada tahap accept/deny —
     * begitu dapet lawan, duel langsung mulai (umum di fitur "quick match"
     * plugin duel lain).
     */
    public RandomQueueResult toggleRandomQueue(Player player) {
        UUID uuid = player.getUniqueId();
        if (isInDuel(uuid)) {
            return RandomQueueResult.ALREADY_IN_DUEL;
        }
        if (randomQueue.contains(uuid)) {
            randomQueue.remove(uuid);
            return RandomQueueResult.LEFT;
        }
        randomQueue.add(uuid);
        tryMatchRandom();
        return RandomQueueResult.JOINED;
    }

    public boolean isInRandomQueue(UUID uuid) {
        return randomQueue.contains(uuid);
    }

    public void removeFromRandomQueue(UUID uuid) {
        randomQueue.remove(uuid);
    }

    /**
     * Coba jodohin 2 player pertama di antrian kalau ada arena kosong.
     * Dipanggil tiap ada player baru masuk antrian, dan tiap ada arena
     * yang baru selesai di-reset (lihat endDuel) — soalnya bisa aja
     * antriannya udah cukup dari sebelumnya tapi nunggu arena kosong.
     */
    public void tryMatchRandom() {
        if (randomQueue.size() < 2) return;
        if (arenaManager.findFreeArena() == null) return;

        Iterator<UUID> it = randomQueue.iterator();
        UUID u1 = it.next();
        it.remove();
        Player p1 = Bukkit.getPlayer(u1);
        if (p1 == null || !p1.isOnline()) {
            // Player pertama ternyata udah offline (belum sempet ke-cleanup di quit event), buang & coba lagi.
            tryMatchRandom();
            return;
        }

        if (!it.hasNext()) {
            // Cuma ada 1 orang valid, taruh lagi p1 biar nunggu lawan berikutnya.
            randomQueue.add(u1);
            return;
        }
        UUID u2 = it.next();
        it.remove();
        Player p2 = Bukkit.getPlayer(u2);
        if (p2 == null || !p2.isOnline()) {
            randomQueue.add(u1);
            tryMatchRandom();
            return;
        }

        boolean started = startDuel(p1, p2);
        if (started) {
            p1.sendMessage(Component.text("Ketemu lawan random: " + p2.getName() + "! Duel dimulai.", NamedTextColor.GOLD));
            p2.sendMessage(Component.text("Ketemu lawan random: " + p1.getName() + "! Duel dimulai.", NamedTextColor.GOLD));
        } else {
            // Arena keburu kepake pas kita proses, taruh lagi kedua-duanya buat dicoba match ulang nanti.
            randomQueue.add(u1);
            randomQueue.add(u2);
        }
    }

    // ---------- Active duel handling ----------

    public boolean isInDuel(UUID uuid) {
        return activeDuels.containsKey(uuid);
    }

    public ActiveDuel getActiveDuel(UUID uuid) {
        return activeDuels.get(uuid);
    }

    /** Mulai duel: cari arena kosong, simpen state kedua player, teleport ke spawn masing-masing. */
    public boolean startDuel(Player p1, Player p2) {
        Arena arena = arenaManager.findFreeArena();
        if (arena == null) {
            p1.sendMessage(Component.text("Gak ada arena duel yang lagi kosong, coba lagi bentar.", NamedTextColor.RED));
            p2.sendMessage(Component.text("Gak ada arena duel yang lagi kosong, coba lagi bentar.", NamedTextColor.RED));
            return false;
        }

        arena.setState(Arena.State.IN_USE);

        PlayerSnapshot snap1 = new PlayerSnapshot(p1);
        PlayerSnapshot snap2 = new PlayerSnapshot(p2);
        ActiveDuel duel = new ActiveDuel(p1, p2, arena, snap1, snap2);
        activeDuels.put(p1.getUniqueId(), duel);
        activeDuels.put(p2.getUniqueId(), duel);

        if (plugin.getConfig().getBoolean("duel.clear-inventory-on-start", false)) {
            p1.getInventory().clear();
            p2.getInventory().clear();
        }
        if (plugin.getConfig().getBoolean("duel.full-heal-on-start", true)) {
            for (Player p : new Player[]{p1, p2}) {
                double max = p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH) != null
                        ? p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue() : 20.0;
                p.setHealth(max);
                p.setFoodLevel(20);
                p.setSaturation(20f);
            }
        }

        p1.teleport(arena.getSpawn1());
        p2.teleport(arena.getSpawn2());

        return true;
    }

    /**
     * Selesaiin duel. winner boleh null kalau seri/dibatalin.
     * Balikin inventory & lokasi kedua player, terus jadwalin arena buat di-reset.
     */
    public void endDuel(ActiveDuel duel, UUID winner) {
        Player p1 = Bukkit.getPlayer(duel.getPlayer1());
        Player p2 = Bukkit.getPlayer(duel.getPlayer2());

        activeDuels.remove(duel.getPlayer1());
        activeDuels.remove(duel.getPlayer2());

        if (p1 != null) {
            duel.getSnapshot(p1.getUniqueId()).restore(p1);
        }
        if (p2 != null) {
            duel.getSnapshot(p2.getUniqueId()).restore(p2);
        }

        if (winner != null) {
            UUID loser = duel.getOpponent(winner);
            addWin(winner);
            addLoss(loser);

            String winnerName = Bukkit.getOfflinePlayer(winner).getName();
            String loserName = Bukkit.getOfflinePlayer(loser).getName();
            Bukkit.broadcast(Component.text(winnerName + " memenangkan duel melawan " + loserName + "!", NamedTextColor.GOLD));
        }

        Arena arena = duel.getArena();
        arenaManager.resetArenaWorld(arena, () -> {
            // Arena baru aja balik AVAILABLE — coba jodohin antrian random
            // yang mungkin lagi nunggu arena kosong.
            tryMatchRandom();
        });
    }

    // ---------- Stats ----------

    private void loadStats() {
        statsConfig = YamlConfiguration.loadConfiguration(statsFile);
    }

    private void saveStats() {
        try {
            statsConfig.save(statsFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Gagal nyimpen stats.yml: " + e.getMessage());
        }
    }

    private void addWin(UUID uuid) {
        int wins = statsConfig.getInt(uuid + ".wins", 0);
        statsConfig.set(uuid + ".wins", wins + 1);
        saveStats();
    }

    private void addLoss(UUID uuid) {
        int losses = statsConfig.getInt(uuid + ".losses", 0);
        statsConfig.set(uuid + ".losses", losses + 1);
        saveStats();
    }

    public int getWins(UUID uuid) {
        return statsConfig.getInt(uuid + ".wins", 0);
    }

    public int getLosses(UUID uuid) {
        return statsConfig.getInt(uuid + ".losses", 0);
    }

    public Map<String, Integer> getTopWins(int limit) {
        Map<String, Integer> result = new java.util.LinkedHashMap<>();
        if (statsConfig.getKeys(false).isEmpty()) return result;

        statsConfig.getKeys(false).stream()
                .map(key -> Map.entry(key, statsConfig.getInt(key + ".wins", 0)))
                .sorted((a, b) -> b.getValue() - a.getValue())
                .limit(limit)
                .forEach(entry -> {
                    String name = Bukkit.getOfflinePlayer(UUID.fromString(entry.getKey())).getName();
                    result.put(name != null ? name : entry.getKey(), entry.getValue());
                });
        return result;
    }
}
