# Revisi SanzDuel

## 1. `/duel random`
- Command baru: `/duel random` — toggle masuk/keluar antrian matchmaking.
- Begitu ada 2 orang di antrian DAN ada arena kosong, duel langsung mulai
  otomatis (tanpa tahap accept/deny, beda dari `/duel <player>`).
- Kalau lagi nunggu arena kosong (semua arena `IN_USE`/`RESETTING`), player
  tetap di antrian dan otomatis di-coba-match lagi begitu ada arena yang
  selesai di-reset abis duel lain kelar.
- Player yang disconnect otomatis kehapus dari antrian.
- Lihat `DuelManager.toggleRandomQueue()` / `tryMatchRandom()` dan
  `DuelCommand.handleRandom()`.

## 2. Arena gak pakai pos1/pos2 lagi, cukup world
Perubahan struktural:
- **Sebelum**: `/duelarena create <nama>` → `pos1` → `pos2` (region di dalem
  world bersama) → `setspawn1/2` → `save` (snapshot block satu-satu).
- **Sekarang**: `/duelarena create <nama> <world>` (langsung sebut nama world
  yang mau dipakai) → `setspawn1/2` → `save` (backup seluruh folder world).
- Arena sekarang = 1 world utuh, bukan region di world bersama. Reset arena
  dilakukan dengan unload world → copy ulang folder world dari backup →
  load ulang, bukan restore block satu-satu per-tick seperti sebelumnya.
- **Konsekuensi buat kalian**: siapkan 1 world terpisah per arena (misal lewat
  Multiverse atau `/mv create`), bangun arena-nya di situ sampai kondisi
  "siap dipakai", baru jalanin `/duelarena create <nama> <world>` lalu
  `save`. Kondisi world PAS `save` itulah yang jadi acuan tiap kali di-reset.
- Backup folder world disimpan di `plugins/SanzDuel/world-backups/<nama>/`.
  `arenas.yml` juga berubah format (field `min`/`max` lama hilang, cuma
  simpan `world` + `spawn1`/`spawn2`).

## 3. Logging error + kode insiden (biar jelas pas member lapor bug)
- Semua titik yang paling sering gagal (backup world, reset arena/copy
  folder, unload/reload world, command `/duel` & `/duelarena`, event
  death/quit yang manggil `endDuel`) sekarang dibungkus try-catch dan
  dicatat lewat `util/ErrorLogger`.
- Tiap error dapet **kode insiden** pendek (mis. `E-143022-7`) yang:
  - ditampilkan ke player yang kena dampaknya ("Ada error internal
    (kode: E-143022-7), laporin ke admin"),
  - dicatat lengkap (waktu, konteks lagi ngapain, stack trace) di
    `plugins/SanzDuel/logs/errors.log`.
- Jadi alurnya: member ngalamin bug -> screenshot/sebutin kode -> admin
  tinggal cari kode itu di `errors.log` atau pakai command baru
  `/duelarena errors [jumlah]` buat liat daftar insiden terbaru
  langsung in-game (kode, waktu, konteks singkat) tanpa buka file
  manual. Detail stack trace lengkap tetap di file kalau perlu
  didalemin lebih jauh.
- Konsekuensi kondisi arena yang mungkin "rusak" (mis. world folder
  kehapus tapi gagal ke-copy balik) juga dicatat jelas di log dengan
  saran manual apa yang perlu dicek — bukan cuma silent warning kayak
  sebelumnya.


- Belum ada guard "world sedang dipakai arena lain" saat `/duelarena create`
  — kalau 2 arena nunjuk ke world yang sama, hasilnya bakal aneh (dobel
  reset/reset saling tabrak). Idealnya command `create` cek dulu apakah
  world itu sudah dipakai arena lain.
- Proses reset (unload → copy folder → reload) belum ditest di server asli
  — perlu dicoba di server nyata dulu, terutama buat world yang gede (copy
  banyak file bisa makan waktu, walau sudah dijalankan async).
- Belum ada command buat lihat sendiri siapa aja yang lagi di antrian random
  (`/duel queue` misalnya) — sekarang cuma pesan personal pas join/keluar.
