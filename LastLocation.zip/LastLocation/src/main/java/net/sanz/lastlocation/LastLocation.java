package net.sanz.lastlocation;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * LastLocation — fixes "always spawns at world spawn on login" by saving the
 * player's exact position (world, x, y, z, yaw, pitch) on quit and forcing a
 * teleport back to it a couple of ticks after they join.
 *
 * The 2-tick delay is deliberate: it lets whatever OTHER plugin/gamerule is
 * currently teleporting the player to spawn on join run first, then this
 * plugin overrides it back to where they actually logged off. That's the
 * usual root cause of "kenapa selalu balik spawn pas login" — another
 * plugin (or a respawn/anchor gamerule) is firing on join and nothing was
 * restoring the real position afterward.
 */
public final class LastLocation extends JavaPlugin implements Listener {

    private NamespacedKey worldKey, xKey, yKey, zKey, yawKey, pitchKey, enabledKey;

    @Override
    public void onEnable() {
        worldKey = new NamespacedKey(this, "loc_world");
        xKey = new NamespacedKey(this, "loc_x");
        yKey = new NamespacedKey(this, "loc_y");
        zKey = new NamespacedKey(this, "loc_z");
        yawKey = new NamespacedKey(this, "loc_yaw");
        pitchKey = new NamespacedKey(this, "loc_pitch");
        enabledKey = new NamespacedKey(this, "enabled");

        getServer().getPluginManager().registerEvents(this, this);

        // Safety net: periodically snapshot everyone's position in case of a
        // crash/power-loss where PlayerQuitEvent never fires (every 5 min).
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                saveLocation(player, player.getLocation());
            }
        }, 20L * 60 * 5, 20L * 60 * 5);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        saveLocation(event.getPlayer(), event.getPlayer().getLocation());
    }

    // MONITOR so this runs after other plugins have already done their own
    // join-teleport logic; we then override it on the next tick.
    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        if (player.hasPermission("lastlocation.bypass")) return;

        PersistentDataContainer pdc = player.getPersistentDataContainer();
        Boolean enabled = pdc.get(enabledKey, PersistentDataType.BOOLEAN);
        if (enabled != null && !enabled) return; // player opted out

        Location loc = loadLocation(player);
        if (loc == null) return; // no saved location yet (first ever join)

        // Delay 2 ticks so we land after any other plugin's join-teleport.
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (player.isOnline()) {
                player.teleport(loc);
            }
        }, 2L);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }

        PersistentDataContainer pdc = player.getPersistentDataContainer();
        Boolean current = pdc.get(enabledKey, PersistentDataType.BOOLEAN);
        boolean newState = current != null && !current; // toggle, default was "on"
        pdc.set(enabledKey, PersistentDataType.BOOLEAN, newState);

        player.sendMessage(newState
                ? "§aLastLocation diaktifkan — kamu akan balik ke posisi terakhir saat login."
                : "§cLastLocation dinonaktifkan — kamu akan spawn normal saat login.");
        return true;
    }

    private void saveLocation(Player player, Location loc) {
        PersistentDataContainer pdc = player.getPersistentDataContainer();
        pdc.set(worldKey, PersistentDataType.STRING, loc.getWorld().getName());
        pdc.set(xKey, PersistentDataType.DOUBLE, loc.getX());
        pdc.set(yKey, PersistentDataType.DOUBLE, loc.getY());
        pdc.set(zKey, PersistentDataType.DOUBLE, loc.getZ());
        pdc.set(yawKey, PersistentDataType.FLOAT, loc.getYaw());
        pdc.set(pitchKey, PersistentDataType.FLOAT, loc.getPitch());
    }

    private Location loadLocation(Player player) {
        PersistentDataContainer pdc = player.getPersistentDataContainer();
        String worldName = pdc.get(worldKey, PersistentDataType.STRING);
        if (worldName == null) return null;

        World world = Bukkit.getWorld(worldName);
        if (world == null) return null; // world was deleted/renamed

        Double x = pdc.get(xKey, PersistentDataType.DOUBLE);
        Double y = pdc.get(yKey, PersistentDataType.DOUBLE);
        Double z = pdc.get(zKey, PersistentDataType.DOUBLE);
        Float yaw = pdc.get(yawKey, PersistentDataType.FLOAT);
        Float pitch = pdc.get(pitchKey, PersistentDataType.FLOAT);
        if (x == null || y == null || z == null) return null;

        return new Location(world, x, y, z, yaw != null ? yaw : 0f, pitch != null ? pitch : 0f);
    }
}
