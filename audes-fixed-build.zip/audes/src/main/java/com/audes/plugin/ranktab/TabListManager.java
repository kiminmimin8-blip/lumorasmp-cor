package com.audes.plugin.ranktab;

import com.audes.plugin.bedrock.BedrockPlayerDetector;
import com.audes.plugin.prefix.PrefixDefinition;
import com.audes.plugin.prefix.PrefixManager;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.List;
import java.util.logging.Logger;

/**
 * Mengatur urutan tampil player di tab list berdasarkan grouping rank
 * (config "rank-tab.group-order"), pakai scoreboard Team untuk sorting
 * (trik umum: nama team menentukan urutan alfabetis di tab list bawaan
 * Minecraft, jadi team di-prefix nomor urutan grup).
 *
 * Real-time update dipicu dari AudesRankChangeEvent (lihat
 * RankTabListener), bukan cuma dari periodic task — periodic task di
 * config cuma fallback/refresh berkala untuk jaga-jaga ada state yang
 * kelewat.
 *
 * Dev16: badge/logo rank (RankBadgeRegistry) di-prepend ke depan nama
 * lewat font custom (lihat RankBadgeDefinition) — SEBELUM prefix teks,
 * sesuai posisi "logo" di setup ItemsAdder lama tim. Di-skip total
 * untuk player Bedrock (BedrockPlayerDetector) karena font custom itu
 * hanya ada di resource pack Java yang tidak pernah dikirim ke mereka
 * (lihat javadoc RankBadgeDefinition) — tanpa skip ini mereka lihat
 * kotak tofu, bukan invisible/error, tapi tetap lebih rapi di-skip.
 */
public class TabListManager {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();
    private static final Key BADGE_FONT = Key.key("audes", "rank_badges");

    private final PrefixManager prefixManager;
    private final RankBadgeRegistry badgeRegistry;
    private final Logger logger;
    private List<String> groupOrder;
    private String format;

    public TabListManager(PrefixManager prefixManager, RankBadgeRegistry badgeRegistry, Logger logger) {
        this.prefixManager = prefixManager;
        this.badgeRegistry = badgeRegistry;
        this.logger = logger;
    }

    public void setGroupOrder(List<String> groupOrder) {
        this.groupOrder = groupOrder;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    /** Dipanggil saat player join atau rank-nya berubah. */
    public void updatePlayer(Player player) {
        String rank = prefixManager.getRank(player);
        int order = groupOrder == null ? 0 : Math.max(0, groupOrder.indexOf(rank));

        Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();
        String teamName = teamNameFor(order, rank);

        // Bersihkan player dari team lama (kalau rank-nya berubah)
        Team existing = board.getEntryTeam(player.getName());
        if (existing != null && !existing.getName().equals(teamName)) {
            existing.removeEntry(player.getName());
        }

        Team team = board.getTeam(teamName);
        if (team == null) {
            team = board.registerNewTeam(teamName);
        }
        if (!team.hasEntry(player.getName())) {
            team.addEntry(player.getName());
        }

        PrefixDefinition def = prefixManager.getDefinitionFor(player);
        if (def != null && def.showInTabList()) {
            String prefixLegacy = def.text();
            // Team.prefix() butuh Component; batasi panjang sesuai limit vanilla.
            team.prefix(LEGACY.deserialize(prefixLegacy));
        }

        Component listName = buildListName(player, def, rank);
        player.playerListName(listName);
    }

    private Component buildListName(Player player, PrefixDefinition def, String rank) {
        String prefixText = def != null ? def.text() : "";
        String rendered = (format != null ? format : "%prefix%%player_name%")
                .replace("%prefix%", prefixText)
                .replace("%player_name%", player.getName());
        Component nameComponent = LEGACY.deserialize(rendered);

        boolean isBedrock = BedrockPlayerDetector.isBedrockPlayer(player.getUniqueId(), logger);
        if (isBedrock || badgeRegistry == null) {
            return nameComponent;
        }

        return badgeRegistry.get(rank)
                .<Component>map(badge -> Component.text(badge.character()).font(BADGE_FONT)
                        .append(Component.text(" "))
                        .append(nameComponent))
                .orElse(nameComponent);
    }

    // Nama team dibatasi 16 char di banyak versi lama; di 1.21.x sudah
    // dilonggarkan tapi tetap kita jaga pendek untuk aman lintas versi.
    private String teamNameFor(int order, String rank) {
        String safeRank = rank.length() > 10 ? rank.substring(0, 10) : rank;
        return String.format("%02d_%s", order, safeRank);
    }

    public void removePlayer(Player player) {
        Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();
        Team team = board.getEntryTeam(player.getName());
        if (team != null) {
            team.removeEntry(player.getName());
        }
    }
}
