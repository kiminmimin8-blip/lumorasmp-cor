package com.sanz.exchange;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ItemExchange extends JavaPlugin implements CommandExecutor, TabCompleter, Listener {

    enum Reward { ITEM, COMMAND }

    enum Prompt { NAME, COMMAND }

    /**
     * input.amount = jumlah yang dibutuhkan per trade.
     * ITEM: pakai output. COMMAND: pakai name (tampilan) dan command (dijalankan console, %player%).
     */
    private record Trade(String id, ItemStack input, Reward reward, ItemStack output, String name, String command) {}

    static class Menu implements InventoryHolder {
        Inventory inv;
        final Map<Integer, String> slots = new HashMap<>();

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    static class TradeMenu extends Menu {}

    static class ListMenu extends Menu {}

    static class EditorMenu extends Menu {}

    /** Sesi edit satu trade oleh satu admin. Item di editor cuma contoh (ghost), nggak diambil dari player. */
    private static class Session {
        String id;
        Reward reward = Reward.ITEM;
        ItemStack input;
        ItemStack output;
        String name;
        String command;
        boolean existing;
        Prompt awaiting;
    }

    // slot editor (27)
    private static final int SLOT_INPUT = 10;
    private static final int SLOT_MODE = 13;
    private static final int SLOT_NAME = 15;
    private static final int SLOT_OUTPUT = 16; // mode ITEM: item hasil, mode COMMAND: tombol Set Command
    private static final int SLOT_BACK = 18;
    private static final int SLOT_DELETE = 24;
    private static final int SLOT_SAVE = 26;
    // slot list admin (54)
    private static final int LIST_TRADES = 45;
    private static final int SLOT_CREATE = 49;

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final Map<String, Trade> trades = new LinkedHashMap<>();
    private final Map<UUID, Session> sessions = new ConcurrentHashMap<>();
    private File dataFile;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadTrades();
        getServer().getPluginManager().registerEvents(this, this);
        PluginCommand cmd = getCommand("jb");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
    }

    // ---------- data ----------

    private void loadTrades() {
        trades.clear();
        dataFile = new File(getDataFolder(), "trades.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection section = data.getConfigurationSection("trades");
        if (section == null) return;
        for (String id : section.getKeys(false)) {
            ItemStack input = section.getItemStack(id + ".input");
            Reward reward;
            try {
                reward = Reward.valueOf(section.getString(id + ".reward", "ITEM").toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException ex) {
                getLogger().warning("Trade '" + id + "' punya reward salah, dilewati.");
                continue;
            }
            ItemStack output = section.getItemStack(id + ".output");
            String name = section.getString(id + ".name", id);
            String command = section.getString(id + ".command", "");

            boolean ok = input != null && !input.getType().isAir();
            if (reward == Reward.ITEM) ok = ok && output != null && !output.getType().isAir();
            else ok = ok && !command.isBlank();
            if (!ok) {
                getLogger().warning("Trade '" + id + "' rusak di trades.yml, dilewati.");
                continue;
            }
            trades.put(id, new Trade(id, input, reward, output, name, command));
        }
    }

    private void saveData() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            getLogger().severe("Gagal simpan trades.yml: " + e.getMessage());
        }
    }

    private String nextId() {
        int n = trades.size() + 1;
        while (trades.containsKey("trade" + n)) n++;
        return "trade" + n;
    }

    // ---------- text helpers ----------

    private void send(CommandSender to, String key, String... replace) {
        String msg = getConfig().getString("messages." + key, key);
        for (int i = 0; i + 1 < replace.length; i += 2) {
            msg = msg.replace(replace[i], replace[i + 1]);
        }
        to.sendMessage(MM.deserialize(getConfig().getString("messages.prefix", "") + msg));
    }

    private Component line(NamedTextColor color, String text) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    private Component nameComp(ItemStack s) {
        ItemMeta m = s.getItemMeta();
        if (m != null && m.hasDisplayName() && m.displayName() != null) return m.displayName();
        return Component.text(s.getType().name().toLowerCase(Locale.ROOT).replace('_', ' '));
    }

    private String plainName(ItemStack s) {
        return PlainTextComponentSerializer.plainText().serialize(nameComp(s));
    }

    private String needText(Trade t) {
        return t.input().getAmount() + "x " + plainName(t.input());
    }

    private String gotText(Trade t, int times) {
        return switch (t.reward()) {
            case ITEM -> (t.output().getAmount() * times) + "x " + plainName(t.output());
            case COMMAND -> MM.stripTags(t.name()) + (times > 1 ? " x" + times : "");
        };
    }

    private ItemStack named(Material m, NamedTextColor color, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(line(color, name));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (String x : lore) l.add(line(NamedTextColor.GRAY, x));
            meta.lore(l);
        }
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack filler() {
        return named(Material.GRAY_STAINED_GLASS_PANE, NamedTextColor.GRAY, " ");
    }

    // ---------- inventory helpers ----------

    private int count(Player p, ItemStack proto) {
        int n = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (s != null && s.isSimilar(proto)) n += s.getAmount();
        }
        return n;
    }

    private void take(Player p, ItemStack proto, int amount) {
        ItemStack[] contents = p.getInventory().getStorageContents();
        for (int i = 0; i < contents.length && amount > 0; i++) {
            ItemStack s = contents[i];
            if (s == null || !s.isSimilar(proto)) continue;
            int t = Math.min(amount, s.getAmount());
            amount -= t;
            if (s.getAmount() - t <= 0) {
                contents[i] = null;
            } else {
                s.setAmount(s.getAmount() - t);
            }
        }
        p.getInventory().setStorageContents(contents);
    }

    private void giveItem(Player p, ItemStack proto, int total) {
        int max = Math.max(1, proto.getMaxStackSize());
        while (total > 0) {
            ItemStack part = proto.clone();
            part.setAmount(Math.min(max, total));
            total -= part.getAmount();
            for (ItemStack left : p.getInventory().addItem(part).values()) {
                p.getWorld().dropItemNaturally(p.getLocation(), left);
            }
        }
    }

    // ---------- trading ----------

    private void doTrade(Player p, Trade t, int times) {
        int req = t.input().getAmount();
        int n = Math.min(times, count(p, t.input()) / req);
        if (n <= 0) {
            send(p, "not-enough", "%need%", needText(t));
            return;
        }

        take(p, t.input(), n * req);

        switch (t.reward()) {
            case ITEM -> giveItem(p, t.output(), t.output().getAmount() * n);
            case COMMAND -> {
                String cmd = t.command().replace("%player%", p.getName());
                for (int i = 0; i < n; i++) {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
                }
            }
        }
        send(p, "traded", "%times%", String.valueOf(n), "%got%", gotText(t, n));
    }

    // ---------- icons ----------

    private ItemStack iconWith(Trade t, List<Component> extra) {
        ItemStack icon;
        if (t.reward() == Reward.ITEM) {
            icon = t.output().clone();
            icon.setAmount(Math.min(icon.getAmount(), icon.getMaxStackSize()));
        } else {
            icon = new ItemStack(Material.PAPER);
        }

        ItemMeta meta = icon.getItemMeta();
        List<Component> lore = new ArrayList<>();
        if (t.reward() == Reward.ITEM) {
            List<Component> old = meta.lore();
            if (old != null) lore.addAll(old);
        } else {
            meta.displayName(MM.deserialize(t.name()).decoration(TextDecoration.ITALIC, false));
        }

        lore.add(Component.empty());
        lore.add(Component.text("Butuh: ", NamedTextColor.GRAY)
                .append(Component.text(t.input().getAmount() + "x ", NamedTextColor.WHITE))
                .append(nameComp(t.input()))
                .decoration(TextDecoration.ITALIC, false));
        lore.add(line(NamedTextColor.GRAY, "Dapat: " + gotText(t, 1)));
        lore.addAll(extra);
        meta.lore(lore);
        icon.setItemMeta(meta);
        return icon;
    }

    // ---------- player menu (/jb) ----------

    private void openMenu(Player p) {
        if (trades.isEmpty()) {
            send(p, "list-empty");
            return;
        }
        int shown = Math.min(trades.size(), 54);
        int size = Math.max(9, ((shown + 8) / 9) * 9);
        TradeMenu menu = new TradeMenu();
        menu.inv = Bukkit.createInventory(menu, size, MM.deserialize(getConfig().getString("menu-title", "<gold>Trade")));
        fillMenu(menu, p);
        p.openInventory(menu.inv);
    }

    private void fillMenu(TradeMenu menu, Player p) {
        menu.inv.clear();
        menu.slots.clear();
        int i = 0;
        for (Trade t : trades.values()) {
            if (i >= menu.inv.getSize()) break;
            int have = count(p, t.input());
            int req = t.input().getAmount();
            List<Component> extra = new ArrayList<>();
            extra.add(line(NamedTextColor.GRAY, "Kamu punya: " + have + " (bisa trade x" + (have / req) + ")"));
            extra.add(Component.empty());
            extra.add(line(NamedTextColor.YELLOW, "Klik: trade 1x"));
            extra.add(line(NamedTextColor.YELLOW, "Shift+klik: trade semua"));
            menu.inv.setItem(i, iconWith(t, extra));
            menu.slots.put(i, t.id());
            i++;
        }
    }

    // ---------- admin list (/jb edit) ----------

    private void openList(Player p) {
        ListMenu menu = new ListMenu();
        menu.inv = Bukkit.createInventory(menu, 54, MM.deserialize(getConfig().getString("list-title", "<gold>Edit Trade")));
        for (int i = LIST_TRADES; i < 54; i++) menu.inv.setItem(i, filler());

        int i = 0;
        for (Trade t : trades.values()) {
            if (i >= LIST_TRADES) break;
            List<Component> extra = new ArrayList<>();
            if (t.reward() == Reward.COMMAND) extra.add(line(NamedTextColor.DARK_GRAY, "Command: " + t.command()));
            extra.add(Component.empty());
            extra.add(line(NamedTextColor.YELLOW, "Klik: edit (" + t.id() + ")"));
            menu.inv.setItem(i, iconWith(t, extra));
            menu.slots.put(i, t.id());
            i++;
        }
        menu.inv.setItem(SLOT_CREATE, named(Material.LIME_DYE, NamedTextColor.GREEN, "Buat trade baru"));
        p.openInventory(menu.inv);
    }

    private void openListLater(Player p) {
        Bukkit.getScheduler().runTask(this, () -> openList(p));
    }

    private void handleListClick(InventoryClickEvent e, ListMenu menu, Inventory top) {
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!p.hasPermission("exchange.admin")) return;
        if (e.getClickedInventory() != top) return;

        int slot = e.getRawSlot();
        Session s = new Session();
        if (slot == SLOT_CREATE) {
            s.id = nextId();
        } else {
            Trade t = trades.get(menu.slots.get(slot));
            if (t == null) return;
            s.id = t.id();
            s.existing = true;
            s.reward = t.reward();
            s.input = t.input().clone();
            s.output = t.output() == null ? null : t.output().clone();
            s.name = t.name();
            s.command = t.command();
        }
        sessions.put(p.getUniqueId(), s);
        Bukkit.getScheduler().runTask(this, () -> openEditor(p, s));
    }

    // ---------- editor ----------

    private void openEditor(Player p, Session s) {
        EditorMenu menu = new EditorMenu();
        menu.inv = Bukkit.createInventory(menu, 27, Component.text("Edit trade: " + s.id));
        drawEditor(menu.inv, s);
        p.openInventory(menu.inv);
    }

    private void drawEditor(Inventory inv, Session s) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler());
        boolean itemMode = s.reward == Reward.ITEM;

        inv.setItem(1, named(Material.PAPER, NamedTextColor.WHITE, "Item syarat",
                "Klik slot di bawah sambil pegang item.", "Jumlah item = jumlah yang dibutuhkan."));
        inv.setItem(SLOT_INPUT, s.input);

        inv.setItem(SLOT_MODE, itemMode
                ? named(Material.CHEST, NamedTextColor.AQUA, "Hadiah: ITEM biasa", "Klik buat ganti ke COMMAND")
                : named(Material.GOLD_INGOT, NamedTextColor.YELLOW, "Hadiah: COMMAND (money dll)", "Klik buat ganti ke ITEM"));

        if (itemMode) {
            inv.setItem(7, named(Material.PAPER, NamedTextColor.WHITE, "Item hasil",
                    "Klik slot di bawah sambil pegang item."));
            inv.setItem(SLOT_OUTPUT, s.output);
        } else {
            String shownName = (s.name == null || s.name.isBlank()) ? "(belum diisi)" : MM.stripTags(s.name);
            String shownCmd = (s.command == null || s.command.isBlank()) ? "(belum diisi)" : s.command;
            inv.setItem(SLOT_NAME, named(Material.PAPER, NamedTextColor.WHITE, "Nama: " + shownName,
                    "Klik, lalu ketik nama di chat."));
            inv.setItem(SLOT_OUTPUT, named(Material.COMMAND_BLOCK, NamedTextColor.GOLD, "Set Command",
                    "Sekarang: " + shownCmd, "Klik, lalu ketik command tanpa /", "Pakai %player% untuk nama player."));
        }

        inv.setItem(SLOT_BACK, named(Material.ARROW, NamedTextColor.RED, "Kembali (tanpa simpan)"));
        if (s.existing) inv.setItem(SLOT_DELETE, named(Material.TNT, NamedTextColor.RED, "Hapus trade"));
        inv.setItem(SLOT_SAVE, named(Material.LIME_WOOL, NamedTextColor.GREEN, "Simpan"));
    }

    private void syncFromEditor(Inventory inv, Session s) {
        ItemStack in = inv.getItem(SLOT_INPUT);
        s.input = (in == null || in.getType().isAir()) ? null : in.clone();
        if (s.reward == Reward.ITEM) {
            ItemStack out = inv.getItem(SLOT_OUTPUT);
            s.output = (out == null || out.getType().isAir()) ? null : out.clone();
        }
    }

    private void closeLater(Player p) {
        Bukkit.getScheduler().runTask(this, p::closeInventory);
    }

    private void handleEditorClick(InventoryClickEvent e, Inventory top) {
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Session s = sessions.get(p.getUniqueId());
        if (s == null || e.getClickedInventory() == null) return;
        boolean itemMode = s.reward == Reward.ITEM;

        // Shift-klik item dari inventory player: jadikan contoh item syarat/hasil
        if (e.getClickedInventory() != top) {
            ItemStack cur = e.getCurrentItem();
            if (e.isShiftClick() && cur != null && !cur.getType().isAir()) {
                syncFromEditor(top, s);
                if (s.input == null || !itemMode) {
                    s.input = cur.clone();
                } else {
                    s.output = cur.clone();
                }
                drawEditor(top, s);
            }
            return;
        }

        int slot = e.getRawSlot();
        if (slot == SLOT_INPUT || (slot == SLOT_OUTPUT && itemMode)) {
            syncFromEditor(top, s);
            ItemStack cursor = e.getCursor();
            ItemStack val = (cursor == null || cursor.getType().isAir()) ? null : cursor.clone();
            if (slot == SLOT_INPUT) s.input = val; else s.output = val;
            drawEditor(top, s);
        } else if (slot == SLOT_MODE) {
            syncFromEditor(top, s);
            s.reward = itemMode ? Reward.COMMAND : Reward.ITEM;
            drawEditor(top, s);
        } else if (slot == SLOT_OUTPUT) { // mode COMMAND: Set Command
            syncFromEditor(top, s);
            s.awaiting = Prompt.COMMAND;
            send(p, "ask-command");
            closeLater(p);
        } else if (slot == SLOT_NAME && !itemMode) {
            syncFromEditor(top, s);
            s.awaiting = Prompt.NAME;
            send(p, "ask-name");
            closeLater(p);
        } else if (slot == SLOT_BACK) {
            sessions.remove(p.getUniqueId());
            openListLater(p);
        } else if (slot == SLOT_DELETE && s.existing) {
            trades.remove(s.id);
            data.set("trades." + s.id, null);
            saveData();
            sessions.remove(p.getUniqueId());
            send(p, "removed", "%id%", s.id);
            openListLater(p);
        } else if (slot == SLOT_SAVE) {
            syncFromEditor(top, s);
            if (s.input == null) { send(p, "edit-need-input"); return; }
            if (itemMode && s.output == null) { send(p, "edit-need-output"); return; }
            if (!itemMode && (s.name == null || s.name.isBlank())) { send(p, "edit-need-name"); return; }
            if (!itemMode && (s.command == null || s.command.isBlank())) { send(p, "edit-need-command"); return; }

            data.set("trades." + s.id, null);
            data.set("trades." + s.id + ".input", s.input);
            data.set("trades." + s.id + ".reward", s.reward.name());
            ItemStack out = null;
            if (itemMode) {
                out = s.output.clone();
                data.set("trades." + s.id + ".output", out);
            } else {
                data.set("trades." + s.id + ".name", s.name);
                data.set("trades." + s.id + ".command", s.command);
            }
            saveData();

            Trade t = new Trade(s.id, s.input.clone(), s.reward, out,
                    itemMode ? s.id : s.name, itemMode ? "" : s.command);
            trades.put(s.id, t);
            sessions.remove(p.getUniqueId());
            send(p, "saved", "%id%", s.id, "%need%", needText(t), "%got%", gotText(t, 1));
            openListLater(p);
        }
    }

    // ---------- events ----------

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        InventoryHolder holder = top.getHolder();
        if (holder instanceof EditorMenu) {
            handleEditorClick(e, top);
        } else if (holder instanceof ListMenu lm) {
            handleListClick(e, lm, top);
        } else if (holder instanceof TradeMenu menu) {
            e.setCancelled(true);
            if (!(e.getWhoClicked() instanceof Player p)) return;
            if (e.getClickedInventory() == null || e.getClickedInventory() != top) return;
            String id = menu.slots.get(e.getRawSlot());
            if (id == null) return;
            Trade t = trades.get(id);
            if (t == null) return;
            doTrade(p, t, e.isShiftClick() ? Integer.MAX_VALUE : 1);
            fillMenu(menu, p);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Menu) e.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof EditorMenu)) return;
        Session s = sessions.get(e.getPlayer().getUniqueId());
        if (s != null && s.awaiting == null) sessions.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        sessions.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        Session s = sessions.get(p.getUniqueId());
        if (s == null || s.awaiting == null) return;
        e.setCancelled(true);
        String text = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
        Bukkit.getScheduler().runTask(this, () -> {
            Session cur = sessions.get(p.getUniqueId());
            if (cur == null || cur.awaiting == null) return;
            Prompt prompt = cur.awaiting;
            cur.awaiting = null;
            if (!text.isEmpty() && !text.equalsIgnoreCase("cancel")) {
                if (prompt == Prompt.NAME) {
                    cur.name = text;
                } else {
                    cur.command = text.startsWith("/") ? text.substring(1) : text;
                }
            }
            openEditor(p, cur);
        });
    }

    // ---------- commands ----------

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "menu" : args[0].toLowerCase(Locale.ROOT);

        switch (sub) {
            case "menu" -> {
                if (!(sender instanceof Player p)) { send(sender, "players-only"); return true; }
                if (!p.hasPermission("exchange.use")) { send(p, "no-permission"); return true; }
                openMenu(p);
            }
            case "trade" -> {
                if (!(sender instanceof Player p)) { send(sender, "players-only"); return true; }
                if (!p.hasPermission("exchange.use")) { send(p, "no-permission"); return true; }
                if (args.length < 2) { send(p, "usage"); return true; }
                Trade t = trades.get(args[1]);
                if (t == null) { send(p, "unknown", "%id%", args[1]); return true; }
                int times = 1;
                if (args.length > 2) {
                    if (args[2].equalsIgnoreCase("all")) {
                        times = Integer.MAX_VALUE;
                    } else {
                        try {
                            times = Integer.parseInt(args[2]);
                        } catch (NumberFormatException ex) {
                            send(p, "bad-amount");
                            return true;
                        }
                        if (times < 1) { send(p, "bad-amount"); return true; }
                    }
                }
                doTrade(p, t, times);
            }
            case "list" -> {
                if (trades.isEmpty()) { send(sender, "list-empty"); return true; }
                send(sender, "list-header");
                for (Trade t : trades.values()) {
                    send(sender, "list-line", "%id%", t.id(), "%need%", needText(t), "%got%", gotText(t, 1));
                }
            }
            case "edit" -> {
                if (!sender.hasPermission("exchange.admin")) { send(sender, "no-permission"); return true; }
                if (!(sender instanceof Player p)) { send(sender, "players-only"); return true; }
                sessions.remove(p.getUniqueId());
                openList(p);
            }
            case "delete", "remove" -> {
                if (!sender.hasPermission("exchange.admin")) { send(sender, "no-permission"); return true; }
                if (args.length < 2) { send(sender, "usage"); return true; }
                if (trades.remove(args[1]) == null) { send(sender, "unknown", "%id%", args[1]); return true; }
                data.set("trades." + args[1], null);
                saveData();
                send(sender, "removed", "%id%", args[1]);
            }
            case "give", "giveinput" -> {
                if (!sender.hasPermission("exchange.admin")) { send(sender, "no-permission"); return true; }
                if (args.length < 2) { send(sender, "usage"); return true; }
                Trade t = trades.get(args[1]);
                if (t == null) { send(sender, "unknown", "%id%", args[1]); return true; }

                Player target;
                if (args.length > 2) {
                    target = Bukkit.getPlayerExact(args[2]);
                    if (target == null) { send(sender, "player-offline", "%player%", args[2]); return true; }
                } else if (sender instanceof Player sp) {
                    target = sp;
                } else {
                    send(sender, "players-only");
                    return true;
                }

                ItemStack proto;
                if (sub.equals("giveinput")) {
                    proto = t.input();
                } else {
                    if (t.reward() != Reward.ITEM) { send(sender, "give-no-item", "%id%", t.id()); return true; }
                    proto = t.output();
                }
                giveItem(target, proto, proto.getAmount());
                send(sender, "given", "%amount%", String.valueOf(proto.getAmount()),
                        "%item%", MM.escapeTags(plainName(proto)), "%player%", target.getName());
            }
            case "info" -> {
                if (!sender.hasPermission("exchange.admin")) { send(sender, "no-permission"); return true; }
                if (args.length < 2) { send(sender, "usage"); return true; }
                Trade t = trades.get(args[1]);
                if (t == null) { send(sender, "unknown", "%id%", args[1]); return true; }
                send(sender, "info-header", "%id%", t.id());
                send(sender, "info-line", "%key%", "Butuh", "%value%", MM.escapeTags(needText(t)));
                if (t.reward() == Reward.ITEM) {
                    send(sender, "info-line", "%key%", "Hadiah (item)", "%value%", MM.escapeTags(gotText(t, 1)));
                } else {
                    send(sender, "info-line", "%key%", "Nama", "%value%", MM.escapeTags(MM.stripTags(t.name())));
                    send(sender, "info-line", "%key%", "Command", "%value%", MM.escapeTags(t.command()));
                }
            }
            case "reload" -> {
                if (!sender.hasPermission("exchange.admin")) { send(sender, "no-permission"); return true; }
                reloadConfig();
                loadTrades();
                send(sender, "reloaded");
            }
            default -> send(sender, "usage");
        }
        return true;
    }

    private void suggest(List<String> out, Iterable<String> options, String typed) {
        String low = typed.toLowerCase(Locale.ROOT);
        for (String o : options) {
            if (o.toLowerCase(Locale.ROOT).startsWith(low)) out.add(o);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        boolean admin = sender.hasPermission("exchange.admin");

        if (args.length == 1) {
            List<String> subs = new ArrayList<>(List.of("menu", "trade", "list"));
            if (admin) subs.addAll(List.of("edit", "info", "delete", "remove", "give", "giveinput", "reload"));
            suggest(out, subs, args[0]);
            return out;
        }

        String a = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2) {
            boolean idCmd = a.equals("trade")
                    || (admin && List.of("info", "delete", "remove", "give", "giveinput").contains(a));
            if (idCmd) suggest(out, trades.keySet(), args[1]);
        } else if (args.length == 3) {
            if (a.equals("trade")) {
                suggest(out, List.of("all"), args[2]);
            } else if (admin && (a.equals("give") || a.equals("giveinput"))) {
                List<String> names = new ArrayList<>();
                for (Player pl : Bukkit.getOnlinePlayers()) names.add(pl.getName());
                suggest(out, names, args[2]);
            }
        }
        return out;
    }
}
