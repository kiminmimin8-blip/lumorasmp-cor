from PIL import Image, ImageDraw
import os as _os
_SCRIPT_DIR = _os.path.dirname(_os.path.abspath(__file__))
_CONTENTS_DIR = _os.path.normpath(_os.path.join(_SCRIPT_DIR, '..', '..', 'contents'))

img = Image.new("RGBA", (128, 128), (30, 30, 40, 255))
draw = ImageDraw.Draw(img)
draw.polygon([(64, 20), (108, 108), (20, 108)], fill=(120, 190, 255, 255), outline=(255, 255, 255, 255))
draw.rectangle([54, 78, 74, 90], fill=(30, 30, 40, 255))
img.save(_os.path.join(_CONTENTS_DIR, 'pack.png'))
print("pack.png selesai")
