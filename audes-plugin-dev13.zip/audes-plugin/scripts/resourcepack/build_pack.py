import json, os
from PIL import Image, ImageDraw
import os as _os
_SCRIPT_DIR = _os.path.dirname(_os.path.abspath(__file__))
_CONTENTS_DIR = _os.path.normpath(_os.path.join(_SCRIPT_DIR, '..', '..', 'contents'))

BASE = _os.path.join(_CONTENTS_DIR, 'assets', 'audes')

# (path_no_ext, parent_model, color, label_pixel_pattern)
items = [
    ("tools/pedang_petir", "minecraft:item/handheld", (120, 190, 255, 255)),
    ("blocks/batu_audes", "minecraft:item/generated", (150, 150, 150, 255)),
    ("blocks/bijih_audes", "minecraft:item/generated", (200, 120, 220, 255)),
    ("furniture/kursi_kayu", "minecraft:item/generated", (150, 100, 60, 255)),
    ("furniture/lampu_mati", "minecraft:item/generated", (90, 90, 90, 255)),
    ("furniture/lampu_nyala", "minecraft:item/generated", (255, 210, 90, 255)),
]

for path, parent, color in items:
    # 1. item model definition -> assets/audes/items/<path>.json
    item_def = {
        "model": {
            "type": "minecraft:model",
            "model": f"audes:item/{path}"
        }
    }
    item_def_path = os.path.join(BASE, "items", path + ".json")
    os.makedirs(os.path.dirname(item_def_path), exist_ok=True)
    with open(item_def_path, "w") as f:
        json.dump(item_def, f, indent=2)

    # 2. model json -> assets/audes/models/item/<path>.json
    model = {
        "parent": parent,
        "textures": {
            "layer0": f"audes:item/{path}"
        }
    }
    model_path = os.path.join(BASE, "models", "item", path + ".json")
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    with open(model_path, "w") as f:
        json.dump(model, f, indent=2)

    # 3. placeholder texture 16x16 -> assets/audes/textures/item/<path>.png
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # bentuk diamond sederhana biar keliatan bukan kotak polos & gampang dibedain per item
    draw.polygon([(8, 1), (14, 8), (8, 15), (2, 8)], fill=color, outline=(0, 0, 0, 255))
    tex_path = os.path.join(BASE, "textures", "item", path + ".png")
    os.makedirs(os.path.dirname(tex_path), exist_ok=True)
    img.save(tex_path)

print("item models & textures selesai:", len(items), "item")
