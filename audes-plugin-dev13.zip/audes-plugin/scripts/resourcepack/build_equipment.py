import json, os
from PIL import Image, ImageDraw
import os as _os
_SCRIPT_DIR = _os.path.dirname(_os.path.abspath(__file__))
_CONTENTS_DIR = _os.path.normpath(_os.path.join(_SCRIPT_DIR, '..', '..', 'contents'))

BASE = _os.path.join(_CONTENTS_DIR, 'assets', 'audes')

equip_path = "armor/zirah_petir"
equip_def = {
    "layers": {
        "humanoid": [
            {"texture": f"audes:{equip_path}"}
        ]
    }
}
equip_json_path = os.path.join(BASE, "equipment", equip_path + ".json")
os.makedirs(os.path.dirname(equip_json_path), exist_ok=True)
with open(equip_json_path, "w") as f:
    json.dump(equip_def, f, indent=2)

# Placeholder texture layer 64x32 (layout tradisional armor_layer_1.png)
img = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
draw = ImageDraw.Draw(img)
# Warnain area body+arm dasar biar keliatan solid warna biru (bukan checkerboard kosong)
draw.rectangle([16, 16, 31, 31], fill=(90, 160, 255, 255))  # body
draw.rectangle([40, 16, 47, 31], fill=(90, 160, 255, 255))  # arm kanan
draw.rectangle([32, 16, 39, 31], fill=(90, 160, 255, 255))  # arm kiri (overlap area umum)
tex_path = os.path.join(BASE, "textures", "entity", "equipment", equip_path + ".png")
os.makedirs(os.path.dirname(tex_path), exist_ok=True)
img.save(tex_path)

print("equipment model & texture selesai")
