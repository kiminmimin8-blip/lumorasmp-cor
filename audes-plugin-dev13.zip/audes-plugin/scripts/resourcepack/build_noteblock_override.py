import json, os
import os as _os
_SCRIPT_DIR = _os.path.dirname(_os.path.abspath(__file__))
_CONTENTS_DIR = _os.path.normpath(_os.path.join(_SCRIPT_DIR, '..', '..', 'contents'))

BASE = _os.path.join(_CONTENTS_DIR, 'assets')

# Mapping enum org.bukkit.Instrument -> nilai blockstate "instrument" asli
# di game (dikonfirmasi dari daftar instrument note_block vanilla).
# CUMA 16 instrument "melodic" yang dicakup di sini -- instrument
# berbasis kepala mob di atas note block (zombie/skeleton/creeper/dragon/
# wither_skeleton/piglin/custom_head) SENGAJA TIDAK di-generate karena
# butuh block di atas note block juga (skull), di luar cakupan pemakaian
# config.yml "instrument: PIANO" dkk yang ada sekarang.
BUKKIT_TO_BLOCKSTATE = {
    "PIANO": "harp",
    "BASS_DRUM": "basedrum",
    "SNARE_DRUM": "snare",
    "STICKS": "hat",
    "BASS_GUITAR": "bass",
    "FLUTE": "flute",
    "BELL": "bell",
    "GUITAR": "guitar",
    "CHIME": "chime",
    "XYLOPHONE": "xylophone",
    "IRON_XYLOPHONE": "iron_xylophone",
    "COW_BELL": "cow_bell",
    "DIDGERIDOO": "didgeridoo",
    "BIT": "bit",
    "BANJO": "banjo",
    "PLING": "pling",
}

# Block custom yang ADA di config.yml sekarang (instrument, note) -> block model key
CUSTOM_BLOCKS = {
    ("PIANO", 0): "audes:block/batu_audes",
    ("BELL", 12): "audes:block/bijih_audes",
}

variants = {}
for bukkit_name, blockstate_instrument in BUKKIT_TO_BLOCKSTATE.items():
    for note in range(25):
        for powered in ("false", "true"):
            key = f"instrument={blockstate_instrument},note={note},powered={powered}"
            custom_model = CUSTOM_BLOCKS.get((bukkit_name, note))
            model = custom_model if custom_model else "minecraft:block/note_block"
            variants[key] = {"model": model}

noteblock_override = {"variants": variants}
path = os.path.join(BASE, "minecraft", "blockstates", "note_block.json")
with open(path, "w") as f:
    json.dump(noteblock_override, f, indent=1)

print(f"note_block.json override selesai -- {len(variants)} variant ({len(CUSTOM_BLOCKS)} di-custom, sisanya fallback vanilla)")

# Block model (BUKAN item model) untuk tiap custom block -- pakai cube_all,
# texture-nya reuse file texture item yang sudah dibuat sebelumnya (tidak
# perlu duplikat PNG, cukup reference path yang sama).
BLOCK_MODELS = {
    "audes:block/batu_audes": "audes:item/blocks/batu_audes",
    "audes:block/bijih_audes": "audes:item/blocks/bijih_audes",
}
for model_key, texture_key in BLOCK_MODELS.items():
    ns, rel_path = model_key.split(":", 1)
    model_json = {
        "parent": "minecraft:block/cube_all",
        "textures": {"all": texture_key}
    }
    model_file = os.path.join(BASE, ns, "models", rel_path.replace("block/", "block/", 1) + ".json")
    os.makedirs(os.path.dirname(model_file), exist_ok=True)
    with open(model_file, "w") as f:
        json.dump(model_json, f, indent=2)

print("block model (cube_all) selesai:", len(BLOCK_MODELS))
