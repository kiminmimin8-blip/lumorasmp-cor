# STATUS-DEV13.md

Lanjutan dari STATUS-DEV12.md (sesi sebelumnya nutup limitasi GUI console).
Sesi ini ngerjain SEMUA sisa item di daftar-fitur-itemsadder.md yang masih
bisa dikerjakan, plus dokumentasi jujur soal yang gak bisa.

> **UPDATE**: modul ke-5, `hud/` (Custom HUD), sempat KELUPAAN di pass
> pertama sesi ini — baru ditambahin belakangan setelah user nanya
> "udah semua fitur kah". Lihat bagian di bawah.

## Modul baru yang selesai dibangun & ke-wiring penuh

1. **`emote/`** — custom emotes + "custom animated text effects".
   `/emote <id>`, teks ngambang di atas kepala, bisa animasi (cycling
   antar text-frames) buat efek rainbow/berkedip. Command TERPISAH dari
   `/audes` (dipakai player biasa, bukan admin tooling).

2. **`structure/`** — generalisasi "custom tree" + "custom surface
   decoration block" + "custom cave decoration block" jadi SATU konsep:
   multi-block placement (all-or-nothing) yang REUSE penuh sistem
   `custom-block` yang udah ada. Gak butuh kode breaking/hardness/loot
   table baru — begitu di-place, tiap block jadi custom block biasa.
   `/audes givestructure`. DEPENDS ke modul `custom-block` (harus
   didaftar setelah itu di AudesPlugin.java, sudah diurus).

3. **`vehicle/`** — custom vehicle. Mounting lewat Interaction+ItemDisplay
   (pola sama kayak furniture), drive-nya DISEDERHANAKAN (maju otomatis
   sesuai arah pandang, sneak = rem/turun) — BUKAN kontrol WASD penuh,
   karena itu butuh baca packet mentah (ProtocolLib) yang sengaja belum
   jadi dependency project ini. `/audes givevehicle`.

4. **`entity/`** — custom animated entities. Mob vanilla asli (AI/hitbox
   penuh) + ItemDisplay overlay yang di-sinkronin & dianimasikan lewat
   "pose cycling" (SATU task global buat semua entity aktif, bukan
   task per-entity). BUKAN engine animasi skeletal penuh (itu di luar
   jangkauan Bukkit API murni). `/audes givemobitem`.

5. **`hud/`** — Custom HUD (kategori UI/UX). Implementasi pakai BossBar
   (persisten di atas layar) & ActionBar bawaan Bukkit, SATU task global
   yang render ulang tiap HUD sesuai update-interval-ticks masing-masing.
   BUKAN pixel HUD custom font kayak ItemsAdder asli (project ini belum
   punya infra custom font di resource pack pipeline — itu keputusan
   besar terpisah kalau nanti mau dikejar). `/audes hud <id> [player]`
   buat toggle, plus opsi `auto-show-on-join` per HUD di config.

## Fitur yang di-extend (bukan modul baru)

5. **Resource pack manager + merger** — `ResourcePackGenerator` sekarang
   bisa gabung pack `.zip` eksternal dari `plugins/Audes/external-packs/`
   (aset Audes sendiri selalu menang kalau ada konflik path), plus
   versioning sederhana (file `.version` yang nge-counter tiap generate).

6. **Scripting minimal** — tag `[if_perm:<permission>]` ditambahkan ke
   parser command GUI (`GuiListener#dispatch`), bisa digabung dengan tag
   `[console]` yang udah ada dari Dev12. SENGAJA BUKAN bahasa scripting
   penuh (parser+interpreter custom itu proyek besar sendiri, di luar
   scope realistis) — ini cuma tag kondisional simpel di depan command.

## Yang SENGAJA TIDAK dikerjakan (bukan malas — teknis gak mungkin)

- **Custom liquid**: Bukkit API gak expose cara bikin fluid/tag baru
  tanpa masuk ke NMS berat (override FlowingFluid dsb, di luar API
  publik yang stabil antar-versi).
- **Colored fire**: warna api vanilla di-hardcode di render client,
  gak ada hook plugin server-side buat override itu tanpa resource
  pack shader-level yang bukan ranah plugin.
- **Resource pack protector (anti-ekstraksi)**: fundamental gak mungkin
  — client WAJIB bisa baca file mentah pack itu buat render teksturnya,
  jadi "melindungi" pack dari ekstraksi bertentangan langsung dengan
  cara kerja resource pack itu sendiri. Enkripsi/obfuscation apapun
  yang diterapkan HARUS bisa di-decrypt/dibaca ulang oleh client vanilla,
  yang berarti siapapun juga bisa.

## Belum di-compile (sama seperti semua sesi sebelumnya)

Sandbox ini gak ada akses internet buat Maven download `paper-api`.
Sudah dicek manual:
- Brace balance 87 file `.java` semua OK.
- `config.yml` & `plugin.yml` divalidasi pakai YAML parser, keduanya
  valid secara sintaks.
- API yang dipake (ItemDisplay, Interaction, Display.Billboard,
  Transformation, addPassenger/removePassenger, EntityDeathEvent,
  PlayerToggleSneakEvent, BossBar, Player#sendActionBar) semua API
  Paper 1.20.4+/1.21+ yang sudah dipakai konsisten di modul-modul
  sebelumnya (furniture, armor) — kecuali BossBar yang API-nya agak
  beda gaya (String legacy, bukan Adventure Component), sudah
  ditangani lewat ChatColor.translateAlternateColorCodes di HudManager.

**WAJIB `mvn clean package` di mesin ber-internet sebelum deploy**,
terutama modul `vehicle` dan `entity` yang paling baru & paling belum
pernah ditest — logic drive vehicle dan sinkronisasi entity animator
butuh testing manual di server nyata buat lihat behavior aslinya
(estimasi/asumsi timing/collision belum tentu persis sama kayak di
kepala pas nulis kode).

## Sisa prioritas berikutnya

1. Compile ulang + deploy test manual (blocker semua verifikasi).
2. Test manual KHUSUS modul vehicle (drive feel) dan entity (pose
   animasi + interaksi mob asli) di server nyata — dua modul paling
   beresiko ada gap kode-vs-kenyataan.
3. Ganti texture placeholder dengan aset final sebelum production
   (masih sama seperti status sebelumnya, belum berubah).
4. Kalau nanti tim BENERAN butuh vehicle dengan kontrol WASD penuh,
   itu keputusan sadar buat nambah dependency ProtocolLib — bukan
   sesuatu yang bisa ditambal dari sisi Bukkit API murni.
