package com.audes.plugin.structure;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class StructureRegistry {

    private final Plugin plugin;
    private final Map<String, StructureDefinition> structures = new LinkedHashMap<>();

    public StructureRegistry(Plugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig(ConfigurationSection structuresSection) {
        structures.clear();
        if (structuresSection == null) return;

        for (String id : structuresSection.getKeys(false)) {
            ConfigurationSection s = structuresSection.getConfigurationSection(id);
            if (s == null) continue;

            List<Map<?, ?>> rawBlocks = s.getMapList("blocks");
            if (rawBlocks.isEmpty()) {
                plugin.getLogger().warning("[Audes] Structure '" + id + "' tidak punya 'blocks', di-skip.");
                continue;
            }

            List<StructureDefinition.StructureBlockEntry> entries = new ArrayList<>();
            int index = 0;
            for (Map<?, ?> raw : rawBlocks) {
                index++;
                Object blockIdRaw = raw.get("block");
                if (blockIdRaw == null) {
                    plugin.getLogger().warning("[Audes] Structure '" + id + "' entri #" + index
                            + " tidak punya 'block' (id block yang dirujuk), entri di-skip.");
                    continue;
                }
                int dx = raw.get("dx") instanceof Number n ? n.intValue() : 0;
                int dy = raw.get("dy") instanceof Number n ? n.intValue() : 0;
                int dz = raw.get("dz") instanceof Number n ? n.intValue() : 0;
                entries.add(new StructureDefinition.StructureBlockEntry(dx, dy, dz, blockIdRaw.toString()));
            }

            if (entries.isEmpty()) continue;

            structures.put(id, new StructureDefinition(id, s.getString("display-name", id),
                    List.copyOf(entries), s.getString("place-sound", null)));
        }

        plugin.getLogger().info("[Audes] " + structures.size() + " structure (tree/decoration) termuat dari config.");
    }

    public Optional<StructureDefinition> get(String id) {
        return Optional.ofNullable(structures.get(id));
    }

    public Map<String, StructureDefinition> getAll() {
        return structures;
    }
}
