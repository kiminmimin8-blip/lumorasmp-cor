package com.audes.plugin.hud;

import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.Plugin;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public class HudRegistry {

    private final Plugin plugin;
    private final Map<String, HudDefinition> huds = new LinkedHashMap<>();

    public HudRegistry(Plugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig(ConfigurationSection section) {
        huds.clear();
        if (section == null) return;

        for (String id : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(id);
            if (s == null) continue;

            HudDefinition.Type type;
            try {
                type = HudDefinition.Type.valueOf(s.getString("type", "ACTIONBAR").toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("[Audes] HUD '" + id + "' type tidak valid (pakai BOSSBAR/ACTIONBAR), di-skip.");
                continue;
            }

            BarColor barColor;
            try {
                barColor = BarColor.valueOf(s.getString("bar-color", "WHITE").toUpperCase());
            } catch (IllegalArgumentException e) {
                barColor = BarColor.WHITE;
            }
            BarStyle barStyle;
            try {
                barStyle = BarStyle.valueOf(s.getString("bar-style", "SOLID").toUpperCase());
            } catch (IllegalArgumentException e) {
                barStyle = BarStyle.SOLID;
            }

            huds.put(id, new HudDefinition(
                    id, type,
                    s.getString("template", "&7HUD"),
                    Math.max(1, s.getInt("update-interval-ticks", 20)),
                    barColor, barStyle,
                    s.getBoolean("auto-show-on-join", false)
            ));
        }

        plugin.getLogger().info("[Audes] " + huds.size() + " custom HUD termuat dari config.");
    }

    public Optional<HudDefinition> get(String id) {
        return Optional.ofNullable(huds.get(id));
    }

    public Map<String, HudDefinition> getAll() {
        return huds;
    }
}
