package com.audes.plugin.entity;

import com.audes.plugin.resourcepack.ResourcePackManifest;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

public class EntitySpawnItemFactory {

    public static final String ENTITY_ID_KEY = "entity_id";

    private final Plugin plugin;
    private final NamespacedKey entityIdKey;
    private final ResourcePackManifest manifest;
    private final EntityAnimator animator;

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    public EntitySpawnItemFactory(Plugin plugin, ResourcePackManifest manifest, EntityAnimator animator) {
        this.plugin = plugin;
        this.entityIdKey = new NamespacedKey(plugin, ENTITY_ID_KEY);
        this.manifest = manifest;
        this.animator = animator;
    }

    /** Item "telur spawn" custom -- klik kanan ke block buat spawn entity ini, lihat EntitySpawnListener. */
    public ItemStack createSpawnItem(EntityDefinition def) {
        ItemStack item = new ItemStack(Material.ZOMBIE_SPAWN_EGG);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(LEGACY.deserialize("&d" + (def.customName() != null ? def.customName() : def.id()) + " &7(Spawn Item)"));
            meta.getPersistentDataContainer().set(entityIdKey, PersistentDataType.STRING, def.id());
            item.setItemMeta(meta);
        }
        return item;
    }

    public String getEntityId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(entityIdKey, PersistentDataType.STRING);
    }

    /**
     * Spawn mob dasar (invisible+silent, punya AI/hitbox vanilla penuh)
     * + ItemDisplay overlay visual, daftarkan pasangannya ke EntityAnimator
     * biar mulai di-animasikan/di-sinkronin dari tick berikutnya.
     */
    public void spawn(Location location, EntityDefinition def) {
        LivingEntity mob = (LivingEntity) location.getWorld().spawnEntity(location, def.baseEntityType());
        mob.setInvisible(true);
        mob.setSilent(true);
        mob.setRemoveWhenFarAway(false);
        if (def.customName() != null) {
            mob.customName(LEGACY.deserialize(def.customName()));
            mob.setCustomNameVisible(true);
        }
        mob.getPersistentDataContainer().set(entityIdKey, PersistentDataType.STRING, def.id());

        ItemDisplay display = location.getWorld().spawn(location, ItemDisplay.class, entity -> {
            ItemStack visual = new ItemStack(def.displayMaterial());
            ItemMeta meta = visual.getItemMeta();
            if (meta != null) {
                applyModelIfAvailable(meta, def.modelKey());
                visual.setItemMeta(meta);
            }
            entity.setItemStack(visual);
            entity.setTransformation(new Transformation(
                    new Vector3f(0f, 0f, 0f),
                    new AxisAngle4f(0f, 0f, 0f, 1f),
                    new Vector3f(def.scale(), def.scale(), def.scale()),
                    new AxisAngle4f(0f, 0f, 0f, 1f)
            ));
            entity.getPersistentDataContainer().set(entityIdKey, PersistentDataType.STRING, def.id());
        });

        animator.register(mob.getUniqueId(), display.getUniqueId(), def);
    }

    private void applyModelIfAvailable(ItemMeta meta, String modelKey) {
        if (modelKey == null || modelKey.isBlank()) return;
        if (!manifest.hasModel(modelKey)) {
            manifest.warnMissingOnce(modelKey, "entity (EntitySpawnItemFactory)");
            return;
        }
        NamespacedKey key = NamespacedKey.fromString(modelKey);
        if (key == null) {
            plugin.getLogger().warning("[Audes] modelKey '" + modelKey + "' di entity bukan format valid, di-skip.");
            return;
        }
        meta.setItemModel(key);
    }

    public NamespacedKey entityIdKey() {
        return entityIdKey;
    }
}
