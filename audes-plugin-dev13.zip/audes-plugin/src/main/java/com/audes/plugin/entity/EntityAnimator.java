package com.audes.plugin.entity;

import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * SATU task global (bukan 1 task per entity kayak drive vehicle) yang
 * tiap tick nyinkronin posisi tiap ItemDisplay overlay ke mob dasarnya
 * + majuin pose animasi. Dipilih pola ini (bukan per-entity task)
 * supaya kalau nanti ada puluhan custom mob aktif bareng, overhead-nya
 * cuma 1 scheduler task, bukan puluhan.
 */
public class EntityAnimator {

    private record Tracked(UUID baseMobUuid, UUID displayUuid, EntityDefinition def, float baseScale) {
    }

    private final Plugin plugin;
    private final Map<UUID, Tracked> tracked = new HashMap<>(); // key = baseMobUuid
    private final Map<UUID, Integer> poseIndex = new HashMap<>();
    private final Map<UUID, Integer> poseTicksLeft = new HashMap<>();
    private BukkitTask task;

    public EntityAnimator(Plugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tickAll, 1L, 1L);
    }

    public void stop() {
        if (task != null) task.cancel();
        // Bersihin sisa display yang masih nempel supaya gak jadi entity "hantu" abis modul di-disable/plugin reload.
        for (Tracked t : tracked.values()) {
            Entity display = Bukkit.getEntity(t.displayUuid());
            if (display != null) display.remove();
        }
        tracked.clear();
        poseIndex.clear();
        poseTicksLeft.clear();
    }

    public void register(UUID baseMobUuid, UUID displayUuid, EntityDefinition def) {
        tracked.put(baseMobUuid, new Tracked(baseMobUuid, displayUuid, def, def.scale()));
        poseIndex.put(baseMobUuid, 0);
        poseTicksLeft.put(baseMobUuid, def.poses().get(0).durationTicks());
    }

    /** Dipanggil listener saat mob dasar mati/hilang, supaya display overlay-nya ikut dibersihkan. */
    public void unregister(UUID baseMobUuid) {
        Tracked t = tracked.remove(baseMobUuid);
        poseIndex.remove(baseMobUuid);
        poseTicksLeft.remove(baseMobUuid);
        if (t != null) {
            Entity display = Bukkit.getEntity(t.displayUuid());
            if (display != null) display.remove();
        }
    }

    private void tickAll() {
        Iterator<Map.Entry<UUID, Tracked>> it = tracked.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Tracked> entry = it.next();
            UUID baseMobUuid = entry.getKey();
            Tracked t = entry.getValue();

            Entity baseMob = Bukkit.getEntity(baseMobUuid);
            Entity displayEntity = Bukkit.getEntity(t.displayUuid());

            if (!(baseMob instanceof LivingEntity mob) || mob.isDead() || displayEntity == null) {
                if (displayEntity != null) displayEntity.remove();
                it.remove();
                poseIndex.remove(baseMobUuid);
                poseTicksLeft.remove(baseMobUuid);
                continue;
            }

            ItemDisplay display = (ItemDisplay) displayEntity;
            EntityDefinition def = t.def();

            int idx = poseIndex.getOrDefault(baseMobUuid, 0);
            int ticksLeft = poseTicksLeft.getOrDefault(baseMobUuid, 1) - 1;
            if (ticksLeft <= 0) {
                idx = (idx + 1) % def.poses().size();
                ticksLeft = def.poses().get(idx).durationTicks();
            }
            poseIndex.put(baseMobUuid, idx);
            poseTicksLeft.put(baseMobUuid, ticksLeft);

            EntityDefinition.Pose pose = def.poses().get(idx);

            display.teleport(mob.getLocation().clone().add(0, pose.offsetY(), 0));
            display.setTransformation(new Transformation(
                    new Vector3f(0f, 0f, 0f),
                    new AxisAngle4f((float) Math.toRadians(pose.yawDegrees()), 0f, 1f, 0f),
                    new Vector3f(t.baseScale(), t.baseScale(), t.baseScale()),
                    new AxisAngle4f(0f, 0f, 0f, 1f)
            ));
        }
    }
}
