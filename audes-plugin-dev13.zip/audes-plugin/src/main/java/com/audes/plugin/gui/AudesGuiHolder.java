package com.audes.plugin.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/**
 * InventoryHolder custom supaya GuiListener bisa tahu "inventory yang
 * baru diklik ini GUI Audes yang mana" cukup lewat
 * event.getInventory().getHolder(), TANPA perlu Map&lt;UUID, String&gt;
 * eksternal buat tracking "player mana lagi buka GUI apa" (yang rawan
 * jadi data basi kalau lupa dibersihkan pas quit/close).
 */
public class AudesGuiHolder implements InventoryHolder {

    private final String guiId;
    private Inventory inventory;

    public AudesGuiHolder(String guiId) {
        this.guiId = guiId;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public String getGuiId() {
        return guiId;
    }
}
