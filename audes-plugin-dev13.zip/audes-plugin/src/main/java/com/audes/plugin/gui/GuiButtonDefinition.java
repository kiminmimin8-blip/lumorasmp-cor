package com.audes.plugin.gui;

import org.bukkit.Material;

import java.util.List;

/**
 * Satu tombol di dalam custom GUI. "commands" DEFAULT dijalankan SEBAGAI
 * PLAYER (bukan console) lewat Bukkit.dispatchCommand(player, ...) saat
 * tombol diklik -- token "%player%" di tiap command otomatis diganti nama
 * player yang klik.
 *
 * KEAMANAN: default player (bukan console/OP), jadi tombol GUI tidak
 * otomatis jadi celah privilege-escalation (player biasa tetap kena
 * permission check normal untuk command yang dijalankan).
 *
 * OPT-IN run-as-console PER BARIS: awali baris command dengan
 * "[console] " (lihat GuiListener#dispatch) untuk menjalankan baris itu
 * spesifik sebagai console -- misal:
 *   commands:
 *     - "[console] give %player% diamond 1"
 *     - "tell %player% Kamu dapat diamond!"
 * Baris pertama jalan sebagai console (elevated), baris kedua tetap
 * sebagai player. Ini keputusan sadar admin yang isi config.yml, BUKAN
 * default yang dipaksakan modul ini -- pakai seperlunya, dan sadari
 * baris yang ditandai "[console]" bisa dipicu SIAPA SAJA yang bisa buka
 * GUI ini (atur permission buka GUI-nya kalau isinya ada command
 * ber-privilege tinggi).
 */
public record GuiButtonDefinition(
        int slot,
        Material material,
        String displayName,
        List<String> lore,
        List<String> commands,
        boolean closeOnClick
) {
}
