package com.audes.plugin.emote;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * /emote <id> — command terpisah dari /audes (bukan /audes emote ...)
 * karena ini dipakai PLAYER BIASA sehari-hari (bukan admin tooling kayak
 * give/setrank/gui), jadi lebih wajar punya command pendek sendiri.
 */
public class EmoteCommand implements CommandExecutor, TabCompleter {

    private final EmoteModule module;

    public EmoteCommand(EmoteModule module) {
        this.module = module;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cCommand ini cuma bisa dipakai in-game.");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage("§cPakai: /emote <id>. Lihat config.yml bagian 'emotes' buat daftar id yang ada.");
            return true;
        }

        var defOpt = module.getRegistry().get(args[0]);
        if (defOpt.isEmpty()) {
            sender.sendMessage("§cEmote '" + args[0] + "' tidak ditemukan.");
            return true;
        }

        EmotePlayer.PlayResult result = module.getPlayer().play(player, defOpt.get());
        if (result == EmotePlayer.PlayResult.ON_COOLDOWN) {
            sender.sendMessage("§cEmote itu masih cooldown, tunggu sebentar.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return new ArrayList<>(module.getRegistry().getAll().keySet());
        }
        return List.of();
    }
}
