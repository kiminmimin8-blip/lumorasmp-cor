package com.audes.plugin.emote;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;

public class EmoteModule implements AudesModule {

    private final AudesPlugin plugin;
    private EmoteRegistry registry;
    private EmotePlayer player;

    public EmoteModule(AudesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getName() {
        return "emote";
    }

    @Override
    public void enable() {
        registry = new EmoteRegistry();
        registry.loadFromConfig(plugin.getConfig().getConfigurationSection("emotes"));
        player = new EmotePlayer(plugin);
    }

    @Override
    public void disable() {
        // Task cycling per-emote self-cancel begitu durationTicks abis atau player logout,
        // jadi tidak ada listener/task jangka panjang yang perlu dilepas manual di sini.
    }

    public EmoteRegistry getRegistry() {
        return registry;
    }

    public EmotePlayer getPlayer() {
        return player;
    }
}
