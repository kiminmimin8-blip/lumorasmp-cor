package com.audes.plugin.vehicle;

import com.audes.plugin.resourcepack.ResourcePackManifest;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

/**
 * Sama teknik dengan FurnitureItemFactory (ItemDisplay visual + Interaction
 * hitbox), tapi ItemDisplay-nya jadi entity yang DINAIKI (lewat
 * addPassenger saat player klik Interaction-nya) alih-alih statis diam
 * di tempat — lihat VehicleListener untuk mount/drive logic.
 */
public class VehicleItemFactory {

    public static final String VEHICLE_ID_KEY = "vehicle_id";
    private static final String LINK_KEY = "vehicle_link";

    private final Plugin plugin;
    private final NamespacedKey vehicleIdKey;
    private final NamespacedKey linkKey;
    private final ResourcePackManifest manifest;

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    public VehicleItemFactory(Plugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.vehicleIdKey = new NamespacedKey(plugin, VEHICLE_ID_KEY);
        this.linkKey = new NamespacedKey(plugin, LINK_KEY);
        this.manifest = manifest;
    }

    public ItemStack create(VehicleDefinition def) {
        ItemStack item = new ItemStack(def.displayMaterial());
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(LEGACY.deserialize(def.displayName()));
            meta.getPersistentDataContainer().set(vehicleIdKey, PersistentDataType.STRING, def.id());
            applyModelIfAvailable(meta, def.modelKey());
            item.setItemMeta(meta);
        }
        return item;
    }

    private void applyModelIfAvailable(ItemMeta meta, String modelKey) {
        if (modelKey == null || modelKey.isBlank()) return;
        if (!manifest.hasModel(modelKey)) {
            manifest.warnMissingOnce(modelKey, "vehicle (VehicleItemFactory)");
            return;
        }
        NamespacedKey key = NamespacedKey.fromString(modelKey);
        if (key == null) {
            plugin.getLogger().warning("[Audes] modelKey '" + modelKey + "' di vehicle bukan format valid, di-skip.");
            return;
        }
        meta.setItemModel(key);
    }

    public String getVehicleId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(vehicleIdKey, PersistentDataType.STRING);
    }

    /** Spawn ItemDisplay (visual + carrier passenger) + Interaction (hitbox mount/break). */
    public ItemDisplay spawn(Location location, VehicleDefinition def) {
        ItemDisplay display = location.getWorld().spawn(location, ItemDisplay.class, entity -> {
            entity.setItemStack(create(def));
            entity.setTransformation(new Transformation(
                    new Vector3f(0f, 0f, 0f),
                    new AxisAngle4f(0f, 0f, 0f, 1f),
                    new Vector3f(def.scale(), def.scale(), def.scale()),
                    new AxisAngle4f(0f, 0f, 0f, 1f)
            ));
            entity.getPersistentDataContainer().set(vehicleIdKey, PersistentDataType.STRING, def.id());
        });

        Interaction interaction = location.getWorld().spawn(location, Interaction.class, entity -> {
            entity.setInteractionWidth(1.0f);
            entity.setInteractionHeight(1.0f);
            entity.setResponsive(true);
            entity.getPersistentDataContainer().set(vehicleIdKey, PersistentDataType.STRING, def.id());
            entity.getPersistentDataContainer().set(linkKey, PersistentDataType.STRING, display.getUniqueId().toString());
        });

        display.getPersistentDataContainer().set(linkKey, PersistentDataType.STRING, interaction.getUniqueId().toString());
        return display;
    }

    public NamespacedKey vehicleIdKey() {
        return vehicleIdKey;
    }

    public NamespacedKey linkKey() {
        return linkKey;
    }
}
