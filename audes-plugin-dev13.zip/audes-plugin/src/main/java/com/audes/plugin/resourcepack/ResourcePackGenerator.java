package com.audes.plugin.resourcepack;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Men-zip folder "contents/" (struktur namespace ala ItemsAdder, lihat
 * catatan bagian 6 dokumen rencana) menjadi satu file resource pack,
 * lalu hitung SHA-1-nya untuk validasi hash di client (dipakai
 * ResourcePackModule saat kirim ResourcePackRequest ke player).
 *
 * GUARD UKURAN — ini alasan utama modul ini ada duluan sebelum fitur
 * lain (lihat riset bug bagian 8 dokumen rencana, issue #5213/#5289):
 * kompetitor sering silent-fail atau baru ketahuan gagal load di client
 * padahal pack sudah kebesaran. Di sini kita GAGALKAN generate secara
 * EKSPLISIT dengan pesan jelas kalau lewat batas 250MB (batas resource
 * pack native Minecraft sejak 1.18+), dan WARNING kalau sudah lewat
 * 100MB (ambang psikologis banyak client mulai lambat/gagal di koneksi
 * lemah — umum dialami base player Indonesia).
 */
public class ResourcePackGenerator {

    public static final long WARN_SIZE_BYTES = 100L * 1024 * 1024;
    public static final long BLOCK_SIZE_BYTES = 250L * 1024 * 1024;

    public record Result(File zipFile, String sha1Hex, long sizeBytes, boolean overWarnThreshold, int version) {
    }

    /**
     * @param contentsFolder      folder sumber (mis. plugins/Audes/contents/)
     * @param outputZip           file tujuan (mis. plugins/Audes/audes-pack.zip)
     * @param externalPacksFolder opsional (boleh null) — folder .zip pack plugin lain
     *                            buat digabung, lihat ResourcePackMerger. null/gak-ada = skip merge.
     * @param logger              buat nge-log hasil merge (boleh null kalau gak pakai external pack)
     * @throws IOException kalau I/O gagal ATAU ukuran hasil melebihi BLOCK_SIZE_BYTES
     *                      (pesan error menyebutkan ukuran aktual, bukan silent fail)
     */
    public Result generate(File contentsFolder, File outputZip, File externalPacksFolder, Logger logger) throws IOException {
        if (!contentsFolder.exists() || !contentsFolder.isDirectory()) {
            throw new IOException("Folder contents/ tidak ditemukan di '" + contentsFolder.getAbsolutePath()
                    + "'. Buat folder itu dan isi struktur namespace resource pack sebelum generate.");
        }

        Path root = contentsFolder.toPath();
        if (outputZip.exists() && !outputZip.delete()) {
            throw new IOException("Tidak bisa menghapus zip lama di '" + outputZip.getAbsolutePath() + "' sebelum regenerate.");
        }

        Set<String> writtenEntries = new HashSet<>();

        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(outputZip))) {
            try (var stream = Files.walk(root)) {
                for (Path path : (Iterable<Path>) stream.filter(Files::isRegularFile)::iterator) {
                    String entryName = root.relativize(path).toString().replace(File.separatorChar, '/');
                    ZipEntry entry = new ZipEntry(entryName);
                    zos.putNextEntry(entry);
                    Files.copy(path, zos);
                    zos.closeEntry();
                    writtenEntries.add(entryName);
                }
            }

            if (externalPacksFolder != null && logger != null) {
                new ResourcePackMerger(logger).mergeInto(externalPacksFolder, zos, writtenEntries);
            }
        }

        long size = outputZip.length();
        if (size > BLOCK_SIZE_BYTES) {
            // Sengaja TIDAK silent-fail — hapus hasil setengah jadi & lempar
            // pesan jelas, sesuai prinsip "no silent fail" di TODO Dev3.
            outputZip.delete();
            throw new IOException("Resource pack melebihi batas 250MB native Minecraft (ukuran: "
                    + (size / (1024 * 1024)) + "MB). Generate DIBATALKAN. Kurangi ukuran aset di contents/ atau external-packs/.");
        }

        String sha1 = sha1Hex(outputZip);
        boolean overWarn = size > WARN_SIZE_BYTES;
        int version = bumpVersion(outputZip);
        return new Result(outputZip, sha1, size, overWarn, version);
    }

    /**
     * Versioning sederhana berbasis file counter (bukan semantic version
     * penuh — "resource pack manager" versioning di sini artinya "tiap
     * generate tau ini generate ke berapa", cukup buat admin bandingin
     * "pack yang kepasang sekarang generate ke berapa" lewat /audes info,
     * bukan sistem changelog/diff penuh).
     */
    private int bumpVersion(File outputZip) {
        File versionFile = new File(outputZip.getParentFile(), outputZip.getName() + ".version");
        int current = 0;
        if (versionFile.exists()) {
            try {
                current = Integer.parseInt(Files.readString(versionFile.toPath()).trim());
            } catch (IOException | NumberFormatException ignored) {
                current = 0; // file rusak/gak kebaca, mulai ulang dari 0 daripada gagal generate gara-gara ini.
            }
        }
        int next = current + 1;
        try {
            Files.writeString(versionFile.toPath(), String.valueOf(next));
        } catch (IOException e) {
            // Gagal simpen versi bukan alasan buat gagalin generate pack-nya sendiri — cukup diam,
            // next generate bakal mulai dari 0 lagi (worst case cuma nomor versi keliru, bukan pack rusak).
        }
        return next;
    }

    private String sha1Hex(File file) throws IOException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            try (FileInputStream fis = new FileInputStream(file)) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = fis.read(buffer)) != -1) {
                    digest.update(buffer, 0, read);
                }
            }
            byte[] hashBytes = digest.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            // SHA-1 selalu tersedia di JVM standar, ini praktis unreachable.
            throw new IOException("SHA-1 tidak tersedia di JVM ini.", e);
        }
    }

    // CRC32 disediakan sebagai util kecil kalau nanti butuh validasi entry
    // per-file (mis. detect korupsi parsial) — belum dipakai di fase ini.
    public long crc32Of(byte[] data) {
        CRC32 crc = new CRC32();
        crc.update(data);
        return crc.getValue();
    }
}
