package com.audes.plugin.structure;

import com.audes.plugin.block.BlockDefinition;
import com.audes.plugin.block.BlockItemFactory;
import com.audes.plugin.block.BlockRegistry;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Note;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.data.type.NoteBlock;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Klik kanan item structure (bibit) ke block -> place SEMUA block dalam
 * StructureDefinition sekaligus, relatif ke titik klik. ALL-OR-NOTHING:
 * kalau ADA SATU SAJA lokasi target yang tidak kosong (bukan AIR), batal
 * total, tidak ada block yang ke-place sama sekali — supaya tidak
 * ninggalin "pohon setengah jadi" kalau kepentok block lain.
 *
 * Breaking TIDAK butuh listener terpisah di sini: tiap block yang
 * di-place lewat factory.markPlaced() jadi custom block biasa yang
 * sudah ditangani CustomBlockListener yang sudah ada (hardness, loot
 * table, tool tier per block id-nya masing-masing tetap berlaku).
 */
public class StructureListener implements Listener {

    private final StructureRegistry structureRegistry;
    private final StructureItemFactory structureFactory;
    private final BlockRegistry blockRegistry;
    private final BlockItemFactory blockFactory;

    public StructureListener(StructureRegistry structureRegistry, StructureItemFactory structureFactory,
                              BlockRegistry blockRegistry, BlockItemFactory blockFactory) {
        this.structureRegistry = structureRegistry;
        this.structureFactory = structureFactory;
        this.blockRegistry = blockRegistry;
        this.blockFactory = blockFactory;
    }

    @EventHandler
    public void onPlace(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null || event.getBlockFace() == null) return;

        ItemStack item = event.getPlayer().getInventory().getItemInMainHand();
        String structureId = structureFactory.getStructureId(item);
        if (structureId == null) return; // item biasa, bukan structure Audes

        structureRegistry.get(structureId).ifPresent(def -> {
            event.setCancelled(true);

            Location origin = event.getClickedBlock().getRelative(event.getBlockFace()).getLocation();

            // Validasi SEMUA lokasi target sebelum place SATU BLOK PUN --
            // baik lokasi kosong maupun block id-nya masih valid di config.
            List<Block> targets = new ArrayList<>();
            List<BlockDefinition> defs = new ArrayList<>();
            for (StructureDefinition.StructureBlockEntry entry : def.blocks()) {
                Block target = origin.clone().add(entry.dx(), entry.dy(), entry.dz()).getBlock();
                if (target.getType() != org.bukkit.Material.AIR) {
                    event.getPlayer().sendMessage("§c[Audes] Gak cukup ruang buat structure '" + structureId
                            + "' (kepentok block di sekitar). Cari tempat lebih lapang.");
                    return;
                }
                var blockDefOpt = blockRegistry.get(entry.blockId());
                if (blockDefOpt.isEmpty()) {
                    event.getPlayer().sendMessage("§c[Audes] Structure '" + structureId + "' merujuk block id '"
                            + entry.blockId() + "' yang tidak terdaftar di config.yml bagian 'blocks'. Place dibatalkan.");
                    return;
                }
                targets.add(target);
                defs.add(blockDefOpt.get());
            }

            for (int i = 0; i < targets.size(); i++) {
                placeOne(targets.get(i), defs.get(i));
            }

            if (event.getPlayer().getGameMode() != GameMode.CREATIVE) {
                item.setAmount(item.getAmount() - 1);
            }
            if (def.placeSoundKey() != null) {
                playConfiguredSound(event.getPlayer(), def.placeSoundKey());
            }
        });
    }

    private void placeOne(Block block, BlockDefinition def) {
        block.setType(org.bukkit.Material.NOTE_BLOCK);
        if (block.getBlockData() instanceof NoteBlock noteBlockData) {
            noteBlockData.setInstrument(def.instrument());
            noteBlockData.setNote(new Note(def.note()));
            block.setBlockData(noteBlockData, false);
        }
        blockFactory.markPlaced(block.getLocation(), def.id());
    }

    private void playConfiguredSound(org.bukkit.entity.Player player, String soundKey) {
        try {
            Sound sound = Sound.valueOf(soundKey.toUpperCase());
            player.getWorld().playSound(player.getLocation(), sound, 1.0f, 1.0f);
        } catch (IllegalArgumentException ignored) {
            // nama sound salah ketik di config -- diamkan.
        }
    }
}
