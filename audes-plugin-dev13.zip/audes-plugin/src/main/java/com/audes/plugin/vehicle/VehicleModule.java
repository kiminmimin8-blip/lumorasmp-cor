package com.audes.plugin.vehicle;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import com.audes.plugin.resourcepack.ResourcePackManifest;
import org.bukkit.event.HandlerList;

public class VehicleModule implements AudesModule {

    private final AudesPlugin plugin;
    private final ResourcePackManifest manifest;
    private VehicleRegistry registry;
    private VehicleItemFactory factory;
    private VehicleListener listener;

    public VehicleModule(AudesPlugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.manifest = manifest;
    }

    @Override
    public String getName() {
        return "vehicle";
    }

    @Override
    public void enable() {
        registry = new VehicleRegistry(plugin);
        registry.loadFromConfig(plugin.getConfig().getConfigurationSection("vehicles"));
        factory = new VehicleItemFactory(plugin, manifest);
        listener = new VehicleListener(plugin, registry, factory);
        plugin.getServer().getPluginManager().registerEvents(listener, plugin);
    }

    @Override
    public void disable() {
        if (listener != null) {
            HandlerList.unregisterAll(listener);
        }
    }

    public VehicleRegistry getRegistry() {
        return registry;
    }

    public VehicleItemFactory getFactory() {
        return factory;
    }
}
