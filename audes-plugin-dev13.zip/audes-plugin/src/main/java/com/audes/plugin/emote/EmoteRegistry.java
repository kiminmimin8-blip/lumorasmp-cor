package com.audes.plugin.emote;

import org.bukkit.configuration.ConfigurationSection;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public class EmoteRegistry {

    private final Map<String, EmoteDefinition> emotes = new LinkedHashMap<>();

    public void loadFromConfig(ConfigurationSection emotesSection) {
        emotes.clear();
        if (emotesSection == null) return;

        for (String id : emotesSection.getKeys(false)) {
            ConfigurationSection s = emotesSection.getConfigurationSection(id);
            if (s == null) continue;

            java.util.List<String> frames = s.getStringList("text-frames");
            if (frames.isEmpty()) {
                frames = java.util.List.of(s.getString("text", id)); // fallback: 1 baris teks statis kalau text-frames kosong.
            }

            EmoteDefinition def = new EmoteDefinition(
                    id,
                    frames,
                    Math.max(1, s.getInt("frame-interval-ticks", 4)),
                    Math.max(1, s.getInt("duration-ticks", 40)),
                    s.getString("sound", null),
                    s.getString("particle", null),
                    Math.max(0, s.getInt("cooldown-seconds", 3))
            );
            emotes.put(id, def);
        }
    }

    public Optional<EmoteDefinition> get(String id) {
        return Optional.ofNullable(emotes.get(id));
    }

    public Map<String, EmoteDefinition> getAll() {
        return emotes;
    }
}
