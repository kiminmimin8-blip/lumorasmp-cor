package com.audes.plugin.hud;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import org.bukkit.event.HandlerList;

public class HudModule implements AudesModule {

    private final AudesPlugin plugin;
    private HudRegistry registry;
    private HudManager manager;
    private HudListener listener;

    public HudModule(AudesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getName() {
        return "hud";
    }

    @Override
    public void enable() {
        registry = new HudRegistry(plugin);
        registry.loadFromConfig(plugin.getConfig().getConfigurationSection("huds"));
        manager = new HudManager(plugin);
        listener = new HudListener(registry, manager);
        plugin.getServer().getPluginManager().registerEvents(listener, plugin);
        manager.start();
    }

    @Override
    public void disable() {
        if (listener != null) {
            HandlerList.unregisterAll(listener);
        }
        if (manager != null) {
            manager.stop(); // juga bersihin semua BossBar yang masih aktif
        }
    }

    public HudRegistry getRegistry() {
        return registry;
    }

    public HudManager getManager() {
        return manager;
    }
}
