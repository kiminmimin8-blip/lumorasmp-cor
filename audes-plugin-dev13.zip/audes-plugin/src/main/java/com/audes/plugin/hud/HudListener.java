package com.audes.plugin.hud;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class HudListener implements Listener {

    private final HudRegistry registry;
    private final HudManager manager;

    public HudListener(HudRegistry registry, HudManager manager) {
        this.registry = registry;
        this.manager = manager;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        for (HudDefinition def : registry.getAll().values()) {
            if (def.autoShowOnJoin()) {
                manager.show(event.getPlayer(), def);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // Wajib dibersihkan manual -- BossBar TIDAK otomatis ke-remove
        // sendiri cuma karena player disconnect (beda dari action bar
        // yang otomatis "hilang" karena playernya emang udah gak ada).
        manager.hideAll(event.getPlayer());
    }
}
