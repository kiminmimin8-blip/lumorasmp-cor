package com.audes.plugin.structure;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.block.CustomBlockModule;
import com.audes.plugin.core.AudesModule;
import org.bukkit.event.HandlerList;

/**
 * DEPENDS ke CustomBlockModule (butuh BlockRegistry+BlockItemFactory
 * modul itu buat tau block id apa aja yang valid dirujuk structure).
 * Kalau custom-block modul gagal/nonaktif, modul ini ikut nonaktif juga
 * (lempar exception di enable(), ditangkap & di-isolasi ModuleManager
 * seperti modul lain — lihat javadoc ModuleManager).
 */
public class StructureModule implements AudesModule {

    private final AudesPlugin plugin;
    private final CustomBlockModule customBlockModule;
    private final StructureRegistry registry;
    private StructureItemFactory factory;
    private StructureListener listener;

    public StructureModule(AudesPlugin plugin, CustomBlockModule customBlockModule) {
        this.plugin = plugin;
        this.customBlockModule = customBlockModule;
        this.registry = new StructureRegistry(plugin);
    }

    @Override
    public String getName() {
        return "structure";
    }

    @Override
    public void enable() {
        if (customBlockModule == null || customBlockModule.getRegistry() == null) {
            throw new IllegalStateException("Modul 'structure' butuh modul 'custom-block' aktif duluan (structure "
                    + "merujuk block id yang didefinisikan di sana).");
        }

        registry.loadFromConfig(plugin.getConfig().getConfigurationSection("structures"));
        factory = new StructureItemFactory(plugin);
        listener = new StructureListener(registry, factory, customBlockModule.getRegistry(), customBlockModule.getFactory());
        plugin.getServer().getPluginManager().registerEvents(listener, plugin);
    }

    @Override
    public void disable() {
        if (listener != null) {
            HandlerList.unregisterAll(listener);
        }
    }

    public StructureRegistry getRegistry() {
        return registry;
    }

    public StructureItemFactory getFactory() {
        return factory;
    }
}
