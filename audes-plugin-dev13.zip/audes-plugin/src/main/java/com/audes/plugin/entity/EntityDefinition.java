package com.audes.plugin.entity;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;

import java.util.List;

/**
 * "Custom animated entities" dari daftar-fitur-itemsadder.md.
 *
 * PENDEKATAN (baca sebelum pakai): BUKAN engine animasi skeletal/keyframe
 * penuh kayak Blockbench-model-mob ala ItemsAdder (itu butuh render
 * custom di level packet/shader yang di luar jangkauan Bukkit API murni).
 * Yang dibangun di sini: MOB VANILLA ASLI (baseEntityType) dipakai buat
 * AI/hitbox/damage/pathfinding — jadi tetap bisa nyerang, kena damage,
 * drop loot, dsb seperti mob biasa — TAPI mob aslinya di-invisible+silent,
 * dan di atasnya "ditumpangi" ItemDisplay yang jadi wujud visual custom.
 * ItemDisplay itu yang di-animasikan lewat POSE CYCLING (daftar transform
 * offset yang gantian tiap durationTicks, mis. naik-turun buat efek
 * "melayang/bernapas") — sama teknik dengan animated text effect di
 * modul emote, cuma domainnya transform 3D bukan teks.
 *
 * KONSEKUENSI: hitbox visual (ItemDisplay) dan hitbox SERANG (mob asli)
 * TIDAK 100% identik kalau modelnya jauh lebih besar/kecil dari mob
 * dasarnya — mob dasar tetap pakai hitbox vanilla-nya sendiri. Pilih
 * baseEntityType yang ukurannya mendekati model custom-nya.
 */
public record EntityDefinition(
        String id,
        EntityType baseEntityType,
        Material displayMaterial,
        String modelKey,
        float scale,
        String customName,
        List<Pose> poses
) {
    /** Satu frame animasi: offset posisi + rotasi dari titik mob, ditahan selama durationTicks sebelum ganti ke pose berikutnya. */
    public record Pose(float offsetY, float yawDegrees, int durationTicks) {
    }
}
