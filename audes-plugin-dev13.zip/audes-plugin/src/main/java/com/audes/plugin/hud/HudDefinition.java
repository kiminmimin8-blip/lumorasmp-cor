package com.audes.plugin.hud;

import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;

/**
 * "Custom HUD" dari daftar-fitur-itemsadder.md.
 *
 * PENDEKATAN (baca sebelum pakai): implementasi ASLI ItemsAdder buat
 * "custom HUD" pakai FONT CUSTOM dari resource pack (karakter bitmap
 * yang di-render lewat trik title/actionbar dengan character spacing
 * negatif) buat gambar HUD pixel-art bebas bentuk apa aja. Project ini
 * BELUM punya infrastruktur custom font (belum ada modul font/glyph di
 * resource pack pipeline), jadi HUD di sini pakai APPROACH YANG LEBIH
 * SEDERHANA TAPI REALISTIS pakai API BAWAAN Bukkit:
 * - type BOSSBAR: bar persisten di atas layar (progress bar bawaan
 *   Minecraft) -- cocok buat nampilin 1 nilai numerik (health, currency,
 *   progress event, dll) dengan visual yang jelas.
 * - type ACTIONBAR: teks di atas hotbar -- cocok buat info singkat
 *   yang lebih fleksibel bentuk teksnya (tapi TIDAK ada progress bar
 *   visual kayak boss bar).
 * Placeholder yang didukung (lihat HudPlaceholders): %player%,
 * %health%, %max_health%, %world%, %online%, %fps_note% (catatan: gak
 * ada FPS asli, placeholder ini sengaja gak disediakan -- dihapus dari
 * daftar biar gak menyesatkan; lihat HudPlaceholders untuk daftar final).
 */
public record HudDefinition(
        String id,
        Type type,
        String template,
        int updateIntervalTicks,
        BarColor barColor,
        BarStyle barStyle,
        boolean autoShowOnJoin
) {
    public enum Type {
        BOSSBAR, ACTIONBAR
    }
}
