package com.audes.plugin.gui;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;

/**
 * Menangani klik di custom GUI. Identifikasi "ini GUI Audes yang mana"
 * lewat AudesGuiHolder (lihat javadoc class itu untuk alasan tidak pakai
 * Map eksternal).
 *
 * SEMUA klik di GUI Audes DI-CANCEL tanpa terkecuali (termasuk klik ke
 * inventory PLAYER sendiri selama GUI Audes yang lagi terbuka) --
 * disengaja: GUI ini murni menu tombol, bukan tempat pindah-pindah item,
 * jadi tidak ada skenario legit buat player ambil/taruh item selagi GUI
 * ini terbuka. Ini juga mencegah shift-click exploit umum di GUI plugin
 * (klik shift buat "curi" item dari GUI ke inventory sendiri).
 */
public class GuiListener implements Listener {

    private final GuiRegistry registry;

    public GuiListener(GuiRegistry registry) {
        this.registry = registry;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder topHolder = event.getView().getTopInventory().getHolder();
        if (!(topHolder instanceof AudesGuiHolder holder)) return; // bukan GUI Audes, biarkan normal

        event.setCancelled(true); // lihat javadoc class ini kenapa selalu di-cancel

        if (!(event.getWhoClicked() instanceof Player player)) return;
        // Klik di INVENTORY PLAYER (bagian bawah layar) selagi GUI Audes
        // terbuka di atas -- sudah di-cancel di atas, tidak ada tombol
        // yang perlu diproses lebih lanjut.
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getView().getTopInventory()) {
            return;
        }

        registry.get(holder.getGuiId()).ifPresent(def -> {
            int slot = event.getSlot();
            def.buttons().stream()
                    .filter(b -> b.slot() == slot)
                    .findFirst()
                    .ifPresent(button -> {
                        for (String command : button.commands()) {
                            String resolved = command.replace("%player%", player.getName());
                            dispatch(player, resolved);
                        }
                        if (button.closeOnClick()) {
                            player.closeInventory();
                        }
                    });
        });
    }

    /**
     * Default: command dijalankan SEBAGAI PLAYER (lihat javadoc
     * GuiButtonDefinition kenapa itu default-nya). Opt-in eksplisit per
     * baris lewat TAG di awal command, bisa lebih dari satu tag
     * digabung (urutan bebas, dipisah spasi):
     *
     *   [console]              -> jalankan baris ini sebagai console (lihat javadoc GuiButtonDefinition)
     *   [if_perm:<permission>] -> baris ini CUMA jalan kalau player punya permission itu, kalau tidak di-skip diam-diam
     *
     * Contoh gabungan: "[if_perm:audes.vip] [console] give %player% diamond 1"
     * -- cuma player ber-permission audes.vip yang dapet diamond ini,
     * dan command-nya dijalankan sebagai console.
     *
     * INI BUKAN "scripting language internal" PENUH dari
     * daftar-fitur-itemsadder.md (itu berarti bahasa custom lengkap
     * dengan variabel/loop/kondisi kompleks -- proyek parser+interpreter
     * sendiri, effort-nya besar sekali dan di luar scope realistis
     * project ini). Yang dibangun di sini SENGAJA cuma "tag kondisional
     * di depan command", cukup buat kebutuhan umum (gating command per
     * permission) tanpa bikin bahasa scripting generik yang over-engineered.
     */
    private static final String CONSOLE_TAG = "[console]";
    private static final String IF_PERM_PREFIX = "[if_perm:";

    private void dispatch(Player player, String command) {
        String remaining = command.trim();
        boolean asConsole = false;

        while (true) {
            if (remaining.regionMatches(true, 0, CONSOLE_TAG, 0, CONSOLE_TAG.length())) {
                asConsole = true;
                remaining = remaining.substring(CONSOLE_TAG.length()).trim();
                continue;
            }
            if (remaining.regionMatches(true, 0, IF_PERM_PREFIX, 0, IF_PERM_PREFIX.length())) {
                int closeIdx = remaining.indexOf(']');
                if (closeIdx < 0) break; // tag rusak (gak ada penutup ']'), berhenti parse tag, sisanya dianggap command apa adanya.
                String permission = remaining.substring(IF_PERM_PREFIX.length(), closeIdx).trim();
                if (!player.hasPermission(permission)) {
                    return; // player gak punya permission ini -- skip baris ini diam-diam, TIDAK dijalankan sama sekali.
                }
                remaining = remaining.substring(closeIdx + 1).trim();
                continue;
            }
            break; // gak ada tag lagi di depan, sisanya command asli.
        }

        if (asConsole) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), remaining);
        } else {
            Bukkit.dispatchCommand(player, remaining);
        }
    }
}
