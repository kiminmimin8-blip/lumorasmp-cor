package com.audes.plugin.entity;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

public class EntitySpawnListener implements Listener {

    private final EntityRegistry registry;
    private final EntitySpawnItemFactory factory;
    private final EntityAnimator animator;

    public EntitySpawnListener(EntityRegistry registry, EntitySpawnItemFactory factory, EntityAnimator animator) {
        this.registry = registry;
        this.factory = factory;
        this.animator = animator;
    }

    @EventHandler
    public void onSpawnItemUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null || event.getBlockFace() == null) return;

        ItemStack item = event.getPlayer().getInventory().getItemInMainHand();
        String entityId = factory.getEntityId(item);
        if (entityId == null) return;

        registry.get(entityId).ifPresent(def -> {
            event.setCancelled(true);
            Location spawnAt = event.getClickedBlock().getRelative(event.getBlockFace()).getLocation().add(0.5, 0.0, 0.5);
            factory.spawn(spawnAt, def);

            if (event.getPlayer().getGameMode() != GameMode.CREATIVE) {
                item.setAmount(item.getAmount() - 1);
            }
        });
    }

    /** Mob dasar mati (kalah duel/dibunuh) -> ItemDisplay overlay ikut dibersihkan lewat EntityAnimator#unregister. */
    @EventHandler
    public void onBaseMobDeath(EntityDeathEvent event) {
        String entityId = event.getEntity().getPersistentDataContainer().get(factory.entityIdKey(), PersistentDataType.STRING);
        if (entityId == null) return;
        animator.unregister(event.getEntity().getUniqueId());
    }
}
