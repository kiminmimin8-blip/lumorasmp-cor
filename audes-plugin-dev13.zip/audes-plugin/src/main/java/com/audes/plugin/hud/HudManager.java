package com.audes.plugin.hud;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * SATU task global (pola sama kayak EntityAnimator di modul entity)
 * yang tiap tick ngecek semua sesi HUD aktif, dan cuma re-render begitu
 * counter tick-nya nyampe updateIntervalTicks HUD itu masing-masing --
 * jadi HUD dengan interval beda-beda tetap efisien tanpa butuh task
 * terpisah per HUD/per player.
 */
public class HudManager {

    private record Session(HudDefinition def, BossBar bossBar) {
    }

    private final Plugin plugin;
    // key = "<uuid>:<hudId>"
    private final Map<String, Session> sessions = new ConcurrentHashMap<>();
    private final Map<String, Integer> ticksElapsed = new HashMap<>();
    private BukkitTask task;

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    public HudManager(Plugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tickAll, 1L, 1L);
    }

    public void stop() {
        if (task != null) task.cancel();
        for (Session session : sessions.values()) {
            if (session.bossBar() != null) session.bossBar().removeAll();
        }
        sessions.clear();
        ticksElapsed.clear();
    }

    public boolean isActive(Player player, String hudId) {
        return sessions.containsKey(key(player, hudId));
    }

    /** @return true kalau berhasil di-show (baru dinyalain), false kalau sebelumnya udah aktif (di-toggle off, bukan di-show ulang) */
    public boolean toggle(Player player, HudDefinition def) {
        String key = key(player, def.id());
        if (sessions.containsKey(key)) {
            hide(player, def.id());
            return false;
        }
        show(player, def);
        return true;
    }

    public void show(Player player, HudDefinition def) {
        String key = key(player, def.id());
        BossBar bossBar = null;
        if (def.type() == HudDefinition.Type.BOSSBAR) {
            bossBar = Bukkit.createBossBar("", def.barColor(), def.barStyle());
            bossBar.addPlayer(player);
        }
        sessions.put(key, new Session(def, bossBar));
        ticksElapsed.put(key, def.updateIntervalTicks()); // langsung render di tick pertama, bukan nunggu 1 interval penuh
    }

    public void hide(Player player, String hudId) {
        String key = key(player, hudId);
        Session session = sessions.remove(key);
        ticksElapsed.remove(key);
        if (session != null && session.bossBar() != null) {
            session.bossBar().removeAll();
        }
    }

    public void hideAll(Player player) {
        sessions.keySet().stream()
                .filter(k -> k.startsWith(player.getUniqueId() + ":"))
                .toList() // salin dulu biar gak ConcurrentModificationException pas remove
                .forEach(k -> {
                    Session session = sessions.remove(k);
                    ticksElapsed.remove(k);
                    if (session != null && session.bossBar() != null) session.bossBar().removeAll();
                });
    }

    private void tickAll() {
        for (Map.Entry<String, Session> entry : sessions.entrySet()) {
            String key = entry.getKey();
            Session session = entry.getValue();
            UUID uuid = UUID.fromString(key.substring(0, key.indexOf(':')));
            Player player = Bukkit.getPlayer(uuid);

            if (player == null || !player.isOnline()) {
                sessions.remove(key);
                ticksElapsed.remove(key);
                if (session.bossBar() != null) session.bossBar().removeAll();
                continue;
            }

            int elapsed = ticksElapsed.getOrDefault(key, 0) + 1;
            if (elapsed < session.def().updateIntervalTicks()) {
                ticksElapsed.put(key, elapsed);
                continue;
            }
            ticksElapsed.put(key, 0);

            String rendered = HudPlaceholders.resolve(session.def().template(), player);
            if (session.def().type() == HudDefinition.Type.BOSSBAR && session.bossBar() != null) {
                // BossBar API (org.bukkit.boss.BossBar) masih pakai String legacy, bukan Adventure
                // Component, di versi Paper yang jadi target project ini -- translate manual
                // kode warna '&' -> '§' cukup, gak perlu lewat LegacyComponentSerializer segala.
                session.bossBar().setTitle(org.bukkit.ChatColor.translateAlternateColorCodes('&', rendered));
            } else {
                player.sendActionBar(LEGACY.deserialize(rendered));
            }
        }
    }

    private String key(Player player, String hudId) {
        return player.getUniqueId() + ":" + hudId;
    }
}
