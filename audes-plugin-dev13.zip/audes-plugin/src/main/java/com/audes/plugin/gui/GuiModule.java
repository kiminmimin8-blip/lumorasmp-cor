package com.audes.plugin.gui;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import org.bukkit.event.HandlerList;

public class GuiModule implements AudesModule {

    private final AudesPlugin plugin;
    private GuiRegistry registry;
    private GuiManager manager;
    private GuiListener listener;

    public GuiModule(AudesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getName() {
        return "gui";
    }

    @Override
    public void enable() {
        registry = new GuiRegistry(plugin);
        registry.loadFromConfig(plugin.getConfig().getConfigurationSection("guis"));
        manager = new GuiManager();
        listener = new GuiListener(registry);
        plugin.getServer().getPluginManager().registerEvents(listener, plugin);
    }

    @Override
    public void disable() {
        if (listener != null) {
            HandlerList.unregisterAll(listener);
        }
    }

    public GuiRegistry getRegistry() {
        return registry;
    }

    public GuiManager getManager() {
        return manager;
    }
}
