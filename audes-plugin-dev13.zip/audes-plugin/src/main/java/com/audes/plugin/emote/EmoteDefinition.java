package com.audes.plugin.emote;

import java.util.List;

/**
 * Satu custom emote dari config.yml bagian "emotes:".
 *
 * "Custom animated text effects" dari daftar-fitur-itemsadder.md
 * di-implementasi di sini sebagai TEXT FRAME CYCLING: "textFrames" berisi
 * beberapa versi teks (mis. warna beda tiap frame buat efek rainbow, atau
 * teks beda buat efek "berkedip"), ditampilkan bergantian tiap
 * "frameIntervalTicks" selama "durationTicks" total lewat action bar +
 * TextDisplay di atas kepala player. Kalau textFrames cuma 1 elemen,
 * otomatis jadi teks statis biasa (behavior sederhana, tidak ada animasi).
 *
 * Ini BUKAN library animasi teks umum (tidak ada easing/interpolasi) --
 * murni cycling antar frame teks yang sudah jadi, cukup buat kebutuhan
 * emote (rainbow chat bubble, teks berkedip, dll) tanpa bikin engine
 * animasi teks generik yang over-engineered untuk use-case ini.
 */
public record EmoteDefinition(
        String id,
        List<String> textFrames,
        int frameIntervalTicks,
        int durationTicks,
        String soundKey,
        String particleKey,
        int cooldownSeconds
) {
    public boolean isAnimated() {
        return textFrames.size() > 1;
    }
}
