package com.audes.plugin.vehicle;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Place lewat klik kanan (sama pola furniture), mount lewat klik kanan ke
 * Interaction yang sudah di-place, drive lewat task per-tick selagi ada
 * passenger (lihat javadoc VehicleDefinition soal keterbatasan mekanik
 * drive), dismount lewat SNEAK (shift), break lewat serang Interaction
 * SELAGI TIDAK ADA YANG NAIK (supaya gak bisa "curi" vehicle orang lagi
 * naik).
 */
public class VehicleListener implements Listener {

    private final Plugin plugin;
    private final VehicleRegistry registry;
    private final VehicleItemFactory factory;

    private final Map<UUID, BukkitTask> driveTasks = new HashMap<>();

    public VehicleListener(Plugin plugin, VehicleRegistry registry, VehicleItemFactory factory) {
        this.plugin = plugin;
        this.registry = registry;
        this.factory = factory;
    }

    @EventHandler
    public void onPlace(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null || event.getBlockFace() == null) return;

        ItemStack item = event.getPlayer().getInventory().getItemInMainHand();
        String vehicleId = factory.getVehicleId(item);
        if (vehicleId == null) return;

        registry.get(vehicleId).ifPresent(def -> {
            event.setCancelled(true);
            Location spawnAt = event.getClickedBlock().getRelative(event.getBlockFace()).getLocation().add(0.5, 0.0, 0.5);
            factory.spawn(spawnAt, def);

            if (event.getPlayer().getGameMode() != GameMode.CREATIVE) {
                item.setAmount(item.getAmount() - 1);
            }
            if (def.placeSoundKey() != null) playConfiguredSound(event.getPlayer(), def.placeSoundKey());
        });
    }

    @EventHandler
    public void onMountAttempt(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Interaction interaction)) return;

        String vehicleId = interaction.getPersistentDataContainer().get(factory.vehicleIdKey(), PersistentDataType.STRING);
        if (vehicleId == null) return;

        registry.get(vehicleId).ifPresent(def -> {
            event.setCancelled(true);

            String linkedUuid = interaction.getPersistentDataContainer().get(factory.linkKey(), PersistentDataType.STRING);
            if (linkedUuid == null) return;
            Entity linked = Bukkit.getEntity(UUID.fromString(linkedUuid));
            if (!(linked instanceof ItemDisplay display)) return;

            if (!display.getPassengers().isEmpty()) return; // udah ada yang naik

            Player rider = event.getPlayer();
            display.addPassenger(rider);
            startDriving(display, def);

            if (def.mountSoundKey() != null) playConfiguredSound(rider, def.mountSoundKey());
        });
    }

    /**
     * Mekanik drive DISEDERHANAKAN (lihat javadoc VehicleDefinition):
     * tiap tick selagi ada passenger & passenger TIDAK sneak, display
     * digerakkan maju sesuai arah HORIZONTAL pandangan player (yaw),
     * kecepatan dari def.speedBlocksPerSecond(). Sneak = berhenti total.
     * Task auto-cancel begitu getPassengers() kosong (baik dari sneak
     * dismount di bawah, maupun jalur lain kayak player disconnect).
     */
    private void startDriving(ItemDisplay display, VehicleDefinition def) {
        UUID displayUuid = display.getUniqueId();

        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            Entity current = Bukkit.getEntity(displayUuid);
            if (!(current instanceof ItemDisplay liveDisplay) || liveDisplay.getPassengers().isEmpty()) {
                stopDriving(displayUuid);
                return;
            }

            Entity passenger = liveDisplay.getPassengers().get(0);
            if (!(passenger instanceof Player rider) || !rider.isOnline() || rider.isSneaking()) {
                return; // sneak = rem, diem di tempat tick ini
            }

            double speedPerTick = def.speedBlocksPerSecond() / 20.0;
            float yaw = rider.getLocation().getYaw();
            Vector direction = new Vector(-Math.sin(Math.toRadians(yaw)), 0, Math.cos(Math.toRadians(yaw)))
                    .normalize().multiply(speedPerTick);

            Location next = liveDisplay.getLocation().add(direction);
            next.setYaw(yaw);
            liveDisplay.teleport(next);
        }, 1L, 1L);

        driveTasks.put(displayUuid, task);
    }

    private void stopDriving(UUID displayUuid) {
        BukkitTask task = driveTasks.remove(displayUuid);
        if (task != null) task.cancel();
    }

    /**
     * Sneak sekali saat naik = turun total dari vehicle (bukan cuma rem
     * sesaat — beda dari sneak yang dicek di dalam task drive di atas).
     */
    @EventHandler
    public void onSneakToDismount(PlayerToggleSneakEvent event) {
        if (!event.isSneaking()) return;
        Player player = event.getPlayer();
        if (!(player.getVehicle() instanceof ItemDisplay display)) return;

        String vehicleId = display.getPersistentDataContainer().get(factory.vehicleIdKey(), PersistentDataType.STRING);
        if (vehicleId == null) return; // ItemDisplay biasa (bukan vehicle Audes)

        display.removePassenger(player);
        // stopDriving otomatis kepanggil dari dalam task begitu getPassengers() kosong tick berikutnya.
    }

    @EventHandler
    public void onAttack(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Interaction interaction)) return;
        if (!(event.getDamager() instanceof Player breaker)) return;

        String vehicleId = interaction.getPersistentDataContainer().get(factory.vehicleIdKey(), PersistentDataType.STRING);
        if (vehicleId == null) return;

        event.setCancelled(true);

        registry.get(vehicleId).ifPresent(def -> {
            String linkedUuid = interaction.getPersistentDataContainer().get(factory.linkKey(), PersistentDataType.STRING);
            if (linkedUuid == null) return;
            Entity linked = Bukkit.getEntity(UUID.fromString(linkedUuid));
            if (!(linked instanceof ItemDisplay display)) return;

            if (!display.getPassengers().isEmpty()) {
                breaker.sendMessage("§c[Audes] Gak bisa hancurin vehicle yang lagi dinaiki orang.");
                return;
            }

            stopDriving(display.getUniqueId());
            Location dropLocation = interaction.getLocation();
            display.remove();
            interaction.remove();
            dropLocation.getWorld().dropItemNaturally(dropLocation, factory.create(def));
        });
    }

    private void playConfiguredSound(Player player, String soundKey) {
        try {
            player.getWorld().playSound(player.getLocation(), Sound.valueOf(soundKey.toUpperCase()), 1.0f, 1.0f);
        } catch (IllegalArgumentException ignored) {
            // nama sound salah ketik di config -- diamkan.
        }
    }
}
