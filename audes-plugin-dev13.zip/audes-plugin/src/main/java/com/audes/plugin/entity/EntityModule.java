package com.audes.plugin.entity;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import com.audes.plugin.resourcepack.ResourcePackManifest;
import org.bukkit.event.HandlerList;

public class EntityModule implements AudesModule {

    private final AudesPlugin plugin;
    private final ResourcePackManifest manifest;
    private EntityRegistry registry;
    private EntitySpawnItemFactory factory;
    private EntityAnimator animator;
    private EntitySpawnListener listener;

    public EntityModule(AudesPlugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.manifest = manifest;
    }

    @Override
    public String getName() {
        return "entity";
    }

    @Override
    public void enable() {
        registry = new EntityRegistry(plugin);
        registry.loadFromConfig(plugin.getConfig().getConfigurationSection("entities"));
        animator = new EntityAnimator(plugin);
        factory = new EntitySpawnItemFactory(plugin, manifest, animator);
        listener = new EntitySpawnListener(registry, factory, animator);
        plugin.getServer().getPluginManager().registerEvents(listener, plugin);
        animator.start();
    }

    @Override
    public void disable() {
        if (listener != null) {
            HandlerList.unregisterAll(listener);
        }
        if (animator != null) {
            animator.stop(); // juga bersihin semua ItemDisplay overlay yang masih nempel
        }
    }

    public EntityRegistry getRegistry() {
        return registry;
    }

    public EntitySpawnItemFactory getFactory() {
        return factory;
    }
}
