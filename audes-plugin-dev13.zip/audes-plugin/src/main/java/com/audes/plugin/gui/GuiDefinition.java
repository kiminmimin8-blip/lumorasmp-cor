package com.audes.plugin.gui;

import java.util.List;

/**
 * Satu custom GUI dari config.yml bagian "guis:". "rows" 1-6 (kelipatan
 * 9 slot per baris, standar inventory chest Minecraft).
 *
 * BEDA DARI custom block/furniture/tool/armor: GUI TIDAK menghasilkan
 * ItemStack yang bisa di-give ke player. Cara buka GUI ini sekarang
 * cuma lewat "/audes gui &lt;gui_id&gt; [player]" (admin command, lihat
 * AudesCommand). TODO(Dev lain): kalau tim mau trigger GUI dari sisi
 * player sendiri (mis. klik kanan item tertentu buat buka shop, atau
 * command non-admin "/shop"), itu belum diwire di sesi ini -- framework
 * GuiManager#open() sudah generik & siap dipanggil dari trigger manapun,
 * tinggal tambah pemanggilnya.
 */
public record GuiDefinition(
        String id,
        String title,
        int rows,
        List<GuiButtonDefinition> buttons
) {
}
