package com.audes.plugin.emote;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Nampilin emote: TextDisplay ngambang di atas kepala player yang
 * teksnya di-cycle antar frame (lihat javadoc EmoteDefinition), plus
 * sound/particle sekali di awal. TextDisplay ngikutin posisi player
 * tiap frame (bukan dipasang statis di 1 titik) supaya kalau player
 * gerak selagi emote jalan, teksnya tetap ngambang di atas kepala.
 *
 * Cooldown per-player per-emote dicek di sini (bukan di listener command)
 * biar konsisten kalau nanti emote juga dipicu dari jalur lain (mis. GUI
 * tombol emote), bukan cuma dari command langsung.
 */
public class EmotePlayer {

    private final Plugin plugin;
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder().character('&').build();

    // key = "<uuid>:<emoteId>", value = timestamp (ms) boleh pakai lagi
    private final Map<String, Long> cooldowns = new HashMap<>();

    public EmotePlayer(Plugin plugin) {
        this.plugin = plugin;
    }

    public enum PlayResult {
        PLAYED, ON_COOLDOWN
    }

    public PlayResult play(Player player, EmoteDefinition def) {
        String key = player.getUniqueId() + ":" + def.id();
        long now = System.currentTimeMillis();
        Long readyAt = cooldowns.get(key);
        if (readyAt != null && now < readyAt) {
            return PlayResult.ON_COOLDOWN;
        }
        cooldowns.put(key, now + def.cooldownSeconds() * 1000L);

        if (def.soundKey() != null) {
            try {
                player.getWorld().playSound(player.getLocation(), Sound.valueOf(def.soundKey().toUpperCase()), 1.0f, 1.0f);
            } catch (IllegalArgumentException ignored) {
                // nama sound salah ketik di config -- diamkan, jangan ganggu jalannya emote.
            }
        }
        if (def.particleKey() != null) {
            try {
                player.getWorld().spawnParticle(Particle.valueOf(def.particleKey().toUpperCase()),
                        player.getLocation().add(0, 2.0, 0), 12, 0.3, 0.3, 0.3, 0.01);
            } catch (IllegalArgumentException ignored) {
                // nama particle salah ketik -- diamkan sama seperti sound di atas.
            }
        }

        spawnAndCycle(player, def);
        return PlayResult.PLAYED;
    }

    private void spawnAndCycle(Player player, EmoteDefinition def) {
        Location spawnAt = player.getLocation().add(0, 2.2, 0);
        TextDisplay display = player.getWorld().spawn(spawnAt, TextDisplay.class, td -> {
            td.setBillboard(Display.Billboard.CENTER);
            td.setSeeThrough(true);
            td.setShadowed(true);
            td.setDefaultBackground(false);
            td.text(LEGACY.deserialize(def.textFrames().get(0)));
        });

        UUID playerUuid = player.getUniqueId();
        UUID displayUuid = display.getUniqueId();

        new BukkitRunnable() {
            int elapsed = 0;
            int frameIndex = 0;

            @Override
            public void run() {
                var displayEntity = plugin.getServer().getEntity(displayUuid);
                var playerEntity = plugin.getServer().getPlayer(playerUuid);

                if (displayEntity == null || elapsed >= def.durationTicks() || playerEntity == null || !playerEntity.isOnline()) {
                    if (displayEntity != null) displayEntity.remove();
                    cancel();
                    return;
                }

                if (displayEntity instanceof TextDisplay td) {
                    // Ikutin posisi player tiap frame supaya teks tetap ngambang di atas kepala saat player gerak.
                    td.teleport(playerEntity.getLocation().add(0, 2.2, 0));

                    if (elapsed % def.frameIntervalTicks() == 0 && def.isAnimated()) {
                        frameIndex = (frameIndex + 1) % def.textFrames().size();
                        td.text(LEGACY.deserialize(def.textFrames().get(frameIndex)));
                    }
                }

                elapsed++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
}
