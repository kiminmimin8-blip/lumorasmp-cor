package com.audes.plugin.structure;

import java.util.List;

/**
 * "Custom tree", "custom surface decoration block", "custom cave
 * decoration block" dari daftar-fitur-itemsadder.md — tiga fitur beda
 * di ItemsAdder, tapi secara teknis sama-sama "tempatkan SEKUMPULAN
 * custom block sekaligus dalam satu aksi" (tree = batang+daun, decoration
 * cluster = beberapa block dekorasi nempel jadi satu formasi). Daripada
 * bikin 3 modul terpisah yang isinya sama, di-generalisasi jadi SATU
 * konsep: "structure" = daftar offset relatif + block id (merujuk ke
 * BlockDefinition yang SUDAH terdaftar di config.yml bagian "blocks:").
 *
 * TIDAK BUTUH kode baru untuk breaking/hardness/loot table per block
 * dalam structure — begitu di-place, tiap block JADI custom block biasa
 * yang sudah dikenali CustomBlockListener (sama seperti dipasang manual
 * satu-satu), jadi break/hardness/loot table-nya otomatis ikut aturan
 * BlockDefinition masing-masing.
 */
public record StructureDefinition(
        String id,
        String displayName,
        List<StructureBlockEntry> blocks,
        String placeSoundKey
) {
    public record StructureBlockEntry(int dx, int dy, int dz, String blockId) {
    }
}
