package com.audes.plugin.entity;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.EntityType;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class EntityRegistry {

    private final Plugin plugin;
    private final Map<String, EntityDefinition> entities = new LinkedHashMap<>();

    public EntityRegistry(Plugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig(ConfigurationSection section) {
        entities.clear();
        if (section == null) return;

        for (String id : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(id);
            if (s == null) continue;

            EntityType baseType;
            try {
                baseType = EntityType.valueOf(s.getString("base-entity", "ZOMBIE").toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("[Audes] base-entity tidak valid buat entity '" + id + "', di-skip.");
                continue;
            }

            Material material;
            try {
                material = Material.valueOf(s.getString("material", "PLAYER_HEAD").toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("[Audes] Material tidak valid buat entity '" + id + "', di-skip.");
                continue;
            }

            List<Map<?, ?>> rawPoses = s.getMapList("poses");
            List<EntityDefinition.Pose> poses = new ArrayList<>();
            for (Map<?, ?> raw : rawPoses) {
                float offsetY = raw.get("offset-y") instanceof Number n ? n.floatValue() : 0f;
                float yaw = raw.get("yaw") instanceof Number n ? n.floatValue() : 0f;
                int duration = raw.get("duration-ticks") instanceof Number n ? n.intValue() : 10;
                poses.add(new EntityDefinition.Pose(offsetY, yaw, Math.max(1, duration)));
            }
            if (poses.isEmpty()) {
                poses.add(new EntityDefinition.Pose(0f, 0f, 20)); // fallback: 1 pose diam (gak animasi) daripada divide-by-zero di task.
            }

            entities.put(id, new EntityDefinition(
                    id, baseType, material, s.getString("model", null),
                    (float) s.getDouble("scale", 1.0),
                    s.getString("custom-name", null),
                    List.copyOf(poses)
            ));
        }

        plugin.getLogger().info("[Audes] " + entities.size() + " custom animated entity termuat dari config.");
    }

    public Optional<EntityDefinition> get(String id) {
        return Optional.ofNullable(entities.get(id));
    }

    public Map<String, EntityDefinition> getAll() {
        return entities;
    }
}
