package com.audes.plugin.vehicle;

import org.bukkit.Material;

/**
 * "Custom vehicle" dari daftar-fitur-itemsadder.md.
 *
 * KETERBATASAN YANG SENGAJA DIDOKUMENTASIKAN (baca sebelum pakai):
 * vehicle asli (boat/minecart) gerak berdasarkan input WASD MENTAH yang
 * dikirim client lewat packet — Bukkit API TIDAK expose ini secara resmi
 * (biasanya butuh ProtocolLib buat baca PlayerInput packet), dan project
 * ini sengaja belum depend ke ProtocolLib (lihat prinsip arsitektur:
 * API resmi dulu). Jadi vehicle di sini pakai mekanik yang DISEDERHANAKAN:
 * - MAJU TERUS otomatis selagi dimount (kecuali player sneak = rem/stop).
 * - BELOK dengan noleh (yaw player nentuin arah maju vehicle tiap tick).
 * - TIDAK ada mundur/strafe kiri-kanan murni, TIDAK mengikuti kontur
 *   tanah (asumsi dipakai di permukaan rata / bukan climbing tebing).
 * Ini "vehicle" dalam artian kendaraan yang bisa dinaiki & jalan sendiri
 * dengan kontrol arah dari arah pandang, BUKAN replika penuh kontrol
 * boat/minecart vanilla. Kalau tim butuh kontrol WASD penuh nanti,
 * itu perlu keputusan sadar buat nambah dependency ProtocolLib.
 */
public record VehicleDefinition(
        String id,
        Material displayMaterial,
        String displayName,
        String modelKey,
        float scale,
        double speedBlocksPerSecond,
        String placeSoundKey,
        String mountSoundKey
) {
}
