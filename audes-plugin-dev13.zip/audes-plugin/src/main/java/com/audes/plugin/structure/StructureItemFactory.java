package com.audes.plugin.structure;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

/**
 * Item "bibit" structure (mis. bibit pohon custom) — beda dari
 * BlockItemFactory, item ini SELALU Material.SAPLING-ish generik (default
 * OAK_SAPLING) karena yang di-place bukan block ini sendiri, tapi
 * SEKUMPULAN block lain yang dirujuk StructureDefinition. Kalau mau
 * tampilan item beda per structure, tetap bisa lewat modelKey item biasa
 * (belum diterapkan di sini — bisa ditambah nanti pakai pola yang sama
 * seperti applyModelIfAvailable di BlockItemFactory kalau dibutuhkan).
 */
public class StructureItemFactory {

    public static final String STRUCTURE_ID_KEY = "structure_id";

    private final NamespacedKey structureIdKey;
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    public StructureItemFactory(Plugin plugin) {
        this.structureIdKey = new NamespacedKey(plugin, STRUCTURE_ID_KEY);
    }

    public ItemStack create(StructureDefinition def) {
        ItemStack item = new ItemStack(Material.OAK_SAPLING);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(LEGACY.deserialize(def.displayName()));
            meta.getPersistentDataContainer().set(structureIdKey, PersistentDataType.STRING, def.id());
            item.setItemMeta(meta);
        }
        return item;
    }

    public String getStructureId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        return meta.getPersistentDataContainer().get(structureIdKey, PersistentDataType.STRING);
    }
}
