package com.audes.plugin.hud;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/**
 * Resolver placeholder built-in buat template HUD. SENGAJA TIDAK
 * depend ke PlaceholderAPI (project ini belum punya dependency
 * itu) -- daftar placeholder di sini murni dari data yang Bukkit API
 * sendiri sediakan. Kalau tim butuh placeholder custom lain (mis. data
 * dari plugin economy), itu perlu keputusan sadar buat nambah
 * dependency PlaceholderAPI dan extend method resolve() di sini.
 */
public final class HudPlaceholders {

    private HudPlaceholders() {}

    public static String resolve(String template, Player player) {
        return template
                .replace("%player%", player.getName())
                .replace("%health%", String.valueOf(Math.round(player.getHealth())))
                .replace("%max_health%", String.valueOf(Math.round(player.getAttribute(
                        org.bukkit.attribute.Attribute.MAX_HEALTH).getValue())))
                .replace("%food%", String.valueOf(player.getFoodLevel()))
                .replace("%world%", player.getWorld().getName())
                .replace("%online%", String.valueOf(Bukkit.getOnlinePlayers().size()))
                .replace("%level%", String.valueOf(player.getLevel()));
    }
}
