package com.audes.plugin.gui;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class GuiManager {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    public void open(Player player, GuiDefinition def) {
        AudesGuiHolder holder = new AudesGuiHolder(def.id());
        Inventory inventory = Bukkit.createInventory(holder, def.rows() * 9, LEGACY.deserialize(def.title()));
        holder.setInventory(inventory);

        for (GuiButtonDefinition button : def.buttons()) {
            inventory.setItem(button.slot(), buildItem(button));
        }

        player.openInventory(inventory);
    }

    private ItemStack buildItem(GuiButtonDefinition button) {
        ItemStack item = new ItemStack(button.material());
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            if (button.displayName() != null && !button.displayName().isBlank()) {
                meta.displayName(LEGACY.deserialize(button.displayName()));
            }
            List<String> lore = button.lore();
            if (!lore.isEmpty()) {
                meta.lore(lore.stream().map(LEGACY::deserialize).toList());
            }
            item.setItemMeta(meta);
        }
        return item;
    }
}
