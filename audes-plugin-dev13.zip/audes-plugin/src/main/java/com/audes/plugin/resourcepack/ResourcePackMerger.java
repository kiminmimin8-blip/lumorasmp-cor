package com.audes.plugin.resourcepack;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * "Resource pack manager (versioning, multi-pack merge)" +
 * "Resource pack merger" dari daftar-fitur-itemsadder.md.
 *
 * PENDEKATAN: bukan versioning/merge di level SERVER config antar-plugin
 * (itu butuh semua plugin lain "tau" soal Audes, gak realistis), tapi di
 * level FILE — admin taruh pack .zip dari plugin lain (atau texture pack
 * custom manual) di folder plugins/Audes/external-packs/, dan tiap kali
 * ResourcePackGenerator#generate() jalan, isi zip-zip itu ikut digabung
 * ke pack final Audes SEBELUM di-hash & dikirim ke player.
 *
 * ATURAN GABUNG: aset Audes sendiri (contents/) SELALU menang kalau ada
 * path yang sama persis di lebih dari satu sumber (prioritas: Audes >
 * external-packs, urut sesuai nama file .zip alfabetis). Ini mencegah
 * pack eksternal diam-diam nimpa aset Audes sendiri tanpa admin sadar —
 * konflik tetap di-log sebagai warning, bukan silent overwrite.
 */
public class ResourcePackMerger {

    private final Logger logger;

    public ResourcePackMerger(Logger logger) {
        this.logger = logger;
    }

    /**
     * @param externalPacksFolder folder berisi file .zip pack lain (boleh gak ada/kosong)
     * @param zos                 stream zip pack Audes yang LAGI DIBANGUN (belum di-close)
     * @param alreadyWritten       set nama entry yang sudah ditulis duluan (aset Audes sendiri) —
     *                             dipakai buat skip konflik, HARUS berisi entry Audes sebelum method ini dipanggil
     */
    public void mergeInto(File externalPacksFolder, ZipOutputStream zos, Set<String> alreadyWritten) throws IOException {
        if (externalPacksFolder == null || !externalPacksFolder.exists() || !externalPacksFolder.isDirectory()) {
            return; // gak ada folder external-packs, gak ada yang perlu digabung — bukan error.
        }

        File[] zipFiles = externalPacksFolder.listFiles((dir, name) -> name.toLowerCase().endsWith(".zip"));
        if (zipFiles == null || zipFiles.length == 0) return;

        java.util.Arrays.sort(zipFiles); // urutan alfabetis biar hasil gabung deterministik & bisa direproduksi.

        for (File externalZip : zipFiles) {
            mergeOneZip(externalZip, zos, alreadyWritten);
        }
    }

    private void mergeOneZip(File externalZip, ZipOutputStream zos, Set<String> alreadyWritten) throws IOException {
        int added = 0;
        int skippedConflict = 0;

        try (ZipFile zf = new ZipFile(externalZip)) {
            var entries = zf.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (entry.isDirectory()) continue;

                if (alreadyWritten.contains(entry.getName())) {
                    skippedConflict++;
                    continue; // aset Audes (atau pack eksternal sebelumnya) sudah pegang path ini duluan.
                }

                ZipEntry newEntry = new ZipEntry(entry.getName());
                zos.putNextEntry(newEntry);
                try (var in = zf.getInputStream(entry)) {
                    in.transferTo(zos);
                }
                zos.closeEntry();
                alreadyWritten.add(entry.getName());
                added++;
            }
        }

        logger.info("[Audes] Resource pack merge: '" + externalZip.getName() + "' -> " + added
                + " file digabung" + (skippedConflict > 0 ? ", " + skippedConflict + " di-skip (konflik path, aset Audes/pack lain menang)" : "") + ".");
    }
}
