package com.audes.plugin.vehicle;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.Plugin;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public class VehicleRegistry {

    private final Plugin plugin;
    private final Map<String, VehicleDefinition> vehicles = new LinkedHashMap<>();

    public VehicleRegistry(Plugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig(ConfigurationSection section) {
        vehicles.clear();
        if (section == null) return;

        for (String id : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(id);
            if (s == null) continue;

            Material material;
            try {
                material = Material.valueOf(s.getString("material", "MINECART").toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("[Audes] Material tidak valid untuk vehicle '" + id + "', di-skip.");
                continue;
            }

            vehicles.put(id, new VehicleDefinition(
                    id,
                    material,
                    s.getString("display-name", id),
                    s.getString("model", null),
                    (float) s.getDouble("scale", 1.0),
                    Math.max(0.5, s.getDouble("speed-blocks-per-second", 4.0)),
                    s.getString("place-sound", null),
                    s.getString("mount-sound", null)
            ));
        }

        plugin.getLogger().info("[Audes] " + vehicles.size() + " custom vehicle termuat dari config.");
    }

    public Optional<VehicleDefinition> get(String id) {
        return Optional.ofNullable(vehicles.get(id));
    }

    public Map<String, VehicleDefinition> getAll() {
        return vehicles;
    }
}
