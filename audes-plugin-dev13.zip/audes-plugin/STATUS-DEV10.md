# STATUS-DEV10.md

## Konfirmasi: compile kedua (Dev6-9 batch) SUKSES 🎉
User upload `Audes-0_1_0-SNAPSHOT.jar` baru, 54 class file, semua modul
armor/emoji/block.ToolTier/furniture-toggle-state ADA dan lengkap. Semua
compile risk yang dicatat Dev6-9 (`EquippableComponent`,
`Enchantment.FORTUNE`, `Component#replaceText`, `PlayerInteractEntityEvent`)
TERKONFIRMASI lolos compile. Pola "tulis manual + dokumentasikan risiko"
sejauh ini reliable.

## Yang dikerjakan sesi ini: Custom GUI ✅
Prioritas Sedang terakhir yang masuk akal untuk effort sedang (skip
"custom animated entities" — effort besar, relevansi rendah buat
EcoCPvP, lihat catatan Dev9).

- **Framework generik**, bukan satu GUI spesifik: `GuiDefinition` +
  `GuiButtonDefinition` di config.yml bagian `guis:`, tiap tombol bisa
  jalanin list command SAAT DIKLIK.
- **`AudesGuiHolder`** — custom `InventoryHolder` buat identifikasi "ini
  GUI Audes yang mana" langsung dari `event.getInventory().getHolder()`,
  SENGAJA tidak pakai `Map<UUID,String>` eksternal (rawan data basi
  kalau lupa dibersihkan pas quit/close — pelajaran dari pola yang sudah
  dipakai `CustomBlockStore` soal keterbatasan persistent state).
- **`GuiListener`** — SEMUA klik di GUI Audes di-cancel tanpa
  terkecuali (termasuk klik ke inventory player sendiri selagi GUI
  terbuka), mencegah shift-click exploit umum di GUI plugin. Ini murni
  menu tombol, bukan tempat pindah item.
- **Command**: `/audes gui <gui_id> [player]` — tanpa `[player]` buka
  untuk sender sendiri (kalau sender player), dengan `[player]` admin
  bisa buka-kan untuk orang lain.

## KETERBATASAN PENTING yang sengaja belum diselesaikan (baca sebelum pakai)
**Command tombol GUI dijalankan SEBAGAI PLAYER, bukan console.** Kalau
tombol manggil `/audes give ...` (command admin-only, lihat
`plugin.yml` — seluruh command `/audes` butuh permission `audes.admin`),
dan GUI itu dibuka untuk PLAYER BIASA (bukan admin/op), tombolnya akan
GAGAL dengan permission denied walau GUI-nya sendiri kebuka normal.

Ini BUKAN bug tersembunyi -- sudah didokumentasikan jelas di komentar
`config.yml` bagian `guis:` dan di sini. Alasan desain: command
dijalankan sebagai player (bukan console/OP) itu KEPUTUSAN KEAMANAN
sengaja (lihat javadoc `GuiButtonDefinition`) supaya GUI tidak otomatis
jadi celah privilege-escalation. Konsekuensinya: kalau tim mau GUI
shop/menu yang dipakai PLAYER UMUM (bukan admin), config-nya harus diisi
command yang player memang punya izin, ATAU dev berikutnya perlu nambah
opsi eksplisit "run-as-console" per tombol (dengan risiko keamanan yang
harus di-declare jelas kalau opsi itu dipakai).

## COMPILE RISK sesi ini
Rendah. Semua API yang dipakai (`InventoryHolder`, `InventoryClickEvent`,
`Bukkit.createInventory(holder, size, Component)`, `Bukkit.dispatchCommand`)
API lama & stabil, sudah dipakai luas di ekosistem plugin Bukkit selama
bertahun-tahun. Satu-satunya bagian yang agak baru: `createInventory`
dengan parameter title `Component` (bukan `String` legacy) — kemungkinan
besar aman karena Paper API sudah lama support Component untuk title
inventory, tapi tetap dicatat sesuai konvensi jujur project ini.

## Rekomendasi urutan kerja dev berikutnya
1. Compile ulang, konfirmasi GUI framework ini lolos.
2. Test manual: buka GUI, klik tombol, konfirmasi command jalan dan
   permission behave seperti yang didokumentasikan di atas.
3. Sisa fitur di `daftar-fitur-itemsadder.md` yang belum dikerjakan
   sekarang tinggal **Custom animated entities** (effort besar) dan
   beberapa item prioritas Rendah (custom vehicle, scripting language
   internal, dll) — evaluasi bareng tim apakah masih worth dikerjakan,
   atau fokus geser ke stabilisasi/testing semua modul yang sudah ada
   dulu (10 sesi dev sudah numpuk banyak fitur, belum ada testing
   end-to-end di server beneran selain compile check).
