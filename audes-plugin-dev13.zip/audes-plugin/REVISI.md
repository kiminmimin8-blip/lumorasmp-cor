# Revisi Audes (sesi saya — Dev12 + Dev13)

Rangkuman singkat, detail lengkap tetap di `STATUS-DEV12.md` dan
`STATUS-DEV13.md` masing-masing.

## Dev12 — nutup limitasi GUI
- Command tombol GUI defaultnya jalan sebagai player (Dev10). Ditambah
  tag `[console]` per baris buat opt-in jalanin baris tertentu sebagai
  console, tanpa ubah default yang udah ada.

## Dev13 — 4 modul baru + 2 fitur di-extend

**Modul baru:**
- `emote/` — `/emote <id>`, teks ngambang di atas kepala, bisa animasi
  (cycling text-frames buat efek rainbow/berkedip).
- `structure/` — `/audes givestructure`, custom tree & decoration
  cluster (multi-block, all-or-nothing), reuse penuh sistem
  `custom-block` yang udah ada.
- `vehicle/` — `/audes givevehicle`, mounting + auto-drive
  disederhanakan (maju sesuai arah pandang, sneak = rem/turun).
- `entity/` — `/audes givemobitem`, mob asli (AI/hitbox vanilla) +
  overlay ItemDisplay yang dianimasikan lewat pose cycling.
- `hud/` — `/audes hud <id> [player]`, Custom HUD pakai BossBar/ActionBar
  bawaan Bukkit (BUKAN pixel HUD custom font kayak ItemsAdder asli —
  ini sempat kelupaan di pass pertama, baru ditambahin belakangan).

**Di-extend:**
- Resource pack manager/merger — gabung pack `.zip` eksternal dari
  `external-packs/`, plus versioning (counter file).
- Tag `[if_perm:<permission>]` di command GUI, bisa digabung dengan
  `[console]` — scripting minimal (BUKAN bahasa scripting penuh).

**Didokumentasikan sebagai gak mungkin dikerjakan** (bukan males —
limitasi teknis nyata, alasan lengkap di STATUS-DEV13.md):
- Custom liquid
- Colored fire
- Resource pack protector (anti-ekstraksi)

## Status compile
**Belum pernah di-compile** — sandbox saya gak ada akses internet buat
Maven download `paper-api`. Sudah dicek manual: brace balance semua
file `.java` OK, `config.yml`/`plugin.yml` divalidasi pakai YAML parser
(valid). WAJIB `mvn clean package` + test manual di server nyata
sebelum deploy, terutama modul `vehicle` dan `entity` (paling baru,
paling belum pernah disentuh server asli).
