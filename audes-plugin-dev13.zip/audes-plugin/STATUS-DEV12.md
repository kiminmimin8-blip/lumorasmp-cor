# STATUS-DEV12.md

## Yang dikerjakan sesi ini: nutup keterbatasan GUI (Dev10)

Dev10 mendokumentasikan tapi sengaja TIDAK menyelesaikan: command tombol
GUI jalan sebagai player, jadi GUI berisi command admin-only gagal kalau
dibuka player biasa. Sesi ini nambah opsi eksplisit buat itu.

**Opt-in run-as-console PER BARIS command**, bukan per-tombol/per-GUI:
- Baris command yang diawali `[console] ` (case-insensitive) di-strip
  prefix-nya dan dijalankan lewat `Bukkit.dispatchCommand(Bukkit.getConsoleSender(), ...)`.
- Baris lain di tombol yang sama (tanpa prefix itu) tetap jalan sebagai
  player seperti biasa — jadi satu tombol boleh campur (mis. 1 baris
  `[console] give ...` buat kasih item, 1 baris `tell %player% ...` buat
  notifikasi biasa).
- Default TIDAK BERUBAH — tombol yang config-nya belum dikasih prefix
  `[console]` tetap jalan sebagai player persis kayak sebelumnya. Ini
  murni penambahan opsi, bukan perubahan behavior lama.
- File yang diubah: `GuiListener.java` (logic dispatch),
  `GuiButtonDefinition.java` (javadoc), `config.yml` (contoh penggunaan
  di bagian `guis:`, ada 1 contoh admin-only default dan 1 contoh
  run-as-console).

**Kenapa per-baris, bukan per-tombol**: dipertimbangkan bikin field
`runAsConsole: true` per tombol, tapi itu berarti SEMUA command di
tombol itu ke-elevate sekaligus — kurang presisi. Prefix per-baris kasih
kontrol lebih halus dan bikin config-nya self-documenting (langsung
kelihatan baris mana yang di-elevate tanpa buka dokumentasi lain).

## Belum di-compile

Sama seperti sesi-sesi sebelumnya, sandbox ini gak ada akses internet
buat Maven download `paper-api`, jadi perubahan ini belum ke-compile.
Udah dicek manual: brace balance semua 59 file `.java` OK, API yang
dipake (`Bukkit.getConsoleSender()`, `String.regionMatches`) API lama
& stabil, compile risk dinilai RENDAH. Tetap perlu `mvn clean package`
di mesin ber-internet buat konfirmasi final sebelum deploy.

## Sisa prioritas (belum berubah dari daftar-fitur-itemsadder.md)

1. Compile ulang beneran (blocker semua verifikasi sejak Dev10).
2. Deploy & test manual di server nyata — terutama custom block/noteblock
   override (Dev11) yang paling berisiko ada gap antara "kelihatan benar
   di kode" vs "kelihatan benar di game".
3. **Custom animated entities** dan sisa item prioritas Rendah — ini
   keputusan produk (worth dikerjakan atau di-skip buat EcoCPvP), bukan
   sesuatu yang bisa saya putusin sepihak. Tanya balik ke tim/user dulu
   sebelum dev berikutnya lanjut ke situ.
4. Ganti texture placeholder dengan aset final sebelum production.
