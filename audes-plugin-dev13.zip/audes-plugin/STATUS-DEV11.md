# STATUS-DEV11.md

## Yang dikerjakan sesi ini: Isi Resource Pack ✅
Sebelumnya `ResourcePackModule` cuma infrastruktur (generator, hosting,
manifest) TANPA ada aset nyata di dalamnya — semua `modelKey`/`asset`
yang direferensikan `config.yml` selalu fallback vanilla + warning di
log karena filenya memang belum ada. Sesi ini isi folder `contents/`
LENGKAP untuk semua contoh di config.yml bawaan.

## Yang dibuat
1. **Item model + texture placeholder** untuk 6 item (tools/blocks/furniture)
   — `assets/audes/items/*.json` + `assets/audes/models/item/*.json` +
   `assets/audes/textures/item/*.png` (16x16, bentuk diamond warna solid,
   digenerate pakai PIL biar valid PNG, bukan cuma file kosong).
2. **Equipment model + texture placeholder** untuk armor —
   `assets/audes/equipment/armor/zirah_petir.json` + texture 64x32.
3. **`pack.mcmeta`** — `pack_format: 75` (dikonfirmasi lewat web search
   untuk 1.21.11) + `min_format`/`max_format` (format baru pasca 25w31a,
   ditulis dua-duanya buat kompatibilitas client lama & baru).
4. **`pack.png`** — icon placeholder.
5. **PALING PENTING**: `assets/minecraft/blockstates/note_block.json`
   — override blockstate VANILLA (bukan namespace audes), berisi 800
   variant kombinasi instrument×note×powered. 4 di antaranya (2 kombinasi
   × 2 powered state) dipetakan ke block model custom, SISANYA fallback
   ke `minecraft:block/note_block` supaya note block biasa di server
   tidak ikut berubah. **Ini bagian yang bikin custom block BENERAN
   keliatan beda di dunia** (sebelumnya cuma icon di tangan yang custom,
   block yang sudah di-place tetap note block vanilla polos).
6. **Block model** (`cube_all`) untuk 2 custom block yang ada di config,
   textures-nya REUSE file texture item yang sama (tidak duplikat PNG).
7. **Script generator** dipindah ke `scripts/resourcepack/` di dalam
   project (bukan cuma dipakai sekali terus dibuang) — `build_pack.py`,
   `build_equipment.py`, `build_icon.py`, `build_noteblock_override.py`.
   Path di-patch supaya resolve relatif ke lokasi script sendiri (aman
   dijalankan dari direktori manapun, dites ulang dan masih jalan).
8. **`contents/README-RESOURCEPACK.md`** — panduan deploy + tabel
   mapping config↔file + peringatan soal placeholder.

## RISIKO YANG BELUM DIVERIFIKASI (baca sebelum production)
1. **Mapping nama instrument Bukkit → string blockstate vanilla**
   (mis. `PIANO`→`harp`, `BASS_GUITAR`→`bass`) — dikonfirmasi dari riset
   dokumentasi, TAPI belum ditest langsung di server + client beneran.
   Kalau custom block ternyata tetap tampil note block vanilla polos
   setelah pack diterapkan, cek di sini duluan.
2. **Dimensi texture equipment (64x32)** — diasumsikan sama dengan
   layout `armor_layer_1.png` legacy, karena sistem equipment 1.21.2+
   didesain kompatibel visual. Belum diverifikasi apakah benar masih
   64x32 atau berubah ke ukuran lain di versi terbaru.
3. **`item/generated` sebagai parent model furniture** — ItemDisplay
   yang render model flat (`item/generated`) akan terlihat seperti
   "kartu tipis melayang", BUKAN objek 3D solid. Ini bukan bug, tapi
   keterbatasan model placeholder — furniture beneran butuh model 3D
   custom (parent model kustom dengan geometri "elements", bukan
   `item/generated`/`item/handheld`) yang di luar cakupan sesi ini
   (butuh software modeling 3D seperti Blockbench, bukan sesuatu yang
   bisa di-generate otomatis lewat script).

## Yang SENGAJA belum dikerjakan
- **Texture asli/final** — semua PNG di sini placeholder warna solid,
  bukan seni final. WAJIB diganti tim artist sebelum production (lihat
  `README-RESOURCEPACK.md`).
- **Model 3D custom untuk furniture** — lihat poin risiko #3 di atas.
- **Sound custom** — semua `break-sound`/`place-sound`/`toggle-sound`
  di config.yml masih pakai `Sound` enum vanilla Bukkit (mis.
  `BLOCK_STONE_BREAK`), BUKAN sound custom dari resource pack. Kalau
  tim butuh sound custom, itu perlu `sounds.json` + file `.ogg` di
  `assets/audes/sounds/` dan perubahan di `BlockRegistry`/dsb buat baca
  namespaced sound key alih-alih `Sound.valueOf()` — belum dikerjakan.

## Rekomendasi urutan kerja dev berikutnya
1. Compile ulang (walau sesi ini TIDAK ada perubahan kode Java, cuma
   aset resource pack — tapi tetap worth diverifikasi bareng kalau ada
   perubahan lain yang menumpuk).
2. Deploy `contents/` ke server test, verifikasi custom block BENERAN
   berubah tampilan (bukan cuma icon di tangan) — ini validasi paling
   penting dari sesi ini yang belum bisa dites di sandbox.
3. Kalau instrument mapping ternyata salah, cek F3 debug screen di
   server buat lihat nilai blockstate instrument yang sebenarnya, lalu
   perbaiki `BUKKIT_TO_BLOCKSTATE` di `build_noteblock_override.py`.
