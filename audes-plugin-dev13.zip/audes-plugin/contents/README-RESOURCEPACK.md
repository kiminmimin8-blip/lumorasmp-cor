# README — Resource Pack Audes (`contents/`)

## Apa isinya
Folder ini adalah folder `contents/` yang harus ditaruh di
`plugins/Audes/contents/` di server (BUKAN bagian dari build Maven —
`ResourcePackModule` yang membaca folder ini langsung dari data folder
plugin saat `enable()`, lihat `ResourcePackGenerator`).

Sudah dibuatkan LENGKAP untuk SEMUA `model`/`asset` yang direferensikan
di `config.yml` contoh bawaan plugin:

| Config key | modelKey/asset | File yang dibuat |
|---|---|---|
| `tools.contoh_pedang_petir` | `audes:tools/pedang_petir` | item model + texture |
| `blocks.contoh_batu_audes` | `audes:blocks/batu_audes` | item model + texture + **block model + note_block override** |
| `blocks.contoh_bijih_audes` | `audes:blocks/bijih_audes` | item model + texture + **block model + note_block override** |
| `furniture.contoh_kursi_kayu` | `audes:furniture/kursi_kayu` | item model + texture |
| `furniture.contoh_lampu_audes` (states) | `audes:furniture/lampu_mati` + `lampu_nyala` | item model + texture (2 state) |
| `armor.contoh_zirah_petir` | `audes:armor/zirah_petir` | equipment model + texture |

## ⚠️ SEMUA TEXTURE DI SINI PLACEHOLDER
Texture di `assets/audes/textures/` cuma bentuk diamond warna solid
(digenerate otomatis buat memastikan pack VALID dan LENGKAP secara
struktur), **BUKAN seni final**. Sebelum dipakai production, tim artist
WAJIB ganti semua file `.png` di bawah ini dengan tekstur asli:
- `assets/audes/textures/item/**/*.png` (6 file, 16x16)
- `assets/audes/textures/entity/equipment/armor/zirah_petir.png` (64x32)
- `pack.png` (128x128, icon pack)

JSON model & blockstate TIDAK PERLU diubah kalau cuma ganti texture
(selama nama file PNG tetap sama) — cukup timpa isinya.

## Bagian PALING PENTING: `assets/minecraft/blockstates/note_block.json`
Ini file yang bikin custom block BENERAN keliatan beda di dunia (bukan
cuma icon-nya di tangan). File ini **override blockstate vanilla**
`note_block` — berisi 800 variant (16 instrument x 25 note x 2 powered
state), 4 di antaranya (2 kombinasi instrument+note x 2 powered state)
dipetakan ke block model custom (`audes:block/batu_audes` dan
`audes:block/bijih_audes`), sisanya fallback ke `minecraft:block/note_block`
vanilla biar note block BIASA di server (yang bukan custom block Audes)
tidak ikut berubah.

**KALAU NAMBAH CUSTOM BLOCK BARU DI CONFIG.YML, WAJIB TAMBAH VARIANT
BARU DI FILE INI JUGA** — plugin tidak otomatis generate bagian ini
(beda dari item model yang otomatis divalidasi lewat
`ResourcePackManifest`). Cara paling gampang: edit ulang
`build_noteblock_override.py` (ada di root project, bukan di dalam
`contents/`) dengan nambah entry baru ke dict `CUSTOM_BLOCKS`, lalu
jalankan ulang scriptnya.

**RISIKO YANG PERLU DITES MANUAL** (belum diverifikasi di server
beneran): mapping nama instrument Bukkit → string blockstate vanilla
(mis. `PIANO` → `harp`, `BASS_GUITAR` → `bass`) dikonfirmasi dari riset
dokumentasi, TAPI belum ditest langsung. Kalau block custom ternyata
TETAP tampil sebagai note block vanilla polos setelah pack diterapkan,
kemungkinan besar penyebabnya di sini — cek nama instrument yang benar
lewat F3 (debug screen) saat berdiri di atas note block yang dimaksud.

## Cara deploy
1. Copy seluruh isi folder `contents/` ini ke `plugins/Audes/contents/`
   di server (bikin folder itu kalau belum ada).
2. Restart/reload plugin — `ResourcePackModule` otomatis generate
   `audes-pack.zip` dari folder ini dan mulai serve ke player yang join.
3. Ganti semua placeholder sebelum production (lihat bagian di atas).
4. Kalau nambah item/block/furniture/armor baru di `config.yml`,
   selalu bikin file model + texture yang sesuai di sini juga —
   `ResourcePackManifest` akan warning di console (bukan error/crash)
   kalau ada modelKey yang tidak ketemu filenya.
