# Patch notes — fix build error + lengkapin equipment armor

Extract zip ini ke root repo (timpa file yang sama), commit, push biar
workflow GitHub Actions compile ulang.

## File yang diubah

1. `src/main/java/com/audes/plugin/gui/GuiRegistry.java`
   Fix compile error di baris `name = String.valueOf(raw.getOrDefault("name", ""))`.
   `raw` bertipe `Map<?, ?>` (wildcard), jadi `getOrDefault` menolak literal
   `String` sebagai default value karena gak match capture type-nya.
   Diganti ke `raw.get("name")` + null-check manual, sama pola kayak
   `materialRaw` di baris sebelumnya. Ini yang bikin build kemarin gagal
   dengan error:
   `[ERROR] GuiRegistry.java:[83,67] incompatible types: java.lang.String cannot be converted to capture#1 of ?`

2. `src/main/resources/config.yml`
   Section `armor:` dilengkapin dari 1 piece (`contoh_zirah_petir`,
   chestplate doang) jadi full 4-piece set: `zirah_petir_helmet`,
   `zirah_petir_chestplate`, `zirah_petir_leggings`, `zirah_petir_boots`.
   Semua nunjuk ke `asset` yang sama (`audes:armor/zirah_petir`) — ini
   memang cara kerja native equippable component, satu model asset
   dipakai semua slot, engine yang milih layer sesuai slot armor.

3. `scripts/resourcepack/build_equipment.py`
   Ditambah generate layer kedua (`humanoid_leggings`) + texture kedua
   (`zirah_petir_legs.png`). Tanpa ini, leggings tetap bisa di-equip
   secara fungsional (armor value/enchant jalan normal) tapi teksturnya
   bisa kosong di area paha-betis karena leggings pakai UV layout beda
   dari helm/chest/boots. Sudah ditest jalan lokal, output:
   - `contents/assets/audes/equipment/armor/zirah_petir.json` (2 layer)
   - `contents/assets/audes/textures/entity/equipment/armor/zirah_petir.png`
   - `contents/assets/audes/textures/entity/equipment/armor/zirah_petir_legs.png`

   Kalau workflow lu manggil script ini otomatis pas build resourcepack,
   gak perlu action tambahan. Kalau resourcepack di-generate manual/lokal,
   jalanin ulang script ini abis extract patch, biar texture leggings-nya
   ke-generate.

## Belum ditest

Fix #1 udah pasti valid secara sintaks Java (perubahan minor, pola sama
persis kayak baris di atasnya yang udah kompilasi normal). Fix #2 & #3
belum ditest render in-game (armor value/texture beneran nongol pas
dipakein) — perlu deploy ke server nyata buat verifikasi visual.
