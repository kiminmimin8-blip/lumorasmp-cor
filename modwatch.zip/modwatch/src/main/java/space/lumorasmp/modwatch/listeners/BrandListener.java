package space.lumorasmp.modwatch.listeners;

import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;
import space.lumorasmp.modwatch.ModWatchPlugin;
import space.lumorasmp.modwatch.data.PlayerData;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

/**
 * Nangkep string "brand" yang dikirim client saat login (vanilla, fabric, forge, dll).
 *
 * PENTING: ini BUKAN deteksi cheat client. Client seperti Meteor/Wurst/dll secara default
 * ngirim brand "vanilla" biar gak ketauan dari sini. Yang berguna dari data ini cuma buat:
 * 1) Nangkep pemain yang lupa/gak sempet spoof brand-nya (masih ada, apalagi pemain awam)
 * 2) Statistik umum: berapa % player pakai Fabric/Forge/dll di server lo
 * Deteksi yang lebih diandelin ada di CombatListener (pola perilaku).
 */
public class BrandListener implements PluginMessageListener {

    private final ModWatchPlugin plugin;

    public BrandListener(ModWatchPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void onPluginMessageReceived(String channel, Player player, byte[] message) {
        if (!channel.equals("minecraft:brand")) return;

        String brand = readBrand(message);
        if (brand == null) return;

        PlayerData data = plugin.getData(player);
        data.clientBrand = brand;

        String normalized = brand.toLowerCase();
        if (!normalized.contains("vanilla") && !normalized.isBlank()) {
            // brand non-vanilla itu wajar (fabric/forge buat mod visual, dll), cuma dicatat.
            plugin.getLogger().info("[Brand] " + player.getName() + " -> " + brand);
        }
    }

    private String readBrand(byte[] message) {
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(message))) {
            return in.readUTF();
        } catch (IOException e) {
            return null;
        }
    }
}
