package space.lumorasmp.modwatch;

import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import space.lumorasmp.modwatch.commands.ModWatchCommand;
import space.lumorasmp.modwatch.commands.ModsCommand;
import space.lumorasmp.modwatch.commands.SusCommand;
import space.lumorasmp.modwatch.data.PlayerData;
import space.lumorasmp.modwatch.listeners.BrandListener;
import space.lumorasmp.modwatch.listeners.ChannelListener;
import space.lumorasmp.modwatch.listeners.CombatListener;
import space.lumorasmp.modwatch.listeners.JoinQuitListener;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ModWatchPlugin extends JavaPlugin {

    private static ModWatchPlugin instance;

    // registry per-player, thread-safe karena brand channel & combat event bisa
    // kepanggil dari thread berbeda kalau server pakai Folia region threads.
    private final Map<UUID, PlayerData> registry = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        getServer().getMessenger().registerIncomingPluginChannel(this, "minecraft:brand", new BrandListener(this));

        getServer().getPluginManager().registerEvents(new JoinQuitListener(this), this);
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new ChannelListener(this), this);

        ModWatchCommand cmd = new ModWatchCommand(this);
        getCommand("modwatch").setExecutor(cmd);
        getCommand("modwatch").setTabCompleter(cmd);

        ModsCommand modsCmd = new ModsCommand(this);
        getCommand("mods").setExecutor(modsCmd);
        getCommand("mods").setTabCompleter(modsCmd);

        SusCommand susCmd = new SusCommand(this);
        getCommand("sus").setExecutor(susCmd);
        getCommand("sus").setTabCompleter(susCmd);

        getLogger().info("ModWatch aktif. Ingat: ini alat bantu logging & deteksi pola, bukan pengganti GrimAC.");
    }

    @Override
    public void onDisable() {
        registry.clear();
    }

    public static ModWatchPlugin getInstance() {
        return instance;
    }

    public PlayerData getData(Player player) {
        return registry.computeIfAbsent(player.getUniqueId(), PlayerData::new);
    }

    public PlayerData getDataIfPresent(UUID uuid) {
        return registry.get(uuid);
    }

    public void removeData(UUID uuid) {
        registry.remove(uuid);
    }

    public Map<UUID, PlayerData> getRegistry() {
        return registry;
    }

    /** Kirim pesan ke semua staff yang punya permission modwatch.alert */
    public void alertStaff(String message) {
        String formatted = org.bukkit.ChatColor.RED + "[ModWatch] " + org.bukkit.ChatColor.YELLOW + message;
        for (Player p : getServer().getOnlinePlayers()) {
            if (p.hasPermission("modwatch.alert")) {
                p.sendMessage(formatted);
            }
        }
        getServer().getConsoleSender().sendMessage(formatted);
    }
}
