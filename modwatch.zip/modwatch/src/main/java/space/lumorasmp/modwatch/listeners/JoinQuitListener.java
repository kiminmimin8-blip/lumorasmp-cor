package space.lumorasmp.modwatch.listeners;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import space.lumorasmp.modwatch.ModWatchPlugin;

public class JoinQuitListener implements Listener {

    private final ModWatchPlugin plugin;

    public JoinQuitListener(ModWatchPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        plugin.getData(e.getPlayer()); // init entry
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        // dilepas beberapa saat biar staff masih bisa /modwatch cek riwayat sesaat sebelum quit.
        // Kalau server rame & mau hemat memori, boleh langsung plugin.removeData(...) di sini.
    }
}
