package space.lumorasmp.modwatch.commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import space.lumorasmp.modwatch.ModWatchPlugin;
import space.lumorasmp.modwatch.data.PlayerData;

import java.util.ArrayList;
import java.util.List;

public class ModsCommand implements CommandExecutor, TabCompleter {

    private final ModWatchPlugin plugin;

    public ModsCommand(ModWatchPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("modwatch.use")) {
            sender.sendMessage(ChatColor.RED + "Lo gak punya izin buat command ini.");
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(ChatColor.YELLOW + "Pakai: /mods <nama_player>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player gak online / gak ketemu.");
            return true;
        }

        PlayerData data = plugin.getData(target);
        sender.sendMessage(ChatColor.GOLD + "=== Mods terdeteksi: " + target.getName() + " ===");
        sender.sendMessage(ChatColor.GRAY + "Client brand: " + ChatColor.WHITE + data.clientBrand);

        if (data.getChannels().isEmpty()) {
            sender.sendMessage(ChatColor.GRAY + "Belum ada plugin channel yang terdaftar "
                    + "(bisa berarti vanilla polos, atau client yang gak pakai sistem channel mod).");
        } else {
            sender.sendMessage(ChatColor.GRAY + "Channel terdaftar (" + data.getChannels().size() + "):");
            for (String ch : data.getChannels()) {
                boolean flagged = data.getWatchlistMatches().contains(ch);
                ChatColor color = flagged ? ChatColor.RED : ChatColor.WHITE;
                String tag = flagged ? ChatColor.RED + " [WATCHLIST]" : "";
                sender.sendMessage(ChatColor.DARK_GRAY + " - " + color + ch + tag);
            }
        }

        sender.sendMessage(ChatColor.DARK_GRAY
                + "Catatan: cuma mod yang daftar channel networking yang kelihatan di sini. "
                + "Client internal/injected bisa aja gak kelihatan sama sekali.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> options = new ArrayList<>();
        if (args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                options.add(p.getName());
            }
        }
        return options;
    }
}
