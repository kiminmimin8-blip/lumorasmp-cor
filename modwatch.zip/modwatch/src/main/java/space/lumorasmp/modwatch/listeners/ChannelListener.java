package space.lumorasmp.modwatch.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRegisterChannelEvent;
import space.lumorasmp.modwatch.ModWatchPlugin;
import space.lumorasmp.modwatch.data.PlayerData;

import java.util.List;

/**
 * Banyak mod (Fabric/Forge) otomatis "daftar" plugin channel sendiri pas connect ke server
 * (biasanya buat sinkronisasi data mod, cek versi, dll). Server bisa lihat daftar channel ini
 * lewat PlayerRegisterChannelEvent -- ini API resmi Bukkit, bukan exploit, dan gak bisa
 * di-spoof semudah brand string karena nempel ke cara kerja mod-nya sendiri.
 *
 * CATATAN JUJUR:
 * - Ini nangkep MOD yang pakai sistem networking channel (kebanyakan mod Fabric/Forge "legit").
 * - Client cheat yang berupa "client internal/injected" (bukan mod yang di-load via
 *   Fabric/Forge loader) BISA JADI gak daftar channel apapun, jadi gak selalu kelihatan.
 * - Kami TIDAK menyertakan daftar channel spesifik cheat client karena signature-nya sering
 *   berubah & kalau salah tebak bisa bikin tuduhan salah ke pemain yang gak bersalah.
 *   Isi sendiri "known-cheat-channels" di config.yml begitu lo temuin pola nyata dari
 *   investigasi manual (misal cross-check sama recording/replay pas ada laporan cheat).
 */
public class ChannelListener implements Listener {

    private final ModWatchPlugin plugin;

    public ChannelListener(ModWatchPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onRegister(PlayerRegisterChannelEvent e) {
        if (!(e.getPlayer() instanceof Player player)) return;

        String channel = e.getChannel();
        PlayerData data = plugin.getData(player);
        boolean isNew = !data.getChannels().contains(channel);
        data.addChannel(channel);

        if (!isNew) return;

        List<String> watchlist = plugin.getConfig().getStringList("known-cheat-channels");
        for (String watched : watchlist) {
            if (channel.equalsIgnoreCase(watched)) {
                data.addWatchlistMatch(channel);
                data.addFlag(10);
                plugin.getLogger().warning("[Channel] " + player.getName()
                        + " mendaftarkan channel di watchlist: " + channel
                        + " (skor curiga: " + data.flagScore + ")");
                plugin.alertStaff(player.getName() + " mendaftarkan channel watchlist: " + channel);
                return;
            }
        }

        if (plugin.getConfig().getBoolean("log-brand-changes", true)) {
            plugin.getLogger().info("[Channel] " + player.getName() + " register: " + channel);
        }
    }
}
