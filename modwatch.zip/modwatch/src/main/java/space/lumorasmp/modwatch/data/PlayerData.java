package space.lumorasmp.modwatch.data;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Menyimpan data pantauan untuk satu pemain.
 * clientBrand: string yang dikirim client lewat channel "minecraft:brand".
 * clickTimestamps: dipakai buat hitung CPS (click per second).
 * flagScore: akumulasi "poin curiga" dari berbagai deteksi. Bukan vonis pasti,
 *            cuma sinyal buat staff cek manual (misal lewat spectator / replay).
 */
public class PlayerData {

    public final UUID uuid;
    public String clientBrand = "unknown";
    public int flagScore = 0;
    public boolean staffAlerted = false;

    private final Set<String> registeredChannels = new LinkedHashSet<>();
    private final Set<String> matchedWatchlistChannels = new LinkedHashSet<>();

    public void addChannel(String channel) {
        registeredChannels.add(channel);
    }

    public Set<String> getChannels() {
        return registeredChannels;
    }

    public void addWatchlistMatch(String channel) {
        matchedWatchlistChannels.add(channel);
    }

    public Set<String> getWatchlistMatches() {
        return matchedWatchlistChannels;
    }

    private final Deque<Long> clickTimestamps = new ArrayDeque<>();
    private final Deque<Float> yawDeltas = new ArrayDeque<>();

    private float lastYaw = 0f;
    private float lastPitch = 0f;
    private long lastAttackTime = 0L;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
    }

    public void recordClick(long now) {
        clickTimestamps.addLast(now);
        // buang timestamp yang lebih tua dari 1 detik
        while (!clickTimestamps.isEmpty() && now - clickTimestamps.peekFirst() > 1000) {
            clickTimestamps.pollFirst();
        }
    }

    public int getCurrentCps() {
        return clickTimestamps.size();
    }

    public void recordRotation(float yaw, float pitch) {
        this.lastYaw = yaw;
        this.lastPitch = pitch;
    }

    public float getLastYaw() {
        return lastYaw;
    }

    public float getLastPitch() {
        return lastPitch;
    }

    public long getLastAttackTime() {
        return lastAttackTime;
    }

    public void setLastAttackTime(long t) {
        this.lastAttackTime = t;
    }

    public void addYawDeltaSample(float delta) {
        yawDeltas.addLast(delta);
        if (yawDeltas.size() > 20) {
            yawDeltas.pollFirst();
        }
    }

    public Deque<Float> getYawDeltas() {
        return yawDeltas;
    }

    public void addFlag(int amount) {
        this.flagScore += amount;
    }
}
