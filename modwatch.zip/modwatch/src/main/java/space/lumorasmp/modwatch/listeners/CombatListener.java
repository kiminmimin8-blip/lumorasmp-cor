package space.lumorasmp.modwatch.listeners;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.util.Vector;
import space.lumorasmp.modwatch.ModWatchPlugin;
import space.lumorasmp.modwatch.data.PlayerData;

import java.util.Deque;

/**
 * Deteksi pola pukulan yang gak wajar secara manusiawi:
 *
 * 1) CPS ekstrem & terlalu konsisten -> indikasi autoclicker.
 * 2) Selisih sudut hadap vs arah ke target terlalu KECIL terus-menerus (nyaris 0.00 derajat
 *    di banyak hit berturut-turut) -> indikasi aimbot/killaura (manusia natural selalu ada jitter).
 * 3) Selisih sudut hadap vs arah ke target terlalu BESAR tapi tetap kena hit -> indikasi
 *    hit-nya gak lewat swing normal (killaura no-rotation / reach-hack varian).
 *
 * Semua threshold di sini konservatif & cuma nambah flagScore, TIDAK auto-kick/ban.
 * Silakan disambungin ke sistem punishment lo sendiri (misal alert staff dulu, manual review).
 */
public class CombatListener implements Listener {

    private final ModWatchPlugin plugin;

    private static final int CPS_FLAG_THRESHOLD = 18;
    private static final double SNAP_ANGLE_SUSPICIOUS_LOW = 1.5;   // derajat, terlalu presisi
    private static final double SNAP_ANGLE_SUSPICIOUS_HIGH = 55.0; // derajat, kena hit tapi gak nengok target

    public CombatListener(ModWatchPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player attacker)) return;

        PlayerData data = plugin.getData(attacker);
        long now = System.currentTimeMillis();

        // --- 1) CPS check ---
        data.recordClick(now);
        int cps = data.getCurrentCps();
        if (cps >= CPS_FLAG_THRESHOLD) {
            data.addFlag(1);
            plugin.getLogger().warning("[CPS] " + attacker.getName() + " CPS=" + cps
                    + " (skor curiga: " + data.flagScore + ")");
        }

        // --- 2) Angle check ---
        Location eye = attacker.getEyeLocation();
        Location targetLoc = e.getEntity().getLocation();
        Vector toTarget = targetLoc.toVector().subtract(eye.toVector()).normalize();
        Vector facing = eye.getDirection().normalize();

        double dot = Math.max(-1.0, Math.min(1.0, facing.dot(toTarget)));
        double angleDeg = Math.toDegrees(Math.acos(dot));

        if (angleDeg >= SNAP_ANGLE_SUSPICIOUS_HIGH) {
            // kena hit padahal gak beneran ngadep target -> paling mencurigakan
            data.addFlag(3);
            plugin.getLogger().warning("[Angle] " + attacker.getName()
                    + " hit dengan selisih hadap " + String.format("%.1f", angleDeg)
                    + " derajat (skor curiga: " + data.flagScore + ")");
        } else {
            data.addYawDeltaSample((float) angleDeg);
            Deque<Float> samples = data.getYawDeltas();
            if (samples.size() >= 12) {
                double avg = samples.stream().mapToDouble(Float::doubleValue).average().orElse(999);
                double variance = samples.stream()
                        .mapToDouble(v -> Math.pow(v - avg, 2)).average().orElse(999);
                double stdDev = Math.sqrt(variance);
                // presisi tinggi + variasi nyaris nol berkali-kali = kemungkinan aimbot/silent-aim
                if (avg <= SNAP_ANGLE_SUSPICIOUS_LOW && stdDev <= 0.4) {
                    data.addFlag(2);
                    plugin.getLogger().warning("[Aim] " + attacker.getName()
                            + " pola sudut hit terlalu presisi (avg=" + String.format("%.2f", avg)
                            + ", stdev=" + String.format("%.2f", stdDev)
                            + ") (skor curiga: " + data.flagScore + ")");
                }
            }
        }

        data.setLastAttackTime(now);

        int threshold = plugin.getConfig().getInt("alert-staff-threshold", 6);
        if (!data.staffAlerted && data.flagScore >= threshold) {
            data.staffAlerted = true;
            plugin.alertStaff(attacker.getName() + " skor curiga udah nyampe " + data.flagScore
                    + " (cek /sus " + attacker.getName() + ")");
        }
    }
}
