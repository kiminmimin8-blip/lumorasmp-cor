package space.lumorasmp.modwatch.commands;

import org.bukkit.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import space.lumorasmp.modwatch.ModWatchPlugin;
import space.lumorasmp.modwatch.data.PlayerData;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

public class ModWatchCommand implements CommandExecutor, TabCompleter {

    private final ModWatchPlugin plugin;

    public ModWatchCommand(ModWatchPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("modwatch.use")) {
            sender.sendMessage(ChatColor.RED + "Lo gak punya izin buat command ini.");
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(ChatColor.YELLOW + "Pakai: /modwatch <list|nama_player>");
            return true;
        }

        if (args[0].equalsIgnoreCase("list")) {
            List<Map.Entry<UUID, PlayerData>> sorted = plugin.getRegistry().entrySet().stream()
                    .filter(en -> en.getValue().flagScore > 0)
                    .sorted((a, b) -> b.getValue().flagScore - a.getValue().flagScore)
                    .limit(15)
                    .collect(Collectors.toList());

            if (sorted.isEmpty()) {
                sender.sendMessage(ChatColor.GREEN + "Belum ada pemain dengan skor curiga saat ini.");
                return true;
            }

            sender.sendMessage(ChatColor.GOLD + "=== Top pemain skor curiga ===");
            for (Map.Entry<UUID, PlayerData> entry : sorted) {
                Player p = Bukkit.getPlayer(entry.getKey());
                String name = p != null ? p.getName() : entry.getKey().toString();
                sender.sendMessage(ChatColor.YELLOW + name + ChatColor.GRAY + " -> skor "
                        + ChatColor.RED + entry.getValue().flagScore
                        + ChatColor.GRAY + " | brand: " + entry.getValue().clientBrand);
            }
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player gak online / gak ketemu.");
            return true;
        }

        PlayerData data = plugin.getData(target);
        sender.sendMessage(ChatColor.GOLD + "=== ModWatch: " + target.getName() + " ===");
        sender.sendMessage(ChatColor.GRAY + "Client brand: " + ChatColor.WHITE + data.clientBrand);
        sender.sendMessage(ChatColor.GRAY + "CPS saat ini: " + ChatColor.WHITE + data.getCurrentCps());
        sender.sendMessage(ChatColor.GRAY + "Skor curiga: " + ChatColor.WHITE + data.flagScore);
        sender.sendMessage(ChatColor.DARK_GRAY + "Catatan: skor ini sinyal awal, bukan bukti final. "
                + "Cek manual (spectator/replay) sebelum ambil tindakan.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> options = new ArrayList<>();
        if (args.length == 1) {
            options.add("list");
            for (Player p : Bukkit.getOnlinePlayers()) {
                options.add(p.getName());
            }
        }
        return options;
    }
}
