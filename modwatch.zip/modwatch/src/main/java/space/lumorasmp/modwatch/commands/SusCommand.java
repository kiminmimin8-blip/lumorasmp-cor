package space.lumorasmp.modwatch.commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import space.lumorasmp.modwatch.ModWatchPlugin;
import space.lumorasmp.modwatch.data.PlayerData;

import java.util.ArrayList;
import java.util.List;

/**
 * /sus <player> - kasih verdict ringkas ala DonutSMP, dibangun dari flagScore
 * yang udah diakumulasi CombatListener (CPS + angle) dan ChannelListener (watchlist match).
 *
 * INI BUKAN VONIS. Threshold di bawah cuma contoh awal, silakan disesuaikan
 * sama pengalaman moderasi lo sendiri (bisa dipindah ke config kalau udah pas).
 */
public class SusCommand implements CommandExecutor, TabCompleter {

    private final ModWatchPlugin plugin;

    public SusCommand(ModWatchPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("modwatch.use")) {
            sender.sendMessage(ChatColor.RED + "Lo gak punya izin buat command ini.");
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(ChatColor.YELLOW + "Pakai: /sus <nama_player>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player gak online / gak ketemu.");
            return true;
        }

        PlayerData data = plugin.getData(target);
        int score = data.flagScore;

        String verdict;
        ChatColor color;
        if (score >= 15) {
            verdict = "SANGAT MENCURIGAKAN";
            color = ChatColor.DARK_RED;
        } else if (score >= 7) {
            verdict = "MENCURIGAKAN";
            color = ChatColor.RED;
        } else if (score >= 3) {
            verdict = "PERLU DIPANTAU";
            color = ChatColor.YELLOW;
        } else {
            verdict = "AMAN";
            color = ChatColor.GREEN;
        }

        sender.sendMessage(ChatColor.GOLD + "=== /sus " + target.getName() + " ===");
        sender.sendMessage("Status: " + color + ChatColor.BOLD + verdict + ChatColor.RESET
                + ChatColor.GRAY + " (skor " + score + ")");
        sender.sendMessage(ChatColor.GRAY + "Client brand: " + ChatColor.WHITE + data.clientBrand);

        if (!data.getWatchlistMatches().isEmpty()) {
            sender.sendMessage(ChatColor.RED + "Channel watchlist terdeteksi: "
                    + String.join(", ", data.getWatchlistMatches()));
        }

        sender.sendMessage(ChatColor.DARK_GRAY
                + "Skor dihitung dari CPS abnormal, pola sudut hit, & channel watchlist. "
                + "Bukan bukti final -- cek manual sebelum tindakan.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> options = new ArrayList<>();
        if (args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                options.add(p.getName());
            }
        }
        return options;
    }
}
