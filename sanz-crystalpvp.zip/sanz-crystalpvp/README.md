# SanzCrystalPvP

Plugin standalone buat restore damage **End Crystal** & **Respawn Anchor** ke gaya
Crystal PvP era classic, plus combo cepat tanpa attack cooldown.

## Mekanik yang di-restore

1. **No damage cap** - damage crystal/anchor gak dibatasin kayak versi modern, dihitung
   sendiri berdasarkan jarak dari titik ledak (falloff linear, full damage di titik pusat).
2. **No attack cooldown** - attribute `ATTACK_SPEED` di-set tinggi banget, jadi gak perlu
   nunggu buat damage penuh (combo klik cepat gaya 1.8).
3. **No crystal invulnerability** - invulnerability tick di-bypass khusus buat damage
   crystal/anchor, jadi 2 ledakan beruntun bisa dua-duanya full damage (gak diredam).

Ketiganya bisa dimatiin sendiri-sendiri di `config.yml` (`mechanics:`), atau semuanya
sekaligus lewat `/crystalpvp off`.

## Command

| Command | Fungsi |
|---|---|
| `/crystalpvp on` | Aktifin semua mekanik custom |
| `/crystalpvp off` | Matiin, balik ke vanilla normal |
| `/crystalpvp status` | Lihat status & config aktif sekarang |
| `/crystalpvp damage <preset>` | Ganti damage - tab-complete kasih pilihan: `ringan`, `klasik`, `agresif`, `ekstrem` |
| `/crystalpvp damage <angka>` | Custom damage manual, contoh `/crystalpvp damage 28` |
| `/crystalpvp reload` | Reload config.yml tanpa restart server |

Semua command punya **tab completion** (subcommand + nama preset).

Alias: `/cpvp`. Permission: `sanzcrystalpvp.admin` (default: op).

## 4 Preset Damage

| Preset | Value | Catatan |
|---|---|---|
| `ringan` | 16 | PvP gak terlalu brutal, armor masih lumayan protektif |
| `klasik` | 24 | **Rekomendasi default** - rasa "classic crystal pvp" |
| `agresif` | 32 | Kompetitif, damage tembus armor bagus |
| `ekstrem` | 40 | Nyaris one-shot walau full netherite prot4 |

⚠️ Angka ini **starting point buat testing**, bukan angka baku dari versi tertentu -
tiap server beda-beda (tergantung enchant, armor set player, dll). Sesuaikan lewat
`/crystalpvp damage <angka>` sampai kerasa pas buat server kamu.

Preset custom sendiri juga bisa ditambah di config.yml bagian `presets:` (key : value),
tinggal edit filenya terus `/crystalpvp reload`.

## Cara build

Sandbox aku gak ada akses internet buat `mvn compile`, jadi plugin ini **belum ke-compile
beneran** - cuma di-review manual baris per baris. Push ke GitHub, biarin Actions CI
(`.github/workflows/build.yml`) yang build otomatis, ambil jar dari tab Actions.

**Cek dulu versi paper-api di `pom.xml`** - masih `1.21.11-R0.1-SNAPSHOT`, sesuaikan
kalau versi API buat 26.1.2 kamu beda.

## Catatan teknis / batasan yang perlu kamu tau

- **Respawn Anchor**: karena ledakannya bukan disebabkan entity (beda sama crystal),
  plugin ini "menebak" korelasi antara ledakan block sama damage yang masuk lewat jendela
  2 tick. Di kondisi normal (1 anchor meledak sendiri) ini akurat, tapi kalau ada BANYAK
  anchor meledak bersamaan persis di waktu yang sama, korelasinya bisa sedikit meleset
  (damage ke-assign ke ledakan terdekat, bukan yang "benar" persis) - biasanya gak masalah
  karena efeknya keliatan sama dari sisi gameplay.
- **Attack speed attribute**: kalau ada plugin lain yang juga ngatur attribute
  `ATTACK_SPEED` (misal plugin custom kit/class), bisa tabrakan - yang paling terakhir
  di-set yang menang. Kalau ada masalah kayak gini, kasih tau aku detail plugin yang
  bentrok.
- Kalau `Attribute.ATTACK_SPEED` gak ke-compile di versi API kamu, ganti ke
  `Attribute.GENERIC_ATTACK_SPEED` (nama lama, sebelum di-rename) di
  `AttackSpeedListener.java`.

## Belum ke-tes end-to-end

Sama kayak plugin lain yang aku buatin sebelumnya - ini belum pernah di-compile beneran
karena sandbox gak ada internet. Kalau ada error compile pas build asli, kirim log-nya
ke sini, aku bantu benerin secepatnya.
