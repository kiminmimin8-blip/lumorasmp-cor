package com.sanz.crystalpvp.listeners;

import com.sanz.crystalpvp.SanzCrystalPvP;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

/**
 * Attack cooldown (sejak 1.9) bikin damage pedang "penuh" cuma kalau nunggu ~0.5-1 detik
 * antar serangan. Buat combo cepat gaya 1.8, kita set attribute GENERIC_ATTACK_SPEED
 * tinggi banget biar cooldown-nya charge instan tiap klik.
 *
 * VANILLA_ATTACK_SPEED dipakai buat restore balik kalau mekanik ini dimatiin.
 */
public class AttackSpeedListener implements Listener {

    private static final double NO_COOLDOWN_SPEED = 1024.0;
    private static final double VANILLA_ATTACK_SPEED = 4.0;

    private final SanzCrystalPvP plugin;

    public AttackSpeedListener(SanzCrystalPvP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        applyTo(event.getPlayer());
    }

    public void applyTo(Player player) {
        // NOTE: Attribute.ATTACK_SPEED itu nama baru (API 1.21+), gantiin GENERIC_ATTACK_SPEED
        // yang udah deprecated. Kalau versi API kamu lebih lama dan ini gak ke-compile,
        // ganti ke Attribute.GENERIC_ATTACK_SPEED.
        AttributeInstance attribute = player.getAttribute(Attribute.ATTACK_SPEED);
        if (attribute == null) return;

        boolean enabled = plugin.getConfig().getBoolean("enabled", true)
                && plugin.getConfig().getBoolean("mechanics.no-attack-cooldown", true);

        attribute.setBaseValue(enabled ? NO_COOLDOWN_SPEED : VANILLA_ATTACK_SPEED);
    }

    /** Dipanggil pas toggle /crystalpvp on|off atau /crystalpvp reload, buat re-apply ke semua player online. */
    public void applyToAllOnline() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            applyTo(player);
        }
    }
}
