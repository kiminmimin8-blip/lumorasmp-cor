package com.sanz.crystalpvp;

import com.sanz.crystalpvp.commands.CrystalPvPCommand;
import com.sanz.crystalpvp.listeners.AnchorDamageListener;
import com.sanz.crystalpvp.listeners.AttackSpeedListener;
import com.sanz.crystalpvp.listeners.CrystalDamageListener;
import com.sanz.crystalpvp.util.DamageCalculator;
import org.bukkit.plugin.java.JavaPlugin;

public class SanzCrystalPvP extends JavaPlugin {

    private DamageCalculator damageCalculator;
    private AttackSpeedListener attackSpeedListener;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        damageCalculator = new DamageCalculator(this);
        attackSpeedListener = new AttackSpeedListener(this);

        getServer().getPluginManager().registerEvents(new CrystalDamageListener(this), this);
        getServer().getPluginManager().registerEvents(new AnchorDamageListener(this), this);
        getServer().getPluginManager().registerEvents(attackSpeedListener, this);

        CrystalPvPCommand command = new CrystalPvPCommand(this);
        getCommand("crystalpvp").setExecutor(command);
        getCommand("crystalpvp").setTabCompleter(command);

        applyMechanicsToAll();

        getLogger().info("SanzCrystalPvP enabled - damage crystal & anchor di-restore ke gaya classic.");
    }

    /** Dipanggil pas enable, reload, atau toggle on/off - re-apply attack speed ke semua player online. */
    public void applyMechanicsToAll() {
        attackSpeedListener.applyToAllOnline();
    }

    public DamageCalculator getDamageCalculator() {
        return damageCalculator;
    }
}
