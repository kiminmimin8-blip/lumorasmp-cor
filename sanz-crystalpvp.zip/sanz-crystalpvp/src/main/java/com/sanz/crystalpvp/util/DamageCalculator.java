package com.sanz.crystalpvp.util;

import com.sanz.crystalpvp.SanzCrystalPvP;

/**
 * Baca damage yang lagi aktif dari config (preset atau custom-value), dan
 * hitung damage final berdasarkan jarak dari titik ledak - falloff linear
 * dari full damage di titik pusat sampai 0 di ujung radius, TANPA cap
 * tambahan kayak vanilla modern (makanya "no-damage-cap").
 */
public final class DamageCalculator {

    private final SanzCrystalPvP plugin;

    public DamageCalculator(SanzCrystalPvP plugin) {
        this.plugin = plugin;
    }

    /** Ambil damage penuh (di titik pusat ledakan) sesuai preset/custom yang aktif sekarang. */
    public double getConfiguredMaxDamage() {
        String preset = plugin.getConfig().getString("damage.preset", "klasik");
        if ("custom".equalsIgnoreCase(preset)) {
            return plugin.getConfig().getDouble("damage.custom-value", 24.0);
        }
        double value = plugin.getConfig().getDouble("presets." + preset, -1);
        if (value < 0) {
            plugin.getLogger().warning("Preset damage '" + preset + "' gak ketemu di config, fallback ke 24.0");
            return 24.0;
        }
        return value;
    }

    /** Hitung damage final buat jarak tertentu dari titik ledak. */
    public double calculate(double distance, double radius) {
        if (distance >= radius) return 0;
        double maxDamage = getConfiguredMaxDamage();
        if (!plugin.getConfig().getBoolean("mechanics.no-damage-cap", true)) {
            // Kalau mekanik ini dimatiin, biarin vanilla yang handle (gak dipakai - dicek di listener)
            return maxDamage;
        }
        double falloff = 1.0 - (distance / radius);
        return maxDamage * falloff;
    }
}
