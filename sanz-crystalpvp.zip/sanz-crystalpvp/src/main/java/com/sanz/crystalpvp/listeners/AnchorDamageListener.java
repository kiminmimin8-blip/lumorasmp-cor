package com.sanz.crystalpvp.listeners;

import com.sanz.crystalpvp.SanzCrystalPvP;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityDamageEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Respawn Anchor explosion itu "block explosion" (bukan disebabkan entity), jadi gak bisa
 * dipakein EntityDamageByEntityEvent kayak crystal. Caranya: tangkep lokasi ledakannya di
 * BlockExplodeEvent, simpen sebentar (expire ~2 tick), terus di EntityDamageEvent generik
 * yang cause-nya BLOCK_EXPLOSION, kita cocokin ke lokasi ledakan anchor yang barusan
 * kejadian buat ngitung ulang damage-nya sendiri.
 */
public class AnchorDamageListener implements Listener {

    private record PendingExplosion(Location location, long expireAtTick) {
    }

    private final SanzCrystalPvP plugin;
    private final List<PendingExplosion> pending = new ArrayList<>();

    public AnchorDamageListener(SanzCrystalPvP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onAnchorExplode(BlockExplodeEvent event) {
        if (!plugin.getConfig().getBoolean("enabled", true)) return;
        if (event.getBlock().getType() != Material.RESPAWN_ANCHOR) return;

        long currentTick = plugin.getServer().getCurrentTick();
        pending.add(new PendingExplosion(event.getBlock().getLocation().add(0.5, 0.5, 0.5), currentTick + 2));
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onExplosionDamage(EntityDamageEvent event) {
        if (!plugin.getConfig().getBoolean("enabled", true)) return;
        if (event.getCause() != EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) return;
        if (!(event.getEntity() instanceof Player player)) return;

        cleanupExpired();

        double radius = plugin.getConfig().getDouble("anchor.radius", 6.0);
        PendingExplosion match = findNearest(player.getLocation(), radius);
        if (match == null) return;

        double distance = match.location().distance(player.getLocation());

        if (plugin.getConfig().getBoolean("mechanics.no-crystal-invulnerability", true)) {
            player.setNoDamageTicks(0);
        }

        if (plugin.getConfig().getBoolean("mechanics.no-damage-cap", true)) {
            double customDamage = plugin.getDamageCalculator().calculate(distance, radius);
            event.setDamage(customDamage);
        }
    }

    private PendingExplosion findNearest(Location playerLoc, double radius) {
        PendingExplosion best = null;
        double bestDistance = Double.MAX_VALUE;
        for (PendingExplosion p : pending) {
            if (!p.location().getWorld().equals(playerLoc.getWorld())) continue;
            double distance = p.location().distance(playerLoc);
            if (distance <= radius && distance < bestDistance) {
                best = p;
                bestDistance = distance;
            }
        }
        return best;
    }

    private void cleanupExpired() {
        long currentTick = plugin.getServer().getCurrentTick();
        pending.removeIf(p -> p.expireAtTick() < currentTick);
    }
}
