package com.sanz.crystalpvp.commands;

import com.sanz.crystalpvp.SanzCrystalPvP;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class CrystalPvPCommand implements CommandExecutor, TabCompleter {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private static final List<String> SUB_COMMANDS = List.of("on", "off", "damage", "reload", "status");

    private final SanzCrystalPvP plugin;

    public CrystalPvPCommand(SanzCrystalPvP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendUsage(sender);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "on" -> {
                plugin.getConfig().set("enabled", true);
                plugin.saveConfig();
                plugin.applyMechanicsToAll();
                sender.sendMessage(LEGACY.deserialize(plugin.getConfig().getString("messages.toggle-on", "&aDiaktifkan.")));
            }
            case "off" -> {
                plugin.getConfig().set("enabled", false);
                plugin.saveConfig();
                plugin.applyMechanicsToAll();
                sender.sendMessage(LEGACY.deserialize(plugin.getConfig().getString("messages.toggle-off", "&cDimatikan.")));
            }
            case "reload" -> {
                plugin.reloadConfig();
                plugin.applyMechanicsToAll();
                sender.sendMessage(LEGACY.deserialize(plugin.getConfig().getString("messages.reload", "&aConfig di-reload.")));
            }
            case "status" -> {
                boolean enabled = plugin.getConfig().getBoolean("enabled", true);
                String preset = plugin.getConfig().getString("damage.preset", "klasik");
                double dmg = plugin.getDamageCalculator().getConfiguredMaxDamage();
                sender.sendMessage(LEGACY.deserialize("&7Status: " + (enabled ? "&aAKTIF" : "&cMATI")));
                sender.sendMessage(LEGACY.deserialize("&7Preset damage: &f" + preset + " &7(&f" + dmg + "&7)"));
                sender.sendMessage(LEGACY.deserialize("&7No damage cap: &f" + plugin.getConfig().getBoolean("mechanics.no-damage-cap", true)));
                sender.sendMessage(LEGACY.deserialize("&7No attack cooldown: &f" + plugin.getConfig().getBoolean("mechanics.no-attack-cooldown", true)));
                sender.sendMessage(LEGACY.deserialize("&7No crystal invulnerability: &f" + plugin.getConfig().getBoolean("mechanics.no-crystal-invulnerability", true)));
            }
            case "damage" -> {
                if (args.length < 2) {
                    sender.sendMessage(LEGACY.deserialize("&cUsage: /crystalpvp damage <ringan|klasik|agresif|ekstrem|angka>"));
                    return true;
                }
                handleDamageArg(sender, args[1]);
            }
            default -> sendUsage(sender);
        }
        return true;
    }

    private void handleDamageArg(CommandSender sender, String arg) {
        Set<String> presetNames = plugin.getConfig().getConfigurationSection("presets") != null
                ? plugin.getConfig().getConfigurationSection("presets").getKeys(false)
                : Set.of();

        if (presetNames.contains(arg.toLowerCase())) {
            plugin.getConfig().set("damage.preset", arg.toLowerCase());
            plugin.saveConfig();
            double value = plugin.getConfig().getDouble("presets." + arg.toLowerCase());
            String msg = plugin.getConfig().getString("messages.damage-set", "&aDamage diset ke {preset} ({value}).")
                    .replace("{preset}", arg.toLowerCase())
                    .replace("{value}", String.valueOf(value));
            sender.sendMessage(LEGACY.deserialize(msg));
            return;
        }

        try {
            double custom = Double.parseDouble(arg);
            plugin.getConfig().set("damage.preset", "custom");
            plugin.getConfig().set("damage.custom-value", custom);
            plugin.saveConfig();
            String msg = plugin.getConfig().getString("messages.damage-set", "&aDamage diset ke {preset} ({value}).")
                    .replace("{preset}", "custom")
                    .replace("{value}", String.valueOf(custom));
            sender.sendMessage(LEGACY.deserialize(msg));
        } catch (NumberFormatException e) {
            sender.sendMessage(LEGACY.deserialize("&cPreset gak dikenal dan bukan angka valid. Pilihan: " + String.join(", ", presetNames) + ", atau angka custom."));
        }
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(LEGACY.deserialize("&cUsage: /crystalpvp <on|off|damage|reload|status>"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> result = new ArrayList<>();
            for (String s : SUB_COMMANDS) {
                if (s.startsWith(args[0].toLowerCase())) {
                    result.add(s);
                }
            }
            return result;
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("damage")) {
            List<String> result = new ArrayList<>();
            var section = plugin.getConfig().getConfigurationSection("presets");
            if (section != null) {
                for (String key : section.getKeys(false)) {
                    if (key.startsWith(args[1].toLowerCase())) {
                        result.add(key);
                    }
                }
            }
            return result;
        }

        return List.of();
    }
}
