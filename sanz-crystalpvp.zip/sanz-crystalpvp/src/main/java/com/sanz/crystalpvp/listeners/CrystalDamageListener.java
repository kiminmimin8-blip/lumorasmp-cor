package com.sanz.crystalpvp.listeners;

import com.sanz.crystalpvp.SanzCrystalPvP;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class CrystalDamageListener implements Listener {

    private final SanzCrystalPvP plugin;

    public CrystalDamageListener(SanzCrystalPvP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onCrystalDamage(EntityDamageByEntityEvent event) {
        if (!plugin.getConfig().getBoolean("enabled", true)) return;
        if (!(event.getDamager() instanceof EnderCrystal crystal)) return;
        if (!(event.getEntity() instanceof Player player)) return;

        double radius = plugin.getConfig().getDouble("crystal.radius", 6.0);
        double distance = crystal.getLocation().distance(player.getLocation());

        if (distance > radius) {
            event.setDamage(0);
            return;
        }

        // Bypass invulnerability tick SEBELUM damage diterapkan, biar hit ini gak "diredam"
        // sama damage sebelumnya (misal dari crystal lain barusan) kalau mekanik ini nyala.
        if (plugin.getConfig().getBoolean("mechanics.no-crystal-invulnerability", true)) {
            player.setNoDamageTicks(0);
        }

        if (plugin.getConfig().getBoolean("mechanics.no-damage-cap", true)) {
            double customDamage = plugin.getDamageCalculator().calculate(distance, radius);
            event.setDamage(customDamage);
        }
        // Kalau no-damage-cap dimatiin, biarin damage vanilla apa adanya (gak di-override).
    }
}
