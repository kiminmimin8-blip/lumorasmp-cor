package net.sanzitem.util;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.List;

/** Helper target dan damage yang dipakai banyak skill. */
public final class Combat {

    private Combat() {
    }

    /** Boleh jadi korban? Caster, armor stand, NPC, dan spectator nggak. */
    public static boolean valid(Player caster, Entity e) {
        if (!(e instanceof LivingEntity) || e.equals(caster) || e instanceof ArmorStand) return false;
        if (e.hasMetadata("NPC")) return false;
        return !(e instanceof Player other && other.getGameMode() == GameMode.SPECTATOR);
    }

    /** Semua korban valid dalam radius dari titik center, diurutkan dari yang terdekat. */
    public static List<LivingEntity> around(Player caster, Location center, double radius) {
        List<LivingEntity> out = new ArrayList<>();
        if (center.getWorld() == null) return out;
        for (Entity e : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (valid(caster, e) && e.getLocation().distanceSquared(center) <= radius * radius * 1.3) {
                out.add((LivingEntity) e);
            }
        }
        out.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(center)));
        return out;
    }

    public static LivingEntity nearest(Player caster, Location center, double radius) {
        List<LivingEntity> list = around(caster, center, radius);
        return list.isEmpty() ? null : list.get(0);
    }

    public static void damage(Player caster, LivingEntity target, double amount) {
        target.damage(amount, caster);
    }

    /** Dorong target menjauh dari from (horizontal) + dongkrak vertikal. */
    public static void push(LivingEntity target, Location from, double power, double lift) {
        Vector v = target.getLocation().toVector().subtract(from.toVector());
        v.setY(0);
        if (v.lengthSquared() < 0.01) v = new Vector(0, 0, 1);
        v.normalize().multiply(power).setY(lift);
        target.setVelocity(v);
    }

    /** Tarik target ke arah titik to. */
    public static void pull(LivingEntity target, Location to, double power, double lift) {
        Vector v = to.toVector().subtract(target.getLocation().toVector());
        v.setY(0);
        if (v.lengthSquared() < 0.01) return;
        v.normalize().multiply(power).setY(lift);
        target.setVelocity(v);
    }

    // ---------------------------------------------------------- fall guard

    private static final Map<UUID, Long> FALL_GUARD = new HashMap<>();

    /** Player ini kebal fall damage selama ticks tick ke depan (buat skill lompat/dash). */
    public static void guardFall(Player player, int ticks) {
        FALL_GUARD.put(player.getUniqueId(), System.currentTimeMillis() + ticks * 50L);
    }

    public static boolean hasFallGuard(UUID id) {
        Long until = FALL_GUARD.get(id);
        if (until == null) return false;
        if (until < System.currentTimeMillis()) {
            FALL_GUARD.remove(id);
            return false;
        }
        return true;
    }

    public static void forget(UUID id) {
        FALL_GUARD.remove(id);
    }
}
