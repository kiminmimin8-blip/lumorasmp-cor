package net.sanzitem.util;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.util.Vector;

/** Warna dan bentuk tambahan buat Frostbane (es), Dawnbreaker (matahari), dan Soulreaver (jiwa). */
public final class Palette {

    // ---- es
    public static final Particle.DustOptions ICE = new Particle.DustOptions(Color.fromRGB(170, 235, 255), 1.4f);
    public static final Particle.DustOptions ICE_DEEP = new Particle.DustOptions(Color.fromRGB(70, 150, 255), 1.5f);
    public static final Particle.DustOptions FROST_WHITE = new Particle.DustOptions(Color.fromRGB(240, 252, 255), 1.6f);

    // ---- matahari
    public static final Particle.DustOptions SUN = new Particle.DustOptions(Color.fromRGB(255, 215, 90), 1.5f);
    public static final Particle.DustOptions SUN_CORE = new Particle.DustOptions(Color.fromRGB(255, 250, 210), 1.8f);
    public static final Particle.DustOptions SUN_ORANGE = new Particle.DustOptions(Color.fromRGB(255, 140, 30), 1.5f);

    // ---- jiwa
    public static final Particle.DustOptions SOUL = new Particle.DustOptions(Color.fromRGB(70, 255, 205), 1.4f);
    public static final Particle.DustOptions SOUL_DEEP = new Particle.DustOptions(Color.fromRGB(30, 120, 150), 1.5f);
    public static final Particle.DustOptions SHADOW = new Particle.DustOptions(Color.fromRGB(30, 10, 50), 1.7f);

    // ---- air
    public static final Particle.DustOptions WATER = new Particle.DustOptions(Color.fromRGB(60, 150, 255), 1.5f);
    public static final Particle.DustOptions WATER_DEEP = new Particle.DustOptions(Color.fromRGB(20, 70, 200), 1.6f);
    public static final Particle.DustOptions FOAM = new Particle.DustOptions(Color.fromRGB(235, 250, 255), 1.4f);

    // ---- tanah
    public static final Particle.DustOptions EARTH = new Particle.DustOptions(Color.fromRGB(140, 95, 55), 1.6f);
    public static final Particle.DustOptions STONE = new Particle.DustOptions(Color.fromRGB(135, 135, 140), 1.6f);

    // ---- alam
    public static final Particle.DustOptions LEAF = new Particle.DustOptions(Color.fromRGB(90, 225, 80), 1.4f);
    public static final Particle.DustOptions LEAF_DARK = new Particle.DustOptions(Color.fromRGB(30, 110, 40), 1.5f);
    public static final Particle.DustOptions VENOM = new Particle.DustOptions(Color.fromRGB(175, 255, 60), 1.5f);

    public static final Particle.DustTransition SOUL_FADE = new Particle.DustTransition(
            Color.fromRGB(130, 255, 225), Color.fromRGB(70, 20, 120), 1.6f);

    private Palette() {
    }

    /** Puing blok bertekstur material tertentu (es, dll) yang berhamburan. */
    public static void block(Location at, Material material, int count, double spread, double speed) {
        World world = at.getWorld();
        if (world == null) return;
        world.spawnParticle(Particle.BLOCK, at, count, spread, spread * 0.6, spread, speed, material.createBlockData());
    }

    /** Vektor horizontal tegak lurus dir. */
    public static Vector right(Vector dir) {
        Vector r = dir.clone().crossProduct(new Vector(0, 1, 0));
        if (r.lengthSquared() < 1.0E-4) r = new Vector(1, 0, 0);
        return r.normalize();
    }

    /** Duri/kristal runcing dari base setinggi height, melancip ke atas. */
    public static void spike(Location base, double height, double radius,
                             Particle.DustOptions a, Particle.DustOptions b) {
        World world = base.getWorld();
        if (world == null || height <= 0.1) return;
        for (double y = 0; y <= height; y += 0.3) {
            double r = radius * (1 - y / height);
            int pts = r > 0.35 ? 6 : 3;
            for (int i = 0; i < pts; i++) {
                double ang = i * 2 * Math.PI / pts + y * 0.5;
                world.spawnParticle(Particle.DUST,
                        base.getX() + Math.cos(ang) * r, base.getY() + y, base.getZ() + Math.sin(ang) * r,
                        1, 0, 0, 0, 0, (i % 2 == 0) ? a : b);
            }
        }
        world.spawnParticle(Particle.END_ROD, base.clone().add(0, height, 0), 3, 0.05, 0.05, 0.05, 0.02);
    }

    /** Kolom cahaya vertikal berpilin dari base setinggi height. */
    public static void lightColumn(Location base, double height, double radius,
                                   Particle.DustOptions main, Particle.DustOptions edge) {
        World world = base.getWorld();
        if (world == null) return;
        int n = 0;
        for (double y = 0; y <= height; y += 0.5, n++) {
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4 + y * 0.6;
                Fx.dust(base.clone().add(Math.cos(a) * radius, y, Math.sin(a) * radius), edge);
            }
            Fx.dust(base.clone().add(0, y, 0), main);
            if (n % 4 == 0) {
                world.spawnParticle(Particle.END_ROD, base.clone().add(0, y, 0), 1, 0.15, 0, 0.15, 0.01);
            }
        }
    }
}
