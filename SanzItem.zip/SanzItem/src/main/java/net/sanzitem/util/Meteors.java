package net.sanzitem.util;

import net.sanzitem.SanzItem;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

/** Satu meteor: jatuh miring berekor api, penanda di tanah, ledakan, damage, bakar. Dipakai beberapa skill. */
public final class Meteors {

    /** Ekor meteor: oranye terang ke merah gelap. */
    public static final Particle.DustTransition TAIL = new Particle.DustTransition(
            Color.fromRGB(255, 175, 45), Color.fromRGB(95, 20, 10), 1.9f);

    private Meteors() {
    }

    /** Boleh kena damage? Caster sendiri, armor stand, dan spectator nggak. */
    public static boolean valid(Player caster, LivingEntity e) {
        if (e.equals(caster) || e instanceof ArmorStand) return false;
        return !(e instanceof Player other && other.getGameMode() == GameMode.SPECTATOR);
    }

    /**
     * Jatuhin satu meteor ke impact.
     *
     * @param slant   arah dari titik jatuh menuju langit (miring)
     * @param maxPath panjang lintasan maksimal kalau langit terbuka
     * @param scale   1.0 = meteor biasa, 3.0 = meteor raksasa (kepala, ekor, ledakan lebih besar)
     */
    public static void launch(SanzItem plugin, Player caster, Location impact, Vector slant,
                              double maxPath, int fallTicks, double scale,
                              double impactRadius, double damage, int burnTicks, boolean big) {
        World world = impact.getWorld();
        if (world == null) return;

        // Lintasan miring dibatasi batu. Kalau terlalu pendek (goa sempit) jatuh lurus dari langit-langit.
        Location rayStart = impact.clone().add(0, 0.6, 0);
        final Vector dir;
        final double len;
        RayTraceResult hit = world.rayTraceBlocks(rayStart, slant, maxPath, FluidCollisionMode.NEVER, true);
        if (hit == null || hit.getHitPosition() == null) {
            dir = slant;
            len = maxPath;
        } else {
            double d = hit.getHitPosition().distance(rayStart.toVector());
            if (d < 5) {
                dir = new Vector(0, 1, 0);
                len = Math.min(maxPath, Fx.ceiling(rayStart, maxPath));
            } else {
                dir = slant;
                len = d - 0.5;
            }
        }

        final Location start = impact.clone().add(dir.clone().multiply(len));
        if (len < maxPath - 0.05) {
            // Meteor nembus batu: puing + asap di titik tembus
            Fx.debris(start.clone().subtract(dir.clone().multiply(0.3)),
                    start.clone().add(dir.clone().multiply(0.6)).getBlock(), 30, 0.7);
            world.spawnParticle(Particle.LARGE_SMOKE, start, 8, 0.4, 0.2, 0.4, 0.02);
            world.playSound(start, Sound.BLOCK_STONE_BREAK, 1.2f, 0.6f);
        }
        world.playSound(impact, Sound.ENTITY_GHAST_SHOOT, (float) Math.min(2.0, 0.7 * scale), 0.6f);

        final int tailLen = (int) Math.min(30, 12 * scale);

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                double p = tick / (double) fallTicks;

                // Penanda: cincin merah berdenyut + cincin oranye tetap di batas ledakan
                double pulse = impactRadius * (0.65 + 0.35 * Math.abs(Math.sin(tick * 0.8)));
                int ringPts = (int) Math.min(60, 16 + impactRadius * 3);
                Fx.ringDust(impact.clone().add(0, 0.1, 0), pulse, ringPts, Fx.RED);
                Fx.ringDust(impact.clone().add(0, 0.1, 0), impactRadius, ringPts, Fx.ORANGE);

                // Kepala meteor: bola api + asap
                Location head = impact.clone().add(dir.clone().multiply(len * (1 - p)));
                Fx.sphere(head, 0.5 * scale, (int) (10 * scale), Particle.FLAME);
                world.spawnParticle(Particle.FLAME, head, (int) (10 * scale), 0.25 * scale, 0.25 * scale, 0.25 * scale, 0.02);
                world.spawnParticle(Particle.LARGE_SMOKE, head, (int) (3 * scale), 0.2 * scale, 0.2 * scale, 0.2 * scale, 0.01);
                Fx.dust(head, Fx.WHITE);

                // Ekor: gradasi oranye ke merah gelap sepanjang lintasan di belakang kepala
                double behind = len * p;
                for (int k = 1; k <= tailLen; k++) {
                    double dist = k * 0.7;
                    if (dist > behind) break;
                    Location pos = head.clone().add(dir.clone().multiply(dist));
                    Fx.trail(pos, TAIL);
                    if (k % 3 == 0) {
                        world.spawnParticle(Particle.SMOKE, pos, 1, 0.1, 0.1, 0.1, 0.01);
                    }
                }

                if (tick < fallTicks) return;
                cancel();
                land(plugin, caster, impact, impactRadius, damage, burnTicks, big, scale);
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private static void land(SanzItem plugin, Player caster, Location impact, double impactRadius,
                             double damage, int burnTicks, boolean big, double scale) {
        World world = impact.getWorld();
        if (world == null) return;
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        // Ledakan: yang "big" meledak besar (raksasa = beberapa ledakan sekaligus), sisanya sedang
        if (big) {
            int bursts = scale >= 2 ? 5 : 1;
            for (int i = 0; i < bursts; i++) {
                double ox = i == 0 ? 0 : rnd.nextDouble(-1, 1) * impactRadius * 0.5;
                double oz = i == 0 ? 0 : rnd.nextDouble(-1, 1) * impactRadius * 0.5;
                world.spawnParticle(Particle.EXPLOSION_EMITTER, impact.clone().add(ox, 0.5, oz), 1);
            }
        } else {
            world.spawnParticle(Particle.EXPLOSION, impact.clone().add(0, 0.5, 0), 2, 0.5, 0.2, 0.5, 0);
        }
        Fx.burst(impact.clone().add(0, 0.5, 0), Particle.FLAME, (int) (60 * scale), 0.35);
        world.spawnParticle(Particle.LAVA, impact.clone().add(0, 0.4, 0), (int) (12 * scale), 0.8, 0.2, 0.8, 0);
        world.spawnParticle(Particle.LARGE_SMOKE, impact.clone().add(0, 0.5, 0), (int) (15 * scale), 0.6, 0.3, 0.6, 0.02);
        Fx.debris(impact.clone().add(0, 0.3, 0), impact.clone().subtract(0, 0.5, 0).getBlock(), (int) (40 * scale), 0.9);
        // Semburan api & asap naik
        for (int i = 0; i < (int) (14 * scale); i++) {
            world.spawnParticle(Particle.FLAME, impact, 0,
                    rnd.nextDouble(-0.4, 0.4), 1.0, rnd.nextDouble(-0.4, 0.4), 0.3);
        }
        for (int i = 0; i < 8; i++) {
            world.spawnParticle(Particle.SMOKE, impact, 0,
                    rnd.nextDouble(-0.2, 0.2), 1.0, rnd.nextDouble(-0.2, 0.2), 0.2);
        }

        // Gelombang kejut api melebar
        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                t++;
                int pts = (int) Math.min(80, 24 + impactRadius * 4);
                Fx.ringDust(impact.clone().add(0, 0.15, 0), t * impactRadius / 3.0, pts, Fx.ORANGE);
                Fx.ringDust(impact.clone().add(0, 0.3, 0), t * impactRadius / 4.0, pts / 2, Fx.RED);
                if (t >= 4) cancel();
            }
        }.runTaskTimer(plugin, 0L, 1L);

        world.playSound(impact, Sound.ENTITY_GENERIC_EXPLODE,
                (float) (big ? 1.2f * Math.min(scale, 2.0) : 0.8f), big ? 0.7f : 1.0f + rnd.nextFloat() * 0.3f);
        world.playSound(impact, Sound.BLOCK_FIRE_EXTINGUISH, 0.6f, 0.7f);

        for (LivingEntity target : world.getNearbyLivingEntities(impact, impactRadius)) {
            if (!valid(caster, target)) continue;
            if (caster.isOnline()) {
                target.damage(damage, caster);
            } else {
                target.damage(damage);
            }

            Vector push = target.getLocation().toVector().subtract(impact.toVector());
            push.setY(0);
            if (push.lengthSquared() < 0.01) {
                push = new Vector(0, 0, 0);
            } else {
                push.normalize().multiply(0.6 * Math.min(scale, 2.0));
            }
            push.setY(0.45);
            target.setVelocity(push);

            if (burnTicks > 0) {
                target.setFireTicks(burnTicks);
            }
            Fx.shock(plugin, target, 20, Fx.RED, Fx.ORANGE, Particle.FLAME);
        }
    }
}
