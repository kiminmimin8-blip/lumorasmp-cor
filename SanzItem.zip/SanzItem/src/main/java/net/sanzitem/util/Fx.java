package net.sanzitem.util;

import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.LivingEntity;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Helper buat animasi partikel. */
public final class Fx {

    public static final Particle.DustOptions CYAN = new Particle.DustOptions(Color.fromRGB(90, 225, 255), 1.3f);
    public static final Particle.DustOptions GOLD = new Particle.DustOptions(Color.fromRGB(255, 205, 80), 1.3f);
    public static final Particle.DustOptions RED = new Particle.DustOptions(Color.fromRGB(255, 70, 50), 1.4f);
    public static final Particle.DustOptions ORANGE = new Particle.DustOptions(Color.fromRGB(255, 140, 30), 1.3f);
    public static final Particle.DustOptions WHITE = new Particle.DustOptions(Color.fromRGB(255, 255, 255), 1.5f);
    public static final Particle.DustOptions DARK = new Particle.DustOptions(Color.fromRGB(35, 35, 45), 1.2f);
    public static final Particle.DustOptions PURPLE = new Particle.DustOptions(Color.fromRGB(165, 70, 235), 1.5f);
    public static final Particle.DustOptions VOID = new Particle.DustOptions(Color.fromRGB(25, 0, 40), 1.6f);

    public static final Particle.DustTransition GOLD_TO_RED = new Particle.DustTransition(
            Color.fromRGB(255, 225, 90), Color.fromRGB(255, 70, 40), 1.6f);

    private Fx() {
    }

    // ------------------------------------------------------------ titik dasar

    /** Satu titik partikel berwarna. */
    public static void dust(Location at, Particle.DustOptions options) {
        World world = at.getWorld();
        if (world == null) return;
        world.spawnParticle(Particle.DUST, at, 1, 0, 0, 0, 0, options);
    }

    /** Satu titik partikel yang warnanya berubah (gradasi) selama hidupnya. */
    public static void trail(Location at, Particle.DustTransition transition) {
        World world = at.getWorld();
        if (world == null) return;
        world.spawnParticle(Particle.DUST_COLOR_TRANSITION, at, 1, 0, 0, 0, 0, transition);
    }

    /** Ledakan partikel ke segala arah. */
    public static void burst(Location at, Particle particle, int count, double speed) {
        World world = at.getWorld();
        if (world == null) return;
        world.spawnParticle(particle, at, count, 0, 0, 0, speed);
    }

    /** Puing blok (dari blok sumber) yang berhamburan. */
    public static void debris(Location at, Block source, int count, double spread) {
        World world = at.getWorld();
        if (world == null) return;
        BlockData data = (source.getType().isAir() || source.isLiquid())
                ? Material.STONE.createBlockData()
                : source.getBlockData();
        world.spawnParticle(Particle.BLOCK, at, count, spread, spread * 0.6, spread, 0.15, data);
    }

    // ------------------------------------------------------------- bentuk

    /** Cincin partikel horizontal. */
    public static void ring(Location center, double radius, int points, Particle particle) {
        World world = center.getWorld();
        if (world == null || radius <= 0) return;
        for (int i = 0; i < points; i++) {
            double angle = 2 * Math.PI * i / points;
            world.spawnParticle(particle,
                    center.getX() + Math.cos(angle) * radius,
                    center.getY(),
                    center.getZ() + Math.sin(angle) * radius,
                    1, 0, 0, 0, 0);
        }
    }

    /** Cincin partikel berwarna. */
    public static void ringDust(Location center, double radius, int points, Particle.DustOptions options) {
        if (center.getWorld() == null || radius <= 0) return;
        for (int i = 0; i < points; i++) {
            double angle = 2 * Math.PI * i / points;
            dust(center.clone().add(Math.cos(angle) * radius, 0, Math.sin(angle) * radius), options);
        }
    }

    public static void line(Location from, Location to, Particle particle, double step) {
        line(from, to, particle, step, 0.15);
    }

    /** Garis partikel, jitter = seberapa bergerigi. */
    public static void line(Location from, Location to, Particle particle, double step, double jitter) {
        World world = from.getWorld();
        if (world == null) return;
        Vector dir = to.toVector().subtract(from.toVector());
        double length = dir.length();
        if (length < 0.01) return;
        dir.normalize();

        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (double t = 0; t <= length; t += step) {
            Location p = from.clone().add(dir.clone().multiply(t));
            if (jitter > 0) {
                p.add(rnd.nextDouble(-jitter, jitter), rnd.nextDouble(-jitter, jitter), rnd.nextDouble(-jitter, jitter));
            }
            world.spawnParticle(particle, p, 1, 0, 0, 0, 0);
        }
    }

    /** Garis partikel berwarna (tanpa jitter). */
    public static void lineDust(Location from, Location to, double step, Particle.DustOptions options) {
        if (from.getWorld() == null) return;
        Vector dir = to.toVector().subtract(from.toVector());
        double length = dir.length();
        if (length < 0.01) return;
        dir.normalize();
        for (double t = 0; t <= length; t += step) {
            dust(from.clone().add(dir.clone().multiply(t)), options);
        }
    }

    /** Titik-titik acak di permukaan bola. */
    public static void sphere(Location center, double radius, int points, Particle particle) {
        World world = center.getWorld();
        if (world == null) return;
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int i = 0; i < points; i++) {
            double x = rnd.nextGaussian();
            double y = rnd.nextGaussian();
            double z = rnd.nextGaussian();
            double len = Math.sqrt(x * x + y * y + z * z);
            if (len < 1e-6) continue;
            world.spawnParticle(particle,
                    center.getX() + x / len * radius,
                    center.getY() + y / len * radius,
                    center.getZ() + z / len * radius,
                    1, 0, 0, 0, 0);
        }
    }

    /** Hexagram (bintang segi enam) horizontal yang bisa diputar. */
    public static void star(Location center, double radius, double rotation, double step,
                            Particle.DustOptions options) {
        for (int tri = 0; tri < 2; tri++) {
            Location[] v = new Location[3];
            for (int i = 0; i < 3; i++) {
                double a = rotation + tri * Math.PI / 3 + i * 2 * Math.PI / 3;
                v[i] = center.clone().add(Math.cos(a) * radius, 0, Math.sin(a) * radius);
            }
            for (int i = 0; i < 3; i++) {
                lineDust(v[i], v[(i + 1) % 3], step, options);
            }
        }
    }

    /** Kolom cahaya vertikal berpilin, dari base ke atas. */
    public static void pillar(Location base, double height, double radius, Particle.DustOptions options) {
        for (double y = 0; y <= height; y += 0.6) {
            for (int i = 0; i < 3; i++) {
                double a = i * 2 * Math.PI / 3 + y * 0.8;
                dust(base.clone().add(Math.cos(a) * radius, y, Math.sin(a) * radius), options);
            }
        }
    }

    /** Aura heliks ganda di sekeliling badan (kaki sampai kepala). Dipakai buat caster dan korban. */
    public static void bodyHelix(Location base, double tick, double radius,
                                 Particle.DustOptions a, Particle.DustOptions b) {
        for (int i = 0; i < 2; i++) {
            double angle = tick * 0.6 + i * Math.PI;
            for (double y = 0; y <= 2.0; y += 0.25) {
                double ang = angle + y * 2.2;
                dust(base.clone().add(Math.cos(ang) * radius, y, Math.sin(ang) * radius), i == 0 ? a : b);
            }
        }
    }

    // --------------------------------------------------------------- petir

    private static List<Location> path(Location from, Location to, int segments, double jitter) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        double j = Math.max(jitter, 0.001);
        Vector delta = to.toVector().subtract(from.toVector());
        List<Location> points = new ArrayList<>();
        for (int i = 0; i <= segments; i++) {
            Location p = from.clone().add(delta.clone().multiply((double) i / segments));
            if (i > 0 && i < segments) {
                p.add(rnd.nextDouble(-j, j), rnd.nextDouble(-j, j), rnd.nextDouble(-j, j));
            }
            points.add(p);
        }
        return points;
    }

    /** Sambaran petir bergerigi tipis: patah-patah dari from ke to + titik berwarna di tiap patahan. */
    public static void bolt(Location from, Location to, int segments, double jitter,
                            Particle particle, Particle.DustOptions options) {
        if (from.getWorld() == null) return;
        List<Location> points = path(from, to, segments, jitter);
        for (int i = 0; i < points.size() - 1; i++) {
            line(points.get(i), points.get(i + 1), particle, 0.3, 0.03);
            dust(points.get(i), options);
        }
    }

    /** Petir tebal: 3 untai sejajar + percikan + cabang-cabang kecil. */
    public static void thickBolt(Location from, Location to, int segments, double jitter,
                                 Particle.DustOptions main, Particle.DustOptions glow) {
        World world = from.getWorld();
        if (world == null) return;
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        List<Location> pts = path(from, to, segments, jitter);

        for (int strand = 0; strand < 3; strand++) {
            double ox = strand == 0 ? 0 : rnd.nextDouble(-0.2, 0.2);
            double oz = strand == 0 ? 0 : rnd.nextDouble(-0.2, 0.2);
            Particle.DustOptions color = strand == 0 ? main : glow;
            for (int i = 0; i < pts.size() - 1; i++) {
                lineDust(pts.get(i).clone().add(ox, 0, oz), pts.get(i + 1).clone().add(ox, 0, oz), 0.35, color);
            }
        }
        for (int i = 0; i < pts.size(); i++) {
            Location p = pts.get(i);
            world.spawnParticle(Particle.ELECTRIC_SPARK, p, 3, 0.25, 0.25, 0.25, 0.05);
            if (i > 0 && i < pts.size() - 1 && rnd.nextDouble() < 0.35) {
                Location end = p.clone().add(rnd.nextDouble(-2.5, 2.5), rnd.nextDouble(-2.0, 0.5), rnd.nextDouble(-2.5, 2.5));
                bolt(p, end, 3, 0.3, Particle.ELECTRIC_SPARK, glow);
            }
        }
    }

    // ------------------------------------------------------- goa / langit-langit

    /**
     * Jarak ke langit-langit tepat di atas titik from (maks max). Dipakai supaya petir dan bintang
     * mulai dari bawah langit-langit goa, bukan dari dalam batu.
     */
    public static double ceiling(Location from, double max) {
        World world = from.getWorld();
        if (world == null) return max;
        RayTraceResult hit = world.rayTraceBlocks(from, new Vector(0, 1, 0), max, FluidCollisionMode.NEVER, true);
        if (hit == null || hit.getHitPosition() == null) return max;
        return Math.max(2.0, hit.getHitPosition().getY() - from.getY());
    }

    /** Titik lantai terdekat di kolom (x, z) di sekitar tinggi refY. Aman buat goa. */
    public static Location groundNear(World world, double x, double z, double refY) {
        int bx = (int) Math.floor(x);
        int bz = (int) Math.floor(z);
        int startY = (int) Math.floor(refY) + 3;
        int endY = (int) Math.floor(refY) - 6;
        for (int y = startY; y >= endY; y--) {
            Block here = world.getBlockAt(bx, y, bz);
            Block below = world.getBlockAt(bx, y - 1, bz);
            if (here.isPassable() && !below.isPassable()) {
                return new Location(world, x, y, z);
            }
        }
        return new Location(world, x, refY, z);
    }

    /**
     * Petir dari atas ke ground. Kalau ada langit-langit (goa), petir mulai dari bawah langit-langit
     * dan nembus: puing, asap, dan percikan muncul di titik tembus.
     */
    public static void skyBolt(Location ground, double max, Particle.DustOptions main, Particle.DustOptions glow) {
        World world = ground.getWorld();
        if (world == null) return;
        double up = ceiling(ground.clone().add(0, 0.5, 0), max);
        Location top = ground.clone().add(0, up, 0);
        thickBolt(top, ground.clone().add(0, 0.1, 0), Math.max(5, (int) (up / 1.7)),
                Math.min(1.0, up / 20.0 + 0.3), main, glow);

        if (up < max - 0.05) {
            debris(top.clone().add(0, -0.2, 0), top.clone().add(0, 0.6, 0).getBlock(), 50, 0.8);
            world.spawnParticle(Particle.LARGE_SMOKE, top, 12, 0.5, 0.2, 0.5, 0.02);
            burst(top, Particle.ELECTRIC_SPARK, 40, 0.4);
            world.playSound(top, Sound.BLOCK_STONE_BREAK, 1.5f, 0.6f);
        }
    }

    // ------------------------------------------------------------- korban

    /** Aura kejut di sekeliling korban selama ticks tick (heliks berwarna + percikan). */
    public static void shock(Plugin plugin, LivingEntity target, int ticks,
                             Particle.DustOptions a, Particle.DustOptions b, Particle spark) {
        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (!target.isValid() || target.isDead() || t >= ticks) {
                    cancel();
                    return;
                }
                Location base = target.getLocation();
                bodyHelix(base, t, 0.6, a, b);
                if (t % 2 == 0) {
                    target.getWorld().spawnParticle(spark, base.clone().add(0, 1, 0), 4, 0.3, 0.6, 0.3, 0.05);
                }
                t++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
}
