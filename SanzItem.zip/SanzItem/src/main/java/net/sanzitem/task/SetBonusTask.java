package net.sanzitem.task;

import net.sanzitem.SanzItem;
import net.sanzitem.item.SetDef;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;

/** Nge-refresh efek pasif set armor tiap 2 detik buat yang pakai set penuh. */
public final class SetBonusTask extends BukkitRunnable {

    private final SanzItem plugin;

    public SetBonusTask(SanzItem plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            SetDef set = plugin.items().getWornSet(player);
            if (set == null) continue;

            for (Map.Entry<String, Integer> e : set.bonusEffects().entrySet()) {
                PotionEffectType type = Registry.EFFECT.get(NamespacedKey.minecraft(e.getKey()));
                if (type == null) continue;
                // durasi 5 detik, di-refresh tiap 2 detik; tanpa ambient & tanpa partikel
                player.addPotionEffect(new PotionEffect(type, 100, e.getValue(), true, false, true));
            }
        }
    }
}
