package net.sanzitem.listener;

import net.sanzitem.SanzItem;
import net.sanzitem.item.ItemDef;
import net.sanzitem.item.SetDef;
import net.sanzitem.item.SkillSpec;
import net.sanzitem.skill.GroundSlamSkill;
import net.sanzitem.util.Combat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Kontrol skill (aman buat Bedrock, cuma butuh sneak + klik):
 * <ul>
 *   <li>Item di tangan: Shift + Klik Kanan = pakai skill terpilih, Shift + Klik Kiri = ganti skill.</li>
 *   <li>Set armor: sneak 2x = skill 1, 3x = skill 2, 4x = skill 3.</li>
 * </ul>
 * Klik kanan biasa (tanpa Shift) nggak disentuh sama sekali, jadi mana ability AuraSkills tetap jalan.
 */
public final class SkillListener implements Listener {

    private static final class Taps {
        int count;
        long last;
        BukkitTask task;
    }

    private final SanzItem plugin;
    private final Map<UUID, Taps> taps = new HashMap<>();

    public SkillListener(SanzItem plugin) {
        this.plugin = plugin;
    }

    private ItemDef skillItem(ItemStack stack) {
        String id = plugin.items().getId(stack);
        if (id == null) return null;
        ItemDef def = plugin.items().get(id);
        if (def == null || def.skills().isEmpty() || def.slot() != EquipmentSlotGroup.MAINHAND) return null;
        return def;
    }

    /**
     * Shift + Klik Kanan = pakai skill. Prioritas LOWEST + cancel supaya plugin lain (AuraSkills, dll)
     * yang jalan setelah ini nggak ikut kepicu.
     */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        if (!player.isSneaking()) return;

        ItemDef def = skillItem(event.getItem());
        if (def == null) return;

        event.setCancelled(true);
        plugin.skills().castSelected(player, def.id(), def.skills());
    }

    /** Shift + Klik Kiri (ayun tangan, termasuk pas ngenain mob/pemain) = ganti skill. */
    @EventHandler
    public void onSwing(PlayerAnimationEvent event) {
        if (event.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        Player player = event.getPlayer();
        if (!player.isSneaking()) return;

        ItemDef def = skillItem(player.getInventory().getItemInMainHand());
        if (def == null) return;
        plugin.skills().cycle(player, def.id(), def.skills());
    }

    /** Ganti slot hotbar: tampilkan skill terpilih dari item yang baru dipegang. */
    @EventHandler
    public void onHeld(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        ItemStack next = player.getInventory().getItem(event.getNewSlot());
        ItemDef def = skillItem(next);
        if (def == null) return;
        plugin.getServer().getScheduler().runTask(plugin,
                () -> plugin.skills().showSelected(player, def.id(), def.skills()));
    }

    /**
     * Set armor: sneak 2x / 3x / 4x cepat = skill 1 / 2 / 3. Skill jalan setelah jeda singkat
     * (nunggu apakah masih ada tap berikutnya), kecuali tap-nya udah mentok jumlah skill.
     */
    @EventHandler
    public void onSneak(PlayerToggleSneakEvent event) {
        if (!event.isSneaking()) return;

        Player player = event.getPlayer();
        SetDef set = plugin.items().getWornSet(player);
        if (set == null || set.skills().isEmpty()) return;

        long window = plugin.getConfig().getLong("double-sneak-window-ms", 400);
        long now = System.currentTimeMillis();

        Taps t = taps.computeIfAbsent(player.getUniqueId(), k -> new Taps());
        if (now - t.last > window) t.count = 0;
        t.count++;
        t.last = now;
        if (t.task != null) {
            t.task.cancel();
            t.task = null;
        }
        if (t.count < 2) return;

        List<SkillSpec> list = set.skills();
        int index = Math.min(t.count, list.size() + 1) - 2;
        String owner = "set:" + set.id();

        if (t.count >= list.size() + 1) {
            t.count = 0;
            plugin.skills().castAt(player, owner, list, index);
            return;
        }
        long delayTicks = Math.max(2L, window / 50L);
        t.task = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            t.count = 0;
            t.task = null;
            if (player.isOnline() && plugin.items().getWornSet(player) == set) {
                plugin.skills().castAt(player, owner, list, index);
            }
        }, delayTicks);
    }

    /** Skill lompat/slam: nggak boleh kena fall damage pas mendarat. */
    @EventHandler
    public void onFall(EntityDamageEvent event) {
        if (event.getCause() == EntityDamageEvent.DamageCause.FALL
                && event.getEntity() instanceof Player player
                && (GroundSlamSkill.isSlamming(player.getUniqueId()) || Combat.hasFallGuard(player.getUniqueId()))) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        Taps t = taps.remove(id);
        if (t != null && t.task != null) t.task.cancel();
        plugin.skills().forget(id);
        Combat.forget(id);
    }
}
