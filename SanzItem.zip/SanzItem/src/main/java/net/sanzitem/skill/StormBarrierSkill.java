package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Fx;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Storm Barrier: 5 petir tebal turun (nembus langit-langit goa), pulsa melebar, kubah listrik dibangun
 * dari bawah ke atas, lingkaran sihir hexagram nempel di kaki caster, 4 bola listrik berekor ngorbit,
 * heliks di badan, dan busur acak selama buff aktif. Musuh yang kena didorong + aura kejut.
 */
public final class StormBarrierSkill implements Skill {

    /** Radius kubah visual di sekeliling player. */
    private static final double DOME = 2.2;
    private static final double SKY = 24;

    @Override
    public String displayName() {
        return "Storm Barrier";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 7);
        double damage = params.getDouble("damage", 6);
        double knockback = params.getDouble("knockback", 1.4);
        int absorption = Math.max(1, params.getInt("absorption-level", 2));
        int resistance = Math.max(1, params.getInt("resistance-level", 2));
        int ticks = params.getInt("seconds", 8) * 20;

        Location origin = player.getLocation();
        World world = player.getWorld();

        player.swingMainHand();
        player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, ticks, absorption - 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, ticks, resistance - 1));

        for (Entity e : player.getNearbyEntities(radius, radius / 2, radius)) {
            if (!(e instanceof LivingEntity living) || e instanceof ArmorStand) continue;
            if (e instanceof Player other && other.getGameMode() == GameMode.SPECTATOR) continue;

            Vector push = e.getLocation().toVector().subtract(origin.toVector());
            push.setY(0);
            if (push.lengthSquared() < 0.01) {
                push = new Vector(0, 0, 1);
            }
            push.normalize().multiply(knockback).setY(0.4);
            living.setVelocity(push);
            if (damage > 0) {
                living.damage(damage, player);
            }
            world.spawnParticle(Particle.ELECTRIC_SPARK, living.getLocation().add(0, 1, 0), 30, 0.3, 0.6, 0.3, 0.3);
            Fx.shock(plugin, living, 20, Fx.CYAN, Fx.WHITE, Particle.ELECTRIC_SPARK);
        }

        // 4 petir tebal di sekeliling + 1 di caster. Semuanya nembus langit-langit kalau di goa.
        double ringDist = Math.min(3.5, radius / 2);
        double[][] offsets = {{ringDist, 0}, {-ringDist, 0}, {0, ringDist}, {0, -ringDist}, {0, 0}};
        for (double[] o : offsets) {
            Location ground = Fx.groundNear(world, origin.getX() + o[0], origin.getZ() + o[1], origin.getY());
            Fx.skyBolt(ground, SKY, Fx.WHITE, Fx.CYAN);
            if (o[0] != 0 || o[1] != 0) {
                world.strikeLightningEffect(ground);
            }
        }
        world.spawnParticle(Particle.EXPLOSION_EMITTER, origin.clone().add(0, 1, 0), 1);
        world.playSound(origin, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.2f, 1.3f);
        world.playSound(origin, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 1.0f);
        world.playSound(origin, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.5f);

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead() || tick > ticks) {
                    if (player.isOnline() && !player.isDead()) {
                        Location end = player.getLocation().add(0, 1, 0);
                        Fx.burst(end, Particle.END_ROD, 60, 0.4);
                        Fx.burst(end, Particle.ELECTRIC_SPARK, 60, 0.5);
                        Fx.ringDust(player.getLocation().add(0, 0.2, 0), 2.5, 28, Fx.CYAN);
                        world.playSound(end, Sound.BLOCK_BEACON_DEACTIVATE, 1.0f, 1.4f);
                    }
                    cancel();
                    return;
                }

                Location base = player.getLocation();

                // 1. Pulsa ganda melebar sekali di awal
                if (tick < 8) {
                    double r = radius * (tick / 2 + 1) / 4.0;
                    Fx.ringDust(origin.clone().add(0, 0.2, 0), r, (int) (r * 8) + 12, Fx.CYAN);
                    Fx.ringDust(origin.clone().add(0, 0.4, 0), r * 0.8, (int) (r * 6) + 10, Fx.WHITE);
                }

                // 2. Kubah dibangun dari bawah ke atas (12 tick pertama), lalu dijaga tipis-tipis
                if (tick <= 12) {
                    double top = DOME * tick / 12.0;
                    for (double y = 0.2; y <= top; y += 0.4) {
                        double rr = Math.sqrt(Math.max(0, DOME * DOME - (y - 1.1) * (y - 1.1)));
                        Fx.ringDust(base.clone().add(0, y, 0), rr, 28, Fx.CYAN);
                    }
                } else if (tick % 4 == 0) {
                    Fx.sphere(base.clone().add(0, 1.1, 0), DOME, 14, Particle.ELECTRIC_SPARK);
                }

                // 3. Hexagram nempel di kaki caster, berputar
                if (tick % 4 == 0) {
                    Fx.star(base.clone().add(0, 0.1, 0), 2.4, tick * 0.05, 0.6, Fx.CYAN);
                    Fx.ringDust(base.clone().add(0, 0.1, 0), 2.4, 30, Fx.WHITE);
                }

                // 4. Empat bola listrik ngorbit lengkap dengan ekor
                for (int i = 0; i < 4; i++) {
                    double angle = tick * 0.25 + i * (Math.PI / 2);
                    double h = 1.1 + Math.sin(tick * 0.15 + i) * 0.8;
                    for (int k = 0; k < 4; k++) {
                        double a = angle - k * 0.18;
                        Location p = base.clone().add(Math.cos(a) * 1.6, h, Math.sin(a) * 1.6);
                        if (k == 0) {
                            world.spawnParticle(Particle.ELECTRIC_SPARK, p, 3, 0.05, 0.05, 0.05, 0);
                            world.spawnParticle(Particle.END_ROD, p, 1, 0, 0, 0, 0);
                        } else {
                            Fx.dust(p, Fx.CYAN);
                        }
                    }
                }

                // 5. Heliks di badan caster
                Fx.bodyHelix(base, tick, 0.9, Fx.CYAN, Fx.WHITE);

                // 6. Busur listrik acak antar dua titik di kubah, sekitar tiap 1 detik
                if (tick > 12 && tick % 20 == 0) {
                    Fx.bolt(randomOnDome(base), randomOnDome(base), 5, 0.25, Particle.ELECTRIC_SPARK, Fx.CYAN);
                    world.playSound(base, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 0.6f, 1.8f);
                }

                tick += 2;
            }
        }.runTaskTimer(plugin, 0L, 2L);

        return true;
    }

    private static Location randomOnDome(Location base) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        double x, y, z, len;
        do {
            x = rnd.nextGaussian();
            y = rnd.nextGaussian();
            z = rnd.nextGaussian();
            len = Math.sqrt(x * x + y * y + z * z);
        } while (len < 1e-6);
        return base.clone().add(x / len * DOME, 1.1 + y / len * DOME, z / len * DOME);
    }
}
