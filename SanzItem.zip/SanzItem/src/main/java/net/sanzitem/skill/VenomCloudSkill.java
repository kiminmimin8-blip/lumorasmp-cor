package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Venom Cloud: caster melempar kantong racun (busur hijau) ke titik bidikan. Meledak jadi awan
 * beracun yang bertahan beberapa detik: racun, lemah, dan damage berkala buat musuh di dalamnya.
 */
public final class VenomCloudSkill implements Skill {

    @Override
    public String displayName() {
        return "Venom Cloud";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 6);
        int seconds = params.getInt("seconds", 7);
        double tickDamage = params.getDouble("tick-damage", 3.5);
        double range = params.getDouble("range", 20);

        World world = player.getWorld();
        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection();
        RayTraceResult hit = world.rayTraceBlocks(eye, dir, range, FluidCollisionMode.NEVER, true);
        Location aim = (hit == null || hit.getHitPosition() == null)
                ? eye.clone().add(dir.clone().multiply(range))
                : hit.getHitPosition().toLocation(world).subtract(dir.clone().multiply(0.8));
        final Location ground = Fx.groundNear(world, aim.getX(), aim.getZ(), aim.getY());
        final Location from = eye.clone().add(0, -0.4, 0);
        final int flight = 10;

        world.playSound(eye, Sound.ENTITY_SPLASH_POTION_THROW, 1.2f, 0.7f);
        player.swingMainHand();

        int total = flight + seconds * 20;
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                if (tick <= flight) {
                    double p = tick / (double) flight;
                    Location pos = from.clone().add(ground.clone().add(0, 0.8, 0).subtract(from).toVector().multiply(p));
                    pos.add(0, Math.sin(p * Math.PI) * 2.5, 0);
                    Fx.sphere(pos, 0.35, 10, Particle.COMPOSTER);
                    for (int i = 0; i < 6; i++) Fx.dust(pos.clone().add(rnd.nextGaussian() * 0.2, rnd.nextGaussian() * 0.2, rnd.nextGaussian() * 0.2), Palette.VENOM);
                    if (tick == flight) {
                        world.spawnParticle(Particle.EXPLOSION, ground.clone().add(0, 0.8, 0), 1);
                        world.playSound(ground, Sound.ENTITY_GENERIC_SPLASH, 1.5f, 0.6f);
                        world.playSound(ground, Sound.BLOCK_BREWING_STAND_BREW, 1.5f, 0.5f);
                    }
                    return;
                }
                int t = tick - flight;
                double grow = Math.min(1.0, t / 10.0);
                double r = radius * grow;
                for (int i = 0; i < 28; i++) {
                    double a = rnd.nextDouble(Math.PI * 2);
                    double d = Math.sqrt(rnd.nextDouble()) * r;
                    Location p = ground.clone().add(Math.cos(a) * d, rnd.nextDouble(0.2, 2.8), Math.sin(a) * d);
                    Fx.dust(p, i % 3 == 0 ? Palette.LEAF_DARK : Palette.VENOM);
                    if (i % 7 == 0) world.spawnParticle(Particle.SPORE_BLOSSOM_AIR, p, 1, 0.1, 0.1, 0.1, 0.0);
                }
                if (t % 5 == 0) Fx.ringDust(ground.clone().add(0, 0.12, 0), r, 36, Palette.VENOM);
                if (t % 20 == 0) world.playSound(ground, Sound.BLOCK_BREWING_STAND_BREW, 1.0f, 0.6f);

                if (t % 10 == 0) {
                    for (LivingEntity e : Combat.around(player, ground, radius)) {
                        e.damage(tickDamage, player);
                        e.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 60, 1));
                        e.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 0));
                        e.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 80, 0));
                        world.spawnParticle(Particle.COMPOSTER, e.getLocation().add(0, 1, 0), 10, 0.3, 0.6, 0.3, 0.1);
                        Fx.shock(plugin, e, 10, Palette.VENOM, Palette.LEAF_DARK, Particle.SPORE_BLOSSOM_AIR);
                    }
                }
                if (tick >= total) {
                    Fx.burst(ground.clone().add(0, 1, 0), Particle.COMPOSTER, 60, 0.4);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
