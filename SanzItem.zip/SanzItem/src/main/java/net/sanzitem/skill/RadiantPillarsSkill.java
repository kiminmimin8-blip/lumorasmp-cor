package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Radiant Pillars: halo emas muncul di atas kepala caster, lalu satu per satu penanda cahaya
 * (bintang berputar + cincin berdenyut) muncul di sekitar musuh. Sesaat kemudian tiap penanda
 * disambar pilar cahaya dari langit: damage, buta, terbakar, terlempar.
 */
public final class RadiantPillarsSkill implements Skill {

    private static final int TELEGRAPH = 14;

    @Override
    public String displayName() {
        return "Radiant Pillars";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 10);
        int pillars = Math.max(1, params.getInt("pillars", 9));
        int interval = Math.max(1, params.getInt("interval-ticks", 5));
        double impact = params.getDouble("impact-radius", 3);
        double damage = params.getDouble("damage", 12);
        int blindTicks = params.getInt("blind-seconds", 2) * 20;
        double seek = params.getDouble("seek-chance", 0.6);

        World world = player.getWorld();
        world.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.2f, 1.9f);
        world.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.5f, 1.2f);
        player.swingMainHand();

        new BukkitRunnable() {
            int tick = 0;
            int spawned = 0;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }
                // Halo di atas kepala caster
                Location head = player.getLocation().add(0, 2.4, 0);
                Fx.ringDust(head, 0.55, 14, Palette.SUN_CORE);
                Fx.ringDust(head, 0.35, 8, Palette.SUN);
                world.spawnParticle(Particle.END_ROD, head, 1, 0.3, 0.05, 0.3, 0.01);

                if ((tick - 1) % interval == 0 && spawned < pillars) {
                    spawned++;
                    mark(pickSpot());
                }
                if (spawned >= pillars && tick > pillars * interval + 2) cancel();
            }

            private Location pickSpot() {
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                Location base = player.getLocation();
                if (rnd.nextDouble() < seek) {
                    List<LivingEntity> near = Combat.around(player, base, radius);
                    if (!near.isEmpty()) {
                        LivingEntity e = near.get(rnd.nextInt(Math.min(4, near.size())));
                        return Fx.groundNear(world, e.getLocation().getX(), e.getLocation().getZ(), e.getLocation().getY());
                    }
                }
                double a = rnd.nextDouble(Math.PI * 2);
                double r = Math.sqrt(rnd.nextDouble()) * radius;
                return Fx.groundNear(world, base.getX() + Math.cos(a) * r, base.getZ() + Math.sin(a) * r, base.getY());
            }

            /** Penanda: bintang berputar + cincin berdenyut, lalu pilar menyambar. */
            private void mark(Location spot) {
                new BukkitRunnable() {
                    int t = 0;

                    @Override
                    public void run() {
                        t++;
                        Location g = spot.clone().add(0, 0.1, 0);
                        double pulse = impact * (0.6 + 0.4 * Math.abs(Math.sin(t * 0.5)));
                        Fx.ringDust(g, pulse, 24, Palette.SUN);
                        Fx.ringDust(g, impact, 28, Palette.SUN_ORANGE);
                        if (t % 2 == 0) Fx.star(g, impact * 0.8, t * 0.25, 0.5, Palette.SUN_CORE);
                        world.spawnParticle(Particle.END_ROD, spot.clone().add(0, 0.3, 0), 2,
                                impact * 0.4, 0.1, impact * 0.4, 0.05);
                        if (t == 1) world.playSound(spot, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 1.5f);
                        if (t >= TELEGRAPH) {
                            strike(spot);
                            cancel();
                        }
                    }
                }.runTaskTimer(plugin, 0L, 1L);
            }

            private void strike(Location spot) {
                double up = Fx.ceiling(spot.clone().add(0, 0.5, 0), 20);
                Palette.lightColumn(spot, up, 1.0, Palette.SUN_CORE, Palette.SUN);
                Palette.lightColumn(spot, up, 1.9, Palette.SUN, Palette.SUN_ORANGE);
                if (up < 19.9) {
                    Location top = spot.clone().add(0, up, 0);
                    Fx.debris(top.clone().add(0, -0.2, 0), top.clone().add(0, 0.6, 0).getBlock(), 30, 0.7);
                    world.playSound(top, Sound.BLOCK_STONE_BREAK, 1.2f, 0.6f);
                }

                Location mid = spot.clone().add(0, 0.5, 0);
                world.spawnParticle(Particle.EXPLOSION, mid, 1);
                Fx.burst(mid, Particle.END_ROD, 50, 0.5);
                Fx.burst(mid, Particle.FLAME, 40, 0.25);
                Fx.debris(mid, spot.clone().subtract(0, 0.5, 0).getBlock(), 25, 0.8);
                world.playSound(spot, Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 1.2f, 1.2f);
                world.playSound(spot, Sound.ENTITY_GENERIC_EXPLODE, 0.7f, 1.5f);
                world.playSound(spot, Sound.BLOCK_BEACON_DEACTIVATE, 1.0f, 1.6f);

                new BukkitRunnable() {
                    int t = 0;

                    @Override
                    public void run() {
                        t++;
                        Fx.ringDust(spot.clone().add(0, 0.15, 0), t * impact / 3.0, 32, Palette.SUN_CORE);
                        Fx.ringDust(spot.clone().add(0, 0.3, 0), t * impact / 4.0, 20, Palette.SUN_ORANGE);
                        if (t >= 4) cancel();
                    }
                }.runTaskTimer(plugin, 0L, 1L);

                for (LivingEntity e : Combat.around(player, spot, impact)) {
                    Combat.damage(player, e, damage);
                    e.setFireTicks(40);
                    e.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, blindTicks, 0, false, false, true));
                    Combat.push(e, spot, 0.5, 0.5);
                    Location c = e.getLocation().add(0, 1, 0);
                    world.spawnParticle(Particle.END_ROD, c, 20, 0.3, 0.6, 0.3, 0.2);
                    Fx.shock(plugin, e, 20, Palette.SUN, Palette.SUN_CORE, Particle.FLAME);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
