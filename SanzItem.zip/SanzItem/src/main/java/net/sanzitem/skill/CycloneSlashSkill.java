package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Cyclone Slash: caster berputar 2x sambil nebas. Bilah angin melingkar, musuh terhisap ke tengah
 * dan kena 4 tebasan beruntun, ditutup ledakan angin yang melempar semuanya.
 */
public final class CycloneSlashSkill implements Skill {

    private static final int SPIN_TICKS = 16;

    @Override
    public String displayName() {
        return "Cyclone Slash";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 6);
        double damage = params.getDouble("damage", 5);
        double pull = params.getDouble("pull", 0.45);

        World world = player.getWorld();
        world.playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.5f, 0.6f);
        world.playSound(player.getLocation(), Sound.ENTITY_BREEZE_WIND_BURST, 1.2f, 0.8f);

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }
                Location base = player.getLocation();
                // Caster ikut berputar: 2 putaran penuh
                player.setRotation(base.getYaw() + 45f, base.getPitch());
                if (tick % 3 == 0) player.swingMainHand();

                double spin = tick * Math.PI / 4;
                // 3 bilah angin melengkung (busur) mengitari caster di tiga tinggi
                for (int blade = 0; blade < 3; blade++) {
                    double h = 0.4 + blade * 0.6;
                    for (int i = 0; i < 14; i++) {
                        double a = spin + blade * 2.1 - i * 0.09;
                        double r = radius * 0.55 * (1 - i * 0.02);
                        Location p = base.clone().add(Math.cos(a) * r, h, Math.sin(a) * r);
                        if (i < 3) {
                            world.spawnParticle(Particle.SWEEP_ATTACK, p, 1, 0, 0, 0, 0);
                        }
                        Fx.dust(p, i % 2 == 0 ? Fx.WHITE : Fx.CYAN);
                    }
                }
                Fx.ring(base.clone().add(0, 0.2, 0), radius * 0.8, 32, Particle.CLOUD);
                world.spawnParticle(Particle.GUST, base.clone().add(0, 1, 0), 1, 1.5, 0.3, 1.5, 0);
                Fx.debris(base.clone().add(0, 0.2, 0), base.clone().subtract(0, 0.5, 0).getBlock(), 4, radius * 0.4);

                // Tiap 4 tick: sedot musuh dan tebas
                if (tick % 4 == 0 && tick < SPIN_TICKS) {
                    world.playSound(base, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 0.8f + tick * 0.03f);
                    for (LivingEntity e : Combat.around(player, base, radius)) {
                        Combat.damage(player, e, damage);
                        Combat.pull(e, base, pull, 0.2);
                        world.spawnParticle(Particle.SWEEP_ATTACK, e.getLocation().add(0, 1, 0), 2, 0.4, 0.4, 0.4, 0);
                        world.spawnParticle(Particle.CRIT, e.getLocation().add(0, 1, 0), 14, 0.3, 0.5, 0.3, 0.4);
                    }
                } else if (tick % 2 == 0 && tick < SPIN_TICKS) {
                    // Sedotan halus antar tebasan
                    for (LivingEntity e : Combat.around(player, base, radius)) {
                        Combat.pull(e, base, pull * 0.5, 0.05);
                    }
                }

                if (tick >= SPIN_TICKS) {
                    finale(base);
                    cancel();
                }
            }

            private void finale(Location base) {
                world.spawnParticle(Particle.EXPLOSION, base.clone().add(0, 1, 0), 3, 0.8, 0.3, 0.8, 0);
                world.spawnParticle(Particle.SONIC_BOOM, base.clone().add(0, 1, 0), 1);
                Fx.burst(base.clone().add(0, 1, 0), Particle.CLOUD, 80, 0.6);
                Fx.ringDust(base.clone().add(0, 0.2, 0), radius, 48, Fx.WHITE);
                Fx.ringDust(base.clone().add(0, 0.2, 0), radius * 0.6, 32, Fx.CYAN);
                world.playSound(base, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.8f, 1.6f);
                world.playSound(base, Sound.ENTITY_BREEZE_WIND_BURST, 1.5f, 0.6f);
                for (LivingEntity e : Combat.around(player, base, radius)) {
                    Combat.damage(player, e, damage * 1.5);
                    Combat.push(e, base, 1.6, 0.6);
                    Fx.shock(plugin, e, 20, Fx.WHITE, Fx.CYAN, Particle.CLOUD);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
