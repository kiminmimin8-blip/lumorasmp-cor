package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Tsunami (ultimate): caster nyedot air jadi bola, lalu dinding air melebar ke semua arah dari caster.
 * Musuh yang tersapu terlempar keluar dan basah kuyup. Caster dapat Dolphin's Grace singkat.
 */
public final class TsunamiSkill implements Skill {

    @Override
    public String displayName() {
        return "Tsunami";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 14);
        double damage = params.getDouble("damage", 22);
        double knockback = params.getDouble("knockback", 1.8);

        World world = player.getWorld();
        world.playSound(player.getLocation(), Sound.ENTITY_DROWNED_AMBIENT_WATER, 1.5f, 0.5f);
        world.playSound(player.getLocation(), Sound.AMBIENT_UNDERWATER_ENTER, 1.5f, 0.5f);
        player.swingMainHand();
        player.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, 160, 1));

        new BukkitRunnable() {
            int tick = 0;
            Location center;
            final Set<LivingEntity> hit = new HashSet<>();

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }
                if (tick <= 12) {
                    Location body = player.getLocation().add(0, 1, 0);
                    double p = tick / 12.0;
                    Fx.sphere(body, 3.0 * (1 - p) + 0.6, 24, Particle.SPLASH);
                    Fx.bodyHelix(player.getLocation(), tick * 2, 0.9, Palette.WATER, Palette.FOAM);
                    Fx.ringDust(player.getLocation().add(0, 0.1, 0), radius * (1 - p) * 0.5 + 1, 28, Palette.WATER_DEEP);
                    if (tick == 12) {
                        center = player.getLocation().clone();
                        world.spawnParticle(Particle.EXPLOSION_EMITTER, center.clone().add(0, 1, 0), 1);
                        world.playSound(center, Sound.ENTITY_GENERIC_SPLASH, 2.0f, 0.4f);
                        world.playSound(center, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.0f, 0.6f);
                    }
                    return;
                }
                int w = tick - 12;
                double r = radius * w / 16.0;
                int pts = (int) (r * 5) + 16;
                for (int i = 0; i < pts; i++) {
                    double a = i * Math.PI * 2 / pts;
                    Location g = Fx.groundNear(world, center.getX() + Math.cos(a) * r,
                            center.getZ() + Math.sin(a) * r, center.getY());
                    for (double y = 0.2; y <= 3.0; y += 0.55) {
                        Fx.dust(g.clone().add(0, y, 0), y > 2.4 ? Palette.FOAM : Palette.WATER);
                    }
                    if (i % 3 == 0) world.spawnParticle(Particle.SPLASH, g.clone().add(0, 3.0, 0), 3, 0.2, 0.1, 0.2, 0.15);
                }
                if (w % 3 == 0) world.playSound(center, Sound.ENTITY_PLAYER_SWIM, 1.5f, 0.5f);

                for (LivingEntity e : Combat.around(player, center, r + 1.5)) {
                    double d = e.getLocation().distance(center);
                    if (d < r - 2.5 || !hit.add(e)) continue;
                    Combat.damage(player, e, damage);
                    Combat.push(e, center, knockback, 0.7);
                    e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1));
                    world.spawnParticle(Particle.SPLASH, e.getLocation().add(0, 1, 0), 60, 0.5, 0.9, 0.5, 0.3);
                    Fx.shock(plugin, e, 30, Palette.WATER, Palette.FOAM, Particle.BUBBLE_POP);
                }
                if (w >= 16) {
                    world.spawnParticle(Particle.SPLASH, center.clone().add(0, 3, 0), 200, radius * 0.5, 0.5, radius * 0.5, 0.2);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
