package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.item.SkillSpec;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class SkillManager {

    private final SanzItem plugin;
    private final Map<String, Skill> skills = new HashMap<>();
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();
    /** Skill terpilih per player per pemilik (itemId atau "set:id"). */
    private final Map<UUID, Map<String, Integer>> selected = new HashMap<>();
    private final Map<UUID, Long> lastCycle = new HashMap<>();

    public SkillManager(SanzItem plugin) {
        this.plugin = plugin;
        register("lightning_strike", new LightningStrikeSkill());
        register("thunder_dash", new ThunderDashSkill());
        register("storm_nova", new StormNovaSkill());
        register("berserker_roar", new BerserkerRoarSkill());
        register("cyclone_slash", new CycloneSlashSkill());
        register("ground_slam", new GroundSlamSkill());
        register("starfall", new StarfallSkill());
        register("starlight_mend", new StarlightMendSkill());
        register("singularity", new SingularitySkill());
        register("meteor_shower", new MeteorShowerSkill());
        register("comet_strike", new CometStrikeSkill());
        register("void_domain", new VoidDomainSkill());
        register("storm_barrier", new StormBarrierSkill());
        register("gale_step", new GaleStepSkill());
        register("static_storm", new StaticStormSkill());
    }

    private void register(String type, Skill skill) {
        skills.put(type, skill);
    }

    public String displayName(String type) {
        Skill s = skills.get(type);
        return s == null ? type : s.displayName();
    }

    // ------------------------------------------------------------- pilihan

    public int selectedIndex(Player player, String owner, int size) {
        int i = selected.getOrDefault(player.getUniqueId(), Map.of()).getOrDefault(owner, 0);
        return size <= 0 ? 0 : Math.floorMod(i, size);
    }

    public long cooldownLeftMs(Player player, String owner, SkillSpec spec) {
        Map<String, Long> mine = cooldowns.get(player.getUniqueId());
        if (mine == null) return 0;
        return Math.max(0, mine.getOrDefault(owner + ":" + spec.type(), 0L) - System.currentTimeMillis());
    }

    /** Tampilkan skill terpilih di actionbar. */
    public void showSelected(Player player, String owner, List<SkillSpec> list) {
        if (list.isEmpty()) return;
        int idx = selectedIndex(player, owner, list.size());
        SkillSpec spec = list.get(idx);
        long left = cooldownLeftMs(player, owner, spec);
        String status = left > 0 ? "<red>" + ((left + 999) / 1000) + "s" : "<green>siap";
        player.sendActionBar(plugin.bar("skill-selected",
                "index", String.valueOf(idx + 1), "total", String.valueOf(list.size()),
                "skill", displayName(spec.type()), "status", status));
    }

    /** Ganti ke skill berikutnya (ada debounce biar klik ganda Bedrock nggak loncat 2x). */
    public void cycle(Player player, String owner, List<SkillSpec> list) {
        if (list.size() < 2) {
            showSelected(player, owner, list);
            return;
        }
        long now = System.currentTimeMillis();
        Long last = lastCycle.get(player.getUniqueId());
        if (last != null && now - last < 250) return;
        lastCycle.put(player.getUniqueId(), now);

        int next = (selectedIndex(player, owner, list.size()) + 1) % list.size();
        selected.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>()).put(owner, next);
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.3f);
        showSelected(player, owner, list);
    }

    // ---------------------------------------------------------------- cast

    /** Pakai skill yang lagi terpilih. */
    public void castSelected(Player player, String owner, List<SkillSpec> list) {
        if (list.isEmpty()) return;
        castAt(player, owner, list, selectedIndex(player, owner, list.size()));
    }

    /** Pakai skill pada index tertentu (dipakai armor: sneak 2x/3x/4x). */
    public void castAt(Player player, String owner, List<SkillSpec> list, int index) {
        if (index < 0 || index >= list.size()) return;
        SkillSpec spec = list.get(index);
        Skill skill = skills.get(spec.type());
        if (skill == null) {
            plugin.getLogger().warning("Tipe skill nggak dikenal: " + spec.type());
            return;
        }

        long now = System.currentTimeMillis();
        Map<String, Long> mine = cooldowns.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>());
        String key = owner + ":" + spec.type();
        long until = mine.getOrDefault(key, 0L);
        if (until > now) {
            long left = (until - now + 999) / 1000;
            player.sendActionBar(plugin.bar("cooldown", "time", String.valueOf(left)));
            return;
        }

        if (skill.cast(plugin, player, spec.params())) {
            mine.put(key, now + spec.cooldown() * 1000L);
            player.sendActionBar(plugin.bar("skill-used", "skill", skill.displayName()));
        }
    }

    public void forget(UUID id) {
        selected.remove(id);
        lastCycle.remove(id);
        // cooldown sengaja dibiarkan supaya relog nggak mereset cooldown
    }
}
