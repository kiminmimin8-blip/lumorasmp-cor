package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Storm Nova: energi petir ditarik masuk ke caster (bola menyusut), lalu meledak jadi bola listrik
 * melebar + petir menyebar ke semua arah + petir langit nyambar tiap korban.
 */
public final class StormNovaSkill implements Skill {

    private static final int CHARGE = 14;
    private static final int EXPAND = 10;

    @Override
    public String displayName() {
        return "Storm Nova";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 9);
        double damage = params.getDouble("damage", 15);
        double knockback = params.getDouble("knockback", 1.2);

        World world = player.getWorld();
        world.playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1.5f, 1.4f);
        player.swingMainHand();

        new BukkitRunnable() {
            int tick = 0;
            Location center;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }
                ThreadLocalRandom rnd = ThreadLocalRandom.current();

                if (tick <= CHARGE) {
                    Location body = player.getLocation().add(0, 1, 0);
                    double p = tick / (double) CHARGE;
                    Fx.sphere(body, 3.2 * (1 - p) + 0.5, 22, Particle.ELECTRIC_SPARK);
                    Fx.bodyHelix(player.getLocation(), tick * 2, 0.9, Fx.CYAN, Fx.WHITE);
                    Fx.ringDust(player.getLocation().add(0, 0.1, 0), radius * (1 - p) + 1, 30, Fx.CYAN);
                    // Garis energi tertarik masuk dari 3 arah acak
                    for (int i = 0; i < 3; i++) {
                        double a = rnd.nextDouble(Math.PI * 2);
                        Location src = body.clone().add(Math.cos(a) * 4, rnd.nextDouble(-0.5, 1.5), Math.sin(a) * 4);
                        Fx.bolt(src, body, 4, 0.3, Particle.ELECTRIC_SPARK, Fx.WHITE);
                    }
                    if (tick % 4 == 0) {
                        world.playSound(body, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1.0f, 0.8f + (float) p);
                    }
                    if (tick == CHARGE) {
                        center = player.getLocation().clone();
                        detonate();
                    }
                    return;
                }

                int w = tick - CHARGE;
                double r = radius * w / EXPAND;
                Location mid = center.clone().add(0, 1, 0);
                Fx.sphere(mid, r, (int) (30 + r * 10), Particle.ELECTRIC_SPARK);
                Fx.sphere(mid, r * 0.92, (int) (14 + r * 5), Particle.END_ROD);
                Fx.ringDust(center.clone().add(0, 0.2, 0), r, (int) (r * 8) + 12, Fx.CYAN);
                Fx.ringDust(center.clone().add(0, 0.2, 0), r * 0.75, (int) (r * 6) + 10, Fx.WHITE);
                // Petir menyebar dari pusat ke tepi gelombang
                for (int i = 0; i < 3; i++) {
                    double a = rnd.nextDouble(Math.PI * 2);
                    Location edge = Fx.groundNear(world, center.getX() + Math.cos(a) * r, center.getZ() + Math.sin(a) * r,
                            center.getY()).add(0, 0.6, 0);
                    Fx.bolt(mid, edge, 5, 0.6, Particle.ELECTRIC_SPARK, Fx.CYAN);
                }
                if (w >= EXPAND) cancel();
            }

            private void detonate() {
                world.spawnParticle(Particle.EXPLOSION_EMITTER, center.clone().add(0, 1, 0), 1);
                Fx.burst(center.clone().add(0, 1, 0), Particle.ELECTRIC_SPARK, 150, 0.9);
                Fx.pillar(center, 6, 0.7, Fx.WHITE);
                Fx.debris(center.clone().add(0, 0.3, 0), center.clone().subtract(0, 0.5, 0).getBlock(), 60, 1.4);
                world.playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.6f, 0.8f);
                world.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.2f);
                world.playSound(center, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.8f, 1.5f);

                List<LivingEntity> victims = Combat.around(player, center, radius);
                for (LivingEntity e : victims) {
                    Combat.damage(player, e, damage);
                    Combat.push(e, center, knockback, 0.55);
                    Fx.skyBolt(Fx.groundNear(world, e.getLocation().getX(), e.getLocation().getZ(),
                            e.getLocation().getY()), 14, Fx.CYAN, Fx.WHITE);
                    Fx.shock(plugin, e, 30, Fx.CYAN, Fx.WHITE, Particle.ELECTRIC_SPARK);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
