package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Absolute Zero (ultimate): kristal es naik mengelilingi caster, bintang es berputar di tanah dan
 * salju tertarik masuk. Lalu ledakan dingin melebar. Semua musuh di area terkunci dalam bongkahan es
 * (nggak bisa gerak) dan kena damage, lalu pecah berkeping-keping dengan damage tambahan.
 */
public final class AbsoluteZeroSkill implements Skill {

    private static final int CHARGE = 16;
    private static final int EXPAND = 10;

    @Override
    public String displayName() {
        return "Absolute Zero";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 10);
        int freezeTicks = params.getInt("freeze-seconds", 4) * 20;
        double damage = params.getDouble("damage", 10);
        double shatter = params.getDouble("shatter-damage", 16);

        World world = player.getWorld();
        world.playSound(player.getLocation(), Sound.ENTITY_PLAYER_HURT_FREEZE, 1.6f, 0.5f);
        world.playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1.2f, 1.8f);
        player.swingMainHand();

        new BukkitRunnable() {
            int tick = 0;
            int holdLeft = freezeTicks;
            Location center;
            final List<LivingEntity> frozen = new ArrayList<>();

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead()) {
                    release();
                    cancel();
                    return;
                }
                ThreadLocalRandom rnd = ThreadLocalRandom.current();

                // ---------------- fase 1: charge
                if (tick <= CHARGE) {
                    double p = tick / (double) CHARGE;
                    Location base = player.getLocation();
                    Location body = base.clone().add(0, 1, 0);
                    Fx.sphere(body, 3.4 * (1 - p) + 0.6, 24, Particle.SNOWFLAKE);
                    Fx.bodyHelix(base, tick * 2, 0.9, Palette.ICE, Palette.FROST_WHITE);
                    Fx.star(base.clone().add(0, 0.1, 0), 1.5 + p * radius * 0.55, tick * 0.18, 0.45, Palette.ICE);
                    Fx.ringDust(base.clone().add(0, 0.1, 0), radius * (1 - p) + 1, 36, Palette.ICE_DEEP);
                    if (tick % 2 == 0) {
                        for (int k = 0; k < 4; k++) {
                            double a = tick * 0.4 + k * Math.PI / 2;
                            Location g = Fx.groundNear(world, base.getX() + Math.cos(a) * 3.0,
                                    base.getZ() + Math.sin(a) * 3.0, base.getY());
                            Palette.spike(g, 0.6 + p * 2.4, 0.5, Palette.ICE, Palette.ICE_DEEP);
                        }
                    }
                    if (tick % 4 == 0) {
                        world.playSound(body, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1.0f, 0.7f + (float) p);
                    }
                    if (tick == CHARGE) {
                        center = base.clone();
                        detonate();
                    }
                    return;
                }

                // ---------------- fase 2: gelombang melebar
                int w = tick - CHARGE;
                if (w <= EXPAND) {
                    expansion(w, rnd);
                }

                // ---------------- fase 3: musuh terkunci es
                holdLeft--;
                if (tick % 2 == 0) shells();
                if (tick % 10 == 0) refreeze();
                if (holdLeft <= 0) {
                    shatterAll();
                    cancel();
                }
            }

            private void detonate() {
                Location mid = center.clone().add(0, 1, 0);
                world.spawnParticle(Particle.SONIC_BOOM, mid, 1);
                Fx.burst(mid, Particle.CLOUD, 120, 0.5);
                Fx.burst(mid, Particle.SNOWFLAKE, 250, 0.6);
                Fx.burst(mid, Particle.END_ROD, 100, 0.7);
                Fx.pillar(center, 6, 0.8, Palette.FROST_WHITE);
                Palette.block(center.clone().add(0, 0.3, 0), Material.PACKED_ICE, 100, 1.5, 0.3);
                world.playSound(center, Sound.BLOCK_GLASS_BREAK, 1.8f, 0.5f);
                world.playSound(center, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.0f, 1.8f);
                world.playSound(center, Sound.BLOCK_AMETHYST_CLUSTER_BREAK, 1.6f, 0.6f);

                for (LivingEntity e : Combat.around(player, center, radius)) {
                    Combat.damage(player, e, damage);
                    e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, freezeTicks + 10, 6, false, false, true));
                    e.setFreezeTicks(e.getMaxFreezeTicks() + 40);
                    e.setVelocity(new Vector(0, 0.1, 0));
                    frozen.add(e);
                    Location c = e.getLocation().add(0, 1, 0);
                    Palette.block(c, Material.ICE, 50, 0.5, 0.25);
                    world.spawnParticle(Particle.SNOWFLAKE, c, 40, 0.4, 0.8, 0.4, 0.2);
                    world.playSound(c, Sound.ENTITY_PLAYER_HURT_FREEZE, 1.2f, 0.7f);
                }
            }

            private void expansion(int w, ThreadLocalRandom rnd) {
                double r = radius * w / EXPAND;
                Location mid = center.clone().add(0, 1, 0);
                Fx.sphere(mid, r, (int) (30 + r * 10), Particle.SNOWFLAKE);
                Fx.sphere(mid, r * 0.9, (int) (14 + r * 4), Particle.END_ROD);
                Fx.ringDust(center.clone().add(0, 0.2, 0), r, (int) (r * 8) + 12, Palette.ICE);
                Fx.ringDust(center.clone().add(0, 0.2, 0), r * 0.7, (int) (r * 6) + 10, Palette.FROST_WHITE);
                for (int i = 0; i < 4; i++) {
                    double a = rnd.nextDouble(Math.PI * 2);
                    Location g = Fx.groundNear(world, center.getX() + Math.cos(a) * r,
                            center.getZ() + Math.sin(a) * r, center.getY());
                    Palette.spike(g, 1.2 + rnd.nextDouble(2.0), 0.5, Palette.ICE, Palette.ICE_DEEP);
                }
            }

            /** Cangkang es di sekeliling tiap musuh yang terkunci. */
            private void shells() {
                for (LivingEntity e : frozen) {
                    if (!e.isValid() || e.isDead()) continue;
                    double hw = e.getWidth() / 2 + 0.15;
                    double hh = e.getHeight() / 2;
                    Location c = e.getLocation().add(0, hh, 0);
                    world.spawnParticle(Particle.BLOCK, c, 8, hw, hh, hw, 0, Material.PACKED_ICE.createBlockData());
                    if (tick % 4 == 0) {
                        for (int sx = -1; sx <= 1; sx += 2) {
                            for (int sz = -1; sz <= 1; sz += 2) {
                                for (double y = -hh; y <= hh; y += 0.5) {
                                    Fx.dust(c.clone().add(sx * hw, y, sz * hw), Palette.ICE);
                                }
                            }
                        }
                        world.spawnParticle(Particle.SNOWFLAKE, c, 2, hw, hh, hw, 0.01);
                    }
                }
            }

            private void refreeze() {
                for (LivingEntity e : frozen) {
                    if (e.isValid() && !e.isDead()) e.setFreezeTicks(e.getMaxFreezeTicks() + 40);
                }
            }

            private void shatterAll() {
                for (LivingEntity e : frozen) {
                    if (!e.isValid() || e.isDead()) continue;
                    e.removePotionEffect(PotionEffectType.SLOWNESS);
                    e.setFreezeTicks(0);
                    e.setNoDamageTicks(0);
                    Combat.damage(player, e, shatter);
                    e.setVelocity(new Vector(0, 0.5, 0));
                    Location c = e.getLocation().add(0, 1, 0);
                    Palette.block(c, Material.ICE, 120, 0.6, 0.4);
                    Palette.block(c, Material.BLUE_ICE, 60, 0.5, 0.35);
                    Fx.burst(c, Particle.SNOWFLAKE, 40, 0.25);
                    Fx.burst(c, Particle.END_ROD, 20, 0.3);
                    world.playSound(c, Sound.BLOCK_GLASS_BREAK, 1.4f, 0.6f);
                }
            }

            /** Caster keluar/mati: lepasin semua yang masih beku. */
            private void release() {
                for (LivingEntity e : frozen) {
                    if (!e.isValid() || e.isDead()) continue;
                    e.removePotionEffect(PotionEffectType.SLOWNESS);
                    e.setFreezeTicks(0);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
