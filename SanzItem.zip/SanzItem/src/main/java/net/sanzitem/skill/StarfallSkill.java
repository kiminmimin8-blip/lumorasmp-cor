package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Fx;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Starfall: caster memanggil bintang. Bintang tersedot ke badan, pilar emas naik, lingkaran sihir
 * hexagram muncul di tanah, tangan caster mengayun tiap bintang dilepas. Bintang jatuh berekor komet
 * (mulai dari bawah langit-langit kalau di goa, dengan puing di titik tembus), sebagian ngejar musuh.
 * Korban kena aura emas.
 */
public final class StarfallSkill implements Skill {

    /** Lama satu bintang jatuh dari langit sampai mendarat (tick). */
    private static final int FALL_TICKS = 8;
    private static final double FALL_HEIGHT = 16;

    @Override
    public String displayName() {
        return "Starfall";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 10);
        int strikes = Math.max(1, params.getInt("strikes", 12));
        int interval = Math.max(1, params.getInt("interval-ticks", 10));
        double impactRadius = params.getDouble("impact-radius", 3);
        double damage = params.getDouble("damage", 9);
        double seekChance = Math.max(0, Math.min(1, params.getDouble("seek-chance", 0.5)));

        // Nggak ada target di area = skill batal, cooldown nggak kepake
        boolean anyTarget = player.getNearbyEntities(radius, radius, radius).stream()
                .anyMatch(e -> e instanceof LivingEntity le && valid(player, le));
        if (!anyTarget) {
            player.sendActionBar(plugin.bar("no-target"));
            return false;
        }

        Location center = player.getLocation().clone();
        World world = center.getWorld();
        world.playSound(center, Sound.BLOCK_BEACON_POWER_SELECT, 1.0f, 1.6f);
        world.playSound(center, Sound.BLOCK_END_PORTAL_SPAWN, 0.4f, 1.8f);
        world.playSound(center, Sound.ENTITY_EVOKER_CAST_SPELL, 1.0f, 1.2f);
        player.swingMainHand();

        int duration = 10 + strikes * interval + FALL_TICKS;
        double pillarUp = Fx.ceiling(center.clone().add(0, 0.5, 0), 14);

        // Lingkaran sihir di tanah + animasi di caster
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (tick > duration || !player.isOnline()) {
                    cancel();
                    return;
                }

                // Lingkaran sihir: cincin emas + cincin putih + hexagram berputar, membesar di awal
                double cr = Math.min(radius * 0.6, 6.0) * Math.min(1.0, tick / 10.0);
                double rotation = tick * 0.05;
                Location ground = center.clone().add(0, 0.1, 0);
                Fx.ringDust(ground, cr, 40, Fx.GOLD);
                Fx.ringDust(ground, cr * 0.55, 24, Fx.WHITE);
                Fx.star(ground, cr, rotation, 1.2, Fx.GOLD);
                if (tick % 6 == 0) {
                    world.spawnParticle(Particle.END_ROD, center.clone().add(0, 0.2, 0), 6,
                            cr * 0.5, 0.1, cr * 0.5, 0.02);
                }

                // Animasi di CASTER
                Location me = player.getLocation();
                Fx.bodyHelix(me, tick, 0.8, Fx.GOLD, Fx.WHITE);
                if (tick < 10) {
                    // Bintang-bintang tersedot ke badan + pilar emas naik
                    Fx.sphere(me.clone().add(0, 1, 0), 3.0 * (1 - tick / 10.0) + 0.4, 10, Particle.END_ROD);
                    Fx.pillar(center, pillarUp, 0.9, Fx.GOLD);
                } else {
                    // Aliran bintang naik terus dari atas kepala caster
                    ThreadLocalRandom rnd = ThreadLocalRandom.current();
                    for (int i = 0; i < 3; i++) {
                        world.spawnParticle(Particle.END_ROD, me.clone().add(0, 2.2, 0), 0,
                                rnd.nextDouble(-0.1, 0.1), 1.0, rnd.nextDouble(-0.1, 0.1), 0.5);
                    }
                }
                tick += 2;
            }
        }.runTaskTimer(plugin, 0L, 2L);

        new BukkitRunnable() {
            int fired = 0;

            @Override
            public void run() {
                if (!player.isOnline() || fired >= strikes) {
                    cancel();
                    return;
                }
                fired++;
                player.swingMainHand();

                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                Location impact = null;

                // Sebagian bintang ngejar posisi musuh saat ini (musuh masih bisa kabur pas penanda muncul)
                if (rnd.nextDouble() < seekChance) {
                    List<LivingEntity> pool = new ArrayList<>();
                    for (LivingEntity le : world.getNearbyLivingEntities(center, radius)) {
                        if (valid(player, le)) pool.add(le);
                    }
                    if (!pool.isEmpty()) {
                        Location at = pool.get(rnd.nextInt(pool.size())).getLocation();
                        impact = Fx.groundNear(world, at.getX(), at.getZ(), at.getY());
                    }
                }

                if (impact == null) {
                    double angle = rnd.nextDouble(0, Math.PI * 2);
                    double dist = Math.sqrt(rnd.nextDouble()) * radius;
                    impact = Fx.groundNear(world,
                            center.getX() + Math.cos(angle) * dist,
                            center.getZ() + Math.sin(angle) * dist,
                            center.getY());
                }

                spawnFallingStar(plugin, player, impact, impactRadius, damage);
            }
        }.runTaskTimer(plugin, 10L, interval);

        return true;
    }

    private void spawnFallingStar(SanzItem plugin, Player player, Location impact,
                                  double impactRadius, double damage) {
        World world = impact.getWorld();
        if (world == null) return;

        // Tinggi jatuh dibatasi langit-langit: di goa bintang mulai tepat di bawah langit-langit
        double fallHeight = Math.min(FALL_HEIGHT, Fx.ceiling(impact.clone().add(0, 0.5, 0), FALL_HEIGHT));
        boolean capped = fallHeight < FALL_HEIGHT - 0.05;

        if (capped) {
            // Bintang nembus langit-langit: puing, asap, percikan
            Location top = impact.clone().add(0, fallHeight, 0);
            Fx.debris(top.clone().add(0, -0.2, 0), top.clone().add(0, 0.6, 0).getBlock(), 30, 0.7);
            world.spawnParticle(Particle.LARGE_SMOKE, top, 8, 0.4, 0.2, 0.4, 0.02);
            world.playSound(top, Sound.BLOCK_STONE_BREAK, 1.2f, 0.7f);
        }
        world.playSound(impact, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.8f, 1.5f);

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;

                // Penanda: cincin merah berdenyut + cincin emas tetap di batas ledakan
                double pulse = impactRadius * (0.65 + 0.35 * Math.abs(Math.sin(tick * 0.8)));
                Fx.ringDust(impact.clone().add(0, 0.1, 0), pulse, 20, Fx.RED);
                Fx.ringDust(impact.clone().add(0, 0.1, 0), impactRadius, 20, Fx.GOLD);

                // Bintang jatuh + ekor komet bergradasi emas ke merah
                double h = fallHeight * (1 - (double) tick / FALL_TICKS);
                Location star = impact.clone().add(0, h, 0);
                world.spawnParticle(Particle.END_ROD, star, 6, 0.15, 0.15, 0.15, 0.02);
                world.spawnParticle(Particle.FIREWORK, star, 3, 0.1, 0.1, 0.1, 0.03);
                for (int k = 1; k <= 8; k++) {
                    Fx.trail(star.clone().add(0, k * 0.5, 0), Fx.GOLD_TO_RED);
                }

                if (tick < FALL_TICKS) return;
                cancel();

                // Pendaratan: ledakan, semburan bintang, puing, gelombang kejut emas
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                world.spawnParticle(Particle.EXPLOSION, impact.clone().add(0, 0.5, 0), 2, 0.4, 0.2, 0.4, 0);
                Fx.burst(impact.clone().add(0, 0.5, 0), Particle.END_ROD, 50, 0.3);
                Fx.debris(impact.clone().add(0, 0.3, 0), impact.clone().subtract(0, 0.5, 0).getBlock(), 30, 0.8);
                for (int i = 0; i < 16; i++) {
                    world.spawnParticle(Particle.END_ROD, impact, 0,
                            rnd.nextDouble(-0.4, 0.4), 1.0, rnd.nextDouble(-0.4, 0.4), 0.3);
                }
                new BukkitRunnable() {
                    int t = 0;

                    @Override
                    public void run() {
                        t++;
                        Fx.ringDust(impact.clone().add(0, 0.15, 0), t * impactRadius / 3.0, 22, Fx.GOLD);
                        Fx.ringDust(impact.clone().add(0, 0.3, 0), t * impactRadius / 4.0, 16, Fx.WHITE);
                        if (t >= 4) cancel();
                    }
                }.runTaskTimer(plugin, 0L, 1L);

                world.playSound(impact, Sound.ENTITY_GENERIC_EXPLODE, 0.7f, 1.3f);
                world.playSound(impact, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1.0f, 0.9f);
                world.playSound(impact, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 1.4f);

                for (LivingEntity target : world.getNearbyLivingEntities(impact, impactRadius)) {
                    if (!valid(player, target)) continue;
                    if (player.isOnline()) {
                        target.damage(damage, player);
                    } else {
                        target.damage(damage);
                    }
                    target.setVelocity(target.getVelocity().add(new Vector(0, 0.35, 0)));
                    Fx.shock(plugin, target, 20, Fx.GOLD, Fx.WHITE, Particle.END_ROD);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private static boolean valid(Player caster, LivingEntity e) {
        if (e.equals(caster) || e instanceof ArmorStand) return false;
        return !(e instanceof Player other && other.getGameMode() == GameMode.SPECTATOR);
    }
}
