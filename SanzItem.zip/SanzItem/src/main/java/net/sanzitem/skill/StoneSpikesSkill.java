package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Stone Spikes: tanda merah muncul di tanah sekitar titik bidikan, lalu duri-duri batu menyembul
 * satu per satu (melempar musuh ke atas) dan ditutup satu duri raksasa di tengah.
 */
public final class StoneSpikesSkill implements Skill {

    @Override
    public String displayName() {
        return "Stone Spikes";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 7);
        int spikes = Math.max(3, params.getInt("spikes", 14));
        double damage = params.getDouble("damage", 11);
        double finalDamage = params.getDouble("final-damage", 20);
        double range = params.getDouble("range", 20);

        World world = player.getWorld();
        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection();
        RayTraceResult hit = world.rayTraceBlocks(eye, dir, range, FluidCollisionMode.NEVER, true);
        Location aim = (hit == null || hit.getHitPosition() == null)
                ? eye.clone().add(dir.clone().multiply(range))
                : hit.getHitPosition().toLocation(world);
        final Location center = Fx.groundNear(world, aim.getX(), aim.getZ(), aim.getY());

        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        List<Location> spots = new ArrayList<>();
        for (int i = 0; i < spikes; i++) {
            double a = rnd.nextDouble(Math.PI * 2);
            double d = Math.sqrt(rnd.nextDouble()) * radius;
            spots.add(Fx.groundNear(world, center.getX() + Math.cos(a) * d, center.getZ() + Math.sin(a) * d, center.getY()));
        }

        world.playSound(center, Sound.ENTITY_IRON_GOLEM_ATTACK, 1.5f, 0.5f);
        player.swingMainHand();
        final int finalTick = 10 + spikes * 2 + 8;

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                if (player.isOnline() && !player.isDead() && tick <= 10) {
                    Fx.bodyHelix(player.getLocation(), tick * 2, 0.8, Palette.EARTH, Palette.STONE);
                    Fx.debris(player.getLocation().add(0, 0.2, 0),
                            player.getLocation().subtract(0, 0.5, 0).getBlock(), 6, 0.6);
                }
                Fx.ringDust(center.clone().add(0, 0.12, 0), radius, 44, Palette.STONE);
                Fx.star(center.clone().add(0, 0.12, 0), radius * 0.7, tick * 0.1, 0.6, Palette.EARTH);

                for (int i = 0; i < spots.size(); i++) {
                    Location s = spots.get(i);
                    int erupt = 10 + i * 2;
                    if (tick < erupt) {
                        Fx.ringDust(s.clone().add(0, 0.12, 0), 1.1, 12, Fx.RED);
                    } else if (tick == erupt) {
                        Block src = s.clone().subtract(0, 0.5, 0).getBlock();
                        Palette.spike(s, 3.0, 1.0, Palette.STONE, Palette.EARTH);
                        Fx.debris(s.clone().add(0, 0.5, 0), src, 40, 0.8);
                        world.playSound(s, Sound.BLOCK_STONE_BREAK, 1.5f, 0.5f);
                        for (LivingEntity e : Combat.around(player, s, 2.4)) {
                            if (e.getLocation().distance(s) > 2.2) continue;
                            Combat.damage(player, e, damage);
                            e.setVelocity(new Vector(0, 1.0, 0));
                            Fx.shock(plugin, e, 14, Palette.EARTH, Palette.STONE, Particle.CRIT);
                        }
                    }
                }

                if (tick == finalTick) {
                    Block src = center.clone().subtract(0, 0.5, 0).getBlock();
                    Palette.spike(center, 7.0, 3.0, Palette.STONE, Palette.EARTH);
                    Fx.debris(center.clone().add(0, 1, 0), src, 150, 2.0);
                    world.spawnParticle(Particle.EXPLOSION_EMITTER, center.clone().add(0, 1, 0), 1);
                    world.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.6f, 0.6f);
                    world.playSound(center, Sound.BLOCK_ANVIL_LAND, 1.5f, 0.4f);
                    for (LivingEntity e : Combat.around(player, center, 4.5)) {
                        Combat.damage(player, e, finalDamage);
                        e.setVelocity(new Vector(0, 1.3, 0));
                        Fx.shock(plugin, e, 24, Palette.EARTH, Palette.STONE, Particle.CRIT);
                    }
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
