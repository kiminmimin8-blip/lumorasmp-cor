package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Meteors;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Meteor Shower (versi biasa, tanpa dimensi kekosongan): portal api di langit, lingkaran sihir di tanah,
 * dan puluhan meteor jatuh miring. Skill ini nggak dipakai item bawaan lagi (diganti void_domain),
 * tapi tetap tersedia: pasang dengan "type: meteor_shower" di items.yml.
 */
public final class MeteorShowerSkill implements Skill {

    private static final int FALL_TICKS = 12;
    private static final double MAX_PATH = 26;

    @Override
    public String displayName() {
        return "Meteor Shower";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 12);
        int meteors = Math.max(1, params.getInt("meteors", 20));
        int interval = Math.max(1, params.getInt("interval-ticks", 4));
        double impactRadius = params.getDouble("impact-radius", 3.5);
        double damage = params.getDouble("damage", 6);
        double seekChance = Math.max(0, Math.min(1, params.getDouble("seek-chance", 0.4)));
        int burnTicks = Math.max(0, params.getInt("burn-seconds", 3)) * 20;

        // Nggak ada target di area = skill batal, cooldown nggak kepake
        boolean anyTarget = player.getNearbyEntities(radius, radius, radius).stream()
                .anyMatch(e -> e instanceof LivingEntity le && Meteors.valid(player, le));
        if (!anyTarget) {
            player.sendActionBar(plugin.bar("no-target"));
            return false;
        }

        Location center = player.getLocation().clone();
        World world = center.getWorld();
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        // Semua meteor di satu cast jatuh miring ke arah yang sama (arah acak per cast)
        double windAngle = rnd.nextDouble(0, Math.PI * 2);
        Vector slant = new Vector(Math.cos(windAngle) * 0.55, 1.0, Math.sin(windAngle) * 0.55).normalize();

        world.playSound(center, Sound.ENTITY_WITHER_SPAWN, 0.6f, 1.6f);
        world.playSound(center, Sound.BLOCK_END_PORTAL_SPAWN, 0.5f, 0.8f);
        world.playSound(center, Sound.ENTITY_BLAZE_SHOOT, 1.2f, 0.6f);
        player.swingMainHand();

        int duration = 12 + meteors * interval + FALL_TICKS;
        // Portal api di langit; di goa dipasang tepat di bawah langit-langit
        double skyY = Math.max(3.0, Fx.ceiling(center.clone().add(0, 0.5, 0), 14) - 0.6);

        // Lingkaran sihir api di tanah + portal di langit + animasi di caster + hujan bara
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (tick > duration || !player.isOnline()) {
                    cancel();
                    return;
                }

                double cr = Math.min(radius * 0.6, 7.0) * Math.min(1.0, tick / 10.0);
                double rotation = tick * 0.05;
                Location ground = center.clone().add(0, 0.1, 0);
                Fx.ringDust(ground, cr, 48, Fx.RED);
                Fx.ringDust(ground, cr * 0.6, 30, Fx.ORANGE);
                Fx.star(ground, cr, rotation, 1.2, Fx.ORANGE);

                Location portal = center.clone().add(0, skyY, 0);
                double pr = 4.2 * Math.min(1.0, tick / 8.0);
                Fx.ringDust(portal, pr, 40, Fx.RED);
                Fx.ringDust(portal, pr * 0.62, 28, Fx.ORANGE);
                Fx.star(portal, pr * 0.85, -rotation * 1.5, 1.0, Fx.ORANGE);
                world.spawnParticle(Particle.FLAME, portal, 8, pr * 0.4, 0.2, pr * 0.4, 0.03);

                ThreadLocalRandom r = ThreadLocalRandom.current();
                for (int i = 0; i < 4; i++) {
                    double a = r.nextDouble(0, Math.PI * 2);
                    double d = Math.sqrt(r.nextDouble()) * cr;
                    world.spawnParticle(Particle.FALLING_LAVA,
                            center.getX() + Math.cos(a) * d, center.getY() + skyY * 0.8, center.getZ() + Math.sin(a) * d,
                            1, 0, 0, 0, 0);
                }

                Location me = player.getLocation();
                Fx.bodyHelix(me, tick, 0.85, Fx.RED, Fx.ORANGE);
                if (tick < 10) {
                    Fx.sphere(me.clone().add(0, 1, 0), 3.0 * (1 - tick / 10.0) + 0.4, 10, Particle.FLAME);
                    Fx.pillar(center, skyY, 0.9, Fx.ORANGE);
                } else if (tick % 4 == 0) {
                    world.spawnParticle(Particle.FLAME, me.clone().add(0, 0.1, 0), 4, 0.5, 0.05, 0.5, 0.02);
                }
                tick += 2;
            }
        }.runTaskTimer(plugin, 0L, 2L);

        // Pelepasan meteor
        new BukkitRunnable() {
            int fired = 0;

            @Override
            public void run() {
                if (!player.isOnline() || fired >= meteors) {
                    cancel();
                    return;
                }
                fired++;
                player.swingMainHand();

                ThreadLocalRandom r = ThreadLocalRandom.current();
                Location impact = null;

                // Sebagian meteor ngejar posisi musuh saat ini (musuh masih bisa kabur pas penanda muncul)
                if (r.nextDouble() < seekChance) {
                    List<LivingEntity> pool = new ArrayList<>();
                    for (LivingEntity le : world.getNearbyLivingEntities(center, radius)) {
                        if (Meteors.valid(player, le)) pool.add(le);
                    }
                    if (!pool.isEmpty()) {
                        Location at = pool.get(r.nextInt(pool.size())).getLocation();
                        impact = Fx.groundNear(world, at.getX(), at.getZ(), at.getY());
                    }
                }

                if (impact == null) {
                    double angle = r.nextDouble(0, Math.PI * 2);
                    double dist = Math.sqrt(r.nextDouble()) * radius;
                    impact = Fx.groundNear(world,
                            center.getX() + Math.cos(angle) * dist,
                            center.getZ() + Math.sin(angle) * dist,
                            center.getY());
                }

                Meteors.launch(plugin, player, impact, slant, MAX_PATH, FALL_TICKS, 1.0,
                        impactRadius, damage, burnTicks, fired % 4 == 0);
            }
        }.runTaskTimer(plugin, 10L, interval);

        return true;
    }
}
