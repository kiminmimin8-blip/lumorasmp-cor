package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Reaper's Harvest (ultimate): lingkaran sihir jiwa mekar di kaki caster dan ikut ke mana pun dia
 * bergerak. Dua arit hantu mengorbit, jiwa-jiwa naik dari tanah. Tiap setengah detik musuh di dalam
 * lingkaran dikuras, jiwa mereka melesat ke caster dan menyembuhkannya. Ditutup ledakan sabit
 * melebar yang melempar dan melemahkan semua musuh.
 */
public final class ReapersHarvestSkill implements Skill {

    private static final int OPEN = 12;
    private static final int FINALE = 8;

    @Override
    public String displayName() {
        return "Reaper's Harvest";
    }

    private static double maxHealth(Player p) {
        AttributeInstance a = p.getAttribute(Attribute.MAX_HEALTH);
        return a == null ? 20.0 : a.getValue();
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 9);
        int seconds = params.getInt("seconds", 6);
        double tickDamage = params.getDouble("tick-damage", 4);
        double healPercent = params.getDouble("heal-percent", 0.5);
        double finalDamage = params.getDouble("final-damage", 20);
        int total = seconds * 20;

        World world = player.getWorld();
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, total, 0, false, true, true));
        world.playSound(player.getLocation(), Sound.ENTITY_WITHER_AMBIENT, 1.5f, 0.5f);
        world.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 0.5f);
        player.swingMainHand();

        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                t++;
                if (!player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                Location center = player.getLocation().clone();
                Location g = center.clone().add(0, 0.12, 0);
                double r = radius * Math.min(1.0, t / (double) OPEN);

                // Lingkaran sihir: cincin ganda + dua bintang berlawanan arah
                Fx.ringDust(g, r, 56, Palette.SOUL);
                if (t % 2 == 0) Fx.ringDust(g, r * 0.72, 40, Palette.SOUL_DEEP);
                if (t % 3 == 0) {
                    Fx.star(g, r * 0.7, t * 0.08, 0.5, Palette.SOUL);
                    Fx.star(g, r * 0.5, -t * 0.11, 0.5, Palette.SHADOW);
                }

                // Jiwa naik dari tanah di seluruh lingkaran
                for (int i = 0; i < 5; i++) {
                    double a = rnd.nextDouble(Math.PI * 2);
                    double rr = Math.sqrt(rnd.nextDouble()) * r;
                    world.spawnParticle(Particle.SOUL,
                            center.getX() + Math.cos(a) * rr, center.getY() + 0.2, center.getZ() + Math.sin(a) * rr,
                            0, 0, 1.0, 0, 0.08 + rnd.nextDouble(0.06));
                }
                if (t % 2 == 0) {
                    double a = rnd.nextDouble(Math.PI * 2);
                    double rr = Math.sqrt(rnd.nextDouble()) * r;
                    world.spawnParticle(Particle.SOUL_FIRE_FLAME,
                            center.getX() + Math.cos(a) * rr, center.getY() + 0.1, center.getZ() + Math.sin(a) * rr,
                            2, 0.1, 0.1, 0.1, 0.02);
                }

                // Dua arit hantu mengorbit caster
                for (int blade = 0; blade < 2; blade++) {
                    double base = t * 0.45 + blade * Math.PI;
                    double y = 1.0 + 0.25 * Math.sin(t * 0.2 + blade);
                    for (int i = 0; i < 10; i++) {
                        double a = base - i * 0.08;
                        Fx.trail(center.clone().add(Math.cos(a) * 2.4, y, Math.sin(a) * 2.4), Palette.SOUL_FADE);
                    }
                    Location tip = center.clone().add(Math.cos(base) * 2.4, y, Math.sin(base) * 2.4);
                    world.spawnParticle(Particle.SOUL_FIRE_FLAME, tip, 1, 0.03, 0.03, 0.03, 0.01);
                    Fx.dust(tip, Palette.SOUL);
                }

                if (t % 10 == 0 && t >= OPEN) drain(center);
                if (t % 20 == 0) {
                    world.playSound(center, Sound.ENTITY_WITHER_AMBIENT, 0.5f, 0.5f);
                }
                if (t >= total) {
                    finale(center);
                    cancel();
                }
            }

            private void drain(Location center) {
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                List<LivingEntity> victims = Combat.around(player, center, radius);
                double healed = 0;
                Location chest = player.getLocation().add(0, 1.2, 0);
                for (LivingEntity e : victims) {
                    e.setNoDamageTicks(0);
                    Combat.damage(player, e, tickDamage);
                    healed += tickDamage * healPercent;
                    e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 25, 0, false, false, true));

                    Location c = e.getLocation().add(0, 1, 0);
                    Vector to = chest.toVector().subtract(c.toVector());
                    if (to.lengthSquared() > 0.04) {
                        to.normalize();
                        // Jiwa melesat dari korban ke caster
                        for (int i = 0; i < 8; i++) {
                            world.spawnParticle(Particle.SOUL, c, 0, to.getX(), to.getY() + 0.15, to.getZ(),
                                    0.35 + rnd.nextDouble(0.2));
                        }
                        Fx.line(c, chest, Particle.SOUL_FIRE_FLAME, 0.9, 0.12);
                    }
                    world.spawnParticle(Particle.SOUL_FIRE_FLAME, c, 10, 0.3, 0.5, 0.3, 0.05);
                    Fx.shock(plugin, e, 12, Palette.SOUL, Palette.SHADOW, Particle.SOUL);
                    world.playSound(c, Sound.ENTITY_VEX_CHARGE, 0.7f, 0.6f);
                }
                if (healed > 0) {
                    player.setHealth(Math.min(maxHealth(player), player.getHealth() + healed));
                    world.spawnParticle(Particle.HEART, player.getLocation().add(0, 2.1, 0), 3, 0.3, 0.2, 0.3, 0);
                    Fx.burst(chest, Particle.SOUL, 14, 0.1);
                    Fx.ringDust(player.getLocation().add(0, 0.2, 0), 1.0, 14, Palette.SOUL);
                }
            }

            private void finale(Location center) {
                Location mid = center.clone().add(0, 1, 0);
                world.spawnParticle(Particle.SONIC_BOOM, mid, 1);
                Fx.burst(mid, Particle.SOUL, 120, 0.6);
                Fx.burst(mid, Particle.SOUL_FIRE_FLAME, 80, 0.5);
                world.spawnParticle(Particle.DUST, mid, 80, 1.0, 1.0, 1.0, 0, Palette.SHADOW);
                world.playSound(center, Sound.ENTITY_WITHER_BREAK_BLOCK, 1.2f, 0.6f);
                world.playSound(center, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.8f, 0.7f);
                world.playSound(center, Sound.ENTITY_VEX_CHARGE, 1.2f, 0.5f);

                // Cincin sabit melebar
                new BukkitRunnable() {
                    int w = 0;

                    @Override
                    public void run() {
                        w++;
                        double rr = radius * w / (double) FINALE;
                        Fx.ringDust(center.clone().add(0, 0.2, 0), rr, (int) (rr * 8) + 16, Palette.SOUL);
                        Fx.ringDust(center.clone().add(0, 0.5, 0), rr * 0.85, (int) (rr * 6) + 12, Palette.SHADOW);
                        Fx.ring(center.clone().add(0, 0.8, 0), rr, (int) (rr * 4) + 10, Particle.SOUL);
                        for (int i = 0; i < 8; i++) {
                            double a = i * Math.PI / 4 + w * 0.4;
                            world.spawnParticle(Particle.SWEEP_ATTACK,
                                    center.getX() + Math.cos(a) * rr, center.getY() + 1.0, center.getZ() + Math.sin(a) * rr,
                                    1, 0, 0, 0, 0);
                        }
                        if (w >= FINALE) cancel();
                    }
                }.runTaskTimer(plugin, 0L, 1L);

                for (LivingEntity e : Combat.around(player, center, radius)) {
                    e.setNoDamageTicks(0);
                    Combat.damage(player, e, finalDamage);
                    Combat.push(e, center, 1.3, 0.55);
                    e.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, 0, false, false, true));
                    e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 1, false, false, true));
                    Location c = e.getLocation().add(0, 1, 0);
                    Fx.burst(c, Particle.SOUL, 25, 0.2);
                    Fx.shock(plugin, e, 24, Palette.SOUL, Palette.SHADOW, Particle.SOUL_FIRE_FLAME);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
