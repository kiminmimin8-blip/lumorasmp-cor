package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.domain.DomainManager;
import org.bukkit.GameMode;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Void Cataclysm (ultimate): musuh di sekitar caster diseret ke dimensi kekosongan bareng caster,
 * lalu hujan meteor + meteor penutup raksasa. Caster kebal dari meteor. Semua dibalikin setelahnya.
 * Logika lengkapnya ada di DomainManager.
 */
public final class VoidDomainSkill implements Skill {

    @Override
    public String displayName() {
        return "Void Cataclysm";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        DomainManager domains = plugin.domains();
        if (domains.isBusy()) {
            player.sendActionBar(plugin.bar("domain-busy"));
            return false;
        }

        double radius = params.getDouble("radius", 10);
        int max = Math.max(1, params.getInt("max-targets", 10));
        boolean includeMobs = params.getBoolean("include-mobs", false);

        List<LivingEntity> victims = new ArrayList<>();
        for (Entity e : player.getNearbyEntities(radius, radius, radius)) {
            // hasMetadata("NPC") = NPC Citizens, jangan diseret
            if (!(e instanceof LivingEntity living) || e instanceof ArmorStand || e.hasMetadata("NPC")) continue;
            if (e instanceof Player other) {
                if (other.getGameMode() == GameMode.SPECTATOR) continue;
            } else if (!includeMobs) {
                continue;
            }
            victims.add(living);
        }

        if (victims.isEmpty()) {
            player.sendActionBar(plugin.bar("no-target"));
            return false;
        }

        victims.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(player.getLocation())));
        if (victims.size() > max) {
            victims = new ArrayList<>(victims.subList(0, max));
        }

        if (domains.world() == null) {
            player.sendActionBar(plugin.bar("domain-error"));
            return false;
        }

        domains.start(player, victims, params);
        return true;
    }
}
