package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Static Storm: awan badai berputar di atas caster (dari bawah langit-langit kalau di goa),
 * menyambar musuh di sekitar secara bergantian selama beberapa detik. Caster berselimut listrik statis.
 */
public final class StaticStormSkill implements Skill {

    @Override
    public String displayName() {
        return "Static Storm";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 10);
        double damage = params.getDouble("damage", 7);
        int seconds = params.getInt("seconds", 8);
        int interval = Math.max(4, params.getInt("interval-ticks", 12));

        World world = player.getWorld();
        world.playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 1.2f);
        world.playSound(player.getLocation(), Sound.WEATHER_RAIN_ABOVE, 1.5f, 0.8f);
        player.swingMainHand();

        int total = seconds * 20;
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead() || tick > total) {
                    cancel();
                    return;
                }
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                Location base = player.getLocation();
                double height = Math.min(6.5, Fx.ceiling(base.clone().add(0, 1, 0), 7) - 0.8);
                Location cloud = base.clone().add(0, Math.max(2.5, height), 0);

                // Awan: gumpalan abu berputar + kilat internal
                double grow = Math.min(1.0, tick / 12.0);
                for (int i = 0; i < 10; i++) {
                    double a = tick * 0.15 + i * Math.PI / 5;
                    double rr = (1.5 + (i % 3) * 1.2) * grow;
                    Location p = cloud.clone().add(Math.cos(a) * rr, rnd.nextDouble(-0.3, 0.3), Math.sin(a) * rr);
                    world.spawnParticle(Particle.CLOUD, p, 1, 0.2, 0.1, 0.2, 0.0);
                    Fx.dust(p, Fx.DARK);
                }
                if (tick % 5 == 0) {
                    Location a = cloud.clone().add(rnd.nextDouble(-2, 2), 0, rnd.nextDouble(-2, 2));
                    Location b = cloud.clone().add(rnd.nextDouble(-2, 2), 0, rnd.nextDouble(-2, 2));
                    Fx.bolt(a, b, 4, 0.4, Particle.ELECTRIC_SPARK, Fx.WHITE);
                }
                // Caster: percikan listrik statis + cincin di kaki
                Fx.bodyHelix(base, tick, 0.7, Fx.CYAN, Fx.WHITE);
                world.spawnParticle(Particle.ELECTRIC_SPARK, base.clone().add(0, 1, 0), 3, 0.5, 0.8, 0.5, 0.1);
                if (tick % 20 == 0) {
                    Fx.ringDust(base.clone().add(0, 0.1, 0), radius, 40, Fx.CYAN);
                }

                // Sambaran: ke musuh terdekat/acak; kalau nggak ada, tanah acak sebagai peringatan visual
                if (tick % interval == 0) {
                    List<LivingEntity> victims = Combat.around(player, base, radius);
                    if (victims.isEmpty()) return;
                    LivingEntity e = victims.get(rnd.nextInt(Math.min(3, victims.size())));
                    Location g = Fx.groundNear(world, e.getLocation().getX(), e.getLocation().getZ(),
                            e.getLocation().getY());
                    Fx.bolt(cloud, e.getLocation().add(0, 1, 0), 5, 0.5, Particle.ELECTRIC_SPARK, Fx.CYAN);
                    Fx.skyBolt(g, 14, Fx.CYAN, Fx.WHITE);
                    Fx.ringDust(g.clone().add(0, 0.1, 0), 2.0, 20, Fx.CYAN);
                    world.spawnParticle(Particle.ELECTRIC_SPARK, e.getLocation().add(0, 1, 0), 30, 0.4, 0.7, 0.4, 0.3);
                    world.playSound(g, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.8f, 1.5f);
                    Combat.damage(player, e, damage);
                    Fx.shock(plugin, e, 16, Fx.CYAN, Fx.WHITE, Particle.ELECTRIC_SPARK);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
