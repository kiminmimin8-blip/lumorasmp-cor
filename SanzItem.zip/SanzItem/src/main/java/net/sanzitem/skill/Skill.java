package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public interface Skill {

    /** Nama yang tampil di actionbar. */
    String displayName();

    /**
     * Jalanin skill.
     *
     * @return true kalau skill berhasil kepakai (cooldown baru mulai), false kalau batal
     */
    boolean cast(SanzItem plugin, Player player, ConfigurationSection params);
}
