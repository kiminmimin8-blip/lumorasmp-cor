package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Fx;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Lightning Strike: caster dikelilingi aura listrik sambil energi tersedot ke badan, busur ke target,
 * target di-charge, lalu petir tebal turun (nembus langit-langit goa kalau ada) dan loncat ke
 * musuh lain. Target kena aura kejut.
 */
public final class LightningStrikeSkill implements Skill {

    /** Lama animasi charge sebelum petir nyambar (tick). */
    private static final int CHARGE_TICKS = 14;
    /** Tinggi maksimal petir kalau langit terbuka. */
    private static final double SKY = 24;

    @Override
    public String displayName() {
        return "Lightning Strike";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 10);
        double damage = params.getDouble("damage", 16);
        int chainTargets = params.getInt("chain-targets", 2);
        double chainRange = params.getDouble("chain-range", 7);
        double chainPercent = params.getDouble("chain-percent", 0.7);

        LivingEntity target = null;
        double best = Double.MAX_VALUE;
        for (Entity e : player.getNearbyEntities(radius, radius, radius)) {
            if (!isValid(player, e)) continue;
            double dist = e.getLocation().distanceSquared(player.getLocation());
            if (dist < best) {
                best = dist;
                target = (LivingEntity) e;
            }
        }

        if (target == null) {
            player.sendActionBar(plugin.bar("no-target"));
            return false;
        }

        final LivingEntity victim = target;
        World castWorld = player.getWorld();

        player.swingMainHand();
        castWorld.playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1.0f, 1.8f);
        castWorld.playSound(player.getLocation(), Sound.ITEM_TRIDENT_THUNDER, 0.9f, 1.5f);

        // Busur tebal dari tangan caster ke target
        Fx.thickBolt(player.getLocation().add(0, 1.3, 0), victim.getLocation().add(0, 1, 0),
                8, 0.4, Fx.CYAN, Fx.WHITE);

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead() || victim.isDead() || !victim.isValid()) {
                    cancel();
                    return;
                }

                double p = tick / (double) CHARGE_TICKS;

                // --- Animasi di CASTER: heliks listrik di badan, energi tersedot masuk, cincin melebar
                Location me = player.getLocation();
                Fx.bodyHelix(me, tick, 0.85, Fx.CYAN, Fx.WHITE);
                Fx.sphere(me.clone().add(0, 1, 0), 2.2 * (1 - p) + 0.3, 6, Particle.ELECTRIC_SPARK);
                Fx.ringDust(me.clone().add(0, 0.1, 0), 0.6 + p * 1.8, 20, Fx.CYAN);
                if (tick == CHARGE_TICKS - 2) {
                    player.swingMainHand();
                }

                // --- Animasi di TARGET: spiral menyempit, cincin penanda, garis telegraph dari atas
                Location base = victim.getLocation();
                World world = victim.getWorld();
                for (int i = 0; i < 3; i++) {
                    double angle = tick * 0.7 + i * (2 * Math.PI / 3);
                    double r = 1.8 * (1 - p) + 0.4;
                    Location at = base.clone().add(Math.cos(angle) * r, p * 2.4, Math.sin(angle) * r);
                    Fx.dust(at, Fx.CYAN);
                    world.spawnParticle(Particle.ELECTRIC_SPARK, at, 1, 0, 0, 0, 0);
                }
                Fx.ringDust(base.clone().add(0, 0.1, 0), 2.4 * (1 - p) + 0.5, 18, Fx.CYAN);
                if (tick % 3 == 0) {
                    double up = Fx.ceiling(base.clone().add(0, 0.5, 0), SKY);
                    Fx.lineDust(base.clone().add(0, up, 0), base.clone().add(0, 0.2, 0), 0.7, Fx.WHITE);
                }
                world.playSound(base, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.7f, 0.6f + (float) p);

                if (tick >= CHARGE_TICKS) {
                    cancel();
                    strike(plugin, player, victim, damage, chainTargets, chainRange, chainPercent);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);

        return true;
    }

    private void strike(SanzItem plugin, Player player, LivingEntity victim, double damage,
                        int chainTargets, double chainRange, double chainPercent) {
        Location base = victim.getLocation();
        World world = victim.getWorld();

        // Petir tebal dari langit / langit-langit goa (nembus + puing kalau di goa)
        Fx.skyBolt(base, SKY, Fx.WHITE, Fx.CYAN);
        // Efek petir vanilla (visual doang, nggak bakar & nggak nyambar sembarangan)
        world.strikeLightningEffect(base);

        hit(player, victim, damage);
        victim.setVelocity(victim.getVelocity().setY(0.5));
        Fx.shock(plugin, victim, 30, Fx.CYAN, Fx.WHITE, Particle.ELECTRIC_SPARK);
        impactFx(plugin, base);
        world.playSound(base, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.2f, 1.2f);
        world.playSound(base, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.0f, 1.0f);

        // Afterglow di caster
        if (player.isOnline()) {
            player.swingMainHand();
            Fx.burst(player.getLocation().add(0, 1, 0), Particle.ELECTRIC_SPARK, 40, 0.35);
        }

        // Chain: loncat ke musuh terdekat dari korban pertama, dengan jeda antar loncatan
        List<LivingEntity> chain = new ArrayList<>();
        for (Entity e : victim.getNearbyEntities(chainRange, chainRange, chainRange)) {
            if (e.equals(victim) || !isValid(player, e)) continue;
            chain.add((LivingEntity) e);
        }
        chain.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(base)));

        Location[] previous = {base.clone().add(0, 1, 0)};
        int count = Math.min(chainTargets, chain.size());
        for (int i = 0; i < count; i++) {
            final LivingEntity next = chain.get(i);
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (next.isDead() || !next.isValid()) return;
                Location to = next.getLocation().add(0, 1, 0);
                Fx.thickBolt(previous[0], to, 6, 0.4, Fx.CYAN, Fx.WHITE);
                hit(player, next, damage * chainPercent);
                next.setVelocity(next.getVelocity().setY(0.35));
                Fx.shock(plugin, next, 24, Fx.CYAN, Fx.WHITE, Particle.ELECTRIC_SPARK);
                impactFx(plugin, next.getLocation());
                next.getWorld().playSound(to, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.9f, 1.5f);
                previous[0] = to;
            }, 3L * (i + 1));
        }
    }

    private void impactFx(SanzItem plugin, Location base) {
        World world = base.getWorld();
        if (world == null) return;
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        world.spawnParticle(Particle.EXPLOSION, base.clone().add(0, 0.5, 0), 2, 0.4, 0.2, 0.4, 0);
        Fx.burst(base.clone().add(0, 1, 0), Particle.ELECTRIC_SPARK, 80, 0.5);
        Fx.debris(base.clone().add(0, 0.3, 0), base.clone().subtract(0, 0.5, 0).getBlock(), 40, 0.8);
        // Air mancur bintang ke atas
        for (int i = 0; i < 24; i++) {
            world.spawnParticle(Particle.END_ROD, base, 0,
                    rnd.nextDouble(-0.3, 0.3), 1.0, rnd.nextDouble(-0.3, 0.3), 0.35);
        }

        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                t++;
                Fx.ringDust(base.clone().add(0, 0.15, 0), t * 1.1, 10 + t * 6, Fx.CYAN);
                Fx.ringDust(base.clone().add(0, 0.3, 0), t * 0.8, 10 + t * 4, Fx.WHITE);
                if (t >= 6) cancel();
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void hit(Player player, LivingEntity target, double amount) {
        if (player.isOnline()) {
            target.damage(amount, player);
        } else {
            target.damage(amount);
        }
    }

    private static boolean isValid(Player caster, Entity e) {
        if (!(e instanceof LivingEntity) || e instanceof ArmorStand || e.equals(caster)) return false;
        return !(e instanceof Player other && other.getGameMode() == GameMode.SPECTATOR);
    }
}
