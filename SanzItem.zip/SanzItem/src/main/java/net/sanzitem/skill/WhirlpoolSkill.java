package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Whirlpool: pusaran air raksasa di titik bidikan. Corong air berputar, musuh terseret ke tengah
 * dan kena damage berkala, lalu pusaran meledak jadi geyser yang melempar semua ke udara.
 */
public final class WhirlpoolSkill implements Skill {

    @Override
    public String displayName() {
        return "Whirlpool";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 8);
        int seconds = params.getInt("seconds", 5);
        double tickDamage = params.getDouble("tick-damage", 3);
        double finalDamage = params.getDouble("final-damage", 18);
        double range = params.getDouble("range", 22);
        double pullPower = params.getDouble("pull", 0.3);

        World world = player.getWorld();
        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection();
        RayTraceResult hit = world.rayTraceBlocks(eye, dir, range, FluidCollisionMode.NEVER, true);
        Location aim = (hit == null || hit.getHitPosition() == null)
                ? eye.clone().add(dir.clone().multiply(range))
                : hit.getHitPosition().toLocation(world).subtract(dir.clone().multiply(1.0));
        final Location ground = Fx.groundNear(world, aim.getX(), aim.getZ(), aim.getY());

        world.playSound(ground, Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 1.5f, 0.5f);
        world.playSound(ground, Sound.AMBIENT_UNDERWATER_ENTER, 1.5f, 0.7f);
        player.swingMainHand();

        int total = seconds * 20;
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                if (player.isOnline() && !player.isDead() && tick <= 16) {
                    Fx.bodyHelix(player.getLocation(), tick * 2, 0.8, Palette.WATER, Palette.FOAM);
                    Fx.lineDust(player.getEyeLocation().add(0, -0.4, 0), ground.clone().add(0, 1, 0), 0.8, Palette.WATER);
                }
                double grow = Math.min(1.0, tick / 10.0);
                double height = Math.min(5.0, Fx.ceiling(ground.clone().add(0, 1, 0), 6) - 0.4);

                // Corong: tiap lapisan makin lebar ke atas, berputar
                for (double y = 0.2; y <= height; y += 0.45) {
                    double r = radius * grow * (0.25 + 0.75 * y / height);
                    for (int arm = 0; arm < 3; arm++) {
                        double a = tick * 0.4 - y * 0.8 + arm * Math.PI * 2 / 3;
                        Location p = ground.clone().add(Math.cos(a) * r, y, Math.sin(a) * r);
                        Fx.dust(p, (arm + (int) (y * 2)) % 2 == 0 ? Palette.WATER : Palette.FOAM);
                    }
                }
                world.spawnParticle(Particle.SPLASH, ground.clone().add(0, 0.5, 0), 20, radius * 0.4, 0.3, radius * 0.4, 0.2);
                world.spawnParticle(Particle.BUBBLE_POP, ground.clone().add(0, 0.8, 0), 8, radius * 0.4, 0.4, radius * 0.4, 0.0);
                Fx.ringDust(ground.clone().add(0, 0.12, 0), radius * grow, 40, Palette.WATER_DEEP);
                if (tick % 20 == 0) world.playSound(ground, Sound.ENTITY_DOLPHIN_SWIM, 1.2f, 0.6f);

                for (LivingEntity e : Combat.around(player, ground, radius)) {
                    Combat.pull(e, ground, pullPower, e.isOnGround() ? 0.1 : 0.0);
                    if (tick % 10 == 0) {
                        e.damage(tickDamage, player);
                        e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 25, 1));
                        world.spawnParticle(Particle.SPLASH, e.getLocation().add(0, 1, 0), 20, 0.3, 0.6, 0.3, 0.2);
                    }
                    if (tick % 4 == 0) Fx.bodyHelix(e.getLocation(), tick, 0.6, Palette.WATER, Palette.FOAM);
                }

                if (tick >= total) {
                    geyser();
                    cancel();
                }
            }

            private void geyser() {
                Fx.pillar(ground, 9, 1.4, Palette.WATER);
                Fx.pillar(ground, 9, 0.7, Palette.FOAM);
                for (double y = 0; y <= 9; y += 1.0) {
                    world.spawnParticle(Particle.SPLASH, ground.clone().add(0, y, 0), 25, 0.8, 0.3, 0.8, 0.3);
                }
                world.spawnParticle(Particle.EXPLOSION_EMITTER, ground.clone().add(0, 1, 0), 1);
                Fx.ringDust(ground.clone().add(0, 0.2, 0), radius, 48, Palette.FOAM);
                world.playSound(ground, Sound.ENTITY_GENERIC_SPLASH, 2.0f, 0.5f);
                world.playSound(ground, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.2f);
                for (LivingEntity e : Combat.around(player, ground, radius)) {
                    Combat.damage(player, e, finalDamage);
                    e.setVelocity(new Vector(0, 1.5, 0));
                    Fx.shock(plugin, e, 24, Palette.WATER, Palette.FOAM, Particle.SPLASH);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
