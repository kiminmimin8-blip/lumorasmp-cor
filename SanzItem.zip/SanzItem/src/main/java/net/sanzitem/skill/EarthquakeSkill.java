package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Earthquake (ultimate): tiga hentakan beruntun mengguncang area sekitar caster. Tiap hentakan
 * ngelempar semua musuh ke atas, bikin retakan radial dan hujan puing.
 */
public final class EarthquakeSkill implements Skill {

    @Override
    public String displayName() {
        return "Earthquake";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 12);
        double damage = params.getDouble("damage", 10);
        double finalDamage = params.getDouble("final-damage", 18);

        World world = player.getWorld();
        Location c = player.getLocation().clone();
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 120, 1));
        player.swingMainHand();

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                if (tick > 40) {
                    cancel();
                    return;
                }
                if (tick == 1 || tick == 14 || tick == 27) pulse(tick == 27);

                int phase = (tick - 1) % 13;
                double r = radius * Math.min(1.0, phase / 10.0);
                if (phase <= 10) {
                    int pts = (int) (r * 7) + 12;
                    Fx.ringDust(c.clone().add(0, 0.2, 0), r, pts, Palette.EARTH);
                    Fx.ringDust(c.clone().add(0, 0.35, 0), r * 0.7, pts, Palette.STONE);
                    for (int i = 0; i < 12; i++) {
                        double a = i * Math.PI / 6 + tick * 0.05;
                        Vector d = new Vector(Math.cos(a), 0, Math.sin(a));
                        Fx.lineDust(c.clone().add(d.clone().multiply(Math.max(0, r - 3))).add(0, 0.15, 0),
                                c.clone().add(d.clone().multiply(r)).add(0, 0.15, 0), 0.5, Fx.DARK);
                    }
                    Fx.debris(c.clone().add(0, 0.3, 0), c.clone().subtract(0, 0.5, 0).getBlock(), 10, r * 0.5);
                }
                // Caster: aura tanah
                if (player.isOnline()) Fx.bodyHelix(player.getLocation(), tick, 0.8, Palette.EARTH, Palette.STONE);
            }

            private void pulse(boolean last) {
                double dmg = last ? finalDamage : damage;
                world.playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, last ? 0.5f : 0.8f);
                world.playSound(c, Sound.BLOCK_ANVIL_LAND, 1.2f, 0.4f);
                world.playSound(c, Sound.ENTITY_IRON_GOLEM_DAMAGE, 1.5f, 0.5f);
                world.spawnParticle(Particle.EXPLOSION_EMITTER, c.clone().add(0, 0.5, 0), last ? 2 : 1);
                Fx.debris(c.clone().add(0, 0.5, 0), c.clone().subtract(0, 0.5, 0).getBlock(), last ? 160 : 80, 2.0);
                for (LivingEntity e : Combat.around(player, c, radius)) {
                    Combat.damage(player, e, dmg);
                    e.setVelocity(new Vector(0, last ? 1.2 : 0.8, 0));
                    e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 2));
                    Fx.debris(e.getLocation().add(0, 0.3, 0), e.getLocation().subtract(0, 0.5, 0).getBlock(), 30, 0.6);
                    Fx.shock(plugin, e, 16, Palette.EARTH, Palette.STONE, Particle.CRIT);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
