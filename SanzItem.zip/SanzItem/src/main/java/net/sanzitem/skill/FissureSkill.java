package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Fissure: caster menghentak tanah, retakan merambat lurus ke depan sambil menyemburkan batu.
 * Musuh di sepanjang retakan terlempar ke atas dan kena slow.
 */
public final class FissureSkill implements Skill {

    @Override
    public String displayName() {
        return "Fissure";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double range = params.getDouble("range", 22);
        double damage = params.getDouble("damage", 17);
        double width = params.getDouble("width", 2.4);

        Vector dir = player.getLocation().getDirection().setY(0);
        if (dir.lengthSquared() < 0.01) return false;
        dir.normalize();
        World world = player.getWorld();
        Location origin = player.getLocation().clone();

        world.playSound(origin, Sound.ENTITY_IRON_GOLEM_ATTACK, 1.5f, 0.5f);
        world.playSound(origin, Sound.BLOCK_ANVIL_LAND, 1.2f, 0.5f);
        player.swingMainHand();

        new BukkitRunnable() {
            int tick = 0;
            Location last = origin.clone();
            final Set<LivingEntity> hit = new HashSet<>();

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }
                if (tick <= 5) {
                    Location b = player.getLocation();
                    Fx.ringDust(b.clone().add(0, 0.12, 0), 1.0 + tick * 0.4, 20, Palette.EARTH);
                    Fx.debris(b.clone().add(0, 0.2, 0), b.clone().subtract(0, 0.5, 0).getBlock(), 8, 0.7);
                    return;
                }
                for (int sub = 0; sub < 2; sub++) {
                    int step = (tick - 5) * 2 + sub;
                    double dist = step * 0.7;
                    if (dist > range) {
                        end();
                        cancel();
                        return;
                    }
                    Location flat = origin.clone().add(dir.clone().multiply(dist));
                    if (!flat.clone().add(0, 1, 0).getBlock().isPassable()
                            && !flat.clone().add(0, 2, 0).getBlock().isPassable()) {
                        end();
                        cancel();
                        return;
                    }
                    Location p = Fx.groundNear(world, flat.getX(), flat.getZ(), last.getY());
                    Block src = p.clone().subtract(0, 0.5, 0).getBlock();
                    // Retakan gelap + puing menyembur
                    Fx.lineDust(last.clone().add(0, 0.15, 0), p.clone().add(0, 0.15, 0), 0.35, Fx.DARK);
                    Fx.lineDust(last.clone().add(0.3, 0.15, 0), p.clone().add(0.3, 0.15, 0), 0.5, Palette.EARTH);
                    Fx.debris(p.clone().add(0, 0.8, 0), src, 12, 0.45);
                    if (step % 3 == 0) {
                        Palette.spike(p, 1.8 + ThreadLocalRandom.current().nextDouble(1.2), 0.7, Palette.STONE, Palette.EARTH);
                        world.playSound(p, Sound.BLOCK_STONE_BREAK, 1.2f, 0.5f);
                    }
                    last = p;

                    for (LivingEntity e : Combat.around(player, p, width + 1)) {
                        if (e.getLocation().distance(p) > width || !hit.add(e)) continue;
                        Combat.damage(player, e, damage);
                        e.setVelocity(new Vector(0, 1.0, 0));
                        e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 2));
                        Fx.debris(e.getLocation().add(0, 0.5, 0), src, 40, 0.6);
                        Fx.shock(plugin, e, 20, Palette.EARTH, Palette.STONE, Particle.CRIT);
                    }
                }
            }

            private void end() {
                Fx.debris(last.clone().add(0, 0.5, 0), last.clone().subtract(0, 0.5, 0).getBlock(), 100, 1.4);
                world.spawnParticle(Particle.EXPLOSION, last.clone().add(0, 0.8, 0), 2, 0.6, 0.3, 0.6, 0);
                world.playSound(last, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 0.7f);
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
