package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Tidal Wave: caster nyedot air ke tangan, lalu gelombang air setinggi 2-3 blok menyapu ke depan.
 * Musuh yang kena terseret dan terlempar. Tembus lantai tidak rata (ikut kontur tanah), berhenti di tembok.
 */
public final class TidalWaveSkill implements Skill {

    @Override
    public String displayName() {
        return "Tidal Wave";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double range = params.getDouble("range", 20);
        double width = params.getDouble("width", 9);
        double damage = params.getDouble("damage", 16);
        double push = params.getDouble("push", 1.3);

        Vector dir = player.getLocation().getDirection().setY(0);
        if (dir.lengthSquared() < 0.01) return false;
        dir.normalize();
        Vector right = Palette.right(dir);
        World world = player.getWorld();
        Location origin = player.getLocation().clone();

        world.playSound(origin, Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 1.5f, 0.6f);
        world.playSound(origin, Sound.ENTITY_DOLPHIN_SPLASH, 1.5f, 0.7f);
        player.swingMainHand();

        new BukkitRunnable() {
            int tick = 0;
            final Set<LivingEntity> hit = new HashSet<>();
            final int windup = 6;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }
                if (tick <= windup) {
                    Location b = player.getLocation();
                    Fx.bodyHelix(b, tick * 2, 0.9, Palette.WATER, Palette.FOAM);
                    world.spawnParticle(Particle.SPLASH, b.clone().add(0, 1, 0), 25, 0.6, 0.8, 0.6, 0.2);
                    Fx.ringDust(b.clone().add(0, 0.1, 0), 2.2 - tick * 0.3, 22, Palette.WATER_DEEP);
                    return;
                }
                int step = tick - windup;
                double dist = step * 1.2;
                if (dist > range) {
                    cancel();
                    return;
                }
                Location front = origin.clone().add(dir.clone().multiply(dist));
                if (!front.clone().add(0, 1, 0).getBlock().isPassable()) {
                    Fx.burst(front.clone().add(0, 1, 0), Particle.SPLASH, 80, 0.5);
                    world.spawnParticle(Particle.BLOCK, front.clone().add(0, 1, 0), 30, 0.6, 0.6, 0.6, 0.1,
                            Material.WATER.createBlockData());
                    world.playSound(front, Sound.ENTITY_GENERIC_SPLASH, 1.5f, 0.6f);
                    cancel();
                    return;
                }

                // Muka gelombang: lengkung (tengah paling tinggi) mengikuti lantai
                for (double s = -width / 2; s <= width / 2; s += 0.5) {
                    double h = 2.6 * (1 - Math.abs(s) / (width / 2) * 0.45);
                    Location col = front.clone().add(right.clone().multiply(s));
                    Location g = Fx.groundNear(world, col.getX(), col.getZ(), origin.getY());
                    for (double y = 0.2; y <= h; y += 0.45) {
                        Fx.dust(g.clone().add(0, y, 0), y > h - 0.5 ? Palette.FOAM : Palette.WATER);
                    }
                    world.spawnParticle(Particle.SPLASH, g.clone().add(0, h, 0), 2, 0.2, 0.1, 0.2, 0.1);
                    // Buih di belakang muka gelombang
                    Fx.dust(g.clone().subtract(dir.clone().multiply(0.9)).add(0, 0.4, 0), Palette.WATER_DEEP);
                }
                if (step % 3 == 0) world.playSound(front, Sound.ENTITY_PLAYER_SWIM, 1.0f, 0.7f);

                for (LivingEntity e : Combat.around(player, front, width / 2 + 1.5)) {
                    Vector rel = e.getLocation().toVector().subtract(front.toVector());
                    if (Math.abs(rel.dot(right)) > width / 2 + 0.5 || Math.abs(rel.dot(dir)) > 1.8) continue;
                    if (!hit.add(e)) continue;
                    Combat.damage(player, e, damage);
                    e.setVelocity(dir.clone().multiply(push).setY(0.55));
                    e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 50, 1));
                    world.spawnParticle(Particle.SPLASH, e.getLocation().add(0, 1, 0), 50, 0.4, 0.8, 0.4, 0.3);
                    Fx.shock(plugin, e, 24, Palette.WATER, Palette.FOAM, Particle.BUBBLE_POP);
                    world.playSound(e.getLocation(), Sound.ENTITY_GENERIC_SPLASH, 1.2f, 0.8f);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
