package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Fx;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.List;

/**
 * Starlight Mend: cahaya bintang turun dari atas, pilar cahaya + cincin sihir mekar di bawah kaki,
 * menyembuhkan caster dan pemain di sekitar (heal + absorption + regen). Kalau semua sudah full, batal.
 */
public final class StarlightMendSkill implements Skill {

    @Override
    public String displayName() {
        return "Starlight Mend";
    }

    private static double maxHealth(Player p) {
        AttributeInstance a = p.getAttribute(Attribute.MAX_HEALTH);
        return a == null ? 20.0 : a.getValue();
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 8);
        double heal = params.getDouble("heal", 12);
        int absorbLevel = Math.max(1, params.getInt("absorption-level", 2));
        int regenSeconds = params.getInt("regen-seconds", 6);
        boolean others = params.getBoolean("include-others", true);

        List<Player> targets = new ArrayList<>();
        targets.add(player);
        if (others) {
            for (Player p : player.getWorld().getPlayers()) {
                if (p.equals(player) || p.isDead() || p.getGameMode() == org.bukkit.GameMode.SPECTATOR) continue;
                if (p.getLocation().distanceSquared(player.getLocation()) <= radius * radius) targets.add(p);
            }
        }
        boolean needed = false;
        for (Player p : targets) {
            if (p.getHealth() < maxHealth(p) - 0.1) needed = true;
        }
        if (!needed) {
            player.sendActionBar(plugin.bar("full-health"));
            return false;
        }

        World world = player.getWorld();
        Location center = player.getLocation().clone();
        world.playSound(center, Sound.BLOCK_BEACON_POWER_SELECT, 1.4f, 1.6f);
        world.playSound(center, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.5f, 1.0f);
        player.swingMainHand();

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline()) {
                    cancel();
                    return;
                }
                Location base = player.getLocation();
                double up = Fx.ceiling(base.clone().add(0, 1, 0), 10);

                // Bintang-bintang turun dari atas (dari bawah langit-langit kalau di goa)
                for (int i = 0; i < 4; i++) {
                    double a = tick * 0.5 + i * Math.PI / 2;
                    double y = up - ((tick * 0.7 + i * 2.5) % up);
                    world.spawnParticle(Particle.END_ROD, base.clone().add(Math.cos(a) * 1.4, y, Math.sin(a) * 1.4),
                            2, 0.05, 0.05, 0.05, 0.0);
                    Fx.dust(base.clone().add(Math.cos(a) * 1.4, y, Math.sin(a) * 1.4), Fx.GOLD);
                }
                // Cincin sihir mekar membesar
                double r = Math.min(radius, tick * radius / 14.0);
                Fx.ringDust(base.clone().add(0, 0.12, 0), r, (int) (r * 7) + 10, Fx.GOLD);
                Fx.star(base.clone().add(0, 0.12, 0), r * 0.8, tick * 0.15, 0.55, Fx.WHITE);
                Fx.pillar(base, Math.min(5, up), 0.9, Fx.GOLD);
                world.spawnParticle(Particle.HAPPY_VILLAGER, base.clone().add(0, 1, 0), 3, 0.7, 0.8, 0.7, 0);

                if (tick == 10) applyHeal();
                if (tick >= 24) cancel();
            }

            private void applyHeal() {
                for (Player p : targets) {
                    if (!p.isOnline() || p.isDead()) continue;
                    p.setHealth(Math.min(maxHealth(p), p.getHealth() + heal));
                    p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 20 * 10, absorbLevel - 1));
                    p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, regenSeconds * 20, 1));
                    Location l = p.getLocation();
                    world.spawnParticle(Particle.HEART, l.clone().add(0, 2, 0), 8, 0.5, 0.3, 0.5, 0);
                    world.spawnParticle(Particle.TOTEM_OF_UNDYING, l.clone().add(0, 1, 0), 30, 0.4, 0.7, 0.4, 0.4);
                    Fx.shock(plugin, p, 30, Fx.GOLD, Fx.WHITE, Particle.END_ROD);
                    world.playSound(l, Sound.ENTITY_PLAYER_LEVELUP, 0.9f, 1.4f);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
