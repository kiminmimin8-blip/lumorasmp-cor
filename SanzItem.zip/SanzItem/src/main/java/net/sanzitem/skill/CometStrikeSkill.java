package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Meteors;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/**
 * Comet Strike: satu meteor raksasa ke titik yang dibidik. Caster angkat tongkat (aura api),
 * lingkaran sihir merah terbentuk di sasaran, lalu komet menghantam dengan ledakan besar.
 */
public final class CometStrikeSkill implements Skill {

    private static final int WARN_TICKS = 24;

    @Override
    public String displayName() {
        return "Comet Strike";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double range = params.getDouble("range", 30);
        double impactRadius = params.getDouble("impact-radius", 7);
        double damage = params.getDouble("damage", 26);
        int burnTicks = params.getInt("burn-seconds", 5) * 20;
        double scale = params.getDouble("scale", 3.0);

        World world = player.getWorld();
        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection();
        RayTraceResult hit = world.rayTraceBlocks(eye, dir, range, FluidCollisionMode.NEVER, true);
        Location aim = (hit == null || hit.getHitPosition() == null)
                ? eye.clone().add(dir.clone().multiply(range))
                : hit.getHitPosition().toLocation(world);
        final Location impact = Fx.groundNear(world, aim.getX(), aim.getZ(), aim.getY());

        world.playSound(player.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1.5f, 0.5f);
        world.playSound(impact, Sound.ENTITY_WARDEN_HEARTBEAT, 1.5f, 0.6f);
        player.swingMainHand();

        double windAngle = Math.atan2(impact.getZ() - player.getLocation().getZ(),
                impact.getX() - player.getLocation().getX()) + Math.PI;
        Vector slant = new Vector(Math.cos(windAngle) * 0.5, 1.0, Math.sin(windAngle) * 0.5).normalize();

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                if (player.isOnline() && !player.isDead()) {
                    Location base = player.getLocation();
                    Fx.bodyHelix(base, tick * 1.5, 0.8, Fx.ORANGE, Fx.RED);
                    world.spawnParticle(Particle.FLAME, base.clone().add(0, 2.2, 0), 4, 0.2, 0.1, 0.2, 0.02);
                    if (tick % 6 == 0) player.swingMainHand();
                }

                // Lingkaran sihir di sasaran: hexagram + cincin mengunci, makin padat mendekati hantaman
                double p = tick / (double) WARN_TICKS;
                Fx.star(impact.clone().add(0, 0.12, 0), impactRadius * 0.9, tick * 0.2, 0.55, Fx.RED);
                Fx.ringDust(impact.clone().add(0, 0.12, 0), impactRadius, 48, Fx.ORANGE);
                Fx.ringDust(impact.clone().add(0, 0.12, 0), impactRadius * (1 - p), 36, Fx.RED);
                Fx.pillar(impact, 8 * p, 0.8, Fx.ORANGE);
                world.spawnParticle(Particle.FLAME, impact.clone().add(0, 0.2, 0), 4, impactRadius * 0.4, 0.1,
                        impactRadius * 0.4, 0.02);
                if (tick % 6 == 0) world.playSound(impact, Sound.BLOCK_NOTE_BLOCK_BASS, 1.5f, 0.5f + (float) p);

                if (tick >= WARN_TICKS) {
                    cancel();
                    world.playSound(impact, Sound.ENTITY_ENDER_DRAGON_GROWL, 1.2f, 0.5f);
                    Meteors.launch(plugin, player, impact, slant, 40, 26, scale, impactRadius, damage, burnTicks, true);
                    // Korban yang masih di lingkaran tersulut aura api sebelum hantaman
                    for (LivingEntity e : Combat.around(player, impact, impactRadius)) {
                        Fx.shock(plugin, e, 26, Fx.RED, Fx.ORANGE, Particle.FLAME);
                    }
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
