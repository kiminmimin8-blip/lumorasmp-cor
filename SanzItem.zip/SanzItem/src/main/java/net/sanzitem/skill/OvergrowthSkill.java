package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Overgrowth (ultimate): akar dan sulur meledak dari tanah, melilit semua musuh di sekitar caster
 * (nggak bisa gerak), menguras darah mereka tiap detik. Caster menyerap sebagian jadi penyembuhan,
 * lalu sulur mekar jadi ledakan bunga + damage penutup.
 */
public final class OvergrowthSkill implements Skill {

    @Override
    public String displayName() {
        return "Overgrowth";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 10);
        int seconds = params.getInt("seconds", 4);
        double tickDamage = params.getDouble("tick-damage", 4);
        double healPerHit = params.getDouble("heal-per-hit", 1.5);
        double finalDamage = params.getDouble("final-damage", 16);
        int maxTargets = Math.max(1, params.getInt("max-targets", 8));

        List<LivingEntity> victims = Combat.around(player, player.getLocation(), radius);
        if (victims.isEmpty()) {
            player.sendActionBar(plugin.bar("no-target"));
            return false;
        }
        if (victims.size() > maxTargets) victims = new ArrayList<>(victims.subList(0, maxTargets));
        final List<LivingEntity> targets = victims;

        World world = player.getWorld();
        final Location c = player.getLocation().clone();
        world.playSound(c, Sound.BLOCK_BIG_DRIPLEAF_TILT_DOWN, 1.5f, 0.5f);
        world.playSound(c, Sound.BLOCK_AZALEA_LEAVES_BREAK, 1.5f, 0.6f);
        player.swingMainHand();

        int total = seconds * 20;
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                // Caster: hexagram daun + helix
                if (player.isOnline() && !player.isDead()) {
                    Location pl = player.getLocation();
                    Fx.bodyHelix(pl, tick, 0.8, Palette.LEAF, Palette.LEAF_DARK);
                    if (tick % 3 == 0) Fx.star(pl.clone().add(0, 0.12, 0), 3.0, tick * 0.1, 0.5, Palette.LEAF);
                }
                // Akar merambat dari caster ke tiap korban (terbentuk 8 tick pertama)
                for (LivingEntity e : targets) {
                    if (!e.isValid() || e.isDead()) continue;
                    Location el = e.getLocation();
                    double p = Math.min(1.0, tick / 8.0);
                    Location start = c.clone().add(0, 0.2, 0);
                    Location end = start.clone().add(el.clone().add(0, 0.2, 0).subtract(start).toVector().multiply(p));
                    Fx.lineDust(start, end, 0.45, Palette.LEAF_DARK);
                    if (tick % 2 == 0) Fx.dust(end.clone().add(0, 0.3, 0), Palette.VENOM);

                    if (tick >= 8) {
                        // Sulur melilit tubuh korban naik-turun
                        for (int i = 0; i < 2; i++) {
                            double a = tick * 0.5 + i * Math.PI;
                            for (double y = 0; y <= 2.0; y += 0.3) {
                                double aa = a + y * 3;
                                Fx.dust(el.clone().add(Math.cos(aa) * 0.55, y, Math.sin(aa) * 0.55),
                                        i == 0 ? Palette.LEAF : Palette.LEAF_DARK);
                            }
                        }
                        e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 6, 6, false, false, false));
                        if (tick % 20 == 0) {
                            e.damage(tickDamage, player);
                            healCaster(healPerHit);
                            world.spawnParticle(Particle.COMPOSTER, el.clone().add(0, 1, 0), 15, 0.3, 0.6, 0.3, 0.1);
                            Fx.line(el.clone().add(0, 1, 0), player.getEyeLocation(), Particle.HAPPY_VILLAGER, 0.6, 0.1);
                        }
                    }
                }
                if (tick % 20 == 0) world.playSound(c, Sound.BLOCK_AZALEA_LEAVES_BREAK, 1.2f, 0.7f);

                if (tick >= total) {
                    bloom();
                    cancel();
                }
            }

            private void healCaster(double amount) {
                if (!player.isOnline() || player.isDead()) return;
                var attr = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH);
                double max = attr == null ? 20.0 : attr.getValue();
                player.setHealth(Math.min(max, player.getHealth() + amount));
                world.spawnParticle(Particle.HEART, player.getLocation().add(0, 2, 0), 2, 0.3, 0.2, 0.3, 0);
            }

            private void bloom() {
                world.playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.4f);
                world.playSound(c, Sound.BLOCK_FLOWERING_AZALEA_BREAK, 1.5f, 0.8f);
                for (LivingEntity e : targets) {
                    if (!e.isValid() || e.isDead()) continue;
                    Location l = e.getLocation();
                    e.damage(finalDamage, player);
                    e.setVelocity(new Vector(0, 0.8, 0));
                    world.spawnParticle(Particle.HAPPY_VILLAGER, l.clone().add(0, 1, 0), 60, 0.5, 0.9, 0.5, 0.3);
                    world.spawnParticle(Particle.COMPOSTER, l.clone().add(0, 1, 0), 40, 0.5, 0.9, 0.5, 0.3);
                    Fx.pillar(l, 3, 0.8, Palette.LEAF);
                    Fx.shock(plugin, e, 20, Palette.LEAF, Palette.VENOM, Particle.SPORE_BLOSSOM_AIR);
                }
                Fx.ringDust(c.clone().add(0, 0.2, 0), radius, 56, Palette.LEAF);
                Fx.burst(c.clone().add(0, 1, 0), Particle.HAPPY_VILLAGER, 80, 0.8);
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
