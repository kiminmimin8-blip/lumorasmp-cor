package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Fx;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Berserker Roar: caster mengamuk (aura api heliks, api tersedot masuk, tanah retak, tangan ayun),
 * lalu ledakan raungan + pilar api + gelombang kejut dengan retakan radial. Selama Strength aktif,
 * caster tetap berselimut aura merah. Korban kena aura api.
 */
public final class BerserkerRoarSkill implements Skill {

    private static final int WINDUP_TICKS = 8;
    private static final int WAVE_TICKS = 12;

    @Override
    public String displayName() {
        return "Berserker Roar";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 7);
        double damage = params.getDouble("damage", 8);
        double knockback = params.getDouble("knockback", 1.6);
        int level = Math.max(1, params.getInt("strength-level", 2));
        int ticks = params.getInt("strength-seconds", 8) * 20;

        World world = player.getWorld();
        world.playSound(player.getLocation(), Sound.ENTITY_WARDEN_HEARTBEAT, 1.5f, 0.7f);
        player.swingMainHand();

        new BukkitRunnable() {
            int tick = 0;
            Location center;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }

                // Fase 1: wind-up di caster
                if (tick <= WINDUP_TICKS) {
                    Location base = player.getLocation();
                    double p = tick / (double) WINDUP_TICKS;
                    if (tick == 5) player.swingMainHand();

                    Fx.bodyHelix(base, tick * 1.5, 0.9, Fx.RED, Fx.ORANGE);
                    world.spawnParticle(Particle.FLAME, base.clone().add(0, 0.1, 0), 8, 0.6, 0.1, 0.6, 0.04);
                    Fx.ringDust(base.clone().add(0, 0.15, 0), radius * (1 - p) + 1.0, 32, Fx.RED);
                    Fx.sphere(base.clone().add(0, 1, 0), 2.6 * (1 - p) + 0.4, 8, Particle.FLAME);

                    // Retakan tanah memanjang keluar dari kaki caster
                    for (int i = 0; i < 6; i++) {
                        double a = i * Math.PI / 3 + 0.3;
                        Vector dir = new Vector(Math.cos(a), 0, Math.sin(a));
                        Fx.lineDust(base.clone().add(0, 0.1, 0),
                                base.clone().add(dir.multiply(radius * p * 0.8)).add(0, 0.1, 0), 0.5, Fx.DARK);
                    }
                    Fx.debris(base.clone().add(0, 0.2, 0), base.clone().subtract(0, 0.5, 0).getBlock(), 4, 0.6);

                    if (tick == WINDUP_TICKS) {
                        center = base.clone();
                        blast(plugin, player, center, radius, damage, knockback, level, ticks);
                    }
                    return;
                }

                // Fase 2: dua gelombang kejut melebar + 8 retakan radial
                int w = tick - WINDUP_TICKS;
                double r = radius * w / WAVE_TICKS;
                int points = (int) (r * 8) + 12;
                Fx.ringDust(center.clone().add(0, 0.2, 0), r, points, Fx.RED);
                Fx.ringDust(center.clone().add(0, 0.35, 0), r * 0.7, points, Fx.ORANGE);
                Fx.ring(center.clone().add(0, 0.5, 0), r * 0.9, points, Particle.CLOUD);
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4 + 0.2;
                    Vector dir = new Vector(Math.cos(a), 0, Math.sin(a));
                    Location from = center.clone().add(dir.clone().multiply(Math.max(0, r - 2))).add(0, 0.2, 0);
                    Location to = center.clone().add(dir.clone().multiply(r)).add(0, 0.2, 0);
                    Fx.line(from, to, Particle.CRIT, 0.5, 0.05);
                    Fx.lineDust(from, to, 0.5, Fx.DARK);
                }
                Fx.debris(center.clone().add(0, 0.3, 0), center.clone().subtract(0, 0.5, 0).getBlock(), 6, r * 0.5);

                if (w >= WAVE_TICKS) {
                    world.spawnParticle(Particle.SONIC_BOOM, center.clone().add(0, 1, 0), 1);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);

        return true;
    }

    private void blast(SanzItem plugin, Player player, Location origin, double radius, double damage,
                       double knockback, int level, int ticks) {
        World world = origin.getWorld();
        if (world == null) return;

        for (Entity e : player.getNearbyEntities(radius, radius / 2, radius)) {
            if (!(e instanceof LivingEntity living) || e instanceof ArmorStand) continue;
            if (e instanceof Player other && other.getGameMode() == GameMode.SPECTATOR) continue;

            Vector push = e.getLocation().toVector().subtract(origin.toVector());
            push.setY(0);
            if (push.lengthSquared() < 0.01) {
                push = new Vector(0, 0, 1);
            }
            push.normalize().multiply(knockback).setY(0.5);
            living.setVelocity(push);
            living.damage(damage, player);

            // Korban: ledakan crit + aura api
            world.spawnParticle(Particle.CRIT, living.getLocation().add(0, 1, 0), 25, 0.3, 0.5, 0.3, 0.4);
            Fx.shock(plugin, living, 24, Fx.RED, Fx.ORANGE, Particle.FLAME);
        }

        player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, ticks, level - 1));

        // Ledakan raungan: ledakan besar, pilar api di caster, puing, tiga lapis suara
        world.spawnParticle(Particle.EXPLOSION_EMITTER, origin.clone().add(0, 1, 0), 1);
        world.spawnParticle(Particle.FLAME, origin.clone().add(0, 0.3, 0), 80, 0.3, 0.2, 0.3, 0.3);
        for (double y = 0; y <= 4.5; y += 0.5) {
            Fx.ring(origin.clone().add(0, y, 0), 1.2 - y * 0.12, 14, Particle.FLAME);
        }
        Fx.debris(origin.clone().add(0, 0.4, 0), origin.clone().subtract(0, 0.5, 0).getBlock(), 80, 1.5);
        world.playSound(origin, Sound.ENTITY_RAVAGER_ROAR, 1.4f, 0.7f);
        world.playSound(origin, Sound.ENTITY_ENDER_DRAGON_GROWL, 0.8f, 0.6f);
        world.playSound(origin, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 0.7f);

        // Selama Strength aktif, caster tetap berselimut aura merah-api
        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead() || t > ticks) {
                    cancel();
                    return;
                }
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                Location base = player.getLocation();
                for (int i = 0; i < 5; i++) {
                    Fx.dust(base.clone().add(rnd.nextDouble(-0.5, 0.5), rnd.nextDouble(0, 2), rnd.nextDouble(-0.5, 0.5)),
                            Fx.RED);
                }
                base.getWorld().spawnParticle(Particle.FLAME, base.clone().add(0, 0.1, 0), 2, 0.4, 0.05, 0.4, 0.02);
                if (t % 20 == 0) {
                    Fx.ringDust(base.clone().add(0, 0.1, 0), 1.2, 16, Fx.ORANGE);
                }
                t += 2;
            }
        }.runTaskTimer(plugin, 2L, 2L);
    }
}
