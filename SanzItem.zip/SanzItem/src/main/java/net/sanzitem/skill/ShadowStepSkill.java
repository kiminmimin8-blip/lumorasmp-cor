package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Shadow Step: caster lenyap jadi kabut bayangan, muncul tepat di belakang musuh terdekat, lalu
 * menghujani musuh dengan tebasan beruntun dari berbagai sudut dan menutup dengan tebasan silang X.
 */
public final class ShadowStepSkill implements Skill {

    @Override
    public String displayName() {
        return "Shadow Step";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double range = params.getDouble("range", 14);
        double slashDamage = params.getDouble("damage", 8);
        double finisherDamage = params.getDouble("finisher-damage", 18);
        int slashes = Math.max(1, params.getInt("slashes", 4));
        int speedLevel = Math.max(1, params.getInt("speed-level", 2));
        int speedTicks = params.getInt("speed-seconds", 4) * 20;

        LivingEntity target = Combat.nearest(player, player.getLocation(), range);
        if (target == null) {
            player.sendActionBar(plugin.bar("no-target"));
            return false;
        }

        World world = player.getWorld();
        Location origin = player.getLocation().clone();
        Location spot = findSpot(world, target);

        // Menghilang: kabut bayangan + jiwa
        vanish(world, origin);
        if (spot != null) {
            Fx.lineDust(origin.clone().add(0, 1, 0), spot.clone().add(0, 1, 0), 0.35, Palette.SHADOW);
            Fx.line(origin.clone().add(0, 1, 0), spot.clone().add(0, 1, 0), Particle.SOUL, 0.7, 0.2);
            Fx.line(origin.clone().add(0, 1.4, 0), spot.clone().add(0, 1.4, 0), Particle.SOUL_FIRE_FLAME, 0.9, 0.1);

            Location dest = spot.clone();
            dest.setDirection(target.getLocation().add(0, 1, 0).toVector()
                    .subtract(spot.clone().add(0, 1.6, 0).toVector()));
            Combat.guardFall(player, 40);
            player.teleport(dest);
            vanish(world, dest);
        }
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, speedTicks, speedLevel - 1));

        new BukkitRunnable() {
            int tick = 0;
            int done = 0;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead() || !target.isValid() || target.isDead()) {
                    cancel();
                    return;
                }
                // Selalu menghadap musuh
                Location pl = player.getLocation();
                pl.setDirection(target.getLocation().add(0, 1, 0).toVector()
                        .subtract(pl.clone().add(0, 1.6, 0).toVector()));
                player.setRotation(pl.getYaw(), pl.getPitch());

                if (tick % 3 == 0 && done < slashes) {
                    done++;
                    slash(done);
                }
                if (done >= slashes && tick == slashes * 3 + 4) {
                    finisher();
                    cancel();
                }
            }

            private void slash(int i) {
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                Location c = target.getLocation().add(0, target.getHeight() * 0.55, 0);
                Vector toTarget = c.toVector().subtract(player.getEyeLocation().toVector());
                if (toTarget.lengthSquared() < 0.01) toTarget = new Vector(0, 0, 1);
                toTarget.normalize();
                Vector rt = Palette.right(toTarget);
                Vector upv = rt.clone().crossProduct(toTarget).normalize();
                double tilt = rnd.nextDouble(-0.9, 0.9);
                double sign = (i % 2 == 0) ? 1 : -1;
                Vector axis = rt.clone().multiply(Math.cos(tilt)).add(upv.clone().multiply(Math.sin(tilt)));

                // Garis tebasan melengkung
                for (int k = 0; k <= 14; k++) {
                    double s = -1.8 + k * 3.6 / 14.0;
                    Location p = c.clone().add(axis.clone().multiply(s * sign))
                            .add(toTarget.clone().multiply(-0.6 * (1 - (s * s) / 3.24)));
                    Fx.dust(p, k % 2 == 0 ? Palette.SOUL : Fx.WHITE);
                    if (k % 3 == 0) world.spawnParticle(Particle.SOUL_FIRE_FLAME, p, 1, 0.02, 0.02, 0.02, 0.01);
                }
                world.spawnParticle(Particle.SWEEP_ATTACK, c, 1, 0.2, 0.2, 0.2, 0);
                world.spawnParticle(Particle.CRIT, c, 12, 0.3, 0.4, 0.3, 0.5);
                world.spawnParticle(Particle.SOUL, c, 4, 0.3, 0.4, 0.3, 0.05);
                player.swingMainHand();

                target.setNoDamageTicks(0);
                Combat.damage(player, target, slashDamage);
                world.playSound(c, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.2f, 1.0f + i * 0.1f);
                world.playSound(c, Sound.ENTITY_PLAYER_ATTACK_CRIT, 0.8f, 0.8f + i * 0.1f);
            }

            private void finisher() {
                Location c = target.getLocation().add(0, target.getHeight() * 0.55, 0);
                Vector toTarget = c.toVector().subtract(player.getEyeLocation().toVector());
                if (toTarget.lengthSquared() < 0.01) toTarget = new Vector(0, 0, 1);
                toTarget.normalize();
                Vector rt = Palette.right(toTarget);
                Vector upv = rt.clone().crossProduct(toTarget).normalize();

                // Tebasan silang X besar
                for (int dd = -1; dd <= 1; dd += 2) {
                    Vector axis = rt.clone().add(upv.clone().multiply(dd)).normalize();
                    for (int k = 0; k <= 24; k++) {
                        double s = -2.6 + k * 5.2 / 24.0;
                        Location p = c.clone().add(axis.clone().multiply(s));
                        Fx.dust(p, Palette.SOUL);
                        Fx.dust(p.clone().add(0, 0.12, 0), Palette.SHADOW);
                        if (k % 4 == 0) world.spawnParticle(Particle.END_ROD, p, 1, 0, 0, 0, 0);
                    }
                }
                world.spawnParticle(Particle.SONIC_BOOM, c, 1);
                world.spawnParticle(Particle.SWEEP_ATTACK, c, 4, 0.5, 0.5, 0.5, 0);
                Fx.burst(c, Particle.SOUL, 60, 0.4);
                Fx.burst(c, Particle.SOUL_FIRE_FLAME, 40, 0.35);
                world.spawnParticle(Particle.DUST, c, 40, 0.6, 0.8, 0.6, 0, Palette.SHADOW);
                world.playSound(c, Sound.ENTITY_WITHER_BREAK_BLOCK, 0.8f, 1.4f);
                world.playSound(c, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.2f, 0.6f);
                world.playSound(c, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.6f, 1.6f);

                target.setNoDamageTicks(0);
                Combat.damage(player, target, finisherDamage);
                Combat.push(target, player.getLocation(), 1.0, 0.5);
                Fx.shock(plugin, target, 26, Palette.SOUL, Palette.SHADOW, Particle.SOUL_FIRE_FLAME);
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }

    /** Titik aman di belakang musuh (atau samping/depan kalau terhalang). Null kalau semuanya buntu. */
    private static Location findSpot(World world, LivingEntity target) {
        Vector facing = target.getLocation().getDirection().setY(0);
        if (facing.lengthSquared() < 0.01) facing = new Vector(0, 0, 1);
        facing.normalize();
        double[] angles = {0, 90, -90, 180};
        for (double deg : angles) {
            Vector v = facing.clone().rotateAroundY(Math.toRadians(deg)).multiply(-1.6);
            Location c = target.getLocation().add(v);
            c = Fx.groundNear(world, c.getX(), c.getZ(), target.getLocation().getY());
            if (c.getBlock().isPassable() && c.clone().add(0, 1, 0).getBlock().isPassable()) {
                return c;
            }
        }
        return null;
    }

    private static void vanish(World world, Location at) {
        Location c = at.clone().add(0, 1, 0);
        Fx.burst(c, Particle.SMOKE, 30, 0.08);
        Fx.burst(c, Particle.SOUL, 25, 0.12);
        world.spawnParticle(Particle.DUST, c, 40, 0.4, 0.8, 0.4, 0, Palette.SHADOW);
        Fx.bodyHelix(at, 4, 0.7, Palette.SOUL, Palette.SHADOW);
        Fx.ringDust(at.clone().add(0, 0.1, 0), 1.2, 16, Palette.SOUL_DEEP);
        world.playSound(at, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 0.6f);
        world.playSound(at, Sound.ENTITY_VEX_CHARGE, 0.8f, 0.7f);
    }
}
