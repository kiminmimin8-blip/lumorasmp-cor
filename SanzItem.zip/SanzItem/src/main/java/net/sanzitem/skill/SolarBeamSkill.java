package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Solar Beam: bola matahari mini terbentuk di depan caster (sinar berputar, energi tertarik masuk),
 * lalu ditembakkan jadi sinar emas tebal berpilin yang menembus semua musuh di jalurnya.
 * Ujung sinar meledak jadi suar cahaya.
 */
public final class SolarBeamSkill implements Skill {

    private static final int CHARGE = 14;
    private static final int BEAM = 10;

    @Override
    public String displayName() {
        return "Solar Beam";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double range = params.getDouble("range", 26);
        double damage = params.getDouble("damage", 22);
        double width = params.getDouble("width", 1.6);
        int burnTicks = params.getInt("burn-seconds", 5) * 20;

        World world = player.getWorld();
        world.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.4f, 1.6f);
        world.playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0f, 0.5f);
        player.swingMainHand();

        new BukkitRunnable() {
            int tick = 0;
            Location from;
            Location to;
            Vector n;
            Vector right;
            Vector up;
            double segLen;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }
                ThreadLocalRandom rnd = ThreadLocalRandom.current();

                // ---------------- charge: bola matahari + sinar berputar
                if (tick <= CHARGE) {
                    double p = tick / (double) CHARGE;
                    Location eye = player.getEyeLocation();
                    Vector d = eye.getDirection().normalize();
                    Location orb = eye.clone().add(d.clone().multiply(1.9)).add(0, -0.2, 0);
                    double r = 0.25 + 0.55 * p;

                    Fx.sphere(orb, r, 18, Particle.FLAME);
                    Fx.sphere(orb, r * 0.6, 10, Particle.END_ROD);
                    world.spawnParticle(Particle.DUST, orb, 4, r * 0.3, r * 0.3, r * 0.3, 0, Palette.SUN_CORE);

                    Vector rt = Palette.right(d);
                    Vector upv = rt.clone().crossProduct(d).normalize();
                    for (int k = 0; k < 8; k++) {
                        double a = tick * 0.35 + k * Math.PI / 4;
                        Vector ray = rt.clone().multiply(Math.cos(a)).add(upv.clone().multiply(Math.sin(a)));
                        double l = (0.8 + 1.4 * p) * (k % 2 == 0 ? 1.0 : 0.65);
                        Fx.lineDust(orb.clone().add(ray.clone().multiply(r)),
                                orb.clone().add(ray.clone().multiply(r + l)), 0.25,
                                k % 2 == 0 ? Palette.SUN : Palette.SUN_ORANGE);
                    }
                    // Energi tertarik masuk dari titik acak
                    for (int i = 0; i < 2; i++) {
                        Vector v = new Vector(rnd.nextGaussian(), rnd.nextGaussian(), rnd.nextGaussian());
                        if (v.lengthSquared() < 0.01) continue;
                        Location src = orb.clone().add(v.normalize().multiply(3.5));
                        Fx.line(src, orb, Particle.END_ROD, 0.5, 0.05);
                    }
                    Fx.bodyHelix(player.getLocation(), tick, 0.8, Palette.SUN, Palette.SUN_CORE);
                    if (tick % 4 == 0) {
                        world.playSound(orb, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1.0f, 0.8f + (float) p);
                    }
                    if (tick == CHARGE) fire();
                    return;
                }

                // ---------------- tembak: sinar berpilin memudar
                int f = tick - CHARGE;
                double fade = 1.0 - (f - 1) / (double) BEAM;
                double rad = 0.15 + 0.5 * fade;
                for (double t = 0, idx = 0; t <= segLen; t += 0.45, idx++) {
                    Location p = from.clone().add(n.clone().multiply(t));
                    Fx.dust(p, Palette.SUN_CORE);
                    double a = t * 1.3 + f * 0.9;
                    Vector o1 = right.clone().multiply(Math.cos(a) * rad).add(up.clone().multiply(Math.sin(a) * rad));
                    Vector o2 = right.clone().multiply(Math.cos(a + Math.PI) * rad)
                            .add(up.clone().multiply(Math.sin(a + Math.PI) * rad));
                    Fx.dust(p.clone().add(o1), Palette.SUN);
                    Fx.dust(p.clone().add(o2), Palette.SUN_ORANGE);
                    if (((int) idx) % 5 == 0) {
                        world.spawnParticle(Particle.FLAME, p, 1, rad, rad, rad, 0.02);
                        world.spawnParticle(Particle.END_ROD, p, 1, rad * 0.5, rad * 0.5, rad * 0.5, 0.03);
                    }
                }
                // Suar di mulut sinar dan di ujung
                world.spawnParticle(Particle.END_ROD, from, 4, 0.2, 0.2, 0.2, 0.08);
                world.spawnParticle(Particle.END_ROD, to, 4, 0.4, 0.4, 0.4, 0.15);
                if (f >= BEAM) cancel();
            }

            private void fire() {
                Location eye = player.getEyeLocation();
                Vector dir = eye.getDirection().normalize();
                RayTraceResult hit = world.rayTraceBlocks(eye, dir, range, FluidCollisionMode.NEVER, true);
                double len = (hit == null || hit.getHitPosition() == null)
                        ? range : Math.max(2.0, hit.getHitPosition().distance(eye.toVector()));
                boolean hitBlock = hit != null && hit.getHitPosition() != null;

                from = eye.clone().add(dir.clone().multiply(1.2)).add(0, -0.25, 0);
                to = eye.clone().add(dir.clone().multiply(len));
                Vector seg = to.toVector().subtract(from.toVector());
                segLen = seg.length();
                if (segLen < 0.5) {
                    n = dir.clone();
                    segLen = 0.5;
                } else {
                    n = seg.clone().normalize();
                }
                right = Palette.right(n);
                up = right.clone().crossProduct(n).normalize();

                world.playSound(from, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.2f, 1.4f);
                world.playSound(from, Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 1.4f, 0.8f);
                world.playSound(to, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.3f);

                // Damage semua musuh di sepanjang sinar
                Location mid = from.clone().add(n.clone().multiply(segLen / 2));
                for (LivingEntity e : Combat.around(player, mid, segLen / 2 + width + 2)) {
                    Vector rel = e.getLocation().add(0, e.getHeight() / 2, 0).toVector().subtract(from.toVector());
                    double along = rel.dot(n);
                    if (along < -1 || along > segLen + 1) continue;
                    double perp = rel.clone().subtract(n.clone().multiply(along)).length();
                    if (perp > width + e.getWidth() / 2) continue;

                    Combat.damage(player, e, damage);
                    e.setFireTicks(burnTicks);
                    Location c = e.getLocation().add(0, 1, 0);
                    world.spawnParticle(Particle.FLAME, c, 40, 0.4, 0.7, 0.4, 0.12);
                    world.spawnParticle(Particle.END_ROD, c, 25, 0.4, 0.7, 0.4, 0.2);
                    Fx.ringDust(e.getLocation().add(0, 0.1, 0), 1.2, 16, Palette.SUN);
                    Fx.shock(plugin, e, 24, Palette.SUN, Palette.SUN_CORE, Particle.FLAME);
                    world.playSound(c, Sound.ENTITY_BLAZE_SHOOT, 1.0f, 1.4f);
                }

                // Suar di ujung: ledakan cahaya + gelombang cincin
                world.spawnParticle(Particle.EXPLOSION_EMITTER, to, 1);
                Fx.burst(to, Particle.FLAME, 80, 0.4);
                Fx.burst(to, Particle.END_ROD, 60, 0.6);
                world.spawnParticle(Particle.LAVA, to, 10, 0.6, 0.3, 0.6, 0);
                if (hitBlock) {
                    Fx.debris(to, to.clone().add(n.clone().multiply(0.6)).getBlock(), 50, 0.8);
                }
                // Mulut sinar
                Fx.burst(from, Particle.END_ROD, 30, 0.35);
                Fx.ringDust(from, 1.0, 16, Palette.SUN_CORE);
                final Location flare = to.clone();
                new BukkitRunnable() {
                    int t = 0;

                    @Override
                    public void run() {
                        t++;
                        Fx.sphere(flare, t * 0.9, 24, Particle.END_ROD);
                        Fx.ringDust(flare, t * 1.0, 24, Palette.SUN);
                        Fx.ringDust(flare, t * 0.7, 18, Palette.SUN_ORANGE);
                        if (t >= 4) cancel();
                    }
                }.runTaskTimer(plugin, 0L, 1L);
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
