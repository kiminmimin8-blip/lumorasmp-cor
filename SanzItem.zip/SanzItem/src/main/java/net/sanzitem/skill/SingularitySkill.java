package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Singularity: lubang hitam muncul di titik yang dibidik. Inti gelap, cakram akresi berputar,
 * partikel portal tersedot, musuh ditarik dan kena damage berkala, lalu runtuh jadi ledakan.
 */
public final class SingularitySkill implements Skill {

    @Override
    public String displayName() {
        return "Singularity";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 9);
        int seconds = params.getInt("seconds", 5);
        double tickDamage = params.getDouble("tick-damage", 3);
        double finalDamage = params.getDouble("final-damage", 18);
        double range = params.getDouble("range", 22);
        double pullPower = params.getDouble("pull", 0.35);

        World world = player.getWorld();
        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection();
        RayTraceResult hit = world.rayTraceBlocks(eye, dir, range, FluidCollisionMode.NEVER, true);
        Location target;
        if (hit == null || hit.getHitPosition() == null) {
            target = eye.clone().add(dir.clone().multiply(range));
        } else {
            target = hit.getHitPosition().toLocation(world).subtract(dir.clone().multiply(1.2));
        }
        Location ground = Fx.groundNear(world, target.getX(), target.getZ(), target.getY());
        Location center = ground.clone().add(0, 2.2, 0);
        // Pastikan pusat nggak di dalam batu (goa rendah)
        if (!center.getBlock().isPassable()) center = ground.clone().add(0, 1.0, 0);
        final Location core = center;

        world.playSound(core, Sound.BLOCK_END_PORTAL_SPAWN, 1.2f, 1.6f);
        world.playSound(core, Sound.ENTITY_WARDEN_SONIC_CHARGE, 1.5f, 0.6f);
        player.swingMainHand();

        int total = seconds * 20;
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                double grow = Math.min(1.0, tick / 10.0);

                // Animasi caster: tangan terulur, aura ungu
                if (player.isOnline() && !player.isDead() && tick <= 20) {
                    Fx.bodyHelix(player.getLocation(), tick, 0.7, Fx.PURPLE, Fx.VOID);
                    if (tick % 5 == 0) player.swingMainHand();
                }

                // Inti gelap + halo
                Fx.sphere(core, 0.9 * grow, 16, Particle.SQUID_INK);
                for (int i = 0; i < 12; i++) Fx.dust(core.clone().add(rnd.nextGaussian() * 0.35,
                        rnd.nextGaussian() * 0.35, rnd.nextGaussian() * 0.35), Fx.VOID);
                Fx.sphere(core, 1.3 * grow, 10, Particle.REVERSE_PORTAL);

                // Cakram akresi: dua cincin miring berputar berlawanan arah
                for (int ring = 0; ring < 2; ring++) {
                    double rr = (ring == 0 ? 2.4 : 3.6) * grow;
                    double tilt = ring == 0 ? 0.35 : -0.5;
                    for (int i = 0; i < 28; i++) {
                        double a = tick * (ring == 0 ? 0.35 : -0.25) + i * Math.PI * 2 / 28;
                        double x = Math.cos(a) * rr;
                        double z = Math.sin(a) * rr;
                        Location p = core.clone().add(x, z * tilt, z);
                        Fx.dust(p, i % 2 == 0 ? Fx.PURPLE : Fx.VOID);
                    }
                }
                // Partikel tersedot dari jauh
                for (int i = 0; i < 8; i++) {
                    double a = rnd.nextDouble(Math.PI * 2);
                    double d = rnd.nextDouble(radius * 0.5, radius);
                    Location from = core.clone().add(Math.cos(a) * d, rnd.nextDouble(-1.5, 1.5), Math.sin(a) * d);
                    Vector toward = core.toVector().subtract(from.toVector()).multiply(0.1);
                    world.spawnParticle(Particle.PORTAL, from, 0, toward.getX() * 4, toward.getY() * 4,
                            toward.getZ() * 4, 1.0);
                }
                Fx.ringDust(ground.clone().add(0, 0.12, 0), radius, 40, Fx.PURPLE);
                if (tick % 20 == 0) world.playSound(core, Sound.ENTITY_ENDERMAN_STARE, 0.6f, 0.5f);

                // Tarik semua musuh, damage tiap 10 tick
                for (LivingEntity e : Combat.around(player, core, radius)) {
                    Combat.pull(e, core, pullPower, e.isOnGround() ? 0.12 : 0.0);
                    if (tick % 10 == 0) {
                        e.damage(tickDamage, player);
                        world.spawnParticle(Particle.WITCH, e.getLocation().add(0, 1, 0), 12, 0.3, 0.6, 0.3, 0.1);
                        Fx.line(e.getLocation().add(0, 1, 0), core, Particle.PORTAL, 0.4, 0.1);
                    }
                    if (tick % 4 == 0) {
                        Fx.bodyHelix(e.getLocation(), tick, 0.6, Fx.PURPLE, Fx.VOID);
                    }
                }

                if (tick >= total) {
                    collapse();
                    cancel();
                }
            }

            private void collapse() {
                world.spawnParticle(Particle.EXPLOSION_EMITTER, core, 2, 0.5, 0.5, 0.5, 0);
                Fx.burst(core, Particle.REVERSE_PORTAL, 200, 1.2);
                Fx.burst(core, Particle.END_ROD, 80, 0.8);
                Fx.sphere(core, 4, 80, Particle.PORTAL);
                Fx.ringDust(core, 5, 40, Fx.PURPLE);
                Fx.ringDust(core, radius * 0.7, 56, Fx.VOID);
                world.playSound(core, Sound.ENTITY_GENERIC_EXPLODE, 1.6f, 0.5f);
                world.playSound(core, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.2f, 0.7f);
                world.playSound(core, Sound.ENTITY_ENDER_DRAGON_GROWL, 0.8f, 0.5f);
                for (LivingEntity e : Combat.around(player, core, radius)) {
                    Combat.damage(player, e, finalDamage);
                    Combat.push(e, core, 1.7, 0.6);
                    Fx.shock(plugin, e, 28, Fx.PURPLE, Fx.VOID, Particle.WITCH);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
