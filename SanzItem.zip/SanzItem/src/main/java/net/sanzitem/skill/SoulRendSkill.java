package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Soul Rend: dua tebasan arit jiwa berturut-turut yang membentuk huruf X. Pertama gelombang sabit
 * mendatar, lima tick kemudian sabit tegak. Keduanya melesat ke depan berekor jiwa yang memudar,
 * menembus semua musuh, dan pecah jadi wisp jiwa di ujungnya.
 */
public final class SoulRendSkill implements Skill {

    @Override
    public String displayName() {
        return "Soul Rend";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double range = params.getDouble("range", 18);
        double damage = params.getDouble("damage", 17);
        double width = params.getDouble("width", 3.0);

        Vector dir = player.getLocation().getDirection().setY(0);
        if (dir.lengthSquared() < 0.01) return false;
        dir.normalize();
        final Vector forward = dir;

        Location origin = player.getLocation().add(0, 1.0, 0).add(forward.clone().multiply(1.2));
        World world = player.getWorld();
        world.playSound(origin, Sound.ENTITY_WITHER_AMBIENT, 0.8f, 1.6f);
        player.swingMainHand();

        wave(plugin, player, origin, forward, range, damage * 0.6, width, false);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline() || player.isDead()) return;
            player.swingMainHand();
            wave(plugin, player, origin, forward, range, damage * 0.6, width, true);
        }, 5L);
        return true;
    }

    private static void wave(SanzItem plugin, Player player, Location origin, Vector dir,
                             double range, double damage, double width, boolean vertical) {
        World world = origin.getWorld();
        if (world == null) return;
        Vector right = Palette.right(dir);
        Vector axis = vertical ? new Vector(0, 1, 0) : right;
        double reach = vertical ? 2.4 : 3.0;
        double lift = vertical ? 0.6 : 0.0;

        world.playSound(origin, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.4f, vertical ? 0.7f : 0.5f);
        world.playSound(origin, Sound.ENTITY_WITHER_SHOOT, 0.5f, 1.8f);

        new BukkitRunnable() {
            double dist = 0;
            int tick = 0;
            final Set<UUID> hit = new HashSet<>();

            @Override
            public void run() {
                tick++;
                dist += 1.5;
                if (!player.isOnline()) {
                    cancel();
                    return;
                }
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                Location pos = origin.clone().add(dir.clone().multiply(dist));

                if (!pos.getBlock().isPassable()) {
                    dissolve(pos.clone().subtract(dir.clone().multiply(1.5)));
                    cancel();
                    return;
                }

                // Sabit: 3 lapis busur melengkung ke depan, ekor jiwa memudar
                for (int layer = 0; layer < 3; layer++) {
                    double rr = reach * (1 - layer * 0.18);
                    double ly = vertical ? lift : lift + (layer - 1) * 0.45;
                    for (int i = 0; i <= 16; i++) {
                        double a = Math.toRadians(-75 + i * (150 / 16.0));
                        Location p = pos.clone()
                                .add(axis.clone().multiply(Math.sin(a) * rr))
                                .add(dir.clone().multiply((Math.cos(a) - 1) * rr * 0.8))
                                .add(0, ly, 0);
                        Fx.trail(p, Palette.SOUL_FADE);
                        if (layer == 0 && i % 4 == 0) {
                            world.spawnParticle(Particle.SOUL_FIRE_FLAME, p, 1, 0.05, 0.05, 0.05, 0.01);
                        }
                        // Mata sabit: ujung-ujung tajam putih
                        if (layer == 0 && (i == 0 || i == 16)) {
                            Fx.dust(p, Palette.SOUL);
                            world.spawnParticle(Particle.END_ROD, p, 1, 0, 0, 0, 0);
                        }
                    }
                }
                if (tick % 2 == 0) {
                    world.spawnParticle(Particle.SOUL, pos.clone().add(0, lift, 0), 3, 1.2, 0.8, 1.2, 0.03);
                    world.spawnParticle(Particle.DUST, pos.clone().add(0, lift, 0), 4, 1.0, 0.6, 1.0, 0, Palette.SHADOW);
                }

                // Kena musuh
                for (LivingEntity e : Combat.around(player, pos, Math.max(width, 3.0) + 1.5)) {
                    if (hit.contains(e.getUniqueId())) continue;
                    Vector rel = e.getLocation().add(0, 1, 0).toVector().subtract(pos.toVector());
                    double fwd = rel.dot(dir);
                    double lat = Math.abs(rel.dot(right));
                    double vert = Math.abs(rel.getY());
                    boolean inside = Math.abs(fwd) <= 1.8
                            && (vertical ? (lat <= width * 0.45 && vert <= 2.6) : (lat <= width && vert <= 2.0));
                    if (!inside) continue;
                    hit.add(e.getUniqueId());

                    e.setNoDamageTicks(0);
                    Combat.damage(player, e, damage);
                    e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 1, false, false, true));
                    Location c = e.getLocation().add(0, 1, 0);
                    world.spawnParticle(Particle.SWEEP_ATTACK, c, 2, 0.3, 0.3, 0.3, 0);
                    world.spawnParticle(Particle.SOUL, c, 16, 0.3, 0.6, 0.3, 0.08);
                    world.spawnParticle(Particle.SOUL_FIRE_FLAME, c, 20, 0.3, 0.6, 0.3, 0.1);
                    world.spawnParticle(Particle.CRIT, c, 14, 0.3, 0.5, 0.3, 0.4);
                    Fx.shock(plugin, e, 24, Palette.SOUL, Palette.SOUL_DEEP, Particle.SOUL_FIRE_FLAME);
                    world.playSound(c, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 0.7f);
                    world.playSound(c, Sound.ENTITY_VEX_CHARGE, 1.0f, 0.6f);
                }

                if (dist >= range) {
                    dissolve(pos);
                    cancel();
                }
            }

            /** Gelombang pecah jadi wisp jiwa. */
            private void dissolve(Location at) {
                Location c = at.clone().add(0, 0.8, 0);
                Fx.burst(c, Particle.SOUL, 40, 0.15);
                Fx.burst(c, Particle.SOUL_FIRE_FLAME, 25, 0.2);
                world.spawnParticle(Particle.DUST, c, 30, 1.2, 0.8, 1.2, 0, Palette.SHADOW);
                Fx.ringDust(at.clone().add(0, 0.2, 0), 1.6, 20, Palette.SOUL);
                world.playSound(c, Sound.ENTITY_VEX_CHARGE, 0.8f, 1.5f);
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }
}
