package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Blizzard: badai salju mekar di tempat caster berdiri. Puting beliung es berputar naik, salju turun
 * deras, duri es tumbuh di tepi area. Selama badai, musuh di dalamnya melambat, membeku, dan
 * kena damage tiap setengah detik.
 */
public final class BlizzardSkill implements Skill {

    @Override
    public String displayName() {
        return "Blizzard";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 8);
        int seconds = params.getInt("seconds", 6);
        double tickDamage = params.getDouble("tick-damage", 3);
        int slowLevel = Math.max(1, params.getInt("slow-level", 3));

        World world = player.getWorld();
        Location center = player.getLocation().clone();
        double top = Math.min(7.0, Fx.ceiling(center.clone().add(0, 0.5, 0), 7.0));
        int total = seconds * 20;

        world.playSound(center, Sound.ENTITY_BREEZE_WIND_BURST, 1.6f, 0.5f);
        world.playSound(center, Sound.ENTITY_PLAYER_HURT_FREEZE, 1.5f, 0.5f);
        world.playSound(center, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.9f);
        player.swingMainHand();

        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                t++;
                if (!player.isOnline()) {
                    cancel();
                    return;
                }
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                double grow = Math.min(1.0, t / 10.0);
                double rr = radius * grow;

                // Puting beliung: 3 lengan berpilin, melebar ke atas seperti corong
                for (int arm = 0; arm < 3; arm++) {
                    for (int i = 0; i < 12; i++) {
                        double h = i * top / 12.0;
                        double ang = t * 0.30 + arm * (2 * Math.PI / 3) + h * 0.9;
                        double r = 0.8 + rr * 0.5 * (h / top);
                        Location p = center.clone().add(Math.cos(ang) * r, 0.2 + h, Math.sin(ang) * r);
                        Fx.dust(p, (i % 2 == 0) ? Palette.FROST_WHITE : Palette.ICE);
                        if (i % 4 == 0) {
                            world.spawnParticle(Particle.SNOWFLAKE, p, 1, 0.1, 0.1, 0.1, 0.02);
                        }
                    }
                }

                // Salju turun deras di seluruh area
                for (int i = 0; i < 10; i++) {
                    double a = rnd.nextDouble(Math.PI * 2);
                    double r = Math.sqrt(rnd.nextDouble()) * rr;
                    world.spawnParticle(Particle.SNOWFLAKE,
                            center.getX() + Math.cos(a) * r,
                            center.getY() + rnd.nextDouble(0.3, top),
                            center.getZ() + Math.sin(a) * r,
                            1, 0, 0, 0, 0.03);
                }
                if (t % 3 == 0) {
                    double a = rnd.nextDouble(Math.PI * 2);
                    double r = Math.sqrt(rnd.nextDouble()) * rr;
                    world.spawnParticle(Particle.CLOUD,
                            center.getX() + Math.cos(a) * r, center.getY() + 0.3, center.getZ() + Math.sin(a) * r,
                            2, 0.4, 0.1, 0.4, 0.02);
                }

                // Batas area + duri es tumbuh di tepi
                if (t % 2 == 0) {
                    Fx.ringDust(center.clone().add(0, 0.15, 0), rr, 40, Palette.ICE);
                }
                if (t % 8 == 0 && t > 6) {
                    for (int i = 0; i < 2; i++) {
                        double a = rnd.nextDouble(Math.PI * 2);
                        Location g = Fx.groundNear(world, center.getX() + Math.cos(a) * rr * 0.95,
                                center.getZ() + Math.sin(a) * rr * 0.95, center.getY());
                        Palette.spike(g, 1.2 + rnd.nextDouble(1.0), 0.4, Palette.ICE, Palette.ICE_DEEP);
                    }
                }

                // Denyut badai: damage + lambat + beku
                if (t % 10 == 0) {
                    for (LivingEntity e : Combat.around(player, center, radius)) {
                        Combat.damage(player, e, tickDamage);
                        e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 30, slowLevel - 1, false, false, true));
                        e.setFreezeTicks(Math.min(e.getMaxFreezeTicks() + 40, e.getFreezeTicks() + 60));
                        Location c = e.getLocation().add(0, 1, 0);
                        world.spawnParticle(Particle.SNOWFLAKE, c, 14, 0.35, 0.7, 0.35, 0.1);
                        world.spawnParticle(Particle.END_ROD, c, 4, 0.3, 0.6, 0.3, 0.05);
                        Fx.shock(plugin, e, 12, Palette.ICE, Palette.FROST_WHITE, Particle.SNOWFLAKE);
                    }
                }
                if (t % 20 == 0) {
                    world.playSound(center, Sound.ENTITY_BREEZE_WIND_BURST, 0.7f, 0.5f);
                    world.playSound(center, Sound.BLOCK_SNOW_BREAK, 1.2f, 0.6f);
                }

                if (t >= total) {
                    Fx.burst(center.clone().add(0, 1, 0), Particle.CLOUD, 60, 0.4);
                    Fx.burst(center.clone().add(0, 1, 0), Particle.SNOWFLAKE, 80, 0.5);
                    Fx.ringDust(center.clone().add(0, 0.2, 0), radius, 50, Palette.FROST_WHITE);
                    world.playSound(center, Sound.BLOCK_GLASS_BREAK, 1.0f, 0.8f);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
