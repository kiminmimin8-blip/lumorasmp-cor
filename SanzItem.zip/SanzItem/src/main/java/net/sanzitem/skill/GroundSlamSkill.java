package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Ground Slam: caster loncat tinggi dengan pilar angin, bayangan sasaran membesar di tanah,
 * menghujam berekor komet api, lalu kawah meledak: cincin kejut berlapis, retakan radial, pilar debu.
 */
public final class GroundSlamSkill implements Skill {

    /** Player yang lagi di tengah slam (buat batalin fall damage). */
    private static final Set<UUID> SLAMMING = new HashSet<>();

    public static boolean isSlamming(UUID id) {
        return SLAMMING.contains(id);
    }

    @Override
    public String displayName() {
        return "Ground Slam";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        UUID id = player.getUniqueId();
        if (SLAMMING.contains(id)) return false;

        double radius = params.getDouble("radius", 8);
        double damage = params.getDouble("damage", 20);
        double launch = params.getDouble("launch", 1.15);

        // Di goa sempit: lompatan dipendekin biar nggak mentok langit-langit
        double room = Fx.ceiling(player.getLocation().add(0, 1.8, 0), 8);
        if (room < 4) launch *= 0.45;

        World world = player.getWorld();
        SLAMMING.add(id);
        player.setVelocity(new Vector(0, launch, 0));
        player.swingMainHand();
        world.playSound(player.getLocation(), Sound.ENTITY_WIND_CHARGE_WIND_BURST, 1.4f, 0.7f);
        world.playSound(player.getLocation(), Sound.ENTITY_IRON_GOLEM_ATTACK, 1.0f, 0.6f);
        Location takeoff = player.getLocation();
        Fx.ringDust(takeoff.clone().add(0, 0.15, 0), 1.8, 24, Fx.GOLD);
        world.spawnParticle(Particle.CLOUD, takeoff, 40, 0.8, 0.1, 0.8, 0.15);
        Fx.debris(takeoff.clone().add(0, 0.2, 0), takeoff.clone().subtract(0, 0.5, 0).getBlock(), 30, 0.9);

        final double fLaunch = launch;
        new BukkitRunnable() {
            int tick = 0;
            boolean diving = false;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead() || tick > 100) {
                    release(plugin, id);
                    cancel();
                    return;
                }
                Location loc = player.getLocation();
                Location ground = Fx.groundNear(world, loc.getX(), loc.getZ(), loc.getY());

                if (!diving) {
                    // Naik: pilin angin di sekeliling caster
                    Fx.bodyHelix(loc, tick * 2, 0.8, Fx.GOLD, Fx.WHITE);
                    world.spawnParticle(Particle.CLOUD, loc, 4, 0.3, 0.1, 0.3, 0.02);
                    if (tick >= (fLaunch < 0.7 ? 6 : 10)) {
                        diving = true;
                        player.setVelocity(new Vector(0, -1.9, 0));
                        world.playSound(loc, Sound.ENTITY_PHANTOM_SWOOP, 1.2f, 0.6f);
                    }
                    return;
                }

                // Bayangan sasaran di tanah: cincin mengecil mendekati lantai
                double h = Math.max(0, loc.getY() - ground.getY());
                double r = radius * Math.max(0.35, 1.0 - h / 14.0);
                Fx.ringDust(ground.clone().add(0, 0.12, 0), r, 36, Fx.RED);
                Fx.ringDust(ground.clone().add(0, 0.12, 0), radius, 40, Fx.ORANGE);
                Fx.star(ground.clone().add(0, 0.12, 0), r * 0.7, tick * 0.2, 0.6, Fx.GOLD);

                // Komet: bola api + ekor gradasi di belakang caster
                Fx.sphere(loc.clone().add(0, 1, 0), 0.9, 14, Particle.FLAME);
                world.spawnParticle(Particle.LARGE_SMOKE, loc.clone().add(0, 1.5, 0), 3, 0.3, 0.3, 0.3, 0.02);
                for (int i = 1; i <= 8; i++) {
                    Fx.trail(loc.clone().add(0, 1 + i * 0.6, 0), Fx.GOLD_TO_RED);
                }

                Location below = loc.clone().subtract(0, 0.25, 0);
                if (player.isOnGround() || !below.getBlock().isPassable()) {
                    impact(plugin, player, loc, radius, damage);
                    release(plugin, id);
                    cancel();
                } else {
                    player.setVelocity(new Vector(0, -1.9, 0));
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }

    /** Flag dilepas agak telat biar fall damage pas mendarat tetap ke-cancel. */
    private void release(SanzItem plugin, UUID id) {
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> SLAMMING.remove(id), 5L);
    }

    private void impact(SanzItem plugin, Player player, Location at, double radius, double damage) {
        World world = at.getWorld();
        if (world == null) return;
        Location c = at.clone();
        Block ground = c.clone().subtract(0, 0.5, 0).getBlock();

        world.spawnParticle(Particle.EXPLOSION_EMITTER, c.clone().add(0, 0.5, 0), 2, 0.6, 0.1, 0.6, 0);
        Fx.burst(c.clone().add(0, 0.5, 0), Particle.FLAME, 100, 0.4);
        Fx.debris(c.clone().add(0, 0.3, 0), ground, 160, 2.2);
        Fx.pillar(c, 6, 1.0, Fx.GOLD);
        world.playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 1.6f, 0.6f);
        world.playSound(c, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.2f, 0.8f);
        world.playSound(c, Sound.BLOCK_ANVIL_LAND, 1.0f, 0.5f);

        // Gelombang kejut 3 lapis + retakan radial, melebar selama 10 tick
        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                t++;
                double r = radius * t / 10.0;
                int pts = (int) (r * 8) + 12;
                Fx.ringDust(c.clone().add(0, 0.2, 0), r, pts, Fx.ORANGE);
                Fx.ringDust(c.clone().add(0, 0.3, 0), r * 0.75, pts, Fx.GOLD);
                Fx.ring(c.clone().add(0, 0.4, 0), r * 0.9, pts, Particle.CLOUD);
                for (int i = 0; i < 10; i++) {
                    double a = i * Math.PI / 5 + 0.15;
                    Vector d = new Vector(Math.cos(a), 0, Math.sin(a));
                    Fx.lineDust(c.clone().add(d.clone().multiply(Math.max(0, r - 2.5))).add(0, 0.15, 0),
                            c.clone().add(d.clone().multiply(r)).add(0, 0.15, 0), 0.5, Fx.DARK);
                }
                Fx.debris(c.clone().add(0, 0.3, 0), ground, 8, r * 0.5);
                if (t >= 10) cancel();
            }
        }.runTaskTimer(plugin, 1L, 1L);

        for (LivingEntity e : Combat.around(player, c, radius)) {
            Combat.damage(player, e, damage);
            e.setVelocity(new Vector(0, 0.85, 0));
            world.spawnParticle(Particle.CRIT, e.getLocation().add(0, 1, 0), 30, 0.4, 0.6, 0.4, 0.5);
            Fx.shock(plugin, e, 24, Fx.GOLD, Fx.ORANGE, Particle.FLAME);
        }
    }
}
