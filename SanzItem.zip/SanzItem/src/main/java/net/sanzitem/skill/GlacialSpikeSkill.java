package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Glacial Spike: tanah di depan caster pecah, duri-duri es raksasa menyembul beruntun lurus ke depan
 * (satu besar + dua pengawal di kiri-kanan). Musuh kena terpental ke udara, beku, dan melambat.
 * Ujung jalur ditutup satu kristal raksasa yang pecah berhamburan.
 */
public final class GlacialSpikeSkill implements Skill {

    private static final double STEP = 1.8;

    @Override
    public String displayName() {
        return "Glacial Spike";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double range = params.getDouble("range", 16);
        double damage = params.getDouble("damage", 15);
        double width = params.getDouble("width", 2.0);
        int slowTicks = params.getInt("slow-seconds", 4) * 20;

        Vector dir = player.getLocation().getDirection().setY(0);
        if (dir.lengthSquared() < 0.01) return false;
        dir.normalize();
        final Vector forward = dir;
        final Vector right = Palette.right(dir);
        final Location start = player.getLocation().clone();
        final World world = player.getWorld();

        world.playSound(start, Sound.ENTITY_PLAYER_HURT_FREEZE, 1.5f, 0.6f);
        world.playSound(start, Sound.BLOCK_GLASS_BREAK, 1.0f, 0.5f);
        player.swingMainHand();
        Palette.block(start.clone().add(0, 0.2, 0), Material.PACKED_ICE, 40, 0.8, 0.2);

        new BukkitRunnable() {
            int tick = 0;
            Location last = start.clone();
            final Set<UUID> hit = new HashSet<>();

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }
                double d = 1.5 + tick * STEP;
                Location ground = Fx.groundNear(world,
                        start.getX() + forward.getX() * d, start.getZ() + forward.getZ() * d, last.getY());
                boolean blocked = !ground.getBlock().isPassable()
                        || !ground.clone().add(0, 1, 0).getBlock().isPassable();
                if (blocked || d > range) {
                    finale(last);
                    cancel();
                    return;
                }
                last = ground.clone();
                eruption(ground);
            }

            private void eruption(Location ground) {
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                double h = 2.6 + rnd.nextDouble(1.2);

                // Duri utama + dua pengawal
                Palette.spike(ground, h, 0.8, Palette.ICE, Palette.ICE_DEEP);
                for (int s = -1; s <= 1; s += 2) {
                    Location sx = ground.clone().add(right.clone().multiply(s * 1.3));
                    Location sg = Fx.groundNear(world, sx.getX(), sx.getZ(), ground.getY());
                    Palette.spike(sg, h * 0.6, 0.45, Palette.ICE, Palette.FROST_WHITE);
                }

                // Retakan tanah + puing es + embun beku
                Fx.ringDust(ground.clone().add(0, 0.1, 0), 1.4, 16, Palette.ICE);
                Fx.ringDust(ground.clone().add(0, 0.1, 0), 0.8, 10, Palette.FROST_WHITE);
                Palette.block(ground.clone().add(0, 0.4, 0), Material.ICE, 20, 0.7, 0.14);
                Fx.debris(ground.clone().add(0, 0.3, 0), ground.clone().subtract(0, 0.5, 0).getBlock(), 10, 0.6);
                world.spawnParticle(Particle.SNOWFLAKE, ground.clone().add(0, 1, 0), 16, 0.6, 0.9, 0.6, 0.05);
                world.spawnParticle(Particle.CLOUD, ground.clone().add(0, 0.2, 0), 3, 0.5, 0.1, 0.5, 0.02);

                world.playSound(ground, Sound.BLOCK_GLASS_BREAK, 0.8f, 1.1f + tick * 0.06f);
                world.playSound(ground, Sound.BLOCK_AMETHYST_CLUSTER_BREAK, 1.0f, 0.7f);

                for (LivingEntity e : Combat.around(player, ground, width + 1.0)) {
                    if (hit.contains(e.getUniqueId())) continue;
                    double dx = e.getLocation().getX() - ground.getX();
                    double dz = e.getLocation().getZ() - ground.getZ();
                    if (Math.hypot(dx, dz) > width + 0.5) continue;
                    hit.add(e.getUniqueId());

                    Combat.damage(player, e, damage);
                    e.setVelocity(new Vector(0, 0.9, 0));
                    e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, slowTicks, 2, false, false, true));
                    e.setFreezeTicks(Math.max(e.getFreezeTicks(), 120));

                    Location c = e.getLocation().add(0, 1, 0);
                    Palette.block(c, Material.PACKED_ICE, 35, 0.4, 0.2);
                    world.spawnParticle(Particle.SNOWFLAKE, c, 30, 0.4, 0.7, 0.4, 0.15);
                    world.spawnParticle(Particle.END_ROD, c, 12, 0.3, 0.6, 0.3, 0.1);
                    Fx.shock(plugin, e, 30, Palette.ICE, Palette.FROST_WHITE, Particle.SNOWFLAKE);
                    world.playSound(c, Sound.ENTITY_PLAYER_HURT_FREEZE, 1.0f, 0.9f);
                }
            }

            private void finale(Location at) {
                // Kristal raksasa di ujung jalur, lalu pecah
                Palette.spike(at, 5.5, 1.7, Palette.ICE, Palette.ICE_DEEP);
                Palette.spike(at, 4.0, 0.9, Palette.FROST_WHITE, Palette.ICE);
                Fx.ringDust(at.clone().add(0, 0.15, 0), 3.0, 40, Palette.ICE);
                Fx.ringDust(at.clone().add(0, 0.15, 0), 2.0, 28, Palette.FROST_WHITE);
                Palette.block(at.clone().add(0, 0.6, 0), Material.BLUE_ICE, 70, 1.3, 0.28);
                Fx.burst(at.clone().add(0, 1, 0), Particle.SNOWFLAKE, 90, 0.35);
                Fx.burst(at.clone().add(0, 2, 0), Particle.END_ROD, 40, 0.3);
                world.spawnParticle(Particle.SONIC_BOOM, at.clone().add(0, 1.5, 0), 1);
                world.playSound(at, Sound.BLOCK_GLASS_BREAK, 1.6f, 0.6f);
                world.playSound(at, Sound.ENTITY_GENERIC_EXPLODE, 0.7f, 1.7f);
            }
        }.runTaskTimer(plugin, 1L, 2L);
        return true;
    }
}
