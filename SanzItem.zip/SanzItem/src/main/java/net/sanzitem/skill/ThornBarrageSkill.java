package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Thorn Barrage: caster menembakkan belasan duri hijau beruntun ke arah depan (menyebar acak).
 * Tiap duri menembus satu musuh, kena damage dan racun. Berhenti di tembok.
 */
public final class ThornBarrageSkill implements Skill {

    @Override
    public String displayName() {
        return "Thorn Barrage";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double range = params.getDouble("range", 22);
        double damage = params.getDouble("damage", 4.5);
        int needles = Math.max(1, params.getInt("needles", 16));
        double spreadDeg = params.getDouble("spread-degrees", 14);
        int poisonSeconds = params.getInt("poison-seconds", 4);

        World world = player.getWorld();
        Location eye = player.getEyeLocation();
        Vector base = eye.getDirection().normalize();
        world.playSound(eye, Sound.ENTITY_ARROW_SHOOT, 1.2f, 0.6f);
        world.playSound(eye, Sound.BLOCK_SWEET_BERRY_BUSH_BREAK, 1.5f, 0.7f);
        player.swingMainHand();

        new BukkitRunnable() {
            int fired = 0;

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead() || fired >= needles) {
                    cancel();
                    return;
                }
                // 2 duri per tick
                for (int k = 0; k < 2 && fired < needles; k++, fired++) {
                    ThreadLocalRandom rnd = ThreadLocalRandom.current();
                    Location from = player.getEyeLocation().add(0, -0.3, 0);
                    Vector dir = base.clone()
                            .rotateAroundY(Math.toRadians(rnd.nextDouble(-spreadDeg, spreadDeg)))
                            .add(new Vector(0, rnd.nextDouble(-0.08, 0.08), 0)).normalize();
                    Fx.burst(from.clone().add(dir.clone().multiply(1.0)), Particle.COMPOSTER, 4, 0.1);
                    fire(from.add(dir.clone().multiply(0.8)), dir);
                }
                Fx.bodyHelix(player.getLocation(), fired, 0.7, Palette.LEAF, Palette.LEAF_DARK);
            }

            private void fire(Location start, Vector dir) {
                new BukkitRunnable() {
                    final Location pos = start.clone();
                    double travelled = 0;
                    boolean done = false;

                    @Override
                    public void run() {
                        for (int s = 0; s < 2 && !done; s++) {
                            pos.add(dir.clone().multiply(0.9));
                            travelled += 0.9;
                            if (!pos.getBlock().isPassable() || travelled > range) {
                                Fx.burst(pos, Particle.COMPOSTER, 8, 0.2);
                                world.playSound(pos, Sound.BLOCK_GRASS_BREAK, 0.8f, 1.2f);
                                done = true;
                                break;
                            }
                            for (double b = 0; b < 1.2; b += 0.3) {
                                Fx.dust(pos.clone().subtract(dir.clone().multiply(b)), b < 0.3 ? Palette.VENOM : Palette.LEAF_DARK);
                            }
                            for (LivingEntity e : Combat.around(player, pos, 1.8)) {
                                if (!e.getBoundingBox().expand(0.4).contains(pos.toVector())) continue;
                                Combat.damage(player, e, damage);
                                e.addPotionEffect(new PotionEffect(PotionEffectType.POISON, poisonSeconds * 20, 1));
                                world.spawnParticle(Particle.COMPOSTER, e.getLocation().add(0, 1, 0), 12, 0.3, 0.5, 0.3, 0.1);
                                Fx.dust(e.getLocation().add(0, 1, 0), Palette.VENOM);
                                done = true;
                                break;
                            }
                        }
                        if (done) cancel();
                    }
                }.runTaskTimer(plugin, 1L, 1L);
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
