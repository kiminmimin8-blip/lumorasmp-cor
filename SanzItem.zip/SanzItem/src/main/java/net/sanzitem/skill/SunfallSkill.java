package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Palette;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Sunfall (ultimate): matahari mini muncul di atas caster, makin besar dan panas (sinar korona,
 * lingkaran penanda di tanah, musuh mulai gosong). Lalu runtuh ke dalam dan menghujam sebagai
 * kolom cahaya raksasa: ledakan besar, gelombang api melebar, semua musuh terbakar dan terlempar.
 */
public final class SunfallSkill implements Skill {

    private static final int CHARGE = 50;
    private static final int IMPLODE = 5;
    private static final int WAVE = 8;

    @Override
    public String displayName() {
        return "Sunfall";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 12);
        double damage = params.getDouble("damage", 30);
        int burnTicks = params.getInt("burn-seconds", 6) * 20;
        double height = params.getDouble("height", 9);

        World world = player.getWorld();
        Location base = player.getLocation().clone();
        double head = Fx.ceiling(base.clone().add(0, 1, 0), height + 3.0);
        double up = Math.max(3.0, Math.min(height, head - 2.0));
        Location sun = base.clone().add(0, up, 0);

        world.playSound(base, Sound.BLOCK_BEACON_ACTIVATE, 1.6f, 0.6f);
        world.playSound(base, Sound.ENTITY_BLAZE_AMBIENT, 1.5f, 0.5f);
        player.swingMainHand();

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                Location g = base.clone().add(0, 0.12, 0);

                // ---------------- fase 1: matahari membesar
                if (tick <= CHARGE) {
                    double p = tick / (double) CHARGE;
                    double r = (0.5 + 1.7 * p) * (1 + 0.08 * Math.sin(tick * 0.9));

                    Fx.sphere(sun, r, 40, Particle.FLAME);
                    Fx.sphere(sun, r * 0.75, 20, Particle.END_ROD);
                    world.spawnParticle(Particle.DUST, sun, 8, r * 0.4, r * 0.4, r * 0.4, 0, Palette.SUN_CORE);

                    // Sinar korona acak keluar dari permukaan
                    for (int i = 0; i < 4; i++) {
                        Vector v = new Vector(rnd.nextGaussian(), rnd.nextGaussian(), rnd.nextGaussian());
                        if (v.lengthSquared() < 0.01) continue;
                        v.normalize();
                        Fx.lineDust(sun.clone().add(v.clone().multiply(r)),
                                sun.clone().add(v.clone().multiply(r + rnd.nextDouble(1.0, 2.5))), 0.3,
                                i % 2 == 0 ? Palette.SUN : Palette.SUN_ORANGE);
                    }

                    // Penanda area di tanah: cincin batas, cincin progres, bintang berputar
                    Fx.ringDust(g, radius, 64, Palette.SUN_ORANGE);
                    Fx.ringDust(g, radius * p, 48, Palette.SUN);
                    if (tick % 3 == 0) Fx.star(g, radius * 0.85, tick * 0.1, 0.55, Palette.SUN_CORE);
                    Fx.bodyHelix(player.getLocation(), tick, 0.8, Palette.SUN, Palette.SUN_CORE);

                    if (tick % 5 == 0) {
                        world.playSound(sun, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1.2f, 0.5f + (float) p * 1.5f);
                    }
                    if (tick % 10 == 0) {
                        world.playSound(sun, Sound.BLOCK_FIRE_AMBIENT, 1.5f, 0.6f);
                        // Musuh di area mulai gosong
                        for (LivingEntity e : Combat.around(player, base, radius)) {
                            world.spawnParticle(Particle.FLAME, e.getLocation().add(0, 1, 0), 8, 0.3, 0.6, 0.3, 0.02);
                            world.spawnParticle(Particle.SMOKE, e.getLocation().add(0, 1.5, 0), 4, 0.2, 0.3, 0.2, 0.02);
                        }
                    }
                    return;
                }

                // ---------------- fase 2: runtuh ke dalam
                int w = tick - CHARGE;
                if (w <= IMPLODE) {
                    double k = 1 - w / (double) IMPLODE;
                    Fx.sphere(sun, 2.2 * k + 0.3, 30, Particle.END_ROD);
                    world.spawnParticle(Particle.DUST, sun, 20, 0.3, 0.3, 0.3, 0, Palette.SUN_CORE);
                    for (int i = 0; i < 6; i++) {
                        Vector v = new Vector(rnd.nextGaussian(), rnd.nextGaussian(), rnd.nextGaussian());
                        if (v.lengthSquared() < 0.01) continue;
                        Fx.line(sun.clone().add(v.normalize().multiply(4 * k + 1)), sun, Particle.END_ROD, 0.5, 0.05);
                    }
                    if (w == 1) world.playSound(sun, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.0f, 0.5f);
                    if (w == IMPLODE) flare();
                    return;
                }

                // ---------------- fase 3: gelombang api melebar
                int e = w - IMPLODE;
                double r = radius * e / (double) WAVE;
                Fx.ringDust(base.clone().add(0, 0.2, 0), r, (int) (r * 8) + 16, Palette.SUN_CORE);
                Fx.ringDust(base.clone().add(0, 0.4, 0), r * 0.8, (int) (r * 6) + 12, Palette.SUN_ORANGE);
                Fx.ring(base.clone().add(0, 0.3, 0), r, (int) (r * 5) + 12, Particle.FLAME);
                Fx.sphere(base.clone().add(0, 1, 0), r, (int) (20 + r * 4), Particle.END_ROD);
                if (e >= WAVE) cancel();
            }

            private void flare() {
                world.spawnParticle(Particle.EXPLOSION_EMITTER, sun, 1);
                Fx.burst(sun, Particle.FLAME, 200, 0.7);
                Fx.burst(sun, Particle.END_ROD, 120, 0.9);

                // Kolom cahaya dari matahari ke tanah
                Palette.lightColumn(base, up, 1.6, Palette.SUN_CORE, Palette.SUN);
                Palette.lightColumn(base, up, 2.6, Palette.SUN, Palette.SUN_ORANGE);

                // Dentuman di tanah
                for (int i = 0; i < 3; i++) {
                    Location o = base.clone().add((i - 1) * 1.4, 0.5, (i % 2) * 1.2 - 0.6);
                    world.spawnParticle(Particle.EXPLOSION_EMITTER, o, 1);
                }
                Fx.burst(base.clone().add(0, 0.5, 0), Particle.FLAME, 150, 0.5);
                world.spawnParticle(Particle.LAVA, base.clone().add(0, 0.4, 0), 30, 2.0, 0.3, 2.0, 0);
                Fx.debris(base.clone().add(0, 0.3, 0), base.clone().subtract(0, 0.5, 0).getBlock(), 100, 2.0);

                world.playSound(base, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.5f);
                world.playSound(base, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.5f, 0.7f);
                world.playSound(base, Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 2.0f, 0.6f);
                world.playSound(base, Sound.BLOCK_BEACON_DEACTIVATE, 1.5f, 0.8f);

                for (LivingEntity e : Combat.around(player, base, radius)) {
                    Combat.damage(player, e, damage);
                    e.setFireTicks(burnTicks);
                    e.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0, false, false, true));
                    Combat.push(e, base, 1.2, 0.9);
                    Location c = e.getLocation().add(0, 1, 0);
                    world.spawnParticle(Particle.FLAME, c, 50, 0.4, 0.8, 0.4, 0.2);
                    world.spawnParticle(Particle.END_ROD, c, 30, 0.4, 0.8, 0.4, 0.25);
                    Fx.shock(plugin, e, 30, Palette.SUN, Palette.SUN_CORE, Particle.FLAME);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
