package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

/**
 * Thunder Dash: caster nge-charge sebentar (aura listrik), lalu melesat jadi petir ke depan.
 * Semua musuh di jalur kena sambaran + damage, jalur ninggalin garis petir dan bayangan yang memudar.
 */
public final class ThunderDashSkill implements Skill {

    @Override
    public String displayName() {
        return "Thunder Dash";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double distance = params.getDouble("distance", 14);
        double damage = params.getDouble("damage", 14);
        double width = params.getDouble("width", 2.0);

        Vector dir = player.getLocation().getDirection().setY(0);
        if (dir.lengthSquared() < 0.01) return false;
        dir.normalize();

        // Cari titik akhir: maju tiap 0.5 blok selama kaki dan kepala masih kosong (aman buat goa)
        Location start = player.getLocation().clone();
        Location end = start.clone();
        for (double t = 0.5; t <= distance; t += 0.5) {
            Location p = start.clone().add(dir.clone().multiply(t));
            if (!p.getBlock().isPassable() || !p.clone().add(0, 1, 0).getBlock().isPassable()) break;
            end = p;
        }
        if (end.distance(start) < 1.5) {
            player.sendActionBar(plugin.bar("no-space"));
            return false;
        }

        final Location from = start;
        final Location to = end;
        World world = player.getWorld();
        world.playSound(from, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.8f, 1.6f);
        world.playSound(from, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 2.0f);
        player.swingMainHand();

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }

                // Fase 1 (4 tick): charge, listrik ngumpul di kaki dan badan
                if (tick <= 4) {
                    Location base = player.getLocation();
                    Fx.bodyHelix(base, tick * 2, 0.8, Fx.CYAN, Fx.WHITE);
                    world.spawnParticle(Particle.ELECTRIC_SPARK, base.clone().add(0, 1, 0), 14, 0.6, 0.8, 0.6, 0.2);
                    Fx.ringDust(base.clone().add(0, 0.1, 0), 1.6 - tick * 0.3, 18, Fx.CYAN);
                    if (tick == 4) dash();
                    return;
                }

                // Fase 2: bayangan listrik memudar di sepanjang jalur
                int fade = tick - 4;
                if (fade > 10) {
                    cancel();
                    return;
                }
                Vector step = to.toVector().subtract(from.toVector());
                for (int i = 0; i <= 8; i++) {
                    Location p = from.clone().add(step.clone().multiply(i / 8.0)).add(0, 1, 0);
                    if (fade % 2 == 0) {
                        world.spawnParticle(Particle.ELECTRIC_SPARK, p, 3, 0.3, 0.6, 0.3, 0.05);
                    }
                    Fx.dust(p.clone().add(0, (i % 3 - 1) * 0.5, 0), Fx.CYAN);
                }
            }

            private void dash() {
                // Victim di sepanjang segmen from -> to
                Vector seg = to.toVector().subtract(from.toVector());
                double len = seg.length();
                Vector n = seg.clone().normalize();
                Location mid = from.clone().add(seg.clone().multiply(0.5));
                List<LivingEntity> hit = new ArrayList<>();
                for (LivingEntity e : Combat.around(player, mid, len / 2 + width + 1)) {
                    Vector rel = e.getLocation().toVector().subtract(from.toVector());
                    double along = rel.dot(n);
                    if (along < -1 || along > len + 1) continue;
                    double side = rel.clone().subtract(n.clone().multiply(along)).setY(0).length();
                    if (side <= width) hit.add(e);
                }

                // Caster melesat
                Combat.guardFall(player, 30);
                Location dest = to.clone();
                dest.setYaw(player.getLocation().getYaw());
                dest.setPitch(player.getLocation().getPitch());
                player.teleport(dest);
                player.setVelocity(n.clone().multiply(0.4));

                // Garis petir tebal sepanjang jalur
                Location a = from.clone().add(0, 1.0, 0);
                Location b = to.clone().add(0, 1.0, 0);
                Fx.thickBolt(a, b, Math.max(4, (int) (len / 1.5)), 0.5, Fx.CYAN, Fx.WHITE);
                Fx.thickBolt(a.clone().add(0, 0.5, 0), b.clone().add(0, 0.5, 0), Math.max(4, (int) (len / 1.5)),
                        0.4, Fx.GOLD, Fx.CYAN);
                for (double t = 0; t <= len; t += 1.2) {
                    Location p = from.clone().add(n.clone().multiply(t));
                    world.spawnParticle(Particle.CLOUD, p.clone().add(0, 0.2, 0), 2, 0.2, 0.05, 0.2, 0.02);
                    Fx.ringDust(p.clone().add(0, 0.15, 0), 1.0, 10, Fx.CYAN);
                }
                world.spawnParticle(Particle.SONIC_BOOM, from.clone().add(0, 1, 0), 1);
                world.playSound(to, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.2f, 1.4f);
                world.playSound(to, Sound.ITEM_TRIDENT_RIPTIDE_3, 1.0f, 1.3f);

                for (LivingEntity e : hit) {
                    Combat.damage(player, e, damage);
                    Combat.push(e, from, 0.6, 0.45);
                    Fx.skyBolt(Fx.groundNear(world, e.getLocation().getX(), e.getLocation().getZ(),
                            e.getLocation().getY()), 12, Fx.CYAN, Fx.WHITE);
                    world.spawnParticle(Particle.ELECTRIC_SPARK, e.getLocation().add(0, 1, 0), 30, 0.4, 0.7, 0.4, 0.3);
                    Fx.shock(plugin, e, 24, Fx.CYAN, Fx.WHITE, Particle.ELECTRIC_SPARK);
                    world.playSound(e.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.8f, 1.8f);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
