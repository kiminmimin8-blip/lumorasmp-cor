package net.sanzitem.skill;

import net.sanzitem.SanzItem;
import net.sanzitem.util.Combat;
import net.sanzitem.util.Fx;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/**
 * Gale Step: ledakan angin di kaki melempar caster ke depan dan ke atas. Musuh di titik lompat
 * terdorong, caster dapat Speed + Slow Falling singkat, dan ninggalin jejak pusaran angin.
 */
public final class GaleStepSkill implements Skill {

    @Override
    public String displayName() {
        return "Gale Step";
    }

    @Override
    public boolean cast(SanzItem plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 5);
        double damage = params.getDouble("damage", 6);
        double power = params.getDouble("power", 1.5);
        int speedLevel = Math.max(1, params.getInt("speed-level", 3));
        int seconds = params.getInt("seconds", 6);

        World world = player.getWorld();
        Location from = player.getLocation().clone();

        // Ledakan angin di titik lompat
        world.playSound(from, Sound.ENTITY_BREEZE_JUMP, 1.4f, 0.9f);
        world.playSound(from, Sound.ENTITY_WIND_CHARGE_WIND_BURST, 1.4f, 0.8f);
        world.spawnParticle(Particle.GUST_EMITTER_LARGE, from.clone().add(0, 0.3, 0), 1);
        Fx.burst(from.clone().add(0, 0.3, 0), Particle.CLOUD, 60, 0.4);
        Fx.debris(from.clone().add(0, 0.2, 0), from.clone().subtract(0, 0.5, 0).getBlock(), 30, 1.0);
        for (int i = 0; i < 3; i++) {
            Fx.ringDust(from.clone().add(0, 0.15 + i * 0.25, 0), 1.2 + i * 0.9, 24 + i * 6, i == 1 ? Fx.CYAN : Fx.WHITE);
        }
        for (LivingEntity e : Combat.around(player, from, radius)) {
            Combat.damage(player, e, damage);
            Combat.push(e, from, power, 0.6);
            world.spawnParticle(Particle.CLOUD, e.getLocation().add(0, 1, 0), 20, 0.3, 0.5, 0.3, 0.15);
            Fx.shock(plugin, e, 16, Fx.WHITE, Fx.CYAN, Particle.CLOUD);
        }

        // Lontar caster, lompatan dipendekin kalau langit-langit rendah
        Vector dir = player.getLocation().getDirection().setY(0);
        if (dir.lengthSquared() < 0.01) dir = new Vector(0, 0, 1);
        dir.normalize();
        double up = Fx.ceiling(from.clone().add(0, 1.8, 0), 8) < 4 ? 0.45 : 0.95;
        Combat.guardFall(player, 100);
        player.setVelocity(dir.multiply(1.3).setY(up));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, seconds * 20, speedLevel - 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 70, 0));
        player.swingMainHand();

        // Jejak: pusaran angin berpilin ngikutin caster selama di udara
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead() || tick > 36) {
                    cancel();
                    return;
                }
                Location l = player.getLocation();
                Fx.bodyHelix(l, tick * 1.5, 0.7, Fx.WHITE, Fx.CYAN);
                world.spawnParticle(Particle.CLOUD, l.clone().add(0, 0.2, 0), 6, 0.3, 0.1, 0.3, 0.03);
                world.spawnParticle(Particle.GUST, l, 1, 0.4, 0.2, 0.4, 0);
                if (tick % 3 == 0) {
                    Fx.ringDust(l.clone().add(0, 0.1, 0), 0.9 + (tick % 9) * 0.1, 14, Fx.CYAN);
                }
                // Ledakan kecil pas mendarat
                if (tick > 8 && player.isOnGround()) {
                    world.spawnParticle(Particle.CLOUD, l, 30, 1.0, 0.1, 1.0, 0.1);
                    Fx.ringDust(l.clone().add(0, 0.15, 0), 2.2, 28, Fx.WHITE);
                    world.playSound(l, Sound.ENTITY_BREEZE_LAND, 1.0f, 1.0f);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 2L, 1L);
        return true;
    }
}
