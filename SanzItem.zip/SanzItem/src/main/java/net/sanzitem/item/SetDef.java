package net.sanzitem.item;

import java.util.List;
import java.util.Map;

public record SetDef(
        String id,
        List<String> pieces,
        Map<String, Integer> bonusEffects,
        List<SkillSpec> skills) {
}
