package net.sanzitem.item;

import org.bukkit.Material;
import org.bukkit.inventory.EquipmentSlotGroup;

import java.util.List;
import java.util.Map;

public record ItemDef(
        String id,
        Material material,
        String name,
        List<String> lore,
        EquipmentSlotGroup slot,
        Map<String, Double> attributes,
        boolean unbreakable,
        boolean glow,
        List<SkillSpec> skills) {
}
