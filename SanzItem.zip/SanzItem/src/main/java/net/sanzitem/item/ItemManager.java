package net.sanzitem.item;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.sanzitem.SanzItem;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ItemManager {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final SanzItem plugin;
    private final NamespacedKey idKey;

    private final Map<String, ItemDef> items = new LinkedHashMap<>();
    private final Map<String, SetDef> sets = new LinkedHashMap<>();
    private final Map<String, String> pieceToSet = new LinkedHashMap<>();

    public ItemManager(SanzItem plugin) {
        this.plugin = plugin;
        this.idKey = new NamespacedKey(plugin, "item_id");
    }

    // ------------------------------------------------------------------ load

    public void load() {
        items.clear();
        sets.clear();
        pieceToSet.clear();

        File file = new File(plugin.getDataFolder(), "items.yml");
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);

        ConfigurationSection itemSec = yml.getConfigurationSection("items");
        if (itemSec != null) {
            for (String id : itemSec.getKeys(false)) {
                ConfigurationSection s = itemSec.getConfigurationSection(id);
                if (s == null) continue;

                Material material = Material.matchMaterial(s.getString("material", ""));
                if (material == null) {
                    plugin.getLogger().warning("Item '" + id + "': material nggak valid, dilewati.");
                    continue;
                }

                Map<String, Double> attrs = new LinkedHashMap<>();
                ConfigurationSection a = s.getConfigurationSection("attributes");
                if (a != null) {
                    for (String key : a.getKeys(false)) {
                        attrs.put(key, a.getDouble(key));
                    }
                }

                items.put(id, new ItemDef(
                        id,
                        material,
                        s.getString("name", id),
                        s.getStringList("lore"),
                        parseSlot(s.getString("slot", "mainhand")),
                        attrs,
                        s.getBoolean("unbreakable", false),
                        s.getBoolean("glow", false),
                        parseSkills(s)));
            }
        }

        ConfigurationSection setSec = yml.getConfigurationSection("sets");
        if (setSec != null) {
            for (String id : setSec.getKeys(false)) {
                ConfigurationSection s = setSec.getConfigurationSection(id);
                if (s == null) continue;

                List<String> pieces = s.getStringList("pieces");
                Map<String, Integer> bonus = new LinkedHashMap<>();
                ConfigurationSection b = s.getConfigurationSection("bonus-effects");
                if (b != null) {
                    for (String key : b.getKeys(false)) {
                        bonus.put(key, b.getInt(key));
                    }
                }

                sets.put(id, new SetDef(id, pieces, bonus, parseSkills(s)));
                for (String piece : pieces) {
                    if (!items.containsKey(piece)) {
                        plugin.getLogger().warning("Set '" + id + "': piece '" + piece + "' nggak ada di items.");
                    }
                    pieceToSet.put(piece, id);
                }
            }
        }
    }

    /**
     * Baca daftar skill dari section "skills:". Key = tipe skill (atau pakai "type:" di dalamnya).
     * Urutan di file = urutan pas ganti skill (Shift+Klik Kiri / sneak 2x-3x-4x).
     */
    private List<SkillSpec> parseSkills(ConfigurationSection owner) {
        List<SkillSpec> list = new ArrayList<>();
        ConfigurationSection sec = owner.getConfigurationSection("skills");
        if (sec == null) return list;
        int def = plugin.getConfig().getInt("default-cooldown", 60);
        for (String key : sec.getKeys(false)) {
            ConfigurationSection one = sec.getConfigurationSection(key);
            if (one == null) continue;
            String type = one.getString("type", key);
            list.add(new SkillSpec(type, one.getInt("cooldown", def), one));
        }
        return list;
    }

    private EquipmentSlotGroup parseSlot(String slot) {
        return switch (slot.toLowerCase()) {
            case "head" -> EquipmentSlotGroup.HEAD;
            case "chest" -> EquipmentSlotGroup.CHEST;
            case "legs" -> EquipmentSlotGroup.LEGS;
            case "feet" -> EquipmentSlotGroup.FEET;
            default -> EquipmentSlotGroup.MAINHAND;
        };
    }

    // ----------------------------------------------------------------- build

    public ItemStack build(ItemDef def) {
        ItemStack stack = new ItemStack(def.material());
        ItemMeta meta = stack.getItemMeta();

        meta.displayName(MM.deserialize(def.name()).decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        for (String line : def.lore()) {
            lore.add(MM.deserialize(line).decoration(TextDecoration.ITALIC, false));
        }
        if (!def.skills().isEmpty() && def.slot() == EquipmentSlotGroup.MAINHAND) {
            lore.add(Component.empty());
            lore.add(MM.deserialize("<yellow>⚡ Skill <dark_gray>(Shift+Klik Kanan = pakai, Shift+Klik Kiri = ganti)")
                    .decoration(TextDecoration.ITALIC, false));
            int n = 1;
            for (SkillSpec spec : def.skills()) {
                lore.add(MM.deserialize("<gray> " + n++ + ". <white>" + plugin.skills().displayName(spec.type())
                        + " <dark_gray>(" + spec.cooldown() + "s)").decoration(TextDecoration.ITALIC, false));
            }
        }
        meta.lore(lore);

        for (Map.Entry<String, Double> e : def.attributes().entrySet()) {
            Attribute attribute = Registry.ATTRIBUTE.get(NamespacedKey.minecraft(e.getKey()));
            if (attribute == null) {
                plugin.getLogger().warning("Item '" + def.id() + "': atribut '" + e.getKey() + "' nggak dikenal.");
                continue;
            }
            NamespacedKey modKey = new NamespacedKey(plugin, def.id() + "_" + e.getKey());
            meta.addAttributeModifier(attribute, new AttributeModifier(
                    modKey, e.getValue(), AttributeModifier.Operation.ADD_NUMBER, def.slot()));
        }

        if (def.unbreakable()) {
            meta.setUnbreakable(true);
            meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        }
        if (def.glow()) {
            meta.setEnchantmentGlintOverride(true);
        }

        meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, def.id());
        stack.setItemMeta(meta);
        return stack;
    }

    // --------------------------------------------------------------- lookups

    /** ID item custom dari ItemStack, atau null kalau bukan item custom. */
    public String getId(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return null;
        return stack.getItemMeta().getPersistentDataContainer().get(idKey, PersistentDataType.STRING);
    }

    public ItemDef get(String id) {
        return items.get(id);
    }

    public SetDef getSet(String id) {
        return sets.get(id);
    }

    /** Set yang lagi dipakai penuh (4 piece dari set yang sama), atau null. */
    public SetDef getWornSet(Player player) {
        String setId = null;
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            String id = getId(armor);
            if (id == null) return null;
            String s = pieceToSet.get(id);
            if (s == null) return null;
            if (setId == null) setId = s;
            else if (!setId.equals(s)) return null;
        }
        return setId == null ? null : sets.get(setId);
    }

    public List<String> itemIds() {
        return new ArrayList<>(items.keySet());
    }

    public List<String> setIds() {
        return new ArrayList<>(sets.keySet());
    }

    public int itemCount() {
        return items.size();
    }

    public int setCount() {
        return sets.size();
    }
}
