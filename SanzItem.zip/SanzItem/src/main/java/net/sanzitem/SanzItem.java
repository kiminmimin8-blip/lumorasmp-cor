package net.sanzitem;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.sanzitem.command.CustomItemCommand;
import net.sanzitem.domain.DomainListener;
import net.sanzitem.domain.DomainManager;
import net.sanzitem.item.ItemManager;
import net.sanzitem.listener.SkillListener;
import net.sanzitem.skill.SkillManager;
import net.sanzitem.task.SetBonusTask;
import org.bukkit.plugin.java.JavaPlugin;

public final class SanzItem extends JavaPlugin {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private ItemManager itemManager;
    private SkillManager skillManager;
    private DomainManager domainManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new java.io.File(getDataFolder(), "items.yml").exists()) {
            saveResource("items.yml", false);
        }

        itemManager = new ItemManager(this);
        skillManager = new SkillManager(this);
        domainManager = new DomainManager(this);
        itemManager.load();

        getServer().getPluginManager().registerEvents(new SkillListener(this), this);
        getServer().getPluginManager().registerEvents(new DomainListener(this, domainManager), this);

        // Bikin dunia kosong buat skill void_domain lebih awal supaya cast pertama nggak nge-lag
        if (getConfig().getBoolean("void-world.preload", true)) {
            getServer().getScheduler().runTaskLater(this, () -> {
                if (domainManager.world() == null) {
                    getLogger().warning("Dunia kosong buat void_domain belum bisa dibuat.");
                }
            }, 40L);
        }

        CustomItemCommand command = new CustomItemCommand(this);
        var cmd = getCommand("customitem");
        if (cmd != null) {
            cmd.setExecutor(command);
            cmd.setTabCompleter(command);
        }

        new SetBonusTask(this).runTaskTimer(this, 40L, 40L);
        getLogger().info("SanzItem aktif: " + itemManager.itemCount() + " item, "
                + itemManager.setCount() + " set.");
    }

    @Override
    public void onDisable() {
        // Kalau ada domain yang lagi jalan, balikin semua orang dulu sebelum plugin mati
        if (domainManager != null) {
            domainManager.shutdown();
        }
    }

    public void reloadAll() {
        reloadConfig();
        itemManager.load();
    }

    public ItemManager items() {
        return itemManager;
    }

    public SkillManager skills() {
        return skillManager;
    }

    public DomainManager domains() {
        return domainManager;
    }

    /** Pesan dengan prefix (chat). */
    public Component msg(String key, String... pairs) {
        return MM.deserialize(getConfig().getString("prefix", "") + raw(key, pairs));
    }

    /** Pesan tanpa prefix (actionbar). */
    public Component bar(String key, String... pairs) {
        return MM.deserialize(raw(key, pairs));
    }

    private String raw(String key, String... pairs) {
        // Tanpa nilai default eksplisit: kalau key nggak ada di config.yml server, dipakai default dari jar
        String text = getConfig().getString("messages." + key);
        if (text == null) {
            text = "<red>pesan hilang: " + key;
        }
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            text = text.replace("{" + pairs[i] + "}", pairs[i + 1]);
        }
        return text;
    }
}
