package net.sanzitem.domain;

import net.kyori.adventure.title.Title;
import net.sanzitem.SanzItem;
import net.sanzitem.util.Fx;
import net.sanzitem.util.Meteors;
import org.bukkit.Bukkit;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.WorldCreator;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Dimensi kekosongan (domain) buat skill void_domain.
 * <p>
 * Alur: korban + caster disedot (30 tick) -> dipindah ke dunia kosong -> hitung mundur -> hujan meteor
 * (caster kebal) -> meteor penutup raksasa -> semua dibalikin ke lokasi asal.
 * Cuma satu domain aktif sekaligus. Dunia kosong dibuat otomatis (nggak butuh Multiverse).
 */
public final class DomainManager {

    private static final int CAST_TICKS = 30;
    private static final int FINALE_DELAY = 16;
    private static final int FINALE_FALL = 26;
    private static final int METEOR_FALL = 14;
    private static final double METEOR_PATH = 28;
    private static final double SKY_HEIGHT = 24;

    private final SanzItem plugin;
    private World voidWorld;
    private Session active;

    public DomainManager(SanzItem plugin) {
        this.plugin = plugin;
    }

    // --------------------------------------------------------------- config

    private String worldName() {
        return plugin.getConfig().getString("void-world.name", "sanzitem_void");
    }

    private int platformY() {
        return plugin.getConfig().getInt("void-world.platform-y", 100);
    }

    private int platformRadius() {
        return Math.max(8, plugin.getConfig().getInt("void-world.platform-radius", 14));
    }

    public boolean isVoidWorld(World world) {
        return world != null && world.getName().equals(worldName());
    }

    public boolean isBusy() {
        return active != null;
    }

    public boolean isParticipant(Player player) {
        return active != null && active.members.containsKey(player.getUniqueId());
    }

    // ---------------------------------------------------------------- dunia

    /** Dunia kosong (dibuat kalau belum ada). null kalau gagal. */
    public World world() {
        if (voidWorld != null && Bukkit.getWorld(voidWorld.getName()) != null) {
            return voidWorld;
        }
        String name = worldName();
        World w = Bukkit.getWorld(name);
        if (w == null) {
            try {
                WorldCreator creator = new WorldCreator(name);
                creator.generator(new VoidGenerator());
                creator.generateStructures(false);
                w = creator.createWorld();
            } catch (Exception ex) {
                plugin.getLogger().warning("Gagal bikin dunia kosong '" + name + "': " + ex.getMessage());
                return null;
            }
        }
        if (w == null) return null;
        configure(w);
        voidWorld = w;
        return w;
    }

    private void configure(World w) {
        rule(w, false, "doDaylightCycle", "advance_time");
        rule(w, false, "doWeatherCycle", "advance_weather");
        rule(w, false, "doMobSpawning", "spawn_mobs");
        rule(w, false, "announceAdvancements", "announce_advancements");
        w.setTime(18000);
        w.setStorm(false);
        w.setThundering(false);
        w.setSpawnLocation(0, platformY() + 1, 0);

        WorldBorder border = w.getWorldBorder();
        border.setCenter(0.5, 0.5);
        border.setSize(Math.max(40, plugin.getConfig().getDouble("void-world.border-size", 80)));
    }

    /** Set gamerule boolean lewat nama (cobain beberapa nama, biar tahan beda versi). */
    @SuppressWarnings("unchecked")
    private void rule(World w, boolean value, String... names) {
        for (String n : names) {
            GameRule<?> r = GameRule.getByName(n);
            if (r != null && Boolean.class.equals(r.getType())) {
                w.setGameRule((GameRule<Boolean>) r, value);
                return;
            }
        }
    }

    /** Platform bundar dari blackstone + crying obsidian. Dipasang sekali; dicek tiap domain. */
    private void ensurePlatform(World w) {
        int y = platformY();
        int radius = platformRadius();
        if (!w.getBlockAt(0, y, 0).getType().isAir()) return;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > radius + 0.5) continue;

                Material top;
                if (d >= radius - 1.2 || Math.abs(d - radius * 0.55) < 0.7) {
                    top = Material.CRYING_OBSIDIAN;
                } else if (d <= 1.5) {
                    top = Material.GILDED_BLACKSTONE;
                } else {
                    top = ((dx + dz) & 1) == 0 ? Material.POLISHED_BLACKSTONE : Material.POLISHED_BLACKSTONE_BRICKS;
                }
                w.getBlockAt(dx, y, dz).setType(top, false);
                w.getBlockAt(dx, y - 1, dz).setType(Material.BLACKSTONE, false);
                if (d <= radius - 2) {
                    w.getBlockAt(dx, y - 2, dz).setType(Material.BASALT, false);
                }
            }
        }
    }

    // -------------------------------------------------------------- API

    public void start(Player caster, List<LivingEntity> victims, ConfigurationSection params) {
        World w = world();
        if (w == null || active != null) return;
        active = new Session(caster, victims, w, params);
        active.begin();
    }

    /** Dipanggil pas plugin dimatikan: balikin semua orang dulu. */
    public void shutdown() {
        if (active != null) active.finish();
    }

    public void onQuit(Player player) {
        Session s = active;
        if (s == null || !s.members.containsKey(player.getUniqueId())) return;
        if (player.equals(s.caster)) {
            s.finish();
        } else {
            LivingEntity e = s.members.remove(player.getUniqueId());
            returnHome(e, s.origins.get(player.getUniqueId()), s.vw, false);
        }
    }

    public void onDeath(PlayerDeathEvent event) {
        Player p = event.getEntity();
        if (isVoidWorld(p.getWorld()) && plugin.getConfig().getBoolean("void-world.keep-inventory", true)) {
            event.setKeepInventory(true);
            event.setKeepLevel(true);
            event.getDrops().clear();
            event.setDroppedExp(0);
        }
        Session s = active;
        if (s == null || !s.members.containsKey(p.getUniqueId())) return;
        if (p.equals(s.caster)) {
            s.finish();
        } else {
            s.members.remove(p.getUniqueId());
        }
    }

    /** Kalau ada yang login di dunia kosong padahal nggak ada domain (mis. server restart pas domain), keluarin. */
    public void onJoin(Player player) {
        if (!isVoidWorld(player.getWorld()) || isParticipant(player)) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (player.isOnline() && isVoidWorld(player.getWorld()) && !isParticipant(player)) {
                player.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
            }
        });
    }

    // ---------------------------------------------------------- bantuan

    private void returnHome(LivingEntity e, Location origin, World vw, boolean announce) {
        if (e == null || !e.isValid() || e.isDead()) return;

        Location dest = origin;
        if (dest == null || dest.getWorld() == null || isVoidWorld(dest.getWorld())) {
            dest = Bukkit.getWorlds().get(0).getSpawnLocation();
        }

        e.setFireTicks(0);
        e.removePotionEffect(PotionEffectType.BLINDNESS);
        e.removePotionEffect(PotionEffectType.SLOWNESS);

        Location from = e.getLocation();
        if (from.getWorld() != null) {
            from.getWorld().spawnParticle(Particle.PORTAL, from.clone().add(0, 1, 0), 80, 0.4, 0.8, 0.4, 0.8);
            from.getWorld().playSound(from, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 0.8f);
        }

        e.eject();
        e.leaveVehicle();
        e.teleport(dest);
        e.setFallDistance(0);

        World dw = dest.getWorld();
        if (dw != null) {
            dw.spawnParticle(Particle.PORTAL, dest.clone().add(0, 1, 0), 80, 0.4, 0.8, 0.4, 0.8);
            dw.playSound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.2f);
        }
        if (announce && e instanceof Player p) {
            p.showTitle(Title.title(plugin.bar("domain-return-title"), plugin.bar("domain-return-subtitle"),
                    Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(1600), Duration.ofMillis(500))));
        }
    }

    // ================================================================ sesi

    private final class Session {

        final Player caster;
        final World vw;
        final Location center;
        final int pY;
        final int pR;
        final Vector slant;
        final Map<UUID, LivingEntity> members = new LinkedHashMap<>();
        final Map<UUID, Location> origins = new LinkedHashMap<>();

        final int introTicks;
        final int meteors;
        final int interval;
        final double impactRadius;
        final double damage;
        final double seekChance;
        final int burnTicks;
        final double finaleRadius;
        final double finaleDamage;

        BukkitRunnable loop;
        int t = 0;
        boolean arrived = false;

        Session(Player caster, List<LivingEntity> victims, World vw, ConfigurationSection p) {
            this.caster = caster;
            this.vw = vw;
            this.pY = platformY();
            this.pR = platformRadius();
            this.center = new Location(vw, 0.5, pY + 1, 0.5);

            this.introTicks = Math.max(20, p.getInt("intro-seconds", 2) * 20);
            this.meteors = Math.max(1, p.getInt("meteors", 36));
            this.interval = Math.max(1, p.getInt("interval-ticks", 6));
            this.impactRadius = p.getDouble("impact-radius", 3.5);
            this.damage = p.getDouble("damage", 7);
            this.seekChance = Math.max(0, Math.min(1, p.getDouble("seek-chance", 0.6)));
            this.burnTicks = Math.max(0, p.getInt("burn-seconds", 3)) * 20;
            this.finaleRadius = p.getDouble("finale-radius", 9);
            this.finaleDamage = p.getDouble("finale-damage", 16);

            double wind = ThreadLocalRandom.current().nextDouble(0, Math.PI * 2);
            this.slant = new Vector(Math.cos(wind) * 0.45, 1.0, Math.sin(wind) * 0.45).normalize();

            members.put(caster.getUniqueId(), caster);
            origins.put(caster.getUniqueId(), caster.getLocation().clone());
            for (LivingEntity v : victims) {
                members.put(v.getUniqueId(), v);
                origins.put(v.getUniqueId(), v.getLocation().clone());
            }
        }

        void begin() {
            Location at = caster.getLocation();
            at.getWorld().playSound(at, Sound.BLOCK_PORTAL_TRIGGER, 1.2f, 0.5f);
            at.getWorld().playSound(at, Sound.ENTITY_WITHER_SPAWN, 0.6f, 0.6f);
            caster.swingMainHand();

            // Korban buta + lumpuh sebentar selama disedot
            for (LivingEntity e : members.values()) {
                if (e.equals(caster)) continue;
                e.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 50, 0, false, false, false));
                e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 50, 3, false, false, false));
            }

            loop = new BukkitRunnable() {
                @Override
                public void run() {
                    tick();
                }
            };
            loop.runTaskTimer(plugin, 0L, 1L);
        }

        List<Player> players() {
            List<Player> list = new ArrayList<>();
            for (LivingEntity e : members.values()) {
                if (e instanceof Player p && p.isOnline()) list.add(p);
            }
            return list;
        }

        void tick() {
            t++;
            if (!caster.isOnline() || !members.containsKey(caster.getUniqueId())) {
                finish();
                return;
            }

            if (t <= CAST_TICKS) {
                castPhase();
                return;
            }
            if (!arrived) {
                arrived = true;
                arrive();
            }

            int vt = t - CAST_TICKS - 1;
            int fireTicks = meteors * interval;

            atmosphere(vt);
            if (vt % 5 == 0) rescue();

            if (vt < introTicks) {
                intro(vt);
            } else if (vt < introTicks + fireTicks) {
                int idx = vt - introTicks;
                if (idx % interval == 0) fireMeteor(idx / interval);
            } else if (vt == introTicks + fireTicks + FINALE_DELAY) {
                finale();
            } else if (vt >= introTicks + fireTicks + FINALE_DELAY + FINALE_FALL + 50) {
                finish();
            }
        }

        // ----------------------------------------------- fase 1: disedot

        void castPhase() {
            double p = t / (double) CAST_TICKS;
            if (t == CAST_TICKS - 2) caster.swingMainHand();

            for (LivingEntity e : members.values()) {
                if (!e.isValid()) continue;
                Location base = e.getLocation();

                if (e.equals(caster)) {
                    Fx.bodyHelix(base, t, 0.9, Fx.PURPLE, Fx.WHITE);
                    Fx.sphere(base.clone().add(0, 1, 0), 2.5 * (1 - p) + 0.3, 6, Particle.PORTAL);
                    continue;
                }

                // Korban: bola void menciut, cincin ungu menyempit di tanah, spiral naik
                Fx.sphere(base.clone().add(0, 1, 0), 3.0 * (1 - p) + 0.4, 14, Particle.PORTAL);
                Fx.sphere(base.clone().add(0, 1, 0), 2.4 * (1 - p) + 0.3, 8, Particle.REVERSE_PORTAL);
                Fx.ringDust(base.clone().add(0, 0.1, 0), 2.2 * (1 - p) + 0.4, 24, Fx.PURPLE);
                Fx.ringDust(base.clone().add(0, 0.12, 0), 1.4 * (1 - p) + 0.2, 16, Fx.VOID);
                for (int i = 0; i < 3; i++) {
                    double a = t * 0.8 + i * 2.09;
                    double r = 2.0 * (1 - p) + 0.3;
                    Fx.dust(base.clone().add(Math.cos(a) * r, p * 2.2, Math.sin(a) * r), Fx.PURPLE);
                }
            }
        }

        // ---------------------------------------- fase 2: pindah ke void

        void arrive() {
            ensurePlatform(vw);
            vw.setTime(18000);

            for (LivingEntity e : members.values()) {
                Location from = e.getLocation();
                if (from.getWorld() != null) {
                    from.getWorld().spawnParticle(Particle.PORTAL, from.clone().add(0, 1, 0), 100, 0.4, 0.8, 0.4, 0.9);
                    from.getWorld().playSound(from, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 0.6f);
                }
            }

            ThreadLocalRandom rnd = ThreadLocalRandom.current();
            teleportTo(caster, center.clone());

            List<LivingEntity> victims = new ArrayList<>(members.values());
            victims.remove(caster);
            int n = victims.size();
            double offset = rnd.nextDouble(0, Math.PI * 2);
            for (int i = 0; i < n; i++) {
                double angle = offset + 2 * Math.PI * i / Math.max(1, n);
                double r = Math.min(pR - 3, 6 + rnd.nextDouble(0, 3));
                double x = 0.5 + Math.cos(angle) * r;
                double z = 0.5 + Math.sin(angle) * r;
                float yaw = (float) Math.toDegrees(Math.atan2(-(0.5 - x), 0.5 - z));
                teleportTo(victims.get(i), new Location(vw, x, pY + 1, z, yaw, 0));
            }

            for (LivingEntity e : members.values()) {
                e.removePotionEffect(PotionEffectType.BLINDNESS);
                e.removePotionEffect(PotionEffectType.SLOWNESS);
            }

            Title title = Title.title(plugin.bar("domain-title"), plugin.bar("domain-subtitle"),
                    Title.Times.times(Duration.ofMillis(300), Duration.ofMillis(2200), Duration.ofMillis(600)));
            for (Player p : players()) p.showTitle(title);

            vw.playSound(center, Sound.BLOCK_END_PORTAL_SPAWN, 2.0f, 0.7f);
            Fx.burst(center.clone().add(0, 1, 0), Particle.PORTAL, 200, 1.2);
        }

        void teleportTo(LivingEntity e, Location dest) {
            e.eject();
            e.leaveVehicle();
            e.teleport(dest);
            e.setFallDistance(0);
            e.setVelocity(new Vector(0, 0, 0));
        }

        // ------------------------------------- suasana dunia kosong (tiap 2 tick)

        void atmosphere(int vt) {
            if (vt % 2 != 0) return;

            vw.spawnParticle(Particle.ASH, center.clone().add(0, 12, 0), 40, 18, 10, 18, 0);
            vw.spawnParticle(Particle.PORTAL, center.clone().add(0, 3, 0), 20, 14, 4, 14, 0.5);

            double rot = vt * 0.04;
            // Merah = peringatan sebelum meteor turun, ungu = pas hujan meteor
            Particle.DustOptions col = vt < introTicks ? Fx.RED : Fx.PURPLE;
            Location ground = center.clone().add(0, 0.05, 0);
            if (vt % 4 == 0) {
                Fx.star(ground, pR - 2, rot, 1.0, col);
                Fx.ringDust(ground, pR - 2, 64, col);
                Fx.ringDust(ground, (pR - 2) * 0.5, 36, Fx.VOID);
            }

            // Portal api raksasa di langit, makin lama makin terbuka
            Location sky = center.clone().add(0, SKY_HEIGHT, 0);
            double open = Math.min(1.0, (vt + 10) / 20.0);
            double pr = 10 * open;
            Fx.ringDust(sky, pr, 56, Fx.RED);
            Fx.ringDust(sky, pr * 0.7, 40, Fx.ORANGE);
            Fx.star(sky, pr * 0.9, -rot * 1.5, 1.4, Fx.PURPLE);
            vw.spawnParticle(Particle.FLAME, sky, 12, pr * 0.5, 0.5, pr * 0.5, 0.03);
        }

        void rescue() {
            if (!plugin.getConfig().getBoolean("void-world.rescue", true)) return;
            ThreadLocalRandom rnd = ThreadLocalRandom.current();
            for (LivingEntity e : new ArrayList<>(members.values())) {
                if (!e.isValid() || e.isDead() || e.getWorld() != vw) continue;
                if (e.getLocation().getY() >= pY - 12) continue;

                double a = rnd.nextDouble(0, Math.PI * 2);
                double r = rnd.nextDouble(0, 5);
                Location dest = new Location(vw, 0.5 + Math.cos(a) * r, pY + 1, 0.5 + Math.sin(a) * r);
                teleportTo(e, dest);
                vw.playSound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
                Fx.burst(dest.clone().add(0, 1, 0), Particle.PORTAL, 40, 0.5);
            }
        }

        // ----------------------------------------- fase 3: hitung mundur

        void intro(int vt) {
            if (vt % 20 != 0) return;
            int sec = (introTicks - vt + 19) / 20;
            for (Player p : players()) {
                p.sendActionBar(plugin.bar("domain-countdown", "sec", String.valueOf(sec)));
            }
            vw.playSound(center, Sound.ENTITY_WARDEN_HEARTBEAT, 2.0f, 0.8f);
        }

        // ------------------------------------------- fase 4: hujan meteor

        void fireMeteor(int idx) {
            ThreadLocalRandom rnd = ThreadLocalRandom.current();
            Location impact = null;

            // Sebagian meteor ngejar posisi korban saat ini
            if (rnd.nextDouble() < seekChance) {
                List<LivingEntity> pool = new ArrayList<>();
                for (LivingEntity e : members.values()) {
                    if (!e.equals(caster) && e.isValid() && !e.isDead()
                            && e.getWorld() == vw && e.getLocation().getY() >= pY) {
                        pool.add(e);
                    }
                }
                if (!pool.isEmpty()) {
                    Location at = pool.get(rnd.nextInt(pool.size())).getLocation();
                    impact = new Location(vw, at.getX(), pY + 1, at.getZ());
                }
            }
            if (impact == null) {
                double angle = rnd.nextDouble(0, Math.PI * 2);
                double dist = Math.sqrt(rnd.nextDouble()) * (pR - 2);
                impact = new Location(vw, 0.5 + Math.cos(angle) * dist, pY + 1, 0.5 + Math.sin(angle) * dist);
            }

            Meteors.launch(plugin, caster, impact, slant, METEOR_PATH, METEOR_FALL, 1.0,
                    impactRadius, damage, burnTicks, idx % 8 == 7);
            if (idx % 2 == 0) caster.swingMainHand();
        }

        // ------------------------------------------ fase 5: meteor penutup

        void finale() {
            Title title = Title.title(plugin.bar("domain-finale-title"), plugin.bar("domain-finale-subtitle"),
                    Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(1400), Duration.ofMillis(400)));
            for (Player p : players()) p.showTitle(title);

            vw.playSound(center, Sound.ENTITY_ENDER_DRAGON_GROWL, 3.0f, 0.5f);
            vw.playSound(center, Sound.ENTITY_WITHER_SPAWN, 2.0f, 0.5f);
            caster.swingMainHand();

            Vector down = new Vector(0.12, 1.0, 0.12).normalize();
            Meteors.launch(plugin, caster, center.clone(), down, METEOR_PATH, FINALE_FALL, 3.0,
                    finaleRadius, finaleDamage, 100, true);
        }

        // ------------------------------------------------- selesai / balik

        void finish() {
            if (loop != null) loop.cancel();
            if (active == this) active = null;

            List<Map.Entry<UUID, LivingEntity>> all = new ArrayList<>(members.entrySet());
            members.clear();
            for (Map.Entry<UUID, LivingEntity> en : all) {
                returnHome(en.getValue(), origins.get(en.getKey()), vw, true);
            }
        }
    }
}
