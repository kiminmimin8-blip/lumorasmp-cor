package net.sanzitem.domain;

import net.sanzitem.SanzItem;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/** Pengaman dunia kosong: orang keluar/mati pas domain, command, blok, spawn mob. */
public final class DomainListener implements Listener {

    private static final String ADMIN = "customitem.admin";

    private final SanzItem plugin;
    private final DomainManager domains;

    public DomainListener(SanzItem plugin, DomainManager domains) {
        this.plugin = plugin;
        this.domains = domains;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        domains.onQuit(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent event) {
        domains.onDeath(event);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        domains.onJoin(event.getPlayer());
    }

    /** Peserta domain nggak boleh kabur pakai /home, /spawn, /tpa, dll. */
    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (domains.isParticipant(player) && !player.hasPermission(ADMIN)) {
            event.setCancelled(true);
            player.sendMessage(plugin.msg("domain-blocked-command"));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (domains.isVoidWorld(event.getBlock().getWorld()) && !event.getPlayer().hasPermission(ADMIN)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (domains.isVoidWorld(event.getBlock().getWorld()) && !event.getPlayer().hasPermission(ADMIN)) {
            event.setCancelled(true);
        }
    }

    /** Nggak ada mob spawn alami di dunia kosong. */
    @EventHandler(ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent event) {
        CreatureSpawnEvent.SpawnReason reason = event.getSpawnReason();
        if (domains.isVoidWorld(event.getLocation().getWorld())
                && (reason == CreatureSpawnEvent.SpawnReason.NATURAL
                || reason == CreatureSpawnEvent.SpawnReason.CHUNK_GEN)) {
            event.setCancelled(true);
        }
    }
}
