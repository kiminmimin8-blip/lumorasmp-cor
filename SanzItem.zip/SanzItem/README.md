# SanzItem

Plugin Paper 1.21.11: 4 senjata + 1 set armor bertema badai. **Tiap item punya 3 skill aktif, masing-masing dengan animasi sendiri** (di caster, di area, dan di korban). Nggak butuh permission buat pakai skill.

## Kontrol (Java & Bedrock)

Cuma pakai sneak + klik, jadi aman buat Bedrock (Geyser).

| Aksi | Cara |
|---|---|
| Pakai skill terpilih | **Shift + Klik Kanan** (item di tangan) |
| Ganti skill | **Shift + Klik Kiri** (muncul di actionbar) |
| Set armor | Sneak **2x** = skill 1, **3x** = skill 2, **4x** = skill 3 |

Klik kanan biasa (tanpa Shift) nggak disentuh, jadi mana ability AuraSkills tetap jalan. Cooldown 60 detik **per skill**.

## Item dan skill

| Item | Skill 1 | Skill 2 | Skill 3 |
|---|---|---|---|
| `stormbrand` (pedang) | Lightning Strike | Thunder Dash | Storm Nova |
| `tempest_cleaver` (kapak) | Berserker Roar | Cyclone Slash | Ground Slam |
| `stormheart` (nether star) | Starfall | Starlight Mend (heal) | Singularity (lubang hitam) |
| `cataclysm_scepter` (blaze rod) | Meteor Shower | Comet Strike | Void Cataclysm (ultimate) |
| `stormguard_*` (set 4 piece) | Storm Barrier | Gale Step | Static Storm |

Set Stormguard juga kasih Speed I + Regeneration I pasif. Semua efek tembus goa (mulai dari bawah langit-langit), dan Void Cataclysm menyeret target ke dunia kosong lalu hujan meteor (mob nggak ikut kecuali `include-mobs: true`).

## Command

- `/customitem give <player> <id> [jumlah]`
- `/customitem giveset <player> <set>`
- `/customitem list`
- `/customitem reload`

Alias `/citem`, permission `customitem.admin` (default OP).

## Build

```
mvn clean package
```

Jar di `target/SanzItem-1.0.0.jar` → taruh di `plugins/`. Butuh Java 21.

## Update dari versi lama

`items.yml` formatnya berubah (`skills:` berisi 3 skill, bukan `skill:` + `trigger:`). Folder data pindah ke `plugins/SanzItem/` (folder lama `plugins/ThunderForge/` dan jar lamanya hapus aja). Item lama (key `thunderforge:item_id`) NGGAK dikenali lagi, jadi give ulang semua item. Item lama yang udah dipegang pemain tetap dikenali, tapi lore-nya baru ikut setelah item di-give ulang.

## Config

- `config.yml`: pesan, cooldown default, jendela tap sneak (`double-sneak-window-ms`), dunia void
- `items.yml`: item, atribut, skill + parameternya (daftar tipe skill ada di komentar atas file)
