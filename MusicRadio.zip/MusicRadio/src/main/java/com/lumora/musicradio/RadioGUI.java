package com.lumora.musicradio;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class RadioGUI implements Listener {

    private static final String TITLE = "§d§l♪ Music Radio";
    private final MusicRadio plugin;

    public RadioGUI(MusicRadio plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        RadioManager rm = plugin.getRadioManager();
        List<Track> playlist = rm.getPlaylist();

        int size = Math.max(9, ((playlist.size() / 9) + 1) * 9);
        Inventory inv = plugin.getServer().createInventory(null, size, Component.text(TITLE));

        for (int i = 0; i < playlist.size(); i++) {
            Track t = playlist.get(i);
            boolean current = t.equals(rm.getCurrentTrack()) && rm.isPlaying();

            ItemStack item = new ItemStack(current ? Material.MUSIC_DISC_CAT : Material.MUSIC_DISC_13);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Component.text((current ? "§a▶ " : "§e") + t.getName())
                    .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
            meta.lore(List.of(
                    Component.text("§7Durasi: §f" + formatDuration(t.getDurationSeconds())),
                    Component.text(current ? "§aLagi diputer" : "§7Klik buat muter")
                            .colorIfAbsent(NamedTextColor.GRAY)
            ));
            item.setItemMeta(meta);
            inv.setItem(i, item);
        }

        player.openInventory(inv);
    }

    private String formatDuration(int seconds) {
        int m = seconds / 60;
        int s = seconds % 60;
        return String.format("%d:%02d", m, s);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!Component.text(TITLE).equals(event.getView().title())) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getItemMeta() == null) return;

        if (!player.hasPermission("musicradio.admin")) {
            player.sendMessage("§cLu gak punya izin buat ganti lagu radio.");
            return;
        }

        String rawName = net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().serialize(clicked.getItemMeta().displayName())
                .replace("▶ ", "").trim();
        // buang kode warna manual biar match nama asli
        String name = rawName.replaceAll("§[0-9a-fk-or]", "").trim();

        RadioManager rm = plugin.getRadioManager();
        if (rm.playByName(name)) {
            player.sendMessage("§aMuter: §e" + name);
            open(player); // refresh GUI biar marker "lagi diputer" update
        }
    }
}
