package com.lumora.musicradio;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class RadioCommand implements CommandExecutor, TabCompleter {

    private final MusicRadio plugin;

    public RadioCommand(MusicRadio plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        RadioManager rm = plugin.getRadioManager();

        if (args.length == 0) {
            if (sender instanceof Player p) {
                new RadioGUI(plugin).open(p);
                return true;
            }
            sender.sendMessage("§7Pake: /radio <play|stop|next|list|gui> [track]");
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "gui" -> {
                if (sender instanceof Player p) {
                    new RadioGUI(plugin).open(p);
                } else {
                    sender.sendMessage("§cGUI cuma bisa dipake in-game.");
                }
            }
            case "list" -> {
                sender.sendMessage("§d§l♪ Playlist Radio:");
                for (Track t : rm.getPlaylist()) {
                    String marker = t.equals(rm.getCurrentTrack()) ? "§a▶ " : "§7- ";
                    sender.sendMessage(marker + "§f" + t.getName());
                }
            }
            case "play" -> {
                if (!sender.hasPermission("musicradio.admin")) {
                    sender.sendMessage("§cLu gak punya izin.");
                    return true;
                }
                if (args.length >= 2) {
                    String name = String.join(" ", List.of(args).subList(1, args.length));
                    if (rm.playByName(name)) {
                        sender.sendMessage("§aMuter: §e" + name);
                    } else {
                        sender.sendMessage("§cTrack \"" + name + "\" gak ketemu di playlist.");
                    }
                } else {
                    rm.start();
                    sender.sendMessage("§aRadio dimulai.");
                }
            }
            case "stop" -> {
                if (!sender.hasPermission("musicradio.admin")) {
                    sender.sendMessage("§cLu gak punya izin.");
                    return true;
                }
                rm.stop();
                sender.sendMessage("§cRadio distop.");
            }
            case "next" -> {
                if (!sender.hasPermission("musicradio.admin")) {
                    sender.sendMessage("§cLu gak punya izin.");
                    return true;
                }
                rm.next();
                sender.sendMessage("§aSkip ke track selanjutnya.");
            }
            case "reload" -> {
                if (!sender.hasPermission("musicradio.admin")) {
                    sender.sendMessage("§cLu gak punya izin.");
                    return true;
                }
                plugin.reloadConfig();
                rm.reload();
                sender.sendMessage("§aConfig radio di-reload.");
            }
            default -> sender.sendMessage("§7Pake: /radio <play|stop|next|list|gui|reload> [track]");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("play", "stop", "next", "list", "gui", "reload").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (args.length >= 2 && args[0].equalsIgnoreCase("play")) {
            List<String> names = new ArrayList<>();
            for (Track t : plugin.getRadioManager().getPlaylist()) {
                names.add(t.getName());
            }
            return names;
        }
        return List.of();
    }
}
