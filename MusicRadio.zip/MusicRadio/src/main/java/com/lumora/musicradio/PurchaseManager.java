package com.lumora.musicradio;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class PurchaseManager {

    private final MusicRadio plugin;
    private Economy economy;
    private final File dataFile;
    // playerUUID -> set nama track yang udah dibeli permanen
    private final Map<UUID, Set<String>> purchases = new HashMap<>();

    public PurchaseManager(MusicRadio plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "purchases.yml");
        hookVault();
        load();
    }

    private void hookVault() {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
            plugin.getLogger().warning("Vault gak ketemu! Sistem beli lagu bakal dianggap gratis semua.");
            return;
        }
        var rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) {
            economy = rsp.getProvider();
            plugin.getLogger().info("Vault economy ke-hook: " + economy.getName());
        } else {
            plugin.getLogger().warning("Vault ada tapi gak ada economy plugin nyambung. Sistem beli lagu bakal dianggap gratis semua.");
        }
    }

    public boolean hasEconomy() {
        return economy != null;
    }

    public boolean hasPurchased(Player player, Track track) {
        if (track.getPrice() <= 0) return true; // lagu gratis
        Set<String> owned = purchases.get(player.getUniqueId());
        return owned != null && owned.contains(track.getName());
    }

    /**
     * Coba beli track. Return null kalo berhasil, atau pesan error kalo gagal.
     */
    public String tryPurchase(Player player, Track track) {
        if (hasPurchased(player, track)) return null;

        if (track.getPrice() > 0) {
            if (economy == null) {
                // gak ada economy ke-hook, anggap free biar gak ngeblok fitur
                markPurchased(player, track);
                return null;
            }
            if (economy.getBalance(player) < track.getPrice()) {
                return "§cSaldo lu kurang! Butuh §e" + formatPrice(track.getPrice()) + " §cbuat beli lagu ini.";
            }
            economy.withdrawPlayer(player, track.getPrice());
        }

        markPurchased(player, track);
        return null;
    }

    private void markPurchased(Player player, Track track) {
        purchases.computeIfAbsent(player.getUniqueId(), k -> new HashSet<>()).add(track.getName());
        save();
    }

    public String formatPrice(double price) {
        if (price == Math.floor(price)) {
            return String.format("%,.0f", price);
        }
        return String.format("%,.2f", price);
    }

    private void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (Map.Entry<UUID, Set<String>> entry : purchases.entrySet()) {
            cfg.set("purchases." + entry.getKey(), new java.util.ArrayList<>(entry.getValue()));
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            cfg.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal nyimpen purchases.yml: " + e.getMessage());
        }
    }

    private void load() {
        if (!dataFile.exists()) return;
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(dataFile);
        var section = cfg.getConfigurationSection("purchases");
        if (section == null) return;
        for (String uuidStr : section.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(uuidStr);
                Set<String> names = new HashSet<>(section.getStringList(uuidStr));
                purchases.put(uuid, names);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }
}
