package com.lumora.musicradio;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RadioBlockManager {

    private final MusicRadio plugin;
    private final Map<String, RadioBlockSession> sessions = new HashMap<>();
    private final NamespacedKey itemKey;
    private final NamespacedKey lockedTrackKey;
    private final File dataFile;
    private int radius;

    public RadioBlockManager(MusicRadio plugin) {
        this.plugin = plugin;
        this.itemKey = new NamespacedKey(plugin, "radioblock");
        this.lockedTrackKey = new NamespacedKey(plugin, "radioblock_locked_track");
        this.dataFile = new File(plugin.getDataFolder(), "radioblocks.yml");
        this.radius = plugin.getConfig().getInt("radioblock.radius", 50);
        load();
    }

    public NamespacedKey getItemKey() {
        return itemKey;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = Math.max(5, radius);
        plugin.getConfig().set("radioblock.radius", this.radius);
        plugin.saveConfig();
        // update semua session yang udah ada biar langsung kepake radius baru
        for (RadioBlockSession session : sessions.values()) {
            session.setRadius(this.radius);
        }
    }

    private String keyFor(Location loc) {
        return loc.getWorld().getName() + ";" + loc.getBlockX() + ";" + loc.getBlockY() + ";" + loc.getBlockZ();
    }

    public boolean isRadioBlock(Location loc) {
        return sessions.containsKey(keyFor(loc));
    }

    public RadioBlockSession getSession(Location loc) {
        return sessions.get(keyFor(loc));
    }

    public void registerBlock(Location loc) {
        registerBlock(loc, null);
    }

    public void registerBlock(Location loc, String lockedTrackName) {
        Location blockLoc = loc.getBlock().getLocation().add(0.5, 0.5, 0.5);
        RadioBlockSession session = new RadioBlockSession(plugin, blockLoc, radius, lockedTrackName);
        sessions.put(keyFor(loc), session);
        save();
        if (lockedTrackName != null) {
            session.start(); // block terkunci langsung mulai muter begitu ditaro
        }
    }

    public void unregisterBlock(Location loc) {
        RadioBlockSession session = sessions.remove(keyFor(loc));
        if (session != null) session.stop();
        save();
    }

    public ItemStack createRadioBlockItem() {
        String materialName = plugin.getConfig().getString("radioblock.material", "JUKEBOX");
        org.bukkit.Material material = org.bukkit.Material.matchMaterial(materialName);
        if (material == null) material = org.bukkit.Material.JUKEBOX;

        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        String name = plugin.getConfig().getString("radioblock.item-name", "§d§lRadio Block");
        meta.setDisplayName(name);
        meta.setLore(List.of(
                "§7Taro block ini di map lu.",
                "§7Klik kanan buat pilih & muter lagu.",
                "§7Cuma kedengeran radius " + radius + " blok."
        ));
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isRadioBlockItem(ItemStack item) {
        if (item == null || item.getItemMeta() == null) return false;
        return item.getItemMeta().getPersistentDataContainer()
                .has(itemKey, PersistentDataType.BYTE);
    }

    /**
     * Item khusus: block yang begitu ditaro, LANGSUNG terkunci muter 1 lagu
     * doang, loop selamanya, gak ada GUI, gak ada broadcast chat. Beda dari
     * Radio Block biasa (yang bisa ganti-ganti lagu lewat GUI).
     */
    public ItemStack createLoopRadioBlockItem(Track track) {
        String materialName = plugin.getConfig().getString("radioblock.material", "JUKEBOX");
        org.bukkit.Material material = org.bukkit.Material.matchMaterial(materialName);
        if (material == null) material = org.bukkit.Material.JUKEBOX;

        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§b§l♪ Radio Block: " + track.getName());
        meta.setLore(List.of(
                "§7Taro block ini di map lu.",
                "§7Otomatis muter §b" + track.getName() + " §7terus-terusan.",
                "§7Gak ada tombol ganti lagu, gak ada notifikasi chat.",
                "§7Cuma kedengeran radius " + radius + " blok."
        ));
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(lockedTrackKey, PersistentDataType.STRING, track.getName());
        item.setItemMeta(meta);
        return item;
    }

    /** Null kalo item ini Radio Block biasa (bukan yang terkunci 1 lagu). */
    public String getLockedTrackFromItem(ItemStack item) {
        if (item == null || item.getItemMeta() == null) return null;
        return item.getItemMeta().getPersistentDataContainer().get(lockedTrackKey, PersistentDataType.STRING);
    }

    /** Stop semua session, dipanggil pas plugin disable. */
    public void stopAll() {
        sessions.values().forEach(RadioBlockSession::stop);
    }

    private void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        List<Map<String, Object>> raw = new java.util.ArrayList<>();
        for (Map.Entry<String, RadioBlockSession> entry : sessions.entrySet()) {
            Map<String, Object> map = new java.util.LinkedHashMap<>();
            map.put("key", entry.getKey());
            String locked = entry.getValue().getLockedTrackName();
            if (locked != null) map.put("locked-track", locked);
            raw.add(map);
        }
        cfg.set("blocks", raw);
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            cfg.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal nyimpen radioblocks.yml: " + e.getMessage());
        }
    }

    private void load() {
        if (!dataFile.exists()) return;
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(dataFile);
        List<?> rawList = cfg.getList("blocks");
        if (rawList == null) return;

        for (Object rawEntry : rawList) {
            String key;
            String lockedTrack = null;

            if (rawEntry instanceof Map<?, ?> map) {
                Object k = map.get("key");
                if (k == null) continue;
                key = k.toString();
                Object locked = map.get("locked-track");
                if (locked != null) lockedTrack = locked.toString();
            } else if (rawEntry instanceof String s) {
                key = s; // format lama (sebelum ada fitur locked-track), tetep kebaca
            } else {
                continue;
            }

            String[] parts = key.split(";");
            if (parts.length != 4) continue;
            World world = Bukkit.getWorld(parts[0]);
            if (world == null) continue;
            try {
                int x = Integer.parseInt(parts[1]);
                int y = Integer.parseInt(parts[2]);
                int z = Integer.parseInt(parts[3]);
                Location loc = new Location(world, x + 0.5, y + 0.5, z + 0.5);
                RadioBlockSession session = new RadioBlockSession(plugin, loc, radius, lockedTrack);
                sessions.put(key, session);
                if (lockedTrack != null) session.start();
            } catch (NumberFormatException ignored) {
            }
        }
    }
}
