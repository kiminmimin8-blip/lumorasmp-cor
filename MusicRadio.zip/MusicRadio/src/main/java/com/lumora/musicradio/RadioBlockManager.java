package com.lumora.musicradio;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RadioBlockManager {

    private final MusicRadio plugin;
    private final Map<String, RadioBlockSession> sessions = new HashMap<>();
    private final NamespacedKey itemKey;
    private final File dataFile;
    private int radius;

    public RadioBlockManager(MusicRadio plugin) {
        this.plugin = plugin;
        this.itemKey = new NamespacedKey(plugin, "radioblock");
        this.dataFile = new File(plugin.getDataFolder(), "radioblocks.yml");
        this.radius = plugin.getConfig().getInt("radioblock.radius", 50);
        load();
    }

    public NamespacedKey getItemKey() {
        return itemKey;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = Math.max(5, radius);
        plugin.getConfig().set("radioblock.radius", this.radius);
        plugin.saveConfig();
        // update semua session yang udah ada biar langsung kepake radius baru
        for (RadioBlockSession session : sessions.values()) {
            session.setRadius(this.radius);
        }
    }

    private String keyFor(Location loc) {
        return loc.getWorld().getName() + ";" + loc.getBlockX() + ";" + loc.getBlockY() + ";" + loc.getBlockZ();
    }

    public boolean isRadioBlock(Location loc) {
        return sessions.containsKey(keyFor(loc));
    }

    public RadioBlockSession getSession(Location loc) {
        return sessions.get(keyFor(loc));
    }

    public void registerBlock(Location loc) {
        Location blockLoc = loc.getBlock().getLocation().add(0.5, 0.5, 0.5);
        sessions.put(keyFor(loc), new RadioBlockSession(plugin, blockLoc, radius));
        save();
    }

    public void unregisterBlock(Location loc) {
        RadioBlockSession session = sessions.remove(keyFor(loc));
        if (session != null) session.stop();
        save();
    }

    public ItemStack createRadioBlockItem() {
        String materialName = plugin.getConfig().getString("radioblock.material", "JUKEBOX");
        org.bukkit.Material material = org.bukkit.Material.matchMaterial(materialName);
        if (material == null) material = org.bukkit.Material.JUKEBOX;

        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        String name = plugin.getConfig().getString("radioblock.item-name", "§d§lRadio Block");
        meta.setDisplayName(name);
        meta.setLore(List.of(
                "§7Taro block ini di map lu.",
                "§7Klik kanan buat pilih & muter lagu.",
                "§7Cuma kedengeran radius " + radius + " blok."
        ));
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isRadioBlockItem(ItemStack item) {
        if (item == null || item.getItemMeta() == null) return false;
        return item.getItemMeta().getPersistentDataContainer()
                .has(itemKey, PersistentDataType.BYTE);
    }

    /** Stop semua session, dipanggil pas plugin disable. */
    public void stopAll() {
        sessions.values().forEach(RadioBlockSession::stop);
    }

    private void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        List<String> keys = sessions.keySet().stream().toList();
        cfg.set("blocks", keys);
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            cfg.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal nyimpen radioblocks.yml: " + e.getMessage());
        }
    }

    private void load() {
        if (!dataFile.exists()) return;
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(dataFile);
        List<String> keys = cfg.getStringList("blocks");
        for (String key : keys) {
            String[] parts = key.split(";");
            if (parts.length != 4) continue;
            World world = Bukkit.getWorld(parts[0]);
            if (world == null) continue;
            try {
                int x = Integer.parseInt(parts[1]);
                int y = Integer.parseInt(parts[2]);
                int z = Integer.parseInt(parts[3]);
                Location loc = new Location(world, x + 0.5, y + 0.5, z + 0.5);
                sessions.put(key, new RadioBlockSession(plugin, loc, radius));
            } catch (NumberFormatException ignored) {
            }
        }
    }
}
