package com.lumora.musicradio;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class RadioAdminGUI implements Listener {

    private static final String TITLE = "§c§l⚙ Radio Admin Settings";
    private static final int SIZE = 54;
    private static final int RADIUS_SLOT = 49;
    private static final int ADD_TRACK_SLOT = 50;
    private static final int HELP_SLOT = 53;

    private final MusicRadio plugin;
    private final Set<UUID> awaitingTrackInput = new HashSet<>();

    public RadioAdminGUI(MusicRadio plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        Inventory inv = plugin.getServer().createInventory(null, SIZE, Component.text(TITLE));
        List<Track> playlist = plugin.getRadioManager().getPlaylist();

        for (int i = 0; i < playlist.size() && i < 45; i++) {
            Track t = playlist.get(i);
            ItemStack item = new ItemStack(Material.MUSIC_DISC_13);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Component.text("§e" + t.getName()).decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(
                    Component.text("§7Key: §f" + t.getKey()),
                    Component.text("§7Durasi: §f" + t.getDurationSeconds() + "s"),
                    Component.text("§7Harga: §6" + t.getPrice()),
                    Component.text(""),
                    Component.text("§aKlik kiri: §f+1000  §aShift+klik kiri: §f+10000"),
                    Component.text("§cKlik kanan: §f-1000  §cShift+klik kanan: §f-10000"),
                    Component.text("§4Tombol Q: hapus track ini")
            ));
            item.setItemMeta(meta);
            inv.setItem(i, item);
        }

        int radius = plugin.getRadioBlockManager().getRadius();
        ItemStack radiusItem = new ItemStack(Material.COMPASS);
        ItemMeta radiusMeta = radiusItem.getItemMeta();
        radiusMeta.displayName(Component.text("§bRadius Radio Block").decoration(TextDecoration.ITALIC, false));
        radiusMeta.lore(List.of(
                Component.text("§7Sekarang: §f" + (radius * 2) + "x" + (radius * 2) + " blok (kotak)"),
                Component.text("§aKlik kiri: §f+5  §aShift+klik kiri: §f+25"),
                Component.text("§cKlik kanan: §f-5  §cShift+klik kanan: §f-25")
        ));
        radiusItem.setItemMeta(radiusMeta);
        inv.setItem(RADIUS_SLOT, radiusItem);

        ItemStack addItem = new ItemStack(Material.EMERALD);
        ItemMeta addMeta = addItem.getItemMeta();
        addMeta.displayName(Component.text("§a+ Tambah Lagu Baru").decoration(TextDecoration.ITALIC, false));
        addMeta.lore(List.of(
                Component.text("§7Klik buat input lewat chat:"),
                Component.text("§fkey|nama|durasi(detik)|harga")
        ));
        addItem.setItemMeta(addMeta);
        inv.setItem(ADD_TRACK_SLOT, addItem);

        ItemStack helpItem = new ItemStack(Material.PAPER);
        ItemMeta helpMeta = helpItem.getItemMeta();
        helpMeta.displayName(Component.text("§7ℹ Info").decoration(TextDecoration.ITALIC, false));
        helpMeta.lore(List.of(
                Component.text("§7Harga 0 = lagu gratis, gak perlu beli."),
                Component.text("§7Semua perubahan otomatis ke-save ke config.yml")
        ));
        helpItem.setItemMeta(helpMeta);
        inv.setItem(HELP_SLOT, helpItem);

        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!Component.text(TITLE).equals(event.getView().title())) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!player.hasPermission("musicradio.admin")) return;

        int slot = event.getSlot();
        ClickType click = event.getClick();

        if (slot == ADD_TRACK_SLOT) {
            player.closeInventory();
            awaitingTrackInput.add(player.getUniqueId());
            player.sendMessage("§aKetik di chat format: §fkey|nama|durasi(detik)|harga");
            player.sendMessage("§7Contoh: §flumora:radio.lagubaru|Lagu Baru|200|5000");
            player.sendMessage("§7Ketik §ccancel§7 buat batal.");
            return;
        }

        if (slot == RADIUS_SLOT) {
            RadioBlockManager rbm = plugin.getRadioBlockManager();
            int delta = switch (click) {
                case LEFT -> 5;
                case SHIFT_LEFT -> 25;
                case RIGHT -> -5;
                case SHIFT_RIGHT -> -25;
                default -> 0;
            };
            if (delta != 0) {
                rbm.setRadius(rbm.getRadius() + delta);
                player.sendMessage("§bArea radio block sekarang: §f" + (rbm.getRadius() * 2) + "x" + (rbm.getRadius() * 2) + " blok");
                open(player);
            }
            return;
        }

        if (slot >= 45) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getItemMeta() == null || clicked.getItemMeta().displayName() == null) return;

        String name = PlainTextComponentSerializer.plainText().serialize(clicked.getItemMeta().displayName()).trim();
        Track track = plugin.getRadioManager().getPlaylist().stream()
                .filter(t -> t.getName().equalsIgnoreCase(name))
                .findFirst().orElse(null);
        if (track == null) return;

        if (click == ClickType.DROP || click == ClickType.CONTROL_DROP) {
            plugin.getRadioManager().removeTrack(track.getName());
            player.sendMessage("§cTrack \"" + track.getName() + "\" dihapus dari playlist.");
            open(player);
            return;
        }

        double delta = switch (click) {
            case LEFT -> 1000;
            case SHIFT_LEFT -> 10000;
            case RIGHT -> -1000;
            case SHIFT_RIGHT -> -10000;
            default -> 0;
        };
        if (delta != 0) {
            track.setPrice(Math.max(0, track.getPrice() + delta));
            plugin.getRadioManager().persistPlaylist();
            open(player);
        }
    }

    @EventHandler
    public void onChat(AsyncChatEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        if (!awaitingTrackInput.contains(uuid)) return;

        event.setCancelled(true);
        awaitingTrackInput.remove(uuid);

        String message = PlainTextComponentSerializer.plainText().serialize(event.message()).trim();
        Player player = event.getPlayer();

        if (message.equalsIgnoreCase("cancel")) {
            player.sendMessage("§7Dibatalin.");
            return;
        }

        String[] parts = message.split("\\|");
        if (parts.length != 4) {
            player.sendMessage("§cFormat salah! Harus: key|nama|durasi|harga");
            return;
        }

        try {
            String key = parts[0].trim();
            String trackName = parts[1].trim();
            int duration = Integer.parseInt(parts[2].trim());
            double price = Double.parseDouble(parts[3].trim());

            plugin.getRadioManager().addTrack(new Track(key, trackName, duration, price));
            player.sendMessage("§aTrack \"" + trackName + "\" ditambahin ke playlist!");
            try {
                player.getScheduler().run(plugin, task -> open(player), null);
            } catch (NoSuchMethodError | NoClassDefFoundError ex) {
                plugin.getServer().getScheduler().runTask(plugin, () -> open(player));
            }
        } catch (NumberFormatException e) {
            player.sendMessage("§cDurasi/harga harus angka. Contoh: lumora:radio.lagu|Nama Lagu|200|5000");
        }
    }
}
