package com.lumora.musicradio;

import net.kyori.adventure.resource.ResourcePackInfo;
import net.kyori.adventure.resource.ResourcePackRequest;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.net.URI;
import java.util.UUID;

public class ResourcePackListener implements Listener {

    private final MusicRadio plugin;
    private final boolean floodgateAvailable;

    public ResourcePackListener(MusicRadio plugin) {
        this.plugin = plugin;
        this.floodgateAvailable = Bukkit.getPluginManager().getPlugin("floodgate") != null;
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onJoin(PlayerJoinEvent event) {
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.getBoolean("resourcepack.enabled", false)) return;

        Player player = event.getPlayer();

        // Player Bedrock (lewat Geyser/Floodgate) JANGAN dikirimin resourcepack versi Java.
        // Bedrock client punya sistem pack sendiri (folder plugins/Geyser-Spigot/packs/),
        // ngirim link zip Java ke Bedrock bakal gagal parse & bikin player ke-disconnect.
        if (isBedrockPlayer(player)) return;

        String url = cfg.getString("resourcepack.url", "");
        String sha1 = cfg.getString("resourcepack.sha1", "");
        String prompt = cfg.getString("resourcepack.prompt", "Server ini pake custom radio music, mau download resourcepack?");
        boolean force = cfg.getBoolean("resourcepack.force", false);

        if (url == null || url.isBlank()) {
            plugin.getLogger().warning("resourcepack.enabled true tapi resourcepack.url masih kosong di config.yml, skip kirim pack.");
            return;
        }

        try {
            // PENTING: pakai sendResourcePacks() (Adventure API, Paper 1.20.3+),
            // BUKAN setResourcePack() lama yang deprecated. Kalau plugin lain di
            // server (mis. Audes) juga ngirim resourcepack sendiri pakai API
            // yang beda, salah satu bisa nimpa yang lain -- cuma 1 pack yang
            // beneran nyampe ke client walau dua-duanya "berhasil" ke-log.
            // sendResourcePacks() nyusun pack sebagai STACK (nambah), bukan
            // ganti satu slot tunggal, jadi aman dipasang bareng plugin lain
            // yang pakai API yang sama.
            ResourcePackInfo info = (sha1 != null && !sha1.isBlank())
                    ? ResourcePackInfo.resourcePackInfo(UUID.randomUUID(), URI.create(url), sha1)
                    : ResourcePackInfo.resourcePackInfo(UUID.randomUUID(), URI.create(url), "");

            ResourcePackRequest.Builder builder = ResourcePackRequest.resourcePackRequest()
                    .packs(info)
                    .required(force);
            if (prompt != null && !prompt.isBlank()) {
                builder.prompt(Component.text(prompt));
            }

            player.sendResourcePacks(builder.build());
        } catch (Exception e) {
            plugin.getLogger().warning("Gagal kirim resourcepack ke " + player.getName() + ": " + e.getMessage());
        }
    }

    private boolean isBedrockPlayer(Player player) {
        if (!floodgateAvailable) return false;
        try {
            var api = Class.forName("org.geysermc.floodgate.api.FloodgateApi");
            Object instance = api.getMethod("getInstance").invoke(null);
            Object result = api.getMethod("isFloodgatePlayer", UUID.class).invoke(instance, player.getUniqueId());
            return result instanceof Boolean b && b;
        } catch (Exception e) {
            // Floodgate ke-detect tapi API-nya beda/gagal dipanggil, aman default ke false
            return false;
        }
    }
}
