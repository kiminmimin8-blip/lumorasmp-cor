package com.lumora.musicradio;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.UUID;

public class ResourcePackListener implements Listener {

    private final MusicRadio plugin;
    private final boolean floodgateAvailable;

    public ResourcePackListener(MusicRadio plugin) {
        this.plugin = plugin;
        this.floodgateAvailable = Bukkit.getPluginManager().getPlugin("floodgate") != null;
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onJoin(PlayerJoinEvent event) {
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.getBoolean("resourcepack.enabled", false)) return;

        Player player = event.getPlayer();

        // Player Bedrock (lewat Geyser/Floodgate) JANGAN dikirimin resourcepack versi Java.
        // Bedrock client punya sistem pack sendiri (folder plugins/Geyser-Spigot/packs/),
        // ngirim link zip Java ke Bedrock bakal gagal parse & bikin player ke-disconnect.
        if (isBedrockPlayer(player)) return;

        String url = cfg.getString("resourcepack.url", "");
        String sha1 = cfg.getString("resourcepack.sha1", "");
        String prompt = cfg.getString("resourcepack.prompt", "Server ini pake custom radio music, mau download resourcepack?");
        boolean force = cfg.getBoolean("resourcepack.force", false);

        if (url == null || url.isBlank()) {
            plugin.getLogger().warning("resourcepack.enabled true tapi resourcepack.url masih kosong di config.yml, skip kirim pack.");
            return;
        }

        UUID packId = UUID.nameUUIDFromBytes(url.getBytes());

        try {
            if (sha1 != null && !sha1.isBlank()) {
                player.setResourcePack(packId, url, sha1, Component.text(prompt), force);
            } else {
                player.setResourcePack(url);
            }
        } catch (Exception e) {
            plugin.getLogger().warning("Gagal kirim resourcepack ke " + player.getName() + ": " + e.getMessage());
        }
    }

    private boolean isBedrockPlayer(Player player) {
        if (!floodgateAvailable) return false;
        try {
            var api = Class.forName("org.geysermc.floodgate.api.FloodgateApi");
            Object instance = api.getMethod("getInstance").invoke(null);
            Object result = api.getMethod("isFloodgatePlayer", UUID.class).invoke(instance, player.getUniqueId());
            return result instanceof Boolean b && b;
        } catch (Exception e) {
            // Floodgate ke-detect tapi API-nya beda/gagal dipanggil, aman default ke false
            return false;
        }
    }
}
