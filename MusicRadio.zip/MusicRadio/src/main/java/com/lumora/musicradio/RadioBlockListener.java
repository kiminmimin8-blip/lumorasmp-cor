package com.lumora.musicradio;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

public class RadioBlockListener implements Listener {

    private final MusicRadio plugin;
    private final RadioBlockGUI gui;

    public RadioBlockListener(MusicRadio plugin, RadioBlockGUI gui) {
        this.plugin = plugin;
        this.gui = gui;
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent event) {
        if (!plugin.getRadioBlockManager().isRadioBlockItem(event.getItemInHand())) return;

        Location loc = event.getBlock().getLocation();
        plugin.getRadioBlockManager().registerBlock(loc);
        event.getPlayer().sendMessage("§d§l♪ Radio Block §7dipasang! Klik kanan buat pilih lagu.");
    }

    @EventHandler
    public void onBreak(BlockBreakEvent event) {
        Location loc = event.getBlock().getLocation();
        if (!plugin.getRadioBlockManager().isRadioBlock(loc)) return;

        plugin.getRadioBlockManager().unregisterBlock(loc);
        event.setDropItems(false);
        event.getBlock().getWorld().dropItemNaturally(
                loc.add(0.5, 0.5, 0.5),
                plugin.getRadioBlockManager().createRadioBlockItem()
        );
        event.getPlayer().sendMessage("§7Radio Block dibongkar.");
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;

        Location loc = event.getClickedBlock().getLocation();
        if (!plugin.getRadioBlockManager().isRadioBlock(loc)) return;

        Player player = event.getPlayer();
        if (!player.hasPermission("musicradio.use")) {
            player.sendMessage("§cLu gak punya izin buat pake radio block.");
            return;
        }

        event.setCancelled(true);

        if (player.isSneaking()) {
            RadioBlockSession session = plugin.getRadioBlockManager().getSession(loc);
            if (session != null) {
                session.stop();
                player.sendMessage("§cRadio block distop.");
            }
            return;
        }

        gui.open(player, loc);
    }
}
