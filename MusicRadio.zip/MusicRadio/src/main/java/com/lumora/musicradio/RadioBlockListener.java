package com.lumora.musicradio;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class RadioBlockListener implements Listener {

    private final MusicRadio plugin;
    private final RadioBlockGUI gui;

    public RadioBlockListener(MusicRadio plugin, RadioBlockGUI gui) {
        this.plugin = plugin;
        this.gui = gui;
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent event) {
        RadioBlockManager rbm = plugin.getRadioBlockManager();
        ItemStack inHand = event.getItemInHand();
        if (!rbm.isRadioBlockItem(inHand)) return;

        Location loc = event.getBlock().getLocation();
        String lockedTrack = rbm.getLockedTrackFromItem(inHand);
        rbm.registerBlock(loc, lockedTrack);

        if (lockedTrack != null) {
            event.getPlayer().sendMessage("§b§l♪ Radio Block §7dipasang, otomatis muter §b" + lockedTrack + " §7terus-terusan (gak ada notif chat).");
        } else {
            event.getPlayer().sendMessage("§d§l♪ Radio Block §7dipasang! Klik kanan buat pilih lagu.");
        }
    }

    @EventHandler
    public void onBreak(BlockBreakEvent event) {
        RadioBlockManager rbm = plugin.getRadioBlockManager();
        Location loc = event.getBlock().getLocation();
        if (!rbm.isRadioBlock(loc)) return;

        RadioBlockSession session = rbm.getSession(loc);
        String lockedTrack = session != null ? session.getLockedTrackName() : null;

        rbm.unregisterBlock(loc);
        event.setDropItems(false);

        ItemStack drop;
        if (lockedTrack != null) {
            Track track = plugin.getRadioManager().getPlaylist().stream()
                    .filter(t -> t.getName().equalsIgnoreCase(lockedTrack))
                    .findFirst().orElse(null);
            drop = track != null ? rbm.createLoopRadioBlockItem(track) : rbm.createRadioBlockItem();
        } else {
            drop = rbm.createRadioBlockItem();
        }
        event.getBlock().getWorld().dropItemNaturally(loc.add(0.5, 0.5, 0.5), drop);
        event.getPlayer().sendMessage("§7Radio Block dibongkar.");
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;

        RadioBlockManager rbm = plugin.getRadioBlockManager();
        Location loc = event.getClickedBlock().getLocation();
        if (!rbm.isRadioBlock(loc)) return;

        Player player = event.getPlayer();
        if (!player.hasPermission("musicradio.use")) {
            player.sendMessage("§cLu gak punya izin buat pake radio block.");
            return;
        }

        event.setCancelled(true);
        RadioBlockSession session = rbm.getSession(loc);
        if (session == null) return;

        // Block terkunci 1 lagu: GAK ada GUI sama sekali. Sneak+klik buat
        // stop/start doang, pesan status cuma ke player yang klik (private,
        // BUKAN broadcast ke semua chat).
        if (session.isLocked()) {
            if (player.isSneaking()) {
                if (session.isPlaying()) {
                    session.stop();
                    player.sendMessage("§cRadio block ini distop.");
                } else {
                    session.start();
                    player.sendMessage("§aRadio block ini dinyalain lagi.");
                }
            } else {
                player.sendMessage("§7Radio block ini muter: §b" + session.getLockedTrackName()
                        + (session.isPlaying() ? " §a(lagi jalan)" : " §c(mati)"));
            }
            return;
        }

        if (player.isSneaking()) {
            session.stop();
            player.sendMessage("§cRadio block distop.");
            return;
        }

        gui.open(player, loc);
    }
}
