package com.lumora.musicradio;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class RadioBlockGUI implements Listener {

    private static final String TITLE = "§d§l♪ Radio Block";
    private final MusicRadio plugin;
    // player UUID -> lokasi radio block yang lagi dia buka GUI-nya
    private final Map<UUID, Location> openFor = new HashMap<>();

    public RadioBlockGUI(MusicRadio plugin) {
        this.plugin = plugin;
    }

    public void open(Player player, Location blockLocation) {
        RadioBlockManager rbm = plugin.getRadioBlockManager();
        RadioBlockSession session = rbm.getSession(blockLocation);
        if (session == null) return;

        PurchaseManager pm = plugin.getPurchaseManager();
        List<Track> playlist = plugin.getRadioManager().getPlaylist();
        // +9 slot ekstra buat baris tombol stop di bawah
        int size = Math.max(18, (((playlist.size() / 9) + 1) * 9) + 9);
        int stopSlot = size - 5; // tengah baris terakhir

        Inventory inv = plugin.getServer().createInventory(null, size, Component.text(TITLE));

        for (int i = 0; i < playlist.size(); i++) {
            Track t = playlist.get(i);
            boolean current = t.equals(session.getCurrentTrack()) && session.isPlaying();
            boolean owned = pm.hasPurchased(player, t);

            Material mat = current ? Material.MUSIC_DISC_CAT
                    : owned ? Material.MUSIC_DISC_13
                    : Material.MUSIC_DISC_11; // beda item buat yang belom dibeli
            ItemStack item = new ItemStack(mat);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Component.text((current ? "§a▶ " : owned ? "§e" : "§7") + t.getName())
                    .decoration(TextDecoration.ITALIC, false));

            List<Component> lore = new java.util.ArrayList<>();
            lore.add(Component.text("§7Jangkauan: §f" + (rbm.getRadius() * 2) + "x" + (rbm.getRadius() * 2) + " blok"));
            if (t.getPrice() > 0) {
                if (owned) {
                    lore.add(Component.text("§aUdah dibeli, bisa muter kapan aja"));
                } else {
                    lore.add(Component.text("§cBelum dibeli §7- §fHarga: §6" + pm.formatPrice(t.getPrice())));
                    lore.add(Component.text("§7Klik buat beli & langsung muter"));
                }
            } else {
                lore.add(Component.text(current ? "§aLagi diputer disini" : "§7Klik buat muter disini (gratis)"));
            }
            meta.lore(lore);
            item.setItemMeta(meta);
            inv.setItem(i, item);
        }

        // tombol STOP, jelas & gampang diliat, gak perlu sneak+klik lagi
        ItemStack stopItem = new ItemStack(session.isPlaying() ? Material.BARRIER : Material.GRAY_DYE);
        ItemMeta stopMeta = stopItem.getItemMeta();
        stopMeta.displayName(Component.text(session.isPlaying() ? "§c§lSTOP MUSIK" : "§7Radio lagi mati")
                .decoration(TextDecoration.ITALIC, false));
        stopMeta.lore(List.of(Component.text(session.isPlaying() ? "§7Klik buat matiin radio block ini" : "§7Klik lagu di atas buat mulai muter")));
        stopItem.setItemMeta(stopMeta);
        inv.setItem(stopSlot, stopItem);

        openFor.put(player.getUniqueId(), blockLocation);
        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!Component.text(TITLE).equals(event.getView().title())) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        Location blockLocation = openFor.get(player.getUniqueId());
        if (blockLocation == null) return;

        RadioBlockSession session = plugin.getRadioBlockManager().getSession(blockLocation);
        if (session == null) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getItemMeta() == null) return;

        // klik tombol stop (barrier/gray dye)
        if (clicked.getType() == Material.BARRIER) {
            session.stop();
            player.sendMessage("§cRadio block distop.");
            open(player, blockLocation);
            return;
        }
        if (clicked.getType() == Material.GRAY_DYE) {
            return; // radio emang lagi mati, gak ngapa2in
        }

        String rawName = net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().serialize(clicked.getItemMeta().displayName());
        String name = rawName.replace("▶ ", "").replaceAll("§[0-9a-fk-or]", "").trim();

        Track track = plugin.getRadioManager().getPlaylist().stream()
                .filter(t -> t.getName().equalsIgnoreCase(name))
                .findFirst().orElse(null);
        if (track == null) return;

        String error = plugin.getPurchaseManager().tryPurchase(player, track);
        if (error != null) {
            player.sendMessage(error);
            return;
        }

        if (session.playByName(name)) {
            player.sendMessage("§aMuter di radio block ini: §e" + name);
            open(player, blockLocation);
        }
    }
}
