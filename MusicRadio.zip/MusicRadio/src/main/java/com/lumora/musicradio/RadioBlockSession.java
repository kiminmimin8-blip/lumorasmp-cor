package com.lumora.musicradio;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class RadioBlockSession {

    private final MusicRadio plugin;
    private final Location location;
    private int radius; // radius = setengah sisi kotak. radius 50 = area 100x100

    // Kalo diisi, block ini TERKUNCI ke 1 lagu doang, muter ulang terus
    // (loop 1 lagu), gak bisa diganti lewat GUI, dan GUI-nya sendiri
    // gak dibuka pas diklik (lihat RadioBlockListener).
    private final String lockedTrackName;

    private int currentIndex = -1;
    private boolean playing = false;
    private Object scheduledTask; // auto-next abis durasi lagu abis
    private Object watcherTask;   // cek berkala siapa masuk/keluar radius

    // key lagu yang BENERAN lagi diputer sekarang (bukan getCurrentTrack(),
    // soalnya currentIndex bisa udah kepindah duluan sebelum sound lama di-stop)
    private String playingKey;

    // Dev-fix (radius bug): player yang KETAUAN lagi denger track ini SEKARANG.
    // Sebelum ini gak ada -- playSound cuma di-trigger SEKALI pas track mulai
    // ke nearbyPlayers() SAAT ITU DOANG, jadi player yang baru JALAN MASUK radius
    // pas lagu udah jalan gak bakal denger apa-apa sampe lagu berikutnya mulai.
    // watcherTask di bawah ngecek berkala, kirim playSound cuma ke yang BARU
    // masuk (bukan restart ulang buat yang udah denger dari awal).
    private final Set<UUID> listeningNow = new HashSet<>();

    public RadioBlockSession(MusicRadio plugin, Location location, int radius) {
        this(plugin, location, radius, null);
    }

    public RadioBlockSession(MusicRadio plugin, Location location, int radius, String lockedTrackName) {
        this.plugin = plugin;
        this.location = location;
        this.radius = radius;
        this.lockedTrackName = lockedTrackName;
    }

    public Location getLocation() {
        return location;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public boolean isPlaying() {
        return playing;
    }

    public boolean isLocked() {
        return lockedTrackName != null;
    }

    public String getLockedTrackName() {
        return lockedTrackName;
    }

    public Track getCurrentTrack() {
        var playlist = plugin.getRadioManager().getPlaylist();
        if (currentIndex < 0 || currentIndex >= playlist.size()) return null;
        return playlist.get(currentIndex);
    }

    public void start() {
        if (lockedTrackName != null) {
            playByName(lockedTrackName);
            return;
        }
        if (currentIndex < 0) currentIndex = 0;
        playing = true;
        playCurrent();
    }

    public boolean playByName(String name) {
        var playlist = plugin.getRadioManager().getPlaylist();
        for (int i = 0; i < playlist.size(); i++) {
            if (playlist.get(i).getName().equalsIgnoreCase(name)) {
                currentIndex = i;
                playing = true;
                playCurrent();
                return true;
            }
        }
        return false;
    }

    public void next() {
        // Block terkunci: gak pindah track, ulang lagu yang sama lagi (loop 1 lagu).
        if (lockedTrackName != null) {
            playCurrent();
            return;
        }
        var playlist = plugin.getRadioManager().getPlaylist();
        if (playlist.isEmpty()) return;
        currentIndex = (currentIndex + 1) % playlist.size();
        playCurrent();
    }

    public void stop() {
        playing = false;
        cancelScheduled();
        cancelWatcher();
        stopCurrentSound();
    }

    private void playCurrent() {
        // stop lagu SEBELUMNYA (pake key yg beneran lagi jalan), baru mulai yg baru
        stopCurrentSound();
        cancelScheduled();

        Track track = getCurrentTrack();
        if (track == null) return;

        float audibleVolume = calcAudibleVolume();
        listeningNow.clear();
        for (Player p : nearbyPlayers()) {
            p.playSound(location, track.getKey(), SoundCategory.RECORDS, audibleVolume, 1.0f);
            listeningNow.add(p.getUniqueId());
        }
        playingKey = track.getKey();

        scheduleAutoNext(track.getDurationSeconds());
        scheduleWatcher();
    }

    private float calcAudibleVolume() {
        // Volume di Minecraft ngaruh ke jarak dengar: volume 1.0 cuma kedenger ~16 blok.
        // Biar suara beneran nyampe sejauh radius yang di-set, volume di-scale sesuai
        // radius, DIKALI extra-margin (config) soalnya di lapangan jarak beneran suka
        // lebih pendek dari perhitungan teoritis radius/16 doang.
        double margin = plugin.getConfig().getDouble("radioblock.volume-margin", 1.5);
        return (float) Math.max(1.0, (radius / 16.0) * margin);
    }

    /**
     * Dev-fix (radius bug): dipanggil berkala (lihat scheduleWatcher()).
     * Player yang BARU masuk radius dari cek terakhir -> playSound (baru
     * denger track yg lagi jalan). Player yang BARU keluar radius -> stopSound
     * (kalo enggak, kalo mereka connect ulang & jalan masuk radius block LAIN
     * sebelum sound lama abis durasinya sendiri, ini juga cegah numpuk).
     */
    private void checkListeners() {
        if (!playing) return;
        Track track = getCurrentTrack();
        if (track == null) return;

        Set<Player> currentlyInRange = new HashSet<>(nearbyPlayers());
        float audibleVolume = calcAudibleVolume();

        for (Player p : currentlyInRange) {
            if (!listeningNow.contains(p.getUniqueId())) {
                p.playSound(location, track.getKey(), SoundCategory.RECORDS, audibleVolume, 1.0f);
                listeningNow.add(p.getUniqueId());
            }
        }

        listeningNow.removeIf(uuid -> {
            boolean stillInRange = currentlyInRange.stream().anyMatch(p -> p.getUniqueId().equals(uuid));
            if (!stillInRange) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null) p.stopSound(track.getKey(), SoundCategory.RECORDS);
            }
            return !stillInRange;
        });
    }

    private void stopCurrentSound() {
        if (playingKey == null) return;
        for (UUID uuid : listeningNow) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) p.stopSound(playingKey, SoundCategory.RECORDS);
        }
        listeningNow.clear();
        playingKey = null;
    }

    /** Cek radius pake kotak (bukan lingkaran), radius = setengah sisi. */
    private java.util.List<Player> nearbyPlayers() {
        return location.getWorld().getPlayers().stream()
                .filter(p -> {
                    if (!p.getWorld().equals(location.getWorld())) return false;
                    double dx = Math.abs(p.getLocation().getX() - location.getX());
                    double dz = Math.abs(p.getLocation().getZ() - location.getZ());
                    return dx <= radius && dz <= radius;
                })
                .toList();
    }

    private void cancelScheduled() {
        if (scheduledTask instanceof org.bukkit.scheduler.BukkitTask bt) {
            bt.cancel();
        } else if (scheduledTask instanceof io.papermc.paper.threadedregions.scheduler.ScheduledTask st) {
            st.cancel();
        }
        scheduledTask = null;
    }

    private void cancelWatcher() {
        if (watcherTask instanceof org.bukkit.scheduler.BukkitTask bt) {
            bt.cancel();
        } else if (watcherTask instanceof io.papermc.paper.threadedregions.scheduler.ScheduledTask st) {
            st.cancel();
        }
        watcherTask = null;
    }

    private void scheduleAutoNext(int seconds) {
        long ticks = Math.max(20L, seconds * 20L);
        try {
            // Folia-safe: RegionScheduler jalanin task di thread region yang bener buat lokasi ini
            scheduledTask = Bukkit.getRegionScheduler().runDelayed(plugin, location, task -> {
                if (playing) next();
            }, ticks);
        } catch (NoSuchMethodError | NoClassDefFoundError e) {
            scheduledTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (playing) next();
            }, ticks);
        }
    }

    /** Cek listener baru/keluar tiap 5 detik selama lagu masih jalan. */
    private void scheduleWatcher() {
        long intervalTicks = 100L; // 5 detik
        try {
            watcherTask = Bukkit.getRegionScheduler().runAtFixedRate(plugin, location, task -> {
                if (!playing) {
                    cancelWatcher();
                    return;
                }
                checkListeners();
            }, intervalTicks, intervalTicks);
        } catch (NoSuchMethodError | NoClassDefFoundError e) {
            watcherTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
                if (!playing) {
                    cancelWatcher();
                    return;
                }
                checkListeners();
            }, intervalTicks, intervalTicks);
        }
    }
}
