package com.lumora.musicradio;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;

public class RadioBlockSession {

    private final MusicRadio plugin;
    private final Location location;
    private int radius;

    private int currentIndex = -1;
    private boolean playing = false;
    private Object scheduledTask;

    public RadioBlockSession(MusicRadio plugin, Location location, int radius) {
        this.plugin = plugin;
        this.location = location;
        this.radius = radius;
    }

    public Location getLocation() {
        return location;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public boolean isPlaying() {
        return playing;
    }

    public Track getCurrentTrack() {
        var playlist = plugin.getRadioManager().getPlaylist();
        if (currentIndex < 0 || currentIndex >= playlist.size()) return null;
        return playlist.get(currentIndex);
    }

    public void start() {
        if (currentIndex < 0) currentIndex = 0;
        playing = true;
        playCurrent();
    }

    public boolean playByName(String name) {
        var playlist = plugin.getRadioManager().getPlaylist();
        for (int i = 0; i < playlist.size(); i++) {
            if (playlist.get(i).getName().equalsIgnoreCase(name)) {
                currentIndex = i;
                playing = true;
                playCurrent();
                return true;
            }
        }
        return false;
    }

    public void next() {
        var playlist = plugin.getRadioManager().getPlaylist();
        if (playlist.isEmpty()) return;
        currentIndex = (currentIndex + 1) % playlist.size();
        playCurrent();
    }

    public void stop() {
        playing = false;
        cancelScheduled();
        stopSoundNearby();
    }

    private void playCurrent() {
        stopSoundNearby();
        Track track = getCurrentTrack();
        if (track == null) return;

        for (Player p : nearbyPlayers()) {
            p.playSound(location, track.getKey(), SoundCategory.RECORDS, 1.0f, 1.0f);
        }

        scheduleAutoNext(track.getDurationSeconds());
    }

    private void stopSoundNearby() {
        Track track = getCurrentTrack();
        if (track == null) return;
        for (Player p : nearbyPlayers()) {
            p.stopSound(track.getKey(), SoundCategory.RECORDS);
        }
        cancelScheduled();
    }

    private Iterable<Player> nearbyPlayers() {
        double radiusSquared = (double) radius * radius;
        return location.getWorld().getPlayers().stream()
                .filter(p -> p.getLocation().distanceSquared(location) <= radiusSquared)
                .toList();
    }

    private void cancelScheduled() {
        if (scheduledTask instanceof org.bukkit.scheduler.BukkitTask bt) {
            bt.cancel();
        } else if (scheduledTask instanceof io.papermc.paper.threadedregions.scheduler.ScheduledTask st) {
            st.cancel();
        }
        scheduledTask = null;
    }

    private void scheduleAutoNext(int seconds) {
        long ticks = Math.max(20L, seconds * 20L);
        try {
            // Folia-safe: RegionScheduler jalanin task di thread region yang bener buat lokasi ini
            scheduledTask = Bukkit.getRegionScheduler().runDelayed(plugin, location, task -> {
                if (playing) next();
            }, ticks);
        } catch (NoSuchMethodError | NoClassDefFoundError e) {
            scheduledTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (playing) next();
            }, ticks);
        }
    }
}
