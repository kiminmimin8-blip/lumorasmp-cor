package com.lumora.musicradio;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;

public class RadioBlockSession {

    private final MusicRadio plugin;
    private final Location location;
    private int radius; // radius = setengah sisi kotak. radius 50 = area 100x100

    private int currentIndex = -1;
    private boolean playing = false;
    private Object scheduledTask;

    // key lagu yang BENERAN lagi diputer sekarang (bukan getCurrentTrack(),
    // soalnya currentIndex bisa udah kepindah duluan sebelum sound lama di-stop)
    private String playingKey;

    public RadioBlockSession(MusicRadio plugin, Location location, int radius) {
        this.plugin = plugin;
        this.location = location;
        this.radius = radius;
    }

    public Location getLocation() {
        return location;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public boolean isPlaying() {
        return playing;
    }

    public Track getCurrentTrack() {
        var playlist = plugin.getRadioManager().getPlaylist();
        if (currentIndex < 0 || currentIndex >= playlist.size()) return null;
        return playlist.get(currentIndex);
    }

    public void start() {
        if (currentIndex < 0) currentIndex = 0;
        playing = true;
        playCurrent();
    }

    public boolean playByName(String name) {
        var playlist = plugin.getRadioManager().getPlaylist();
        for (int i = 0; i < playlist.size(); i++) {
            if (playlist.get(i).getName().equalsIgnoreCase(name)) {
                currentIndex = i;
                playing = true;
                playCurrent();
                return true;
            }
        }
        return false;
    }

    public void next() {
        var playlist = plugin.getRadioManager().getPlaylist();
        if (playlist.isEmpty()) return;
        currentIndex = (currentIndex + 1) % playlist.size();
        playCurrent();
    }

    public void stop() {
        playing = false;
        cancelScheduled();
        stopCurrentSound();
    }

    private void playCurrent() {
        // stop lagu SEBELUMNYA (pake key yg beneran lagi jalan), baru mulai yg baru
        stopCurrentSound();
        cancelScheduled();

        Track track = getCurrentTrack();
        if (track == null) return;

        // Volume di Minecraft ngaruh ke jarak dengar: volume 1.0 cuma kedenger ~16 blok.
        // Biar suara beneran nyampe sejauh radius yang di-set, volume di-scale sesuai radius.
        float audibleVolume = Math.max(1.0f, radius / 16f);
        for (Player p : nearbyPlayers()) {
            p.playSound(location, track.getKey(), SoundCategory.RECORDS, audibleVolume, 1.0f);
        }
        playingKey = track.getKey();

        scheduleAutoNext(track.getDurationSeconds());
    }

    private void stopCurrentSound() {
        if (playingKey == null) return;
        for (Player p : nearbyPlayers()) {
            p.stopSound(playingKey, SoundCategory.RECORDS);
        }
        playingKey = null;
    }

    /** Cek radius pake kotak (bukan lingkaran), radius = setengah sisi. */
    private Iterable<Player> nearbyPlayers() {
        return location.getWorld().getPlayers().stream()
                .filter(p -> {
                    if (!p.getWorld().equals(location.getWorld())) return false;
                    double dx = Math.abs(p.getLocation().getX() - location.getX());
                    double dz = Math.abs(p.getLocation().getZ() - location.getZ());
                    return dx <= radius && dz <= radius;
                })
                .toList();
    }

    private void cancelScheduled() {
        if (scheduledTask instanceof org.bukkit.scheduler.BukkitTask bt) {
            bt.cancel();
        } else if (scheduledTask instanceof io.papermc.paper.threadedregions.scheduler.ScheduledTask st) {
            st.cancel();
        }
        scheduledTask = null;
    }

    private void scheduleAutoNext(int seconds) {
        long ticks = Math.max(20L, seconds * 20L);
        try {
            // Folia-safe: RegionScheduler jalanin task di thread region yang bener buat lokasi ini
            scheduledTask = Bukkit.getRegionScheduler().runDelayed(plugin, location, task -> {
                if (playing) next();
            }, ticks);
        } catch (NoSuchMethodError | NoClassDefFoundError e) {
            scheduledTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (playing) next();
            }, ticks);
        }
    }
}
