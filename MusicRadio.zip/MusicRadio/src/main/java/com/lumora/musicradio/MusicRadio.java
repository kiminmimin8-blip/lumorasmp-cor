package com.lumora.musicradio;

import org.bukkit.plugin.java.JavaPlugin;

public class MusicRadio extends JavaPlugin {

    private static MusicRadio instance;
    private RadioManager radioManager;
    private RadioBlockManager radioBlockManager;
    private PurchaseManager purchaseManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        radioManager = new RadioManager(this);
        radioBlockManager = new RadioBlockManager(this);
        purchaseManager = new PurchaseManager(this);

        RadioCommand executor = new RadioCommand(this);
        getCommand("radio").setExecutor(executor);
        getCommand("radio").setTabCompleter(executor);

        RadioBlockGUI radioBlockGUI = new RadioBlockGUI(this);
        RadioAdminGUI radioAdminGUI = new RadioAdminGUI(this);
        getServer().getPluginManager().registerEvents(new RadioGUI(this), this);
        getServer().getPluginManager().registerEvents(radioBlockGUI, this);
        getServer().getPluginManager().registerEvents(radioAdminGUI, this);
        getServer().getPluginManager().registerEvents(new RadioBlockListener(this, radioBlockGUI), this);
        getServer().getPluginManager().registerEvents(new ResourcePackListener(this), this);
        executor.setAdminGUI(radioAdminGUI);

        if (getConfig().getBoolean("autoplay", true)) {
            radioManager.start();
        }

        getLogger().info("MusicRadio nyala! " + radioManager.getPlaylist().size() + " track ke-load.");
    }

    @Override
    public void onDisable() {
        if (radioManager != null) {
            radioManager.stop();
        }
        if (radioBlockManager != null) {
            radioBlockManager.stopAll();
        }
    }

    public static MusicRadio getInstance() {
        return instance;
    }

    public RadioManager getRadioManager() {
        return radioManager;
    }

    public RadioBlockManager getRadioBlockManager() {
        return radioBlockManager;
    }

    public PurchaseManager getPurchaseManager() {
        return purchaseManager;
    }
}
