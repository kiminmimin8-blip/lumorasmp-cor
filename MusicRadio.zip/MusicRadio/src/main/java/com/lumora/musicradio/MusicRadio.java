package com.lumora.musicradio;

import org.bukkit.plugin.java.JavaPlugin;

public class MusicRadio extends JavaPlugin {

    private static MusicRadio instance;
    private RadioManager radioManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        radioManager = new RadioManager(this);

        RadioCommand executor = new RadioCommand(this);
        getCommand("radio").setExecutor(executor);
        getCommand("radio").setTabCompleter(executor);

        getServer().getPluginManager().registerEvents(new RadioGUI(this), this);
        getServer().getPluginManager().registerEvents(new ResourcePackListener(this), this);

        if (getConfig().getBoolean("autoplay", true)) {
            radioManager.start();
        }

        getLogger().info("MusicRadio nyala! " + radioManager.getPlaylist().size() + " track ke-load.");
    }

    @Override
    public void onDisable() {
        if (radioManager != null) {
            radioManager.stop();
        }
    }

    public static MusicRadio getInstance() {
        return instance;
    }

    public RadioManager getRadioManager() {
        return radioManager;
    }
}
