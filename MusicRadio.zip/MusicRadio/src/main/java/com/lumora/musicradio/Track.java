package com.lumora.musicradio;

public class Track {

    private final String key;
    private final String name;
    private final int durationSeconds;

    public Track(String key, String name, int durationSeconds) {
        this.key = key;
        this.name = name;
        this.durationSeconds = durationSeconds;
    }

    public String getKey() {
        return key;
    }

    public String getName() {
        return name;
    }

    public int getDurationSeconds() {
        return durationSeconds;
    }
}
