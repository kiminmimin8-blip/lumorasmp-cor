package com.lumora.musicradio;

public class Track {

    private String key;
    private String name;
    private int durationSeconds;
    private double price;

    public Track(String key, String name, int durationSeconds, double price) {
        this.key = key;
        this.name = name;
        this.durationSeconds = durationSeconds;
        this.price = price;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDurationSeconds() {
        return durationSeconds;
    }

    public void setDurationSeconds(int durationSeconds) {
        this.durationSeconds = durationSeconds;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
