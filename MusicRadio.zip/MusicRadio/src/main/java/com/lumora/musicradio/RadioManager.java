package com.lumora.musicradio;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;

public class RadioManager {

    private final MusicRadio plugin;
    private final List<Track> playlist = new ArrayList<>();

    private boolean loop;
    private boolean broadcastMessage;
    private float volume;
    private float pitch;

    private int currentIndex = -1;
    private boolean playing = false;

    // handle buat scheduled task auto-next (Folia-safe & fallback Paper biasa)
    private Object scheduledTask;

    public RadioManager(MusicRadio plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        FileConfiguration cfg = plugin.getConfig();
        playlist.clear();
        for (var section : cfg.getMapList("playlist")) {
            String key = String.valueOf(section.get("key"));
            String name = String.valueOf(section.get("name"));
            int duration = section.get("duration") instanceof Number n ? n.intValue() : 180;
            playlist.add(new Track(key, name, duration));
        }
        loop = cfg.getBoolean("loop", true);
        broadcastMessage = cfg.getBoolean("broadcast-message", true);
        volume = (float) cfg.getDouble("volume", 1.0);
        pitch = (float) cfg.getDouble("pitch", 1.0);
    }

    public List<Track> getPlaylist() {
        return playlist;
    }

    public boolean isPlaying() {
        return playing;
    }

    public Track getCurrentTrack() {
        if (currentIndex < 0 || currentIndex >= playlist.size()) return null;
        return playlist.get(currentIndex);
    }

    /** Mulai playlist dari track pertama (atau lanjut kalo udah ada index). */
    public void start() {
        if (playlist.isEmpty()) return;
        if (currentIndex < 0) currentIndex = 0;
        playing = true;
        playCurrent();
    }

    public void stop() {
        playing = false;
        cancelScheduled();
        stopSoundForAll();
    }

    public void next() {
        if (playlist.isEmpty()) return;
        currentIndex++;
        if (currentIndex >= playlist.size()) {
            if (!loop) {
                stop();
                return;
            }
            currentIndex = 0;
        }
        playCurrent();
    }

    /** Play track spesifik berdasarkan nama (dipake command/GUI). */
    public boolean playByName(String name) {
        for (int i = 0; i < playlist.size(); i++) {
            if (playlist.get(i).getName().equalsIgnoreCase(name)) {
                currentIndex = i;
                playing = true;
                playCurrent();
                return true;
            }
        }
        return false;
    }

    private void playCurrent() {
        stopSoundForAll();
        Track track = getCurrentTrack();
        if (track == null) return;

        for (Player p : Bukkit.getOnlinePlayers()) {
            p.playSound(p.getLocation(), track.getKey(), SoundCategory.RECORDS, volume, pitch);
        }

        if (broadcastMessage) {
            Bukkit.broadcastMessage("§d§l♪ Radio §7» §fNow Playing: §e" + track.getName());
        }

        scheduleAutoNext(track.getDurationSeconds());
    }

    private void stopSoundForAll() {
        Track track = getCurrentTrack();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (track != null) {
                p.stopSound(track.getKey(), SoundCategory.RECORDS);
            }
        }
        cancelScheduled();
    }

    private void cancelScheduled() {
        if (scheduledTask instanceof BukkitTask bt) {
            bt.cancel();
        } else if (scheduledTask instanceof io.papermc.paper.threadedregions.scheduler.ScheduledTask st) {
            st.cancel();
        }
        scheduledTask = null;
    }

    /** Jadwalin auto-next setelah durasi lagu abis. Folia-safe pake GlobalRegionScheduler. */
    private void scheduleAutoNext(int seconds) {
        long ticks = Math.max(20L, seconds * 20L);
        try {
            // Folia & Paper 1.20.5+ punya GlobalRegionScheduler
            scheduledTask = Bukkit.getGlobalRegionScheduler().runDelayed(plugin, task -> {
                if (playing) next();
            }, ticks);
        } catch (NoSuchMethodError | NoClassDefFoundError e) {
            // fallback buat Paper versi lama yang belum ada GlobalRegionScheduler
            scheduledTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (playing) next();
            }, ticks);
        }
    }
}
