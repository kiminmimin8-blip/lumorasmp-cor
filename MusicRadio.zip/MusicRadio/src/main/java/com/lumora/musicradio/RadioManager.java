package com.lumora.musicradio;

import org.bukkit.Bukkit;
import org.bukkit.SoundCategory;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class RadioManager {

    private final MusicRadio plugin;
    private final List<Track> playlist = new ArrayList<>();

    private boolean loop;
    private boolean broadcastMessage;
    private float volume;
    private float pitch;

    private int currentIndex = -1;
    private boolean playing = false;

    // key lagu yang BENERAN lagi diputer sekarang (bukan getCurrentTrack(),
    // soalnya currentIndex bisa udah kepindah duluan sebelum sound lama di-stop)
    private String playingKey;

    // handle buat scheduled task auto-next (Folia-safe & fallback Paper biasa)
    private Object scheduledTask;

    public RadioManager(MusicRadio plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        FileConfiguration cfg = plugin.getConfig();
        playlist.clear();
        for (var section : cfg.getMapList("playlist")) {
            String key = String.valueOf(section.get("key"));
            String name = String.valueOf(section.get("name"));
            int duration = section.get("duration") instanceof Number n ? n.intValue() : 180;
            double price = section.get("price") instanceof Number n ? n.doubleValue() : 0.0;
            playlist.add(new Track(key, name, duration, price));
        }
        loop = cfg.getBoolean("loop", true);
        broadcastMessage = cfg.getBoolean("broadcast-message", true);
        volume = (float) cfg.getDouble("volume", 1.0);
        pitch = (float) cfg.getDouble("pitch", 1.0);
    }

    /** Tulis balik playlist (yg mungkin diedit admin GUI) ke config.yml & save ke disk. */
    public void persistPlaylist() {
        List<Map<String, Object>> raw = new ArrayList<>();
        for (Track t : playlist) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("key", t.getKey());
            map.put("name", t.getName());
            map.put("duration", t.getDurationSeconds());
            map.put("price", t.getPrice());
            raw.add(map);
        }
        plugin.getConfig().set("playlist", raw);
        plugin.saveConfig();
    }

    public void addTrack(Track track) {
        playlist.add(track);
        persistPlaylist();
    }

    public boolean removeTrack(String name) {
        boolean removed = playlist.removeIf(t -> t.getName().equalsIgnoreCase(name));
        if (removed) persistPlaylist();
        return removed;
    }

    public List<Track> getPlaylist() {
        return playlist;
    }

    public boolean isPlaying() {
        return playing;
    }

    public Track getCurrentTrack() {
        if (currentIndex < 0 || currentIndex >= playlist.size()) return null;
        return playlist.get(currentIndex);
    }

    /** Mulai playlist dari track pertama (atau lanjut kalo udah ada index). */
    public void start() {
        if (playlist.isEmpty()) return;
        if (currentIndex < 0) currentIndex = 0;
        playing = true;
        playCurrent();
    }

    public void stop() {
        playing = false;
        cancelScheduled();
        stopCurrentSound();
    }

    public void next() {
        if (playlist.isEmpty()) return;
        currentIndex++;
        if (currentIndex >= playlist.size()) {
            if (!loop) {
                stop();
                return;
            }
            currentIndex = 0;
        }
        playCurrent();
    }

    /** Play track spesifik berdasarkan nama (dipake command/GUI). */
    public boolean playByName(String name) {
        for (int i = 0; i < playlist.size(); i++) {
            if (playlist.get(i).getName().equalsIgnoreCase(name)) {
                currentIndex = i;
                playing = true;
                playCurrent();
                return true;
            }
        }
        return false;
    }

    private void playCurrent() {
        // stop lagu SEBELUMNYA (pake key yg beneran lagi jalan), baru mulai yg baru
        stopCurrentSound();
        cancelScheduled();

        Track track = getCurrentTrack();
        if (track == null) return;

        for (Player p : Bukkit.getOnlinePlayers()) {
            p.playSound(p.getLocation(), track.getKey(), SoundCategory.RECORDS, volume, pitch);
        }
        playingKey = track.getKey();

        if (broadcastMessage) {
            Bukkit.broadcastMessage("§d§l♪ Radio §7» §fNow Playing: §e" + track.getName());
        }

        scheduleAutoNext(track.getDurationSeconds());
    }

    private void stopCurrentSound() {
        if (playingKey == null) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.stopSound(playingKey, SoundCategory.RECORDS);
        }
        playingKey = null;
    }

    private void cancelScheduled() {
        if (scheduledTask instanceof BukkitTask bt) {
            bt.cancel();
        } else if (scheduledTask instanceof io.papermc.paper.threadedregions.scheduler.ScheduledTask st) {
            st.cancel();
        }
        scheduledTask = null;
    }

    /** Jadwalin auto-next setelah durasi lagu abis. Folia-safe pake GlobalRegionScheduler. */
    private void scheduleAutoNext(int seconds) {
        long ticks = Math.max(20L, seconds * 20L);
        try {
            // Folia & Paper 1.20.5+ punya GlobalRegionScheduler
            scheduledTask = Bukkit.getGlobalRegionScheduler().runDelayed(plugin, task -> {
                if (playing) next();
            }, ticks);
        } catch (NoSuchMethodError | NoClassDefFoundError e) {
            // fallback buat Paper versi lama yang belum ada GlobalRegionScheduler
            scheduledTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (playing) next();
            }, ticks);
        }
    }
}
