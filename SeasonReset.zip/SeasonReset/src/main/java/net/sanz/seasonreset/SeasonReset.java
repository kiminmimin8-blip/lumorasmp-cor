package net.sanz.seasonreset;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Statistic;
import org.bukkit.advancement.Advancement;
import org.bukkit.advancement.AdvancementProgress;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;

import java.util.Iterator;

/**
 * SeasonReset — full player-state wipe for a new server season.
 *
 * /seasonreset confirm resets every online player immediately and bumps the
 * stored season number. Any player who logs in later with an older season
 * number stamped on their profile gets reset automatically on join, so
 * offline players are covered without touching world/playerdata files by hand.
 *
 * This plugin resets PLAYER STATE ONLY (inventory, enderchest, XP, health,
 * food, potion effects, advancements, statistics). It does NOT touch the
 * world itself — pair with a world regenerate / Multiverse swap separately
 * if you also want a fresh map.
 */
public final class SeasonReset extends JavaPlugin implements Listener {

    private NamespacedKey seasonKey;

    @Override
    public void onEnable() {
        this.seasonKey = new NamespacedKey(this, "season");
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("SeasonReset enabled. Current season: " + getConfig().getInt("season", 1));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("seasonreset.use")) {
            sender.sendMessage("§cKamu tidak punya izin untuk command ini.");
            return true;
        }

        if (args.length != 1 || !args[0].equalsIgnoreCase("confirm")) {
            sender.sendMessage("§eIni akan mereset inventory, XP, health, advancement, dan " +
                    "statistik SEMUA pemain (online sekarang + offline saat mereka join lagi).");
            sender.sendMessage("§eKetik §c/" + label + " confirm §euntuk melanjutkan.");
            return true;
        }

        int newSeason = getConfig().getInt("season", 1) + 1;
        getConfig().set("season", newSeason);
        saveConfig();

        int count = 0;
        for (Player player : Bukkit.getOnlinePlayers()) {
            resetPlayer(player, newSeason);
            count++;
        }

        Bukkit.broadcastMessage("§6§lSeason baru dimulai! §7Semua progress pemain telah direset.");
        sender.sendMessage("§aSelesai. " + count + " pemain online direset. Season sekarang: §f" + newSeason
                + "§a. Pemain offline akan direset otomatis saat login berikutnya.");
        getLogger().info(sender.getName() + " triggered a season reset -> season " + newSeason
                + " (" + count + " online players reset immediately)");
        return true;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        int currentSeason = getConfig().getInt("season", 1);
        Integer stored = player.getPersistentDataContainer().get(seasonKey, PersistentDataType.INTEGER);

        if (stored == null || stored < currentSeason) {
            resetPlayer(player, currentSeason);
            player.sendMessage("§6Akunmu telah direset untuk season baru. Selamat bermain!");
        }
    }

    /**
     * Wipes a single player's inventory, enderchest, XP, health, food,
     * potion effects, advancements, and statistics, then stamps them with
     * the given season number so they won't be reset again until the next
     * /seasonreset.
     */
    private void resetPlayer(Player player, int season) {
        // Inventory, armor, offhand, enderchest
        player.getInventory().clear();
        player.getInventory().setArmorContents(null);
        player.getInventory().setItemInOffHand(null);
        player.getEnderChest().clear();

        // XP / level
        player.setExp(0f);
        player.setLevel(0);
        player.setTotalExperience(0);

        // Health / hunger / effects
        var maxHealthAttr = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH);
        if (maxHealthAttr != null) {
            player.setHealth(maxHealthAttr.getValue());
        }
        player.setFoodLevel(20);
        player.setSaturation(5f);
        player.setExhaustion(0f);
        player.setFireTicks(0);
        for (PotionEffect effect : player.getActivePotionEffects()) {
            player.removePotionEffect(effect.getType());
        }

        // Advancements — revoke everything that's been awarded
        Iterator<Advancement> advancements = Bukkit.advancementIterator();
        while (advancements.hasNext()) {
            Advancement advancement = advancements.next();
            AdvancementProgress progress = player.getAdvancementProgress(advancement);
            for (String criterion : progress.getAwardedCriteria()) {
                progress.revokeCriteria(criterion);
            }
        }

        // Statistics — untyped, plus per-block/item/entity typed stats
        for (Statistic stat : Statistic.values()) {
            try {
                switch (stat.getType()) {
                    case UNTYPED -> player.setStatistic(stat, 0);
                    case BLOCK, ITEM -> {
                        for (Material material : Material.values()) {
                            if (material.isLegacy()) continue;
                            try {
                                player.setStatistic(stat, material, 0);
                            } catch (IllegalArgumentException ignored) {
                                // stat/material combo not applicable, skip
                            }
                        }
                    }
                    case ENTITY -> {
                        for (EntityType type : EntityType.values()) {
                            try {
                                player.setStatistic(stat, type, 0);
                            } catch (IllegalArgumentException ignored) {
                                // stat/entity combo not applicable, skip
                            }
                        }
                    }
                }
            } catch (Exception e) {
                getLogger().warning("Skipped statistic " + stat + " for " + player.getName() + ": " + e.getMessage());
            }
        }

        // Misc: back to survival, clear cursor item, respawn at world spawn
        if (player.getGameMode() == GameMode.SPECTATOR) {
            player.setGameMode(GameMode.SURVIVAL);
        }
        player.teleport(player.getWorld().getSpawnLocation());

        // Stamp the season so this player isn't reset again until the next trigger
        player.getPersistentDataContainer().set(seasonKey, PersistentDataType.INTEGER, season);
    }
}
