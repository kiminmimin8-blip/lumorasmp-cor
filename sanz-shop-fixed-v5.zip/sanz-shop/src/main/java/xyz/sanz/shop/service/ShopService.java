package xyz.sanz.shop.service;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import xyz.sanz.shop.EconomyHook;
import xyz.sanz.shop.SanzShop;
import xyz.sanz.shop.ShopManager;
import xyz.sanz.shop.model.ShopItem;
import xyz.sanz.shop.util.InventoryUtils;
import xyz.sanz.shop.util.Messages;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Logika transaksi jual-beli murni, dipisah dari kode GUI supaya bisa dites/dipakai ulang
 * (mis. dari command langsung, bukan cuma dari klik inventory).
 */
public class ShopService {

    public enum Result {
        SUCCESS,
        NOT_ENOUGH_MONEY,
        INVENTORY_FULL,
        NOT_ENOUGH_ITEMS,
        NOT_BUYABLE,
        NOT_SELLABLE,
        NO_ECONOMY,
        /** Player punya materialnya, tapi yang kurang itu gara-gara sebagian dilindungi (item bagus). */
        PROTECTED_ITEMS,
        /** Vault nolak transaksinya (deposit/withdraw gagal) -- item dikembalikan, gak ada yang ilang. */
        ECONOMY_ERROR
    }

    /** Preview buat GUI konfirmasi /sell (jual item di tangan) -- read-only, gak ngubah apa pun. */
    public record HandPreview(boolean sellable, ShopItem item, String itemName, int amount,
                               double totalPrice, int protectedCount) {}

    /** Preview buat GUI konfirmasi /sell all -- read-only, gak ngubah apa pun. */
    public record SellAllPreview(int materialCount, int totalItems, double totalPrice, int protectedCount) {}

    /** Ringkasan hasil eksekusi /sell all, dipakai buat 1 pesan rangkuman (bukan spam per-material). */
    public record SellAllSummary(int materialCount, int totalItems, double totalPrice, int protectedCount) {}

    private final SanzShop plugin;
    private final Messages messages;

    public ShopService(SanzShop plugin) {
        this.plugin = plugin;
        this.messages = plugin.getMessages();
    }

    /** Proteksi item bagus (enchant/nama/lore/isi) aktif? Lihat sell.protect-valuable-items di config.yml. */
    public boolean isProtectionEnabled() {
        return plugin.getConfig().getBoolean("sell.protect-valuable-items", true);
    }

    /** Jumlah `material` di inventory player yang BOLEH dijual (item bagus gak dihitung kalau proteksi aktif). */
    public int countSellable(Player player, Material material) {
        return InventoryUtils.countSellable(player.getInventory(), material, isProtectionEnabled());
    }

    public Result buy(Player player, ShopItem item, int qty) {
        if (!EconomyHook.isReady()) return Result.NO_ECONOMY;
        if (!item.isBuyable()) return Result.NOT_BUYABLE;

        double totalPrice = buyTotal(item, qty);
        int totalAmount = item.getAmount() * qty;

        Economy econ = EconomyHook.get();
        if (econ.getBalance(player) < totalPrice) return Result.NOT_ENOUGH_MONEY;
        if (!InventoryUtils.hasSpaceFor(player.getInventory(), item.getMaterial(), totalAmount)) {
            return Result.INVENTORY_FULL;
        }

        EconomyResponse resp = econ.withdrawPlayer(player, totalPrice);
        if (!resp.transactionSuccess()) return Result.ECONOMY_ERROR;

        InventoryUtils.giveItems(player, item.getMaterial(), totalAmount);
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);

        Map<String, String> ph = new HashMap<>();
        ph.put("%amount%", String.valueOf(totalAmount));
        ph.put("%item%", item.getDisplayName());
        ph.put("%price%", formatMoney(totalPrice));
        messages.send(player, "purchase-success", ph);
        return Result.SUCCESS;
    }

    /** Jual `qty` x (item.getAmount()) item, kirim pesan sukses/notice seperti biasa. */
    public Result sell(Player player, ShopItem item, int qty) {
        return sell(player, item, qty, false);
    }

    /**
     * Jual `qty` x (item.getAmount()) item dari SLOT PENYIMPANAN player (hotbar + tas).
     * Yang ikut kejual cuma item yang lolos proteksi; item bagus (enchant/nama/lore/isi)
     * dilewati. Barang yang kejual dicatat persis (utuh) di RefundManager buat /sellrefund.
     *
     * `silent` = true -> tetep jual & catat refund seperti biasa, tapi TIDAK kirim pesan
     * sell-success/sell-protected-notice per item. Dipakai oleh sellAll() supaya jual banyak
     * material sekaligus gak nge-spam chat -- pemanggil yang kirim 1 pesan rangkuman sendiri.
     */
    public Result sell(Player player, ShopItem item, int qty, boolean silent) {
        if (!EconomyHook.isReady()) return Result.NO_ECONOMY;
        if (!item.isSellable()) return Result.NOT_SELLABLE;

        Material material = item.getMaterial();
        boolean protect = isProtectionEnabled();
        Inventory inv = player.getInventory();
        int totalAmount = item.getAmount() * qty;

        if (InventoryUtils.countSellable(inv, material, protect) < totalAmount) {
            boolean hasProtected = protect && InventoryUtils.countProtected(inv, material) > 0;
            return hasProtected ? Result.PROTECTED_ITEMS : Result.NOT_ENOUGH_ITEMS;
        }

        double totalPrice = sellTotal(item, qty);

        List<ItemStack> removed = InventoryUtils.removeSellable(inv, material, totalAmount, protect);
        EconomyResponse resp = EconomyHook.get().depositPlayer(player, totalPrice);
        if (!resp.transactionSuccess()) {
            // uang gagal masuk -> balikin barangnya, jangan sampai player rugi
            InventoryUtils.giveOrDrop(player, removed);
            return Result.ECONOMY_ERROR;
        }

        plugin.getRefundManager().record(player, item.getDisplayName(), material, totalAmount, totalPrice, removed);
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 0.7f);

        if (!silent) {
            Map<String, String> ph = new HashMap<>();
            ph.put("%amount%", String.valueOf(totalAmount));
            ph.put("%item%", item.getDisplayName());
            ph.put("%price%", formatMoney(totalPrice));
            messages.send(player, "sell-success", ph);

            // kasih tau kalau ada stack sejenis yang sengaja gak ikut kejual karena dilindungi
            if (protect) {
                int skipped = InventoryUtils.countProtected(inv, material);
                if (skipped > 0) {
                    Map<String, String> ph2 = new HashMap<>();
                    ph2.put("%protected%", String.valueOf(skipped));
                    ph2.put("%item%", item.getDisplayName());
                    messages.send(player, "sell-protected-notice", ph2);
                }
            }
        }
        return Result.SUCCESS;
    }

    /** Harga total jual `qty` x item.getAmount(), termasuk sell-multiplier global. */
    private double sellTotal(ShopItem item, int qty) {
        double multiplier = plugin.getConfig().getDouble("economy.sell-multiplier", 1.0);
        return item.getSellPrice() * qty * multiplier;
    }

    /** Semua material unik yang ada di slot penyimpanan (hotbar + tas) player. */
    private Set<Material> distinctStorageMaterials(Player player) {
        Set<Material> set = EnumSet.noneOf(Material.class);
        for (ItemStack stack : player.getInventory().getStorageContents()) {
            if (stack != null && stack.getType() != Material.AIR) set.add(stack.getType());
        }
        return set;
    }

    /**
     * Cari ShopItem yang cocok buat 1 material tertentu, harga jual PALING TINGGI kalau
     * kebetulan material itu terdaftar di lebih dari 1 kategori (sama kayak logika /sellhand).
     * Balikin null kalau material itu emang gak dijual di shop sama sekali.
     */
    private ShopItem bestSellableFor(Material material) {
        List<ShopManager.ItemMatch> matches = plugin.getShopManager().findItemAcrossCategories(material.name());
        return matches.stream()
                .map(ShopManager.ItemMatch::item)
                .filter(ShopItem::isSellable)
                .max(Comparator.comparingDouble(ShopItem::getSellPrice))
                .orElse(null);
    }

    /** Preview (read-only) buat GUI konfirmasi jual item di tangan. */
    public HandPreview previewHand(Player player) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand.getType() == Material.AIR) {
            return new HandPreview(false, null, null, 0, 0, 0);
        }
        ShopItem item = bestSellableFor(hand.getType());
        int protectedCount = InventoryUtils.countProtected(player.getInventory(), hand.getType());
        if (item == null) {
            return new HandPreview(false, null, hand.getType().name(), 0, 0, protectedCount);
        }
        int qty = countSellable(player, item.getMaterial()) / item.getAmount();
        int amount = qty * item.getAmount();
        return new HandPreview(qty > 0, item, item.getDisplayName(), amount, sellTotal(item, qty), protectedCount);
    }

    /** Preview (read-only) buat GUI konfirmasi /sell all -- gak jual apa-apa, cuma ngitung. */
    public SellAllPreview previewSellAll(Player player) {
        int materials = 0, totalItems = 0, protectedCount = 0;
        double totalPrice = 0;
        for (Material material : distinctStorageMaterials(player)) {
            ShopItem item = bestSellableFor(material);
            if (item == null) continue;
            int qty = countSellable(player, material) / item.getAmount();
            if (qty <= 0) continue;
            materials++;
            totalItems += qty * item.getAmount();
            totalPrice += sellTotal(item, qty);
        }
        if (isProtectionEnabled()) {
            for (Material material : distinctStorageMaterials(player)) {
                protectedCount += InventoryUtils.countProtected(player.getInventory(), material);
            }
        }
        return new SellAllPreview(materials, totalItems, totalPrice, protectedCount);
    }

    /**
     * Eksekusi beneran /sell all: jual semua material di slot penyimpanan yang ada di shop
     * & sellable, satu-satu lewat sell(..., silent=true), lalu kirim SATU pesan rangkuman
     * (bukan 1 pesan per material -- bakal nge-spam chat kalau player punya banyak jenis item).
     * Tiap material tetap tercatat terpisah di RefundManager, jadi masing-masing tetap bisa
     * di-refund sendiri-sendiri lewat /sellrefund.
     */
    public SellAllSummary sellAll(Player player) {
        int materials = 0, totalItems = 0;
        double totalPrice = 0;

        for (Material material : distinctStorageMaterials(player)) {
            ShopItem item = bestSellableFor(material);
            if (item == null) continue;

            int qty = countSellable(player, material) / item.getAmount();
            if (qty <= 0) continue;

            int totalAmount = item.getAmount() * qty;
            double price = sellTotal(item, qty);

            Result result = sell(player, item, qty, true);
            if (result == Result.SUCCESS) {
                materials++;
                totalItems += totalAmount;
                totalPrice += price;
            }
            // hasil selain SUCCESS di titik ini praktis gak mungkin (baru aja dihitung qty-nya),
            // kecuali NO_ECONOMY/ECONOMY_ERROR -- kalau itu terjadi, lewatin aja material ini,
            // material berikutnya tetap dicoba (satu gangguan gak nge-gagalin semuanya).
        }

        int protectedCount = 0;
        if (isProtectionEnabled()) {
            for (Material material : distinctStorageMaterials(player)) {
                protectedCount += InventoryUtils.countProtected(player.getInventory(), material);
            }
        }

        if (materials > 0) {
            Map<String, String> ph = new HashMap<>();
            ph.put("%materials%", String.valueOf(materials));
            ph.put("%amount%", String.valueOf(totalItems));
            ph.put("%price%", formatMoney(totalPrice));
            messages.send(player, "sell-all-success", ph);

            if (protectedCount > 0) {
                Map<String, String> ph2 = new HashMap<>();
                ph2.put("%protected%", String.valueOf(protectedCount));
                messages.send(player, "sell-all-protected-notice", ph2);
            }
            if (plugin.getRefundManager().isEnabled()) {
                Map<String, String> ph3 = new HashMap<>();
                ph3.put("%window%", plugin.getRefundManager().windowText());
                messages.send(player, "refund-hint", ph3);
            }
        } else {
            messages.send(player, "sell-all-empty");
        }

        return new SellAllSummary(materials, totalItems, totalPrice, protectedCount);
    }

    /**
     * Kirim pesan error yang sesuai buat hasil buy/sell yang GAGAL (sekaligus isi placeholder
     * %item%, %price%, dll yang dulu gak pernah keganti dan muncul mentah di chat).
     * `qty` = jumlah transaksi yang dicoba (kelipatan item.getAmount()).
     */
    public void reportFailure(Player player, ShopItem item, int qty, Result result) {
        if (result == Result.SUCCESS) return;

        Map<String, String> ph = new HashMap<>();
        ph.put("%item%", item.getDisplayName());
        ph.put("%amount%", String.valueOf(item.getAmount() * qty));

        switch (result) {
            case NOT_ENOUGH_MONEY -> {
                ph.put("%price%", formatMoney(buyTotal(item, qty)));
                messages.send(player, "not-enough-money", ph);
            }
            case INVENTORY_FULL -> messages.send(player, "inventory-full", ph);
            case NOT_ENOUGH_ITEMS -> messages.send(player, "no-items-to-sell", ph);
            case PROTECTED_ITEMS -> {
                ph.put("%protected%", String.valueOf(InventoryUtils.countProtected(player.getInventory(), item.getMaterial())));
                ph.put("%sellable%", String.valueOf(countSellable(player, item.getMaterial())));
                messages.send(player, "sell-protected", ph);
            }
            case NOT_BUYABLE -> messages.send(player, "cannot-buy", ph);
            case NOT_SELLABLE -> messages.send(player, "cannot-sell", ph);
            case NO_ECONOMY -> messages.send(player, "economy-missing", ph);
            case ECONOMY_ERROR -> messages.send(player, "economy-error", ph);
            default -> { /* SUCCESS udah di-return di atas */ }
        }
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
    }

    private double buyTotal(ShopItem item, int qty) {
        double multiplier = plugin.getConfig().getDouble("economy.buy-multiplier", 1.0);
        return item.getBuyPrice() * qty * multiplier;
    }

    public String formatMoney(double amount) {
        if (amount == Math.floor(amount)) {
            return String.format("%,.0f", amount);
        }
        return String.format("%,.2f", amount);
    }
}
