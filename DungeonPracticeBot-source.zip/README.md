# DungeonPracticeBot

Plugin practice bot PvP standalone, terinspirasi dari PracticeBotPlus tapi dibangun dari nol,
plus fitur tambahan: **Dungeon Bot** — bot spesial yang cuma bisa di-spawn di dungeon, punya
titik spawn sendiri, dan drop item random pas dikalahkan.

## Fitur

- `/bot spawn` — spawn bot practice biasa (zombie hostile, ngejar & nyerang player)
- `/bot remove` — hapus bot kamu
- `/bot difficulty <easy|medium|hard>` — atur health & damage multiplier bot
- `/bot settings` — lihat setting bot kamu saat ini
- `/bot spawn dungeon` — spawn Dungeon Guardian di titik spawn dungeon (permission `dpbot.dungeon.spawn`)
- `/bot setspawn dungeon` — set titik spawn dungeon bot ke posisi kamu sekarang (default OP-only, `dpbot.dungeon.setspawn`)
- `/bot dungeon` — buka **GUI setting dungeon bot** (default OP-only, `dpbot.dungeon.settings`):
  - HP, Knockback Immune (on/off), Fire Immune (on/off), Crit Chance (%), Totem Charges
    (berapa kali bot bisa "nyelametin diri" kayak Totem of Undying sebelum beneran mati),
    Leash Radius (kalau bot lewat radius ini dari spawn-nya, auto teleport balik), Respawn Delay
  - Tombol **Edit Gear** buka GUI kedua: drag item dari inventory kamu ke slot helmet/chest/legs/boots/mainhand/offhand,
    lalu klik **Save & Back**. Karena disimpen sebagai ItemStack asli, enchant/NBT apapun kebawa utuh.
- Dungeon bot drop item random (diatur di `config.yml` → `dungeon-bot.loot-table`, atau lewat gear/loot config manual) pas mati beneran, lalu auto-respawn di titik spawnnya sendiri setelah delay
- **Crystal PvP** — bot (normal & dungeon) bisa naro obsidian + end crystal deket target terus detonasi, kayak CPvP player beneran. Gak butuh inventory beneran (scripted ability, cooldown-based), block yang ditaro otomatis dibalikin ke semula. Toggle per-dungeon-bot ada di GUI (`/bot dungeon`), tuning global (cooldown, power, range, dll) di `config.yml` → `crystal-pvp`
- Attack-cooldown debounce di combat listener — mencegah bot "tap-tap" / double-hit gara-gara lag tick, jadi hit-nya konsisten kayak player beneran mukul
- Auto-respawn juga jalan buat bot biasa (opsional, di config)
- Folia-safe: pakai region scheduler / entity scheduler (termasuk leash-radius checker), bukan `Bukkit.getScheduler()` biasa

## Build (lewat GitHub Actions, karena kamu kerja dari HP)

1. Push folder ini ke repo GitHub baru.
2. Workflow `.github/workflows/build.yml` otomatis jalan tiap push ke `main` (Java 21 + Maven).
3. Ambil hasil `.jar` dari tab **Actions** → artifact `DungeonPracticeBot`.
4. Taruh jar di folder `plugins/` server Folia kamu, restart.

## Konfigurasi Dungeon Bot

Edit `config.yml` bagian `dungeon-bot`:

```yaml
dungeon-bot:
  spawn:
    world: world
    x: 0.5
    y: 64.0
    z: 0.5
  loot-table:
    - material: DIAMOND
      min-amount: 1
      max-amount: 3
      chance: 0.35
```

Atau lebih gampang: berdiri di titik yang mau dijadikan spawn dungeon, jalankan `/bot setspawn dungeon`.

## Catatan

- Bot pakai entity Zombie vanilla dengan AI hostile bawaan (otomatis ngejar & nyerang player terdekat) —
  ini paling stabil buat Folia dibanding custom pathfinding manual. Plugin originalnya (yang kamu kasih contoh)
  juga begini di balik layar — "skin" di situ artinya tampilan gear/armor, bukan skin wajah player asli
  (itu butuh Citizens/fake-player NPC, jauh lebih ribet & rawan putus tiap update Minecraft).
- `single-instance: true` di config bikin cuma ada 1 Dungeon Guardian hidup sekaligus di server.
- Attack timing dungeon bot & bot biasa di-debounce manual (bukan cuma ngandelin cooldown vanilla zombie),
  jadi hit-nya gak dobel/nge-tap kalau server lagi rada lag.
- Kalau nanti mau nambah tipe mob lain buat dungeon bot (misal Vindicator/Pillager biar keliatan beda),
  tinggal ganti `EntityType.ZOMBIE` di `BotManager.spawnDungeonBot()`.
