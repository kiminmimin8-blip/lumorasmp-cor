# DungeonPracticeBot

Plugin PvP practice bot standalone. Semua bot itu sama - gak ada lagi bedanya "dungeon bot"
vs "bot biasa". Bikin sampai **50 bot bernama**, masing-masing punya fitur lengkap sendiri:
gear+enchant custom (bebas di atas vanilla max), HP, totem saves, crystal/anchor PvP,
combat AI (strafe/w-tap/block/crit/swap), mode CPvP/SPvP.

## Konsep dasar

- **`/bot create <nama>`** — bikin definisi bot baru (max 30 total di server)
- **`/bot spawn <nama>`** — spawn sekali di posisi kamu berdiri. Kalau bot ini mati, dia
  hilang gitu aja — harus `/bot spawn <nama>` lagi manual.
- **`/bot setspawn <nama>`** — simpen posisi kamu sekarang jadi **rumah tetap** bot itu.
  Begitu di-set, bot auto-respawn di situ tiap kali mati (default 30 detik).
- **`/bot edit`** — GUI daftar semua bot yang udah dibuat. Klik satu → masuk ke GUI setting
  bot itu (HP, totem, crystal/anchor toggle, gear, dll).

## Commands lengkap

- `/bot create <nama>` / `/bot delete <nama>` / `/bot list`
- `/bot spawn <nama>` (admin-only) / `/bot remove <nama>` (remove = hapus dari world, config tetep ada)
- `/bot setspawn <nama>` — rumah tetap + auto-respawn
- `/bot edit` — GUI daftar bot → GUI setting per bot
- `/bot difficulty <nama> <easy|medium|hard>` — atur damage/attack-speed/reach/block-chance
- `/bot enchant <nama> <slot> <enchant> <level>` — enchant custom lewat command (bisa juga lewat GUI)
- `/bot rename <lama> <baru>` — ganti nama bot
- `/bot egg <nama> [player]` — kasih item "Bot Egg" ke player, klik kanan ke tanah buat spawn bot itu
  tanpa butuh permission command (cocok buat dikasih ke member)
- `/bot kit list|create|delete|gui|apply <kit> <bot>` — preset gear yang bisa dipasang ke bot manapun

## GUI setting per bot (`/bot edit` → klik bot)

- **HP**, **Knockback Immune**, **Fire Immune**, **Crit Chance**
- **Totem Charges** — klik = +10, mentok di 150, kalau udah 150 diklik lagi balik ke 10
- **Leash Radius** — kalau bot lewat radius ini dari rumahnya (butuh fixed spawn), auto teleport balik
- **Respawn Delay** — cuma berlaku kalau bot ini punya fixed spawn
- **Crystal PvP** / **Anchor PvP** — toggle on/off masing-masing
- **Mode (SPvP/CPvP)** — tombol cepat: SPvP matiin crystal+anchor sekaligus (murni melee),
  CPvP nyalain dua-duanya (playstyle explosive)
- **Difficulty** — klik buat cycle Easy → Medium → Hard
- **Delete Bot** — shift-click buat beneran hapus (config-nya ikut kehapus)
- **Edit Gear** → sub-GUI: helmet/chest/legs/boots/mainhand/offhand + slot **Secondary Weapon**
  (buat combo-swap abis critical hit). **Klik kanan** item gear yang udah ke-taro buat buka
  **pemilih enchant**: klik enchant yang mau dipasang, left-click +1 level, right-click -1,
  shift-click ±10 — bebas di atas batas vanilla (Protection 10, Sharpness 20, dll)

## Fitur combat

- **Strafe + W-tap** — bot gak jalan lurus doang, muter-muter & sesekali mundur-maju biar gak gampang ditebak. Cek ulang posisi tiap 2 tick (dipercepat dari 4) biar lebih lincah
- **Combo system** — bot ngerangkai 2-4 hit cepat (burst) baru jeda recovery lebih lama, terus mulai combo baru dengan panjang acak lagi. Bukan hit rata-rata terus kayak sebelumnya — kerasa kayak combo beneran, bukan poke satu-satu
- **Block/parry** — kadang ngurangin damage masuk (fungsional, bukan animasi shield beneran)
- **Crit + weapon swap** — pas crit, swap ke secondary weapon sebentar terus balik
- **Hit timing jitter** — attack cooldown di-random dikit tiap swing + di-debounce biar gak "tap-tap"
- **Crystal PvP** — naro obsidian+crystal deket target, detonasi. Block yang ditaro otomatis dibalikin
- **Anchor PvP** — sama kayak crystal tapi pake Respawn Anchor, blast lebih gede, cooldown lebih lama
- **Totem saves** — bot bisa "nyelametin diri" dari kematian sebanyak totem charge yang di-set,
  offhand-nya keliatan megang stack totem yang beneran berkurang tiap dipake
- Loot table (item yang di-drop pas bot mati) di-share semua bot, diatur di `config.yml` → `loot-table`

## Build (lewat GitHub Actions)

1. Push folder ini ke repo GitHub.
2. Workflow `.github/workflows/build.yml` otomatis build tiap push ke `main` (Java 21 + Maven).
3. Ambil `.jar` dari tab **Actions** → artifact `DungeonPracticeBot`.
4. Taruh di `plugins/` server Folia, restart.

## Penyimpanan data

- `config.yml` — tuning global (combat-ai, crystal-pvp, anchor-pvp, difficulty presets, loot-table)
- `bots.yml` — semua definisi bot (auto-generate, jangan diedit manual pas server jalan)
- `kits.yml` — semua kit gear

## Catatan

- Bot pakai entity Zombie vanilla dengan AI hostile bawaan + controller custom buat strafe/w-tap/block.
  Paling stabil buat Folia dibanding custom pathfinding manual.
- "Skin" bot itu gear/armor, bukan skin wajah player asli — itu butuh Citizens/fake-player NPC
  yang jauh lebih ribet & rawan putus tiap update Minecraft.
