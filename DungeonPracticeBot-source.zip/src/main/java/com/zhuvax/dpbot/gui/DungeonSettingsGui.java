package com.zhuvax.dpbot.gui;

import com.zhuvax.dpbot.bot.DungeonSettings;
import com.zhuvax.dpbot.config.ConfigManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class DungeonSettingsGui {

    public static final int SLOT_HP = 10;
    public static final int SLOT_KNOCKBACK = 11;
    public static final int SLOT_FIRE = 12;
    public static final int SLOT_CRIT = 13;
    public static final int SLOT_TOTEM = 14;
    public static final int SLOT_LEASH = 15;
    public static final int SLOT_RESPAWN = 16;
    public static final int SLOT_CRYSTAL = 17;
    public static final int SLOT_GEAR = 22;
    public static final int SLOT_CLOSE = 26;

    public static Inventory open(Player player, ConfigManager cfg) {
        GuiHolders.SettingsHolder holder = new GuiHolders.SettingsHolder();
        Inventory inv = org.bukkit.Bukkit.createInventory(holder, 27, "§4§lDungeon Bot Settings");
        holder.setInventory(inv);
        render(inv, cfg.loadDungeonSettings());
        player.openInventory(inv);
        return inv;
    }

    public static void render(Inventory inv, DungeonSettings s) {
        inv.clear();
        inv.setItem(SLOT_HP, item(Material.REDSTONE_BLOCK, "§cHealth: §f" + s.getHealth(),
                "§7Left-click: +2  Right-click: -2"));
        inv.setItem(SLOT_KNOCKBACK, item(s.isKnockbackImmune() ? Material.SHIELD : Material.FEATHER,
                "§bKnockback Immune: " + onOff(s.isKnockbackImmune()),
                "§7Click untuk toggle"));
        inv.setItem(SLOT_FIRE, item(s.isFireImmune() ? Material.FIRE_CHARGE : Material.WATER_BUCKET,
                "§6Fire Immune: " + onOff(s.isFireImmune()),
                "§7Click untuk toggle"));
        inv.setItem(SLOT_CRIT, item(Material.DIAMOND_SWORD, "§dCrit Chance: §f" + Math.round(s.getCritChance() * 100) + "%",
                "§7Left-click: +5%  Right-click: -5%"));
        inv.setItem(SLOT_TOTEM, item(Material.TOTEM_OF_UNDYING, "§eTotem Charges: §f" + s.getTotemCount() + " §7(max 100)",
                "§7Berapa kali bot bisa 'nyelametin diri' dari kematian",
                "§7Left-click: +1  Right-click: -1",
                "§7Shift+click: ±10"));
        inv.setItem(SLOT_LEASH, item(Material.COMPASS, "§aLeash Radius: §f" + Math.round(s.getLeashRadius()) + " block",
                "§7Kalau bot lewat radius ini, balik ke spawn",
                "§7Left-click: +10  Right-click: -10"));
        inv.setItem(SLOT_RESPAWN, item(Material.CLOCK, "§9Respawn Delay: §f" + (s.getRespawnDelayTicks() / 20) + "s",
                "§7Left-click: +5s  Right-click: -5s"));
        inv.setItem(SLOT_CRYSTAL, item(s.isCrystalPvpEnabled() ? Material.END_CRYSTAL : Material.OBSIDIAN,
                "§dCrystal PvP: " + onOff(s.isCrystalPvpEnabled()),
                "§7Bot bisa naro obsidian+crystal & detonasi",
                "§7Click untuk toggle"));
        inv.setItem(SLOT_GEAR, item(Material.NETHERITE_CHESTPLATE, "§5Edit Gear",
                "§7Atur helmet/chest/legs/boots/hand/offhand",
                "§7(enchant kebawa apa adanya)"));
        inv.setItem(SLOT_CLOSE, item(Material.BARRIER, "§cClose"));
    }

    private static String onOff(boolean b) {
        return b ? "§aON" : "§cOFF";
    }

    private static ItemStack item(Material mat, String name, String... lore) {
        ItemStack stack = new ItemStack(mat);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(name);
        if (lore.length > 0) {
            meta.setLore(List.of(lore));
        }
        stack.setItemMeta(meta);
        return stack;
    }
}
