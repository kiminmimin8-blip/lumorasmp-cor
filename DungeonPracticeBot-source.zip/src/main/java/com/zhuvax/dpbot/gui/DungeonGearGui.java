package com.zhuvax.dpbot.gui;

import com.zhuvax.dpbot.bot.DungeonSettings;
import com.zhuvax.dpbot.config.ConfigManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.Map;

public class DungeonGearGui {

    public static final int SLOT_HELMET = 10;
    public static final int SLOT_CHEST = 11;
    public static final int SLOT_LEGS = 12;
    public static final int SLOT_BOOTS = 13;
    public static final int SLOT_MAINHAND = 15;
    public static final int SLOT_OFFHAND = 16;
    public static final int SLOT_SAVE = 22;
    public static final int SLOT_BACK = 26;

    public static final Map<Integer, EquipmentSlot> EDITABLE_SLOTS = Map.of(
            SLOT_HELMET, EquipmentSlot.HEAD,
            SLOT_CHEST, EquipmentSlot.CHEST,
            SLOT_LEGS, EquipmentSlot.LEGS,
            SLOT_BOOTS, EquipmentSlot.FEET,
            SLOT_MAINHAND, EquipmentSlot.HAND,
            SLOT_OFFHAND, EquipmentSlot.OFF_HAND
    );

    public static Inventory open(Player player, ConfigManager cfg) {
        GuiHolders.GearHolder holder = new GuiHolders.GearHolder();
        Inventory inv = org.bukkit.Bukkit.createInventory(holder, 27, "§5§lDungeon Bot Gear");
        holder.setInventory(inv);

        DungeonSettings settings = cfg.loadDungeonSettings();
        for (Map.Entry<Integer, EquipmentSlot> e : EDITABLE_SLOTS.entrySet()) {
            ItemStack current = settings.getGear(e.getValue());
            if (current != null) {
                inv.setItem(e.getKey(), current.clone());
            }
        }
        inv.setItem(SLOT_SAVE, deco(Material.EMERALD_BLOCK, "§aSave & Back"));
        inv.setItem(SLOT_BACK, deco(Material.ARROW, "§7Back (tanpa save)"));

        for (int i = 0; i < 27; i++) {
            if (!EDITABLE_SLOTS.containsKey(i) && i != SLOT_SAVE && i != SLOT_BACK) {
                inv.setItem(i, deco(Material.GRAY_STAINED_GLASS_PANE, " "));
            }
        }

        player.openInventory(inv);
        return inv;
    }

    public static void saveFrom(Inventory inv, ConfigManager cfg) {
        DungeonSettings settings = cfg.loadDungeonSettings();
        for (Map.Entry<Integer, EquipmentSlot> e : EDITABLE_SLOTS.entrySet()) {
            ItemStack item = inv.getItem(e.getKey());
            settings.setGear(e.getValue(), item);
        }
        cfg.saveDungeonSettings(settings);
    }

    private static ItemStack deco(Material mat, String name) {
        ItemStack stack = new ItemStack(mat);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(List.of());
        stack.setItemMeta(meta);
        return stack;
    }
}
