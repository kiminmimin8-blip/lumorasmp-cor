package com.zhuvax.dpbot.config;

import com.zhuvax.dpbot.bot.DungeonSettings;
import com.zhuvax.dpbot.difficulty.Difficulty;
import com.zhuvax.dpbot.loot.LootEntry;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ConfigManager {

    private final JavaPlugin plugin;
    private FileConfiguration config;
    private FileConfiguration messages;
    private File messagesFile;

    public ConfigManager(JavaPlugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        config = plugin.getConfig();

        messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        if (!messagesFile.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        messages = YamlConfiguration.loadConfiguration(messagesFile);
    }

    public FileConfiguration raw() {
        return config;
    }

    // ---------------- Messages ----------------

    public String msg(String key) {
        String prefix = messages.getString("prefix", "");
        return prefix + messages.getString(key, key);
    }

    public String msg(String key, String placeholder, String value) {
        return msg(key).replace("{" + placeholder + "}", value);
    }

    // ---------------- Combat AI (strafe / w-tap / block / jitter) ----------------

    public boolean combatAiEnabled() {
        return config.getBoolean("combat-ai.enabled", true);
    }

    public int strafeSwitchMinTicks() {
        return config.getInt("combat-ai.strafe-switch-min-ticks", 15);
    }

    public int strafeSwitchMaxTicks() {
        return config.getInt("combat-ai.strafe-switch-max-ticks", 35);
    }

    public double strafeDistance() {
        return config.getDouble("combat-ai.strafe-distance", 2.2);
    }

    public int wtapMinTicks() {
        return config.getInt("combat-ai.wtap-min-ticks", 20);
    }

    public int wtapMaxTicks() {
        return config.getInt("combat-ai.wtap-max-ticks", 60);
    }

    public int wtapDurationTicks() {
        return config.getInt("combat-ai.wtap-duration-ticks", 4);
    }

    public double engageRange() {
        return config.getDouble("combat-ai.engage-range", 8.0);
    }

    public double blockDamageReduction() {
        return config.getDouble("combat-ai.block-damage-reduction", 0.55);
    }

    public int blockDurationTicks() {
        return config.getInt("combat-ai.block-duration-ticks", 5);
    }

    public int blockRerollTicks() {
        return config.getInt("combat-ai.block-reroll-ticks", 8);
    }

    public double hitJitterFraction() {
        return config.getDouble("combat-ai.hit-jitter-fraction", 0.3);
    }

    // ---------------- Crystal PvP ----------------

    public boolean crystalPvpEnabled() {
        return config.getBoolean("crystal-pvp.enabled", true);
    }

    public long crystalCooldownTicks() {
        return config.getLong("crystal-pvp.cooldown-ticks", 60);
    }

    public double crystalMinRange() {
        return config.getDouble("crystal-pvp.min-range", 1.2);
    }

    public double crystalMaxRange() {
        return config.getDouble("crystal-pvp.max-range", 5.0);
    }

    public double crystalAttemptChance() {
        return config.getDouble("crystal-pvp.attempt-chance", 0.35);
    }

    public int crystalDetonateDelayMinTicks() {
        return config.getInt("crystal-pvp.detonate-delay-min-ticks", 4);
    }

    public int crystalDetonateDelayMaxTicks() {
        return config.getInt("crystal-pvp.detonate-delay-max-ticks", 10);
    }

    public float crystalExplosionPower() {
        return (float) config.getDouble("crystal-pvp.explosion-power", 6.0);
    }

    public boolean crystalBreakBlocks() {
        return config.getBoolean("crystal-pvp.break-blocks", false);
    }

    public long crystalRestoreBlockDelayTicks() {
        return config.getLong("crystal-pvp.restore-block-delay-ticks", 40);
    }

    public double crystalSelfDamageReduction() {
        return config.getDouble("crystal-pvp.self-damage-reduction", 0.4);
    }

    // ---------------- Bot defaults ----------------

    public String nameFormat() {
        return config.getString("bot.name-format", "&6{player}'s Bot");
    }

    public int attackCooldownTicks() {
        return config.getInt("bot.attack-cooldown-ticks", 10);
    }

    public boolean fallDamage() {
        return config.getBoolean("bot.fall-damage", false);
    }

    public Difficulty startingDifficulty() {
        return Difficulty.byName(config.getString("bot.starting-difficulty", "MEDIUM"));
    }

    public boolean autoRespawnEnabled() {
        return config.getBoolean("bot.auto-respawn.enabled", true);
    }

    public long autoRespawnDelay() {
        return config.getLong("bot.auto-respawn.delay-ticks", 60);
    }

    public int maxBotsPerPlayer() {
        return config.getInt("limits.max-bots-per-player", 1);
    }

    public Difficulty loadDifficulty(String key) {
        String path = "difficulty." + key.toUpperCase();
        if (!config.isConfigurationSection(path)) {
            return Difficulty.byName(key);
        }
        return new Difficulty(
                key.toUpperCase(),
                config.getDouble(path + ".health", 20.0),
                config.getDouble(path + ".damage-multiplier", 1.0),
                config.getDouble(path + ".reach", 3.5),
                config.getInt(path + ".attack-speed-ticks", 12),
                config.getDouble(path + ".block-chance", 0.1)
        );
    }

    // ---------------- Dungeon bot ----------------

    public String dungeonNameFormat() {
        return config.getString("dungeon-bot.name-format", "&c&lDungeon Guardian");
    }

    public Difficulty dungeonDifficulty() {
        return loadDifficulty(config.getString("dungeon-bot.difficulty", "HARD"));
    }

    public boolean dungeonAutoRespawnEnabled() {
        return config.getBoolean("dungeon-bot.auto-respawn.enabled", true);
    }

    public long dungeonAutoRespawnDelay() {
        return config.getLong("dungeon-bot.auto-respawn.delay-ticks", 100);
    }

    public boolean dungeonSingleInstance() {
        return config.getBoolean("dungeon-bot.single-instance", true);
    }

    public Location dungeonSpawn() {
        String worldName = config.getString("dungeon-bot.spawn.world");
        if (worldName == null) return null;
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        double x = config.getDouble("dungeon-bot.spawn.x");
        double y = config.getDouble("dungeon-bot.spawn.y");
        double z = config.getDouble("dungeon-bot.spawn.z");
        float yaw = (float) config.getDouble("dungeon-bot.spawn.yaw", 0.0);
        return new Location(world, x, y, z, yaw, 0f);
    }

    public void setDungeonSpawn(Location location) {
        config.set("dungeon-bot.spawn.world", location.getWorld().getName());
        config.set("dungeon-bot.spawn.x", location.getX());
        config.set("dungeon-bot.spawn.y", location.getY());
        config.set("dungeon-bot.spawn.z", location.getZ());
        config.set("dungeon-bot.spawn.yaw", (double) location.getYaw());
        plugin.saveConfig();
    }

    public List<LootEntry> dungeonLootTable() {
        List<LootEntry> entries = new ArrayList<>();
        List<Map<?, ?>> rawList = config.getMapList("dungeon-bot.loot-table");
        for (Map<?, ?> row : rawList) {
            try {
                Material material = Material.valueOf(String.valueOf(row.get("material")).toUpperCase());
                int min = row.get("min-amount") != null ? ((Number) row.get("min-amount")).intValue() : 1;
                int max = row.get("max-amount") != null ? ((Number) row.get("max-amount")).intValue() : min;
                double chance = row.get("chance") != null ? ((Number) row.get("chance")).doubleValue() : 1.0;
                entries.add(new LootEntry(material, min, max, chance));
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Item loot tidak valid di config dungeon-bot.loot-table: " + row);
            }
        }
        return entries;
    }

    // ---------------- Dungeon bot: combat/gear tunables ----------------

    public DungeonSettings loadDungeonSettings() {
        DungeonSettings s = new DungeonSettings();
        s.setHealth(config.getDouble("dungeon-bot.health", 26.0));
        s.setKnockbackImmune(config.getBoolean("dungeon-bot.knockback-immune", false));
        s.setFireImmune(config.getBoolean("dungeon-bot.fire-immune", false));
        s.setCritChance(config.getDouble("dungeon-bot.crit-chance", 0.15));
        s.setTotemCount(config.getInt("dungeon-bot.totem-count", 0));
        s.setLeashRadius(config.getDouble("dungeon-bot.leash-radius", 250.0));
        s.setRespawnDelayTicks(config.getLong("dungeon-bot.auto-respawn.delay-ticks", 400));
        s.setCrystalPvpEnabled(config.getBoolean("dungeon-bot.crystal-pvp-enabled", true));

        for (EquipmentSlot slot : EquipmentSlot.values()) {
            String path = "dungeon-bot.gear." + slot.name();
            if (config.contains(path)) {
                ItemStack item = config.getItemStack(path);
                if (item != null) {
                    s.setGear(slot, item);
                }
            }
        }
        return s;
    }

    public void saveDungeonSettings(DungeonSettings s) {
        config.set("dungeon-bot.health", s.getHealth());
        config.set("dungeon-bot.knockback-immune", s.isKnockbackImmune());
        config.set("dungeon-bot.fire-immune", s.isFireImmune());
        config.set("dungeon-bot.crit-chance", s.getCritChance());
        config.set("dungeon-bot.totem-count", s.getTotemCount());
        config.set("dungeon-bot.leash-radius", s.getLeashRadius());
        config.set("dungeon-bot.auto-respawn.delay-ticks", s.getRespawnDelayTicks());
        config.set("dungeon-bot.crystal-pvp-enabled", s.isCrystalPvpEnabled());

        for (EquipmentSlot slot : EquipmentSlot.values()) {
            String path = "dungeon-bot.gear." + slot.name();
            ItemStack item = s.getGear(slot);
            if (item != null) {
                config.set(path, item);
            } else {
                config.set(path, null);
            }
        }
        plugin.saveConfig();
    }
}
