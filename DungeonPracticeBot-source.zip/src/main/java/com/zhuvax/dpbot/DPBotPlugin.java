package com.zhuvax.dpbot;

import com.zhuvax.dpbot.bot.BotManager;
import com.zhuvax.dpbot.commands.BotCommand;
import com.zhuvax.dpbot.config.ConfigManager;
import com.zhuvax.dpbot.listeners.BlockListener;
import com.zhuvax.dpbot.listeners.BotDeathListener;
import com.zhuvax.dpbot.listeners.CombatListener;
import com.zhuvax.dpbot.listeners.CrystalDamageListener;
import com.zhuvax.dpbot.listeners.FireImmuneListener;
import com.zhuvax.dpbot.listeners.GuiListener;
import com.zhuvax.dpbot.listeners.TotemListener;
import org.bukkit.plugin.java.JavaPlugin;

public class DPBotPlugin extends JavaPlugin {

    private ConfigManager configManager;
    private BotManager botManager;

    @Override
    public void onEnable() {
        this.configManager = new ConfigManager(this);
        this.botManager = new BotManager(this, configManager);

        BotCommand botCommand = new BotCommand(botManager, configManager);
        getCommand("bot").setExecutor(botCommand);
        getCommand("bot").setTabCompleter(botCommand);

        getServer().getPluginManager().registerEvents(new CombatListener(botManager, configManager), this);
        getServer().getPluginManager().registerEvents(new CrystalDamageListener(botManager, configManager), this);
        getServer().getPluginManager().registerEvents(new BotDeathListener(this, botManager, configManager), this);
        getServer().getPluginManager().registerEvents(new FireImmuneListener(botManager, configManager), this);
        getServer().getPluginManager().registerEvents(new TotemListener(botManager), this);
        getServer().getPluginManager().registerEvents(new BlockListener(botManager, configManager), this);
        getServer().getPluginManager().registerEvents(new GuiListener(configManager), this);

        getLogger().info("DungeonPracticeBot aktif. Folia terdeteksi: "
                + com.zhuvax.dpbot.util.SchedulerUtil.isFolia());
    }

    @Override
    public void onDisable() {
        if (botManager != null) {
            botManager.removeAll();
        }
    }

    public BotManager getBotManager() {
        return botManager;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }
}
