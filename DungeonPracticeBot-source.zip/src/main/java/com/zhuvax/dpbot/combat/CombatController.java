package com.zhuvax.dpbot.combat;

import com.zhuvax.dpbot.bot.BotType;
import com.zhuvax.dpbot.bot.PracticeBot;
import com.zhuvax.dpbot.config.ConfigManager;
import com.zhuvax.dpbot.util.SchedulerUtil;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Drives bot movement during a fight: circle-strafing, periodic W-tap
 * (brief retreat-then-reapproach spacing) and block/parry windows.
 * <p>
 * Vanilla mob AI (setAI stays true) still supplies pathing when no player
 * is nearby and still supplies the actual attack swing/damage event once in
 * range - this controller only takes over positioning once a fight starts,
 * re-issuing pathfinder targets often enough to win out over the default
 * straight-line chase.
 */
public class CombatController {

    private final JavaPlugin plugin;
    private final ConfigManager cfg;

    private final Map<UUID, BotCombatState> states = new HashMap<>();
    private final Map<UUID, SchedulerUtil.TaskHandle> tasks = new HashMap<>();

    public CombatController(JavaPlugin plugin, ConfigManager cfg) {
        this.plugin = plugin;
        this.cfg = cfg;
    }

    public void attach(PracticeBot bot) {
        if (!cfg.combatAiEnabled()) return;
        LivingEntity entity = bot.getEntity();
        UUID id = entity.getUniqueId();
        states.put(id, new BotCombatState());
        SchedulerUtil.TaskHandle handle = SchedulerUtil.runOnEntityRepeating(plugin, entity, 10L, 4L, () -> tick(bot));
        tasks.put(id, handle);
    }

    public void detach(UUID id) {
        SchedulerUtil.TaskHandle handle = tasks.remove(id);
        if (handle != null) handle.cancel();
        states.remove(id);
    }

    public boolean isBlocking(UUID id) {
        BotCombatState state = states.get(id);
        return state != null && state.blocking && System.currentTimeMillis() < state.blockingUntilMillis;
    }

    private void tick(PracticeBot bot) {
        LivingEntity entity = bot.getEntity();
        if (entity == null || entity.isDead() || !entity.isValid()) return;
        UUID id = entity.getUniqueId();
        BotCombatState state = states.get(id);
        if (state == null) return;
        if (!(entity instanceof Mob mob)) return;

        Player target = acquireTarget(mob, entity);
        long now = System.currentTimeMillis();

        if (target == null) {
            state.blocking = false;
            return;
        }

        double distance = entity.getLocation().distance(target.getLocation());
        double reach = bot.getDifficulty().getReach();
        double engageRange = cfg.engageRange();

        // Block/parry roll, independent of movement
        if (now >= state.nextBlockRollMillis) {
            state.nextBlockRollMillis = now + cfg.blockRerollTicks() * 50L;
            if (!state.blocking && distance <= reach + 1.5) {
                if (ThreadLocalRandom.current().nextDouble() < bot.getDifficulty().getBlockChance()) {
                    state.blocking = true;
                    state.blockingUntilMillis = now + cfg.blockDurationTicks() * 50L;
                }
            }
        }
        if (state.blocking && now >= state.blockingUntilMillis) {
            state.blocking = false;
        }

        // Crystal PvP: independent of melee engage range, checked first since
        // it can trigger from slightly further out than melee strafing does.
        if (cfg.crystalPvpEnabled() && crystalAllowedFor(bot) && now >= state.nextCrystalMillis) {
            if (distance >= cfg.crystalMinRange() && distance <= cfg.crystalMaxRange()) {
                if (ThreadLocalRandom.current().nextDouble() < cfg.crystalAttemptChance()) {
                    boolean used = CrystalAbility.tryPlaceAndDetonate(plugin, cfg, entity, target);
                    if (used) {
                        state.nextCrystalMillis = now + cfg.crystalCooldownTicks() * 50L;
                    }
                }
            }
        }

        if (distance > engageRange) {
            return; // too far, let vanilla pathing chase it down
        }

        // Strafe direction toggle
        if (now >= state.nextStrafeSwitchMillis) {
            state.strafeDir *= -1;
            state.nextStrafeSwitchMillis = now + randomTicks(cfg.strafeSwitchMinTicks(), cfg.strafeSwitchMaxTicks());
        }

        // W-tap window toggle
        if (state.wtapping) {
            if (now >= state.wtapUntilMillis) {
                state.wtapping = false;
                state.nextWtapMillis = now + randomTicks(cfg.wtapMinTicks(), cfg.wtapMaxTicks());
            }
        } else if (now >= state.nextWtapMillis) {
            state.wtapping = true;
            state.wtapUntilMillis = now + cfg.wtapDurationTicks() * 50L;
        }

        Location desired = computeDesiredPoint(entity, target, reach, state);
        if (desired != null && mob.getPathfinder() != null) {
            double speed = state.wtapping ? 1.15 : 1.0;
            mob.getPathfinder().moveTo(desired, speed);
        }
    }

    private boolean crystalAllowedFor(PracticeBot bot) {
        if (bot.getType() == BotType.DUNGEON) {
            return cfg.loadDungeonSettings().isCrystalPvpEnabled();
        }
        return true;
    }

    private Player acquireTarget(Mob mob, LivingEntity entity) {
        LivingEntity current = mob.getTarget();
        if (current instanceof Player p && p.isOnline() && !p.isDead()) {
            return p;
        }
        List<Player> nearby = entity.getLocation().getNearbyPlayers(cfg.engageRange());
        Player closest = null;
        double best = Double.MAX_VALUE;
        for (Player p : nearby) {
            if (p.getGameMode() == org.bukkit.GameMode.SPECTATOR || p.getGameMode() == org.bukkit.GameMode.CREATIVE) continue;
            double d = p.getLocation().distanceSquared(entity.getLocation());
            if (d < best) {
                best = d;
                closest = p;
            }
        }
        if (closest != null) {
            mob.setTarget(closest);
        }
        return closest;
    }

    private Location computeDesiredPoint(LivingEntity entity, Player target, double reach, BotCombatState state) {
        Location botLoc = entity.getLocation();
        Location targetLoc = target.getLocation();
        if (botLoc.getWorld() == null || !botLoc.getWorld().equals(targetLoc.getWorld())) return null;

        Vector dirToBot = botLoc.toVector().subtract(targetLoc.toVector());
        dirToBot.setY(0);
        if (dirToBot.lengthSquared() < 0.0001) {
            dirToBot = new Vector(1, 0, 0);
        } else {
            dirToBot.normalize();
        }

        Vector perpendicular = new Vector(-dirToBot.getZ(), 0, dirToBot.getX()).multiply(state.strafeDir);

        double radius = state.wtapping ? reach + 2.0 : Math.max(1.5, reach - 0.8);
        double strafeAmount = cfg.strafeDistance() * (state.wtapping ? 0.3 : 1.0);

        Vector offset = dirToBot.clone().multiply(radius).add(perpendicular.multiply(strafeAmount));
        Location dest = targetLoc.clone().add(offset);
        dest.setY(botLoc.getY());
        return dest;
    }

    private long randomTicks(int minTicks, int maxTicks) {
        int lo = Math.min(minTicks, maxTicks);
        int hi = Math.max(minTicks, maxTicks);
        int ticks = hi <= lo ? lo : ThreadLocalRandom.current().nextInt(lo, hi + 1);
        return ticks * 50L;
    }
}
