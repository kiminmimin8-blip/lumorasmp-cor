package com.zhuvax.dpbot.combat;

public class BotCombatState {

    public int strafeDir = Math.random() < 0.5 ? 1 : -1;
    public long nextStrafeSwitchMillis = 0;

    public boolean wtapping = false;
    public long wtapUntilMillis = 0;
    public long nextWtapMillis = 0;

    public boolean blocking = false;
    public long blockingUntilMillis = 0;
    public long nextBlockRollMillis = 0;

    public long nextCrystalMillis = 0;
}
