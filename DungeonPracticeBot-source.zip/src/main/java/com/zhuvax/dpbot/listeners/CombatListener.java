package com.zhuvax.dpbot.listeners;

import com.zhuvax.dpbot.bot.BotDefinition;
import com.zhuvax.dpbot.bot.BotManager;
import com.zhuvax.dpbot.bot.PracticeBot;
import com.zhuvax.dpbot.config.ConfigManager;
import com.zhuvax.dpbot.util.SchedulerUtil;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Handles damage dealt BY our bots:
 * 1. Combo system - bots chain a randomized burst of fast hits (short cooldown),
 *    then take a longer recovery pause once the combo ends, then start a new
 *    combo of a different random length. This is what makes hits read as a
 *    "combo" instead of isolated evenly-spaced pokes.
 * 2. Attack-cooldown enforcement with randomized jitter on top (fixes "tap-tap"
 *    double hits from tick-batching lag).
 * 3. Crit chance + damage multiplier from the bot's difficulty/settings.
 * 4. Weapon combo-swap: on a crit, briefly swaps to the bot's configured
 *    "secondary weapon" then swaps back.
 */
public class CombatListener implements Listener {

    private final JavaPlugin plugin;
    private final BotManager botManager;
    private final ConfigManager cfg;
    private final Map<UUID, Long> nextAllowedAttackMillis = new HashMap<>();

    // Combo tracking: how many hits landed in the current burst, and how long
    // this particular combo is meant to be before a recovery pause kicks in.
    private final Map<UUID, Integer> comboHits = new HashMap<>();
    private final Map<UUID, Integer> comboTarget = new HashMap<>();

    public CombatListener(JavaPlugin plugin, BotManager botManager, ConfigManager cfg) {
        this.plugin = plugin;
        this.botManager = botManager;
        this.cfg = cfg;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onBotAttack(EntityDamageByEntityEvent event) {
        String name = botManager.nameOf(event.getDamager());
        if (name == null) return;
        if (!(event.getEntity() instanceof Player)) return;

        UUID botId = event.getDamager().getUniqueId();
        long now = System.currentTimeMillis();

        Long nextAllowed = nextAllowedAttackMillis.get(botId);
        if (nextAllowed != null && now < nextAllowed) {
            event.setCancelled(true);
            return;
        }

        int baseCooldownTicks = resolveCooldownTicks(name);
        long cooldownMillis = comboAdjustedCooldownMillis(botId, baseCooldownTicks);
        nextAllowedAttackMillis.put(botId, now + cooldownMillis);

        double multiplier = resolveDamageMultiplier(name);
        double damage = event.getDamage() * multiplier;

        BotDefinition def = botManager.getBotDefManager().get(name);
        if (def != null && ThreadLocalRandom.current().nextDouble() < def.getCritChance()) {
            damage *= 1.5;
            event.getEntity().getWorld().spawnParticle(Particle.CRIT, event.getEntity().getLocation().add(0, 1, 0), 15, 0.3, 0.3, 0.3);
            event.getEntity().getWorld().playSound(event.getEntity().getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 1f);

            if (event.getDamager() instanceof LivingEntity botEntity && def.getSecondaryWeapon() != null) {
                swapToSecondaryWeapon(botEntity, def.getSecondaryWeapon());
            }
        }

        event.setDamage(damage);
    }

    /**
     * Picks the next cooldown based on where we are in the current combo:
     * mid-combo hits are fast (chain multiplier), the hit that finishes a
     * combo gets a longer recovery pause, and a fresh (randomized) combo
     * length is picked for next time.
     */
    private long comboAdjustedCooldownMillis(UUID botId, int baseCooldownTicks) {
        int hits = comboHits.getOrDefault(botId, 0) + 1;
        Integer target = comboTarget.get(botId);
        if (target == null) {
            target = ThreadLocalRandom.current().nextInt(cfg.comboMinHits(), cfg.comboMaxHits() + 1);
            comboTarget.put(botId, target);
        }

        double multiplier;
        if (hits >= target) {
            // combo finished - recovery pause, then start a new combo next hit
            multiplier = cfg.comboRecoveryMultiplier();
            comboHits.put(botId, 0);
            comboTarget.put(botId, ThreadLocalRandom.current().nextInt(cfg.comboMinHits(), cfg.comboMaxHits() + 1));
        } else {
            multiplier = cfg.comboChainMultiplier();
            comboHits.put(botId, hits);
        }

        long ticks = Math.max(1, Math.round(baseCooldownTicks * multiplier));
        return jitteredMillis(ticks);
    }

    private long jitteredMillis(long baseTicks) {
        double fraction = cfg.hitJitterFraction();
        double jitterMultiplier = 1.0;
        if (fraction > 0.0001) {
            jitterMultiplier = 1.0 + ThreadLocalRandom.current().nextDouble(-fraction, fraction);
        }
        long ticks = Math.max(1, Math.round(baseTicks * jitterMultiplier));
        return ticks * 50L;
    }

    private void swapToSecondaryWeapon(LivingEntity bot, ItemStack secondary) {
        EntityEquipment eq = bot.getEquipment();
        if (eq == null) return;

        ItemStack primary = eq.getItemInMainHand().clone();
        eq.setItemInMainHand(secondary.clone());

        SchedulerUtil.runOnEntityLater(plugin, bot, cfg.weaponSwapDurationTicks(), () -> {
            EntityEquipment liveEq = bot.getEquipment();
            if (liveEq != null && bot.isValid()) {
                liveEq.setItemInMainHand(primary);
            }
        });
    }

    private int resolveCooldownTicks(String name) {
        PracticeBot bot = botManager.getLive(name);
        return bot != null ? bot.getDifficulty().getAttackSpeedTicks() : cfg.attackCooldownTicks();
    }

    private double resolveDamageMultiplier(String name) {
        PracticeBot bot = botManager.getLive(name);
        return bot != null ? bot.getDifficulty().getDamageMultiplier() : 1.0;
    }
}
