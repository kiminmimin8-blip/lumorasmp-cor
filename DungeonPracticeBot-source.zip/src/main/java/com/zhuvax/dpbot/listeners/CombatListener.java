package com.zhuvax.dpbot.listeners;

import com.zhuvax.dpbot.bot.BotManager;
import com.zhuvax.dpbot.bot.BotType;
import com.zhuvax.dpbot.bot.PracticeBot;
import com.zhuvax.dpbot.config.ConfigManager;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Handles damage dealt BY our bots. Three things happen here that vanilla
 * zombie AI doesn't give you for free:
 *
 * 1. Attack-cooldown enforcement with randomized jitter - without this,
 *    laggy tick batching can let a zombie register two hits almost
 *    back-to-back ("tap-tap" stutter hits), and a perfectly fixed interval
 *    feels robotic. We enforce a real minimum gap, randomized a bit each
 *    swing, per bot.
 * 2. Crit chance + damage multiplier from the bot's difficulty/settings.
 */
public class CombatListener implements Listener {

    private final BotManager botManager;
    private final ConfigManager cfg;
    private final Map<UUID, Long> nextAllowedAttackMillis = new HashMap<>();

    public CombatListener(BotManager botManager, ConfigManager cfg) {
        this.botManager = botManager;
        this.cfg = cfg;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onBotAttack(EntityDamageByEntityEvent event) {
        BotType type = botManager.typeOf(event.getDamager());
        if (type == null) return;
        if (!(event.getEntity() instanceof Player)) return;

        UUID botId = event.getDamager().getUniqueId();
        long now = System.currentTimeMillis();

        Long nextAllowed = nextAllowedAttackMillis.get(botId);
        if (nextAllowed != null && now < nextAllowed) {
            event.setCancelled(true);
            return;
        }

        int baseCooldownTicks = resolveCooldownTicks(type, botId);
        long jitteredMillis = jitteredCooldownMillis(baseCooldownTicks);
        nextAllowedAttackMillis.put(botId, now + jitteredMillis);

        double multiplier = resolveDamageMultiplier(type, botId);
        double damage = event.getDamage() * multiplier;

        if (type == BotType.DUNGEON) {
            double critChance = cfg.loadDungeonSettings().getCritChance();
            if (ThreadLocalRandom.current().nextDouble() < critChance) {
                damage *= 1.5;
                event.getEntity().getWorld().spawnParticle(Particle.CRIT, event.getEntity().getLocation().add(0, 1, 0), 15, 0.3, 0.3, 0.3);
                event.getEntity().getWorld().playSound(event.getEntity().getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 1f);
            }
        }

        event.setDamage(damage);
    }

    private long jitteredCooldownMillis(int baseCooldownTicks) {
        double fraction = cfg.hitJitterFraction();
        double jitterMultiplier = 1.0;
        if (fraction > 0.0001) {
            jitterMultiplier = 1.0 + ThreadLocalRandom.current().nextDouble(-fraction, fraction);
        }
        long ticks = Math.max(1, Math.round(baseCooldownTicks * jitterMultiplier));
        return ticks * 50L;
    }

    private int resolveCooldownTicks(BotType type, UUID botId) {
        if (type == BotType.DUNGEON) {
            return cfg.dungeonDifficulty().getAttackSpeedTicks();
        }
        for (PracticeBot b : botManager.allNormalBots()) {
            if (b.getEntity().getUniqueId().equals(botId)) {
                return b.getDifficulty().getAttackSpeedTicks();
            }
        }
        return cfg.attackCooldownTicks();
    }

    private double resolveDamageMultiplier(BotType type, UUID botId) {
        if (type == BotType.DUNGEON) {
            PracticeBot db = botManager.getDungeonBot();
            return db != null ? db.getDifficulty().getDamageMultiplier() : 1.0;
        }
        for (PracticeBot b : botManager.allNormalBots()) {
            if (b.getEntity().getUniqueId().equals(botId)) {
                return b.getDifficulty().getDamageMultiplier();
            }
        }
        return 1.0;
    }
}
