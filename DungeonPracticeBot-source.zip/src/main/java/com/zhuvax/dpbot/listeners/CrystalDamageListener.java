package com.zhuvax.dpbot.listeners;

import com.zhuvax.dpbot.bot.BotManager;
import com.zhuvax.dpbot.config.ConfigManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;

public class CrystalDamageListener implements Listener {

    private final BotManager botManager;
    private final ConfigManager cfg;

    public CrystalDamageListener(BotManager botManager, ConfigManager cfg) {
        this.botManager = botManager;
        this.cfg = cfg;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onExplosionDamage(EntityDamageByEntityEvent event) {
        if (event.getCause() != EntityDamageEvent.DamageCause.ENTITY_EXPLOSION) return;
        if (botManager.typeOf(event.getDamager()) == null) return;

        // Only reduce damage when the bot is hurting ITSELF with its own crystal,
        // not when it hits the player it's fighting.
        if (!event.getDamager().getUniqueId().equals(event.getEntity().getUniqueId())) return;

        double reduction = cfg.crystalSelfDamageReduction();
        event.setDamage(event.getDamage() * (1.0 - reduction));
    }
}
