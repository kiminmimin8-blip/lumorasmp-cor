package com.zhuvax.dpbot.listeners;

import com.zhuvax.dpbot.bot.DungeonSettings;
import com.zhuvax.dpbot.config.ConfigManager;
import com.zhuvax.dpbot.gui.DungeonGearGui;
import com.zhuvax.dpbot.gui.DungeonSettingsGui;
import com.zhuvax.dpbot.gui.GuiHolders;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public class GuiListener implements Listener {

    private final ConfigManager cfg;

    public GuiListener(ConfigManager cfg) {
        this.cfg = cfg;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getInventory().getHolder() instanceof GuiHolders.SettingsHolder) {
            handleSettingsClick(event);
        } else if (event.getInventory().getHolder() instanceof GuiHolders.GearHolder) {
            handleGearClick(event);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof GuiHolders.SettingsHolder) {
            event.setCancelled(true);
            return;
        }
        if (event.getInventory().getHolder() instanceof GuiHolders.GearHolder) {
            for (int slot : event.getRawSlots()) {
                if (slot < event.getInventory().getSize() && !DungeonGearGui.EDITABLE_SLOTS.containsKey(slot)) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
    }

    private void handleSettingsClick(InventoryClickEvent event) {
        event.setCancelled(true); // this GUI is display/toggle only, never let items move
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getView().getTopInventory())) {
            return;
        }

        DungeonSettings s = cfg.loadDungeonSettings();
        boolean right = event.getClick() == ClickType.RIGHT || event.getClick() == ClickType.SHIFT_RIGHT;
        boolean shift = event.getClick() == ClickType.SHIFT_LEFT || event.getClick() == ClickType.SHIFT_RIGHT;

        switch (event.getSlot()) {
            case DungeonSettingsGui.SLOT_HP -> s.setHealth(s.getHealth() + (right ? -2 : 2));
            case DungeonSettingsGui.SLOT_KNOCKBACK -> s.setKnockbackImmune(!s.isKnockbackImmune());
            case DungeonSettingsGui.SLOT_FIRE -> s.setFireImmune(!s.isFireImmune());
            case DungeonSettingsGui.SLOT_CRIT -> s.setCritChance(s.getCritChance() + (right ? -0.05 : 0.05));
            case DungeonSettingsGui.SLOT_TOTEM -> {
                int step = shift ? 10 : 1;
                s.setTotemCount(s.getTotemCount() + (right ? -step : step));
            }
            case DungeonSettingsGui.SLOT_LEASH -> s.setLeashRadius(s.getLeashRadius() + (right ? -10 : 10));
            case DungeonSettingsGui.SLOT_RESPAWN -> s.setRespawnDelayTicks(s.getRespawnDelayTicks() + (right ? -100 : 100));
            case DungeonSettingsGui.SLOT_CRYSTAL -> s.setCrystalPvpEnabled(!s.isCrystalPvpEnabled());
            case DungeonSettingsGui.SLOT_GEAR -> {
                DungeonGearGui.open(player, cfg);
                return;
            }
            case DungeonSettingsGui.SLOT_CLOSE -> {
                player.closeInventory();
                return;
            }
            default -> {
                return;
            }
        }

        cfg.saveDungeonSettings(s);
        DungeonSettingsGui.render(event.getInventory(), s);
    }

    private void handleGearClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        boolean clickedTop = event.getClickedInventory() != null
                && event.getClickedInventory().equals(event.getView().getTopInventory());

        if (clickedTop) {
            int slot = event.getSlot();
            boolean editable = DungeonGearGui.EDITABLE_SLOTS.containsKey(slot);
            boolean isSave = slot == DungeonGearGui.SLOT_SAVE;
            boolean isBack = slot == DungeonGearGui.SLOT_BACK;

            if (!editable && !isSave && !isBack) {
                event.setCancelled(true);
                return;
            }
            if (isSave) {
                event.setCancelled(true);
                DungeonGearGui.saveFrom(event.getInventory(), cfg);
                player.sendMessage("§aGear dungeon bot disimpen.");
                DungeonSettingsGui.open(player, cfg);
                return;
            }
            if (isBack) {
                event.setCancelled(true);
                DungeonSettingsGui.open(player, cfg);
                return;
            }
            // editable armor/hand slots: allow normal placement, do nothing extra
        }
    }
}
