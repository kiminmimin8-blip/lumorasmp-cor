package com.zhuvax.dpbot.listeners;

import com.zhuvax.dpbot.bot.BotManager;
import com.zhuvax.dpbot.bot.BotType;
import com.zhuvax.dpbot.config.ConfigManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustEvent;

public class FireImmuneListener implements Listener {

    private final BotManager botManager;
    private final ConfigManager cfg;

    public FireImmuneListener(BotManager botManager, ConfigManager cfg) {
        this.botManager = botManager;
        this.cfg = cfg;
    }

    @EventHandler
    public void onCombust(EntityCombustEvent event) {
        BotType type = botManager.typeOf(event.getEntity());
        if (type != BotType.DUNGEON) return;
        if (cfg.loadDungeonSettings().isFireImmune()) {
            event.setCancelled(true);
            event.getEntity().setFireTicks(0);
        }
    }
}
