package com.zhuvax.dpbot.listeners;

import com.zhuvax.dpbot.bot.BotManager;
import com.zhuvax.dpbot.bot.BotType;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class TotemListener implements Listener {

    private final BotManager botManager;

    public TotemListener(BotManager botManager) {
        this.botManager = botManager;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        BotType type = botManager.typeOf(event.getEntity());
        if (type != BotType.DUNGEON) return;
        if (!(event.getEntity() instanceof LivingEntity entity)) return;

        double remainingHealth = entity.getHealth() - event.getFinalDamage();
        if (remainingHealth > 0) return; // not lethal, nothing to do

        if (!botManager.consumeTotemCharge()) return; // no charges left, let it die normally

        event.setCancelled(true);

        double maxHealth = entity.getAttribute(Attribute.MAX_HEALTH) != null
                ? entity.getAttribute(Attribute.MAX_HEALTH).getValue()
                : 20.0;
        entity.setHealth(Math.min(maxHealth, maxHealth * 0.2));
        entity.setFireTicks(0);
        entity.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1));
        entity.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 100, 1));
        entity.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, entity.getLocation().add(0, 1, 0), 30, 0.5, 0.5, 0.5, 0.5);
        entity.getWorld().playSound(entity.getLocation(), Sound.ITEM_TOTEM_USE, 1f, 1f);
    }
}
