package com.zhuvax.dpbot.listeners;

import com.zhuvax.dpbot.bot.BotManager;
import com.zhuvax.dpbot.bot.BotType;
import com.zhuvax.dpbot.config.ConfigManager;
import com.zhuvax.dpbot.loot.LootEntry;
import com.zhuvax.dpbot.util.SchedulerUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.UUID;

public class BotDeathListener implements Listener {

    private final JavaPlugin plugin;
    private final BotManager botManager;
    private final ConfigManager cfg;

    public BotDeathListener(JavaPlugin plugin, BotManager botManager, ConfigManager cfg) {
        this.plugin = plugin;
        this.botManager = botManager;
        this.cfg = cfg;
    }

    @EventHandler
    public void onBotDeath(EntityDeathEvent event) {
        BotType type = botManager.typeOf(event.getEntity());
        if (type == null) return;

        if (type == BotType.DUNGEON) {
            handleDungeonBotDeath(event);
        } else {
            handleNormalBotDeath(event);
        }
    }

    private void handleDungeonBotDeath(EntityDeathEvent event) {
        // Replace vanilla zombie drops with our configured loot table
        event.getDrops().clear();
        event.setDroppedExp(0);

        List<LootEntry> table = cfg.dungeonLootTable();
        List<ItemStack> loot = LootEntry.rollAll(table);
        Location deathLoc = event.getEntity().getLocation();
        for (ItemStack item : loot) {
            deathLoc.getWorld().dropItemNaturally(deathLoc, item);
        }

        // Announce to everyone online
        Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(cfg.msg("dungeon-bot-died")));

        botManager.clearDeadDungeonBot();

        if (cfg.dungeonAutoRespawnEnabled()) {
            Location spawn = cfg.dungeonSpawn();
            if (spawn != null) {
                SchedulerUtil.runAtLocationLater(plugin, spawn, cfg.dungeonAutoRespawnDelay(),
                        () -> botManager.spawnDungeonBot(spawn));
            }
        }
    }

    private void handleNormalBotDeath(EntityDeathEvent event) {
        String ownerRaw = event.getEntity().getPersistentDataContainer()
                .get(botManager.KEY_OWNER, PersistentDataType.STRING);
        if (ownerRaw == null || ownerRaw.equals("DUNGEON")) return;

        UUID ownerId = UUID.fromString(ownerRaw);
        botManager.clearDeadNormalBot(ownerId);

        if (!cfg.autoRespawnEnabled()) return;

        Player owner = Bukkit.getPlayer(ownerId);
        if (owner == null || !owner.isOnline()) return;

        var difficulty = cfg.startingDifficulty();
        Location loc = event.getEntity().getLocation();
        SchedulerUtil.runAtLocationLater(plugin, loc, cfg.autoRespawnDelay(),
                () -> botManager.spawnNormalBot(owner, difficulty));
    }
}
