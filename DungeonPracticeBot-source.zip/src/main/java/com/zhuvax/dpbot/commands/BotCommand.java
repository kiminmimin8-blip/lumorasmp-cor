package com.zhuvax.dpbot.commands;

import com.zhuvax.dpbot.bot.BotManager;
import com.zhuvax.dpbot.bot.PracticeBot;
import com.zhuvax.dpbot.config.ConfigManager;
import com.zhuvax.dpbot.difficulty.Difficulty;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BotCommand implements CommandExecutor, TabCompleter {

    private final BotManager botManager;
    private final ConfigManager cfg;

    public BotCommand(BotManager botManager, ConfigManager cfg) {
        this.botManager = botManager;
        this.cfg = cfg;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "spawn" -> handleSpawn(sender, args);
            case "remove" -> handleRemove(sender);
            case "setspawn" -> handleSetSpawn(sender, args);
            case "dungeon" -> handleDungeonGui(sender);
            case "difficulty" -> handleDifficulty(sender, args);
            case "settings" -> handleSettings(sender);
            case "help" -> sendHelp(sender);
            case "reload" -> handleReload(sender);
            case "removeall" -> handleRemoveAll(sender);
            default -> sendHelp(sender);
        }
        return true;
    }

    private void handleSpawn(CommandSender sender, String[] args) {
        boolean dungeon = args.length > 1 && args[1].equalsIgnoreCase("dungeon");

        if (dungeon) {
            if (!sender.hasPermission("dpbot.dungeon.spawn")) {
                sender.sendMessage(cfg.msg("no-permission"));
                return;
            }
            if (cfg.dungeonSingleInstance() && botManager.isDungeonBotAlive()) {
                sender.sendMessage(cfg.msg("dungeon-bot-already-alive"));
                return;
            }
            Location spawn = cfg.dungeonSpawn();
            if (spawn == null) {
                sender.sendMessage(cfg.msg("dungeon-bot-no-spawn"));
                return;
            }
            botManager.spawnDungeonBot(spawn);
            sender.sendMessage(cfg.msg("dungeon-bot-spawned"));
            return;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(cfg.msg("player-only"));
            return;
        }
        if (!player.hasPermission("dpbot.spawn")) {
            player.sendMessage(cfg.msg("no-permission"));
            return;
        }
        if (botManager.hasNormalBot(player)) {
            player.sendMessage(cfg.msg("bot-already-exists"));
            return;
        }
        botManager.spawnNormalBot(player, cfg.startingDifficulty());
        player.sendMessage(cfg.msg("bot-spawned"));
    }

    private void handleRemove(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(cfg.msg("player-only"));
            return;
        }
        if (!player.hasPermission("dpbot.remove")) {
            player.sendMessage(cfg.msg("no-permission"));
            return;
        }
        if (!botManager.hasNormalBot(player)) {
            player.sendMessage(cfg.msg("bot-not-found"));
            return;
        }
        botManager.removeNormalBot(player);
        player.sendMessage(cfg.msg("bot-removed"));
    }

    private void handleDungeonGui(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(cfg.msg("player-only"));
            return;
        }
        if (!player.hasPermission("dpbot.dungeon.settings")) {
            player.sendMessage(cfg.msg("no-permission"));
            return;
        }
        com.zhuvax.dpbot.gui.DungeonSettingsGui.open(player, cfg);
    }

    private void handleSetSpawn(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(cfg.msg("player-only"));
            return;
        }
        if (args.length < 2 || !args[1].equalsIgnoreCase("dungeon")) {
            player.sendMessage("§eUsage: /bot setspawn dungeon");
            return;
        }
        if (!player.hasPermission("dpbot.dungeon.setspawn")) {
            player.sendMessage(cfg.msg("no-permission"));
            return;
        }
        cfg.setDungeonSpawn(player.getLocation());
        player.sendMessage(cfg.msg("dungeon-spawn-set"));
    }

    private void handleDifficulty(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(cfg.msg("player-only"));
            return;
        }
        if (!player.hasPermission("dpbot.difficulty")) {
            player.sendMessage(cfg.msg("no-permission"));
            return;
        }
        if (args.length < 2) {
            player.sendMessage(cfg.msg("difficulty-invalid"));
            return;
        }
        String key = args[1].toUpperCase();
        if (!key.equals("EASY") && !key.equals("MEDIUM") && !key.equals("HARD")) {
            player.sendMessage(cfg.msg("difficulty-invalid"));
            return;
        }
        PracticeBot bot = botManager.getNormalBot(player);
        if (bot == null || !bot.isAlive()) {
            player.sendMessage(cfg.msg("bot-not-found"));
            return;
        }
        Difficulty difficulty = cfg.loadDifficulty(key);
        bot.setDifficulty(difficulty);
        player.sendMessage(cfg.msg("difficulty-changed", "difficulty", key));
    }

    private void handleSettings(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(cfg.msg("player-only"));
            return;
        }
        PracticeBot bot = botManager.getNormalBot(player);
        if (bot == null || !bot.isAlive()) {
            player.sendMessage(cfg.msg("bot-not-found"));
            return;
        }
        player.sendMessage(cfg.msg("settings-header"));
        player.sendMessage(cfg.msg("settings-difficulty", "difficulty", bot.getDifficulty().getName()));
        player.sendMessage(cfg.msg("settings-health", "health", String.valueOf(bot.getDifficulty().getHealth())));
        player.sendMessage(cfg.msg("settings-reach", "reach", String.valueOf(bot.getDifficulty().getReach())));
    }

    private void handleReload(CommandSender sender) {
        if (!sender.hasPermission("dpbot.admin")) {
            sender.sendMessage(cfg.msg("no-permission"));
            return;
        }
        cfg.load();
        sender.sendMessage("§aConfig di-reload.");
    }

    private void handleRemoveAll(CommandSender sender) {
        if (!sender.hasPermission("dpbot.admin")) {
            sender.sendMessage(cfg.msg("no-permission"));
            return;
        }
        botManager.removeAll();
        sender.sendMessage("§aSemua bot (termasuk dungeon bot) sudah dihapus.");
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage("""
                §6DungeonPracticeBot Commands:
                §e/bot spawn §7- Spawn bot practice biasa
                §e/bot spawn dungeon §7- Spawn dungeon bot (drop item)
                §e/bot remove §7- Hapus bot kamu
                §e/bot setspawn dungeon §7- Set titik spawn dungeon bot (posisi kamu sekarang)
                §e/bot dungeon §7- Buka GUI setting dungeon bot (HP, gear, totem, dll)
                §e/bot difficulty <easy|medium|hard> §7- Ganti difficulty bot
                §e/bot settings §7- Lihat setting bot kamu
                §e/bot help §7- Tampilkan menu ini""");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> options = new ArrayList<>();
        if (args.length == 1) {
            options.addAll(Arrays.asList("spawn", "remove", "setspawn", "dungeon", "difficulty", "settings", "help"));
            if (sender.hasPermission("dpbot.admin")) {
                options.addAll(Arrays.asList("reload", "removeall"));
            }
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("spawn") || args[0].equalsIgnoreCase("setspawn")) {
                options.add("dungeon");
            } else if (args[0].equalsIgnoreCase("difficulty")) {
                options.addAll(Arrays.asList("easy", "medium", "hard"));
            }
        }
        String current = args[args.length - 1].toLowerCase();
        options.removeIf(o -> !o.toLowerCase().startsWith(current));
        return options;
    }
}
