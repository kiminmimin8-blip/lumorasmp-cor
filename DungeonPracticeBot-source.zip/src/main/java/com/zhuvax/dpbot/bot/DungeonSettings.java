package com.zhuvax.dpbot.bot;

import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.EnumMap;
import java.util.Map;

public class DungeonSettings {

    private double health = 26.0;
    private boolean knockbackImmune = false;
    private boolean fireImmune = false;
    private double critChance = 0.15; // 15%
    private int totemCount = 0;
    private double leashRadius = 250.0;
    private long respawnDelayTicks = 400; // 20 seconds
    private boolean crystalPvpEnabled = true;
    private final Map<EquipmentSlot, ItemStack> gear = new EnumMap<>(EquipmentSlot.class);

    public double getHealth() {
        return health;
    }

    public void setHealth(double health) {
        this.health = Math.max(1.0, health);
    }

    public boolean isKnockbackImmune() {
        return knockbackImmune;
    }

    public void setKnockbackImmune(boolean knockbackImmune) {
        this.knockbackImmune = knockbackImmune;
    }

    public boolean isFireImmune() {
        return fireImmune;
    }

    public void setFireImmune(boolean fireImmune) {
        this.fireImmune = fireImmune;
    }

    public double getCritChance() {
        return critChance;
    }

    public void setCritChance(double critChance) {
        this.critChance = Math.max(0.0, Math.min(1.0, critChance));
    }

    public int getTotemCount() {
        return totemCount;
    }

    public void setTotemCount(int totemCount) {
        this.totemCount = Math.max(0, Math.min(100, totemCount));
    }

    public double getLeashRadius() {
        return leashRadius;
    }

    public void setLeashRadius(double leashRadius) {
        this.leashRadius = Math.max(5.0, leashRadius);
    }

    public long getRespawnDelayTicks() {
        return respawnDelayTicks;
    }

    public void setRespawnDelayTicks(long respawnDelayTicks) {
        this.respawnDelayTicks = Math.max(0, respawnDelayTicks);
    }

    public boolean isCrystalPvpEnabled() {
        return crystalPvpEnabled;
    }

    public void setCrystalPvpEnabled(boolean crystalPvpEnabled) {
        this.crystalPvpEnabled = crystalPvpEnabled;
    }

    public Map<EquipmentSlot, ItemStack> getGear() {
        return gear;
    }

    public ItemStack getGear(EquipmentSlot slot) {
        return gear.get(slot);
    }

    public void setGear(EquipmentSlot slot, ItemStack item) {
        if (item == null || item.getType().isAir()) {
            gear.remove(slot);
        } else {
            gear.put(slot, item.clone());
        }
    }
}
