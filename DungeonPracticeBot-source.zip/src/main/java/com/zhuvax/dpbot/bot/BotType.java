package com.zhuvax.dpbot.bot;

public enum BotType {
    NORMAL,
    DUNGEON
}
