package com.zhuvax.dpbot.bot;

import com.zhuvax.dpbot.combat.CombatController;
import com.zhuvax.dpbot.config.ConfigManager;
import com.zhuvax.dpbot.difficulty.Difficulty;
import com.zhuvax.dpbot.util.SchedulerUtil;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class BotManager {

    private final JavaPlugin plugin;
    private final ConfigManager cfg;

    public final NamespacedKey KEY_TYPE;
    public final NamespacedKey KEY_OWNER;

    private final Map<UUID, PracticeBot> normalBots = new HashMap<>();
    private PracticeBot dungeonBot;
    private int totemChargesRemaining = 0;
    private SchedulerUtil.TaskHandle leashTaskHandle;
    private Location dungeonHomeLocation;
    private final CombatController combatController;

    public BotManager(JavaPlugin plugin, ConfigManager cfg) {
        this.plugin = plugin;
        this.cfg = cfg;
        this.KEY_TYPE = new NamespacedKey(plugin, "dpbot_type");
        this.KEY_OWNER = new NamespacedKey(plugin, "dpbot_owner");
        this.combatController = new CombatController(plugin, cfg);
    }

    // ---------------- Normal bots ----------------

    public boolean hasNormalBot(Player player) {
        PracticeBot bot = normalBots.get(player.getUniqueId());
        return bot != null && bot.isAlive();
    }

    public PracticeBot getNormalBot(Player player) {
        return normalBots.get(player.getUniqueId());
    }

    public void spawnNormalBot(Player owner, Difficulty difficulty) {
        Location loc = owner.getLocation();
        SchedulerUtil.runAtLocation(plugin, loc, () -> {
            LivingEntity entity = (LivingEntity) loc.getWorld().spawnEntity(loc, EntityType.ZOMBIE);
            tagEntity(entity, BotType.NORMAL, owner.getUniqueId());
            applyDifficulty(entity, difficulty);
            entity.setCustomName(cfg.nameFormat().replace("{player}", owner.getName())
                    .replace('&', '§'));
            entity.setCustomNameVisible(true);
            entity.setRemoveWhenFarAway(false);
            if (entity instanceof Zombie zombie) {
                zombie.setBaby(false);
            }
            entity.setFallDistance(0f);

            org.bukkit.inventory.EntityEquipment eq = entity.getEquipment();
            if (eq != null) {
                eq.setItemInMainHand(new org.bukkit.inventory.ItemStack(org.bukkit.Material.IRON_SWORD));
                eq.setItemInOffHand(new org.bukkit.inventory.ItemStack(org.bukkit.Material.SHIELD));
                eq.setItemInMainHandDropChance(0f);
                eq.setItemInOffHandDropChance(0f);
            }

            PracticeBot bot = new PracticeBot(entity, BotType.NORMAL, owner.getUniqueId(), difficulty);
            normalBots.put(owner.getUniqueId(), bot);
            combatController.attach(bot);
        });
    }

    public void removeNormalBot(Player owner) {
        PracticeBot bot = normalBots.remove(owner.getUniqueId());
        if (bot != null && bot.isAlive()) {
            combatController.detach(bot.getEntity().getUniqueId());
            SchedulerUtil.consumeOnEntity(plugin, bot.getEntity(), e -> e.remove());
        }
    }

    public void clearDeadNormalBot(UUID owner) {
        PracticeBot bot = normalBots.remove(owner);
        if (bot != null) {
            combatController.detach(bot.getEntity().getUniqueId());
        }
    }

    public CombatController getCombatController() {
        return combatController;
    }

    public java.util.Collection<PracticeBot> allNormalBots() {
        return normalBots.values();
    }

    // ---------------- Dungeon bot ----------------

    public boolean isDungeonBotAlive() {
        return dungeonBot != null && dungeonBot.isAlive();
    }

    public PracticeBot getDungeonBot() {
        return dungeonBot;
    }

    public void spawnDungeonBot(Location spawnLocation) {
        this.dungeonHomeLocation = spawnLocation.clone();
        SchedulerUtil.runAtLocation(plugin, spawnLocation, () -> {
            LivingEntity entity = (LivingEntity) spawnLocation.getWorld().spawnEntity(spawnLocation, EntityType.ZOMBIE);
            DungeonSettings settings = cfg.loadDungeonSettings();
            Difficulty diff = cfg.dungeonDifficulty();

            tagEntity(entity, BotType.DUNGEON, null);

            if (entity.getAttribute(Attribute.MAX_HEALTH) != null) {
                entity.getAttribute(Attribute.MAX_HEALTH).setBaseValue(settings.getHealth());
                entity.setHealth(settings.getHealth());
            }
            if (entity.getAttribute(Attribute.KNOCKBACK_RESISTANCE) != null) {
                entity.getAttribute(Attribute.KNOCKBACK_RESISTANCE).setBaseValue(settings.isKnockbackImmune() ? 1.0 : 0.0);
            }
            entity.setCustomName(cfg.dungeonNameFormat().replace('&', '§'));
            entity.setCustomNameVisible(true);
            entity.setRemoveWhenFarAway(false);
            entity.setPersistent(true);
            entity.setFireTicks(0);

            org.bukkit.inventory.EntityEquipment eq = entity.getEquipment();
            if (eq != null) {
                for (org.bukkit.inventory.EquipmentSlot slot : org.bukkit.inventory.EquipmentSlot.values()) {
                    org.bukkit.inventory.ItemStack gearItem = settings.getGear(slot);
                    if (gearItem != null) {
                        eq.setItem(slot, gearItem);
                        eq.setDropChance(slot, 0f); // don't double up with our custom loot table
                    }
                }
                if (eq.getItemInOffHand().getType().isAir()) {
                    eq.setItemInOffHand(new org.bukkit.inventory.ItemStack(org.bukkit.Material.SHIELD));
                    eq.setItemInOffHandDropChance(0f);
                }
                if (eq.getItemInMainHand().getType().isAir()) {
                    eq.setItemInMainHand(new org.bukkit.inventory.ItemStack(org.bukkit.Material.DIAMOND_SWORD));
                    eq.setItemInMainHandDropChance(0f);
                }
            }

            totemChargesRemaining = settings.getTotemCount();
            dungeonBot = new PracticeBot(entity, BotType.DUNGEON, null, diff);
            combatController.attach(dungeonBot);

            if (leashTaskHandle != null) {
                leashTaskHandle.cancel();
            }
            leashTaskHandle = SchedulerUtil.runOnEntityRepeating(plugin, entity, 40L, 40L, () -> {
                if (dungeonBot == null || !dungeonBot.isAlive() || dungeonHomeLocation == null) return;
                LivingEntity e = dungeonBot.getEntity();
                if (!e.getWorld().equals(dungeonHomeLocation.getWorld())) return;
                double radius = cfg.loadDungeonSettings().getLeashRadius();
                if (e.getLocation().distance(dungeonHomeLocation) > radius) {
                    e.teleport(dungeonHomeLocation);
                    if (e instanceof org.bukkit.entity.Mob mob) {
                        mob.setTarget(null);
                    }
                }
            });
        });
    }

    public int getTotemChargesRemaining() {
        return totemChargesRemaining;
    }

    public boolean consumeTotemCharge() {
        if (totemChargesRemaining <= 0) return false;
        totemChargesRemaining--;
        return true;
    }

    public void removeDungeonBot() {
        if (leashTaskHandle != null) {
            leashTaskHandle.cancel();
            leashTaskHandle = null;
        }
        if (dungeonBot != null && dungeonBot.isAlive()) {
            combatController.detach(dungeonBot.getEntity().getUniqueId());
            SchedulerUtil.consumeOnEntity(plugin, dungeonBot.getEntity(), e -> e.remove());
        }
        dungeonBot = null;
    }

    public void clearDeadDungeonBot() {
        if (leashTaskHandle != null) {
            leashTaskHandle.cancel();
            leashTaskHandle = null;
        }
        if (dungeonBot != null) {
            combatController.detach(dungeonBot.getEntity().getUniqueId());
        }
        dungeonBot = null;
    }

    // ---------------- Shared helpers ----------------

    private void tagEntity(LivingEntity entity, BotType type, UUID owner) {
        entity.getPersistentDataContainer().set(KEY_TYPE, PersistentDataType.STRING, type.name());
        entity.getPersistentDataContainer().set(KEY_OWNER, PersistentDataType.STRING,
                owner != null ? owner.toString() : "DUNGEON");
    }

    private void applyDifficulty(LivingEntity entity, Difficulty difficulty) {
        if (entity.getAttribute(Attribute.MAX_HEALTH) != null) {
            entity.getAttribute(Attribute.MAX_HEALTH).setBaseValue(difficulty.getHealth());
            entity.setHealth(difficulty.getHealth());
        }
    }

    public BotType typeOf(org.bukkit.entity.Entity entity) {
        String raw = entity.getPersistentDataContainer().get(KEY_TYPE, PersistentDataType.STRING);
        if (raw == null) return null;
        try {
            return BotType.valueOf(raw);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public void removeAll() {
        for (PracticeBot bot : normalBots.values()) {
            combatController.detach(bot.getEntity().getUniqueId());
            if (bot.isAlive()) {
                SchedulerUtil.consumeOnEntity(plugin, bot.getEntity(), e -> e.remove());
            }
        }
        normalBots.clear();
        removeDungeonBot();
    }
}
