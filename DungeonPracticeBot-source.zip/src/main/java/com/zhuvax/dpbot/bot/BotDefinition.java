package com.zhuvax.dpbot.bot;

import org.bukkit.Location;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.EnumMap;
import java.util.Map;

/**
 * Full config for one named bot: everything used to used to only live on the
 * singleton "dungeon bot" now lives here, per bot, so every bot you create
 * has the full feature set (gear, totem saves, crystal/anchor pvp, etc).
 */
public class BotDefinition {

    public static final int MAX_TOTEM = 150;
    public static final int TOTEM_STEP = 10;

    private final String name;
    private Location spawnLocation; // null = no fixed home, ad-hoc spawn only, no auto-respawn

    private String difficultyName = "MEDIUM";
    private double health = 40.0;
    private boolean knockbackImmune = false;
    private boolean fireImmune = true;
    private double critChance = 0.15;
    private int totemCount = 0;
    private double leashRadius = 250.0;
    private long respawnDelayTicks = 600; // 30 seconds
    private boolean crystalPvpEnabled = true;
    private boolean anchorPvpEnabled = true;
    private ItemStack secondaryWeapon;
    private final Map<EquipmentSlot, ItemStack> gear = new EnumMap<>(EquipmentSlot.class);

    public BotDefinition(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Location getSpawnLocation() {
        return spawnLocation;
    }

    public void setSpawnLocation(Location spawnLocation) {
        this.spawnLocation = spawnLocation == null ? null : spawnLocation.clone();
    }

    public String getDifficultyName() {
        return difficultyName;
    }

    public void setDifficultyName(String difficultyName) {
        this.difficultyName = difficultyName.toUpperCase();
    }

    public double getHealth() {
        return health;
    }

    public void setHealth(double health) {
        this.health = Math.max(1.0, health);
    }

    public boolean isKnockbackImmune() {
        return knockbackImmune;
    }

    public void setKnockbackImmune(boolean knockbackImmune) {
        this.knockbackImmune = knockbackImmune;
    }

    public boolean isFireImmune() {
        return fireImmune;
    }

    public void setFireImmune(boolean fireImmune) {
        this.fireImmune = fireImmune;
    }

    public double getCritChance() {
        return critChance;
    }

    public void setCritChance(double critChance) {
        this.critChance = Math.max(0.0, Math.min(1.0, critChance));
    }

    public int getTotemCount() {
        return totemCount;
    }

    public void setTotemCount(int totemCount) {
        this.totemCount = Math.max(0, Math.min(MAX_TOTEM, totemCount));
    }

    /** Click-to-cycle: +10 each press, wraps back to 10 once it would exceed the max. */
    public void cycleTotemCount() {
        int next = totemCount + TOTEM_STEP;
        this.totemCount = next > MAX_TOTEM ? TOTEM_STEP : next;
    }

    public double getLeashRadius() {
        return leashRadius;
    }

    public void setLeashRadius(double leashRadius) {
        this.leashRadius = Math.max(5.0, leashRadius);
    }

    public long getRespawnDelayTicks() {
        return respawnDelayTicks;
    }

    public void setRespawnDelayTicks(long respawnDelayTicks) {
        this.respawnDelayTicks = Math.max(0, respawnDelayTicks);
    }

    public boolean isCrystalPvpEnabled() {
        return crystalPvpEnabled;
    }

    public void setCrystalPvpEnabled(boolean crystalPvpEnabled) {
        this.crystalPvpEnabled = crystalPvpEnabled;
    }

    public boolean isAnchorPvpEnabled() {
        return anchorPvpEnabled;
    }

    public void setAnchorPvpEnabled(boolean anchorPvpEnabled) {
        this.anchorPvpEnabled = anchorPvpEnabled;
    }

    public ItemStack getSecondaryWeapon() {
        return secondaryWeapon;
    }

    public void setSecondaryWeapon(ItemStack secondaryWeapon) {
        if (secondaryWeapon == null || secondaryWeapon.getType().isAir()) {
            this.secondaryWeapon = null;
        } else {
            this.secondaryWeapon = secondaryWeapon.clone();
        }
    }

    public Map<EquipmentSlot, ItemStack> getGear() {
        return gear;
    }

    public ItemStack getGear(EquipmentSlot slot) {
        return gear.get(slot);
    }

    public void setGear(EquipmentSlot slot, ItemStack item) {
        if (item == null || item.getType().isAir()) {
            gear.remove(slot);
        } else {
            gear.put(slot, item.clone());
        }
    }
}
