package com.zhuvax.dpbot.bot;

import com.zhuvax.dpbot.difficulty.Difficulty;
import org.bukkit.entity.LivingEntity;

public class PracticeBot {

    private final LivingEntity entity;
    private final String name;
    private Difficulty difficulty;

    public PracticeBot(LivingEntity entity, String name, Difficulty difficulty) {
        this.entity = entity;
        this.name = name;
        this.difficulty = difficulty;
    }

    public LivingEntity getEntity() {
        return entity;
    }

    public String getName() {
        return name;
    }

    public Difficulty getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(Difficulty difficulty) {
        this.difficulty = difficulty;
        if (entity.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH) != null) {
            entity.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).setBaseValue(difficulty.getHealth());
            entity.setHealth(Math.min(difficulty.getHealth(), entity.getHealth()));
        }
    }

    public boolean isAlive() {
        return entity != null && !entity.isDead() && entity.isValid();
    }
}
