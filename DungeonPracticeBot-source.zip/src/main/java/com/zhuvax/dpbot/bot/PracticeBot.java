package com.zhuvax.dpbot.bot;

import com.zhuvax.dpbot.difficulty.Difficulty;
import org.bukkit.entity.LivingEntity;

import java.util.UUID;

public class PracticeBot {

    private final LivingEntity entity;
    private final BotType type;
    private final UUID owner; // null for the dungeon bot
    private Difficulty difficulty;

    public PracticeBot(LivingEntity entity, BotType type, UUID owner, Difficulty difficulty) {
        this.entity = entity;
        this.type = type;
        this.owner = owner;
        this.difficulty = difficulty;
    }

    public LivingEntity getEntity() {
        return entity;
    }

    public BotType getType() {
        return type;
    }

    public UUID getOwner() {
        return owner;
    }

    public Difficulty getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(Difficulty difficulty) {
        this.difficulty = difficulty;
        if (entity.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH) != null) {
            entity.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).setBaseValue(difficulty.getHealth());
            entity.setHealth(Math.min(difficulty.getHealth(), entity.getHealth()));
        }
    }

    public boolean isAlive() {
        return entity != null && !entity.isDead() && entity.isValid();
    }
}
