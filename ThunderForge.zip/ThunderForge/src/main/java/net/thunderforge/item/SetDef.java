package net.thunderforge.item;

import java.util.List;
import java.util.Map;

public record SetDef(
        String id,
        List<String> pieces,
        Map<String, Integer> bonusEffects,
        SkillSpec skill) {
}
