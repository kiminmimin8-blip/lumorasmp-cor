package net.thunderforge.item;

import org.bukkit.configuration.ConfigurationSection;

/** Skill yang dipasang ke item atau set. params = section config skill itu sendiri. */
public record SkillSpec(String type, int cooldown, ConfigurationSection params) {
}
