package net.thunderforge.util;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Helper buat animasi partikel. */
public final class Fx {

    public static final Particle.DustOptions CYAN = new Particle.DustOptions(Color.fromRGB(90, 225, 255), 1.2f);
    public static final Particle.DustOptions GOLD = new Particle.DustOptions(Color.fromRGB(255, 205, 80), 1.2f);
    public static final Particle.DustOptions RED = new Particle.DustOptions(Color.fromRGB(255, 70, 50), 1.3f);
    public static final Particle.DustOptions WHITE = new Particle.DustOptions(Color.fromRGB(255, 255, 255), 1.4f);

    private Fx() {
    }

    /** Satu titik partikel berwarna. */
    public static void dust(Location at, Particle.DustOptions options) {
        World world = at.getWorld();
        if (world == null) return;
        world.spawnParticle(Particle.DUST, at, 1, 0, 0, 0, 0, options);
    }

    /** Cincin partikel horizontal. */
    public static void ring(Location center, double radius, int points, Particle particle) {
        World world = center.getWorld();
        if (world == null || radius <= 0) return;
        for (int i = 0; i < points; i++) {
            double angle = 2 * Math.PI * i / points;
            world.spawnParticle(particle,
                    center.getX() + Math.cos(angle) * radius,
                    center.getY(),
                    center.getZ() + Math.sin(angle) * radius,
                    1, 0, 0, 0, 0);
        }
    }

    /** Cincin partikel berwarna. */
    public static void ringDust(Location center, double radius, int points, Particle.DustOptions options) {
        if (center.getWorld() == null || radius <= 0) return;
        for (int i = 0; i < points; i++) {
            double angle = 2 * Math.PI * i / points;
            dust(center.clone().add(Math.cos(angle) * radius, 0, Math.sin(angle) * radius), options);
        }
    }

    public static void line(Location from, Location to, Particle particle, double step) {
        line(from, to, particle, step, 0.15);
    }

    /** Garis partikel, jitter = seberapa bergerigi. */
    public static void line(Location from, Location to, Particle particle, double step, double jitter) {
        World world = from.getWorld();
        if (world == null) return;
        Vector dir = to.toVector().subtract(from.toVector());
        double length = dir.length();
        if (length < 0.01) return;
        dir.normalize();

        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (double t = 0; t <= length; t += step) {
            Location p = from.clone().add(dir.clone().multiply(t));
            if (jitter > 0) {
                p.add(rnd.nextDouble(-jitter, jitter), rnd.nextDouble(-jitter, jitter), rnd.nextDouble(-jitter, jitter));
            }
            world.spawnParticle(particle, p, 1, 0, 0, 0, 0);
        }
    }

    /** Garis partikel berwarna (tanpa jitter). */
    public static void lineDust(Location from, Location to, double step, Particle.DustOptions options) {
        if (from.getWorld() == null) return;
        Vector dir = to.toVector().subtract(from.toVector());
        double length = dir.length();
        if (length < 0.01) return;
        dir.normalize();
        for (double t = 0; t <= length; t += step) {
            dust(from.clone().add(dir.clone().multiply(t)), options);
        }
    }

    /** Sambaran petir bergerigi: patah-patah dari from ke to + titik berwarna di tiap patahan. */
    public static void bolt(Location from, Location to, int segments, double jitter,
                            Particle particle, Particle.DustOptions options) {
        if (from.getWorld() == null) return;
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        Vector delta = to.toVector().subtract(from.toVector());

        List<Location> points = new ArrayList<>();
        for (int i = 0; i <= segments; i++) {
            Location p = from.clone().add(delta.clone().multiply((double) i / segments));
            if (i > 0 && i < segments) {
                p.add(rnd.nextDouble(-jitter, jitter), rnd.nextDouble(-jitter, jitter), rnd.nextDouble(-jitter, jitter));
            }
            points.add(p);
        }
        for (int i = 0; i < points.size() - 1; i++) {
            line(points.get(i), points.get(i + 1), particle, 0.3, 0.03);
            dust(points.get(i), options);
        }
    }

    /** Ledakan partikel ke segala arah. */
    public static void burst(Location at, Particle particle, int count, double speed) {
        World world = at.getWorld();
        if (world == null) return;
        world.spawnParticle(particle, at, count, 0, 0, 0, speed);
    }

    /** Titik-titik acak di permukaan bola. */
    public static void sphere(Location center, double radius, int points, Particle particle) {
        World world = center.getWorld();
        if (world == null) return;
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int i = 0; i < points; i++) {
            double x = rnd.nextGaussian();
            double y = rnd.nextGaussian();
            double z = rnd.nextGaussian();
            double len = Math.sqrt(x * x + y * y + z * z);
            if (len < 1e-6) continue;
            world.spawnParticle(particle,
                    center.getX() + x / len * radius,
                    center.getY() + y / len * radius,
                    center.getZ() + z / len * radius,
                    1, 0, 0, 0, 0);
        }
    }

    /** Hexagram (bintang segi enam) horizontal yang bisa diputar. */
    public static void star(Location center, double radius, double rotation, double step,
                            Particle.DustOptions options) {
        for (int tri = 0; tri < 2; tri++) {
            Location[] v = new Location[3];
            for (int i = 0; i < 3; i++) {
                double a = rotation + tri * Math.PI / 3 + i * 2 * Math.PI / 3;
                v[i] = center.clone().add(Math.cos(a) * radius, 0, Math.sin(a) * radius);
            }
            for (int i = 0; i < 3; i++) {
                lineDust(v[i], v[(i + 1) % 3], step, options);
            }
        }
    }
}
