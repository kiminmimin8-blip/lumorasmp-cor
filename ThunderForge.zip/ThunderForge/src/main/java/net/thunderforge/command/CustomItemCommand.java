package net.thunderforge.command;

import net.thunderforge.ThunderForge;
import net.thunderforge.item.ItemDef;
import net.thunderforge.item.SetDef;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class CustomItemCommand implements CommandExecutor, TabCompleter {

    private static final String PERMISSION = "customitem.admin";

    private final ThunderForge plugin;

    public CustomItemCommand(ThunderForge plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission(PERMISSION)) {
            sender.sendMessage(plugin.msg("no-permission"));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(plugin.msg("usage"));
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "give" -> give(sender, args);
            case "giveset" -> giveSet(sender, args);
            case "list" -> list(sender);
            case "reload" -> {
                plugin.reloadAll();
                sender.sendMessage(plugin.msg("reloaded",
                        "count", String.valueOf(plugin.items().itemCount()),
                        "sets", String.valueOf(plugin.items().setCount())));
            }
            default -> sender.sendMessage(plugin.msg("usage"));
        }
        return true;
    }

    private void give(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(plugin.msg("usage-give"));
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(plugin.msg("player-not-found", "player", args[1]));
            return;
        }
        ItemDef def = plugin.items().get(args[2].toLowerCase(Locale.ROOT));
        if (def == null) {
            sender.sendMessage(plugin.msg("unknown-item", "id", args[2]));
            return;
        }

        int amount = 1;
        if (args.length >= 4) {
            try {
                amount = Math.max(1, Math.min(64, Integer.parseInt(args[3])));
            } catch (NumberFormatException ignored) {
                amount = 1;
            }
        }

        for (int i = 0; i < amount; i++) {
            giveStack(target, plugin.items().build(def));
        }
        sender.sendMessage(plugin.msg("given", "item", def.id(), "player", target.getName()));
        target.sendMessage(plugin.msg("received", "item", def.id()));
    }

    private void giveSet(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(plugin.msg("usage-giveset"));
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(plugin.msg("player-not-found", "player", args[1]));
            return;
        }
        SetDef set = plugin.items().getSet(args[2].toLowerCase(Locale.ROOT));
        if (set == null) {
            sender.sendMessage(plugin.msg("unknown-set", "id", args[2]));
            return;
        }

        for (String pieceId : set.pieces()) {
            ItemDef def = plugin.items().get(pieceId);
            if (def != null) {
                giveStack(target, plugin.items().build(def));
            }
        }
        sender.sendMessage(plugin.msg("given", "item", "set " + set.id(), "player", target.getName()));
        target.sendMessage(plugin.msg("received", "item", "set " + set.id()));
    }

    private void list(CommandSender sender) {
        sender.sendMessage(plugin.msg("list-header", "count", String.valueOf(plugin.items().itemCount())));
        for (String id : plugin.items().itemIds()) {
            sender.sendMessage(plugin.bar("list-entry", "id", id));
        }
        sender.sendMessage(plugin.msg("list-sets-header", "sets", String.valueOf(plugin.items().setCount())));
        for (String id : plugin.items().setIds()) {
            sender.sendMessage(plugin.bar("list-entry", "id", id));
        }
    }

    private void giveStack(Player target, ItemStack stack) {
        Map<Integer, ItemStack> leftover = target.getInventory().addItem(stack);
        for (ItemStack rest : leftover.values()) {
            target.getWorld().dropItemNaturally(target.getLocation(), rest);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission(PERMISSION)) return out;

        if (args.length == 1) {
            addMatches(out, List.of("give", "giveset", "list", "reload"), args[0]);
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("giveset"))) {
            List<String> names = new ArrayList<>();
            Bukkit.getOnlinePlayers().forEach(p -> names.add(p.getName()));
            addMatches(out, names, args[1]);
        } else if (args.length == 3) {
            if (args[0].equalsIgnoreCase("give")) {
                addMatches(out, plugin.items().itemIds(), args[2]);
            } else if (args[0].equalsIgnoreCase("giveset")) {
                addMatches(out, plugin.items().setIds(), args[2]);
            }
        }
        return out;
    }

    private void addMatches(List<String> out, List<String> options, String typed) {
        String prefix = typed.toLowerCase(Locale.ROOT);
        for (String option : options) {
            if (option.toLowerCase(Locale.ROOT).startsWith(prefix)) {
                out.add(option);
            }
        }
    }
}
