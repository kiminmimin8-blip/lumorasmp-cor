package net.thunderforge.listener;

import net.thunderforge.ThunderForge;
import net.thunderforge.item.ItemDef;
import net.thunderforge.item.SetDef;
import net.thunderforge.skill.GroundSlamSkill;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class SkillListener implements Listener {

    private final ThunderForge plugin;
    private final Map<UUID, Long> lastSneak = new HashMap<>();

    public SkillListener(ThunderForge plugin) {
        this.plugin = plugin;
    }

    /** Skill senjata: klik kanan pakai item di tangan utama. */
    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;

        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        String id = plugin.items().getId(item);
        if (id == null) return;

        ItemDef def = plugin.items().get(id);
        if (def == null || def.skill() == null || def.slot() != EquipmentSlotGroup.MAINHAND) return;
        if (!def.trigger().equals("right_click")) return;

        Player player = event.getPlayer();

        // Jangan nembak skill pas lagi buka chest/pintu/dll (kecuali lagi sneak)
        if (action == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null
                && event.getClickedBlock().getType().isInteractable() && !player.isSneaking()) {
            return;
        }

        plugin.skills().tryCast(player, id, def.skill());
    }

    /**
     * Skill senjata dengan trigger swap_hand: tekan tombol F (tukar tangan) pas item di tangan utama.
     * Dipakai buat item yang klik kanannya udah dipakai plugin lain (mis. mana ability AuraSkills).
     */
    @EventHandler
    public void onSwapHand(PlayerSwapHandItemsEvent event) {
        // getOffHandItem() = item yang barusan ada di tangan utama (akan pindah ke off-hand)
        String id = plugin.items().getId(event.getOffHandItem());
        if (id == null) return;

        ItemDef def = plugin.items().get(id);
        if (def == null || def.skill() == null || def.slot() != EquipmentSlotGroup.MAINHAND) return;
        if (!def.trigger().equals("swap_hand")) return;

        event.setCancelled(true);
        plugin.skills().tryCast(event.getPlayer(), id, def.skill());
    }

    /** Skill set armor: tekan sneak 2x cepat. */
    @EventHandler
    public void onSneak(PlayerToggleSneakEvent event) {
        if (!event.isSneaking()) return;

        Player player = event.getPlayer();
        long now = System.currentTimeMillis();
        Long last = lastSneak.put(player.getUniqueId(), now);
        long window = plugin.getConfig().getLong("double-sneak-window-ms", 400);
        if (last == null || now - last > window) return;

        lastSneak.remove(player.getUniqueId());

        SetDef set = plugin.items().getWornSet(player);
        if (set == null || set.skill() == null) return;
        plugin.skills().tryCast(player, "set:" + set.id(), set.skill());
    }

    /** Ground Slam: nggak boleh kena fall damage pas mendarat. */
    @EventHandler
    public void onFall(EntityDamageEvent event) {
        if (event.getCause() == EntityDamageEvent.DamageCause.FALL
                && event.getEntity() instanceof Player player
                && GroundSlamSkill.isSlamming(player.getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        lastSneak.remove(event.getPlayer().getUniqueId());
    }
}
