package net.thunderforge.skill;

import net.thunderforge.ThunderForge;
import net.thunderforge.util.Fx;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/**
 * Berserker Roar: wind-up singkat (cincin merah menyempit + api), lalu ledakan raungan:
 * damage + knockback + Strength, diikuti gelombang kejut melebar dengan retakan radial.
 */
public final class BerserkerRoarSkill implements Skill {

    private static final int WINDUP_TICKS = 6;
    private static final int WAVE_TICKS = 10;

    @Override
    public String displayName() {
        return "Berserker Roar";
    }

    @Override
    public boolean cast(ThunderForge plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 6);
        double damage = params.getDouble("damage", 4);
        double knockback = params.getDouble("knockback", 1.4);
        int level = Math.max(1, params.getInt("strength-level", 2));
        int ticks = params.getInt("strength-seconds", 8) * 20;

        World world = player.getWorld();
        world.playSound(player.getLocation(), Sound.ENTITY_WARDEN_HEARTBEAT, 1.5f, 0.8f);

        new BukkitRunnable() {
            int tick = 0;
            Location center;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }

                // Fase 1: wind-up. Cincin merah menyempit ke arah player, api naik, aura marah
                if (tick <= WINDUP_TICKS) {
                    Location base = player.getLocation();
                    double p = tick / (double) WINDUP_TICKS;
                    Fx.ringDust(base.clone().add(0, 0.15, 0), radius * (1 - p) + 1.0, 28, Fx.RED);
                    world.spawnParticle(Particle.FLAME, base.clone().add(0, 0.1, 0), 4, 0.5, 0.1, 0.5, 0.02);
                    world.spawnParticle(Particle.ANGRY_VILLAGER, base.clone().add(0, 2.2, 0), 1, 0.3, 0.1, 0.3, 0);
                    if (tick == WINDUP_TICKS) {
                        center = base.clone();
                        blast(player, center, radius, damage, knockback, level, ticks);
                    }
                    return;
                }

                // Fase 2: gelombang kejut melebar + 8 retakan radial di tanah
                int w = tick - WINDUP_TICKS;
                double r = radius * w / WAVE_TICKS;
                int points = (int) (r * 8) + 12;
                Fx.ringDust(center.clone().add(0, 0.2, 0), r, points, Fx.RED);
                Fx.ring(center.clone().add(0, 0.5, 0), r * 0.9, points, Particle.CLOUD);
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4 + 0.2;
                    Vector dir = new Vector(Math.cos(a), 0, Math.sin(a));
                    Location from = center.clone().add(dir.clone().multiply(Math.max(0, r - 2))).add(0, 0.2, 0);
                    Location to = center.clone().add(dir.clone().multiply(r)).add(0, 0.2, 0);
                    Fx.line(from, to, Particle.CRIT, 0.5, 0.05);
                }

                if (w >= WAVE_TICKS) {
                    world.spawnParticle(Particle.SONIC_BOOM, center.clone().add(0, 1, 0), 1);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);

        return true;
    }

    private void blast(Player player, Location origin, double radius, double damage,
                       double knockback, int level, int ticks) {
        World world = origin.getWorld();

        for (Entity e : player.getNearbyEntities(radius, radius / 2, radius)) {
            if (!(e instanceof LivingEntity living) || e instanceof ArmorStand) continue;
            if (e instanceof Player other && other.getGameMode() == GameMode.SPECTATOR) continue;

            Vector push = e.getLocation().toVector().subtract(origin.toVector());
            push.setY(0);
            if (push.lengthSquared() < 0.01) {
                push = new Vector(0, 0, 1);
            }
            push.normalize().multiply(knockback).setY(0.45);
            living.setVelocity(push);
            living.damage(damage, player);
        }

        player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, ticks, level - 1));

        world.playSound(origin, Sound.ENTITY_RAVAGER_ROAR, 1.3f, 0.8f);
        world.spawnParticle(Particle.EXPLOSION, origin.clone().add(0, 1, 0), 1);
        world.spawnParticle(Particle.FLAME, origin.clone().add(0, 0.3, 0), 60, 0.3, 0.2, 0.3, 0.25);
    }
}
