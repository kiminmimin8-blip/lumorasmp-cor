package net.thunderforge.skill;

import net.thunderforge.ThunderForge;
import net.thunderforge.util.Fx;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Lightning Strike: busur listrik ke target terdekat, charge-up, lalu petir nyambar dari langit
 * dan loncat (chain) ke beberapa musuh di dekatnya dengan damage lebih kecil.
 */
public final class LightningStrikeSkill implements Skill {

    /** Lama animasi charge sebelum petir nyambar (tick). */
    private static final int CHARGE_TICKS = 12;

    @Override
    public String displayName() {
        return "Lightning Strike";
    }

    @Override
    public boolean cast(ThunderForge plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 10);
        double damage = params.getDouble("damage", 12);
        int chainTargets = params.getInt("chain-targets", 2);
        double chainRange = params.getDouble("chain-range", 6);
        double chainPercent = params.getDouble("chain-percent", 0.6);

        LivingEntity target = null;
        double best = Double.MAX_VALUE;
        for (Entity e : player.getNearbyEntities(radius, radius, radius)) {
            if (!isValid(player, e)) continue;
            double dist = e.getLocation().distanceSquared(player.getLocation());
            if (dist < best) {
                best = dist;
                target = (LivingEntity) e;
            }
        }

        if (target == null) {
            player.sendActionBar(plugin.bar("no-target"));
            return false;
        }

        final LivingEntity victim = target;

        // Busur listrik dari player ke target, lalu target di-charge sebelum disambar
        Fx.bolt(player.getLocation().add(0, 1.2, 0), victim.getLocation().add(0, 1, 0),
                8, 0.4, Particle.ELECTRIC_SPARK, Fx.CYAN);
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1.0f, 1.8f);

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;
                if (victim.isDead() || !victim.isValid()) {
                    cancel();
                    return;
                }

                Location base = victim.getLocation();
                World world = victim.getWorld();
                double p = tick / (double) CHARGE_TICKS;

                // 3 untai spiral listrik yang menyempit sambil naik + cincin penanda yang mengecil
                for (int i = 0; i < 3; i++) {
                    double angle = tick * 0.7 + i * (2 * Math.PI / 3);
                    double r = 1.8 * (1 - p) + 0.4;
                    Location at = base.clone().add(Math.cos(angle) * r, p * 2.4, Math.sin(angle) * r);
                    Fx.dust(at, Fx.CYAN);
                    world.spawnParticle(Particle.ELECTRIC_SPARK, at, 1, 0, 0, 0, 0);
                }
                Fx.ringDust(base.clone().add(0, 0.1, 0), 2.2 * (1 - p) + 0.5, 16, Fx.CYAN);
                world.playSound(base, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.7f, 0.6f + (float) p);

                if (tick >= CHARGE_TICKS) {
                    cancel();
                    strike(plugin, player, victim, damage, chainTargets, chainRange, chainPercent);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);

        return true;
    }

    private void strike(ThunderForge plugin, Player player, LivingEntity victim, double damage,
                        int chainTargets, double chainRange, double chainPercent) {
        Location base = victim.getLocation();
        World world = victim.getWorld();

        // Petir turun dari langit (visual) + efek petir vanilla (nggak bakar apa-apa)
        Fx.bolt(base.clone().add(0, 16, 0), base.clone().add(0, 0.2, 0), 10, 0.8,
                Particle.ELECTRIC_SPARK, Fx.WHITE);
        world.strikeLightningEffect(base);
        hit(player, victim, damage);
        impactFx(plugin, base);
        world.playSound(base, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 1.2f);

        // Chain: loncat ke musuh terdekat dari korban pertama, dengan jeda antar loncatan
        List<LivingEntity> chain = new ArrayList<>();
        for (Entity e : victim.getNearbyEntities(chainRange, chainRange, chainRange)) {
            if (e.equals(victim) || !isValid(player, e)) continue;
            chain.add((LivingEntity) e);
        }
        chain.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(base)));

        Location[] previous = {base.clone().add(0, 1, 0)};
        int count = Math.min(chainTargets, chain.size());
        for (int i = 0; i < count; i++) {
            final LivingEntity next = chain.get(i);
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (next.isDead() || !next.isValid()) return;
                Location to = next.getLocation().add(0, 1, 0);
                Fx.bolt(previous[0], to, 6, 0.35, Particle.ELECTRIC_SPARK, Fx.CYAN);
                hit(player, next, damage * chainPercent);
                impactFx(plugin, next.getLocation());
                next.getWorld().playSound(to, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.7f, 1.6f);
                previous[0] = to;
            }, 3L * (i + 1));
        }
    }

    private void impactFx(ThunderForge plugin, Location base) {
        Fx.burst(base.clone().add(0, 1, 0), Particle.ELECTRIC_SPARK, 50, 0.4);
        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                t++;
                Fx.ringDust(base.clone().add(0, 0.15, 0), t * 0.8, 10 + t * 6, Fx.CYAN);
                if (t >= 5) cancel();
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void hit(Player player, LivingEntity target, double amount) {
        if (player.isOnline()) {
            target.damage(amount, player);
        } else {
            target.damage(amount);
        }
    }

    private static boolean isValid(Player caster, Entity e) {
        if (!(e instanceof LivingEntity) || e instanceof ArmorStand || e.equals(caster)) return false;
        return !(e instanceof Player other && other.getGameMode() == GameMode.SPECTATOR);
    }
}
