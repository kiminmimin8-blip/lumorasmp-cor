package net.thunderforge.skill;

import net.thunderforge.ThunderForge;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public interface Skill {

    /** Nama yang tampil di actionbar. */
    String displayName();

    /**
     * Jalanin skill.
     *
     * @return true kalau skill berhasil kepakai (cooldown baru mulai), false kalau batal
     */
    boolean cast(ThunderForge plugin, Player player, ConfigurationSection params);
}
