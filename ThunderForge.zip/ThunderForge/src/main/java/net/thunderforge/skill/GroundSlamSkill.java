package net.thunderforge.skill;

import net.thunderforge.ThunderForge;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class GroundSlamSkill implements Skill {

    /** Player yang lagi di tengah slam (buat batalin fall damage). */
    private static final Set<UUID> SLAMMING = new HashSet<>();

    public static boolean isSlamming(UUID id) {
        return SLAMMING.contains(id);
    }

    @Override
    public String displayName() {
        return "Ground Slam";
    }

    @Override
    public boolean cast(ThunderForge plugin, Player player, ConfigurationSection params) {
        UUID id = player.getUniqueId();
        if (SLAMMING.contains(id)) return false;

        double radius = params.getDouble("radius", 6);
        double damage = params.getDouble("damage", 10);
        double launch = params.getDouble("launch", 1.1);

        SLAMMING.add(id);
        player.setVelocity(new Vector(0, launch, 0));
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WIND_CHARGE_WIND_BURST, 1.2f, 0.9f);

        new BukkitRunnable() {
            int tick = 0;
            boolean diving = false;

            @Override
            public void run() {
                tick++;
                if (!player.isOnline() || player.isDead() || tick > 100) {
                    finish(plugin, id);
                    cancel();
                    return;
                }

                if (!diving) {
                    if (tick >= 10) {
                        diving = true;
                        player.setVelocity(new Vector(0, -1.8, 0));
                    }
                    return;
                }

                Location below = player.getLocation().clone().subtract(0, 0.2, 0);
                if (player.isOnGround() || below.getBlock().getType().isSolid()) {
                    impact(player, radius, damage);
                    finish(plugin, id);
                    cancel();
                } else {
                    player.setVelocity(new Vector(0, -1.8, 0));
                    player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 3, 0.2, 0.1, 0.2, 0.01);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);

        return true;
    }

    /** Flag dilepas agak telat biar fall damage pas mendarat tetap ke-cancel. */
    private void finish(ThunderForge plugin, UUID id) {
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> SLAMMING.remove(id), 5L);
    }

    private void impact(Player player, double radius, double damage) {
        Location loc = player.getLocation();
        World world = player.getWorld();

        for (Entity e : player.getNearbyEntities(radius, radius / 2, radius)) {
            if (!(e instanceof LivingEntity living) || e instanceof ArmorStand) continue;
            if (e instanceof Player other && other.getGameMode() == GameMode.SPECTATOR) continue;
            living.damage(damage, player);
            living.setVelocity(new Vector(0, 0.6, 0));
        }

        world.spawnParticle(Particle.EXPLOSION_EMITTER, loc, 1);
        world.spawnParticle(Particle.CLOUD, loc, 60, radius / 3, 0.2, radius / 3, 0.1);
        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 0.8f);
        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.0f, 1.0f);
    }
}
