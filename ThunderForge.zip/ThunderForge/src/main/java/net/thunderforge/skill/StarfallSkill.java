package net.thunderforge.skill;

import net.thunderforge.ThunderForge;
import net.thunderforge.util.Fx;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Starfall: lingkaran sihir emas berputar (hexagram) muncul di tanah, lalu bintang jatuh
 * bertubi-tubi. Sebagian bintang ngejar posisi musuh (seek-chance), sisanya jatuh acak.
 * Tiap bintang punya penanda berdenyut, ekor komet, dan gelombang kejut pas mendarat.
 */
public final class StarfallSkill implements Skill {

    /** Lama satu bintang jatuh dari langit sampai mendarat (tick). */
    private static final int FALL_TICKS = 8;
    private static final double FALL_HEIGHT = 14;

    @Override
    public String displayName() {
        return "Starfall";
    }

    @Override
    public boolean cast(ThunderForge plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 10);
        int strikes = Math.max(1, params.getInt("strikes", 12));
        int interval = Math.max(1, params.getInt("interval-ticks", 10));
        double impactRadius = params.getDouble("impact-radius", 3);
        double damage = params.getDouble("damage", 7);
        double seekChance = Math.max(0, Math.min(1, params.getDouble("seek-chance", 0.5)));

        // Nggak ada target di area = skill batal, cooldown nggak kepake
        boolean anyTarget = player.getNearbyEntities(radius, radius, radius).stream()
                .anyMatch(e -> e instanceof LivingEntity le && valid(player, le));
        if (!anyTarget) {
            player.sendActionBar(plugin.bar("no-target"));
            return false;
        }

        Location center = player.getLocation().clone();
        World world = center.getWorld();
        world.playSound(center, Sound.BLOCK_BEACON_POWER_SELECT, 1.0f, 1.6f);
        world.playSound(center, Sound.BLOCK_END_PORTAL_SPAWN, 0.4f, 1.8f);

        int duration = 10 + strikes * interval + FALL_TICKS;

        // Lingkaran sihir: cincin emas + cincin putih + hexagram berputar, membesar di awal
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (tick > duration) {
                    cancel();
                    return;
                }
                double cr = Math.min(radius * 0.6, 6.0) * Math.min(1.0, tick / 10.0);
                double rotation = tick * 0.05;
                Location ground = center.clone().add(0, 0.1, 0);

                Fx.ringDust(ground, cr, 40, Fx.GOLD);
                Fx.ringDust(ground, cr * 0.55, 24, Fx.WHITE);
                Fx.star(ground, cr, rotation, 1.2, Fx.GOLD);
                if (tick % 6 == 0) {
                    world.spawnParticle(Particle.END_ROD, center.clone().add(0, 0.2, 0), 6,
                            cr * 0.5, 0.1, cr * 0.5, 0.02);
                }
                tick += 2;
            }
        }.runTaskTimer(plugin, 0L, 2L);

        new BukkitRunnable() {
            int fired = 0;

            @Override
            public void run() {
                if (!player.isOnline() || fired >= strikes) {
                    cancel();
                    return;
                }
                fired++;

                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                Location impact = null;

                // Sebagian bintang ngejar posisi musuh saat ini (musuh masih bisa kabur pas penanda muncul)
                if (rnd.nextDouble() < seekChance) {
                    List<LivingEntity> pool = new ArrayList<>();
                    for (LivingEntity le : world.getNearbyLivingEntities(center, radius)) {
                        if (valid(player, le)) pool.add(le);
                    }
                    if (!pool.isEmpty()) {
                        impact = pool.get(rnd.nextInt(pool.size())).getLocation().clone();
                    }
                }

                if (impact == null) {
                    double angle = rnd.nextDouble(0, Math.PI * 2);
                    double dist = Math.sqrt(rnd.nextDouble()) * radius;
                    double x = center.getX() + Math.cos(angle) * dist;
                    double z = center.getZ() + Math.sin(angle) * dist;

                    // Mendarat di permukaan kalau tingginya nggak beda jauh dari posisi cast
                    int surface = world.getHighestBlockYAt((int) Math.floor(x), (int) Math.floor(z)) + 1;
                    double y = Math.abs(surface - center.getY()) <= 3 ? surface : center.getY();
                    impact = new Location(world, x, y, z);
                }

                spawnFallingStar(plugin, player, impact, impactRadius, damage);
            }
        }.runTaskTimer(plugin, 10L, interval);

        return true;
    }

    private void spawnFallingStar(ThunderForge plugin, Player player, Location impact,
                                  double impactRadius, double damage) {
        World world = impact.getWorld();
        world.playSound(impact, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.8f, 1.5f);

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                tick++;

                // Penanda: cincin merah berdenyut + cincin emas tetap di batas ledakan
                double pulse = impactRadius * (0.65 + 0.35 * Math.abs(Math.sin(tick * 0.8)));
                Fx.ringDust(impact.clone().add(0, 0.1, 0), pulse, 18, Fx.RED);
                Fx.ringDust(impact.clone().add(0, 0.1, 0), impactRadius, 18, Fx.GOLD);

                // Bintang jatuh + ekor komet
                double h = FALL_HEIGHT * (1 - (double) tick / FALL_TICKS);
                Location star = impact.clone().add(0, h, 0);
                world.spawnParticle(Particle.END_ROD, star, 5, 0.12, 0.12, 0.12, 0.02);
                for (int k = 1; k <= 5; k++) {
                    Fx.dust(star.clone().add(0, k * 0.6, 0), Fx.GOLD);
                }

                if (tick < FALL_TICKS) return;
                cancel();

                // Pendaratan: ledakan, semburan bintang, gelombang kejut emas, suara
                world.spawnParticle(Particle.EXPLOSION, impact, 1);
                Fx.burst(impact.clone().add(0, 0.5, 0), Particle.END_ROD, 40, 0.25);
                new BukkitRunnable() {
                    int t = 0;

                    @Override
                    public void run() {
                        t++;
                        Fx.ringDust(impact.clone().add(0, 0.15, 0), t * impactRadius / 3.0, 20, Fx.GOLD);
                        if (t >= 4) cancel();
                    }
                }.runTaskTimer(plugin, 0L, 1L);

                world.playSound(impact, Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 1.4f);
                world.playSound(impact, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1.0f, 0.9f);
                world.playSound(impact, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 1.4f);

                for (LivingEntity target : world.getNearbyLivingEntities(impact, impactRadius)) {
                    if (!valid(player, target)) continue;
                    if (player.isOnline()) {
                        target.damage(damage, player);
                    } else {
                        target.damage(damage);
                    }
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private static boolean valid(Player caster, LivingEntity e) {
        if (e.equals(caster) || e instanceof ArmorStand) return false;
        return !(e instanceof Player other && other.getGameMode() == GameMode.SPECTATOR);
    }
}
