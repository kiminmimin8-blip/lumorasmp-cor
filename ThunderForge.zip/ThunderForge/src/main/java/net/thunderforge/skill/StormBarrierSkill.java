package net.thunderforge.skill;

import net.thunderforge.ThunderForge;
import net.thunderforge.util.Fx;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Storm Barrier: petir di 4 arah + pulsa melebar, kubah listrik dibangun dari bawah ke atas,
 * lalu 3 bola listrik berekor ngorbit, heliks di kaki, dan busur listrik acak selama buff aktif.
 */
public final class StormBarrierSkill implements Skill {

    /** Radius kubah visual di sekeliling player. */
    private static final double DOME = 2.2;

    @Override
    public String displayName() {
        return "Storm Barrier";
    }

    @Override
    public boolean cast(ThunderForge plugin, Player player, ConfigurationSection params) {
        double radius = params.getDouble("radius", 6);
        double damage = params.getDouble("damage", 3);
        double knockback = params.getDouble("knockback", 1.2);
        int absorption = Math.max(1, params.getInt("absorption-level", 2));
        int resistance = Math.max(1, params.getInt("resistance-level", 2));
        int ticks = params.getInt("seconds", 8) * 20;

        Location origin = player.getLocation();
        World world = player.getWorld();

        player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, ticks, absorption - 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, ticks, resistance - 1));

        for (Entity e : player.getNearbyEntities(radius, radius / 2, radius)) {
            if (!(e instanceof LivingEntity living) || e instanceof ArmorStand) continue;
            if (e instanceof Player other && other.getGameMode() == GameMode.SPECTATOR) continue;

            Vector push = e.getLocation().toVector().subtract(origin.toVector());
            push.setY(0);
            if (push.lengthSquared() < 0.01) {
                push = new Vector(0, 0, 1);
            }
            push.normalize().multiply(knockback).setY(0.35);
            living.setVelocity(push);
            if (damage > 0) {
                living.damage(damage, player);
            }
        }

        // Petir visual di 4 arah (efek doang) + suara aktivasi
        double ringDist = Math.min(3.0, radius / 2);
        world.strikeLightningEffect(origin.clone().add(ringDist, 0, 0));
        world.strikeLightningEffect(origin.clone().add(-ringDist, 0, 0));
        world.strikeLightningEffect(origin.clone().add(0, 0, ringDist));
        world.strikeLightningEffect(origin.clone().add(0, 0, -ringDist));
        world.playSound(origin, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.0f, 1.3f);
        world.playSound(origin, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.5f);

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead() || tick > ticks) {
                    if (player.isOnline() && !player.isDead()) {
                        Location end = player.getLocation().add(0, 1, 0);
                        Fx.burst(end, Particle.END_ROD, 40, 0.3);
                        Fx.burst(end, Particle.ELECTRIC_SPARK, 40, 0.4);
                        world.playSound(end, Sound.BLOCK_BEACON_DEACTIVATE, 1.0f, 1.4f);
                    }
                    cancel();
                    return;
                }

                Location base = player.getLocation();

                // 1. Pulsa melebar sekali di awal (8 tick pertama)
                if (tick < 8) {
                    double r = radius * (tick / 2 + 1) / 4.0;
                    Fx.ringDust(origin.clone().add(0, 0.2, 0), r, (int) (r * 8) + 12, Fx.CYAN);
                }

                // 2. Kubah dibangun dari bawah ke atas (12 tick pertama), lalu dijaga tipis-tipis
                if (tick <= 12) {
                    double top = DOME * tick / 12.0;
                    for (double y = 0.2; y <= top; y += 0.55) {
                        double rr = Math.sqrt(Math.max(0, DOME * DOME - (y - 1.1) * (y - 1.1)));
                        Fx.ringDust(base.clone().add(0, y, 0), rr, 20, Fx.CYAN);
                    }
                } else if (tick % 4 == 0) {
                    Fx.sphere(base.clone().add(0, 1.1, 0), DOME, 10, Particle.ELECTRIC_SPARK);
                }

                // 3. Tiga bola listrik ngorbit lengkap dengan ekor
                for (int i = 0; i < 3; i++) {
                    double angle = tick * 0.25 + i * (2 * Math.PI / 3);
                    double h = 1.1 + Math.sin(tick * 0.15 + i) * 0.8;
                    for (int k = 0; k < 3; k++) {
                        double a = angle - k * 0.18;
                        Location p = base.clone().add(Math.cos(a) * 1.6, h, Math.sin(a) * 1.6);
                        if (k == 0) {
                            world.spawnParticle(Particle.ELECTRIC_SPARK, p, 2, 0.05, 0.05, 0.05, 0);
                            world.spawnParticle(Particle.END_ROD, p, 1, 0, 0, 0, 0);
                        } else {
                            Fx.dust(p, Fx.CYAN);
                        }
                    }
                }

                // 4. Heliks putih naik dari kaki
                for (int i = 0; i < 2; i++) {
                    double a = tick * 0.4 + i * Math.PI;
                    double hh = (tick * 0.08) % DOME;
                    Fx.dust(base.clone().add(Math.cos(a) * 0.9, hh, Math.sin(a) * 0.9), Fx.WHITE);
                }

                // 5. Busur listrik acak antar dua titik di kubah, sekitar tiap 1 detik
                if (tick > 12 && tick % 20 == 0) {
                    Fx.bolt(randomOnDome(base), randomOnDome(base), 5, 0.25, Particle.ELECTRIC_SPARK, Fx.CYAN);
                    world.playSound(base, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 0.6f, 1.8f);
                }

                tick += 2;
            }
        }.runTaskTimer(plugin, 0L, 2L);

        return true;
    }

    private static Location randomOnDome(Location base) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        double x, y, z, len;
        do {
            x = rnd.nextGaussian();
            y = rnd.nextGaussian();
            z = rnd.nextGaussian();
            len = Math.sqrt(x * x + y * y + z * z);
        } while (len < 1e-6);
        return base.clone().add(x / len * DOME, 1.1 + y / len * DOME, z / len * DOME);
    }
}
