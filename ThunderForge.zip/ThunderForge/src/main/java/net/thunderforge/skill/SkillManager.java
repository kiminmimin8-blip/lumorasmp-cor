package net.thunderforge.skill;

import net.thunderforge.ThunderForge;
import net.thunderforge.item.SkillSpec;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class SkillManager {

    private final ThunderForge plugin;
    private final Map<String, Skill> skills = new HashMap<>();
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    public SkillManager(ThunderForge plugin) {
        this.plugin = plugin;
        register("lightning_strike", new LightningStrikeSkill());
        register("berserker_roar", new BerserkerRoarSkill());
        register("ground_slam", new GroundSlamSkill());
        register("storm_barrier", new StormBarrierSkill());
        register("starfall", new StarfallSkill());
    }

    private void register(String type, Skill skill) {
        skills.put(type, skill);
    }

    /**
     * Coba pakai skill. cooldownKey dipakai buat misahin cooldown per item / per set.
     */
    public void tryCast(Player player, String cooldownKey, SkillSpec spec) {
        Skill skill = skills.get(spec.type());
        if (skill == null) {
            plugin.getLogger().warning("Tipe skill nggak dikenal: " + spec.type());
            return;
        }

        long now = System.currentTimeMillis();
        Map<String, Long> mine = cooldowns.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>());
        long until = mine.getOrDefault(cooldownKey, 0L);
        if (until > now) {
            long left = (until - now + 999) / 1000;
            player.sendActionBar(plugin.bar("cooldown", "time", String.valueOf(left)));
            return;
        }

        if (skill.cast(plugin, player, spec.params())) {
            mine.put(cooldownKey, now + spec.cooldown() * 1000L);
            player.sendActionBar(plugin.bar("skill-used", "skill", skill.displayName()));
        }
    }
}
