package net.thunderforge;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.thunderforge.command.CustomItemCommand;
import net.thunderforge.item.ItemManager;
import net.thunderforge.listener.SkillListener;
import net.thunderforge.skill.SkillManager;
import net.thunderforge.task.SetBonusTask;
import org.bukkit.plugin.java.JavaPlugin;

public final class ThunderForge extends JavaPlugin {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private ItemManager itemManager;
    private SkillManager skillManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new java.io.File(getDataFolder(), "items.yml").exists()) {
            saveResource("items.yml", false);
        }

        itemManager = new ItemManager(this);
        skillManager = new SkillManager(this);
        itemManager.load();

        getServer().getPluginManager().registerEvents(new SkillListener(this), this);

        CustomItemCommand command = new CustomItemCommand(this);
        var cmd = getCommand("customitem");
        if (cmd != null) {
            cmd.setExecutor(command);
            cmd.setTabCompleter(command);
        }

        new SetBonusTask(this).runTaskTimer(this, 40L, 40L);
        getLogger().info("ThunderForge aktif: " + itemManager.itemCount() + " item, "
                + itemManager.setCount() + " set.");
    }

    public void reloadAll() {
        reloadConfig();
        itemManager.load();
    }

    public ItemManager items() {
        return itemManager;
    }

    public SkillManager skills() {
        return skillManager;
    }

    /** Pesan dengan prefix (chat). */
    public Component msg(String key, String... pairs) {
        return MM.deserialize(getConfig().getString("prefix", "") + raw(key, pairs));
    }

    /** Pesan tanpa prefix (actionbar). */
    public Component bar(String key, String... pairs) {
        return MM.deserialize(raw(key, pairs));
    }

    private String raw(String key, String... pairs) {
        String text = getConfig().getString("messages." + key, "<red>pesan hilang: " + key);
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            text = text.replace("{" + pairs[i] + "}", pairs[i + 1]);
        }
        return text;
    }
}
