# ThunderForge

Plugin Paper 1.21.11 buat item custom bertema badai: 3 senjata + 1 set armor, semuanya punya skill aktif.

## Item

| ID | Item | Skill | Trigger |
|---|---|---|---|
| `stormbrand` | Netherite Sword | Lightning Strike | Tombol F |
| `tempest_cleaver` | Netherite Axe | Berserker Roar | Tombol F |
| `stormheart` | Nether Star | Starfall | Klik kanan |
| `stormguard_*` (4 piece) | Netherite armor | Storm Barrier + Speed I & Regen I pasif | Sneak 2x (set penuh) |

Semua skill cooldown 60 detik, nggak butuh permission. Pedang dan kapak pakai tombol F (swap hand) supaya klik kanannya tetap bebas buat mana ability AuraSkills (Lightning Blade / Treecapitator); trigger bisa diganti per item lewat `trigger:` di `items.yml`. Tiap skill punya animasi partikel + suara bertahap: Lightning Strike (charge-up, petir dari langit, loncat ke 2 musuh lain), Berserker Roar (wind-up lalu gelombang kejut dengan retakan), Storm Barrier (kubah listrik dengan bola ngorbit), Starfall (lingkaran sihir hexagram, bintang jatuh berekor, sebagian ngejar musuh).

## Command

- `/customitem give <player> <id> [jumlah]`
- `/customitem giveset <player> <set>` (contoh: `stormguard`)
- `/customitem list`
- `/customitem reload`

Alias: `/citem`. Permission command: `customitem.admin` (default OP).

## Build

```
mvn clean package
```

Jar ada di `target/ThunderForge-1.0.0.jar`, taruh di folder `plugins/`. Butuh Java 21.

## Config

- `config.yml` : pesan, prefix, cooldown default, jendela double-sneak
- `items.yml` : definisi item, atribut, skill, dan set armor

Nilai `attributes` di `items.yml` itu modifier (damage total - 1, attack speed total - 4), dan atribut bawaan item vanilla digantikan semuanya. Detail ada di komentar di file-nya.
