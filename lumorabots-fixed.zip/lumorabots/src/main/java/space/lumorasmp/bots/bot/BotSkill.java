package space.lumorasmp.bots.bot;

/**
 * Skills that can be attached to a MYTHICMOB-type bot via
 * /bot edit <name> skills add/remove <skill>. BotCombatEngine rolls one of the
 * bot's assigned skills (on cooldown) each time it's in combat, in addition to
 * its normal melee attack.
 */
public enum BotSkill {

    FIREBALL("§6Fireball", "Nembak fireball dari jarak jauh, ledakan kecil (gak ngerusak block)."),
    POISON_CLOUD("§2Poison Cloud", "Nyebarin awan racun di sekitar target saat kena hit jarak dekat."),
    LEAP_STRIKE("§bLeap Strike", "Lompat ke arah target lalu nge-slam, damage bonus + knockback gede."),
    LIFE_DRAIN("§5Life Drain", "Nyerap sebagian damage yang dikasih ke HP bot sendiri."),
    STUN_SLAM("§eStun Slam", "Slam area kecil yang bikin target kena Slowness+Weakness sebentar.");

    private final String displayName;
    private final String description;

    BotSkill(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String displayName() {
        return displayName;
    }

    public String description() {
        return description;
    }

    public static BotSkill fromString(String input) {
        if (input == null) return null;
        String s = input.trim().toUpperCase();
        for (BotSkill skill : values()) {
            if (skill.name().equals(s)) return skill;
        }
        // shorthand aliases
        return switch (s) {
            case "FIRE", "FIREBALL" -> FIREBALL;
            case "POISON", "POISONCLOUD" -> POISON_CLOUD;
            case "LEAP", "LEAPSTRIKE" -> LEAP_STRIKE;
            case "DRAIN", "LIFEDRAIN" -> LIFE_DRAIN;
            case "STUN", "STUNSLAM" -> STUN_SLAM;
            default -> null;
        };
    }
}
