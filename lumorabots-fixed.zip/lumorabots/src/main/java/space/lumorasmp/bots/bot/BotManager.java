package space.lumorasmp.bots.bot;

import de.oliver.fancynpcs.api.FancyNpcsPlugin;
import de.oliver.fancynpcs.api.Npc;
import de.oliver.fancynpcs.api.NpcData;
import de.oliver.fancynpcs.api.utils.NpcEquipmentSlot;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import space.lumorasmp.bots.combat.BotRuntime;
import space.lumorasmp.bots.storage.BotStorage;

import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BotManager {

    private final Map<String, BotData> bots = new LinkedHashMap<>();
    private final Map<String, BotRuntime> runtime = new LinkedHashMap<>();
    private final BotStorage storage;
    private final Logger logger;

    public BotManager(BotStorage storage, Logger logger) {
        this.storage = storage;
        this.logger = logger;
        this.bots.putAll(storage.loadAll());
    }

    public void saveAll() {
        storage.saveAll(bots);
    }

    public static String key(String name) {
        return name.toLowerCase();
    }

    public Optional<BotData> get(String name) {
        return Optional.ofNullable(bots.get(key(name)));
    }

    public boolean exists(String name) {
        return bots.containsKey(key(name));
    }

    public Map<String, BotData> all() {
        return bots;
    }

    /** /bot spawner create <tier> <type> <name> - defines a new bot (not spawned yet). */
    public BotData createDefinition(String name, BotTier tier, BotType type) {
        BotData data = new BotData(key(name), name, type, tier);
        bots.put(data.getId(), data);
        saveAll();
        return data;
    }

    /** /bot spawn <name> - spawns (or respawns) the NPC at the given location. */
    public boolean spawn(String name, Location location, UUID creator) {
        BotData data = bots.get(key(name));
        if (data == null) return false;

        // if already spawned somewhere, remove old npc entity first
        despawnNpcOnly(data);

        NpcData npcData = new NpcData(data.getId(), creator, location);
        applySkinSafely(npcData, data);
        npcData.setDisplayName(colorize(data.getDisplayName()));

        // FancyNpcs' NpcData uses its own NpcEquipmentSlot enum (not Bukkit's EquipmentSlot),
        // so we bridge our Bukkit-based equipment map through toNpcEquipment() below.
        npcData.getEquipment().putAll(toNpcEquipment(data.getEquipment()));

        Npc npc = FancyNpcsPlugin.get().getNpcAdapter().apply(npcData);
        FancyNpcsPlugin.get().getNpcManager().registerNpc(npc);
        npc.create();
        npc.spawnForAll();

        World world = location.getWorld();
        data.setLocation(world != null ? world.getName() : "world",
                location.getX(), location.getY(), location.getZ(),
                location.getYaw(), location.getPitch());
        data.setSpawned(true);
        runtime.put(data.getId(), new BotRuntime(data.getMaxHealth()));
        saveAll();
        return true;
    }

    /** /bot despawn <name> - removes the visible NPC but keeps the saved definition. */
    public boolean despawn(String name) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        despawnNpcOnly(data);
        data.setSpawned(false);
        saveAll();
        return true;
    }

    private void despawnNpcOnly(BotData data) {
        Npc npc = FancyNpcsPlugin.get().getNpcManager().getNpc(data.getId());
        if (npc != null) {
            npc.removeForAll();
            FancyNpcsPlugin.get().getNpcManager().removeNpc(npc);
        }
        runtime.remove(data.getId());
    }

    /** /bot remove <name> - deletes the bot entirely (npc + saved data). */
    public boolean remove(String name) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        despawnNpcOnly(data);
        bots.remove(data.getId());
        saveAll();
        return true;
    }

    /** /bot rename <name> <newName> - changes only the display name (the internal id stays the same). */
    public boolean rename(String name, String newDisplayName) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        data.setDisplayName(newDisplayName);
        refreshVisual(data);
        saveAll();
        return true;
    }

    /** /bot skin <name> <skin> */
    public boolean setSkin(String name, String skin) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        data.setSkin(skin);
        refreshVisual(data);
        saveAll();
        return true;
    }

    public boolean setTier(String name, BotTier tier, boolean resetHealthToDefault) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        data.setTier(tier);
        if (resetHealthToDefault) data.setMaxHealth(tier.defaultHealth());
        saveAll();
        return true;
    }

    public boolean setType(String name, BotType type) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        data.setType(type);
        saveAll();
        return true;
    }

    public boolean setHealth(String name, double health) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        data.setMaxHealth(health);
        saveAll();
        return true;
    }

    public boolean addSkill(String name, BotSkill skill) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        data.addSkill(skill);
        saveAll();
        return true;
    }

    public boolean removeSkill(String name, BotSkill skill) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        data.removeSkill(skill);
        saveAll();
        return true;
    }

    public boolean setEquipmentPiece(String name, EquipmentSlot slot, ItemStack item) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        data.setEquipmentPiece(slot, item);
        refreshVisual(data);
        saveAll();
        return true;
    }

    /** Pushes displayName/skin/equipment changes to the live NPC, if it's currently spawned. */
    private void refreshVisual(BotData data) {
        Npc npc = FancyNpcsPlugin.get().getNpcManager().getNpc(data.getId());
        if (npc == null) return;
        NpcData npcData = npc.getData();
        npcData.setDisplayName(colorize(data.getDisplayName()));
        applySkinSafely(npcData, data);
        npcData.getEquipment().clear();
        npcData.getEquipment().putAll(toNpcEquipment(data.getEquipment()));
        // skin/equipment changes generally need a respawn to show correctly
        npc.removeForAll();
        npc.spawnForAll();
    }

    /**
     * Bridges our Bukkit-based equipment map to FancyNpcs' own NpcEquipmentSlot enum.
     * Uses valueOf(String) against a small name table instead of a hardcoded switch,
     * so this keeps compiling even if a future FancyNpcs version renames a constant -
     * unmatched slots are just skipped (logged once) instead of crashing.
     */
    private Map<NpcEquipmentSlot, ItemStack> toNpcEquipment(Map<EquipmentSlot, ItemStack> source) {
        Map<NpcEquipmentSlot, ItemStack> result = new EnumMap<>(NpcEquipmentSlot.class);
        for (Map.Entry<EquipmentSlot, ItemStack> entry : source.entrySet()) {
            NpcEquipmentSlot mapped = mapSlot(entry.getKey());
            if (mapped != null) {
                result.put(mapped, entry.getValue());
            }
        }
        return result;
    }

    private NpcEquipmentSlot mapSlot(EquipmentSlot bukkitSlot) {
        String[] candidates = switch (bukkitSlot) {
            case HEAD -> new String[]{"HELMET", "HEAD"};
            case CHEST -> new String[]{"CHESTPLATE", "CHEST"};
            case LEGS -> new String[]{"LEGGINGS", "LEGS"};
            case FEET -> new String[]{"BOOTS", "FEET"};
            case HAND -> new String[]{"MAINHAND", "HAND"};
            case OFF_HAND -> new String[]{"OFFHAND", "OFF_HAND"};
            default -> new String[0];
        };
        for (String candidate : candidates) {
            try {
                return NpcEquipmentSlot.valueOf(candidate);
            } catch (IllegalArgumentException ignored) {
                // try next candidate name
            }
        }
        logger.log(Level.WARNING, "Gak nemu NpcEquipmentSlot yang cocok buat " + bukkitSlot
                + " - equipment slot ini dilewati. Cek versi FancyNpcs kamu.");
        return null;
    }

    /**
     * Sets the NPC's skin, catching any failure (invalid/unknown username, Mojang API
     * down or unreachable, etc.) instead of letting it bubble up and crash the whole
     * /bot command - the bot still spawns, just with the default Steve skin.
     */
    private void applySkinSafely(NpcData npcData, BotData data) {
        if (data.getSkin() == null || data.getSkin().isBlank()) return;
        try {
            npcData.setSkin(data.getSkin());
        } catch (Exception e) {
            logger.log(Level.WARNING, "Gagal ambil skin '" + data.getSkin() + "' buat bot '"
                    + data.getDisplayName() + "' (" + e.getMessage() + "). Pakai skin default Steve dulu.");
        }
    }

    private String colorize(String input) {
        return input == null ? "" : input.replace('&', '\u00A7');
    }

    // ---- helpers used by BotCombatEngine ----

    public Optional<BotRuntime> getRuntime(String id) {
        return Optional.ofNullable(runtime.get(key(id)));
    }

    /** All bot ids that currently have a live NPC + runtime state. */
    public java.util.Set<String> activeIds() {
        return runtime.keySet();
    }

    public Npc getNpc(String id) {
        return FancyNpcsPlugin.get().getNpcManager().getNpc(key(id));
    }

    /**
     * Moves the NPC to a new location. The Npc object itself has no public teleport()
     * method - position lives on NpcData, so we mutate that and push it to viewers with
     * updateForAll() (same mechanism the getting-started guide uses for other property
     * changes like displayName/skin).
     */
    public void teleportNpc(String id, Location location) {
        Npc npc = getNpc(id);
        if (npc == null) return;
        npc.getData().setLocation(location);
        npc.updateForAll();

        BotData data = bots.get(key(id));
        if (data != null) {
            World world = location.getWorld();
            data.setLocation(world != null ? world.getName() : data.getWorldName(),
                    location.getX(), location.getY(), location.getZ(),
                    location.getYaw(), location.getPitch());
        }
    }

    /** Re-spawns a dead bot at its configured location with full HP, after a delay is handled by the caller. */
    public void respawnAtHome(String id, UUID summoner) {
        BotData data = bots.get(key(id));
        if (data == null || data.getWorldName() == null) return;
        World world = org.bukkit.Bukkit.getWorld(data.getWorldName());
        if (world == null) return;
        Location loc = new Location(world, data.getX(), data.getY(), data.getZ(), data.getYaw(), data.getPitch());
        spawn(data.getDisplayName(), loc, summoner);
    }
}
