package space.lumorasmp.bots.combat;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import space.lumorasmp.bots.LumoraBots;
import space.lumorasmp.bots.bot.BotData;
import space.lumorasmp.bots.bot.BotManager;
import space.lumorasmp.bots.bot.BotSkill;
import space.lumorasmp.bots.bot.BotType;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Drives all bot combat: find nearest player, walk to them, attack in range.
 * MYTHICMOB-type bots additionally roll one of their assigned BotSkills on cooldown
 * (fireball, leap strike, poison cloud, stun slam, life drain) on top of melee.
 *
 * Ticks are dispatched through Paper's region scheduler so this is safe on both
 * Folia and regular Paper/Purpur builds (Paper backported the same scheduler API).
 */
public class BotCombatEngine {

    private static final long TICK_PERIOD = 4L; // ~0.2s
    private static final double AGGRO_RADIUS = 16.0;
    private static final double ATTACK_RANGE = 2.3;
    private static final long ATTACK_COOLDOWN_MS = 650L;
    private static final long RESPAWN_DELAY_TICKS = 100L; // 5s
    private static final double SKILL_RANGE = 12.0;
    private static final long SKILL_COOLDOWN_MS = 5000L;
    private static final java.util.Random RANDOM = new java.util.Random();

    private final LumoraBots plugin;
    private final BotManager botManager;

    public BotCombatEngine(LumoraBots plugin, BotManager botManager) {
        this.plugin = plugin;
        this.botManager = botManager;
    }

    public void start() {
        plugin.getServer().getGlobalRegionScheduler().runAtFixedRate(plugin, task -> tickAll(), 20L, TICK_PERIOD);
    }

    private void tickAll() {
        for (String id : List.copyOf(botManager.activeIds())) {
            Optional<BotData> dataOpt = botManager.get(id);
            Optional<BotRuntime> runtimeOpt = botManager.getRuntime(id);
            if (dataOpt.isEmpty() || runtimeOpt.isEmpty()) continue;

            BotData data = dataOpt.get();
            if (data.getWorldName() == null) continue;

            World world = plugin.getServer().getWorld(data.getWorldName());
            if (world == null) continue;

            Location botLoc = new Location(world, data.getX(), data.getY(), data.getZ(), data.getYaw(), data.getPitch());

            // dispatch the actual movement/attack logic onto the region that owns the bot's current location
            plugin.getServer().getRegionScheduler().run(plugin, botLoc, task -> tickOne(id, data, runtimeOpt.get(), botLoc));
        }
    }

    private void tickOne(String id, BotData data, BotRuntime rt, Location botLoc) {
        if (rt.getCurrentHealth() <= 0) return; // waiting on respawn task

        Player target = findNearestPlayer(botLoc);
        if (target == null) {
            rt.setTargetPlayer(null);
            return;
        }
        rt.setTargetPlayer(target.getUniqueId());

        Location targetLoc = target.getLocation();
        double distance = botLoc.distance(targetLoc);

        if (distance <= ATTACK_RANGE) {
            faceTowards(id, botLoc, targetLoc);
            if (rt.canAttack(ATTACK_COOLDOWN_MS)) {
                attack(data, rt, target);
            }
        } else {
            moveTowards(id, data, botLoc, targetLoc);
        }

        if (data.getType() == BotType.MYTHICMOB && !data.getSkills().isEmpty()
                && distance <= SKILL_RANGE && rt.canCastSkill(skillCooldownFor(data))) {
            castRandomSkill(data, rt, botLoc, target, distance);
        }
    }

    private Player findNearestPlayer(Location botLoc) {
        Player nearest = null;
        double nearestDist = AGGRO_RADIUS;
        for (Player p : botLoc.getWorld().getPlayers()) {
            if (p.getGameMode() == org.bukkit.GameMode.CREATIVE || p.getGameMode() == org.bukkit.GameMode.SPECTATOR) continue;
            double d = p.getLocation().distance(botLoc);
            if (d <= nearestDist) {
                nearest = p;
                nearestDist = d;
            }
        }
        return nearest;
    }

    private void moveTowards(String id, BotData data, Location from, Location to) {
        double speed = speedFor(data); // blocks per tick-batch (TICK_PERIOD ticks)
        Vector dir = to.toVector().subtract(from.toVector());
        dir.setY(0);
        if (dir.lengthSquared() < 0.0001) return;
        dir.normalize().multiply(speed);

        Location next = from.clone().add(dir);
        next.setY(to.getY()); // foundation phase: no real pathfinding/terrain following yet
        faceLocationTowards(next, to);

        botManager.teleportNpc(id, next);
    }

    private void faceTowards(String id, Location from, Location to) {
        Location facing = from.clone();
        faceLocationTowards(facing, to);
        botManager.teleportNpc(id, facing);
    }

    private void faceLocationTowards(Location loc, Location lookAt) {
        Vector dir = lookAt.toVector().subtract(loc.toVector());
        if (dir.lengthSquared() < 0.0001) return;
        double yaw = Math.toDegrees(Math.atan2(-dir.getX(), dir.getZ()));
        loc.setYaw((float) yaw);
        loc.setPitch(0f);
    }

    private double speedFor(BotData data) {
        return switch (data.getTier()) {
            case TIER_1 -> 0.28;
            case TIER_2 -> 0.34;
            case TIER_3 -> 0.42;
        };
    }

    private long skillCooldownFor(BotData data) {
        // higher tier = casts skills more often
        return switch (data.getTier()) {
            case TIER_1 -> SKILL_COOLDOWN_MS + 2000L;
            case TIER_2 -> SKILL_COOLDOWN_MS;
            case TIER_3 -> SKILL_COOLDOWN_MS - 1500L;
        };
    }

    /** Rolls one of the bot's assigned skills that's actually usable at the current range and casts it. */
    private void castRandomSkill(BotData data, BotRuntime rt, Location botLoc, Player target, double distance) {
        List<BotSkill> usable = new ArrayList<>();
        for (BotSkill skill : data.getSkills()) {
            boolean fits = switch (skill) {
                case FIREBALL, LEAP_STRIKE -> distance > ATTACK_RANGE; // ranged / gap-closer
                case POISON_CLOUD, STUN_SLAM -> distance <= ATTACK_RANGE + 1.5; // close-range AoE
                case LIFE_DRAIN -> false; // passive, applied inside attack() instead
            };
            if (fits) usable.add(skill);
        }
        if (usable.isEmpty()) return;

        BotSkill chosen = usable.get(RANDOM.nextInt(usable.size()));
        rt.markSkillCast();

        switch (chosen) {
            case FIREBALL -> castFireball(data, botLoc, target);
            case LEAP_STRIKE -> castLeapStrike(data, rt, botLoc, target);
            case POISON_CLOUD -> castPoisonCloud(data, botLoc, target);
            case STUN_SLAM -> castStunSlam(data, botLoc, target);
            case LIFE_DRAIN -> {} // unreachable, filtered out above
        }
    }

    private void castFireball(BotData data, Location botLoc, Player target) {
        World world = botLoc.getWorld();
        if (world == null) return;
        Location origin = botLoc.clone().add(0, 1.4, 0);
        Vector direction = target.getEyeLocation().toVector().subtract(origin.toVector()).normalize();

        Fireball fireball = world.spawn(origin, Fireball.class, fb -> {
            fb.setDirection(direction);
            fb.setYield(0f);          // no block damage
            fb.setIsIncendiary(false); // no fire
            fb.setVelocity(direction.multiply(1.1));
        });

        broadcastNear(botLoc, "\u00A76" + data.getDisplayName() + " \u00A7cnembak fireball!");
    }

    private void castLeapStrike(BotData data, BotRuntime rt, Location botLoc, Player target) {
        World world = botLoc.getWorld();
        if (world == null) return;

        Vector dir = target.getLocation().toVector().subtract(botLoc.toVector());
        double distance = dir.length();
        if (distance < 0.01) return;

        // leap ~70% of the way to the target, capped so it doesn't overshoot into melee range instantly
        double leapDistance = Math.min(distance * 0.7, 8.0);
        Vector step = dir.normalize().multiply(leapDistance);
        Location landing = botLoc.clone().add(step);
        landing.setY(Math.max(landing.getY(), target.getLocation().getY()));

        botManager.teleportNpc(data.getId(), landing);
        world.spawnParticle(Particle.CLOUD, botLoc, 12, 0.3, 0.1, 0.3, 0.02);
        world.spawnParticle(Particle.CLOUD, landing, 12, 0.3, 0.1, 0.3, 0.02);

        // if the leap landed within melee range, follow up with a bonus hit next attack tick
        if (landing.distance(target.getLocation()) <= ATTACK_RANGE + 1.0 && rt.canAttack(ATTACK_COOLDOWN_MS)) {
            attack(data, rt, target);
        }
        broadcastNear(botLoc, "\u00A7b" + data.getDisplayName() + " \u00A7fmelompat ke arahmu!");
    }

    private void castPoisonCloud(BotData data, Location botLoc, Player target) {
        World world = botLoc.getWorld();
        if (world == null) return;
        int amplifier = data.getTier().level() - 1; // Tier I = Poison I, Tier III = Poison III
        int durationTicks = 60 + data.getTier().level() * 20;

        for (Player p : world.getPlayers()) {
            if (p.getLocation().distance(botLoc) <= 3.5) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, durationTicks, Math.max(0, amplifier)));
            }
        }
        world.spawnParticle(Particle.ITEM_SLIME, botLoc.clone().add(0, 1, 0), 25, 1.2, 0.5, 1.2, 0.02);
        broadcastNear(botLoc, "\u00A72" + data.getDisplayName() + " \u00A7fnyebarin awan racun!");
    }

    private void castStunSlam(BotData data, Location botLoc, Player target) {
        World world = botLoc.getWorld();
        if (world == null) return;
        int durationTicks = 40 + data.getTier().level() * 15;
        int amplifier = data.getTier().level() - 1;

        for (Player p : world.getPlayers()) {
            if (p.getLocation().distance(botLoc) <= 3.0) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, durationTicks, amplifier));
                p.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, durationTicks, amplifier));
            }
        }
        world.spawnParticle(Particle.EXPLOSION, botLoc, 1);
        broadcastNear(botLoc, "\u00A7e" + data.getDisplayName() + " \u00A7fslam! Kamu kena Slowness & Weakness!");
    }

    private void broadcastNear(Location botLoc, String message) {
        World world = botLoc.getWorld();
        if (world == null) return;
        for (Player p : world.getPlayers()) {
            if (p.getLocation().distance(botLoc) <= AGGRO_RADIUS) {
                p.sendMessage(message);
            }
        }
    }

    private void attack(BotData data, BotRuntime rt, Player target) {
        rt.markAttacked();
        double damage = damageFor(data);
        target.damage(damage);

        if (data.getSkills().contains(BotSkill.LIFE_DRAIN)) {
            rt.setCurrentHealth(Math.min(data.getMaxHealth(), rt.getCurrentHealth() + damage * 0.3));
        }

        Vector kb = target.getLocation().toVector()
                .subtract(new Location(target.getWorld(), data.getX(), data.getY(), data.getZ()).toVector())
                .normalize().multiply(0.35).setY(0.25);
        target.setVelocity(target.getVelocity().add(kb));

        target.sendActionBar(net.kyori.adventure.text.Component
                .text("\u00A7c" + data.getDisplayName() + " memukulmu! (-" + String.format("%.1f", damage) + " HP)"));
    }

    private double damageFor(BotData data) {
        double base = switch (data.getType()) {
            case CPVP -> 7.0;      // obsidian/crystal combo feel
            case MYTHICMOB -> 6.0; // hits harder than a plain pvp bot, backed up by skills
            case PVP -> 4.5;
        };
        double tierMultiplier = switch (data.getTier()) {
            case TIER_1 -> 1.0;
            case TIER_2 -> 1.3;
            case TIER_3 -> 1.7;
        };
        return base * tierMultiplier;
    }

    /** Called by BotHitListener when a player successfully lands a hit on the NPC. */
    public void applyIncomingDamage(String botId, Player attacker, BotData data, BotRuntime rt) {
        double dmg = estimateWeaponDamage(attacker);
        rt.damage(dmg);

        if (rt.getCurrentHealth() > 0) {
            attacker.sendActionBar(net.kyori.adventure.text.Component
                    .text("\u00A7f" + data.getDisplayName() + " \u00A77HP: \u00A7c" + String.format("%.1f", rt.getCurrentHealth())
                            + "/" + data.getMaxHealth()));
            return;
        }

        // bot would die - check for totem in offhand first
        ItemStack offhand = data.getEquipment().get(EquipmentSlot.OFF_HAND);
        boolean hasTotem = offhand != null && offhand.getType().name().equals("TOTEM_OF_UNDYING");

        if (hasTotem && !rt.isTotemConsumedThisLife()) {
            rt.setCurrentHealth(Math.min(data.getMaxHealth(), 6.0));
            rt.setTotemConsumedThisLife(true);
            data.getEquipment().remove(EquipmentSlot.OFF_HAND); // consumed - admin needs to /bot edit equip again to refill
            attacker.sendActionBar(net.kyori.adventure.text.Component
                    .text("\u00A7d" + data.getDisplayName() + " pop totem!"));
            return;
        }

        // actually dies
        killBot(botId, data, attacker);
    }

    private void killBot(String botId, BotData data, Player killer) {
        botManager.despawn(botId);
        killer.getWorld().getPlayers().forEach(p ->
                p.sendMessage("\u00A76" + data.getDisplayName() + " \u00A7fdikalahkan oleh \u00A7e" + killer.getName()));

        UUID summoner = killer.getUniqueId();
        plugin.getServer().getGlobalRegionScheduler().runDelayed(plugin,
                task -> botManager.respawnAtHome(botId, summoner), RESPAWN_DELAY_TICKS);
    }

    private double estimateWeaponDamage(Player attacker) {
        ItemStack hand = attacker.getInventory().getItemInMainHand();
        String type = hand.getType().name();
        double base;
        if (type.endsWith("_SWORD")) {
            base = type.startsWith("NETHERITE") ? 8.0 : type.startsWith("DIAMOND") ? 7.0
                    : type.startsWith("IRON") ? 6.0 : type.startsWith("STONE") ? 5.0 : 4.0;
        } else if (type.endsWith("_AXE")) {
            base = type.startsWith("NETHERITE") ? 10.0 : type.startsWith("DIAMOND") ? 9.0 : 7.0;
        } else {
            base = 1.0; // fists / misc items
        }

        int sharpness = hand.getEnchantmentLevel(org.bukkit.enchantments.Enchantment.SHARPNESS);
        base += sharpness * 1.25;

        return base;
    }
}
