package space.lumorasmp.bots.combat;

import de.oliver.fancynpcs.api.Npc;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.util.Vector;
import space.lumorasmp.bots.bot.BotData;
import space.lumorasmp.bots.bot.BotManager;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Detects a player "hitting" a bot NPC.
 *
 * FancyNpcs' NPCs are packet-based (no real server-side entity), so vanilla
 * EntityDamageByEntityEvent never fires for them, and the exact API of
 * de.oliver.fancynpcs.api.events.NpcInteractEvent (method/enum names) has changed
 * between FancyNpcs versions and broke our build before. To stay stable across
 * versions, we detect hits ourselves: every left-click arm swing, check whether the
 * player is aiming roughly at a nearby live bot within melee range, with a short
 * per-player cooldown so one swing can't register twice.
 */
public class BotHitListener implements Listener {

    private static final double MAX_HIT_RANGE = 4.0;
    private static final double AIM_DOT_THRESHOLD = 0.75; // ~40 degree cone
    private static final long HIT_COOLDOWN_MS = 300L;

    private final BotManager botManager;
    private final BotCombatEngine combatEngine;
    private final Map<UUID, Long> lastHitAt = new HashMap<>();

    public BotHitListener(BotManager botManager, BotCombatEngine combatEngine) {
        this.botManager = botManager;
        this.combatEngine = combatEngine;
    }

    @EventHandler
    public void onSwing(PlayerAnimationEvent event) {
        if (event.getAnimationType() != PlayerAnimationType.ARM_SWING) return;

        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        Long last = lastHitAt.get(uuid);
        if (last != null && now - last < HIT_COOLDOWN_MS) return;

        String hitId = findClosestAimedBot(player);
        if (hitId == null) return;

        Optional<BotData> dataOpt = botManager.get(hitId);
        Optional<BotRuntime> runtimeOpt = botManager.getRuntime(hitId);
        if (dataOpt.isEmpty() || runtimeOpt.isEmpty()) return;

        lastHitAt.put(uuid, now);
        combatEngine.applyIncomingDamage(hitId, player, dataOpt.get(), runtimeOpt.get());
    }

    private String findClosestAimedBot(Player player) {
        Location eye = player.getEyeLocation();
        Vector look = eye.getDirection().normalize();

        String bestId = null;
        double bestDist = MAX_HIT_RANGE;

        for (String id : java.util.List.copyOf(botManager.activeIds())) {
            Npc npc = botManager.getNpc(id);
            if (npc == null) continue;

            Location npcLoc = npc.getData().getLocation();
            if (npcLoc == null || npcLoc.getWorld() == null) continue;
            if (!npcLoc.getWorld().equals(eye.getWorld())) continue;

            // aim at roughly torso height, not the feet-position the NPC location stores
            Location target = npcLoc.clone().add(0, 1.1, 0);
            Vector toTarget = target.toVector().subtract(eye.toVector());
            double distance = toTarget.length();
            if (distance > MAX_HIT_RANGE) continue;

            double dot = distance < 0.01 ? 1.0 : toTarget.normalize().dot(look);
            if (dot < AIM_DOT_THRESHOLD) continue;

            if (distance < bestDist) {
                bestDist = distance;
                bestId = id;
            }
        }
        return bestId;
    }
}
