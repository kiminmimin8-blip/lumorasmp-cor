package space.lumorasmp.bots.storage;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import space.lumorasmp.bots.bot.BotData;
import space.lumorasmp.bots.bot.BotSkill;
import space.lumorasmp.bots.bot.BotTier;
import space.lumorasmp.bots.bot.BotType;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BotStorage {

    private final File file;
    private final Logger logger;

    public BotStorage(File dataFolder, Logger logger) {
        this.logger = logger;
        if (!dataFolder.exists()) dataFolder.mkdirs();
        this.file = new File(dataFolder, "bots.yml");
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                logger.log(Level.SEVERE, "Gagal membuat bots.yml", e);
            }
        }
    }

    public Map<String, BotData> loadAll() {
        Map<String, BotData> result = new LinkedHashMap<>();
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection botsSection = yaml.getConfigurationSection("bots");
        if (botsSection == null) return result;

        for (String id : botsSection.getKeys(false)) {
            ConfigurationSection s = botsSection.getConfigurationSection(id);
            if (s == null) continue;

            try {
                String displayName = s.getString("displayName", id);
                BotType type = BotType.fromString(s.getString("type", "PVP"));
                BotTier tier = BotTier.fromString(s.getString("tier", "1"));
                if (type == null) type = BotType.PVP;
                if (tier == null) tier = BotTier.TIER_1;

                BotData data = new BotData(id, displayName, type, tier);
                data.setMaxHealth(s.getDouble("maxHealth", tier.defaultHealth()));
                data.setSkin(s.getString("skin", displayName));
                data.setSpawned(false); // never auto-respawn on load, admin re-spawns manually

                if (s.contains("world")) {
                    data.setLocation(
                            s.getString("world"),
                            s.getDouble("x"),
                            s.getDouble("y"),
                            s.getDouble("z"),
                            (float) s.getDouble("yaw"),
                            (float) s.getDouble("pitch")
                    );
                }

                ConfigurationSection equipSection = s.getConfigurationSection("equipment");
                if (equipSection != null) {
                    for (String slotName : equipSection.getKeys(false)) {
                        try {
                            EquipmentSlot slot = EquipmentSlot.valueOf(slotName);
                            ItemStack item = equipSection.getItemStack(slotName);
                            if (item != null) data.setEquipmentPiece(slot, item);
                        } catch (IllegalArgumentException ignored) {
                        }
                    }
                }

                for (String skillName : s.getStringList("skills")) {
                    BotSkill skill = BotSkill.fromString(skillName);
                    if (skill != null) data.addSkill(skill);
                }

                result.put(id, data);
            } catch (Exception e) {
                logger.log(Level.WARNING, "Gagal load bot '" + id + "' dari bots.yml, dilewati.", e);
            }
        }
        return result;
    }

    public void saveAll(Map<String, BotData> bots) {
        YamlConfiguration yaml = new YamlConfiguration();
        ConfigurationSection botsSection = yaml.createSection("bots");

        for (BotData data : bots.values()) {
            ConfigurationSection s = botsSection.createSection(data.getId());
            s.set("displayName", data.getDisplayName());
            s.set("type", data.getType().name());
            s.set("tier", String.valueOf(data.getTier().level()));
            s.set("maxHealth", data.getMaxHealth());
            s.set("skin", data.getSkin());

            if (!data.getSkills().isEmpty()) {
                List<String> skillNames = data.getSkills().stream().map(Enum::name).toList();
                s.set("skills", skillNames);
            }

            if (data.getWorldName() != null) {
                s.set("world", data.getWorldName());
                s.set("x", data.getX());
                s.set("y", data.getY());
                s.set("z", data.getZ());
                s.set("yaw", data.getYaw());
                s.set("pitch", data.getPitch());
            }

            if (!data.getEquipment().isEmpty()) {
                ConfigurationSection equipSection = s.createSection("equipment");
                for (Map.Entry<EquipmentSlot, ItemStack> entry : data.getEquipment().entrySet()) {
                    equipSection.set(entry.getKey().name(), entry.getValue());
                }
            }
        }

        try {
            yaml.save(file);
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Gagal nyimpen bots.yml", e);
        }
    }
}
