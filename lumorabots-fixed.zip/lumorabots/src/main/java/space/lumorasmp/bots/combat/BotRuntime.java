package space.lumorasmp.bots.combat;

import java.util.UUID;

/**
 * Tracks the "live" combat state of a currently spawned bot.
 * This is intentionally separate from BotData (the saved config) since
 * things like current HP and target reset every time the bot respawns.
 */
public class BotRuntime {

    private double currentHealth;
    private UUID targetPlayer;
    private long lastAttackMillis;
    private long lastHitMillis;
    private long lastSkillMillis;
    private boolean totemConsumedThisLife;

    public BotRuntime(double maxHealth) {
        this.currentHealth = maxHealth;
    }

    public double getCurrentHealth() { return currentHealth; }
    public void setCurrentHealth(double currentHealth) { this.currentHealth = currentHealth; }
    public void damage(double amount) { this.currentHealth -= amount; this.lastHitMillis = System.currentTimeMillis(); }

    public UUID getTargetPlayer() { return targetPlayer; }
    public void setTargetPlayer(UUID targetPlayer) { this.targetPlayer = targetPlayer; }

    public boolean canAttack(long cooldownMillis) {
        return System.currentTimeMillis() - lastAttackMillis >= cooldownMillis;
    }
    public void markAttacked() { lastAttackMillis = System.currentTimeMillis(); }

    public boolean canCastSkill(long cooldownMillis) {
        return System.currentTimeMillis() - lastSkillMillis >= cooldownMillis;
    }
    public void markSkillCast() { lastSkillMillis = System.currentTimeMillis(); }

    public boolean isTotemConsumedThisLife() { return totemConsumedThisLife; }
    public void setTotemConsumedThisLife(boolean value) { this.totemConsumedThisLife = value; }
}
