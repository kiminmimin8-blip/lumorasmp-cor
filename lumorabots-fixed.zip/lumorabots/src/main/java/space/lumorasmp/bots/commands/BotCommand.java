package space.lumorasmp.bots.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import space.lumorasmp.bots.LumoraBots;
import space.lumorasmp.bots.bot.BotData;
import space.lumorasmp.bots.bot.BotManager;
import space.lumorasmp.bots.bot.BotSkill;
import space.lumorasmp.bots.bot.BotTier;
import space.lumorasmp.bots.bot.BotType;
import space.lumorasmp.bots.gui.BotEditGUI;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class BotCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBCOMMANDS = List.of(
            "spawn", "despawn", "spawner", "edit", "rename", "skin", "remove", "list", "info", "help");
    private static final List<String> TIERS = List.of("1", "2", "3");
    private static final List<String> TYPES = List.of("pvp", "cpvp", "mythicmob");
    private static final List<String> EDIT_FIELDS = List.of("health", "tier", "type", "equip", "skills");
    private static final List<String> SKILL_ACTIONS = List.of("add", "remove", "list");
    private static final List<String> SKILL_NAMES = List.of(
            "fireball", "poison_cloud", "leap_strike", "life_drain", "stun_slam");

    private final LumoraBots plugin;
    private final BotManager botManager;
    private final BotEditGUI editGUI;

    public BotCommand(LumoraBots plugin, BotManager botManager) {
        this.plugin = plugin;
        this.botManager = botManager;
        this.editGUI = new BotEditGUI(botManager);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("lumorabots.admin")) {
            sender.sendMessage("\u00A7cKamu tidak punya izin buat command ini.");
            return true;
        }
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "spawner" -> handleSpawner(sender, args);
            case "spawn" -> handleSpawn(sender, args);
            case "despawn" -> handleDespawn(sender, args);
            case "remove" -> handleRemove(sender, args);
            case "rename" -> handleRename(sender, args);
            case "skin" -> handleSkin(sender, args);
            case "edit" -> handleEdit(sender, args);
            case "list" -> handleList(sender);
            case "info" -> handleInfo(sender, args);
            default -> sendHelp(sender);
        }
        return true;
    }

    // /bot spawner create <tier> <type> <name>
    private void handleSpawner(CommandSender sender, String[] args) {
        if (args.length < 5 || !args[1].equalsIgnoreCase("create")) {
            sender.sendMessage("\u00A7cUsage: /bot spawner create <tier:1/2/3> <type:pvp/cpvp/mythicmob> <name>");
            return;
        }
        BotTier tier = BotTier.fromString(args[2]);
        BotType type = BotType.fromString(args[3]);
        String name = args[4];

        if (tier == null) {
            sender.sendMessage("\u00A7cTier gak valid. Pilihan: 1, 2, 3.");
            return;
        }
        if (type == null) {
            sender.sendMessage("\u00A7cType gak valid. Pilihan: pvp, cpvp, mythicmob.");
            return;
        }
        if (botManager.exists(name)) {
            sender.sendMessage("\u00A7cBot dengan nama '" + name + "' udah ada.");
            return;
        }

        BotData data = botManager.createDefinition(name, tier, type);
        sender.sendMessage("\u00A7aBot '" + data.getDisplayName() + "' dibuat. " +
                type.displayName() + " \u00A77| " + tier.displayName() +
                " \u00A77| HP: \u00A7f" + data.getMaxHealth() +
                "\n\u00A77Pakai \u00A7f/bot spawn " + name + " \u00A77buat munculin di lokasi kamu.");
    }

    // /bot spawn <name>
    private void handleSpawn(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("\u00A7cCommand ini cuma bisa dipakai in-game.");
            return;
        }
        if (args.length < 2) {
            sender.sendMessage("\u00A7cUsage: /bot spawn <name>");
            return;
        }
        String name = args[1];
        if (!botManager.exists(name)) {
            sender.sendMessage("\u00A7cBot '" + name + "' gak ketemu. Bikin dulu pakai /bot spawner create.");
            return;
        }
        boolean ok = botManager.spawn(name, player.getLocation(), player.getUniqueId());
        if (ok) {
            sender.sendMessage("\u00A7aBot '" + name + "' spawn di lokasi kamu.");
        } else {
            sender.sendMessage("\u00A7cGagal spawn bot '" + name + "'.");
        }
    }

    private void handleDespawn(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("\u00A7cUsage: /bot despawn <name>");
            return;
        }
        if (botManager.despawn(args[1])) {
            sender.sendMessage("\u00A7aBot '" + args[1] + "' di-despawn (data tetap tersimpan).");
        } else {
            sender.sendMessage("\u00A7cBot '" + args[1] + "' gak ketemu.");
        }
    }

    private void handleRemove(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("\u00A7cUsage: /bot remove <name>");
            return;
        }
        if (botManager.remove(args[1])) {
            sender.sendMessage("\u00A7aBot '" + args[1] + "' dihapus permanen.");
        } else {
            sender.sendMessage("\u00A7cBot '" + args[1] + "' gak ketemu.");
        }
    }

    // /bot rename <name> <newName>
    private void handleRename(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("\u00A7cUsage: /bot rename <name> <newName>");
            return;
        }
        if (botManager.rename(args[1], args[2])) {
            sender.sendMessage("\u00A7aBot '" + args[1] + "' diganti nama jadi '" + args[2] + "'.");
        } else {
            sender.sendMessage("\u00A7cBot '" + args[1] + "' gak ketemu.");
        }
    }

    // /bot skin <name> <skin>
    private void handleSkin(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("\u00A7cUsage: /bot skin <name> <namaPlayer|urlSkin>");
            return;
        }
        if (botManager.setSkin(args[1], args[2])) {
            sender.sendMessage("\u00A7aSkin bot '" + args[1] + "' diganti. (Player Bedrock cuma bakal lihat skin default.)");
        } else {
            sender.sendMessage("\u00A7cBot '" + args[1] + "' gak ketemu.");
        }
    }

    // /bot edit <name> <health|tier|type|equip|skills> [value]
    private void handleEdit(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("\u00A7cUsage: /bot edit <name> <health|tier|type|equip|skills> [value]");
            return;
        }
        String name = args[1];
        var maybe = botManager.get(name);
        if (maybe.isEmpty()) {
            sender.sendMessage("\u00A7cBot '" + name + "' gak ketemu.");
            return;
        }
        BotData data = maybe.get();
        String field = args[2].toLowerCase(Locale.ROOT);

        switch (field) {
            case "health" -> {
                if (args.length < 4) {
                    sender.sendMessage("\u00A7cUsage: /bot edit " + name + " health <jumlah>");
                    return;
                }
                try {
                    double hp = Double.parseDouble(args[3]);
                    if (hp <= 0) throw new NumberFormatException();
                    botManager.setHealth(name, hp);
                    sender.sendMessage("\u00A7aHP bot '" + name + "' diset ke \u00A7f" + hp);
                } catch (NumberFormatException e) {
                    sender.sendMessage("\u00A7cJumlah HP gak valid.");
                }
            }
            case "tier" -> {
                if (args.length < 4) {
                    sender.sendMessage("\u00A7cUsage: /bot edit " + name + " tier <1/2/3>");
                    return;
                }
                BotTier tier = BotTier.fromString(args[3]);
                if (tier == null) {
                    sender.sendMessage("\u00A7cTier gak valid. Pilihan: 1, 2, 3.");
                    return;
                }
                botManager.setTier(name, tier, false);
                sender.sendMessage("\u00A7aTier bot '" + name + "' diset ke " + tier.displayName());
            }
            case "type" -> {
                if (args.length < 4) {
                    sender.sendMessage("\u00A7cUsage: /bot edit " + name + " type <pvp/cpvp/mythicmob>");
                    return;
                }
                BotType type = BotType.fromString(args[3]);
                if (type == null) {
                    sender.sendMessage("\u00A7cType gak valid. Pilihan: pvp, cpvp, mythicmob.");
                    return;
                }
                botManager.setType(name, type);
                sender.sendMessage("\u00A7aType bot '" + name + "' diset ke " + type.displayName());
            }
            case "equip" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("\u00A7cCommand ini cuma bisa dipakai in-game.");
                    return;
                }
                editGUI.open(player, data);
            }
            case "skills" -> handleSkills(sender, name, data, args);
            default -> sender.sendMessage("\u00A7cField gak dikenal. Pilihan: health, tier, type, equip, skills.");
        }
    }

    // /bot edit <n> skills <add|remove|list> [skill]
    private void handleSkills(CommandSender sender, String name, BotData data, String[] args) {
        if (data.getType() != BotType.MYTHICMOB) {
            sender.sendMessage("\u00A7cSkills cuma bisa dipasang di bot type \u00A7dmythicmob\u00A7c. Ganti type-nya dulu pakai /bot edit " + name + " type mythicmob.");
            return;
        }
        if (args.length < 4) {
            sender.sendMessage("\u00A7cUsage: /bot edit " + name + " skills <add|remove|list> [skill]");
            return;
        }
        String action = args[3].toLowerCase(Locale.ROOT);

        if (action.equals("list")) {
            if (data.getSkills().isEmpty()) {
                sender.sendMessage("\u00A77Bot '" + name + "' belum punya skill.");
                return;
            }
            sender.sendMessage("\u00A76--- Skill " + data.getDisplayName() + " ---");
            data.getSkills().forEach(skill -> sender.sendMessage("\u00A7f" + skill.displayName() + " \u00A77- " + skill.description()));
            return;
        }

        if (args.length < 5) {
            sender.sendMessage("\u00A7cUsage: /bot edit " + name + " skills " + action + " <skill>");
            return;
        }
        BotSkill skill = BotSkill.fromString(args[4]);
        if (skill == null) {
            sender.sendMessage("\u00A7cSkill gak dikenal. Pilihan: fireball, poison_cloud, leap_strike, life_drain, stun_slam.");
            return;
        }

        switch (action) {
            case "add" -> {
                botManager.addSkill(name, skill);
                sender.sendMessage("\u00A7aSkill " + skill.displayName() + " \u00A7aditambahin ke '" + name + "'.");
            }
            case "remove" -> {
                botManager.removeSkill(name, skill);
                sender.sendMessage("\u00A7cSkill " + skill.displayName() + " \u00A7cdicopot dari '" + name + "'.");
            }
            default -> sender.sendMessage("\u00A7cAction gak dikenal. Pilihan: add, remove, list.");
        }
    }

    private void handleList(CommandSender sender) {
        if (botManager.all().isEmpty()) {
            sender.sendMessage("\u00A77Belum ada bot yang dibuat.");
            return;
        }
        sender.sendMessage("\u00A76--- Daftar Bot (" + botManager.all().size() + ") ---");
        for (BotData data : botManager.all().values()) {
            String status = data.isSpawned() ? "\u00A7aspawned" : "\u00A78despawned";
            sender.sendMessage("\u00A7f" + data.getDisplayName() + " \u00A77(" + data.getId() + ") " +
                    data.getType().displayName() + " \u00A77| " + data.getTier().displayName() +
                    " \u00A77| " + status);
        }
    }

    private void handleInfo(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("\u00A7cUsage: /bot info <name>");
            return;
        }
        var maybe = botManager.get(args[1]);
        if (maybe.isEmpty()) {
            sender.sendMessage("\u00A7cBot '" + args[1] + "' gak ketemu.");
            return;
        }
        BotData d = maybe.get();
        sender.sendMessage("\u00A76--- " + d.getDisplayName() + " ---");
        sender.sendMessage("\u00A77ID: \u00A7f" + d.getId());
        sender.sendMessage("\u00A77Type: " + d.getType().displayName() + " \u00A77(" + d.getType().description() + ")");
        sender.sendMessage("\u00A77Tier: " + d.getTier().displayName());
        sender.sendMessage("\u00A77HP: \u00A7f" + d.getMaxHealth());
        sender.sendMessage("\u00A77Skin: \u00A7f" + d.getSkin());
        sender.sendMessage("\u00A77Status: " + (d.isSpawned() ? "\u00A7aspawned" : "\u00A78despawned"));
        sender.sendMessage("\u00A77Equipment slots terisi: \u00A7f" + d.getEquipment().size());
        if (!d.getSkills().isEmpty()) {
            String skillList = d.getSkills().stream().map(BotSkill::displayName).collect(Collectors.joining("\u00A77, "));
            sender.sendMessage("\u00A77Skills: " + skillList);
        }
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage("\u00A76--- LumoraBots ---");
        sender.sendMessage("\u00A7f/bot spawner create <tier> <type> <name> \u00A77- bikin definisi bot baru");
        sender.sendMessage("\u00A7f/bot spawn <name> \u00A77- munculin bot di lokasi kamu");
        sender.sendMessage("\u00A7f/bot despawn <name> \u00A77- ilangin dari world (data tetap ada)");
        sender.sendMessage("\u00A7f/bot remove <name> \u00A77- hapus bot permanen");
        sender.sendMessage("\u00A7f/bot rename <name> <newName>");
        sender.sendMessage("\u00A7f/bot skin <name> <skin>");
        sender.sendMessage("\u00A7f/bot edit <name> <health|tier|type|equip|skills> [value]");
        sender.sendMessage("\u00A77  \u00A7f/bot edit <n> skills <add|remove|list> [skill] \u00A77- khusus type mythicmob");
        sender.sendMessage("\u00A7f/bot list \u00A77- semua bot");
        sender.sendMessage("\u00A7f/bot info <name>");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("lumorabots.admin")) return List.of();

        if (args.length == 1) {
            return filter(SUBCOMMANDS, args[0]);
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        return switch (sub) {
            case "spawner" -> tabSpawner(args);
            case "spawn", "despawn", "remove" -> args.length == 2 ? filter(botNames(), args[1]) : List.of();
            case "rename" -> args.length == 2 ? filter(botNames(), args[1]) : List.of();
            case "skin" -> tabSkin(args);
            case "edit" -> tabEdit(args);
            case "info" -> args.length == 2 ? filter(botNames(), args[1]) : List.of();
            default -> List.of();
        };
    }

    private List<String> tabSpawner(String[] args) {
        if (args.length == 2) return filter(List.of("create"), args[1]);
        if (args.length == 3) return filter(TIERS, args[2]);
        if (args.length == 4) return filter(TYPES, args[3]);
        return List.of();
    }

    private List<String> tabSkin(String[] args) {
        if (args.length == 2) return filter(botNames(), args[1]);
        if (args.length == 3) return filter(onlinePlayerNames(), args[2]);
        return List.of();
    }

    private List<String> tabEdit(String[] args) {
        if (args.length == 2) return filter(botNames(), args[1]);
        if (args.length == 3) return filter(EDIT_FIELDS, args[2]);
        if (args.length == 4) {
            String field = args[2].toLowerCase(Locale.ROOT);
            if (field.equals("tier")) return filter(TIERS, args[3]);
            if (field.equals("type")) return filter(TYPES, args[3]);
            if (field.equals("health")) return filter(List.of("20", "40", "60", "100"), args[3]);
            if (field.equals("skills")) return filter(SKILL_ACTIONS, args[3]);
        }
        if (args.length == 5) {
            String field = args[2].toLowerCase(Locale.ROOT);
            String action = args[3].toLowerCase(Locale.ROOT);
            if (field.equals("skills") && (action.equals("add") || action.equals("remove"))) {
                return filter(SKILL_NAMES, args[4]);
            }
        }
        return List.of();
    }

    private List<String> botNames() {
        return botManager.all().values().stream().map(BotData::getDisplayName).collect(Collectors.toList());
    }

    private List<String> onlinePlayerNames() {
        return plugin.getServer().getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList());
    }

    private List<String> filter(List<String> options, String typed) {
        String lower = typed.toLowerCase(Locale.ROOT);
        List<String> result = new ArrayList<>();
        for (String option : options) {
            if (option.toLowerCase(Locale.ROOT).startsWith(lower)) result.add(option);
        }
        return result;
    }
}
