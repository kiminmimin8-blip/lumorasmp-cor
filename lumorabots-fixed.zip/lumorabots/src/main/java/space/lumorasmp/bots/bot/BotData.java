package space.lumorasmp.bots.bot;

import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

/**
 * Our own persisted definition of a bot. This is separate from FancyNpcs' NpcData
 * (which only knows about the visual NPC) - this holds the game-design layer:
 * tier, type, health, and equipment that we apply onto the NPC when spawned.
 */
public class BotData {

    private String id;              // internal lowercase key, unique
    private String displayName;     // shown name, can be changed via /bot rename
    private BotType type;
    private BotTier tier;
    private double maxHealth;
    private String skin;            // player name or skin-url/file, passed straight to FancyNpcs
    private final Map<EquipmentSlot, ItemStack> equipment = new EnumMap<>(EquipmentSlot.class);

    private String worldName;
    private double x, y, z;
    private float yaw, pitch;

    private boolean spawned;        // currently active in world
    private final Set<BotSkill> skills = EnumSet.noneOf(BotSkill.class); // only used by MYTHICMOB type

    public BotData(String id, String displayName, BotType type, BotTier tier) {
        this.id = id;
        this.displayName = displayName;
        this.type = type;
        this.tier = tier;
        this.maxHealth = tier.defaultHealth();
        this.skin = null; // no skin set by default - FancyNpcs falls back to the default Steve skin.
                          // We used to default this to the bot's own display name, but bot names
                          // are often fictional (e.g. "Elite Guard") and aren't real Mojang accounts,
                          // so trying to fetch a skin for them threw SkinLoadException and crashed
                          // /bot spawn entirely. Use /bot skin <name> <player> to set a real one.
    }

    public String getId() { return id; }

    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }

    public BotType getType() { return type; }
    public void setType(BotType type) { this.type = type; }

    public BotTier getTier() { return tier; }
    public void setTier(BotTier tier) { this.tier = tier; }

    public double getMaxHealth() { return maxHealth; }
    public void setMaxHealth(double maxHealth) { this.maxHealth = maxHealth; }

    public String getSkin() { return skin; }
    public void setSkin(String skin) { this.skin = skin; }

    public Map<EquipmentSlot, ItemStack> getEquipment() { return equipment; }

    public void setEquipmentPiece(EquipmentSlot slot, ItemStack item) {
        if (item == null || item.getType().isAir()) {
            equipment.remove(slot);
        } else {
            equipment.put(slot, item.clone());
        }
    }

    public boolean isSpawned() { return spawned; }
    public void setSpawned(boolean spawned) { this.spawned = spawned; }

    public String getWorldName() { return worldName; }
    public double getX() { return x; }
    public double getY() { return y; }
    public double getZ() { return z; }
    public float getYaw() { return yaw; }
    public float getPitch() { return pitch; }

    public Set<BotSkill> getSkills() { return skills; }

    public boolean addSkill(BotSkill skill) { return skills.add(skill); }

    public boolean removeSkill(BotSkill skill) { return skills.remove(skill); }

    public void setLocation(String worldName, double x, double y, double z, float yaw, float pitch) {
        this.worldName = worldName;
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
    }
}
