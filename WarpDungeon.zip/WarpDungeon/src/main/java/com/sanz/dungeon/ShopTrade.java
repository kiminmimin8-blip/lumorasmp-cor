package com.sanz.dungeon;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class ShopTrade {

    public enum OutputType { MONEY, ITEM }

    private final int id;
    private String label; // nama trade, buat identifikasi di list (opsional, default = nama input item)

    private Material inputMaterial = Material.AIR;
    private int inputAmount = 0;

    private OutputType outputType = OutputType.MONEY;
    private double outputMoney = 0;
    private String outputCurrency = "money";
    private Material outputMaterial = Material.AIR;
    private int outputAmount = 0;

    public ShopTrade(int id) { this.id = id; this.label = "Trade #" + id; }

    public int getId() { return id; }

    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }

    public Material getInputMaterial() { return inputMaterial; }
    public void setInputMaterial(Material inputMaterial) { this.inputMaterial = inputMaterial; }

    public int getInputAmount() { return inputAmount; }
    public void setInputAmount(int inputAmount) { this.inputAmount = Math.max(0, inputAmount); }

    public OutputType getOutputType() { return outputType; }
    public void setOutputType(OutputType outputType) { this.outputType = outputType; }

    public double getOutputMoney() { return outputMoney; }
    public void setOutputMoney(double outputMoney) { this.outputMoney = Math.max(0, outputMoney); }

    public String getOutputCurrency() { return outputCurrency; }
    public void setOutputCurrency(String outputCurrency) { this.outputCurrency = outputCurrency; }

    public Material getOutputMaterial() { return outputMaterial; }
    public void setOutputMaterial(Material outputMaterial) { this.outputMaterial = outputMaterial; }

    public int getOutputAmount() { return outputAmount; }
    public void setOutputAmount(int outputAmount) { this.outputAmount = Math.max(0, outputAmount); }

    /** Trade dianggap siap dipajang di /dungeon shop kalau minimal input & output-nya kesetting. */
    public boolean isReady() {
        if (inputMaterial == null || inputMaterial == Material.AIR || inputAmount <= 0) return false;
        if (outputType == OutputType.ITEM) return outputMaterial != null && outputMaterial != Material.AIR && outputAmount > 0;
        return outputMoney > 0;
    }

    public ItemStack buildInputRequirement() { return new ItemStack(inputMaterial, inputAmount); }
    public ItemStack buildOutputItem() { return new ItemStack(outputMaterial, outputAmount); }
}
