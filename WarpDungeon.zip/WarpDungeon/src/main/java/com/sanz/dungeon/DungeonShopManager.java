package com.sanz.dungeon;

import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class DungeonShopManager {

    private final Plugin plugin;
    private final File file;
    private final Map<Integer, ShopTrade> trades = new LinkedHashMap<>();
    private int nextId = 1;

    public DungeonShopManager(Plugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "shop.yml");
        load();
    }

    public Collection<ShopTrade> getAll() { return trades.values(); }
    public ShopTrade get(int id) { return trades.get(id); }

    /** Bikin trade kosong (belum siap dipajang sampai di-setting lewat GUI). */
    public ShopTrade create() {
        ShopTrade t = new ShopTrade(nextId++);
        trades.put(t.getId(), t);
        save();
        return t;
    }

    public boolean remove(int id) {
        boolean removed = trades.remove(id) != null;
        if (removed) save();
        return removed;
    }

    public void load() {
        trades.clear();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        if (yml.getConfigurationSection("trades") == null) return;

        for (String key : yml.getConfigurationSection("trades").getKeys(false)) {
            int id = Integer.parseInt(key);
            String base = "trades." + key + ".";
            ShopTrade t = new ShopTrade(id);
            t.setLabel(yml.getString(base + "label", "Trade #" + id));
            t.setInputMaterial(safeMat(yml.getString(base + "inputMaterial", "STONE")));
            t.setInputAmount(yml.getInt(base + "inputAmount", 1));

            ShopTrade.OutputType type = ShopTrade.OutputType.valueOf(yml.getString(base + "outputType", "MONEY"));
            t.setOutputType(type);
            t.setOutputMoney(yml.getDouble(base + "outputMoney", 0));
            t.setOutputCurrency(yml.getString(base + "outputCurrency", "money"));
            t.setOutputMaterial(safeMat(yml.getString(base + "outputMaterial", "STONE")));
            t.setOutputAmount(yml.getInt(base + "outputAmount", 1));

            trades.put(id, t);
            nextId = Math.max(nextId, id + 1);
        }
    }

    private Material safeMat(String name) {
        Material m = Material.matchMaterial(name);
        return m != null ? m : Material.STONE;
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (ShopTrade t : trades.values()) {
            String base = "trades." + t.getId() + ".";
            yml.set(base + "label", t.getLabel());
            yml.set(base + "inputMaterial", t.getInputMaterial().name());
            yml.set(base + "inputAmount", t.getInputAmount());
            yml.set(base + "outputType", t.getOutputType().name());
            yml.set(base + "outputMoney", t.getOutputMoney());
            yml.set(base + "outputCurrency", t.getOutputCurrency());
            yml.set(base + "outputMaterial", t.getOutputMaterial().name());
            yml.set(base + "outputAmount", t.getOutputAmount());
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal save shop.yml: " + e.getMessage());
        }
    }
}
