package com.sanz.dungeon;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;

public class ShopEditHolder implements InventoryHolder {

    public enum Mode { LIST, DETAIL }

    public static final int INPUT_SLOT = 10;
    public static final int OUTPUT_SLOT = 16;

    private final Mode mode;
    private final Integer tradeId; // null kalau mode LIST
    private final Map<Integer, String> action = new HashMap<>();
    private Inventory inventory;

    public ShopEditHolder(Mode mode, Integer tradeId) {
        this.mode = mode;
        this.tradeId = tradeId;
    }

    public Mode getMode() { return mode; }
    public Integer getTradeId() { return tradeId; }

    public void setInventory(Inventory inventory) { this.inventory = inventory; }
    @Override
    public Inventory getInventory() { return inventory; }

    public void mapAction(int slot, String key) { action.put(slot, key); }
    public String getAction(int slot) { return action.get(slot); }
}
