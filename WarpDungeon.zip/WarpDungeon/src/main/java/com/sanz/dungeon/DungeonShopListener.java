package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class DungeonShopListener implements Listener {

    private final DungeonShopManager shopManager;
    private final DungeonCurrencyProvider currency;

    public DungeonShopListener(DungeonShopManager shopManager, DungeonCurrencyProvider currency) {
        this.shopManager = shopManager;
        this.currency = currency;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof DungeonShopGUI.Holder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;

        Integer tradeId = holder.getTradeId(e.getRawSlot());
        if (tradeId == null) return;
        ShopTrade t = shopManager.get(tradeId);
        if (t == null || !t.isReady()) return;

        ItemStack required = t.buildInputRequirement();
        if (!p.getInventory().containsAtLeast(required, required.getAmount())) {
            p.sendMessage(ChatColor.RED + "Item drop kamu kurang. Butuh " + required.getAmount() + "x " + required.getType().name() + ".");
            return;
        }

        p.getInventory().removeItem(required);

        if (t.getOutputType() == ShopTrade.OutputType.MONEY) {
            currency.deposit(p, t.getOutputCurrency(), t.getOutputMoney());
            p.sendMessage(ChatColor.GREEN + "Ditukar jadi " + currency.format(t.getOutputCurrency(), t.getOutputMoney()) + ".");
        } else {
            java.util.Map<Integer, ItemStack> leftover = p.getInventory().addItem(t.buildOutputItem());
            leftover.values().forEach(item -> p.getWorld().dropItem(p.getLocation(), item));
            p.sendMessage(ChatColor.GREEN + "Ditukar jadi " + t.getOutputAmount() + "x " + t.getOutputMaterial().name() + ".");
        }
    }
}
