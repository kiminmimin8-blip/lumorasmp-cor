package com.sanz.dungeon;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ShopEditGUI {

    private final DungeonShopManager shopManager;

    public ShopEditGUI(DungeonShopManager shopManager) {
        this.shopManager = shopManager;
    }

    // ---------- LIST semua trade + tombol buat baru ----------

    public Inventory buildList() {
        List<ShopTrade> all = new ArrayList<>(shopManager.getAll());
        all.sort(Comparator.comparingInt(ShopTrade::getId));

        int size = Math.max(27, ((all.size() / 9) + 2) * 9);
        if (size > 54) size = 54;

        ShopEditHolder holder = new ShopEditHolder(ShopEditHolder.Mode.LIST, null);
        Inventory inv = Bukkit.createInventory(holder, size, ChatColor.DARK_GREEN + "Edit Shop");
        holder.setInventory(inv);

        int slot = 0;
        for (ShopTrade t : all) {
            if (slot >= size - 9) break;
            Material iconMat = t.getInputMaterial() == Material.AIR ? Material.BARRIER : t.getInputMaterial();
            ItemStack icon = new ItemStack(iconMat, Math.max(1, t.getInputAmount()));
            ItemMeta meta = icon.getItemMeta();
            meta.setDisplayName(ChatColor.AQUA + t.getLabel());

            List<String> lore = new ArrayList<>();
            lore.add(t.isReady() ? ChatColor.GREEN + "Siap dipajang" : ChatColor.RED + "Belum lengkap");
            if (t.getOutputType() == ShopTrade.OutputType.MONEY) {
                lore.add(ChatColor.GRAY + "-> " + t.getOutputMoney() + " " + t.getOutputCurrency());
            } else {
                lore.add(ChatColor.GRAY + "-> " + t.getOutputAmount() + "x " + t.getOutputMaterial());
            }
            lore.add("");
            lore.add(ChatColor.YELLOW + "Klik buat edit");
            meta.setLore(lore);
            icon.setItemMeta(meta);

            inv.setItem(slot, icon);
            holder.mapAction(slot, "open:" + t.getId());
            slot++;
        }

        ItemStack create = named(Material.EMERALD, ChatColor.GREEN + "+ Buat trade baru");
        inv.setItem(size - 1, create);
        holder.mapAction(size - 1, "create");

        return inv;
    }

    // ---------- DETAIL 1 trade, kayak GUI villager ----------

    public Inventory buildDetail(ShopTrade t) {
        ShopEditHolder holder = new ShopEditHolder(ShopEditHolder.Mode.DETAIL, t.getId());
        Inventory inv = Bukkit.createInventory(holder, 27, ChatColor.DARK_GREEN + "Edit: " + t.getLabel());
        holder.setInventory(inv);

        // panel kaca abu2 buat isi slot yang bukan tombol/slot editable
        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        // slot 10 = INPUT (editable beneran, taro item drop-nya di sini)
        if (t.getInputMaterial() != Material.AIR && t.getInputAmount() > 0) {
            inv.setItem(ShopEditHolder.INPUT_SLOT, new ItemStack(t.getInputMaterial(), t.getInputAmount()));
        } else {
            inv.setItem(ShopEditHolder.INPUT_SLOT, null);
        }
        // label slot input pake item di slot 9 (sebelahnya) sebagai penanda, bukan slot interaktif
        inv.setItem(9, named(Material.HOPPER, ChatColor.YELLOW + "Taro item drop di sini ->"));

        // panah penunjuk
        inv.setItem(13, named(Material.ARROW, ChatColor.WHITE + "Ditukar jadi"));

        if (t.getOutputType() == ShopTrade.OutputType.ITEM) {
            if (t.getOutputMaterial() != Material.AIR && t.getOutputAmount() > 0) {
                inv.setItem(ShopEditHolder.OUTPUT_SLOT, new ItemStack(t.getOutputMaterial(), t.getOutputAmount()));
            } else {
                inv.setItem(ShopEditHolder.OUTPUT_SLOT, null);
            }
            inv.setItem(17, named(Material.HOPPER, ChatColor.YELLOW + "<- Taro item hasil tukar di sini"));
        } else {
            // mode MONEY: slot output dikunci, tampilin nominal + tombol +/-
            ItemStack moneyIcon = named(Material.GOLD_INGOT, ChatColor.GOLD.toString() + t.getOutputMoney() + " " + t.getOutputCurrency());
            inv.setItem(ShopEditHolder.OUTPUT_SLOT, moneyIcon);
            holder.mapAction(ShopEditHolder.OUTPUT_SLOT, "noop");

            inv.setItem(19, named(Material.RED_DYE, ChatColor.RED + "-100"));
            holder.mapAction(19, "money:-100");
            inv.setItem(20, named(Material.RED_DYE, ChatColor.RED + "-10"));
            holder.mapAction(20, "money:-10");
            inv.setItem(21, named(Material.RED_DYE, ChatColor.RED + "-1"));
            holder.mapAction(21, "money:-1");
            inv.setItem(23, named(Material.LIME_DYE, ChatColor.GREEN + "+1"));
            holder.mapAction(23, "money:1");
            inv.setItem(24, named(Material.LIME_DYE, ChatColor.GREEN + "+10"));
            holder.mapAction(24, "money:10");
            inv.setItem(25, named(Material.LIME_DYE, ChatColor.GREEN + "+100"));
            holder.mapAction(25, "money:100");
        }

        // toggle mode item <-> money
        inv.setItem(4, named(Material.COMPARATOR, ChatColor.LIGHT_PURPLE + "Mode: " + t.getOutputType() + ChatColor.GRAY + " (klik ganti)"));
        holder.mapAction(4, "toggle_mode");

        // currency cycle (cuma kepake kalau mode MONEY)
        inv.setItem(3, named(Material.NETHER_STAR, ChatColor.AQUA + "Currency: " + t.getOutputCurrency() + ChatColor.GRAY + " (klik ganti)"));
        holder.mapAction(3, "cycle_currency");

        // rename
        inv.setItem(5, named(Material.NAME_TAG, ChatColor.AQUA + "Nama: " + t.getLabel() + ChatColor.GRAY + " (klik ubah)"));
        holder.mapAction(5, "rename");

        // save
        inv.setItem(22, named(Material.EMERALD_BLOCK, ChatColor.GREEN + "SIMPAN"));
        holder.mapAction(22, "save");

        // delete
        inv.setItem(26, named(Material.TNT, ChatColor.RED + "Hapus trade ini (klik 2x)"));
        holder.mapAction(26, "delete");

        // back (gak nyimpen)
        inv.setItem(18, named(Material.ARROW, ChatColor.GRAY + "<- Kembali (tanpa simpan)"));
        holder.mapAction(18, "back");

        return inv;
    }

    private ItemStack named(Material mat, String name) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        item.setItemMeta(meta);
        return item;
    }
}
