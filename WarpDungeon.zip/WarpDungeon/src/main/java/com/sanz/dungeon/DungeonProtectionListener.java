package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.*;
import org.bukkit.plugin.Plugin;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

/**
 * Semua proteksi jalan selama player fisik ada di dalam region dungeon.
 * Bypass: OP atau permission dungeon.bypass.
 */
public class DungeonProtectionListener implements Listener {

    private static final int MORNING_TIME = 1000; // pagi

    // command yg diblok kalau lagi di dalam dungeon (tanpa slash, lowercase)
    private static final Set<String> BLOCKED_COMMANDS = Set.of(
            "teleport", "tp", "tpa", "tpaccept", "tpahere",
            "sethome", "setwarp", "warp",
            "teamwarp", "tw",
            "tpauto"
    );

    private final Plugin plugin;
    private final DungeonManager manager;
    private final DungeonBackManager backManager;

    // player yg lagi tercatat di dalam dungeon tertentu, buat deteksi enter/exit.
    // ConcurrentHashMap (bukan HashMap biasa) -- kalau server jalan di Folia,
    // checkRegion() bisa kepanggil bareng dari beberapa region thread berbeda
    // buat player yang beda-beda pula, HashMap biasa gak aman dipakai gitu.
    private final java.util.Map<UUID, String> insideDungeon = new java.util.concurrent.ConcurrentHashMap<>();

    public DungeonProtectionListener(Plugin plugin, DungeonManager manager, DungeonBackManager backManager) {
        this.plugin = plugin;
        this.manager = manager;
        this.backManager = backManager;
    }

    private boolean bypass(Player p) {
        return p.isOp() || p.hasPermission("dungeon.bypass");
    }

    // ---------- Deteksi masuk / keluar region (dipanggil dari PlayerMoveListener terpisah,
    // biar gak dobel logic move handler) ----------

    /** Dipanggil tiap kali player pindah block. Return true kalau ada perubahan status. */
    public void checkRegion(Player p) {
        Dungeon current = manager.getDungeonAt(p.getLocation());
        String prevId = insideDungeon.get(p.getUniqueId());
        String currId = current != null ? current.getId() : null;

        if (java.util.Objects.equals(prevId, currId)) return; // gak ada perubahan

        // exit dari dungeon sebelumnya
        if (prevId != null) {
            onLeaveDungeon(p, prevId);
        }
        // masuk dungeon baru
        if (currId != null) {
            onEnterDungeon(p, current);
        }

        if (currId != null) insideDungeon.put(p.getUniqueId(), currId);
        else insideDungeon.remove(p.getUniqueId());
    }

    private void onEnterDungeon(Player p, Dungeon d) {
        p.setPlayerTime(MORNING_TIME, false);
    }

    private void onLeaveDungeon(Player p, String dungeonId) {
        p.resetPlayerTime();
        // dianggap "keluar" otomatis, gak perlu /dungeon leave.
        // catat lokasi keluar buat window /back 2 menit
        backManager.recordExit(p.getUniqueId(), dungeonId, p.getLocation().clone());
    }

    public boolean isInsideDungeon(Player p) {
        return insideDungeon.containsKey(p.getUniqueId());
    }

    public void handleQuit(Player p) {
        String id = insideDungeon.remove(p.getUniqueId());
        if (id != null) {
            backManager.recordExit(p.getUniqueId(), id, p.getLocation().clone());
        }
    }

    // ---------- Block break / place ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent e) {
        if (bypass(e.getPlayer())) return;
        if (manager.getDungeonAt(e.getBlock().getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlace(BlockPlaceEvent e) {
        if (bypass(e.getPlayer())) return;
        if (manager.getDungeonAt(e.getBlock().getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    // ---------- Ledakan gak hancurin block, tapi damage tetap jalan ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onExplode(EntityExplodeEvent e) {
        if (manager.getDungeonAt(e.getLocation()) != null) {
            e.blockList().clear();
        }
    }

    // ---------- Fly / Elytra ----------

    @EventHandler
    public void onFlightToggle(PlayerToggleFlightEvent e) {
        Player p = e.getPlayer();
        if (bypass(p)) return;
        if (manager.getDungeonAt(p.getLocation()) != null && p.isFlying()) {
            e.setCancelled(true);
            p.setAllowFlight(false);
        }
    }

    @EventHandler
    public void onGlideToggle(EntityToggleGlideEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (bypass(p)) return;
        if (e.isGliding() && manager.getDungeonAt(p.getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    // ---------- PvP off ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;

        Entity damagerEnt = e.getDamager();
        Player damager = null;
        if (damagerEnt instanceof Player dp) {
            damager = dp;
        } else if (damagerEnt instanceof Projectile proj && proj.getShooter() instanceof Player sp) {
            damager = sp;
        }
        if (damager == null) return;
        if (bypass(damager)) return;

        if (manager.getDungeonAt(victim.getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    // ---------- Enderpearl ----------

    @EventHandler
    public void onProjectileLaunch(org.bukkit.event.entity.ProjectileLaunchEvent e) {
        if (e.getEntityType() != EntityType.ENDER_PEARL) return;
        if (!(e.getEntity().getShooter() instanceof Player p)) return;
        if (bypass(p)) return;
        if (manager.getDungeonAt(p.getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    // ---------- Chorus fruit (makanan yg efeknya teleport) ----------

    @EventHandler
    public void onConsume(PlayerItemConsumeEvent e) {
        if (e.getItem().getType() != Material.CHORUS_FRUIT) return;
        Player p = e.getPlayer();
        if (bypass(p)) return;
        if (manager.getDungeonAt(p.getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    // ---------- Command yg diblok ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (bypass(p)) return;
        if (manager.getDungeonAt(p.getLocation()) == null) return;

        String msg = e.getMessage().substring(1); // buang "/"
        String cmdLabel = msg.split(" ")[0].toLowerCase();
        // buang prefix plugin kalau ada, misal "sanzcore:tp" -> "tp"
        if (cmdLabel.contains(":")) cmdLabel = cmdLabel.substring(cmdLabel.indexOf(":") + 1);

        if (BLOCKED_COMMANDS.contains(cmdLabel)) {
            e.setCancelled(true);
            p.sendMessage(ChatColor.RED + "Command itu gak bisa dipakai di dalam dungeon.");
        }
        // note: /rtp dan /home (bukan /sethome) sengaja gak masuk daftar blokir - dianggap jalur keluar yg sah
    }
}
