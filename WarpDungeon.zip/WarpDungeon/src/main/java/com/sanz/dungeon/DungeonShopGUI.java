package com.sanz.dungeon;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DungeonShopGUI {

    public static class Holder implements InventoryHolder {
        private final Map<Integer, Integer> slotToTradeId = new HashMap<>();
        private Inventory inventory;
        public void setInventory(Inventory inv) { this.inventory = inv; }
        @Override public Inventory getInventory() { return inventory; }
        public void map(int slot, int tradeId) { slotToTradeId.put(slot, tradeId); }
        public Integer getTradeId(int slot) { return slotToTradeId.get(slot); }
    }

    private final DungeonShopManager shopManager;

    public DungeonShopGUI(DungeonShopManager shopManager) {
        this.shopManager = shopManager;
    }

    public Inventory build() {
        List<ShopTrade> ready = new ArrayList<>();
        for (ShopTrade t : shopManager.getAll()) if (t.isReady()) ready.add(t);

        int size = Math.max(27, ((ready.size() / 9) + 1) * 9);
        if (size > 54) size = 54;

        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, size, ChatColor.DARK_GREEN + "Dungeon Shop");
        holder.setInventory(inv);

        int slot = 0;
        for (ShopTrade t : ready) {
            if (slot >= size) break;
            ItemStack icon = new ItemStack(t.getInputMaterial(), t.getInputAmount());
            ItemMeta meta = icon.getItemMeta();
            meta.setDisplayName(ChatColor.YELLOW + t.getLabel());

            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + "Butuh: " + t.getInputAmount() + "x " + prettify(t.getInputMaterial().name()));
            if (t.getOutputType() == ShopTrade.OutputType.MONEY) {
                lore.add(ChatColor.GREEN + "Dapat: " + t.getOutputMoney() + " " + t.getOutputCurrency());
            } else {
                lore.add(ChatColor.AQUA + "Dapat: " + t.getOutputAmount() + "x " + prettify(t.getOutputMaterial().name()));
            }
            meta.setLore(lore);
            icon.setItemMeta(meta);

            inv.setItem(slot, icon);
            holder.map(slot, t.getId());
            slot++;
        }
        return inv;
    }

    private String prettify(String matName) {
        return matName.replace("_", " ").toLowerCase();
    }
}
