package com.audes.plugin.furniture;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.UUID;

/**
 * Place furniture lewat klik kanan ke block (spawn ItemDisplay+Interaction
 * di sisi block yang diklik), dan break lewat serangan (attack) ke entity
 * Interaction-nya.
 *
 * TODO(Dev lain, sudah dicatat di FurnitureItemFactory juga): "/kill @e"
 * atau plugin lain yang mass-remove entity bisa menghapus salah satu dari
 * pasangan ItemDisplay/Interaction tanpa lewat listener ini, meninggalkan
 * pasangannya "yatim" (visual tanpa hitbox, atau hitbox tanpa visual).
 * Belum ada cleanup task berkala untuk kasus ini — kalau jadi masalah nyata,
 * tambahkan task periodik yang scan entity ber-PDC furniture_id tanpa
 * pasangan valid dan hapus.
 */
public class FurnitureListener implements Listener {

    private final FurnitureRegistry registry;
    private final FurnitureItemFactory factory;

    public FurnitureListener(FurnitureRegistry registry, FurnitureItemFactory factory) {
        this.registry = registry;
        this.factory = factory;
    }

    @EventHandler
    public void onPlace(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null || event.getBlockFace() == null) return;

        ItemStack item = event.getPlayer().getInventory().getItemInMainHand();
        String furnitureId = factory.getFurnitureId(item);
        if (furnitureId == null) return; // item biasa, bukan furniture Audes

        registry.get(furnitureId).ifPresent(def -> {
            event.setCancelled(true); // jangan biarkan block asli ikut ke-interact/place ganda

            Location spawnAt = event.getClickedBlock().getRelative(event.getBlockFace()).getLocation()
                    .add(0.5, 0.0, 0.5);
            factory.spawn(spawnAt, def);

            if (event.getPlayer().getGameMode() != GameMode.CREATIVE) {
                item.setAmount(item.getAmount() - 1);
            }

            if (def.placeSoundKey() != null) {
                playConfiguredSound(event.getPlayer(), def.placeSoundKey());
            }
        });
    }

    @EventHandler
    public void onAttack(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Interaction interaction)) return;
        if (!(event.getDamager() instanceof Player player)) return;

        String furnitureId = interaction.getPersistentDataContainer()
                .get(factory.furnitureIdKey(), PersistentDataType.STRING);
        if (furnitureId == null) return; // Interaction entity biasa (bukan buatan plugin ini), abaikan

        event.setCancelled(true); // furniture tidak "berdarah"/knockback seperti mob biasa
        breakFurniture(interaction, furnitureId, player);
    }

    private void breakFurniture(Interaction interaction, String furnitureId, Player breaker) {
        registry.get(furnitureId).ifPresent(def -> {
            Location dropLocation = interaction.getLocation();

            String linkedUuid = interaction.getPersistentDataContainer()
                    .get(factory.linkKey(), PersistentDataType.STRING);
            if (linkedUuid != null) {
                Entity linked = Bukkit.getEntity(UUID.fromString(linkedUuid));
                if (linked != null) linked.remove();
            }
            interaction.remove();

            dropLocation.getWorld().dropItemNaturally(dropLocation, factory.create(def));

            if (def.breakSoundKey() != null) {
                playConfiguredSound(breaker, def.breakSoundKey());
            }
        });
    }

    private void playConfiguredSound(Player player, String soundKey) {
        try {
            Sound sound = Sound.valueOf(soundKey.toUpperCase());
            player.getWorld().playSound(player.getLocation(), sound, 1.0f, 1.0f);
        } catch (IllegalArgumentException e) {
            // Nama sound salah ketik di config.yml — diamkan, jangan lempar exception.
        }
    }
}
