package com.audes.plugin;

import com.audes.plugin.block.BlockDefinition;
import com.audes.plugin.block.CustomBlockModule;
import com.audes.plugin.core.ModuleManager;
import com.audes.plugin.event.AudesRankChangeEvent;
import com.audes.plugin.furniture.FurnitureDefinition;
import com.audes.plugin.furniture.FurnitureModule;
import com.audes.plugin.prefix.PrefixModule;
import com.audes.plugin.tools.CustomToolsModule;
import com.audes.plugin.tools.ToolDefinition;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AudesCommand implements CommandExecutor, TabCompleter {

    private final AudesPlugin plugin;
    private final ModuleManager moduleManager;
    private final PrefixModule prefixModule;
    private final CustomToolsModule customToolsModule;
    private final CustomBlockModule customBlockModule;
    private final FurnitureModule furnitureModule;

    public AudesCommand(AudesPlugin plugin, ModuleManager moduleManager,
                         PrefixModule prefixModule, CustomToolsModule customToolsModule,
                         CustomBlockModule customBlockModule, FurnitureModule furnitureModule) {
        this.plugin = plugin;
        this.moduleManager = moduleManager;
        this.prefixModule = prefixModule;
        this.customToolsModule = customToolsModule;
        this.customBlockModule = customBlockModule;
        this.furnitureModule = furnitureModule;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§7Audes §8» §7Pakai /audes <reload|info|give|giveblock|givefurniture|setrank>");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> handleReload(sender);
            case "info" -> handleInfo(sender);
            case "give" -> handleGive(sender, args);
            case "giveblock" -> handleGiveBlock(sender, args);
            case "givefurniture" -> handleGiveFurniture(sender, args);
            case "setrank" -> handleSetRank(sender, args);
            default -> sender.sendMessage("§cSubcommand tidak dikenal. Pakai /audes <reload|info|give|giveblock|givefurniture|setrank>");
        }
        return true;
    }

    private void handleReload(CommandSender sender) {
        plugin.reloadConfig();
        // NOTE: reload di sini cuma reload config file, BELUM re-enable
        // modul dengan config baru. TODO(Dev lain): panggil
        // moduleManager.disableAll() lalu enableAll() lagi untuk full
        // hot-reload — belum dilakukan karena butuh testing lebih dulu
        // supaya tidak duplikat listener/task.
        sender.sendMessage("§aAudes: config.yml di-reload (modul belum full hot-reload, lihat TODO di kode).");
    }

    private void handleInfo(CommandSender sender) {
        sender.sendMessage("§7Status modul Audes:");
        for (String mod : List.of("custom-tools", "prefix", "rank-tab", "resource-pack", "custom-block", "furniture")) {
            boolean active = moduleManager.isActive(mod);
            sender.sendMessage((active ? "§a✔ " : "§c✘ ") + mod);
        }
    }

    /** /audes give <player> <tool_id> — spawn custom tool dari ToolRegistry, lewat ToolFactory. */
    private void handleGive(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("§cPakai: /audes give <player> <tool_id>");
            return;
        }
        if (customToolsModule == null || !moduleManager.isActive("custom-tools")) {
            sender.sendMessage("§cModul custom-tools tidak aktif.");
            return;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage("§cPlayer '" + args[1] + "' tidak online.");
            return;
        }

        String toolId = args[2];
        var defOpt = customToolsModule.getRegistry().get(toolId);
        if (defOpt.isEmpty()) {
            sender.sendMessage("§cTool id '" + toolId + "' tidak ditemukan di config.yml bagian 'tools'.");
            return;
        }

        ToolDefinition def = defOpt.get();
        ItemStack item = customToolsModule.getFactory().create(def);
        target.getInventory().addItem(item);
        sender.sendMessage("§aDiberikan '" + toolId + "' ke " + target.getName() + ".");
        if (!sender.equals(target)) {
            target.sendMessage("§7Kamu menerima custom tool: " + def.displayName());
        }
    }

    /** /audes giveblock <player> <block_id> — spawn custom block item dari BlockRegistry, lewat BlockItemFactory. */
    private void handleGiveBlock(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("§cPakai: /audes giveblock <player> <block_id>");
            return;
        }
        if (customBlockModule == null || !moduleManager.isActive("custom-block")) {
            sender.sendMessage("§cModul custom-block tidak aktif.");
            return;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage("§cPlayer '" + args[1] + "' tidak online.");
            return;
        }

        String blockId = args[2];
        var defOpt = customBlockModule.getRegistry().get(blockId);
        if (defOpt.isEmpty()) {
            sender.sendMessage("§cBlock id '" + blockId + "' tidak ditemukan di config.yml bagian 'blocks'.");
            return;
        }

        BlockDefinition def = defOpt.get();
        ItemStack item = customBlockModule.getFactory().create(def);
        target.getInventory().addItem(item);
        sender.sendMessage("§aDiberikan '" + blockId + "' ke " + target.getName() + ".");
        if (!sender.equals(target)) {
            target.sendMessage("§7Kamu menerima custom block: " + def.displayName());
        }
    }

    /** /audes givefurniture <player> <furniture_id> — spawn item furniture placeable. */
    private void handleGiveFurniture(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("§cPakai: /audes givefurniture <player> <furniture_id>");
            return;
        }
        if (furnitureModule == null || !moduleManager.isActive("furniture")) {
            sender.sendMessage("§cModul furniture tidak aktif.");
            return;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage("§cPlayer '" + args[1] + "' tidak online.");
            return;
        }

        String furnitureId = args[2];
        var defOpt = furnitureModule.getRegistry().get(furnitureId);
        if (defOpt.isEmpty()) {
            sender.sendMessage("§cFurniture id '" + furnitureId + "' tidak ditemukan di config.yml bagian 'furniture'.");
            return;
        }

        FurnitureDefinition def = defOpt.get();
        ItemStack item = furnitureModule.getFactory().create(def);
        target.getInventory().addItem(item);
        sender.sendMessage("§aDiberikan '" + furnitureId + "' ke " + target.getName() + ".");
        if (!sender.equals(target)) {
            target.sendMessage("§7Kamu menerima custom furniture: " + def.displayName());
        }
    }

    /**
     * /audes setrank <player> <rank> — ganti rank in-memory player di
     * PrefixManager, lalu fire AudesRankChangeEvent supaya rank-tab
     * ter-update real-time, dan langsung refresh above-head lewat
     * PrefixListener (tidak ikut event karena PrefixListener sendiri
     * yang jadi sumber kebenaran prefix, bukan listener terhadap event
     * ini — lihat catatan di PrefixModule).
     */
    private void handleSetRank(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("§cPakai: /audes setrank <player> <rank>");
            return;
        }
        if (prefixModule == null || !moduleManager.isActive("prefix")) {
            sender.sendMessage("§cModul prefix tidak aktif.");
            return;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage("§cPlayer '" + args[1] + "' tidak online.");
            return;
        }

        String newRank = args[2];
        if (!prefixModule.getManager().hasRankDefinition(newRank)) {
            sender.sendMessage("§cRank '" + newRank + "' tidak ada di config.yml bagian 'prefix'.");
            return;
        }

        String oldRank = prefixModule.getManager().getRank(target);
        prefixModule.getManager().setRank(target, newRank);

        // Above-head: PrefixListener yang pegang logic-nya, panggil langsung
        // (bukan lewat event) supaya tidak tergantung modul rank-tab aktif atau tidak.
        if (prefixModule.getListener() != null) {
            prefixModule.getListener().updateAboveHead(target);
        }

        // Rank-tab (kalau aktif) dengarkan event ini untuk update tab list real-time.
        Bukkit.getPluginManager().callEvent(new AudesRankChangeEvent(target, oldRank, newRank));

        sender.sendMessage("§aRank " + target.getName() + " diubah ke '" + newRank + "'.");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("reload", "info", "give", "giveblock", "givefurniture", "setrank");
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("giveblock")
                || args[0].equalsIgnoreCase("givefurniture") || args[0].equalsIgnoreCase("setrank"))) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList());
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("give") && customToolsModule != null) {
            return new ArrayList<>(customToolsModule.getRegistry().getAll().keySet());
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("giveblock") && customBlockModule != null) {
            return new ArrayList<>(customBlockModule.getRegistry().getAll().keySet());
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("givefurniture") && furnitureModule != null) {
            return new ArrayList<>(furnitureModule.getRegistry().getAll().keySet());
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("setrank") && prefixModule != null) {
            return new ArrayList<>(prefixModule.getManager().getAllDefinitions().keySet());
        }
        return List.of();
    }
}
