package com.audes.plugin.furniture;

import org.bukkit.Material;

/**
 * Representasi satu custom furniture dari config.yml bagian "furniture:".
 *
 * Beda pendekatan dari BlockDefinition/ToolDefinition: furniture di sini
 * bukan block ataupun item yang dipegang, tapi ENTITY (ItemDisplay untuk
 * visual + Interaction untuk hitbox) yang di-spawn ke dunia — lihat
 * FurnitureItemFactory untuk detail teknik & alasannya.
 *
 * "displayMaterial" dipakai sebagai item yang ditampilkan ItemDisplay.
 * Belum ada tekstur custom asli (sama seperti tool & block), jadi untuk
 * sekarang isi dengan material vanilla yang paling mirip (mis. OAK_PLANKS
 * untuk kursi kayu polos) sampai ResourcePackModule + modelKey benar-benar
 * dipakai.
 */
public record FurnitureDefinition(
        String id,
        Material displayMaterial,
        String displayName,
        String modelKey,
        float scale,
        double interactionWidth,
        double interactionHeight,
        String placeSoundKey,
        String breakSoundKey
) {
}
