package com.audes.plugin.furniture;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.Plugin;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public class FurnitureRegistry {

    private final Plugin plugin;
    private final Map<String, FurnitureDefinition> furniture = new LinkedHashMap<>();

    public FurnitureRegistry(Plugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig(ConfigurationSection section) {
        furniture.clear();
        if (section == null) return;

        for (String id : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(id);
            if (s == null) continue;

            Material material;
            try {
                material = Material.valueOf(s.getString("display-material", "OAK_PLANKS").toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("[Audes] display-material tidak valid untuk furniture '" + id
                        + "', di-skip. Cek config.yml.");
                continue;
            }

            FurnitureDefinition def = new FurnitureDefinition(
                    id,
                    material,
                    s.getString("display-name", id),
                    s.getString("model", null),
                    (float) s.getDouble("scale", 1.0),
                    s.getDouble("interaction-width", 1.0),
                    s.getDouble("interaction-height", 1.0),
                    s.getString("place-sound", null),
                    s.getString("break-sound", null)
            );
            furniture.put(id, def);
        }

        plugin.getLogger().info("[Audes] " + furniture.size() + " custom furniture termuat dari config.");
    }

    public Optional<FurnitureDefinition> get(String id) {
        return Optional.ofNullable(furniture.get(id));
    }

    public Map<String, FurnitureDefinition> getAll() {
        return furniture;
    }
}
