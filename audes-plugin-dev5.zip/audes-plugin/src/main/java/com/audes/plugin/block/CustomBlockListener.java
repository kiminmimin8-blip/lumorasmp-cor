package com.audes.plugin.block;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Note;
import org.bukkit.Sound;
import org.bukkit.block.data.type.NoteBlock;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Menangani place/break custom block lewat event system Bukkit resmi
 * (bukan reflection/NMS), sesuai prinsip arsitektur di bagian 3 dokumen
 * rencana — sama seperti pola di CustomToolListener.
 *
 * Identitas custom block dibaca/ditulis lewat BlockItemFactory (PDC di
 * item untuk "item apa ini", PDC di chunk untuk "block yang sudah
 * ditanam ini apa") — bukan lewat nama/lore yang gampang ke-parse salah.
 *
 * Dev5 — HARDNESS (prioritas Tinggi "Custom block properties"):
 * diterapkan dengan pendekatan "jumlah hit", BUKAN durasi waktu presisi
 * ala vanilla. Alasannya: Bukkit API TIDAK punya event per-tick "player
 * masih menambang block ini" (BlockDamageEvent cuma fire SEKALI saat
 * mulai menambang) — meniru durasi presisi vanilla butuh manipulasi
 * packet mining-progress (NMS/protocol level), yang melanggar prinsip
 * arsitektur tim ("API resmi dulu, reflection/NMS cuma kalau kepepet").
 * Jadi: def.hardness() dibulatkan jadi jumlah BlockBreakEvent yang harus
 * "lolos" sebelum block beneran hancur; tiap percobaan yang belum cukup
 * di-cancel (block tetap utuh, drop dibatalkan).
 *
 * KETERBATASAN YANG DIKETAHUI (didokumentasikan, bukan silent gap):
 * - Tidak memperhitungkan efficiency/haste/tool yang dipakai — semua
 *   player butuh jumlah hit yang sama, beda dari vanilla yang mining
 *   speed-nya proporsional ke tool.
 * - pendingHits (di bawah) bisa nyisa entry basi kalau player berhenti
 *   menambang di tengah jalan (pindah target, disconnect) — dampaknya
 *   kecil (cuma leak Integer kecil di memory), tapi belum dibersihkan
 *   otomatis. Kalau jadi masalah nyata di server besar, tambahkan
 *   cleanup berkala atau listener PlayerQuitEvent.
 * - Creative mode SELALU bypass hardness (instant break), sesuai
 *   perilaku vanilla creative.
 *
 * TODO(Dev lain — belum dikerjakan, catat biar tidak lupa):
 * - Block yang hilang lewat explosion/piston/WorldEdit TIDAK memicu
 *   BlockBreakEvent, jadi PDC chunk untuk lokasi itu jadi data basi
 *   (block sudah hilang tapi catatan masih ada). Belum ditangani —
 *   perlu listener tambahan (EntityExplodeEvent, BlockPistonExtendEvent,
 *   dsb) kalau server pakai TNT/piston di dekat custom block.
 */
public class CustomBlockListener implements Listener {

    private final BlockRegistry registry;
    private final BlockItemFactory factory;

    // Key: playerUUID + "@" + lokasi block (string). Value: jumlah hit
    // yang sudah "lolos" untuk block itu oleh player itu.
    // ConcurrentHashMap dipakai defensif (event Bukkit normalnya di main
    // thread saja, tapi tidak ada ruginya aman dari akses concurrent).
    private final Map<String, Integer> pendingHits = new ConcurrentHashMap<>();

    public CustomBlockListener(BlockRegistry registry, BlockItemFactory factory) {
        this.registry = registry;
        this.factory = factory;
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent event) {
        ItemStack itemInHand = event.getItemInHand();
        String blockId = factory.getBlockId(itemInHand);
        if (blockId == null) return; // item biasa, bukan custom block Audes

        registry.get(blockId).ifPresentOrElse(def -> {
            if (!(event.getBlock().getBlockData() instanceof NoteBlock noteBlockData)) {
                // Seharusnya selalu NOTE_BLOCK karena BlockItemFactory#create
                // cuma bikin item Material.NOTE_BLOCK, tapi jaga-jaga kalau
                // plugin lain mengubah block data sebelum listener ini jalan.
                return;
            }

            noteBlockData.setInstrument(def.instrument());
            noteBlockData.setNote(new Note(def.note()));
            event.getBlock().setBlockData(noteBlockData, false);

            factory.markPlaced(event.getBlock().getLocation(), blockId);

            if (def.placeSoundKey() != null) {
                playConfiguredSound(event.getPlayer(), def.placeSoundKey());
            }
        }, () -> {
            // block_id ada di item (PDC), tapi id itu sudah tidak terdaftar
            // di config.yml (mis. dihapus setelah item sempat digenerate
            // dan disimpan di chest/inventory player). Jangan silent-place
            // sebagai note block tanpa identitas — kasih tahu player supaya
            // tidak bingung block-nya "polos".
            event.getPlayer().sendMessage("§c[Audes] Block id '" + blockId
                    + "' sudah tidak terdaftar di config.yml — di-place sebagai note block biasa.");
        });
    }

    @EventHandler
    public void onBreak(BlockBreakEvent event) {
        String blockId = factory.getPlacedBlockId(event.getBlock().getLocation());
        if (blockId == null) return; // bukan custom block, biarkan perilaku vanilla apa adanya

        registry.get(blockId).ifPresentOrElse(def -> {
            String hitKey = hitKey(event.getPlayer(), event.getBlock().getLocation());

            if (event.getPlayer().getGameMode() != GameMode.CREATIVE && def.hardness() > 1.0) {
                int requiredHits = (int) Math.round(def.hardness());
                int soFar = pendingHits.merge(hitKey, 1, Integer::sum);
                if (soFar < requiredHits) {
                    event.setCancelled(true);
                    // Feedback kecil supaya player tahu block ini memang butuh
                    // beberapa kali pukul, bukan bug/lag.
                    event.getPlayer().sendActionBar(net.kyori.adventure.text.Component
                            .text("§7" + soFar + "/" + requiredHits));
                    return;
                }
            }

            pendingHits.remove(hitKey);
            event.setDropItems(false); // cegah drop note block vanilla, kita drop item custom sendiri
            factory.clearPlaced(event.getBlock().getLocation());

            dropLoot(event.getBlock().getLocation(), def);

            if (def.breakSoundKey() != null) {
                playConfiguredSound(event.getPlayer(), def.breakSoundKey());
            }
        }, () -> {
            // Id tercatat di chunk tapi sudah dihapus dari config — tetap
            // bersihkan PDC tapi tidak ada definisi buat tahu item apa yang
            // harus di-drop. Tidak drop apa-apa daripada drop item yang
            // salah/berbeda dari yang diharapkan.
            event.setDropItems(false);
            factory.clearPlaced(event.getBlock().getLocation());
        });
    }

    /**
     * Dev5: drop loot table custom kalau diisi, atau fallback ke item
     * block itu sendiri kalau loot-table kosong (behavior lama, backward
     * compatible). Tiap entri loot dievaluasi independen — lihat javadoc
     * BlockLootEntry untuk semantiknya.
     */
    private void dropLoot(Location location, BlockDefinition def) {
        if (def.lootTable().isEmpty()) {
            location.getWorld().dropItemNaturally(location, factory.create(def));
            return;
        }

        for (BlockLootEntry entry : def.lootTable()) {
            if (Math.random() >= entry.chance()) continue;

            int amount = entry.minAmount() == entry.maxAmount()
                    ? entry.minAmount()
                    : entry.minAmount() + (int) (Math.random() * (entry.maxAmount() - entry.minAmount() + 1));
            if (amount <= 0) continue;

            location.getWorld().dropItemNaturally(location, new ItemStack(entry.material(), amount));
        }
    }

    private String hitKey(Player player, Location location) {
        UUID uuid = player.getUniqueId();
        return uuid + "@" + location.getWorld().getName() + ":"
                + location.getBlockX() + "," + location.getBlockY() + "," + location.getBlockZ();
    }

    private void playConfiguredSound(Player player, String soundKey) {
        try {
            Sound sound = Sound.valueOf(soundKey.toUpperCase());
            player.getWorld().playSound(player.getLocation(), sound, 1.0f, 1.0f);
        } catch (IllegalArgumentException e) {
            // Nama sound salah ketik di config.yml — jangan lempar exception
            // yang bisa mengganggu event place/break, cukup diabaikan.
        }
    }
}
