package com.audes.plugin.furniture;

import com.audes.plugin.resourcepack.ResourcePackManifest;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

/**
 * Membuat item furniture (placeable) dan pasangan entity representasinya
 * di dunia: ItemDisplay (visual) + Interaction (hitbox klik/serang).
 *
 * BEDA DENGAN CUSTOM BLOCK (lihat BlockItemFactory): furniture di sini
 * murni ENTITY, bukan block asli.
 * - TIDAK butuh workaround PersistentDataContainer di Chunk — entity
 *   sudah punya PDC sendiri secara native (Entity implements
 *   PersistentDataHolder), dan otomatis ikut ke-save/load bareng
 *   chunk-nya oleh server tanpa kode tambahan.
 * - Bisa diposisikan bebas (termasuk offset dari grid block) dan di-scale
 *   lewat Transformation — ini keunggulan teknik ItemDisplay (Paper
 *   1.19.4+) dibanding trik ArmorStand yang dipakai furniture plugin
 *   generasi sebelumnya.
 * - Konsekuensi: kalau ada command/plugin lain yang mass-remove entity
 *   (mis. "/kill @e" tanpa filter), furniture bisa hilang tanpa lewat
 *   FurnitureListener (lihat TODO di sana).
 */
public class FurnitureItemFactory {

    public static final String FURNITURE_ID_KEY = "furniture_id";
    private static final String LINK_KEY = "furniture_link";

    private final Plugin plugin;
    private final NamespacedKey furnitureIdKey;
    private final NamespacedKey linkKey;
    private final ResourcePackManifest manifest;

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    public FurnitureItemFactory(Plugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.furnitureIdKey = new NamespacedKey(plugin, FURNITURE_ID_KEY);
        this.linkKey = new NamespacedKey(plugin, LINK_KEY);
        this.manifest = manifest;
    }

    /**
     * Bikin ItemStack yang kalau di-place jadi furniture ini.
     *
     * Dev5: setItemModel() diterapkan kalau manifest konfirmasi asetnya
     * ada -- dipakai baik untuk item di inventory MAUPUN item yang
     * ditempel ke ItemDisplay saat spawn() (lihat di bawah), supaya
     * furniture yang sudah ditaruh di dunia ikut tampil dengan model
     * custom yang sama, bukan cuma item di tangan.
     */
    public ItemStack create(FurnitureDefinition def) {
        ItemStack item = new ItemStack(def.displayMaterial());
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(LEGACY.deserialize(def.displayName()));
            meta.getPersistentDataContainer().set(furnitureIdKey, PersistentDataType.STRING, def.id());
            applyModelIfAvailable(meta, def.modelKey());
            item.setItemMeta(meta);
        }
        return item;
    }

    private void applyModelIfAvailable(ItemMeta meta, String modelKey) {
        if (modelKey == null || modelKey.isBlank()) return;

        if (!manifest.hasModel(modelKey)) {
            manifest.warnMissingOnce(modelKey, "furniture (FurnitureItemFactory)");
            return;
        }

        NamespacedKey key = NamespacedKey.fromString(modelKey);
        if (key == null) {
            plugin.getLogger().warning("[Audes] modelKey '" + modelKey
                    + "' di furniture bukan format 'namespace:path' yang valid, di-skip.");
            return;
        }
        meta.setItemModel(key);
    }

    public String getFurnitureId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        return meta.getPersistentDataContainer().get(furnitureIdKey, PersistentDataType.STRING);
    }

    /**
     * Spawn ItemDisplay (visual) + Interaction (hitbox) di lokasi tertentu,
     * saling terhubung lewat PDC berisi UUID satu sama lain supaya break
     * salah satunya bisa menemukan & membersihkan pasangannya.
     */
    public void spawn(Location location, FurnitureDefinition def) {
        ItemDisplay display = location.getWorld().spawn(location, ItemDisplay.class, entity -> {
            // Pakai create(def) (bukan "new ItemStack(def.displayMaterial())" polos)
            // supaya visual di dunia ikut pakai setItemModel() kalau asetnya ada --
            // konsisten dengan item yang dipegang player di inventory.
            entity.setItemStack(create(def));
            entity.setTransformation(new Transformation(
                    new Vector3f(0f, 0f, 0f),
                    new AxisAngle4f(0f, 0f, 0f, 1f),
                    new Vector3f(def.scale(), def.scale(), def.scale()),
                    new AxisAngle4f(0f, 0f, 0f, 1f)
            ));
            entity.getPersistentDataContainer().set(furnitureIdKey, PersistentDataType.STRING, def.id());
        });

        Interaction interaction = location.getWorld().spawn(location, Interaction.class, entity -> {
            entity.setInteractionWidth((float) def.interactionWidth());
            entity.setInteractionHeight((float) def.interactionHeight());
            entity.setResponsive(true);
            entity.getPersistentDataContainer().set(furnitureIdKey, PersistentDataType.STRING, def.id());
            entity.getPersistentDataContainer().set(linkKey, PersistentDataType.STRING,
                    display.getUniqueId().toString());
        });

        display.getPersistentDataContainer().set(linkKey, PersistentDataType.STRING,
                interaction.getUniqueId().toString());
    }

    public NamespacedKey furnitureIdKey() {
        return furnitureIdKey;
    }

    public NamespacedKey linkKey() {
        return linkKey;
    }
}
