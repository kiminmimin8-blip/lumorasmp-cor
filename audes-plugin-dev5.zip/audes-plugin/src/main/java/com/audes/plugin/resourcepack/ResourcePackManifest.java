package com.audes.plugin.resourcepack;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Menjawab prioritas #3 di daftar-fitur-itemsadder.md ("Manifest resource
 * pack + apply model ke item/block/furniture") dan poin risiko yang sudah
 * diperingatkan Dev4 di STATUS-DEV4.md: "typo di config.yml modelKey bisa
 * bikin item invisible tanpa warning".
 *
 * Tugas kelas ini SATU hal saja: tahu modelKey mana yang benar-benar punya
 * file item model definition di contents/, supaya ToolFactory/
 * BlockItemFactory/FurnitureItemFactory bisa memutuskan apply setItemModel()
 * atau tetap fallback vanilla DENGAN peringatan jelas -- bukan silent fail.
 *
 * FORMAT YANG DI-SCAN: mengikuti item model definition resmi Minecraft
 * 1.21.4+ (assets/&lt;namespace&gt;/items/&lt;path&gt;.json), BUKAN model
 * lama assets/&lt;namespace&gt;/models/item/. modelKey di config.yml
 * (mis. "audes:tools/pedang_petir") dipetakan ke file
 * contents/assets/audes/items/tools/pedang_petir.json.
 *
 * Belum berlaku untuk BLOCK (Mojang/Paper belum expose block model
 * override resmi per hari riset ini ditulis -- lihat catatan di
 * BlockDefinition), jadi custom block TETAP pakai teknik note+instrument
 * sampai API itu ada, manifest ini cuma dipakai block untuk validasi
 * ITEM di tangan (BlockItemFactory#create), bukan block yang sudah
 * ter-place di dunia.
 */
public class ResourcePackManifest {

    private final Logger logger;

    // volatile: rebuild() jalan di thread async (lihat ResourcePackModule),
    // sedangkan hasModel()/warnMissingOnce() dipanggil dari main thread
    // (saat create() item). Swap referensi Set utuh (bukan mutasi in-place)
    // supaya tidak butuh lock -- pembaca selalu lihat snapshot yang konsisten.
    private volatile Set<String> availableModelKeys = Set.of();

    // Supaya warning "modelKey tidak ketemu" cuma muncul SEKALI per key,
    // bukan tiap kali item itu di-create ulang (mis. tiap /audes give
    // dipanggil berkali-kali) -- itu akan membanjiri console log.
    private final Set<String> warnedMissingKeys = ConcurrentHashMap.newKeySet();

    public ResourcePackManifest(Logger logger) {
        this.logger = logger;
    }

    /**
     * Scan ulang contents/assets/&lt;namespace&gt;/items/**\/*.json.
     * WAJIB dipanggil dari thread async (I/O jalan-jalan ke filesystem),
     * lihat AsyncUtil di ResourcePackModule.
     *
     * @return jumlah modelKey yang ditemukan (buat log info di caller).
     */
    public int rebuild(File contentsFolder) {
        Set<String> found = new HashSet<>();
        File assetsDir = new File(contentsFolder, "assets");

        File[] namespaceDirs = assetsDir.isDirectory() ? assetsDir.listFiles(File::isDirectory) : null;
        if (namespaceDirs != null) {
            for (File namespaceDir : namespaceDirs) {
                File itemsDir = new File(namespaceDir, "items");
                if (!itemsDir.isDirectory()) continue;

                Path itemsRoot = itemsDir.toPath();
                try (var stream = Files.walk(itemsRoot)) {
                    stream.filter(p -> p.toString().endsWith(".json"))
                            .forEach(p -> {
                                String rel = itemsRoot.relativize(p).toString()
                                        .replace(File.separatorChar, '/');
                                String path = rel.substring(0, rel.length() - ".json".length());
                                found.add(namespaceDir.getName() + ":" + path);
                            });
                } catch (IOException e) {
                    logger.warning("[Audes] Gagal scan contents/assets/" + namespaceDir.getName()
                            + "/items/: " + e.getMessage());
                }
            }
        }

        this.availableModelKeys = Set.copyOf(found);
        // Reset supaya kalau admin nambah aset yang tadinya hilang lalu
        // restart/reload, warning bisa muncul lagi kalau MASIH hilang
        // (bukan macet permanen dari rebuild sebelumnya).
        warnedMissingKeys.clear();
        return found.size();
    }

    public boolean hasModel(String modelKey) {
        return modelKey != null && !modelKey.isBlank() && availableModelKeys.contains(modelKey);
    }

    /**
     * Log peringatan SEKALI per modelKey kalau dikonfigurasi di config.yml
     * tapi tidak ada file item model definition yang cocok di contents/.
     * Dipanggil dari factory (Tool/Block/Furniture) tiap kali create() jalan
     * dan modelKey tidak ketemu -- warnedMissingKeys yang menjaga supaya
     * cuma keluar sekali per key per rebuild.
     */
    public void warnMissingOnce(String modelKey, String contextLabel) {
        if (modelKey == null || modelKey.isBlank()) return;
        if (warnedMissingKeys.add(modelKey)) {
            logger.warning("[Audes] modelKey '" + modelKey + "' dipakai di " + contextLabel
                    + " tapi file-nya tidak ketemu di contents/assets/<namespace>/items/<path>.json "
                    + "-- cek typo di config.yml, atau aset memang belum dibuat. Item ini sementara "
                    + "tampil pakai material vanilla apa adanya (bukan invisible/error).");
        }
    }
}
