package com.sanz.leaderboard.gui;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.LeaderboardEntry;
import com.sanz.leaderboard.data.StatType;
import com.sanz.leaderboard.leaderboard.ValueFormatter;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;

public class LeaderboardGUI {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzLeaderboard plugin;

    public LeaderboardGUI(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    /** Menu utama - satu item per kategori aktif. */
    public void openMainMenu(Player player) {
        String title = plugin.getConfig().getString("gui.title", "&8&lSanz Leaderboard");
        Inventory inv = Bukkit.createInventory(null, 27, LEGACY.deserialize(title));

        int slot = 10;
        for (StatType type : StatType.values()) {
            if (slot > 16) break;
            if (!plugin.getLeaderboardManager().isEnabled(type)) continue;

            ItemStack item = new ItemStack(iconFor(type));
            ItemMeta meta = item.getItemMeta();
            meta.displayName(LEGACY.deserialize(plugin.getLeaderboardManager().getDisplayName(type)));
            meta.lore(List.of(LEGACY.deserialize("&7Klik buat lihat top 10")));
            item.setItemMeta(meta);
            inv.setItem(slot, item);
            slot++;
        }

        player.openInventory(inv);
    }

    /** Menu detail satu kategori - nampilin top-N dengan kepala player. */
    public void openCategory(Player player, StatType type) {
        String title = plugin.getLeaderboardManager().getDisplayName(type);
        Inventory inv = Bukkit.createInventory(null, 45, LEGACY.deserialize(title));

        List<LeaderboardEntry> top = plugin.getLeaderboardManager().getTop(type);

        int slot = 10;
        int rank = 1;
        for (LeaderboardEntry entry : top) {
            if (slot > 34) break;

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.setOwningPlayer(Bukkit.getOfflinePlayer(entry.getUuid()));
            meta.displayName(LEGACY.deserialize("&e#" + rank + " &f" + entry.getPlayerName()));

            List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
            lore.add(LEGACY.deserialize("&7Nilai: &f" + ValueFormatter.format(type, entry.getValue())));
            meta.lore(lore);

            head.setItemMeta(meta);
            inv.setItem(slot, head);

            slot++;
            rank++;
        }

        // Tombol balik ke menu utama
        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta backMeta = back.getItemMeta();
        backMeta.displayName(LEGACY.deserialize("&c« Kembali"));
        back.setItemMeta(backMeta);
        inv.setItem(40, back);

        player.openInventory(inv);
    }

    private Material iconFor(StatType type) {
        return switch (type) {
            case KILLS -> Material.IRON_SWORD;
            case DEATHS -> Material.SKELETON_SKULL;
            case PLAYTIME -> Material.CLOCK;
            case AFK_TIME -> Material.COBWEB;
            case MONEY -> Material.GOLD_INGOT;
            case BLOCKS_MINED -> Material.IRON_PICKAXE;
            case BLOCKS_PLACED -> Material.BRICKS;
            case GEMS -> Material.EMERALD;
        };
    }
}
