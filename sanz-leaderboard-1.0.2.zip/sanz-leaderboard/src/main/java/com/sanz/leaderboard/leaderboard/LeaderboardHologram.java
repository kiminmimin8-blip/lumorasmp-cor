package com.sanz.leaderboard.leaderboard;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.LeaderboardEntry;
import com.sanz.leaderboard.data.StatType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.entity.Display;
import org.bukkit.entity.TextDisplay;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Hologram leaderboard pakai TextDisplay native (bukan library luar kayak DecentHolograms),
 * jadi gak nambah dependency. Satu hologram = satu TextDisplay per kategori, isinya
 * multi-line teks (header + top-N), auto-update pas cache LeaderboardManager di-refresh.
 *
 * Data lokasi hologram disimpan di holograms.yml biar tetep ada setelah restart.
 *
 * Dev-revisi (bug: hologram "gak ada sama sekali" pas baru di-create): TextDisplay
 * multi-line ITU NAMBAH TINGGI KE BAWAH dari titik spawn-nya (bukan ke atas) --
 * kalau di-spawn PERSIS di lokasi player.getLocation() (yang itu artinya di KAKI
 * player, bukan mata), sebagian besar/semua baris teks bisa berakhir NEMPEL/NGUBUR
 * DI DALAM LANTAI, jadi keliatannya kayak "gak ada apa-apa" padahal entity-nya
 * beneran ke-spawn. Sekarang lokasi spawn di-offset ke atas dulu (config
 * "hologram.y-offset", default 1.5 block) sebelum entity-nya dibuat.
 */
public class LeaderboardHologram {

    private final SanzLeaderboard plugin;
    private final Map<StatType, UUID> activeDisplays = new LinkedHashMap<>();
    private final File storageFile;
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();

    public LeaderboardHologram(SanzLeaderboard plugin) {
        this.plugin = plugin;
        this.storageFile = new File(plugin.getDataFolder(), "holograms.yml");
    }

    public boolean create(StatType type, Location rawLocation) {
        remove(type);

        double yOffset = plugin.getConfig().getDouble("hologram.y-offset", 1.5);
        Location location = rawLocation.clone().add(0, yOffset, 0);

        spawnDisplay(type, location);
        saveLocation(type, location);
        return true;
    }

    /**
     * Spawn entity TextDisplay di lokasi yang SUDAH FINAL (offset sudah diterapkan
     * kalau perlu, atau memang lokasi yang mau dipakai apa adanya). TIDAK menambah
     * offset lagi -- dipisah dari create() supaya restoreAll() (yang baca koordinat
     * FINAL hasil create() sebelumnya dari holograms.yml) gak nge-double-apply
     * y-offset tiap kali plugin restart (bug yang sempat kejadian: hologram makin
     * naik ke atas dikit-dikit tiap restart server kalau logic-nya digabung).
     */
    private void spawnDisplay(StatType type, Location location) {
        TextDisplay display = location.getWorld().spawn(location, TextDisplay.class, td -> {
            td.setBillboard(Display.Billboard.CENTER);
            td.setSeeThrough(false);
            td.setShadowed(true);
            td.setDefaultBackground(true);
            td.setAlignment(TextDisplay.TextAlignment.CENTER);
            td.text(buildComponent(type));
            td.setPersistent(true);
        });

        activeDisplays.put(type, display.getUniqueId());
    }

    public boolean remove(StatType type) {
        UUID id = activeDisplays.remove(type);
        if (id == null) return false;

        var entity = plugin.getServer().getEntity(id);
        if (entity != null) {
            entity.remove();
        }
        removeLocation(type);
        return true;
    }

    public List<StatType> listActive() {
        return new ArrayList<>(activeDisplays.keySet());
    }

    /** Dipanggil berkala (main thread) setelah cache leaderboard di-refresh, buat update semua teks hologram. */
    public void updateAll() {
        for (Map.Entry<StatType, UUID> entry : activeDisplays.entrySet()) {
            var entity = plugin.getServer().getEntity(entry.getValue());
            if (entity instanceof TextDisplay display) {
                display.text(buildComponent(entry.getKey()));
            }
        }
    }

    private Component buildComponent(StatType type) {
        List<LeaderboardEntry> top = plugin.getLeaderboardManager().getTopForHologram(type);
        String header = plugin.getConfig().getString("hologram.header-format", "{display_name}")
                .replace("{display_name}", plugin.getLeaderboardManager().getDisplayName(type));

        StringBuilder sb = new StringBuilder(header);
        String format = plugin.getLeaderboardManager().getFormat(type);

        int rank = 1;
        for (LeaderboardEntry e : top) {
            String line = format
                    .replace("{rank}", String.valueOf(rank))
                    .replace("{player}", e.getPlayerName())
                    .replace("{value}", ValueFormatter.format(type, e.getValue()));
            sb.append("\n").append(line);
            rank++;
        }

        if (top.isEmpty()) {
            sb.append("\n&7Belum ada data");
        }

        return legacy.deserialize(sb.toString());
    }

    // ==== Persistence sederhana pakai YAML config, dipanggil pas plugin enable buat restore ====

    private void saveLocation(StatType type, Location loc) {
        org.bukkit.configuration.file.YamlConfiguration yaml = loadYaml();
        String path = type.configKey();
        yaml.set(path + ".world", loc.getWorld().getName());
        yaml.set(path + ".x", loc.getX());
        yaml.set(path + ".y", loc.getY());
        yaml.set(path + ".z", loc.getZ());
        try {
            yaml.save(storageFile);
        } catch (Exception e) {
            plugin.getLogger().warning("Gagal simpan lokasi hologram: " + e.getMessage());
        }
    }

    private void removeLocation(StatType type) {
        org.bukkit.configuration.file.YamlConfiguration yaml = loadYaml();
        yaml.set(type.configKey(), null);
        try {
            yaml.save(storageFile);
        } catch (Exception e) {
            plugin.getLogger().warning("Gagal hapus lokasi hologram: " + e.getMessage());
        }
    }

    private org.bukkit.configuration.file.YamlConfiguration loadYaml() {
        return org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(storageFile);
    }

    /** Dipanggil pas plugin enable, buat spawn ulang semua hologram yang udah pernah dibuat. */
    public void restoreAll() {
        if (!storageFile.exists()) return;
        org.bukkit.configuration.file.YamlConfiguration yaml = loadYaml();

        for (StatType type : StatType.values()) {
            if (!yaml.contains(type.configKey())) continue;

            String worldName = yaml.getString(type.configKey() + ".world");
            var world = plugin.getServer().getWorld(worldName);
            if (world == null) {
                plugin.getLogger().warning("World '" + worldName + "' buat hologram " + type + " gak ketemu, skip restore.");
                continue;
            }

            double x = yaml.getDouble(type.configKey() + ".x");
            double y = yaml.getDouble(type.configKey() + ".y");
            double z = yaml.getDouble(type.configKey() + ".z");

            // spawnDisplay() LANGSUNG, bukan create() -- koordinat yang tersimpan di
            // holograms.yml SUDAH final (sudah termasuk y-offset dari pas /lbhologram
            // create dipanggil), jadi kalau lewat create() lagi bakal ke-offset DUA KALI.
            spawnDisplay(type, new Location(world, x, y, z));
        }
    }
}
