# SanzLeaderboard

Plugin leaderboard standalone buat Sanz SMP — **terpisah dari sanz-core**, gak nyampur.

Ngetrack: **kills, deaths, playtime (dengan deteksi AFK), money (via Vault), blocks mined/placed, gems (custom currency built-in)**.

## Yang baru di revisi ini

- `shards` diganti jadi **`gems`** (command, config, API - semua kena rename)
- **AFK detection buat playtime** - waktu AFK gak dihitung playtime. Otomatis ikut baca metadata dari plugin AFK lain (AxAFKZone dll) kalau ada, plus ada deteksi idle internal sendiri (config `afk.idle-timeout-seconds`)
- **Admin/OP di-exclude dari leaderboard** - player yang OP atau punya permission `sanzleaderboard.exclude` gak akan muncul di GUI maupun hologram manapun (config `exclude-admins: true`)
- **Top-size beda buat GUI vs hologram** - GUI nampilin **top 20**, hologram cuma **top 10** (diatur di config `top-size.gui` dan `top-size.hologram`)

## Revisi terbaru (2)

- **Playtime dipecah jadi 2 kategori**: `playtime` (waktu AKTIF main, kayak sebelumnya) dan
  `afktime` (waktu AFK, sebelumnya waktu AFK cuma dibuang/gak dihitung sama sekali — sekarang
  dialihkan ke leaderboard sendiri). Sumber deteksinya sama (AFKTracker — idle-timeout internal
  ATAU metadata dari AxAFKZone kalau plugin itu ke-install), cuma sekarang waktunya kecatat ke
  tempat yang beda tergantung status AFK pas checkpoint di-flush.
  **Kalau kamu udah punya `database.db` dari sebelumnya**, plugin otomatis migrasi nambah kolom
  `afk_seconds` pas nyala (gak perlu hapus database lama).
- **Bug hologram "gak ada sama sekali" — ketemu & diperbaiki**: TextDisplay multi-baris nambah
  tinggi ke BAWAH dari titik spawn, jadi kalau di-spawn persis di lokasi `player.getLocation()`
  (itu di KAKI player, bukan mata), sebagian besar tekunya kebenam di dalam lantai — kelihatan
  kayak gak ada apa-apa padahal entity-nya beneran ke-spawn. Sekarang otomatis di-offset ke atas
  (config `hologram.y-offset`, default 1.5 block) pas `/lbhologram create`. Kalau masih ketutup
  di server kamu (tergantung tinggi block tempat kamu berdiri), naikkan nilai `y-offset` di
  config lalu `/lbhologram remove <kategori>` + `/lbhologram create <kategori>` ulang.
- Soal **"cuma orang yang terdaftar aja yang muncul, jadi pendek"**: ini bukan bug — leaderboard
  memang cuma bisa nampilin player yang datanya ada di database (siapapun yang PERNAH join server
  ini sejak plugin di-install otomatis kecatat dengan nilai 0, jadi tetap muncul di leaderboard
  meski belum ngapa-ngapain). Kalau daftarnya pendek, itu karena baru sedikit player yang pernah
  join, bukan ada yang di-filter secara gak sengaja.
- Foto referensi yang kamu kirim (border kayu + judul besar "TOP KILL STREAK") itu gaya visual
  dari plugin/server lain (kemungkinan build manual di sekitar hologram + font/format custom) —
  di luar yang bisa diatur murni dari `config.yml` teks. Kalau mau tampilan sedekat itu, format
  teks (warna, simbol ★/→, dll) bisa diatur lewat `categories.<kategori>.format` dan
  `hologram.header-format`, tapi border kayu di foto itu kemungkinan bangunan manual di sekitar
  hologram-nya, bukan sesuatu yang di-generate plugin.

## Revisi terbaru (1) — PlaceholderAPI + tab-completion

- **PlaceholderAPI support** (opsional, softdepend) — placeholder `%sanzleaderboard_<kategori>%`,
  `_raw`, `_rank`, `_top_<n>_name`, `_top_<n>_value` buat semua kategori termasuk `gems`.
  **Identifier-nya bisa diedit dari `config.yml`** (`placeholder.identifier`), jadi kalau plugin
  lain (TAB, DeluxeMenus, scoreboard) perlu tau format placeholder gems/kills/dll, cek langsung
  ke config — gak perlu nebak/hardcode dari kode.
- Semua placeholder baca dari **cache** (bukan query database langsung), jadi aman dipanggil
  sesering apapun dari scoreboard/TAB tanpa bikin server berat — akurasinya ngikutin
  `refresh-interval-seconds` yang sama dengan leaderboard GUI/hologram.
- **Tab-completion** ditambahin ke 3 command (`/leaderboard`, `/gems`, `/lbhologram`) —
  sebelumnya gak ada sama sekali, sekarang kategori/subcommand/nama player online muncul
  otomatis pas nge-tab.

## Cara build

Sandbox ini gak ada akses internet buat download dependency Maven, jadi belum ke-compile/tes di sini.
Karena kamu udah pakai GitHub Actions CI buat plugin lain (sanz-core, sanz-market, dll), cara paling gampang:

1. Push folder ini ke repo GitHub (`sanz-leaderboard`)
2. Workflow `.github/workflows/build.yml` udah disiapin, auto-build tiap push ke `main`
3. Ambil jar hasil build dari tab **Actions** → artifact `sanz-leaderboard`

Atau build lokal (kalau ada Maven + internet):
```bash
mvn clean package
```
Jar hasil ada di `target/sanz-leaderboard-1.0.0.jar`

## PENTING sebelum build — cek versi API

Di `pom.xml`, dependency `paper-api` masih di-set ke `1.21.11-R0.1-SNAPSHOT` karena aku gak bisa cek
langsung versi API yang tersedia buat Purpur 26.1.2 kamu (gak ada akses internet dari sandbox ini).
Cek versi API terdekat di repo Paper dan sesuaikan kalau perlu.

## Install

1. Taruh jar di `plugins/`
2. Pastiin **Vault** ke-install kalau mau kategori `money` jalan (opsional, softdepend)
3. Kalau kamu pakai AxAFKZone atau plugin AFK lain yang nge-set metadata player "afk"/"isAfk"/"AFK",
   plugin ini otomatis ikut baca itu (softdepend, gak wajib ada)
4. Pastiin **PlaceholderAPI** ke-install kalau mau pakai placeholder `%sanzleaderboard_...%` di
   plugin lain (TAB, DeluxeMenus, scoreboard, dll) — opsional, softdepend, plugin tetap jalan
   normal tanpa itu
5. Restart server
6. Edit `plugins/SanzLeaderboard/config.yml` kalau mau ubah format/kategori/top-size/placeholder

## Commands

| Command | Fungsi | Permission |
|---|---|---|
| `/leaderboard` atau `/lb` atau `/top` | Buka GUI menu leaderboard (top 20 per kategori) | `sanzleaderboard.use` (default: semua) |
| `/leaderboard <kategori>` | Langsung buka detail satu kategori | `sanzleaderboard.use` |
| `/gems balance <player>` | Cek gems player | semua |
| `/gems give\|take\|set <player> <jumlah>` | Kelola gems | `sanzleaderboard.admin` (default: op) |
| `/lbhologram create <kategori>` | Bikin hologram (top 10) di posisi kamu | `sanzleaderboard.admin` |
| `/lbhologram remove <kategori>` | Hapus hologram | `sanzleaderboard.admin` |
| `/lbhologram list` | List hologram yang aktif | `sanzleaderboard.admin` |

Kategori valid: `kills`, `deaths`, `playtime`, `money`, `blocks_mined`, `blocks_placed`, `gems`

## Hologram di spawn

Tinggal berdiri di titik yang mau ditaruh hologram, lalu:
```
/lbhologram create kills
/lbhologram create playtime
/lbhologram create gems
```
Bisa taruh beberapa hologram kategori berjejer di spawn. Lokasi disimpan otomatis
(`plugins/SanzLeaderboard/holograms.yml`), jadi tetep ada setelah restart server.

## Exclude admin/OP dari leaderboard

Diatur di `config.yml`:
```yaml
exclude-admins: true
```
Player yang **OP** atau punya permission **`sanzleaderboard.exclude`** otomatis gak muncul
di leaderboard manapun (GUI maupun hologram), walau statistiknya tetep ditrack di database
(cuma disembunyiin dari tampilan top-nya aja). Matiin `exclude-admins: false` kalau mau admin
tetep ikut nongol di leaderboard.

## AFK & Playtime

```yaml
afk:
  enabled: true
  idle-timeout-seconds: 300   # 5 menit gak ada aktivitas = dianggap AFK
```
- Kalau server kamu ada plugin AFK lain (AxAFKZone dll) yang set metadata player
  `afk`/`isAfk`/`AFK` = true, plugin ini otomatis ikut hormatin status itu.
- Kalau gak ada plugin AFK lain, plugin ini pakai deteksi sendiri: gerak/klik/command
  dianggap "aktif", diem lebih dari `idle-timeout-seconds` dianggap AFK.
- Waktu AFK gak nambahin ke stat `playtime`. Granularitas pengecekannya seukuran
  `refresh-interval-seconds`.

## Integrasi ke plugin lain (sanz-core / sanz-market)

Ada `GemsAPI` publik buat plugin lain manggil gems tanpa depend ke internal database:

```java
// di plugin lain, tambahin di plugin.yml: softdepend: [SanzLeaderboard]
import com.sanz.leaderboard.api.GemsAPI;

// cek dulu plugin-nya aktif
if (Bukkit.getPluginManager().isPluginEnabled("SanzLeaderboard")) {
    GemsAPI.add(player.getUniqueId(), player.getName(), 50);
    double balance = GemsAPI.getBalance(player.getUniqueId());
    boolean success = GemsAPI.take(player.getUniqueId(), player.getName(), 20);
}
```

Tambahin dependency ke `pom.xml` plugin lain (scope `provided`, jar-nya ada di classpath server pas runtime):
```xml
<dependency>
    <groupId>com.sanz</groupId>
    <artifactId>sanz-leaderboard</artifactId>
    <version>1.0.0</version>
    <scope>provided</scope>
</dependency>
```

## Arsitektur singkat

- **Storage**: SQLite lokal (`plugins/SanzLeaderboard/database.db`), gak butuh setup database eksternal
- **Performa**: block mine/place di-buffer di memory dulu (bukan query per block), di-flush tiap `refresh-interval-seconds`
- **Cache**: leaderboard di-cache di memory (ukuran = max dari top-size.gui/hologram + buffer buat filter admin), GUI/hologram baca dari cache bukan query DB langsung
- **Hologram**: pakai `TextDisplay` native Paper API, gak nambah dependency ke DecentHolograms atau library luar
- **Money**: sync dari Vault pas player join & quit, jadi gak polling semua player terus-terusan
- **AFK**: cek metadata plugin AFK lain dulu, fallback ke deteksi idle internal sendiri

## Belum ke-tes end-to-end

Karena keterbatasan sandbox (gak ada Maven + internet), plugin ini **belum pernah di-compile beneran**.
Kemungkinan ada typo/import error kecil yang baru ketauan pas build asli. Kalau ada error compile
pas kamu build, kirim log error-nya ke sini, aku bantu benerin.
