package com.audes.plugin.ranktab;

/**
 * Satu badge rank (icon custom lewat font glyph, DIPORTING dari
 * ItemsAdder namespace "sanzranks" — sebenarnya itu aset milik plugin
 * "BetterRanks" yang nempel ke sistem font ItemsAdder, bukan fitur
 * ItemsAdder murni, tapi teknik font-glyph-nya generik & portable ke
 * Audes tanpa perlu plugin BetterRanks itu sendiri).
 *
 * "character" adalah 1 karakter dari Private Use Area Unicode
 * (U+F000-U+F0FF dipakai di sini, lihat contents/assets/audes/font/rank_badges.json)
 * yang di-render jadi badge/logo image lewat custom font provider —
 * BUKAN icon di UI item (beda total dari resource-pack model item).
 *
 * PENTING: karakter ini HANYA tampil benar kalau player sudah terima
 * resource pack Audes (custom font-nya ada di situ). Player yang belum
 * terima pack (baru join, belum accept prompt) akan lihat kotak
 * "tofu"/karakter hilang, BUKAN badge.
 *
 * "bedrockCharacter" OPSIONAL -- Bedrock/Geyser gak pake JSON font
 * provider kayak Java, tapi atlas grid 16x16 per "halaman" unicode
 * (font/glyph_E1.png). Kalau badge ini juga didaftarin di atlas
 * Bedrock, isi karakter unicode versi Bedrock-nya di sini (BEDA dari
 * "character" versi Java). Biarin null kalau badge ini cuma didukung
 * di Java -- TabListManager bakal skip badge (bukan crash) buat
 * player Bedrock kalau field ini null.
 */
public record RankBadgeDefinition(String id, String character, String bedrockCharacter) {
}
