package com.audes.plugin.placeholder;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.prefix.PrefixDefinition;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * Expose data rank/prefix Audes ke PlaceholderAPI, supaya plugin lain
 * yang gak tau apa-apa soal Audes (TAB, DeluxeMenus, dll) tetap bisa
 * nampilin rank/prefix Audes lewat placeholder biasa.
 *
 * Placeholder yang didukung:
 *   %audes_rank%          -> rank key mentah (mis. "owner", "leo")
 *   %audes_prefix%        -> teks prefix LENGKAP dengan kode warna (mis. "&6[Owner]")
 *   %audes_prefix_plain%  -> teks prefix TANPA kode warna (buat sorting/placeholder lain
 *                             yang gak butuh warna, mis. scoreboard-teams sorting)
 *   %audes_rank_badge%    -> badge/logo rank (Dev16) sebagai glyph font, dibungkus tag
 *                             MiniMessage yang benar -- dipakai GUI/menu LUAR yang mau
 *                             nampilin badge di luar tab list (kosong untuk Bedrock).
 *   %audes_img_<id>%      -> custom image (logo, shop icon, dll, lihat ImageRegistry)
 *
 * Hanya aktif kalau PlaceholderAPI ke-detect di server (didaftarkan dari
 * AudesPlugin#onEnable, lihat catatan di sana) -- tidak wajib, plugin lain
 * (termasuk Audes sendiri) tetap jalan normal tanpa PlaceholderAPI.
 */
public class AudesPlaceholders extends PlaceholderExpansion {

    private final AudesPlugin plugin;
    private final boolean floodgateAvailable;

    public AudesPlaceholders(AudesPlugin plugin) {
        this.plugin = plugin;
        this.floodgateAvailable = org.bukkit.Bukkit.getPluginManager().getPlugin("floodgate") != null;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "audes";
    }

    @Override
    public @NotNull String getAuthor() {
        return "Bubuk";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer offlinePlayer, @NotNull String params) {
        if (!(offlinePlayer instanceof Player player) || !player.isOnline()) {
            return "";
        }
        if (plugin.getPrefixModule() == null) {
            return "";
        }

        var manager = plugin.getPrefixModule().getManager();

        return switch (params.toLowerCase()) {
            case "rank" -> manager.getRank(player);
            case "prefix" -> {
                PrefixDefinition def = manager.getDefinitionFor(player);
                yield def != null ? def.text() : "";
            }
            case "prefix_plain" -> {
                PrefixDefinition def = manager.getDefinitionFor(player);
                yield def != null ? def.text().replaceAll("(?i)[&§][0-9a-fk-or]", "") : "";
            }
            case "rank_badge" -> {
                // %audes_rank_badge% -> badge/logo rank (Dev16) buat dipakai GUI
                // LUAR (menu profile, dll) di luar tab list. Sebelum ini badge
                // CUMA di-apply otomatis di TabListManager -- gak ada jalan resmi
                // buat GUI lain nampilinnya, jadi kalau ada yang coba tempel
                // karakter PUA badge langsung tanpa font tag yang bener, hasilnya
                // kotak tofu (font vanilla gak punya glyph itu). Placeholder ini
                // yang benar: dibungkus <font:audes:rank_badges> PERSIS sama kayak
                // BADGE_FONT di TabListManager, biar konsisten satu sumber.
                var rankTabModule = plugin.getRankTabModule();
                var badgeRegistry = rankTabModule != null ? rankTabModule.getBadgeRegistry() : null;
                if (badgeRegistry == null) yield "";

                String rank = manager.getRank(player);
                var badge = badgeRegistry.get(rank);
                if (badge.isEmpty()) yield "";

                if (isBedrockPlayer(player)) {
                    // Atlas Bedrock (font/glyph_E1.png) udah nampung semua 17
                    // badge sejak fix ini -- raw character, TANPA font tag
                    // (Bedrock otomatis nyocokin PUA char ke atlas yang ke-load,
                    // gak ngerti MiniMessage <font:> kayak Java).
                    String bedrockChar = badge.get().bedrockCharacter();
                    yield bedrockChar != null ? bedrockChar : "";
                }

                yield "<font:audes:rank_badges>" + badge.get().character() + "</font>";
            }
            default -> {
                // %audes_img_<key>% -> gambar custom (logo dll) lewat font glyph.
                // Dibungkus tag MiniMessage <font:audes:images> supaya plugin
                // penerima (TAB, dll) nerapin font resource pack-nya, bukan
                // cuma nampilin karakter mentah yang gak ke-mapping ke gambar
                // apapun kalau di-render pake font vanilla.
                String lower = params.toLowerCase();
                if (lower.startsWith("img_")) {
                    String imageId = lower.substring(4);
                    var imageRegistry = plugin.getHudModule() != null ? plugin.getHudModule().getImageRegistry() : null;
                    if (imageRegistry == null) yield "";

                    var imageDef = imageRegistry.get(imageId);
                    if (imageDef.isEmpty()) yield "";

                    if (isBedrockPlayer(player)) {
                        // Bedrock gak ngerti tag MiniMessage <font:>, resource pack-nya
                        // otomatis nyocokin karakter PUA ke atlas font/glyph_XX.png yang
                        // di-load -- gak butuh instruksi font eksplisit kayak Java.
                        String bedrockChar = imageDef.get().bedrockCharacter();
                        yield bedrockChar != null ? bedrockChar : ""; // gambar ini belum ada versi Bedrock-nya
                    }

                    // fontId "default" = karakter ini didaftarin di
                    // minecraft:font/default.json (lihat ImageRegistry), jadi
                    // tampil otomatis TANPA perlu tag <font:> apapun -- ini
                    // yang bikin plugin lain (ShopGUIPlus dll) yang nempelin
                    // karakternya langsung sebagai teks polos (bukan lewat
                    // placeholder ini) tetap bisa nampilin ikonnya dengan benar.
                    if ("default".equals(imageDef.get().fontId())) {
                        yield imageDef.get().character();
                    }
                    yield "<font:audes:" + imageDef.get().fontId() + ">" + imageDef.get().character() + "</font>";
                }
                yield null; // biarin PlaceholderAPI kasih tau placeholder ini gak dikenal
            }
        };
    }

    private boolean isBedrockPlayer(Player player) {
        if (!floodgateAvailable) return false;
        try {
            var api = Class.forName("org.geysermc.floodgate.api.FloodgateApi");
            Object instance = api.getMethod("getInstance").invoke(null);
            Object result = api.getMethod("isFloodgatePlayer", java.util.UUID.class).invoke(instance, player.getUniqueId());
            return result instanceof Boolean b && b;
        } catch (Exception e) {
            return false;
        }
    }
}
