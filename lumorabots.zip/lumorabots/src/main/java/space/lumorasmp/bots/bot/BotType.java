package space.lumorasmp.bots.bot;

public enum BotType {

    PVP("§cPVP", "Bot latihan PvP polos (kayu/besi, tanpa crystal)"),
    CPVP("§dCPvP", "Bot Crystal PvP (obsidian, end crystal, totem)"),
    MYTHICMOB("§5MythicMob", "Mob custom dengan skill (fase combat AI, belum aktif)");

    private final String displayName;
    private final String description;

    BotType(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String displayName() {
        return displayName;
    }

    public String description() {
        return description;
    }

    public static BotType fromString(String input) {
        if (input == null) return null;
        for (BotType type : values()) {
            if (type.name().equalsIgnoreCase(input)) {
                return type;
            }
        }
        // allow shorthand: cpvp, pvp, mm/mythic/mythicmob
        String s = input.toLowerCase();
        if (s.equals("cpvp")) return CPVP;
        if (s.equals("pvp")) return PVP;
        if (s.equals("mm") || s.equals("mythic") || s.equals("mythicmob")) return MYTHICMOB;
        return null;
    }
}
