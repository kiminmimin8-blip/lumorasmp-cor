package space.lumorasmp.bots;

import org.bukkit.plugin.java.JavaPlugin;
import space.lumorasmp.bots.bot.BotManager;
import space.lumorasmp.bots.combat.BotCombatEngine;
import space.lumorasmp.bots.combat.BotHitListener;
import space.lumorasmp.bots.commands.BotCommand;
import space.lumorasmp.bots.gui.BotEditGUI;
import space.lumorasmp.bots.storage.BotStorage;

public class LumoraBots extends JavaPlugin {

    private static LumoraBots instance;
    private BotManager botManager;
    private BotCombatEngine combatEngine;

    @Override
    public void onEnable() {
        instance = this;

        if (getServer().getPluginManager().getPlugin("FancyNpcs") == null) {
            getLogger().severe("FancyNpcs tidak ditemukan! LumoraBots butuh FancyNpcs untuk jalan. Plugin dimatikan.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        BotStorage storage = new BotStorage(getDataFolder(), getLogger());
        botManager = new BotManager(storage, getLogger());

        BotCommand botCommand = new BotCommand(this, botManager);
        getCommand("bot").setExecutor(botCommand);
        getCommand("bot").setTabCompleter(botCommand);

        getServer().getPluginManager().registerEvents(new BotEditGUI(botManager), this);

        combatEngine = new BotCombatEngine(this, botManager);
        getServer().getPluginManager().registerEvents(new BotHitListener(botManager, combatEngine), this);
        combatEngine.start();

        getLogger().info("LumoraBots aktif. " + botManager.all().size() + " bot ter-load dari bots.yml.");
    }

    @Override
    public void onDisable() {
        if (botManager != null) {
            botManager.saveAll();
        }
    }

    public static LumoraBots getInstance() {
        return instance;
    }

    public BotManager getBotManager() {
        return botManager;
    }
}
