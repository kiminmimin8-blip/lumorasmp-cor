package space.lumorasmp.bots.bot;

public enum BotTier {

    TIER_1(1, "§7Tier I", 20.0),
    TIER_2(2, "§eTier II", 30.0),
    TIER_3(3, "§6§lTier III", 40.0);

    private final int level;
    private final String displayName;
    private final double defaultHealth;

    BotTier(int level, String displayName, double defaultHealth) {
        this.level = level;
        this.displayName = displayName;
        this.defaultHealth = defaultHealth;
    }

    public int level() {
        return level;
    }

    public String displayName() {
        return displayName;
    }

    public double defaultHealth() {
        return defaultHealth;
    }

    public static BotTier fromString(String input) {
        if (input == null) return null;
        switch (input.trim()) {
            case "1": return TIER_1;
            case "2": return TIER_2;
            case "3": return TIER_3;
        }
        for (BotTier tier : values()) {
            if (tier.name().equalsIgnoreCase(input)) return tier;
        }
        return null;
    }
}
