package space.lumorasmp.bots.combat;

import de.oliver.fancynpcs.api.events.NpcInteractEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import space.lumorasmp.bots.bot.BotData;
import space.lumorasmp.bots.bot.BotManager;

import java.util.Optional;

/**
 * NOTE: this listens to de.oliver.fancynpcs.api.events.NpcInteractEvent, which FancyNpcs'
 * own javadoc confirms exists ("fired when a player interacts with a NPC"). The exact
 * getter names below (getNpc/getPlayer/getClickType) are the standard convention used by
 * this kind of plugin - if the build fails on this file specifically, check the method
 * names against https://repo.fancyplugins.de/javadoc/releases/de/oliver/FancyNpcs/latest/
 * and adjust just this file.
 */
public class BotHitListener implements Listener {

    private final BotManager botManager;
    private final BotCombatEngine combatEngine;

    public BotHitListener(BotManager botManager, BotCombatEngine combatEngine) {
        this.botManager = botManager;
        this.combatEngine = combatEngine;
    }

    @EventHandler
    public void onNpcInteract(NpcInteractEvent event) {
        if (event.getClickType() != NpcInteractEvent.ClickType.LEFT_CLICK) return;

        String npcId = event.getNpc().getData().getId();
        Player attacker = event.getPlayer();

        Optional<BotData> dataOpt = botManager.get(npcId);
        Optional<BotRuntime> runtimeOpt = botManager.getRuntime(npcId);
        if (dataOpt.isEmpty() || runtimeOpt.isEmpty()) return;

        combatEngine.applyIncomingDamage(npcId, attacker, dataOpt.get(), runtimeOpt.get());
    }
}
