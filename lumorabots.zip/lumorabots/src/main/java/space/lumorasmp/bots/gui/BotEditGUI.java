package space.lumorasmp.bots.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import space.lumorasmp.bots.bot.BotData;
import space.lumorasmp.bots.bot.BotManager;

/**
 * Simple 27-slot inventory GUI: put items in the marked slots to equip the bot.
 * Only reachable through /bot edit <name> equip, which already checks the admin permission.
 */
public class BotEditGUI implements Listener {

    private static final int SLOT_HELMET = 10;
    private static final int SLOT_CHEST = 11;
    private static final int SLOT_LEGS = 12;
    private static final int SLOT_BOOTS = 13;
    private static final int SLOT_MAINHAND = 15;
    private static final int SLOT_OFFHAND = 16;
    private static final int SLOT_SAVE = 22;

    private final BotManager botManager;

    public BotEditGUI(BotManager botManager) {
        this.botManager = botManager;
    }

    public void open(Player player, BotData data) {
        Inventory inv = Bukkit.createInventory(new Holder(data.getId()), 27,
                "\u00A78Edit Equipment: \u00A7f" + data.getDisplayName());

        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        inv.setItem(SLOT_HELMET, orAir(data, EquipmentSlot.HEAD, "\u00A7bHelmet"));
        inv.setItem(SLOT_CHEST, orAir(data, EquipmentSlot.CHEST, "\u00A7bChestplate"));
        inv.setItem(SLOT_LEGS, orAir(data, EquipmentSlot.LEGS, "\u00A7bLeggings"));
        inv.setItem(SLOT_BOOTS, orAir(data, EquipmentSlot.FEET, "\u00A7bBoots"));
        inv.setItem(SLOT_MAINHAND, orAir(data, EquipmentSlot.HAND, "\u00A7bMain Hand"));
        inv.setItem(SLOT_OFFHAND, orAir(data, EquipmentSlot.OFF_HAND, "\u00A7bOff Hand (Totem dll)"));
        inv.setItem(SLOT_SAVE, named(Material.LIME_WOOL, "\u00A7a\u00A7lSIMPAN & TUTUP"));

        player.openInventory(inv);
    }

    private ItemStack orAir(BotData data, EquipmentSlot slot, String label) {
        ItemStack existing = data.getEquipment().get(slot);
        if (existing != null) return existing.clone();
        return named(Material.LIGHT_GRAY_STAINED_GLASS_PANE, "\u00A77" + label + " \u00A78(kosong - taruh item di sini)");
    }

    private ItemStack named(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            item.setItemMeta(meta);
        }
        return item;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof Holder holder)) return;

        int slot = event.getRawSlot();
        boolean isTopInventory = slot >= 0 && slot < event.getInventory().getSize();

        if (!isTopInventory) return; // clicks in the player's own inventory are always fine

        if (slot == SLOT_SAVE) {
            event.setCancelled(true);
            ((Player) event.getWhoClicked()).closeInventory();
            return;
        }

        if (!isEquipSlot(slot)) {
            event.setCancelled(true);
            return;
        }
        // equip slots: allow placing/removing items freely
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (!(event.getInventory().getHolder() instanceof Holder)) return;
        for (int raw : event.getRawSlots()) {
            if (raw < event.getInventory().getSize() && !isEquipSlot(raw)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof Holder holder)) return;

        Inventory inv = event.getInventory();
        botManager.setEquipmentPiece(holder.botId(), EquipmentSlot.HEAD, cleanOrNull(inv.getItem(SLOT_HELMET)));
        botManager.setEquipmentPiece(holder.botId(), EquipmentSlot.CHEST, cleanOrNull(inv.getItem(SLOT_CHEST)));
        botManager.setEquipmentPiece(holder.botId(), EquipmentSlot.LEGS, cleanOrNull(inv.getItem(SLOT_LEGS)));
        botManager.setEquipmentPiece(holder.botId(), EquipmentSlot.FEET, cleanOrNull(inv.getItem(SLOT_BOOTS)));
        botManager.setEquipmentPiece(holder.botId(), EquipmentSlot.HAND, cleanOrNull(inv.getItem(SLOT_MAINHAND)));
        botManager.setEquipmentPiece(holder.botId(), EquipmentSlot.OFF_HAND, cleanOrNull(inv.getItem(SLOT_OFFHAND)));

        if (event.getPlayer() instanceof Player player) {
            player.sendMessage("\u00A7aEquipment bot \u00A7f" + holder.botId() + " \u00A7adisimpan.");
        }
    }

    private ItemStack cleanOrNull(ItemStack item) {
        if (item == null) return null;
        // ignore our own placeholder glass panes
        if (item.getType() == Material.LIGHT_GRAY_STAINED_GLASS_PANE || item.getType() == Material.GRAY_STAINED_GLASS_PANE) {
            return null;
        }
        return item;
    }

    private boolean isEquipSlot(int slot) {
        return slot == SLOT_HELMET || slot == SLOT_CHEST || slot == SLOT_LEGS
                || slot == SLOT_BOOTS || slot == SLOT_MAINHAND || slot == SLOT_OFFHAND;
    }

    private record Holder(String botId) implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            throw new UnsupportedOperationException();
        }
    }
}
