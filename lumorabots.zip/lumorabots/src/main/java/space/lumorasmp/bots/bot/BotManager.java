package space.lumorasmp.bots.bot;

import de.oliver.fancynpcs.api.FancyNpcsPlugin;
import de.oliver.fancynpcs.api.Npc;
import de.oliver.fancynpcs.api.NpcData;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import space.lumorasmp.bots.combat.BotRuntime;
import space.lumorasmp.bots.storage.BotStorage;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Logger;

public class BotManager {

    private final Map<String, BotData> bots = new LinkedHashMap<>();
    private final Map<String, BotRuntime> runtime = new LinkedHashMap<>();
    private final BotStorage storage;
    private final Logger logger;

    public BotManager(BotStorage storage, Logger logger) {
        this.storage = storage;
        this.logger = logger;
        this.bots.putAll(storage.loadAll());
    }

    public void saveAll() {
        storage.saveAll(bots);
    }

    public static String key(String name) {
        return name.toLowerCase();
    }

    public Optional<BotData> get(String name) {
        return Optional.ofNullable(bots.get(key(name)));
    }

    public boolean exists(String name) {
        return bots.containsKey(key(name));
    }

    public Map<String, BotData> all() {
        return bots;
    }

    /** /bot spawner create <tier> <type> <name> - defines a new bot (not spawned yet). */
    public BotData createDefinition(String name, BotTier tier, BotType type) {
        BotData data = new BotData(key(name), name, type, tier);
        bots.put(data.getId(), data);
        saveAll();
        return data;
    }

    /** /bot spawn <name> - spawns (or respawns) the NPC at the given location. */
    public boolean spawn(String name, Location location, UUID creator) {
        BotData data = bots.get(key(name));
        if (data == null) return false;

        // if already spawned somewhere, remove old npc entity first
        despawnNpcOnly(data);

        NpcData npcData = new NpcData(data.getId(), creator, location);
        npcData.setSkin(data.getSkin());
        npcData.setDisplayName(colorize(data.getDisplayName()));

        // apply equipment. NOTE: verify method name against the FancyNpcs javadoc
        // (https://repo.fancyinnovations.com/javadoc/releases/de/oliver/FancyNpcs/latest)
        // if this line fails to compile on a different FancyNpcs version.
        npcData.getEquipment().putAll(data.getEquipment());

        Npc npc = FancyNpcsPlugin.get().getNpcAdapter().apply(npcData);
        FancyNpcsPlugin.get().getNpcManager().registerNpc(npc);
        npc.create();
        npc.spawnForAll();

        World world = location.getWorld();
        data.setLocation(world != null ? world.getName() : "world",
                location.getX(), location.getY(), location.getZ(),
                location.getYaw(), location.getPitch());
        data.setSpawned(true);
        runtime.put(data.getId(), new BotRuntime(data.getMaxHealth()));
        saveAll();
        return true;
    }

    /** /bot despawn <name> - removes the visible NPC but keeps the saved definition. */
    public boolean despawn(String name) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        despawnNpcOnly(data);
        data.setSpawned(false);
        saveAll();
        return true;
    }

    private void despawnNpcOnly(BotData data) {
        Npc npc = FancyNpcsPlugin.get().getNpcManager().getNpc(data.getId());
        if (npc != null) {
            npc.removeForAll();
            FancyNpcsPlugin.get().getNpcManager().removeNpc(npc);
        }
        runtime.remove(data.getId());
    }

    /** /bot remove <name> - deletes the bot entirely (npc + saved data). */
    public boolean remove(String name) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        despawnNpcOnly(data);
        bots.remove(data.getId());
        saveAll();
        return true;
    }

    /** /bot rename <name> <newName> - changes only the display name (the internal id stays the same). */
    public boolean rename(String name, String newDisplayName) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        data.setDisplayName(newDisplayName);
        refreshVisual(data);
        saveAll();
        return true;
    }

    /** /bot skin <name> <skin> */
    public boolean setSkin(String name, String skin) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        data.setSkin(skin);
        refreshVisual(data);
        saveAll();
        return true;
    }

    public boolean setTier(String name, BotTier tier, boolean resetHealthToDefault) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        data.setTier(tier);
        if (resetHealthToDefault) data.setMaxHealth(tier.defaultHealth());
        saveAll();
        return true;
    }

    public boolean setType(String name, BotType type) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        data.setType(type);
        saveAll();
        return true;
    }

    public boolean setHealth(String name, double health) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        data.setMaxHealth(health);
        saveAll();
        return true;
    }

    public boolean setEquipmentPiece(String name, EquipmentSlot slot, ItemStack item) {
        BotData data = bots.get(key(name));
        if (data == null) return false;
        data.setEquipmentPiece(slot, item);
        refreshVisual(data);
        saveAll();
        return true;
    }

    /** Pushes displayName/skin/equipment changes to the live NPC, if it's currently spawned. */
    private void refreshVisual(BotData data) {
        Npc npc = FancyNpcsPlugin.get().getNpcManager().getNpc(data.getId());
        if (npc == null) return;
        NpcData npcData = npc.getData();
        npcData.setDisplayName(colorize(data.getDisplayName()));
        npcData.setSkin(data.getSkin());
        npcData.getEquipment().clear();
        npcData.getEquipment().putAll(data.getEquipment());
        // skin/equipment changes generally need a respawn to show correctly
        npc.removeForAll();
        npc.spawnForAll();
    }

    private String colorize(String input) {
        return input == null ? "" : input.replace('&', '\u00A7');
    }

    // ---- helpers used by BotCombatEngine ----

    public Optional<BotRuntime> getRuntime(String id) {
        return Optional.ofNullable(runtime.get(key(id)));
    }

    /** All bot ids that currently have a live NPC + runtime state. */
    public java.util.Set<String> activeIds() {
        return runtime.keySet();
    }

    public Npc getNpc(String id) {
        return FancyNpcsPlugin.get().getNpcManager().getNpc(key(id));
    }

    /**
     * Moves the NPC to a new location. FancyNpcs exposes a teleport on the Npc object
     * (same one used by the "/npc move_to" command) - if this method name differs on
     * the FancyNpcs version you build against, check the javadoc at
     * https://repo.fancyplugins.de/javadoc/releases/de/oliver/FancyNpcs/latest/
     */
    public void teleportNpc(String id, Location location) {
        Npc npc = getNpc(id);
        if (npc == null) return;
        npc.teleport(location);

        BotData data = bots.get(key(id));
        if (data != null) {
            World world = location.getWorld();
            data.setLocation(world != null ? world.getName() : data.getWorldName(),
                    location.getX(), location.getY(), location.getZ(),
                    location.getYaw(), location.getPitch());
        }
    }

    /** Re-spawns a dead bot at its configured location with full HP, after a delay is handled by the caller. */
    public void respawnAtHome(String id, UUID summoner) {
        BotData data = bots.get(key(id));
        if (data == null || data.getWorldName() == null) return;
        World world = org.bukkit.Bukkit.getWorld(data.getWorldName());
        if (world == null) return;
        Location loc = new Location(world, data.getX(), data.getY(), data.getZ(), data.getYaw(), data.getPitch());
        spawn(data.getDisplayName(), loc, summoner);
    }
}
