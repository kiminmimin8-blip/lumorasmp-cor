package com.audes.plugin.bedrock;

import org.geysermc.floodgate.api.FloodgateApi;

import java.util.UUID;

/**
 * Dev15: kelas TERPISAH sengaja dari BedrockPlayerDetector supaya JVM
 * TIDAK coba load/link kelas org.geysermc.floodgate.api.FloodgateApi
 * kecuali method di sini benar-benar dipanggil. Class loading di Java
 * itu lazy per-kelas -- kalau referensi ke FloodgateApi ada langsung di
 * BedrockPlayerDetector, JVM akan coba resolve kelas itu begitu
 * BedrockPlayerDetector di-load (bahkan kalau method-nya gak pernah
 * dipanggil di server yang gak punya Floodgate), dan itu bisa
 * NoClassDefFoundError. Dengan di-isolasi di sini + hanya dipanggil
 * SETELAH BedrockPlayerDetector.isFloodgatePresent() konfirmasi plugin
 * Floodgate ada, class loading kelas ini aman.
 *
 * Dependency: org.geysermc.floodgate:api (scope "provided" di pom.xml,
 * TIDAK di-shade ke jar Audes -- di runtime kelasnya disuplai oleh
 * plugin Floodgate yang sudah jalan di server, sama seperti cara
 * paper-api "provided" disuplai oleh server Paper itu sendiri).
 */
final class FloodgateBridge {

    private FloodgateBridge() {
    }

    static boolean isBedrockPlayer(UUID playerUuid) {
        return FloodgateApi.getInstance().isFloodgatePlayer(playerUuid);
    }
}
