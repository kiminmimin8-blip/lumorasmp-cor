package com.audes.plugin.gui;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class GuiRegistry {

    private final Plugin plugin;
    private final Map<String, GuiDefinition> guis = new LinkedHashMap<>();

    public GuiRegistry(Plugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig(ConfigurationSection section) {
        guis.clear();
        if (section == null) return;

        for (String id : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(id);
            if (s == null) continue;

            int rows = s.getInt("rows", 3);
            if (rows < 1 || rows > 6) {
                plugin.getLogger().warning("[Audes] gui '" + id + "' punya rows di luar rentang 1-6 (nilai: "
                        + rows + "), di-clamp.");
                rows = Math.max(1, Math.min(6, rows));
            }

            List<GuiButtonDefinition> buttons = parseButtons(s, id, rows);

            GuiDefinition def = new GuiDefinition(
                    id,
                    s.getString("title", id),
                    rows,
                    buttons
            );
            guis.put(id, def);
        }

        plugin.getLogger().info("[Audes] " + guis.size() + " custom GUI termuat dari config.");
    }

    private List<GuiButtonDefinition> parseButtons(ConfigurationSection s, String guiId, int rows) {
        List<Map<?, ?>> rawList = s.getMapList("buttons");
        List<GuiButtonDefinition> buttons = new ArrayList<>();
        int maxSlot = rows * 9;

        int index = 0;
        for (Map<?, ?> raw : rawList) {
            index++;
            Object slotRaw = raw.get("slot");
            if (!(slotRaw instanceof Number slotNum)) {
                plugin.getLogger().warning("[Audes] gui '" + guiId + "' tombol #" + index
                        + " tidak punya 'slot' yang valid, di-skip.");
                continue;
            }
            int slot = slotNum.intValue();
            if (slot < 0 || slot >= maxSlot) {
                plugin.getLogger().warning("[Audes] gui '" + guiId + "' tombol #" + index + " slot " + slot
                        + " di luar jangkauan (gui ini " + rows + " baris, slot valid 0-" + (maxSlot - 1)
                        + "), di-skip.");
                continue;
            }

            Object materialRaw = raw.get("material");
            Material material;
            try {
                material = Material.valueOf(String.valueOf(materialRaw).toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("[Audes] gui '" + guiId + "' tombol #" + index
                        + " material '" + materialRaw + "' tidak valid, di-skip.");
                continue;
            }

            Object nameRaw = raw.get("name");
            String name = nameRaw != null ? String.valueOf(nameRaw) : "";

            List<String> lore = raw.get("lore") instanceof List<?> l
                    ? l.stream().map(String::valueOf).toList()
                    : List.of();

            List<String> commands = raw.get("commands") instanceof List<?> c
                    ? c.stream().map(String::valueOf).toList()
                    : List.of();

            boolean closeOnClick = raw.get("close-on-click") instanceof Boolean b && b;

            buttons.add(new GuiButtonDefinition(slot, material, name, lore, commands, closeOnClick));
        }
        return List.copyOf(buttons);
    }

    public Optional<GuiDefinition> get(String id) {
        return Optional.ofNullable(guis.get(id));
    }

    public Map<String, GuiDefinition> getAll() {
        return guis;
    }
}
