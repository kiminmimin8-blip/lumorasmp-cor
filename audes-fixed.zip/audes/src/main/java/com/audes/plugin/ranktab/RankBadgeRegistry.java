package com.audes.plugin.ranktab;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.Plugin;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Load "rank-badges:" dari config.yml -- key HARUS sama dengan key rank
 * di "prefix:" (mis. "admin", "owner") supaya TabListManager bisa
 * pasangkan badge ke rank yang benar. Validasi keterkaitan ini TIDAK
 * dipaksa di sini (rank-badges boleh punya entri yang rank-nya belum/
 * tidak ada di prefix:, itu cuma berarti badge itu tidak pernah
 * terpasang ke siapa pun -- bukan error).
 *
 * "codepoint" di config WAJIB 1 karakter Private Use Area yang PERSIS
 * sama dengan yang didaftarkan di
 * contents/assets/audes/font/rank_badges.json (17 mapping default
 * sudah disiapkan Dev16, U+F000-U+F010, lihat komentar di config.yml).
 * Kalau admin nambah badge baru, font JSON itu WAJIB diupdate manual
 * juga -- registry ini TIDAK generate font JSON secara otomatis
 * (keterbatasan yang disengaja, bukan lupa: generate font JSON at
 * runtime butuh restart resource pack + reupload, terlalu berat buat
 * dilakukan implicit setiap config reload).
 */
public class RankBadgeRegistry {

    private final Plugin plugin;
    private final Map<String, RankBadgeDefinition> badges = new LinkedHashMap<>();

    public RankBadgeRegistry(Plugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig(ConfigurationSection section) {
        badges.clear();
        if (section == null) return;

        for (String id : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(id);
            if (s == null) continue;

            String codepoint = s.getString("codepoint");
            if (codepoint == null || codepoint.isEmpty()) {
                plugin.getLogger().warning("[Audes] rank-badge '" + id + "' tidak punya 'codepoint' valid, "
                        + "di-skip. Isi 1 karakter Private Use Area, contoh: \"\\uF000\" (lihat contoh bawaan di config.yml).");
                continue;
            }
            if (codepoint.length() != 1) {
                plugin.getLogger().warning("[Audes] rank-badge '" + id + "' punya 'codepoint' lebih dari 1 "
                        + "karakter ('" + codepoint + "'), cuma karakter pertama yang dipakai -- pastikan config "
                        + "cuma isi 1 escape unicode, bukan teks biasa.");
                codepoint = codepoint.substring(0, 1);
            }

            badges.put(id, new RankBadgeDefinition(id, codepoint));
        }
    }

    public Optional<RankBadgeDefinition> get(String id) {
        return Optional.ofNullable(badges.get(id));
    }

    public Map<String, RankBadgeDefinition> getAll() {
        return badges;
    }
}
