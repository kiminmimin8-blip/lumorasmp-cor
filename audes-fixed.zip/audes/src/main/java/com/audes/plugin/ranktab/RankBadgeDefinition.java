package com.audes.plugin.ranktab;

/**
 * Satu badge rank (icon custom lewat font glyph, DIPORTING dari
 * ItemsAdder namespace "sanzranks" — sebenarnya itu aset milik plugin
 * "BetterRanks" yang nempel ke sistem font ItemsAdder, bukan fitur
 * ItemsAdder murni, tapi teknik font-glyph-nya generik & portable ke
 * Audes tanpa perlu plugin BetterRanks itu sendiri).
 *
 * "character" adalah 1 karakter dari Private Use Area Unicode
 * (U+F000-U+F0FF dipakai di sini, lihat contents/assets/audes/font/rank_badges.json)
 * yang di-render jadi badge/logo image lewat custom font provider —
 * BUKAN icon di UI item (beda total dari resource-pack model item).
 *
 * PENTING: karakter ini HANYA tampil benar kalau player sudah terima
 * resource pack Audes (custom font-nya ada di situ). Player yang belum
 * terima pack (baru join, belum accept prompt, atau player Bedrock yang
 * di-skip dari pengiriman pack — lihat BedrockPlayerDetector) akan
 * lihat kotak "tofu"/karakter hilang, BUKAN badge. TabListManager
 * (Dev16) sengaja SKIP badge buat player Bedrock karena alasan ini
 * (mereka tidak pernah dikirimin pack sama sekali).
 */
public record RankBadgeDefinition(String id, String character) {
}
