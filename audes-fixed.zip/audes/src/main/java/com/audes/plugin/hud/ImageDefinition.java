package com.audes.plugin.hud;

/**
 * Satu custom image (logo, dsb) yang di-render lewat font glyph —
 * teknik SAMA PERSIS dengan RankBadgeDefinition (lihat javadoc di
 * sana buat penjelasan lengkap soal Private Use Area + resource pack
 * requirement), bedanya cuma dipakai buat gambar besar standalone
 * (mis. logo server di scoreboard/tab), bukan badge kecil di depan nama.
 *
 * "character" HARUS persis sama dengan yang didaftarkan di
 * contents/assets/audes/font/images.json (dua default sudah disiapkan:
 * serverlogo -> \uF100, serverlogo2 -> \uF101).
 */
public record ImageDefinition(String id, String character) {
}
