package com.audes.plugin.resourcepack;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Dev14: upload resource pack ke LobFile (https://lobfile.com), GANTIKAN
 * ResourcePackServer (self-host webserver JDK) yang dipakai sampai Dev13.
 *
 * KENAPA GANTI, bukan sekadar tambah opsi:
 * - Insiden ItemsAdder tim (lihat catatan chat) -- generated.zip korup
 *   di level binary karena DUA PROSES nulis file resourcepack yang sama
 *   secara bersamaan (race condition). Self-host webserver kita sendiri
 *   (ResourcePackServer) rentan pola serupa: kalau /audes reload dipanggil
 *   pas ada player lagi download dari port lokal, server lama & baru bisa
 *   tumpang tindih pegang file yang sama. Upload ke LobFile menghilangkan
 *   kelas masalah ini total -- kita cuma HTTP POST sekali, sisanya
 *   ditangani infrastruktur mereka, bukan kode kita.
 * - LobFile adalah layanan YANG SAMA dipakai ItemsAdder untuk fitur
 *   "Continuous Uploading" (lihat wiki resmi ItemsAdder, bagian
 *   resourcepack-hosting/lobfile) -- jadi behavior/reliability-nya sudah
 *   familiar buat tim yang sebelumnya pakai ItemsAdder.
 * - Server IP privacy: player yang download pack tidak lagi nembak balik
 *   ke IP/port server (self-host lama expose ini di config
 *   "public-address" + "port").
 *
 * API: https://lobfile.com/api/v3/docs/ -- POST multipart/form-data ke
 * https://lobfile.com/api/v3/upload.php, header X-API-Key, field "file".
 * Response JSON: {"success":true,"url":"..."} atau {"success":false,"error":"..."}.
 */
public class LobFileUploader {

    private static final String UPLOAD_URL = "https://lobfile.com/api/v3/upload.php";
    // Upload bisa lambat untuk pack besar (sampai ~100-250MB, lihat guard
    // ukuran di ResourcePackGenerator) di koneksi upload server yang
    // pas-pasan -- timeout digenerosikan supaya tidak gagal prematur.
    private static final Duration UPLOAD_TIMEOUT = Duration.ofMinutes(10);

    public record UploadResult(boolean success, String url, String error) {
        public static UploadResult ok(String url) {
            return new UploadResult(true, url, null);
        }

        public static UploadResult fail(String error) {
            return new UploadResult(false, null, error);
        }
    }

    private final String apiKey;

    public LobFileUploader(String apiKey) {
        this.apiKey = apiKey;
    }

    /**
     * Upload synchronous -- WAJIB dipanggil dari thread async (caller,
     * lihat ResourcePackModule, sudah di dalam AsyncUtil.runAsyncThenSync
     * heavyWork), karena ini I/O jaringan yang bisa makan waktu lama.
     */
    public UploadResult upload(File zipFile) {
        if (apiKey == null || apiKey.isBlank()) {
            return UploadResult.fail("API key LobFile kosong -- isi di secret.yml (field 'lobfile-api-key'). "
                    + "Daftar & ambil API key di https://lobfile.com/, aktifkan 'Continuous Uploading' di account settings.");
        }
        if (!zipFile.exists()) {
            return UploadResult.fail("File pack '" + zipFile.getAbsolutePath() + "' tidak ditemukan, upload dibatalkan.");
        }

        try {
            byte[] fileBytes = Files.readAllBytes(zipFile.toPath());
            String boundary = "AudesBoundary" + UUID.randomUUID();
            byte[] body = buildMultipartBody(boundary, zipFile.getName(), fileBytes);

            HttpClient client = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(30))
                    .build();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(UPLOAD_URL))
                    .header("X-API-Key", apiKey)
                    .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                    .timeout(UPLOAD_TIMEOUT)
                    .POST(HttpRequest.BodyPublishers.ofByteArray(body))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            return parseResponse(response.statusCode(), response.body());
        } catch (IOException e) {
            return UploadResult.fail("Gagal koneksi ke LobFile: " + e.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return UploadResult.fail("Upload ke LobFile diinterupsi.");
        } catch (Exception e) {
            // Sengaja tangkap Exception umum di sini (bukan cuma IOException) --
            // parsing JSON response yang gak terduga (mis. LobFile down & balikin
            // HTML error page, bukan JSON) tidak boleh bikin plugin crash, cukup
            // dilaporkan sebagai upload gagal dengan pesan jelas.
            return UploadResult.fail("Upload ke LobFile gagal tak terduga: " + e.getMessage());
        }
    }

    private UploadResult parseResponse(int statusCode, String responseBody) {
        if (responseBody == null || responseBody.isBlank()) {
            return UploadResult.fail("HTTP " + statusCode + ": respons kosong dari LobFile.");
        }
        JsonObject json;
        try {
            json = JsonParser.parseString(responseBody).getAsJsonObject();
        } catch (Exception e) {
            return UploadResult.fail("HTTP " + statusCode + ": respons bukan JSON valid (" + responseBody + ")");
        }
        boolean success = json.has("success") && json.get("success").getAsBoolean();
        if (!success) {
            String error = json.has("error") ? json.get("error").getAsString() : ("HTTP " + statusCode + " tanpa detail error.");
            return UploadResult.fail(error);
        }
        if (!json.has("url")) {
            return UploadResult.fail("Respons LobFile sukses tapi field 'url' tidak ada: " + responseBody);
        }
        return UploadResult.ok(json.get("url").getAsString());
    }

    private byte[] buildMultipartBody(String boundary, String filename, byte[] fileBytes) throws IOException {
        List<byte[]> parts = new ArrayList<>();
        String head = "--" + boundary + "\r\n"
                + "Content-Disposition: form-data; name=\"file\"; filename=\"" + filename + "\"\r\n"
                + "Content-Type: application/zip\r\n\r\n";
        parts.add(head.getBytes(StandardCharsets.UTF_8));
        parts.add(fileBytes);
        parts.add(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));

        int total = 0;
        for (byte[] p : parts) {
            total += p.length;
        }
        byte[] out = new byte[total];
        int pos = 0;
        for (byte[] p : parts) {
            System.arraycopy(p, 0, out, pos, p.length);
            pos += p.length;
        }
        return out;
    }
}
