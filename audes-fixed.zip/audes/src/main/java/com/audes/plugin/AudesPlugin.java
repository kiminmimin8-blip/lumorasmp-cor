package com.audes.plugin;

import com.audes.plugin.armor.ArmorModule;
import com.audes.plugin.block.CustomBlockModule;
import com.audes.plugin.core.ModuleManager;
import com.audes.plugin.emoji.EmojiModule;
import com.audes.plugin.emote.EmoteCommand;
import com.audes.plugin.emote.EmoteModule;
import com.audes.plugin.entity.EntityModule;
import com.audes.plugin.furniture.FurnitureModule;
import com.audes.plugin.gui.GuiModule;
import com.audes.plugin.hud.HudModule;
import com.audes.plugin.prefix.PrefixModule;
import com.audes.plugin.ranktab.RankTabModule;
import com.audes.plugin.resourcepack.ResourcePackManifest;
import com.audes.plugin.resourcepack.ResourcePackModule;
import com.audes.plugin.structure.StructureModule;
import com.audes.plugin.tools.CustomToolsModule;
import com.audes.plugin.vehicle.VehicleModule;
import org.bukkit.plugin.java.JavaPlugin;

public class AudesPlugin extends JavaPlugin {

    private ModuleManager moduleManager;
    private PrefixModule prefixModule;
    private CustomToolsModule customToolsModule;
    private ResourcePackModule resourcePackModule;
    private CustomBlockModule customBlockModule;
    private FurnitureModule furnitureModule;
    private ArmorModule armorModule;
    private EmojiModule emojiModule;
    private GuiModule guiModule;
    private EmoteModule emoteModule;
    private StructureModule structureModule;
    private VehicleModule vehicleModule;
    private EntityModule entityModule;
    private HudModule hudModule;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        // Dev15: cek sekali di awal biar admin langsung tau status Bedrock
        // support dari log startup (lihat BedrockPlayerDetector).
        com.audes.plugin.bedrock.BedrockPlayerDetector.isFloodgatePresent(getLogger());

        moduleManager = new ModuleManager(this);

        // Dev5: satu instance ResourcePackManifest dibagi ke semua modul yang
        // bikin item (tools/block/furniture) + ResourcePackModule yang
        // mengisinya. TIDAK masalah kalau resource-pack module enable()
        // belakangan/gagal -- manifest mulai dari kosong (Set.of()) dan
        // factory lain otomatis fallback vanilla + warning, bukan error.
        ResourcePackManifest resourcePackManifest = new ResourcePackManifest(getLogger());

        // Urutan register penting: prefix harus register duluan karena
        // rank-tab bergantung ke PrefixManager miliknya (lihat
        // RankTabModule constructor).
        prefixModule = new PrefixModule(this);
        customToolsModule = new CustomToolsModule(this, resourcePackManifest);
        resourcePackModule = new ResourcePackModule(this, resourcePackManifest);
        customBlockModule = new CustomBlockModule(this, resourcePackManifest);
        furnitureModule = new FurnitureModule(this, resourcePackManifest);
        armorModule = new ArmorModule(this, resourcePackManifest);
        emojiModule = new EmojiModule(this);
        guiModule = new GuiModule(this);
        emoteModule = new EmoteModule(this);
        structureModule = new StructureModule(this, customBlockModule);
        vehicleModule = new VehicleModule(this, resourcePackManifest);
        entityModule = new EntityModule(this, resourcePackManifest);
        hudModule = new HudModule(this);

        moduleManager.register(prefixModule);
        moduleManager.register(new RankTabModule(this, prefixModule));
        moduleManager.register(customToolsModule);
        moduleManager.register(resourcePackModule);
        moduleManager.register(customBlockModule);
        moduleManager.register(furnitureModule);
        moduleManager.register(armorModule);
        moduleManager.register(emojiModule);
        moduleManager.register(guiModule);
        moduleManager.register(emoteModule);
        moduleManager.register(structureModule); // WAJIB didaftar setelah customBlockModule (dependency)
        moduleManager.register(vehicleModule);
        moduleManager.register(entityModule);
        moduleManager.register(hudModule);

        moduleManager.enableAll();

        AudesCommand command = new AudesCommand(this, moduleManager, prefixModule, customToolsModule,
                customBlockModule, furnitureModule, armorModule, guiModule, structureModule, vehicleModule, entityModule, hudModule);
        getCommand("audes").setExecutor(command);
        getCommand("audes").setTabCompleter(command);

        EmoteCommand emoteCommand = new EmoteCommand(emoteModule);
        getCommand("emote").setExecutor(emoteCommand);
        getCommand("emote").setTabCompleter(emoteCommand);

        getLogger().info("[Audes] Plugin aktif.");
    }

    @Override
    public void onDisable() {
        if (moduleManager != null) {
            moduleManager.disableAll();
        }
        getLogger().info("[Audes] Plugin nonaktif.");
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public PrefixModule getPrefixModule() {
        return prefixModule;
    }

    public CustomToolsModule getCustomToolsModule() {
        return customToolsModule;
    }

    public ResourcePackModule getResourcePackModule() {
        return resourcePackModule;
    }

    public CustomBlockModule getCustomBlockModule() {
        return customBlockModule;
    }

    public FurnitureModule getFurnitureModule() {
        return furnitureModule;
    }

    public ArmorModule getArmorModule() {
        return armorModule;
    }

    public EmojiModule getEmojiModule() {
        return emojiModule;
    }

    public GuiModule getGuiModule() {
        return guiModule;
    }

    public EmoteModule getEmoteModule() {
        return emoteModule;
    }

    public StructureModule getStructureModule() {
        return structureModule;
    }

    public VehicleModule getVehicleModule() {
        return vehicleModule;
    }

    public EntityModule getEntityModule() {
        return entityModule;
    }

    public HudModule getHudModule() {
        return hudModule;
    }
}
