package com.audes.plugin.placeholder;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.prefix.PrefixDefinition;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * Expose data rank/prefix Audes ke PlaceholderAPI, supaya plugin lain
 * yang gak tau apa-apa soal Audes (TAB, DeluxeMenus, dll) tetap bisa
 * nampilin rank/prefix Audes lewat placeholder biasa.
 *
 * Placeholder yang didukung:
 *   %audes_rank%          -> rank key mentah (mis. "owner", "leo")
 *   %audes_prefix%        -> teks prefix LENGKAP dengan kode warna (mis. "&6[Owner]")
 *   %audes_prefix_plain%  -> teks prefix TANPA kode warna (buat sorting/placeholder lain
 *                             yang gak butuh warna, mis. scoreboard-teams sorting)
 *
 * Hanya aktif kalau PlaceholderAPI ke-detect di server (didaftarkan dari
 * AudesPlugin#onEnable, lihat catatan di sana) -- tidak wajib, plugin lain
 * (termasuk Audes sendiri) tetap jalan normal tanpa PlaceholderAPI.
 */
public class AudesPlaceholders extends PlaceholderExpansion {

    private final AudesPlugin plugin;

    public AudesPlaceholders(AudesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "audes";
    }

    @Override
    public @NotNull String getAuthor() {
        return "Bubuk";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer offlinePlayer, @NotNull String params) {
        if (!(offlinePlayer instanceof Player player) || !player.isOnline()) {
            return "";
        }
        if (plugin.getPrefixModule() == null) {
            return "";
        }

        var manager = plugin.getPrefixModule().getManager();

        return switch (params.toLowerCase()) {
            case "rank" -> manager.getRank(player);
            case "prefix" -> {
                PrefixDefinition def = manager.getDefinitionFor(player);
                yield def != null ? def.text() : "";
            }
            case "prefix_plain" -> {
                PrefixDefinition def = manager.getDefinitionFor(player);
                yield def != null ? def.text().replaceAll("(?i)[&§][0-9a-fk-or]", "") : "";
            }
            default -> {
                // %audes_img_<key>% -> gambar custom (logo dll) lewat font glyph.
                // Dibungkus tag MiniMessage <font:audes:images> supaya plugin
                // penerima (TAB, dll) nerapin font resource pack-nya, bukan
                // cuma nampilin karakter mentah yang gak ke-mapping ke gambar
                // apapun kalau di-render pake font vanilla.
                String lower = params.toLowerCase();
                if (lower.startsWith("img_")) {
                    String imageId = lower.substring(4);
                    var imageRegistry = plugin.getHudModule() != null ? plugin.getHudModule().getImageRegistry() : null;
                    if (imageRegistry == null) yield "";
                    yield imageRegistry.get(imageId)
                            .map(img -> "<font:audes:images>" + img.character() + "</font>")
                            .orElse("");
                }
                yield null; // biarin PlaceholderAPI kasih tau placeholder ini gak dikenal
            }
        };
    }
}
