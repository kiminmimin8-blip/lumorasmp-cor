package com.audes.plugin.bedrock;

import org.bukkit.Bukkit;

import java.util.UUID;
import java.util.logging.Logger;

/**
 * Dev15: deteksi player Bedrock (lewat Floodgate) tanpa bikin Floodgate
 * jadi dependency WAJIB -- server yang gak pakai Geyser/Floodgate sama
 * sekali TETAP bisa jalanin Audes normal (soft-dependency, lihat plugin.yml
 * "softdepend").
 *
 * KENAPA INI PERLU (bukan cuma nice-to-have): resource pack Java yang
 * di-generate ResourcePackModule TIDAK BISA dipakai player Bedrock --
 * beda format total (Java pakai assets/&lt;namespace&gt;/... , Bedrock
 * pakai manifest.json + struktur folder beda, lihat dokumentasi resmi
 * GeyserMC). Kalau player Bedrock tetap dikirimin ResourcePackRequest
 * Java seperti player biasa:
 * - Kalau "resource-pack.required: true" di config, player Bedrock bisa
 *   KE-KICK karena Geyser gak bisa proses pack itu jadi dianggap nolak.
 * - Minimal buang-buang bandwidth (download pack yang gak kepakai sama
 *   sekali di sisi Bedrock).
 * Makanya ResourcePackJoinListener (Dev15) cek lewat kelas ini SEBELUM
 * kirim, dan skip total untuk player Bedrock -- bukan cuma set
 * required=false untuk mereka.
 *
 * BATASAN JUJUR (supaya tim gak salah ekspektasi): kelas ini CUMA
 * jawab "apakah player ini Bedrock", TIDAK generate/convert resource
 * pack Bedrock apa pun. Custom item/block/furniture Audes SAAT INI
 * akan tampil sebagai item/block VANILLA biasa di sisi Bedrock (Geyser
 * fallback otomatis ke base item Java-nya kalau gak ada custom mapping)
 * -- fungsional (bisa dipegang/dipakai/efek jalan), TAPI visualnya BEDA
 * dari yang dilihat player Java. Supaya visual match, tim perlu salah
 * satu dari:
 * 1. Bikin manual custom item/block mapping JSON di folder
 *    "custom_mappings" milik Geyser + resource pack Bedrock terpisah
 *    (lihat https://geysermc.org/wiki/geyser/custom-items/) -- kerja
 *    manual per item, dan per catatan GeyserMC (issue #5303, per Jan
 *    2025 masih "Work in Progress") dukungan penuh untuk format
 *    item_model 1.21.4+ (yang Audes pakai) BELUM sempurna semua kasus
 *    di sisi Geyser sendiri -- ini keterbatasan upstream, bukan bug
 *    Audes.
 * 2. Pakai tool konversi otomatis pihak ketiga yang memang didesain
 *    untuk format items-definition 1.21.4+ (kalau tim mau eksplor,
 *    cari "ResourcePackManager"/RSPM di ecosystem plugin Minecraft --
 *    BELUM diintegrasikan/divalidasi di Audes, sekadar referensi arah).
 */
public final class BedrockPlayerDetector {

    private static Boolean floodgatePresentCache;

    private BedrockPlayerDetector() {
    }

    /** Dipanggil sekali di AudesPlugin.onEnable() buat log status ke admin, bukan wajib dipanggil ulang. */
    public static boolean isFloodgatePresent(Logger logger) {
        if (floodgatePresentCache != null) return floodgatePresentCache;
        boolean present = Bukkit.getPluginManager().getPlugin("floodgate") != null;
        if (logger != null) {
            if (present) {
                logger.info("[Audes] Floodgate terdeteksi -- player Bedrock akan di-skip dari pengiriman "
                        + "resource pack Java (lihat catatan BedrockPlayerDetector soal batasan visual).");
            } else {
                logger.info("[Audes] Floodgate tidak terdeteksi -- semua player dianggap Java. "
                        + "Kalau server ini juga terima player Bedrock lewat Geyser/Floodgate, install Floodgate "
                        + "supaya Audes bisa skip kirim resource pack Java ke mereka.");
            }
        }
        floodgatePresentCache = present;
        return present;
    }

    /**
     * true kalau UUID ini player Bedrock (lewat Floodgate). SELALU false
     * kalau Floodgate tidak ter-install -- tidak pernah throw meskipun
     * kelas org.geysermc.floodgate.api.FloodgateApi tidak ada di
     * classpath (NoClassDefFoundError ditangani manual di
     * FloodgateBridge, class terpisah, supaya JVM tidak coba load kelas
     * itu sama sekali kalau plugin Floodgate absen -- lihat alasan
     * class-splitting ini di javadoc FloodgateBridge).
     */
    public static boolean isBedrockPlayer(UUID playerUuid, Logger logger) {
        if (!isFloodgatePresent(logger)) return false;
        try {
            return FloodgateBridge.isBedrockPlayer(playerUuid);
        } catch (Throwable t) {
            // Floodgate plugin terdeteksi ADA tapi versi API-nya beda/gak
            // kompatibel -- jangan bikin Audes crash gara-gara ini, cukup
            // anggap "bukan Bedrock" (fallback paling aman: player tetap
            // dapat resource pack Java seperti biasa, bukan malah gagal join).
            if (logger != null) {
                logger.warning("[Audes] Gagal cek status Bedrock lewat Floodgate API: " + t.getMessage()
                        + " -- fallback anggap player Java biasa.");
            }
            return false;
        }
    }
}
