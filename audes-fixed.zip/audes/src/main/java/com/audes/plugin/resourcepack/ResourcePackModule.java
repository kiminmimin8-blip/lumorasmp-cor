package com.audes.plugin.resourcepack;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import com.audes.plugin.util.AsyncUtil;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.HandlerList;

import java.io.File;
import java.io.IOException;

/**
 * Generator + host resource pack untuk custom item model Audes.
 *
 * Dev4: diimplementasikan berdasarkan skeleton/TODO Dev3.
 * Dev5: manifest (ResourcePackManifest) ditambahkan, prioritas #3 di
 * daftar-fitur-itemsadder.md.
 *
 * Dev14: HOSTING DIGANTI TOTAL. Sampai Dev13, mode default adalah
 * self-host lewat ResourcePackServer (HTTP server bawaan JDK, mirip
 * cara lama ItemsAdder). Ini DIHAPUS, digantikan mode "lobfile" --
 * auto-upload ke https://lobfile.com/ (layanan yang SAMA dipakai
 * ItemsAdder untuk fitur "Continuous Uploading", lihat LobFileUploader
 * buat alasan detailnya). Alasan ganti bukan tambah opsi: self-host
 * webserver kita rawan kelas bug yang SAMA seperti insiden generated.zip
 * ItemsAdder tim (race condition nulis file resourcepack bersamaan saat
 * reload sementara masih ada yang download) -- upload sekali ke LobFile
 * menghilangkan kelas masalah ini karena kita tidak lagi jaga server
 * hidup sendiri.
 *
 * Mode hosting sekarang ("resource-pack.hosting-mode" di config.yml):
 * - "lobfile" (default): generate zip lalu upload ke LobFile, API key
 *   dari secret.yml (field "lobfile-api-key", TIDAK di config.yml biar
 *   gak ke-commit ke git kalau config di-share, pola sama seperti
 *   secret.yml ItemsAdder).
 * - "external-url": tim sudah punya CDN/hosting sendiri (Dropbox link,
 *   S3, dst) -- isi manual di "resource-pack.external-url", plugin tidak
 *   upload apa pun, cuma pakai URL itu langsung.
 *
 * Alur enable():
 * 1. Cek folder data/contents/ ada isinya atau tidak. Kalau kosong/tidak
 *    ada, modul tetap "aktif" (bukan error) tapi cuma log info.
 * 2. Generate zip dari contents/ WAJIB async (I/O berat: baca banyak
 *    file + hitung SHA-1 + rebuild manifest, lihat prinsip async di
 *    AsyncUtil).
 * 3. Guard ukuran: 250MB block (generate gagal eksplisit), 100MB warning.
 * 4. Hosting sesuai mode di atas (JUGA async, upload jaringan I/O berat).
 * 5. Kirim ke player saat join lewat ResourcePackJoinListener (Adventure
 *    ResourcePackRequest, native Paper, hash-validated).
 *
 * Dev14 juga menutup TODO Dev13: /audes reload sekarang manggil
 * regenerate() (public), dipanggil dari AudesCommand.handleReload --
 * jadi update aset di contents/ + API key baru di secret.yml bisa
 * langsung dipakai tanpa restart plugin/server.
 */
public class ResourcePackModule implements AudesModule {

    private final AudesPlugin plugin;
    private final ResourcePackManifest manifest;
    private ResourcePackJoinListener joinListener;

    public ResourcePackModule(AudesPlugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.manifest = manifest;
    }

    public ResourcePackManifest getManifest() {
        return manifest;
    }

    @Override
    public String getName() {
        return "resource-pack";
    }

    @Override
    public void enable() {
        regenerate();
    }

    /**
     * Generate ulang pack + rebuild manifest + (re-)upload/apply hosting,
     * lalu re-register join listener dengan URL/hash terbaru. Dipanggil
     * dari enable() (startup) DAN dari AudesCommand /audes reload (Dev14,
     * dulu jadi TODO -- lihat catatan kelas di atas).
     */
    public void regenerate() {
        // Aktif/nonaktifnya modul ini diatur lewat "modules.resource-pack"
        // di config.yml (konsisten dengan modul lain, lihat ModuleManager)
        // -- tidak ada toggle kedua di dalam sini supaya tidak membingungkan.
        File contentsFolder = new File(plugin.getDataFolder(), "contents");
        if (!contentsFolder.exists()) {
            contentsFolder.mkdirs();
            plugin.getLogger().info("[Audes] Folder 'contents/' dibuat kosong di " + contentsFolder.getAbsolutePath()
                    + " -- isi struktur namespace aset resource pack di sini, lalu /audes reload untuk generate.");
            return;
        }

        File outputZip = new File(plugin.getDataFolder(), "audes-pack.zip");
        String hostingMode = plugin.getConfig().getString("resource-pack.hosting-mode", "lobfile");
        String externalUrl = plugin.getConfig().getString("resource-pack.external-url", "");
        boolean required = plugin.getConfig().getBoolean("resource-pack.required", false);
        String promptMessage = plugin.getConfig().getString("resource-pack.prompt-message", "");

        // Lepas listener lama SEBELUM regenerate -- kalau ini dipanggil dari
        // /audes reload (bukan startup pertama), listener lama masih nempel
        // dengan URL/hash pack yang mau digantikan.
        if (joinListener != null) {
            HandlerList.unregisterAll(joinListener);
            joinListener = null;
        }

        // Generate + hosting WAJIB async -- I/O berat (baca semua file contents/
        // + hitung SHA-1 + rebuild manifest + upload jaringan ke LobFile kalau
        // mode "lobfile"), semuanya digabung di satu heavyWork task yang sama.
        AsyncUtil.runAsyncThenSync(
                plugin,
                () -> {
                    // Rebuild manifest DULUAN, terlepas dari sukses/gagalnya zip di bawah --
                    // supaya validasi modelKey tetap jalan meski generate zip gagal
                    // (mis. lewat batas 250MB), bukan ikut gagal total.
                    int modelCount = manifest.rebuild(contentsFolder);
                    ResourcePackGenerator.Result zipResult;
                    try {
                        File externalPacksFolder = new File(plugin.getDataFolder(), "external-packs");
                        zipResult = new ResourcePackGenerator().generate(contentsFolder, outputZip, externalPacksFolder, plugin.getLogger());
                    } catch (Exception e) {
                        plugin.getLogger().severe("[Audes] Gagal generate resource pack: " + e.getMessage());
                        zipResult = null;
                    }

                    LobFileUploader.UploadResult uploadResult = null;
                    if (zipResult != null && "lobfile".equalsIgnoreCase(hostingMode)) {
                        // Upload di dalam heavyWork yang sama -- jaringan sama-sama I/O
                        // berat, tidak boleh blocking main thread server.
                        uploadResult = new LobFileUploader(loadLobFileApiKey()).upload(outputZip);
                    }
                    return new GenerateOutcome(zipResult, modelCount, uploadResult);
                },
                outcome -> {
                    plugin.getLogger().info("[Audes] Manifest resource pack: " + outcome.modelCount()
                            + " item model terdaftar dari contents/assets/*/items/, "
                            + manifest.equipmentModelCount() + " equipment model dari contents/assets/*/equipment/.");

                    ResourcePackGenerator.Result result = outcome.zipResult();
                    if (result == null) {
                        // Generate gagal (sudah di-log di atas dengan pesan jelas,
                        // bukan silent fail) -- modul tetap "hidup" tapi tanpa kirim pack.
                        // Manifest tetap ke-rebuild jadi setItemModel() tetap bisa
                        // apply untuk model yang asetnya ada, meski pack belum terkirim.
                        return;
                    }

                    if (result.overWarnThreshold()) {
                        plugin.getLogger().warning("[Audes] Resource pack berukuran " + (result.sizeBytes() / (1024 * 1024))
                                + "MB, sudah lewat ambang 100MB -- pertimbangkan kompresi aset/texture "
                                + "supaya player koneksi lambat tidak gagal download (lihat bagian 8 dokumen rencana).");
                    }
                    plugin.getLogger().info("[Audes] Resource pack ter-generate (generate ke-" + result.version()
                            + ", " + (result.sizeBytes() / 1024) + "KB, sha1=" + result.sha1Hex() + ").");

                    String url;
                    if ("lobfile".equalsIgnoreCase(hostingMode)) {
                        LobFileUploader.UploadResult uploadResult = outcome.uploadResult();
                        if (uploadResult == null || !uploadResult.success()) {
                            String reason = uploadResult != null ? uploadResult.error() : "hasil upload tidak ada (bug internal).";
                            plugin.getLogger().severe("[Audes] Gagal upload resource pack ke LobFile: " + reason
                                    + " -- pack TIDAK dikirim ke player sampai upload berhasil. Cek 'lobfile-api-key' "
                                    + "di secret.yml, lalu /audes reload lagi.");
                            return;
                        }
                        url = uploadResult.url();
                        plugin.getLogger().info("[Audes] Resource pack ter-upload ke LobFile: " + url);
                    } else if ("external-url".equalsIgnoreCase(hostingMode)) {
                        if (externalUrl == null || externalUrl.isBlank()) {
                            plugin.getLogger().severe("[Audes] resource-pack.hosting-mode = external-url tapi "
                                    + "'external-url' kosong -- isi URL CDN/hosting pack di config.yml.");
                            return;
                        }
                        url = externalUrl;
                    } else {
                        plugin.getLogger().severe("[Audes] resource-pack.hosting-mode = '" + hostingMode
                                + "' tidak dikenal -- pakai 'lobfile' atau 'external-url'.");
                        return;
                    }

                    joinListener = new ResourcePackJoinListener(plugin, url, result.sha1Hex(), required, promptMessage);
                    plugin.getServer().getPluginManager().registerEvents(joinListener, plugin);
                    plugin.getLogger().info("[Audes] Resource pack siap dikirim ke player dari: " + url);
                }
        );
    }

    /**
     * secret.yml TERPISAH dari config.yml (pola sama seperti ItemsAdder) --
     * supaya API key tidak ikut ke-share/ke-commit kalau admin bagi
     * config.yml ke orang lain (mis. minta bantuan debug di forum/Discord).
     * File dibuat otomatis kalau belum ada, isinya placeholder kosong.
     */
    private String loadLobFileApiKey() {
        File secretFile = new File(plugin.getDataFolder(), "secret.yml");
        if (!secretFile.exists()) {
            try {
                secretFile.getParentFile().mkdirs();
                secretFile.createNewFile();
                YamlConfiguration fresh = new YamlConfiguration();
                fresh.set("lobfile-api-key", "");
                fresh.save(secretFile);
                plugin.getLogger().info("[Audes] File 'secret.yml' dibuat di " + secretFile.getAbsolutePath()
                        + " -- isi field 'lobfile-api-key' dengan API key dari https://lobfile.com/ "
                        + "(account settings -> aktifkan 'Continuous Uploading' -> copy API key).");
            } catch (IOException e) {
                plugin.getLogger().severe("[Audes] Gagal bikin secret.yml: " + e.getMessage());
                return "";
            }
        }
        YamlConfiguration secret = YamlConfiguration.loadConfiguration(secretFile);
        return secret.getString("lobfile-api-key", "");
    }

    @Override
    public void disable() {
        if (joinListener != null) {
            HandlerList.unregisterAll(joinListener);
            joinListener = null;
        }
    }

    /** Hasil gabungan satu siklus heavyWork: zip pack (nullable kalau gagal) + jumlah model + hasil upload (nullable kalau mode bukan lobfile / zip gagal). */
    private record GenerateOutcome(ResourcePackGenerator.Result zipResult, int modelCount, LobFileUploader.UploadResult uploadResult) {
    }
}
