package com.audes.plugin.tools;

import com.audes.plugin.resourcepack.ResourcePackManifest;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

/**
 * Membuat ItemStack untuk custom tool, ditandai lewat PersistentDataContainer
 * (bukan lore/NBT manual yang rapuh) supaya gampang & aman dibaca ulang
 * oleh CustomToolListener saat item dipakai.
 *
 * Dev5: custom texture/model SEKARANG diterapkan lewat setItemModel(),
 * TAPI cuma kalau ResourcePackManifest konfirmasi aset modelKey-nya
 * benar-benar ada di contents/ (lihat ResourcePackManifest). Kalau tidak
 * ketemu, item tetap tampil material vanilla dan admin dapat WARNING
 * sekali di log (bukan invisible/silent fail seperti risiko yang
 * disebut Dev4 di STATUS-DEV4.md).
 */
public class ToolFactory {

    public static final String TOOL_ID_KEY = "tool_id";

    private final Plugin plugin;
    private final NamespacedKey toolIdKey;
    private final ResourcePackManifest manifest;
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    public ToolFactory(Plugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.toolIdKey = new NamespacedKey(plugin, TOOL_ID_KEY);
        this.manifest = manifest;
    }

    public ItemStack create(ToolDefinition def) {
        ItemStack item = new ItemStack(def.material());
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(LEGACY.deserialize(def.displayName()));
            meta.getPersistentDataContainer().set(toolIdKey, PersistentDataType.STRING, def.id());
            applyModelIfAvailable(meta, def.modelKey());
            if (def.lore() != null && !def.lore().isEmpty()) {
                meta.lore(def.lore().stream().map(LEGACY::deserialize).toList());
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    /**
     * Apply setItemModel() HANYA kalau manifest konfirmasi aset-nya ada.
     * NamespacedKey.fromString() bisa return null kalau formatnya salah
     * (bukan "namespace:path") -- ditangani sebagai "tidak valid", sama
     * seperti modelKey yang tidak ketemu di manifest.
     */
    private void applyModelIfAvailable(ItemMeta meta, String modelKey) {
        if (modelKey == null || modelKey.isBlank()) return;

        if (!manifest.hasModel(modelKey)) {
            manifest.warnMissingOnce(modelKey, "tool (ToolFactory)");
            return;
        }

        NamespacedKey key = NamespacedKey.fromString(modelKey);
        if (key == null) {
            plugin.getLogger().warning("[Audes] modelKey '" + modelKey
                    + "' di tool bukan format 'namespace:path' yang valid, di-skip.");
            return;
        }
        meta.setItemModel(key);
    }

    /** Return tool id kalau item ini custom tool Audes, null kalau bukan. */
    public String getToolId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        return meta.getPersistentDataContainer().get(toolIdKey, PersistentDataType.STRING);
    }
}
