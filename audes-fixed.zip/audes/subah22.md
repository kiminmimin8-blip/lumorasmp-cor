# subah22 — Changelog & Status Plugin Audes

Satu file ini gantiin semua `STATUS-DEV1.md` s.d. `STATUS-DEV15.md` +
`REVISI.md` yang sebelumnya kepisah-pisah. Isinya ringkasan tiap sesi
dev, urut dari awal, biar tim (atau sesi Claude berikutnya) tinggal baca
satu tempat.

**Catatan yang berlaku di SEMUA sesi**: kode ditulis manual mengikuti API
Paper/Adventure yang diketahui, TANPA akses internet buat `mvn package`
dan TANPA server Paper sungguhan buat testing langsung. Setiap sesi
mendokumentasikan asumsi API yang berisiko secara eksplisit (bukan
silent gap) — kalau ada error compile, cek dulu bagian sesi terkait di
bawah sebelum nebak dari nol.

---

## Dev3 — Skeleton awal
Fondasi project: `pom.xml`, struktur modul (`ModuleManager`, interface
`AudesModule`), `AudesPlugin` + `AudesCommand` dasar. Belum ada fitur
konkret, baru arsitektur.

## Dev1 — Custom block dasar (lanjutan Dev4 yang keputus)
`BlockItemFactory` + `CustomBlockListener` — teknik NOTE_BLOCK +
instrument/note sebagai "id" block custom (karena Paper belum punya
block model API resmi). Place/break lewat PDC (persistent data
container), bukan parsing nama/lore.

## Dev4 — Lanjutan skeleton
Resource pack module tahap awal: generator zip + self-host webserver
(`ResourcePackServer`, DIHAPUS di Dev14 — lihat bawah) + join listener
pakai Adventure `ResourcePackRequest`.

## Dev5 — Manifest resource pack + apply model
`ResourcePackManifest`: scan `contents/assets/<namespace>/items/*.json`
jadi daftar model valid. `ToolFactory`/`BlockItemFactory`/
`FurnitureItemFactory` query manifest sebelum `setItemModel()` — kalau
modelKey dikonfigurasi tapi aset tidak ada → warning log sekali (bukan
silent fail/invisible item).

## Dev6 — ✅ Compile pertama SUKSES + Custom Armor Texture
Konfirmasi: `Audes-0_1_0-SNAPSHOT.jar` pertama berhasil di-compile (44
class file cocok 32 source file Dev1-5). Fitur baru: armor custom lewat
`EquippableComponent` (base item tetap armor vanilla asli, visual
di-override).

## Dev7 — Custom Ore
`ToolTier` enum (WOOD→NETHERITE) + `requiredToolTier`/`xpMin`/`xpMax` di
`BlockDefinition`. Backward compatible (default = tidak ada efek).

## Dev8 — Emoji Chat
`EmojiRegistry` (satu regex gabungan, bukan loop per-shortcode) +
`EmojiManager` (Adventure `Component#replaceText`) + `EmojiListener`
(priority LOWEST). Cakupan cuma chat (belum ada modul book/hologram).

## Dev9 — Custom Furniture "Animasi" (toggle-state)
Animasi tekstur murni = resource-pack-side (`.mcmeta`), tidak butuh
kode. Yang butuh kode: toggle-state terpicu interaksi (lampu
nyala/mati dll) — ini yang dibangun.

## Dev10 — ✅ Compile kedua SUKSES + Custom GUI
54 class file, semua modul Dev6-9 lengkap. Fitur baru: `GuiDefinition` +
`GuiButtonDefinition` generik di config `guis:`, tombol jalanin command
list. Keterbatasan didokumentasikan: command tombol jalan sebagai
player (GUI admin-only gagal) — ditutup Dev12.

## Dev11 — Isi Resource Pack (aset nyata)
Sebelumnya semua `modelKey` fallback vanilla karena aset belum ada.
Sesi ini isi placeholder valid (PNG 16x16/64x32 via PIL, bukan file
kosong) untuk semua contoh di config.yml bawaan + `pack.mcmeta`
(`pack_format: 75`).

## Dev12 — Nutup keterbatasan GUI (Dev10)
Opt-in run-as-console PER BARIS command di tombol GUI: prefix
`[console] ` di awal baris → dijalankan lewat
`Bukkit.dispatchCommand(consoleSender, ...)`. Default tidak berubah.

## Dev13 — 4 modul baru + 2 fitur extend
`emote/` (`/emote <id>`, teks ngambang animasi), `structure/`
(`/audes givestructure`, custom tree/decoration multi-block),
`vehicle/`, `entity/`, `hud/` (custom scoreboard/actionbar — sempat
kelupaan di pass pertama, ditambahkan setelah ditanya user).

## Dev14 — Hosting resource pack diganti + Key & Crate item
- **Hosting**: self-host webserver (`ResourcePackServer`) DIHAPUS
  total, diganti auto-upload ke **LobFile** (layanan yang sama dipakai
  ItemsAdder buat "Continuous Uploading") — alasan: self-host rawan
  race condition kalau `/audes reload` dipanggil pas ada yang masih
  download (persis insiden `generated.zip` korup di ItemsAdder tim).
  Config baru: `resource-pack.hosting-mode` (`lobfile` / `external-url`),
  API key di `secret.yml` terpisah dari `config.yml`.
- **`/audes reload`** sekarang beneran regenerate pack (dulu cuma
  reload config file, TODO Dev13 ditutup).
- **7 Key item** (legendary/mythic/vote/earth/fire/water/wind) — texture
  PNG asli di-copy dari archive backup ItemsAdder lama tim, SIAP PAKAI.
- **7 Crate block** — pakai teknik note+instrument yang sudah ada.
  Visual BELUM custom (keterbatasan block-model, lihat Dev1). Mekanisme
  buka-crate (roll loot pakai key) BELUM ada — dulu di ItemsAdder pun
  itu kerjaan plugin terpisah (ExcellentCrates), bukan ItemsAdder
  sendiri.
- Field `lore` baru ditambah ke `ToolDefinition`/`ToolRegistry`/
  `ToolFactory` (belum ada sebelumnya).

## Dev15 — Bedrock support tahap 1 (deteksi player, BUKAN convert pack)
- `bedrock/BedrockPlayerDetector` + `bedrock/FloodgateBridge` — deteksi
  player Bedrock lewat Floodgate (soft-dependency, aman kalau Floodgate
  gak ter-install). `FloodgateBridge` sengaja kelas terpisah supaya JVM
  gak coba load `FloodgateApi` kecuali Floodgate konfirmasi ada.
- `ResourcePackJoinListener` skip total kirim pack Java ke player
  Bedrock (mencegah ke-kick kalau `required: true`, dan pack Java emang
  gak bisa diproses Bedrock).
- **BELUM dikerjakan** (keterbatasan riil, bukan gap kerja): visual
  custom item/block belum ikut ke Bedrock — butuh Geyser custom mapping
  manual + resource pack Bedrock terpisah (format beda total). Ada bug
  upstream masih open di Geyser (per riset saat itu) untuk format
  item_model 1.21.4+ yang Audes pakai.

## Setelah Dev15 — Klarifikasi soal crate
Sempat dibangun modul `crate/` (mekanisme buka-crate: konsumsi key +
roll loot table) — **DIHAPUS lagi** setelah dikonfirmasi tim sudah
pakai **ExcellentCrates** buat urusan reward/gacha. Audes CUKUP
nyediain **custom block**-nya (sudah ada dari Dev14: `crate4_block`,
`crate5_block`, `crate6_block`, `earth_crate_block`, dst) — ExcellentCrates
bind ke block itu lewat `/crate create` diarahkan ke lokasinya, TIDAK
butuh entity, TIDAK butuh kode tambahan apa pun di Audes. Kalau
suatu saat ExcellentCrates dilepas dan mau full self-contained lagi di
Audes, modul `crate/` yang dihapus ini bisa dibangun ulang (pola
lengkapnya: `CrateDefinition`/`CrateLootEntry`/`CrateRegistry`/
`CrateInteractListener`/`CrateModule`, weighted single-pick loot,
opsional reward berupa custom tool lewat `reward-tool-id`) — tapi
JANGAN dipasang lagi selama ExcellentCrates masih aktif, bisa rebutan
event klik kanan di block yang sama.

---

## Dev16 — Badge/logo rank di tab list
Diporting dari ItemsAdder namespace "sanzranks" (sebenarnya aset plugin
BetterRanks yang nempel font ItemsAdder — teknik font-glyph-nya generik,
diporting tanpa perlu plugin BetterRanks). 17 texture badge asli
(owner/admin/staff/dev/helper/builder/verified/player + 8 zodiac)
di-copy dari archive, dibungkus jadi 1 font provider
(`contents/assets/audes/font/rank_badges.json`, codepoint Private Use
Area U+F000-U+F010).

- **`RankBadgeDefinition`/`RankBadgeRegistry`** (baru) — load
  "rank-badges:" config, key HARUS sama dengan key rank di "prefix:".
- **`TabListManager`** — prepend badge (Component + `.font()`) SEBELUM
  prefix teks di nama tab list. Di-skip buat player Bedrock
  (`BedrockPlayerDetector`, lihat Dev15) karena font custom cuma ada di
  resource pack Java yang gak pernah dikirim ke mereka.
- **BELUM DITES visual** — height/ascent font pakai default generik (8/7),
  kemungkinan perlu di-tuning manual di server sungguhan kalau ukuran
  badge kelihatan gak pas.
- **Scoreboard sidebar TIDAK disentuh** (di luar scope kalimat "logo di
  scoreboard" kalau yang dimaksud beneran scoreboard sidebar, bukan tab
  list) — Audes belum punya modul scoreboard sidebar sama sekali, cuma
  bossbar/actionbar (HudModule). Kabari kalau ini juga perlu.

## Dev17 — File convert Bedrock buat Geyser-Spigot
Folder `bedrock/` (baru): mapping custom item Geyser v2
(`custom_mappings/audes_keys.json`) + resource pack Bedrock siap-pasang
(`audes_bedrock_pack.zip`), khusus buat 7 key item. Cara pasang ada di
`bedrock/README.md`.

Block/furniture/armor BELUM ikut ter-convert -- bukan kelupaan, tapi
aset sumbernya di sisi Java sendiri belum ada (block masih teknik
note+instrument, belum ada model/texture asli buat di-convert).
Formatnya diambil dari dokumentasi resmi GeyserMC per Juli 2026, belum
pernah dites di server Geyser sungguhan.

## Belum dikerjakan sama sekali (per akhir Dev15)
- Mekanisme buka crate (roll loot table pakai key, consume key,
  animasi/efek) — item & block-nya ada (Dev14), logikanya belum.
- Resource pack Bedrock + Geyser custom mapping (visual parity penuh).
- Compile & test di server sungguhan — SELALU jadi langkah wajib
  pertama sebelum production, di setiap sesi.
