import json, os
from PIL import Image, ImageDraw
import os as _os
_SCRIPT_DIR = _os.path.dirname(_os.path.abspath(__file__))
_CONTENTS_DIR = _os.path.normpath(_os.path.join(_SCRIPT_DIR, '..', '..', 'contents'))

BASE = _os.path.join(_CONTENTS_DIR, 'assets', 'audes')

equip_path = "armor/zirah_petir"
equip_def = {
    "layers": {
        "humanoid": [
            {"texture": f"audes:{equip_path}"}
        ],
        "humanoid_leggings": [
            {"texture": f"audes:{equip_path}_legs"}
        ]
    }
}
equip_json_path = os.path.join(BASE, "equipment", equip_path + ".json")
os.makedirs(os.path.dirname(equip_json_path), exist_ok=True)
with open(equip_json_path, "w") as f:
    json.dump(equip_def, f, indent=2)

# Layer 1 (armor_layer_1, dipakai helmet/chestplate/boots): placeholder 64x32
img = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
draw = ImageDraw.Draw(img)
draw.rectangle([16, 16, 31, 31], fill=(90, 160, 255, 255))  # body
draw.rectangle([40, 16, 47, 31], fill=(90, 160, 255, 255))  # arm kanan
draw.rectangle([32, 16, 39, 31], fill=(90, 160, 255, 255))  # arm kiri
tex_path = os.path.join(BASE, "textures", "entity", "equipment", equip_path + ".png")
os.makedirs(os.path.dirname(tex_path), exist_ok=True)
img.save(tex_path)

# Layer 2 (armor_layer_2, dipakai KHUSUS leggings -- UV beda dari layer 1,
# lebih "nempel" ke kaki). Tanpa file ini leggings tetap ke-equip secara
# fungsional (armor value/enchant tetap jalan) tapi visualnya bisa blank
# di area paha-betis. Placeholder 64x32 sama warna biar konsisten dulu.
img_legs = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
draw_legs = ImageDraw.Draw(img_legs)
draw_legs.rectangle([0, 16, 15, 31], fill=(90, 160, 255, 255))   # kaki kanan
draw_legs.rectangle([4, 16, 11, 31], fill=(70, 130, 220, 255))   # aksen tengah
tex_legs_path = os.path.join(BASE, "textures", "entity", "equipment", equip_path + "_legs.png")
img_legs.save(tex_legs_path)

print("equipment model & texture selesai (layer helm/chest/boots + layer leggings)")
