# Cara pasang di Geyser-Spigot

Ini CUMA buat 7 key item (legendary/mythic/vote/earth/fire/water/wind).
Block/furniture/armor custom Audes BELUM di-convert — alasannya di
bagian bawah.

## 1. Custom item mapping

- File: `custom_mappings/audes_keys.json`
- Taruh di: `plugins/Geyser-Spigot/custom_mappings/`
  (folder ini otomatis ke-buat begitu Geyser-Spigot pernah start sekali)

## 2. Resource pack Bedrock

- File: `audes_bedrock_pack.zip`
- Taruh di: `plugins/Geyser-Spigot/packs/`

## 3. Config Geyser

Buka `plugins/Geyser-Spigot/config.yml`, cari `enable-custom-content`,
pastikan `true`.

## 4. Restart server

Restart, bukan reload — Geyser baca custom_mappings & packs pas startup.

## Cara ngetes

Kasih diri sendiri key-nya (`/audes give <namamu> legendary_key`), terus
login dari akun Bedrock (via Geyser). Icon-nya harus keliatan beda dari
paper polos.

## Kenapa cuma key, bukan semua item

- **Block crate (note block)** — Geyser custom block mapping butuh
  geometry Bedrock (format beda total dari block Java), dan block-block
  Audes sendiri belum punya model/texture asli (masih pakai teknik
  note+instrument doang, lihat catatan di blocks: config.yml). Gak ada
  yang bisa di-convert karena sumbernya juga belum ada.
- **Furniture, armor, custom block lain** — sama, belum ada aset
  visual di sisi Java yang bisa di-convert. Kalau nanti itemnya udah
  ada model beneran, tinggal tambah entry baru di `audes_keys.json`
  (atau file mapping baru) pakai pola yang sama kayak di sini.

## Belum dites

File ini dibuat manual ngikutin dokumentasi resmi GeyserMC (format v2,
per Juli 2026), belum pernah dites di server Geyser sungguhan. Kalau
icon gak muncul / error pas start, kemungkinan besar di
`enable-custom-content` yang belum true, atau path folder yang beda
dari yang disebut di atas (tergantung versi Geyser-Spigot yang dipakai).
