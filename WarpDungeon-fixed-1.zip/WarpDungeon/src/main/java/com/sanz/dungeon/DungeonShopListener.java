package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class DungeonShopListener implements Listener {

    private final DungeonShopManager shopManager;
    private final DungeonCurrencyProvider currency;

    public DungeonShopListener(DungeonShopManager shopManager, DungeonCurrencyProvider currency) {
        this.shopManager = shopManager;
        this.currency = currency;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof DungeonShopGUI.Holder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;

        Integer tradeId = holder.getTradeId(e.getRawSlot());
        if (tradeId == null) return;
        ShopTrade t = shopManager.get(tradeId);
        if (t == null || !t.isReady()) return;

        ItemStack req1 = t.buildInput1();
        ItemStack req2 = t.buildInput2();

        // containsAtLeast/removeItem Bukkit ngecek pake ItemStack#isSimilar (Material +
        // seluruh ItemMeta, termasuk PDC), jadi item custom MythicMobs (yg beda cuma
        // di NBT/lore/model data) otomatis gak ketuker sama item vanilla biasa.
        if (!p.getInventory().containsAtLeast(req1, req1.getAmount())) {
            p.sendMessage(ChatColor.RED + "Item drop kamu kurang. Butuh " + req1.getAmount() + "x " + itemName(req1) + ".");
            return;
        }
        if (req2 != null && !p.getInventory().containsAtLeast(req2, req2.getAmount())) {
            p.sendMessage(ChatColor.RED + "Item drop kamu kurang. Butuh " + req2.getAmount() + "x " + itemName(req2) + ".");
            return;
        }

        // Kalau output-nya MONEY, coba deposit DULU sebelum item pemain diambil.
        // Sebelumnya item langsung diambil duluan baru nyoba deposit - kalau
        // deposit gagal (Vault belum ke-install, atau currency "cash"/"shards"
        // yang statusnya masih stub/TODO di DungeonCurrencyProvider), pemain
        // kehilangan item drop-nya tapi gak dapet apa-apa. Sekarang urutannya
        // dibalik: item cuma diambil kalau pembayarannya beneran berhasil.
        if (t.getOutputType() == ShopTrade.OutputType.MONEY) {
            if (!currency.deposit(p, t.getOutputCurrency(), t.getOutputMoney())) {
                p.sendMessage(ChatColor.RED + "Gagal proses tukar (currency '" + t.getOutputCurrency()
                        + "' belum kesambung/error). Item kamu gak diambil, coba lagi nanti.");
                return;
            }
            p.getInventory().removeItem(req1);
            if (req2 != null) p.getInventory().removeItem(req2);
            p.sendMessage(ChatColor.GREEN + "Ditukar jadi " + currency.format(t.getOutputCurrency(), t.getOutputMoney()) + ".");
        } else {
            p.getInventory().removeItem(req1);
            if (req2 != null) p.getInventory().removeItem(req2);

            ItemStack out = t.buildOutputItem();
            java.util.Map<Integer, ItemStack> leftover = p.getInventory().addItem(out);
            leftover.values().forEach(item -> p.getWorld().dropItem(p.getLocation(), item));
            p.sendMessage(ChatColor.GREEN + "Ditukar jadi " + out.getAmount() + "x " + itemName(out) + ".");
        }
    }

    private String itemName(ItemStack item) {
        return item.hasItemMeta() && item.getItemMeta().hasDisplayName()
                ? ChatColor.stripColor(item.getItemMeta().getDisplayName())
                : item.getType().name();
    }
}
