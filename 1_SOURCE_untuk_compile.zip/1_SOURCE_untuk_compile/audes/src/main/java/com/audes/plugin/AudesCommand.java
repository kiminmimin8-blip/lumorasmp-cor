package com.audes.plugin;

import com.audes.plugin.armor.ArmorDefinition;
import com.audes.plugin.armor.ArmorModule;
import com.audes.plugin.block.BlockDefinition;
import com.audes.plugin.block.CustomBlockModule;
import com.audes.plugin.core.ModuleManager;
import com.audes.plugin.event.AudesRankChangeEvent;
import com.audes.plugin.furniture.FurnitureDefinition;
import com.audes.plugin.furniture.FurnitureModule;
import com.audes.plugin.gui.GuiDefinition;
import com.audes.plugin.gui.GuiModule;
import com.audes.plugin.hud.HudDefinition;
import com.audes.plugin.hud.HudModule;
import com.audes.plugin.entity.EntityDefinition;
import com.audes.plugin.entity.EntityModule;
import com.audes.plugin.prefix.PrefixModule;
import com.audes.plugin.shop.ShopDefinition;
import com.audes.plugin.shop.ShopModule;
import com.audes.plugin.structure.StructureDefinition;
import com.audes.plugin.structure.StructureModule;
import com.audes.plugin.tools.CustomToolsModule;
import com.audes.plugin.vehicle.VehicleDefinition;
import com.audes.plugin.vehicle.VehicleModule;
import com.audes.plugin.tools.ToolDefinition;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class AudesCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBCOMMANDS = List.of(
            "reload", "checkmodels", "fixvisuals", "info", "give", "giveblock",
            "givefurniture", "givearmor", "givestructure", "givevehicle",
            "givemobitem", "setrank", "gui", "hud", "shop", "shopedit"
    );

    /** Subcommand yang argumen ke-2 (index 1) nya berupa nama player. */
    private static final Set<String> PLAYER_ARG_AT_INDEX_1 = Set.of(
            "give", "giveblock", "givefurniture", "givearmor", "givestructure",
            "givevehicle", "givemobitem", "setrank"
    );

    /** Subcommand yang argumen ke-3 (index 2, opsional) nya berupa nama player. */
    private static final Set<String> PLAYER_ARG_AT_INDEX_2 = Set.of("shop", "hud", "gui");

    private final AudesPlugin plugin;
    private final ModuleManager moduleManager;
    private final PrefixModule prefixModule;
    private final CustomToolsModule customToolsModule;
    private final CustomBlockModule customBlockModule;
    private final FurnitureModule furnitureModule;
    private final ArmorModule armorModule;
    private final GuiModule guiModule;
    private final StructureModule structureModule;
    private final VehicleModule vehicleModule;
    private final EntityModule entityModule;
    private final HudModule hudModule;
    private final ShopModule shopModule;

    public AudesCommand(AudesPlugin plugin, ModuleManager moduleManager,
                         PrefixModule prefixModule, CustomToolsModule customToolsModule,
                         CustomBlockModule customBlockModule, FurnitureModule furnitureModule,
                         ArmorModule armorModule, GuiModule guiModule, StructureModule structureModule,
                         VehicleModule vehicleModule, EntityModule entityModule, HudModule hudModule,
                         ShopModule shopModule) {
        this.plugin = plugin;
        this.moduleManager = moduleManager;
        this.prefixModule = prefixModule;
        this.customToolsModule = customToolsModule;
        this.customBlockModule = customBlockModule;
        this.furnitureModule = furnitureModule;
        this.armorModule = armorModule;
        this.guiModule = guiModule;
        this.structureModule = structureModule;
        this.vehicleModule = vehicleModule;
        this.entityModule = entityModule;
        this.hudModule = hudModule;
        this.shopModule = shopModule;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§7Audes §8» §7Pakai /audes <reload|checkmodels|fixvisuals|info|give|giveblock|givefurniture|givearmor|givestructure|givevehicle|givemobitem|setrank|gui|hud|shop|shopedit>");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> handleReload(sender);
            case "checkmodels" -> handleCheckModels(sender);
            case "fixvisuals" -> handleFixVisuals(sender);
            case "info" -> handleInfo(sender);
            case "give" -> handleGive(sender, args);
            case "giveblock" -> handleGiveBlock(sender, args);
            case "givefurniture" -> handleGiveFurniture(sender, args);
            case "givearmor" -> handleGiveArmor(sender, args);
            case "givestructure" -> handleGiveStructure(sender, args);
            case "givevehicle" -> handleGiveVehicle(sender, args);
            case "givemobitem" -> handleGiveMobItem(sender, args);
            case "setrank" -> handleSetRank(sender, args);
            case "gui" -> handleGui(sender, args);
            case "hud" -> handleHud(sender, args);
            case "shop" -> handleShop(sender, args);
            case "shopedit" -> handleShopEdit(sender, args);
            default -> sender.sendMessage("§cSubcommand tidak dikenal. Pakai /audes <reload|checkmodels|fixvisuals|info|give|giveblock|givefurniture|givearmor|givestructure|givevehicle|givemobitem|setrank|gui|hud|shop|shopedit>");
        }
        return true;
    }

    private void handleReload(CommandSender sender) {
        plugin.reloadConfig();
        // Dev14: menutup TODO Dev13 -- reload SEKARANG memicu regenerate
        // resource pack (generate ulang zip + rebuild manifest + upload
        // ulang ke LobFile/external-url sesuai config baru), jadi update
        // aset di contents/ atau API key baru di secret.yml langsung
        // kepakai tanpa restart plugin/server. Modul LAIN (tools, block,
        // furniture, dst) masih belum full hot-reload -- itu tetap butuh
        // restart plugin, disengaja: hot-reload modul yang punya listener/
        // task aktif berisiko duplikat kalau di-enable dua kali tanpa
        // testing lebih dulu (sama seperti catatan lama).
        plugin.getResourcePackModule().regenerate();

        // Dev18: shop DITAMBAHIN ke daftar yang hot-reload -- beda dari
        // modul lain (gak punya listener/task yang bisa dobel kalau
        // di-reload), ShopRegistry cuma nge-parse ulang config.yml ke
        // memory, aman dipanggil berkali-kali. Ini juga yang dipanggil
        // ShopEditListener abis nyimpen perubahan lewat GUI edit.
        if (plugin.getShopModule() != null && plugin.getShopModule().getRegistry() != null) {
            plugin.getShopModule().getRegistry().loadFromConfig(plugin.getConfig().getConfigurationSection("shop"));
        }

        sender.sendMessage("§aAudes: config.yml di-reload, resource pack di-generate ulang & di-upload "
                + "(cek console buat hasil upload), menu shop di-reload. Modul lain belum full hot-reload, restart plugin kalau perlu.");
    }

    /**
     * /audes fixvisuals — benerin ItemDisplay yang udah kepasang di
     * world SEBELUM fix ItemDisplayTransform (lihat javadoc method-nya
     * di CustomBlockListener). Block yang ditaro SETELAH fix ini gak
     * butuh command ini, otomatis udah bener dari awal.
     */
    private void handleFixVisuals(CommandSender sender) {
        int fixed = plugin.getCustomBlockModule().getListener().refreshAllVisualTransforms();
        sender.sendMessage("§aBeres, " + fixed + " visual block ke-refresh transform-nya. "
                + "Cuma yang ada di chunk yang lagi loaded -- kalau masih ada yang keliatan gepeng/putih, "
                + "coba jalanin lagi command ini abis lu (atau player) sempet lewat situ.");
    }

    /**
     * /audes checkmodels — versi ringkas ala /iatag ItemsAdder: bandingin
     * tiap modelKey/assetId yang dipakai di config.yml sama file JSON yang
     * beneran ada di contents/assets/. Beda dari warnMissingOnce() (yang
     * cuma nongol sekali di console log), ini bisa dipanggil kapan aja
     * buat ngecek status TANPA harus create item/armor dulu.
     */
    private void handleCheckModels(CommandSender sender) {
        var manifest = plugin.getResourcePackModule().getManifest();
        List<String> missing = new ArrayList<>();
        int total = 0;

        if (customToolsModule != null) {
            for (ToolDefinition def : customToolsModule.getRegistry().getAll().values()) {
                total++;
                if (!manifest.hasModel(def.modelKey())) missing.add("tool:" + def.modelKey());
            }
        }
        if (customBlockModule != null) {
            for (BlockDefinition def : customBlockModule.getRegistry().getAll().values()) {
                total++;
                if (!manifest.hasModel(def.modelKey())) missing.add("block:" + def.modelKey());
            }
        }
        if (furnitureModule != null) {
            for (FurnitureDefinition def : furnitureModule.getRegistry().getAll().values()) {
                total++;
                if (!manifest.hasModel(def.modelKey())) missing.add("furniture:" + def.modelKey());
            }
        }
        if (armorModule != null) {
            for (ArmorDefinition def : armorModule.getRegistry().getAll().values()) {
                total++;
                if (!manifest.hasEquipmentModel(def.assetId())) missing.add("armor:" + def.assetId());
            }
        }

        sender.sendMessage("§7Audes §8» §7Cek " + total + " modelKey/assetId dari config.yml vs contents/assets/.");
        if (missing.isEmpty()) {
            sender.sendMessage("§aSemua modelKey ketemu file-nya. Kalau item masih tampil polos/putih, "
                    + "kemungkinan resourcepack belum ke-apply di client (cek /audes reload dulu, terus rejoin).");
        } else {
            sender.sendMessage("§c" + missing.size() + " modelKey TIDAK ketemu file JSON-nya (fallback ke vanilla material):");
            for (String m : missing) {
                sender.sendMessage("§7 - §c" + m);
            }
        }
    }

    private void handleInfo(CommandSender sender) {
        sender.sendMessage("§7Status modul Audes:");
        for (String mod : List.of("custom-tools", "prefix", "rank-tab", "resource-pack", "custom-block", "furniture", "armor", "emoji", "gui", "emote", "structure", "vehicle", "entity", "hud")) {
            boolean active = moduleManager.isActive(mod);
            sender.sendMessage((active ? "§a✔ " : "§c✘ ") + mod);
        }
    }

    /**
     * Spesifikasi satu subcommand "/audes give*" — dulunya tiap subcommand
     * (give, giveblock, givefurniture, givearmor, givestructure, givevehicle,
     * givemobitem) punya method sendiri yang isinya 95% identik (validasi
     * argumen, cek modul aktif, cek player online, lookup registry, buat
     * item, kirim pesan). Sekarang cuma dideklarasikan sekali di sini per
     * subcommand lewat record ini, dieksekusi oleh {@link #handleGiveGeneric}.
     *
     * @param usage             kata subcommand-nya sendiri, dipakai di pesan usage (mis. "giveblock")
     * @param moduleActive      null-check modul DAN moduleManager.isActive() sudah digabung di call-site
     * @param moduleLabel       nama modul buat pesan "Modul X tidak aktif."
     * @param noun              nama jenis item, kapital di depan (mis. "Block") — dipakai di pesan "id tidak ditemukan"
     * @param section           nama bagian di config.yml (mis. "blocks")
     * @param lookup            cari definisi dari id di registry modul terkait
     * @param createItem        bikin ItemStack dari definisi (lewat factory modul terkait)
     * @param displayName       ambil display name dari definisi, buat notify target
     * @param itemKindLabel     label jenis item di pesan "Kamu menerima ...: ..."
     * @param notifyTarget      true kalau target perlu dikirim pesan "Kamu menerima ..." (givemobitem: false)
     * @param spawnItemPhrasing true kalau pesan sukses pakai frasa "spawn item" (khusus givemobitem)
     */
    private record GiveSpec<D>(
            String usage,
            boolean moduleActive,
            String moduleLabel,
            String noun,
            String section,
            Function<String, Optional<D>> lookup,
            Function<D, ItemStack> createItem,
            Function<D, String> displayName,
            String itemKindLabel,
            boolean notifyTarget,
            boolean spawnItemPhrasing
    ) {
    }

    private <D> void handleGiveGeneric(CommandSender sender, String[] args, GiveSpec<D> spec) {
        if (args.length < 3) {
            sender.sendMessage("§cPakai: /audes " + spec.usage() + " <player> <" + spec.noun().toLowerCase() + "_id>");
            return;
        }
        if (!spec.moduleActive()) {
            sender.sendMessage("§cModul " + spec.moduleLabel() + " tidak aktif.");
            return;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage("§cPlayer '" + args[1] + "' tidak online.");
            return;
        }

        String id = args[2];
        Optional<D> defOpt = spec.lookup().apply(id);
        if (defOpt.isEmpty()) {
            sender.sendMessage("§c" + spec.noun() + " id '" + id + "' tidak ditemukan di config.yml bagian '" + spec.section() + "'.");
            return;
        }

        D def = defOpt.get();
        target.getInventory().addItem(spec.createItem().apply(def));

        String givenLabel = spec.spawnItemPhrasing() ? ("spawn item '" + id + "'") : ("'" + id + "'");
        sender.sendMessage("§aDiberikan " + givenLabel + " ke " + target.getName() + ".");

        if (spec.notifyTarget() && !sender.equals(target)) {
            target.sendMessage("§7Kamu menerima " + spec.itemKindLabel() + ": " + spec.displayName().apply(def));
        }
    }

    /** /audes give <player> <tool_id> — spawn custom tool dari ToolRegistry, lewat ToolFactory. */
    private void handleGive(CommandSender sender, String[] args) {
        handleGiveGeneric(sender, args, new GiveSpec<>(
                "give",
                customToolsModule != null && moduleManager.isActive("custom-tools"),
                "custom-tools", "Tool", "tools",
                id -> customToolsModule.getRegistry().get(id),
                def -> customToolsModule.getFactory().create(def),
                ToolDefinition::displayName,
                "custom tool", true, false
        ));
    }

    /** /audes giveblock <player> <block_id> — spawn custom block item dari BlockRegistry, lewat BlockItemFactory. */
    private void handleGiveBlock(CommandSender sender, String[] args) {
        handleGiveGeneric(sender, args, new GiveSpec<>(
                "giveblock",
                customBlockModule != null && moduleManager.isActive("custom-block"),
                "custom-block", "Block", "blocks",
                id -> customBlockModule.getRegistry().get(id),
                def -> customBlockModule.getFactory().create(def),
                BlockDefinition::displayName,
                "custom block", true, false
        ));
    }

    /** /audes givefurniture <player> <furniture_id> — spawn item furniture placeable. */
    private void handleGiveFurniture(CommandSender sender, String[] args) {
        handleGiveGeneric(sender, args, new GiveSpec<>(
                "givefurniture",
                furnitureModule != null && moduleManager.isActive("furniture"),
                "furniture", "Furniture", "furniture",
                id -> furnitureModule.getRegistry().get(id),
                def -> furnitureModule.getFactory().create(def),
                FurnitureDefinition::displayName,
                "custom furniture", true, false
        ));
    }

    /** /audes givearmor <player> <armor_id> — spawn item custom armor dari ArmorRegistry, lewat ArmorItemFactory. */
    private void handleGiveArmor(CommandSender sender, String[] args) {
        handleGiveGeneric(sender, args, new GiveSpec<>(
                "givearmor",
                armorModule != null && moduleManager.isActive("armor"),
                "armor", "Armor", "armor",
                id -> armorModule.getRegistry().get(id),
                def -> armorModule.getFactory().create(def),
                ArmorDefinition::displayName,
                "custom armor", true, false
        ));
    }

    /** /audes givestructure <player> <structure_id> — spawn item bibit structure (custom tree/decoration). */
    private void handleGiveStructure(CommandSender sender, String[] args) {
        handleGiveGeneric(sender, args, new GiveSpec<>(
                "givestructure",
                structureModule != null && moduleManager.isActive("structure"),
                "structure", "Structure", "structures",
                id -> structureModule.getRegistry().get(id),
                def -> structureModule.getFactory().create(def),
                StructureDefinition::displayName,
                "structure", true, false
        ));
    }

    /** /audes givevehicle <player> <vehicle_id> — spawn item vehicle custom. */
    private void handleGiveVehicle(CommandSender sender, String[] args) {
        handleGiveGeneric(sender, args, new GiveSpec<>(
                "givevehicle",
                vehicleModule != null && moduleManager.isActive("vehicle"),
                "vehicle", "Vehicle", "vehicles",
                id -> vehicleModule.getRegistry().get(id),
                def -> vehicleModule.getFactory().create(def),
                VehicleDefinition::displayName,
                "vehicle", true, false
        ));
    }

    /** /audes givemobitem <player> <entity_id> — spawn item 'telur spawn' custom animated entity. */
    private void handleGiveMobItem(CommandSender sender, String[] args) {
        handleGiveGeneric(sender, args, new GiveSpec<>(
                "givemobitem",
                entityModule != null && moduleManager.isActive("entity"),
                "entity", "Entity", "entities",
                id -> entityModule.getRegistry().get(id),
                def -> entityModule.getFactory().createSpawnItem(def),
                EntityDefinition::customName,
                "", false, true
        ));
    }

    /**
     * Resolve player target buat subcommand yang argumen playernya OPSIONAL
     * (gui/hud/shop): kalau argumen ke-3 (index 2) diisi, pakai itu; kalau
     * tidak, default ke sender sendiri (sender wajib player); dari console
     * tanpa argumen player eksplisit dianggap error. Dulu logic ini
     * diduplikasi 3x (handleGui/handleHud/handleShop), sekarang satu tempat.
     * Return null kalau gagal resolve — pesan error sudah dikirim ke sender,
     * caller cukup langsung return.
     */
    private Player resolveOptionalTarget(CommandSender sender, String[] args, String subUsage, String id) {
        if (args.length >= 3) {
            Player target = Bukkit.getPlayerExact(args[2]);
            if (target == null) {
                sender.sendMessage("§cPlayer '" + args[2] + "' tidak online.");
                return null;
            }
            return target;
        }
        if (sender instanceof Player senderPlayer) {
            return senderPlayer;
        }
        sender.sendMessage("§cDari console wajib sebutkan player: /audes " + subUsage + " " + id + " <player>");
        return null;
    }

    /**
     * /audes gui <gui_id> [player] — buka custom GUI. Kalau [player]
     * tidak diisi, buka untuk sender sendiri (sender wajib player, bukan
     * console). Kalau diisi, admin buka GUI itu UNTUK player lain
     * (mis. buat testing GUI seolah-olah jadi player biasa, atau buat
     * force-open sebagai bagian dari alur admin lain).
     */
    private void handleGui(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§cPakai: /audes gui <gui_id> [player]");
            return;
        }
        if (guiModule == null || !moduleManager.isActive("gui")) {
            sender.sendMessage("§cModul gui tidak aktif.");
            return;
        }

        String guiId = args[1];
        var defOpt = guiModule.getRegistry().get(guiId);
        if (defOpt.isEmpty()) {
            sender.sendMessage("§cGUI id '" + guiId + "' tidak ditemukan di config.yml bagian 'guis'.");
            return;
        }
        GuiDefinition def = defOpt.get();

        Player target = resolveOptionalTarget(sender, args, "gui", guiId);
        if (target == null) return;

        guiModule.getManager().open(target, def);
        if (!sender.equals(target)) {
            sender.sendMessage("§aGUI '" + guiId + "' dibuka untuk " + target.getName() + ".");
        }
    }

    /**
     * /audes shop <shop_id> [player] -- buka menu shop custom. Pola SAMA
     * seperti /audes gui, bedanya isinya beli-beli pake Balance (Vault),
     * lihat ShopListener buat alur validasi saldo.
     */
    private void handleShop(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§cPakai: /audes shop <shop_id> [player]");
            return;
        }
        if (shopModule == null || !moduleManager.isActive("shop")) {
            sender.sendMessage("§cModul shop tidak aktif (cek console -- kemungkinan Vault/economy plugin tidak ke-detect saat startup).");
            return;
        }

        String shopId = args[1];
        var defOpt = shopModule.getRegistry().get(shopId);
        if (defOpt.isEmpty()) {
            sender.sendMessage("§cShop id '" + shopId + "' tidak ditemukan di config.yml bagian 'shop'.");
            return;
        }
        ShopDefinition def = defOpt.get();

        Player target = resolveOptionalTarget(sender, args, "shop", shopId);
        if (target == null) return;

        shopModule.getManager().open(target, def);
        if (!sender.equals(target)) {
            sender.sendMessage("§aShop '" + shopId + "' dibuka untuk " + target.getName() + ".");
        }
    }

    /**
     * /audes shopedit <shop_id> -- buka GUI edit lengkap buat shop
     * (tambah/hapus item, ganti harga) tanpa harus utak-atik config.yml
     * manual dari mobile. Cuma dari SENDER sendiri (bukan buat player lain
     * kayak /audes shop ..., gak masuk akal edit shop di layar orang lain).
     * Lihat ShopEditListener buat alur lengkapnya.
     */
    private void handleShopEdit(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§cPakai: /audes shopedit <shop_id>");
            return;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cCommand ini cuma bisa dipakai in-game.");
            return;
        }
        if (shopModule == null || !moduleManager.isActive("shop")) {
            sender.sendMessage("§cModul shop tidak aktif (cek console -- kemungkinan Vault/economy plugin tidak ke-detect saat startup).");
            return;
        }

        String shopId = args[1];
        var defOpt = shopModule.getRegistry().get(shopId);
        if (defOpt.isEmpty()) {
            sender.sendMessage("§cShop id '" + shopId + "' tidak ditemukan di config.yml bagian 'shop'.");
            return;
        }
        if (defOpt.get().rows() >= 6) {
            // Mode edit nambah 1 baris KHUSUS buat tombol Simpan/Batal di
            // bawah shop (lihat AudesShopEditHolder#getTotalInventoryRows) --
            // shop 6 baris udah mentok limit chest (54 slot), gak ada
            // ruang buat baris tambahan itu (bisa bikin slot Simpan/Batal
            // out-of-bounds). Edit shop 6 baris cuma bisa manual di config.yml.
            sender.sendMessage("§cShop '" + shopId + "' pakai 6 baris (maksimal chest) -- mode edit GUI butuh "
                    + "1 baris ekstra buat tombol Simpan/Batal, jadi gak muat. Edit manual di config.yml aja "
                    + "buat shop ini, lalu /audes reload.");
            return;
        }

        shopModule.getEditManager().openExisting(player, defOpt.get());
        player.sendMessage("§aMode edit shop '" + shopId + "' dibuka. Taro item dari inventory kamu ke slot "
                + "kosong buat nambah, klik kiri item buat ganti harga, klik kanan buat hapus, "
                + "klik hijau buat Simpan.");
    }

    /**
     * /audes hud <hud_id> [player] — toggle HUD (nyalain kalau lagi
     * mati, matiin kalau lagi nyala). Sama pola dengan /audes gui: kalau
     * [player] tidak diisi, target sender sendiri.
     */
    private void handleHud(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§cPakai: /audes hud <hud_id> [player]");
            return;
        }
        if (hudModule == null || !moduleManager.isActive("hud")) {
            sender.sendMessage("§cModul hud tidak aktif.");
            return;
        }

        String hudId = args[1];
        var defOpt = hudModule.getRegistry().get(hudId);
        if (defOpt.isEmpty()) {
            sender.sendMessage("§cHUD id '" + hudId + "' tidak ditemukan di config.yml bagian 'huds'.");
            return;
        }
        HudDefinition def = defOpt.get();

        Player target = resolveOptionalTarget(sender, args, "hud", hudId);
        if (target == null) return;

        boolean nowShown = hudModule.getManager().toggle(target, def);
        String status = nowShown ? "dinyalain" : "dimatiin";
        if (!sender.equals(target)) {
            sender.sendMessage("§aHUD '" + hudId + "' " + status + " buat " + target.getName() + ".");
        } else {
            sender.sendMessage("§7HUD '" + hudId + "' " + status + ".");
        }
    }

    /**
     * /audes setrank <player> <rank> — ganti rank in-memory player di
     * PrefixManager, lalu fire AudesRankChangeEvent supaya rank-tab
     * ter-update real-time, dan langsung refresh above-head lewat
     * PrefixListener (tidak ikut event karena PrefixListener sendiri
     * yang jadi sumber kebenaran prefix, bukan listener terhadap event
     * ini — lihat catatan di PrefixModule).
     */
    private void handleSetRank(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("§cPakai: /audes setrank <player> <rank|clear>");
            return;
        }
        if (prefixModule == null || !moduleManager.isActive("prefix")) {
            sender.sendMessage("§cModul prefix tidak aktif.");
            return;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage("§cPlayer '" + args[1] + "' tidak online.");
            return;
        }

        String newRank = args[2];

        if (newRank.equalsIgnoreCase("clear") || newRank.equalsIgnoreCase("auto")) {
            String oldRankClear = prefixModule.getManager().getRank(target);
            prefixModule.getManager().clearPlayer(target);
            String resolvedRank = prefixModule.getManager().getRank(target);
            if (prefixModule.getListener() != null) {
                prefixModule.getListener().updateAboveHead(target);
            }
            Bukkit.getPluginManager().callEvent(new AudesRankChangeEvent(target, oldRankClear, resolvedRank));
            sender.sendMessage("§aOverride rank manual " + target.getName() + " dihapus. "
                    + "Sekarang: '" + resolvedRank + "' "
                    + (prefixModule.getManager().isLuckPermsIntegrationActive() ? "§7(dari LuckPerms)" : "§7(default)"));
            return;
        }

        if (!prefixModule.getManager().hasRankDefinition(newRank)) {
            sender.sendMessage("§cRank '" + newRank + "' tidak ada di config.yml bagian 'prefix'.");
            return;
        }

        String oldRank = prefixModule.getManager().getRank(target);
        prefixModule.getManager().setRank(target, newRank);

        // Above-head: PrefixListener yang pegang logic-nya, panggil langsung
        // (bukan lewat event) supaya tidak tergantung modul rank-tab aktif atau tidak.
        if (prefixModule.getListener() != null) {
            prefixModule.getListener().updateAboveHead(target);
        }

        // Rank-tab (kalau aktif) dengarkan event ini untuk update tab list real-time.
        Bukkit.getPluginManager().callEvent(new AudesRankChangeEvent(target, oldRank, newRank));

        sender.sendMessage("§aRank " + target.getName() + " diubah ke '" + newRank + "'.");
    }

    private List<String> onlinePlayerNames() {
        return Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList());
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return SUBCOMMANDS;
        }

        String sub = args[0].toLowerCase();

        if (args.length == 2) {
            if (PLAYER_ARG_AT_INDEX_1.contains(sub)) {
                return onlinePlayerNames();
            }
            return switch (sub) {
                case "gui" -> guiModule != null ? new ArrayList<>(guiModule.getRegistry().getAll().keySet()) : List.of();
                case "hud" -> hudModule != null ? new ArrayList<>(hudModule.getRegistry().getAll().keySet()) : List.of();
                case "shop", "shopedit" -> shopModule != null ? new ArrayList<>(shopModule.getRegistry().getAll().keySet()) : List.of();
                default -> List.of();
            };
        }

        if (args.length == 3) {
            if (PLAYER_ARG_AT_INDEX_2.contains(sub)) {
                return onlinePlayerNames();
            }
            return switch (sub) {
                case "give" -> customToolsModule != null ? new ArrayList<>(customToolsModule.getRegistry().getAll().keySet()) : List.of();
                case "giveblock" -> customBlockModule != null ? new ArrayList<>(customBlockModule.getRegistry().getAll().keySet()) : List.of();
                case "givefurniture" -> furnitureModule != null ? new ArrayList<>(furnitureModule.getRegistry().getAll().keySet()) : List.of();
                case "givearmor" -> armorModule != null ? new ArrayList<>(armorModule.getRegistry().getAll().keySet()) : List.of();
                case "givestructure" -> structureModule != null ? new ArrayList<>(structureModule.getRegistry().getAll().keySet()) : List.of();
                case "givevehicle" -> vehicleModule != null ? new ArrayList<>(vehicleModule.getRegistry().getAll().keySet()) : List.of();
                case "givemobitem" -> entityModule != null ? new ArrayList<>(entityModule.getRegistry().getAll().keySet()) : List.of();
                case "setrank" -> prefixModule != null ? new ArrayList<>(prefixModule.getManager().getAllDefinitions().keySet()) : List.of();
                default -> List.of();
            };
        }

        return List.of();
    }
}
