package com.audes.plugin.resourcepack;

import com.audes.plugin.bedrock.BedrockPlayerDetector;
import net.kyori.adventure.resource.ResourcePackInfo;
import net.kyori.adventure.resource.ResourcePackRequest;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;

import java.net.URI;
import java.util.UUID;

/**
 * Kirim resource pack ke player saat join, pakai Adventure
 * ResourcePackRequest (API native Paper sejak 1.20.3, BUKAN
 * Player#setResourcePack(String,byte[]) yang lama/deprecated) —
 * mendukung hash validation supaya client tidak skip re-download pack
 * yang sudah berubah (poin penting di TODO Dev3 no. 3).
 *
 * "required" dan pesan prompt dibaca dari config supaya tim bisa atur
 * apakah player WAJIB terima pack sebelum masuk server, atau opsional.
 *
 * Dev15: player Bedrock (lewat Floodgate, lihat BedrockPlayerDetector)
 * DI-SKIP total dari pengiriman -- resource pack Java ini tidak bisa
 * dipakai/diproses di sisi Bedrock (format beda total, lihat javadoc
 * BedrockPlayerDetector), dan kalau "required: true" mereka bisa
 * ke-kick kalau tetap dikirimin. Skip di sini TIDAK berarti custom item
 * Audes hilang buat player Bedrock -- mereka tetap dapat item/block-nya
 * (fungsional), cuma visualnya fallback ke vanilla sampai ada Geyser
 * custom mapping + resource pack Bedrock terpisah (lihat batasan jujur
 * di javadoc BedrockPlayerDetector).
 */
public class ResourcePackJoinListener implements Listener {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    private final Plugin plugin;
    private final String packUrl;
    private final String sha1Hex;
    private final boolean required;
    private final String promptMessage;

    public ResourcePackJoinListener(Plugin plugin, String packUrl, String sha1Hex, boolean required, String promptMessage) {
        this.plugin = plugin;
        this.packUrl = packUrl;
        this.sha1Hex = sha1Hex;
        this.required = required;
        this.promptMessage = promptMessage;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        sendTo(event.getPlayer());
    }

    /**
     * Dev19: DIPISAH dari onJoin() jadi method publik -- sebelumnya CUMA
     * dipanggil pas PlayerJoinEvent, artinya player yang UDAH online pas
     * /audes reload jalan (mis. lagi testing sambil di server) TIDAK
     * PERNAH dapet pack yang baru di-generate, sampai mereka disconnect-
     * reconnect. Ini penyebab konkret keluhan "udah reload tapi masih
     * keliatan rusak" -- server-side sukses generate+upload, tapi pack
     * barunya gak pernah beneran dikirim ke player yang lagi login.
     * Sekarang dipanggil dari SINI (join) DAN dari ResourcePackModule
     * abis regenerate() sukses, di-loop ke semua online player.
     */
    public void sendTo(Player player) {
        if (BedrockPlayerDetector.isBedrockPlayer(player.getUniqueId(), plugin.getLogger())) {
            return;
        }

        ResourcePackInfo info = ResourcePackInfo.resourcePackInfo(UUID.randomUUID(), URI.create(packUrl), sha1Hex);

        Component prompt = (promptMessage != null && !promptMessage.isBlank())
                ? LEGACY.deserialize(promptMessage)
                : null;

        ResourcePackRequest.Builder builder = ResourcePackRequest.resourcePackRequest()
                .packs(info)
                .required(required);
        if (prompt != null) {
            builder.prompt(prompt);
        }

        player.sendResourcePacks(builder.build());
    }
}
