package com.audes.plugin.shop;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Semua interaksi mode EDIT shop (beda dari ShopListener yang mode BELI):
 *   - Klik slot KOSONG sambil pegang item di tangan (klik kiri/kanan sama
 *     aja) -> item di tangan (1 biji, gak ngurangin stack di tangan --
 *     cuma DICONTOH bentuknya) ditaro di slot itu, harga default 1, minta
 *     admin ketik harga baru di chat.
 *   - Klik kiri item yang UDAH ADA -> minta ketik harga baru di chat.
 *   - Klik kanan item yang UDAH ADA -> hapus dari shop (langsung, gak
 *     minta konfirmasi -- masih di memory, belum ke-save, jadi aman kalau
 *     salah pencet, tinggal klik "Batal").
 *   - Klik "Simpan" -> ShopRegistry#save() nulis ke config.yml + inventory
 *     beli (AudesShopHolder) yang lagi dibuka player LAIN otomatis kepake
 *     versi baru pas mereka buka ulang (registry di-update in-memory juga).
 *   - Klik "Batal" / nutup inventory tanpa Simpan -> perubahan dibuang,
 *     config.yml TIDAK tersentuh.
 *
 * Input harga lewat CHAT (AsyncChatEvent, bukan AnvilInventory) -- dipilih
 * karena AnvilInventory GUI based butuh setup lebih ribet (perlu block
 * fisik/virtual anvil, PrepareAnvilEvent, dsb) sementara chat listener jauh
 * lebih simpel buat kasus "minta 1 baris angka doang", dan pola prompt-lewat-
 * chat ini sudah lazim dipakai plugin shop lain (mis. ChestShop, EconomyShopGUI).
 */
public class ShopEditListener implements Listener {

    private final ShopRegistry registry;
    private final ShopEditManager manager;
    private final org.bukkit.plugin.Plugin plugin;
    /** Player yang lagi ditunggu input harganya di chat -- dicek AsyncChatEvent, supaya chat biasa (bukan lagi edit) gak ke-cancel/ke-parse jadi harga. */
    private final Set<UUID> awaitingChatInput = new HashSet<>();

    public ShopEditListener(ShopRegistry registry, ShopEditManager manager, org.bukkit.plugin.Plugin plugin) {
        this.registry = registry;
        this.manager = manager;
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder topHolder = event.getView().getTopInventory().getHolder();
        if (!(topHolder instanceof AudesShopEditHolder holder)) return;

        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getView().getTopInventory()) {
            return;
        }

        int slot = event.getSlot();

        if (slot == holder.getSaveSlot()) {
            handleSave(player, holder);
            return;
        }
        if (slot == holder.getCancelSlot()) {
            player.closeInventory();
            player.sendMessage("§7Edit shop dibatalkan, tidak ada perubahan yang disimpan.");
            return;
        }
        if (holder.isControlSlot(slot) || slot >= holder.getContentSlotCount()) {
            return; // area filler baris control, bukan area edit
        }

        ShopItemDefinition existing = holder.getPendingItems().get(slot);

        if (existing == null) {
            // Slot kosong -- taro item dari tangan kalau ada.
            ItemStack hand = event.getCursor();
            if (hand == null || hand.getType().isAir()) {
                return;
            }
            ShopItemDefinition fresh = new ShopItemDefinition(slot, hand.getType(),
                    hand.getItemMeta() != null && hand.getItemMeta().hasDisplayName()
                            ? PlainTextComponentSerializer.plainText().serialize(hand.getItemMeta().displayName()) : "",
                    java.util.List.of(), 1.0, -1.0, Math.max(1, hand.getAmount()));
            holder.putItem(slot, fresh);
            manager.render(event.getInventory(), holder);
            player.sendMessage("§aItem ditambahkan di slot " + slot + " dengan harga beli default §e1§a "
                    + "(belum bisa dijual). Klik kiri item itu buat ganti harga beli/jual sekarang.");
            return;
        }

        if (event.getClick() == ClickType.RIGHT) {
            holder.removeItem(slot);
            manager.render(event.getInventory(), holder);
            player.sendMessage("§eItem di slot " + slot + " dihapus dari shop (belum ke-save, klik Batal kalau salah pencet).");
            return;
        }

        // Klik kiri item yang udah ada -> minta harga baru lewat chat.
        holder.setSlotAwaitingPriceInput(slot);
        awaitingChatInput.add(player.getUniqueId());
        player.closeInventory();
        player.sendMessage("§aKetik §eharga_beli harga_jual§a di chat (pisah spasi, mis. §e150 80§a). "
                + "Isi §e-1§a di bagian jual kalau item ini gak boleh dijual di sini (mis. §e150 -1§a). "
                + "Ketik §ccancel§a buat batal.");
        // Simpan holder ke player metadata sementara biar bisa dibuka lagi setelah input -- lihat onChat().
        pendingReturnHolder.put(player.getUniqueId(), holder);
    }

    private final java.util.Map<UUID, AudesShopEditHolder> pendingReturnHolder = new java.util.HashMap<>();

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        if (!awaitingChatInput.contains(player.getUniqueId())) return;

        event.setCancelled(true); // jangan sampe "150 80" ke-broadcast ke seluruh server sebagai chat biasa
        String message = PlainTextComponentSerializer.plainText().serialize(event.message()).trim();
        awaitingChatInput.remove(player.getUniqueId());
        AudesShopEditHolder holder = pendingReturnHolder.remove(player.getUniqueId());
        if (holder == null) return;

        Integer slot = holder.getSlotAwaitingPriceInput();
        holder.setSlotAwaitingPriceInput(null);

        // Balikin ke main thread -- AsyncChatEvent (namanya juga "async")
        // TIDAK jalan di main thread, sedangkan buka inventory/kirim pesan
        // WAJIB main thread di Paper/Folia.
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!"cancel".equalsIgnoreCase(message)) {
                    if (slot != null) {
                        String[] parts = message.trim().split("\\s+");
                        if (parts.length != 2) {
                            player.sendMessage("§cFormat salah -- wajib DUA angka dipisah spasi (harga_beli harga_jual), "
                                    + "mis. '150 80' atau '150 -1'. Harga tidak diubah.");
                        } else {
                            try {
                                double buyPrice = Double.parseDouble(parts[0]);
                                double sellPrice = Double.parseDouble(parts[1]);
                                if (buyPrice < 0) throw new NumberFormatException("harga beli tidak boleh negatif");
                                // sellPrice boleh negatif -- SEMUA nilai negatif diseragamkan jadi -1
                                // (konvensi "gak bisa dijual"), bukan cuma -1 persis, biar admin ketik
                                // -5 atau -1 hasilnya sama-sama valid "tidak bisa dijual".
                                if (sellPrice < 0) sellPrice = -1.0;

                                ShopItemDefinition old = holder.getPendingItems().get(slot);
                                if (old != null) {
                                    holder.putItem(slot, new ShopItemDefinition(old.slot(), old.material(),
                                            old.displayName(), old.lore(), buyPrice, sellPrice, old.giveAmount()));
                                    player.sendMessage("§aHarga slot " + slot + " diubah -- beli: §e" + buyPrice
                                            + "§a, jual: §e" + (sellPrice >= 0 ? sellPrice : "tidak bisa dijual") + "§a.");
                                }
                            } catch (NumberFormatException e) {
                                player.sendMessage("§c'" + message + "' bukan format harga yang valid, harga tidak diubah.");
                            }
                        }
                    }
                } else {
                    player.sendMessage("§7Dibatalkan, harga tidak diubah.");
                }
                // Buka lagi GUI edit-nya dengan state ter-update.
                var inv = holder.getInventory();
                manager.render(inv, holder);
                player.openInventory(inv);
            }
        }.runTask(plugin);
    }

    private void handleSave(Player player, AudesShopEditHolder holder) {
        registry.get(holder.getShopId()).ifPresentOrElse(existingDef -> {
            ShopDefinition updated = new ShopDefinition(holder.getShopId(), existingDef.title(), holder.getRows(),
                    java.util.List.copyOf(holder.getPendingItems().values()));
            registry.save(updated);
            player.closeInventory();
            player.sendMessage("§aShop '" + holder.getShopId() + "' disimpan (" + updated.items().size()
                    + " item) dan langsung aktif.");
        }, () -> player.sendMessage("§cGagal simpan -- shop '" + holder.getShopId() + "' sudah tidak ada di config."));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // Cegah leak kecil: kalau player disconnect PAS lagi nunggu input
        // harga (abis closeInventory() kita panggil sendiri di onClick),
        // dua map ini gak akan pernah ke-cleanup sendiri karena gak ada
        // AsyncChatEvent yang bakal dateng dari player yang udah offline.
        UUID id = event.getPlayer().getUniqueId();
        awaitingChatInput.remove(id);
        pendingReturnHolder.remove(id);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        // Kalau player nutup inventory edit TANPA klik Simpan/Batal (mis.
        // pencet Escape atau ganti window), perubahan tetap gak ke-save
        // (registry.save() cuma dipanggil di handleSave) -- ini cuma
        // bersih-bersih state supaya gak nyangkut nunggu chat input yang
        // gak akan pernah dateng.
        if (event.getInventory().getHolder() instanceof AudesShopEditHolder) {
            // Sengaja TIDAK di-remove dari awaitingChatInput di sini --
            // kalau player lagi nunggu ngetik harga, closeInventory() yang
            // KITA panggil sendiri (lihat onClick di atas) trigger event
            // ini juga, jadi harus dibiarkan tetap nunggu chat.
        }
    }
}
