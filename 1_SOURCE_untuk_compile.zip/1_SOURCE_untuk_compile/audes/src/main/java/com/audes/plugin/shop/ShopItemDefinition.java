package com.audes.plugin.shop;

import org.bukkit.Material;

import java.util.List;

/**
 * Satu item yang dijual di shop. Beda dari GuiButtonDefinition (yang murni
 * command-driven) -- shop item PUNYA harga (price, dipotong dari Balance
 * lewat Vault, lihat VaultEconomyBridge) dan JUMLAH item yang dikasih
 * (giveAmount), bukan cuma command bebas. Ini disengaja: shop item beda
 * konsep dari tombol GUI generik (butuh validasi saldo SEBELUM dikasih
 * barangnya, bukan sekadar jalanin command).
 *
 * sellPrice: -1 = TIDAK BISA dijual di sini (konvensi SAMA persis kayak
 * ShopGUIPlus yang udah dipasang di server -- lihat shops/*.yml mereka,
 * banyak kategori yang sengaja sellPrice: -1). Dipilih angka yang sama
 * biar konsisten kalau admin pindah-pindah baca config dua plugin ini.
 */
public record ShopItemDefinition(
        int slot,
        Material material,
        String displayName,
        List<String> lore,
        double price,
        double sellPrice,
        int giveAmount
) {
}
