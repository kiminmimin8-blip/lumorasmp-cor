package com.audes.plugin.shop;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Dev20: DIROMBAK TOTAL -- sebelumnya item numpuk polos tanpa border/
 * navigasi (keluhan "gak tertata, belum ada UI"). Sekarang tiap kategori
 * dapet WARNA BORDER SENDIRI (biar "gak kaku", request eksplisit) dan
 * baris kontrol di bawah (kembali ke hub, + next/prev buat kategori yang
 * kepecah banyak halaman kayak blocks_shop_1..10 -- sebelumnya HARUS
 * ketik manual /shop blocks_shop_2, sekarang tinggal klik panah).
 */
public class ShopManager {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    // Pola id: "<kategori>_shop" (1 halaman) atau "<kategori>_shop_<N>"
    // (multi-halaman, mis. blocks_shop_1..10). Dipakai buat nentuin warna
    // border DAN buat nyari halaman sebelum/sesudahnya di registry.
    private static final Pattern SHOP_ID_PATTERN = Pattern.compile("^(.+?)_shop(?:_(\\d+))?$");

    // 1 warna kaca per kategori -- sengaja beda-beda (bukan abu-abu semua)
    // biar tiap kategori kerasa punya identitas sendiri sesuai request.
    private static final Map<String, Material> CATEGORY_BORDER = Map.ofEntries(
            Map.entry("armor", Material.LIGHT_BLUE_STAINED_GLASS_PANE),
            Map.entry("blocks", Material.GRAY_STAINED_GLASS_PANE),
            Map.entry("drops", Material.LIME_STAINED_GLASS_PANE),
            Map.entry("dyes", Material.MAGENTA_STAINED_GLASS_PANE),
            Map.entry("farming", Material.GREEN_STAINED_GLASS_PANE),
            Map.entry("foods", Material.ORANGE_STAINED_GLASS_PANE),
            Map.entry("minerals_ores", Material.CYAN_STAINED_GLASS_PANE),
            Map.entry("miscellaneous", Material.PURPLE_STAINED_GLASS_PANE),
            Map.entry("mob_drops", Material.BLACK_STAINED_GLASS_PANE),
            Map.entry("ores", Material.BROWN_STAINED_GLASS_PANE),
            Map.entry("redstone", Material.RED_STAINED_GLASS_PANE),
            Map.entry("tools", Material.YELLOW_STAINED_GLASS_PANE)
    );
    private static final Material DEFAULT_BORDER = Material.WHITE_STAINED_GLASS_PANE;

    private final VaultEconomyBridge economy;
    private final ShopRegistry registry;

    public ShopManager(VaultEconomyBridge economy, ShopRegistry registry) {
        this.economy = economy;
        this.registry = registry;
    }

    /**
     * Hub -- 1 icon per kategori shop, klik buka shop-nya. Ini yang dibuka
     * /shop TANPA argumen (lihat ShopCommand) -- sebelumnya /shop tanpa
     * argumen nyuruh ngetik id manual, kerasa aneh begitu kategori udah
     * banyak (22 menu). /shop <id> tetap ada buat shortcut cepat langsung
     * ke 1 kategori tanpa mampir hub dulu.
     *
     * Kategori berhalaman (blocks_shop_1..10, farming_shop_1..2) CUMA
     * ditampilin SEKALI di hub (halaman pertamanya) -- sisa halamannya
     * diakses lewat tombol next/prev di dalam shop-nya sendiri (lihat
     * open()), bukan didaftar satu-satu di hub (bakal kebanyakan icon
     * kalau semua 10 halaman blocks ikut nongol di hub).
     */
    public void openHub(Player player, Map<String, ShopDefinition> allShops) {
        AudesShopHubHolder holder = new AudesShopHubHolder();

        List<ShopDefinition> firstPagesOnly = new ArrayList<>();
        for (ShopDefinition def : allShops.values()) {
            int page = pageOf(def.id());
            if (page <= 1) {
                firstPagesOnly.add(def);
            }
        }

        int rows = Math.min(6, Math.max(1, (int) Math.ceil(firstPagesOnly.size() / 9.0)));
        Inventory inventory = Bukkit.createInventory(holder, rows * 9, LEGACY.deserialize("&8&lPilih Kategori Shop"));
        holder.setInventory(inventory);

        int slot = 0;
        for (ShopDefinition def : firstPagesOnly) {
            if (slot >= inventory.getSize()) break; // lebih dari 54 kategori gak akan muat 1 GUI (belum kejadian sekarang, 12 kategori unik)
            Material icon = def.items().isEmpty() ? Material.CHEST : def.items().get(0).material();
            ItemStack stack = new ItemStack(icon);
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                meta.displayName(LEGACY.deserialize(def.title()));
                int totalPages = countPages(allShops, categoryOf(def.id()));
                List<String> lore = new ArrayList<>();
                lore.add("&7" + def.items().size() + " item" + (totalPages > 1 ? " (" + totalPages + " halaman)" : ""));
                lore.add("&eKlik buat buka");
                meta.lore(lore.stream().map(LEGACY::deserialize).toList());
                stack.setItemMeta(meta);
            }
            inventory.setItem(slot, stack);
            holder.putSlot(slot, def.id());
            slot++;
        }

        player.openInventory(inventory);
    }

    public void open(Player player, ShopDefinition def) {
        AudesShopHolder holder = new AudesShopHolder(def.id(), def.rows());
        int totalRows = Math.min(6, def.rows() + 1); // +1 baris kontrol di bawah
        Inventory inventory = Bukkit.createInventory(holder, totalRows * 9, LEGACY.deserialize(def.title()));
        holder.setInventory(inventory);

        for (ShopItemDefinition item : def.items()) {
            inventory.setItem(item.slot(), buildItem(item, player));
        }

        String category = categoryOf(def.id());
        int page = pageOf(def.id());
        Material borderMat = CATEGORY_BORDER.getOrDefault(category, DEFAULT_BORDER);

        // Baris kontrol: border warna kategori isi penuh dulu, baru tombol
        // navigasi ditimpa di slot spesifik (kembali selalu ada di tengah,
        // prev/next cuma muncul kalau halaman sebelah beneran ada di registry).
        int base = holder.getContentSlotCount();
        for (int i = base; i < inventory.getSize(); i++) {
            inventory.setItem(i, coloredFiller(borderMat));
        }

        inventory.setItem(holder.getBackSlot(), navItem(Material.NETHER_STAR, "&e&lKembali ke Hub",
                List.of("&7Balik ke daftar semua kategori shop.")));

        String prevId = category + "_shop" + (page - 1 <= 1 ? "" : "_" + (page - 1));
        if (page > 1 && registry.get(prevId).isPresent()) {
            inventory.setItem(holder.getPrevSlot(), navItem(Material.ARROW, "&a&l< Halaman Sebelumnya",
                    List.of("&7Ke halaman " + (page - 1) + ".")));
        }
        String nextId = category + "_shop_" + (page + 1);
        if (registry.get(nextId).isPresent()) {
            inventory.setItem(holder.getNextSlot(), navItem(Material.ARROW, "&a&lHalaman Berikutnya >",
                    List.of("&7Ke halaman " + (page + 1) + ".")));
        }

        player.openInventory(inventory);
    }

    /** Ekstrak nama kategori dari id shop, mis. "blocks_shop_3" -> "blocks", "tools_shop" -> "tools". */
    public static String categoryOf(String shopId) {
        Matcher m = SHOP_ID_PATTERN.matcher(shopId);
        return m.matches() ? m.group(1) : shopId;
    }

    /** Nomor halaman dari id shop, mis. "blocks_shop_3" -> 3, "tools_shop" -> 1 (dianggap halaman pertama/satu-satunya). */
    public static int pageOf(String shopId) {
        Matcher m = SHOP_ID_PATTERN.matcher(shopId);
        if (m.matches() && m.group(2) != null) {
            return Integer.parseInt(m.group(2));
        }
        return 1;
    }

    private int countPages(Map<String, ShopDefinition> allShops, String category) {
        int count = 0;
        for (String id : allShops.keySet()) {
            if (categoryOf(id).equals(category)) count++;
        }
        return count;
    }

    private ItemStack coloredFiller(Material material) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(LEGACY.deserialize("&7"));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack navItem(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(LEGACY.deserialize(name));
            meta.lore(lore.stream().map(LEGACY::deserialize).toList());
            stack.setItemMeta(meta);
        }
        return stack;
    }

    /**
     * Lore harga DITEMPEL OTOMATIS di baris terakhir, terpisah dari lore
     * custom di config -- admin isi lore.yml cuma buat deskripsi item,
     * gak perlu nulis ulang harga manual tiap kali harga berubah (dan gak
     * bisa ke-desync kayak kalau harga di-hardcode di string lore).
     */
    private ItemStack buildItem(ShopItemDefinition item, Player viewer) {
        ItemStack stack = new ItemStack(item.material(), item.giveAmount());
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            if (item.displayName() != null && !item.displayName().isBlank()) {
                meta.displayName(LEGACY.deserialize(item.displayName()));
            }
            List<String> lore = new ArrayList<>(item.lore());
            lore.add("");
            boolean canAfford = !economy.isReady() || economy.has(viewer, item.price());
            String priceColor = canAfford ? "&a" : "&c";
            String priceText = economy.isReady() ? economy.format(item.price()) : String.valueOf(item.price());
            lore.add("&eKlik kiri &7untuk beli &7- &7Harga: " + priceColor + priceText);
            if (item.sellPrice() >= 0) {
                String sellText = economy.isReady() ? economy.format(item.sellPrice()) : String.valueOf(item.sellPrice());
                lore.add("&eKlik kanan &7untuk jual &7(pegang item ini) &7- &7Harga: &a" + sellText);
            } else {
                lore.add("&7Item ini tidak bisa dijual di sini.");
            }
            if (!canAfford) {
                lore.add("&cSaldo kamu tidak cukup buat beli!");
            }
            meta.lore(lore.stream().map(LEGACY::deserialize).toList());
            stack.setItemMeta(meta);
        }
        return stack;
    }
}
