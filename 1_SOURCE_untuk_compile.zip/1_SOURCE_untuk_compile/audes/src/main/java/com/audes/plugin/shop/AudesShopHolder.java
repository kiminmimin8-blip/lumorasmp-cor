package com.audes.plugin.shop;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/**
 * Dev20: DIROMBAK -- sebelumnya cuma nyimpen shopId doang, item numpuk
 * polos gak ada border/navigasi (keluhan "gak tertata"). Sekarang nyimpen
 * juga jumlah baris KONTEN (di luar baris kontrol paling bawah) biar
 * ShopListener bisa bedain klik "beli/jual item" vs klik "navigasi",
 * pola SAMA kayak AudesShopEditHolder (getContentSlotCount dst).
 */
public class AudesShopHolder implements InventoryHolder {

    private final String shopId;
    private final int contentRows;
    private Inventory inventory;

    public AudesShopHolder(String shopId, int contentRows) {
        this.shopId = shopId;
        this.contentRows = contentRows;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public String getShopId() {
        return shopId;
    }

    /** Slot 0..N-1 buat item asli, N ke atas itu baris kontrol (border + tombol navigasi). */
    public int getContentSlotCount() {
        return contentRows * 9;
    }

    public int getBackSlot() {
        return getContentSlotCount() + 4; // tengah baris kontrol
    }

    public int getPrevSlot() {
        return getContentSlotCount(); // paling kiri baris kontrol
    }

    public int getNextSlot() {
        return getContentSlotCount() + 8; // paling kanan baris kontrol
    }

    public boolean isNavSlot(int slot) {
        return slot >= getContentSlotCount();
    }
}
