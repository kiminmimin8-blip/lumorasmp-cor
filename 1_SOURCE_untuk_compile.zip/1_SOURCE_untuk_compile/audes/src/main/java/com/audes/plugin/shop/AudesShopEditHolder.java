package com.audes.plugin.shop;

import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Holder buat mode EDIT shop (beda dari AudesShopHolder yang mode BELI) --
 * dipisah class biar ShopListener (klik = beli) sama ShopEditListener
 * (klik = edit slot) gak ketuker nanganin event yang sama.
 *
 * Perubahan disimpen di MEMORY (pendingItems map) dulu, BELUM nulis ke
 * config.yml sampai admin klik tombol "Simpan" (lihat ShopEditListener) --
 * jadi admin bisa coba-coba susun ulang shop, batal kalau salah, tanpa
 * config.yml keubah tiap klik.
 */
public class AudesShopEditHolder implements InventoryHolder {

    public int getSaveSlot() {
        return getContentSlotCount() + 3; // baris control, slot ke-4 (index 3)
    }

    public int getCancelSlot() {
        return getContentSlotCount() + 5; // baris control, slot ke-6 (index 5)
    }

    private final String shopId;
    private final int rows;
    private final Map<Integer, ShopItemDefinition> pendingItems = new LinkedHashMap<>();
    private Inventory inventory;
    private Integer slotAwaitingPriceInput;

    public AudesShopEditHolder(String shopId, int rows, Map<Integer, ShopItemDefinition> initialItems) {
        this.shopId = shopId;
        this.rows = rows;
        this.pendingItems.putAll(initialItems);
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public String getShopId() {
        return shopId;
    }

    public int getRows() {
        return rows;
    }

    public int getContentSlotCount() {
        return rows * 9; // baris ASLI shop -- control bar ada di baris TAMBAHAN di bawahnya, lihat ShopEditManager
    }

    public int getTotalInventoryRows() {
        return Math.min(6, rows + 1); // +1 baris buat control bar (Simpan/Batal), dicap 6 (limit chest Minecraft)
    }

    public Map<Integer, ShopItemDefinition> getPendingItems() {
        return pendingItems;
    }

    public void putItem(int slot, ShopItemDefinition item) {
        pendingItems.put(slot, item);
    }

    public void removeItem(int slot) {
        pendingItems.remove(slot);
    }

    public Integer getSlotAwaitingPriceInput() {
        return slotAwaitingPriceInput;
    }

    public void setSlotAwaitingPriceInput(Integer slot) {
        this.slotAwaitingPriceInput = slot;
    }

    public boolean isControlSlot(int slot) {
        return slot == getSaveSlot() || slot == getCancelSlot();
    }

    public static Material dummyControlMaterialSave() {
        return Material.LIME_STAINED_GLASS_PANE;
    }

    public static Material dummyControlMaterialCancel() {
        return Material.RED_STAINED_GLASS_PANE;
    }
}
