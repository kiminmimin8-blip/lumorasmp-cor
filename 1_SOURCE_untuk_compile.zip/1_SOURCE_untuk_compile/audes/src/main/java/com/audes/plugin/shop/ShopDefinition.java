package com.audes.plugin.shop;

import java.util.List;

/** Satu menu shop (bisa lebih dari satu, mis. "blocks", "tools" -- pola sama seperti "guis:" boleh punya banyak menu). */
public record ShopDefinition(
        String id,
        String title,
        int rows,
        List<ShopItemDefinition> items
) {
}
