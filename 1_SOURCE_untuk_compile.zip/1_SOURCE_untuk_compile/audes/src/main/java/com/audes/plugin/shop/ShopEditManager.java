package com.audes.plugin.shop;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ShopEditManager {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    /** Buka mode edit buat shop yang UDAH ADA (isi awal = item yang sekarang ada di config). */
    public void openExisting(Player player, ShopDefinition def) {
        Map<Integer, ShopItemDefinition> initial = new LinkedHashMap<>();
        for (ShopItemDefinition item : def.items()) {
            initial.put(item.slot(), item);
        }
        open(player, def.id(), def.title(), def.rows(), initial);
    }

    private void open(Player player, String shopId, String title, int rows, Map<Integer, ShopItemDefinition> initial) {
        AudesShopEditHolder holder = new AudesShopEditHolder(shopId, rows, initial);
        int size = holder.getTotalInventoryRows() * 9;
        Inventory inventory = Bukkit.createInventory(holder, size, LEGACY.deserialize("&8[EDIT] " + title));
        holder.setInventory(inventory);

        render(inventory, holder);
        player.openInventory(inventory);
    }

    /** Gambar ulang SELURUH inventory dari pendingItems -- dipanggil pas buka pertama kali DAN abis tiap perubahan (taro/hapus/ganti harga), biar tampilan selalu sinkron sama data di memory. */
    public void render(Inventory inventory, AudesShopEditHolder holder) {
        inventory.clear();

        for (Map.Entry<Integer, ShopItemDefinition> entry : holder.getPendingItems().entrySet()) {
            inventory.setItem(entry.getKey(), buildDisplayItem(entry.getValue()));
        }

        int controlBase = holder.getContentSlotCount();
        for (int i = controlBase; i < inventory.getSize(); i++) {
            if (i != holder.getSaveSlot() && i != holder.getCancelSlot()) {
                inventory.setItem(i, filler());
            }
        }
        inventory.setItem(holder.getSaveSlot(), controlItem(AudesShopEditHolder.dummyControlMaterialSave(),
                "&a&lSIMPAN", List.of("&7Simpan semua perubahan ke config.yml", "&7dan langsung aktif di /shop.")));
        inventory.setItem(holder.getCancelSlot(), controlItem(AudesShopEditHolder.dummyControlMaterialCancel(),
                "&c&lBATAL", List.of("&7Tutup tanpa nyimpen perubahan.")));
    }

    private ItemStack buildDisplayItem(ShopItemDefinition item) {
        ItemStack stack = new ItemStack(item.material(), Math.max(1, item.giveAmount()));
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            if (item.displayName() != null && !item.displayName().isBlank()) {
                meta.displayName(LEGACY.deserialize(item.displayName()));
            }
            java.util.ArrayList<String> lore = new java.util.ArrayList<>(item.lore());
            lore.add("");
            lore.add("&7Harga beli: &e" + item.price());
            lore.add("&7Harga jual: &e" + (item.sellPrice() >= 0 ? String.valueOf(item.sellPrice()) : "tidak bisa dijual"));
            lore.add("&7Jumlah dikasih: &e" + item.giveAmount());
            lore.add("");
            lore.add("&eKlik kiri &7= ganti harga (chat)");
            lore.add("&eKlik kanan &7= hapus dari shop");
            meta.lore(lore.stream().map(LEGACY::deserialize).toList());
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack filler() {
        ItemStack stack = new ItemStack(org.bukkit.Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(LEGACY.deserialize("&7"));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack controlItem(org.bukkit.Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(LEGACY.deserialize(name));
            meta.lore(lore.stream().map(LEGACY::deserialize).toList());
            stack.setItemMeta(meta);
        }
        return stack;
    }
}
