package com.audes.plugin.shop;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Load "shop:" dari config.yml -- pola SAMA persis seperti GuiRegistry (lihat javadoc di sana), cuma nambah field "price" per item. */
public class ShopRegistry {

    // JavaPlugin (bukan Plugin generik kayak GuiRegistry) -- save() di bawah
    // butuh getConfig()/saveConfig(), yang cuma ada di JavaPlugin, GuiRegistry
    // gak butuh ini karena emang gak ada fitur simpen-balik-ke-config.
    private final JavaPlugin plugin;
    private final Map<String, ShopDefinition> shops = new LinkedHashMap<>();

    public ShopRegistry(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig(ConfigurationSection section) {
        shops.clear();
        if (section == null) return;

        for (String id : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(id);
            if (s == null) continue;

            int rows = s.getInt("rows", 3);
            if (rows < 1 || rows > 6) {
                plugin.getLogger().warning("[Audes] shop '" + id + "' punya rows di luar rentang 1-6 (nilai: "
                        + rows + "), di-clamp.");
                rows = Math.max(1, Math.min(6, rows));
            }

            List<ShopItemDefinition> items = parseItems(s, id, rows);

            shops.put(id, new ShopDefinition(id, s.getString("title", id), rows, items));
        }

        plugin.getLogger().info("[Audes] " + shops.size() + " menu shop termuat dari config.");
    }

    private List<ShopItemDefinition> parseItems(ConfigurationSection s, String shopId, int rows) {
        List<Map<?, ?>> rawList = s.getMapList("items");
        List<ShopItemDefinition> items = new ArrayList<>();
        int maxSlot = rows * 9;

        int index = 0;
        for (Map<?, ?> raw : rawList) {
            index++;
            Object slotRaw = raw.get("slot");
            if (!(slotRaw instanceof Number slotNum)) {
                plugin.getLogger().warning("[Audes] shop '" + shopId + "' item #" + index
                        + " tidak punya 'slot' yang valid, di-skip.");
                continue;
            }
            int slot = slotNum.intValue();
            if (slot < 0 || slot >= maxSlot) {
                plugin.getLogger().warning("[Audes] shop '" + shopId + "' item #" + index + " slot " + slot
                        + " di luar jangkauan (shop ini " + rows + " baris, slot valid 0-" + (maxSlot - 1)
                        + "), di-skip.");
                continue;
            }

            Object materialRaw = raw.get("material");
            Material material;
            try {
                material = Material.valueOf(String.valueOf(materialRaw).toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("[Audes] shop '" + shopId + "' item #" + index
                        + " material '" + materialRaw + "' tidak valid, di-skip.");
                continue;
            }

            Object priceRaw = raw.get("price");
            if (!(priceRaw instanceof Number priceNum) || priceNum.doubleValue() < 0) {
                plugin.getLogger().warning("[Audes] shop '" + shopId + "' item #" + index
                        + " 'price' tidak valid (wajib angka >= 0), di-skip.");
                continue;
            }

            Object nameRaw = raw.get("name");
            String name = nameRaw != null ? String.valueOf(nameRaw) : "";

            List<String> lore = raw.get("lore") instanceof List<?> l
                    ? l.stream().map(String::valueOf).toList()
                    : List.of();

            int amount = raw.get("amount") instanceof Number a ? Math.max(1, a.intValue()) : 1;

            // Opsional -- default -1 (gak bisa dijual), SAMA konvensi kayak
            // ShopGUIPlus yang udah kepasang duluan di server (lihat
            // ShopItemDefinition javadoc kenapa -1 dipilih).
            double sellPrice = raw.get("sell-price") instanceof Number sp ? sp.doubleValue() : -1.0;

            items.add(new ShopItemDefinition(slot, material, name, lore, priceNum.doubleValue(), sellPrice, amount));
        }
        return List.copyOf(items);
    }

    public Optional<ShopDefinition> get(String id) {
        return Optional.ofNullable(shops.get(id));
    }

    public Map<String, ShopDefinition> getAll() {
        return shops;
    }

    /**
     * Tulis balik SATU ShopDefinition ke config.yml (dipanggil ShopEditListener
     * abis save dari GUI edit) + update memory (shops map) sekalian, jadi
     * gak perlu loadFromConfig() lagi setelahnya buat sinkron.
     *
     * Nulis ulang WHOLE section "shop.<id>.items" (bukan patch satu-satu) --
     * lebih simpel dan aman dari sisa data lama nyangkut (mis. item yang
     * dihapus di GUI edit tapi field-nya masih ada di YAML kalau cuma di-set
     * per-index).
     */
    public void save(ShopDefinition def) {
        shops.put(def.id(), def);

        var config = plugin.getConfig();
        String base = "shop." + def.id();
        config.set(base + ".title", def.title());
        config.set(base + ".rows", def.rows());

        List<Map<String, Object>> serialized = new ArrayList<>();
        for (ShopItemDefinition item : def.items()) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("slot", item.slot());
            map.put("material", item.material().name());
            map.put("name", item.displayName());
            map.put("lore", item.lore());
            map.put("price", item.price());
            map.put("sell-price", item.sellPrice());
            map.put("amount", item.giveAmount());
            serialized.add(map);
        }
        config.set(base + ".items", serialized);

        plugin.saveConfig();
    }
}
