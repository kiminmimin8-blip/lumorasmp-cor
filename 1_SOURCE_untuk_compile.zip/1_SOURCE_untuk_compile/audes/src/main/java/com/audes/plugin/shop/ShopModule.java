package com.audes.plugin.shop;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import org.bukkit.event.HandlerList;

/**
 * Modul shop -- pola SAMA seperti GuiModule (lihat javadoc di sana), bedanya
 * shop WAJIB Vault + economy plugin (mis. EssentialsX Economy) ke-detect.
 * Kalau enable() dilempar exception, ModuleManager isolasi modul ini (shop
 * mati, modul lain tetap jalan normal) -- BUKAN seluruh plugin down, sesuai
 * kontrak AudesModule.
 */
public class ShopModule implements AudesModule {

    private final AudesPlugin plugin;
    private ShopRegistry registry;
    private VaultEconomyBridge economy;
    private ShopManager manager;
    private ShopEditManager editManager;
    private ShopListener listener;
    private ShopEditListener editListener;

    public ShopModule(AudesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getName() {
        return "shop";
    }

    @Override
    public void enable() {
        economy = new VaultEconomyBridge();
        if (!economy.setup()) {
            // Sengaja BUKAN silent skip -- admin yang nyalain modul "shop"
            // di config.yml pasti nunggu shop-nya beneran kepake, jadi kalau
            // Vault/economy plugin gak ada, ini WAJIB kelihatan jelas di
            // console (bukan diem-diem gak jalan, atau lebih parah, jalan
            // tapi item gratis semua tanpa potong saldo).
            plugin.getLogger().severe("[Audes] Modul 'shop' GAGAL enable -- Vault dan/atau economy plugin "
                    + "(mis. EssentialsX Economy, CMI) tidak ke-detect. Pasang Vault + economy plugin, "
                    + "lalu restart/reload.");
            throw new IllegalStateException("Vault economy service tidak tersedia");
        }

        registry = new ShopRegistry(plugin);
        registry.loadFromConfig(plugin.getConfig().getConfigurationSection("shop"));
        manager = new ShopManager(economy, registry);
        listener = new ShopListener(registry, economy, manager);
        plugin.getServer().getPluginManager().registerEvents(listener, plugin);

        editManager = new ShopEditManager();
        editListener = new ShopEditListener(registry, editManager, plugin);
        plugin.getServer().getPluginManager().registerEvents(editListener, plugin);
    }

    @Override
    public void disable() {
        if (listener != null) {
            HandlerList.unregisterAll(listener);
            listener = null;
        }
        if (editListener != null) {
            HandlerList.unregisterAll(editListener);
            editListener = null;
        }
    }

    public ShopRegistry getRegistry() {
        return registry;
    }

    public ShopManager getManager() {
        return manager;
    }

    public ShopEditManager getEditManager() {
        return editManager;
    }
}
