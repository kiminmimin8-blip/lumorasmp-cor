package com.audes.plugin.shop;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;

/**
 * Menangani klik di shop. Pola click-cancel SAMA seperti GuiListener (lihat
 * javadoc di sana) -- shop juga murni menu beli/jual, bukan tempat pindah item.
 *
 * Klik KIRI = beli (sesuai giveAmount di config). Klik KANAN = jual seluruh
 * stack material yang sama yang lagi dipegang player di tangan (bukan cuma
 * 1 biji -- niatnya "jual semua yang lagi dipegang", biar gak spam klik).
 * Sengaja gak dijadiin klik kiri=beli DAN jual dobel-fungsi di klik yang
 * sama, biar gak ada salah pencet beli padahal maksudnya jual (atau
 * sebaliknya) -- pemisahan tombol lebih jelas daripada mode toggle.
 *
 * ALUR BELI (klik kiri):
 *   1. Cek VaultEconomyBridge ready (Vault + economy plugin ke-detect) --
 *      kalau tidak, tolak transaksi dengan pesan jelas (BUKAN kasih gratis).
 *   2. Cek saldo cukup (economy.has) SEBELUM withdraw -- withdraw Vault
 *      bisa gagal kalau economy plugin race condition, jadi dicek dulu di
 *      sini biar pesan errornya jelas "saldo kurang" bukan "transaksi gagal"
 *      generik.
 *   3. withdraw() -- kalau balik false (race condition/plugin lain motong
 *      saldo bersamaan), BATALKAN, JANGAN kasih item (jangan dikasih dulu
 *      baru dicek, itu celah dupe/gratis kalau withdraw gagal belakangan).
 *   4. Baru setelah withdraw sukses, kasih item ke inventory player.
 *
 * ALUR JUAL (klik kanan) -- urutan KEBALIKANNYA sengaja: item DIAMBIL DULU
 * (setAmount(0) di tangan) SEBELUM deposit dipanggil, supaya kalau server
 * crash/lag di antara dua step ini, kasus terburuknya player RUGI (item
 * ilang, uang belum masuk -- gampang di-refund manual admin) BUKAN
 * DUPLIKASI UANG (uang nambah tapi item balik ke tangan gara-gara rollback).
 * Aturan umum desain shop: kalau ada 1 sisi yang mungkin gagal ke-refund
 * manual, pilih arah kegagalan yang MERUGIKAN PLAYER, bukan yang bisa
 * dieksploitasi buat dupe duit dari server.
 */
public class ShopListener implements Listener {

    private final ShopRegistry registry;
    private final VaultEconomyBridge economy;
    private final ShopManager manager;

    public ShopListener(ShopRegistry registry, VaultEconomyBridge economy, ShopManager manager) {
        this.registry = registry;
        this.economy = economy;
        this.manager = manager;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder topHolder = event.getView().getTopInventory().getHolder();

        if (topHolder instanceof AudesShopHubHolder hub) {
            event.setCancelled(true);
            if (!(event.getWhoClicked() instanceof Player player)) return;
            if (event.getClickedInventory() == null || event.getClickedInventory() != event.getView().getTopInventory()) {
                return;
            }
            String shopId = hub.getShopId(event.getSlot());
            if (shopId != null) {
                registry.get(shopId).ifPresent(def -> manager.open(player, def));
            }
            return;
        }

        if (!(topHolder instanceof AudesShopHolder holder)) return; // bukan shop Audes, biarkan normal

        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getView().getTopInventory()) {
            return;
        }

        registry.get(holder.getShopId()).ifPresent(def -> {
            int slot = event.getSlot();

            // Dev20: klik di baris kontrol (kembali/prev/next) ditangani
            // DULUAN, sebelum coba cocokin ke daftar item -- baris kontrol
            // ada DI LUAR jangkauan slot item asli (lihat getContentSlotCount),
            // jadi urutan ini murni buat kejelasan kode, bukan buat nyegah bug.
            if (holder.isNavSlot(slot)) {
                if (slot == holder.getBackSlot()) {
                    manager.openHub(player, registry.getAll());
                } else if (slot == holder.getPrevSlot()) {
                    String category = ShopManager.categoryOf(def.id());
                    int page = ShopManager.pageOf(def.id());
                    String prevId = category + "_shop" + (page - 1 <= 1 ? "" : "_" + (page - 1));
                    registry.get(prevId).ifPresent(prevDef -> manager.open(player, prevDef));
                } else if (slot == holder.getNextSlot()) {
                    String category = ShopManager.categoryOf(def.id());
                    int page = ShopManager.pageOf(def.id());
                    registry.get(category + "_shop_" + (page + 1)).ifPresent(nextDef -> manager.open(player, nextDef));
                }
                return;
            }

            def.items().stream()
                    .filter(i -> i.slot() == slot)
                    .findFirst()
                    .ifPresent(item -> {
                        if (event.isRightClick()) {
                            handleSell(player, def, item);
                        } else {
                            handlePurchase(player, def, item);
                        }
                    });
        });
    }

    private void handlePurchase(Player player, ShopDefinition def, ShopItemDefinition item) {
        if (!economy.isReady()) {
            player.sendMessage("§cShop tidak bisa dipakai -- Vault/economy plugin tidak ke-detect di server. Hubungi admin.");
            return;
        }
        if (!economy.has(player, item.price())) {
            player.sendMessage("§cSaldo kamu tidak cukup. Butuh §e" + economy.format(item.price())
                    + " §c, saldo kamu §e" + economy.format(economy.getBalance(player)) + "§c.");
            return;
        }
        if (!economy.withdraw(player, item.price())) {
            // Withdraw gagal PADAHAL has() bilang cukup -- race condition (mis.
            // 2 klik nyaris bersamaan, saldo kepotong transaksi lain duluan).
            // Item TIDAK dikasih, saldo TIDAK jadi kepotong (withdraw gagal),
            // jadi player aman, cuma perlu coba klik lagi.
            player.sendMessage("§cTransaksi gagal, coba lagi.");
            return;
        }

        var leftover = player.getInventory().addItem(
                new org.bukkit.inventory.ItemStack(item.material(), item.giveAmount())
        );
        if (!leftover.isEmpty()) {
            // Inventory penuh SETELAH saldo kepotong -- drop ke lantai
            // daripada item hilang percuma (uang sudah kepotong, item harus
            // tetap sampai ke player dengan cara apa pun).
            leftover.values().forEach(stack -> player.getWorld().dropItemNaturally(player.getLocation(), stack));
            player.sendMessage("§eInventory penuh, sisa item dijatuhkan di tanah.");
        }

        player.sendMessage("§aBerhasil beli " + item.giveAmount() + "x " + item.material().name()
                + " seharga §e" + economy.format(item.price()) + "§a.");

        // Refresh tampilan shop biar lore "Harga: ..." update warnanya kalau
        // saldo sekarang jadi gak cukup buat item lain di shop yang sama.
        manager.open(player, def);
    }

    private void handleSell(Player player, ShopDefinition def, ShopItemDefinition item) {
        if (item.sellPrice() < 0) {
            player.sendMessage("§cItem ini tidak bisa dijual di shop ini.");
            return;
        }
        if (!economy.isReady()) {
            player.sendMessage("§cShop tidak bisa dipakai -- Vault/economy plugin tidak ke-detect di server. Hubungi admin.");
            return;
        }

        var hand = player.getInventory().getItemInMainHand();
        if (hand.getType() != item.material() || hand.getAmount() <= 0) {
            player.sendMessage("§cPegang " + item.material().name() + " di tangan dulu buat dijual di sini.");
            return;
        }

        int amount = hand.getAmount();
        double total = item.sellPrice() * amount;

        // Item DIAMBIL DULU sebelum deposit -- lihat javadoc class di atas
        // soal kenapa urutan ini yang dipilih (bukan asal kebalik dari beli).
        hand.setAmount(0);

        if (!economy.deposit(player, total)) {
            // Deposit gagal (jarang -- biasanya economy plugin down/error).
            // Item SUDAH keambil (lihat javadoc), jadi balikin lagi ke
            // tangan player daripada dia rugi karena bug di plugin lain.
            player.getInventory().setItemInMainHand(new org.bukkit.inventory.ItemStack(item.material(), amount));
            player.sendMessage("§cTransaksi jual gagal (economy plugin error), item dikembalikan. Coba lagi.");
            return;
        }

        player.sendMessage("§aBerhasil jual " + amount + "x " + item.material().name()
                + " seharga total §e" + economy.format(total) + "§a.");
        manager.open(player, def);
    }
}
