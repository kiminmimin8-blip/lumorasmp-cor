package com.audes.plugin.shop;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;

/** Holder buat hub (/shop tanpa argumen) -- beda dari AudesShopHolder (isi 1 kategori) dan AudesShopEditHolder (mode edit). Nyimpen slot->shopId biar ShopListener tau kategori mana yang diklik. */
public class AudesShopHubHolder implements InventoryHolder {

    private final Map<Integer, String> slotToShopId = new HashMap<>();
    private Inventory inventory;

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void putSlot(int slot, String shopId) {
        slotToShopId.put(slot, shopId);
    }

    public String getShopId(int slot) {
        return slotToShopId.get(slot);
    }
}
