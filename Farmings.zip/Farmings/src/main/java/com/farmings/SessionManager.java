package com.farmings;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Ngatur sesi farm tiap member: masuk lewat /farmings, ada hitung mundur,
 * habis waktu -> dibalikin ke lokasi semula. Rank (permission) bisa dapat waktu, drop, dan uang lebih.
 * Cooldown + statistik disimpan di PlayerStore (players.yml).
 */
public final class SessionManager {

    private static final class Session {
        final Location returnLoc;
        final BossBar bar; // bisa null kalau bossbar dimatiin
        final double dropMult;
        final double moneyMult;
        long totalMs;
        long endMillis;
        int lastWarn = -1;
        int harvested;
        double money;

        Session(Location returnLoc, BossBar bar, double dropMult, double moneyMult, long totalMs, long endMillis) {
            this.returnLoc = returnLoc;
            this.bar = bar;
            this.dropMult = dropMult;
            this.moneyMult = moneyMult;
            this.totalMs = totalMs;
            this.endMillis = endMillis;
        }
    }

    private final Farmings plugin;
    private final Map<UUID, Session> sessions = new HashMap<>();
    /** Pemain yang lagi diteleport plugin ini ke farm (biar gak diblok listener teleport). */
    private final Set<UUID> entering = new HashSet<>();
    /** Admin yang lagi mode setting farm (masuk lewat /farmingsadmin tp) -> lokasi asal (bisa null). */
    private final Map<UUID, Location> adminReturn = new HashMap<>();

    public enum AdminResult { OK, NO_SPAWN, IN_SESSION, FAILED }

    SessionManager(Farmings plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------- query

    public boolean inSession(Player p) {
        return sessions.containsKey(p.getUniqueId());
    }

    /** Boleh berada di farm world: lagi sesi, lagi proses masuk lewat /farmings, atau punya bypass. */
    public boolean canBeInFarm(Player p) {
        return sessions.containsKey(p.getUniqueId())
                || entering.contains(p.getUniqueId())
                || adminReturn.containsKey(p.getUniqueId())
                || p.hasPermission("farmings.bypass.time");
    }

    public boolean isAdminMode(Player p) {
        return adminReturn.containsKey(p.getUniqueId());
    }

    /** Boleh build/break bebas di farm world: punya bypass.build atau lagi mode admin farm. */
    public boolean canBuild(Player p) {
        return p.hasPermission("farmings.bypass.build") || isAdminMode(p);
    }

    public int activeCount() {
        return sessions.size();
    }

    /** Sisa waktu (detik), atau -1 kalau lagi gak di sesi. */
    public long remainingSeconds(Player p) {
        Session ses = sessions.get(p.getUniqueId());
        if (ses == null) return -1;
        return Math.max(0L, (ses.endMillis - System.currentTimeMillis() + 999L) / 1000L);
    }

    /** Sisa cooldown (detik), 0 kalau bisa masuk. */
    public long cooldownRemainingSeconds(Player p) {
        if (p.hasPermission("farmings.bypass.cooldown")) return 0L;
        PlayerStore.Entry entry = plugin.store().peek(p.getUniqueId());
        if (entry == null) return 0L;
        long left = entry.cooldownUntil - System.currentTimeMillis();
        return left > 0L ? (left + 999L) / 1000L : 0L;
    }

    /** Durasi sesi buat pemain ini (detik). */
    public int durationSeconds(Player p) {
        return resolveRank(p).seconds();
    }

    /** Pengali hasil panen buat pemain yang lagi sesi (1.0 kalau gak ada). */
    public double dropMultiplier(Player p) {
        Session ses = sessions.get(p.getUniqueId());
        return ses == null ? 1.0 : ses.dropMult;
    }

    /** Gabungan semua rank yang dimiliki pemain: nilai terbesar dari masing-masing. */
    private Settings.Rank resolveRank(Player p) {
        Settings s = plugin.settings();
        int seconds = s.defaultSessionSeconds;
        double drop = 1.0;
        double money = 1.0;
        for (Map.Entry<String, Settings.Rank> e : s.ranks.entrySet()) {
            if (!p.hasPermission("farmings.rank." + e.getKey())) continue;
            Settings.Rank r = e.getValue();
            seconds = Math.max(seconds, r.seconds());
            drop = Math.max(drop, r.dropMultiplier());
            money = Math.max(money, r.moneyMultiplier());
        }
        return new Settings.Rank(seconds, drop, money);
    }

    // ---------------------------------------------------------------- harvest tracking

    /** Dipanggil listener tiap member manen crop matang. */
    public void recordHarvest(Player p, Material type) {
        Session ses = sessions.get(p.getUniqueId());
        if (ses == null) return;
        ses.harvested++;
        ses.money += plugin.settings().cropValue(type) * ses.moneyMult;
    }

    // ---------------------------------------------------------------- actions

    public void enter(Player p) {
        Settings s = plugin.settings();
        FarmData data = plugin.farmData();
        UUID id = p.getUniqueId();

        Location spawn = data.spawn();
        if (spawn == null) {
            p.sendMessage(s.message("no-spawn"));
            return;
        }
        if (sessions.containsKey(id)) {
            p.sendMessage(s.message("already-in"));
            return;
        }

        long cooldownLeft = cooldownRemainingSeconds(p);
        if (cooldownLeft > 0L) {
            p.sendMessage(s.message("cooldown", "%time%", formatLong(cooldownLeft)));
            return;
        }

        boolean unlimited = p.hasPermission("farmings.bypass.time");
        if (!unlimited && s.maxPlayers > 0 && sessions.size() >= s.maxPlayers) {
            p.sendMessage(s.message("farm-full",
                    "%current%", String.valueOf(sessions.size()),
                    "%max%", String.valueOf(s.maxPlayers)));
            return;
        }

        boolean wasInFarm = data.isFarmWorld(p.getWorld());
        Location from = p.getLocation().clone();

        boolean teleported;
        entering.add(id);
        try {
            teleported = p.teleport(spawn);
        } finally {
            entering.remove(id);
        }
        if (!teleported) {
            return; // dibatalin plugin lain
        }

        if (unlimited) {
            p.sendMessage(s.message("entered-unlimited"));
            return;
        }

        Settings.Rank rank = resolveRank(p);
        long seconds = rank.seconds();
        long totalMs = seconds * 1000L;
        long now = System.currentTimeMillis();

        BossBar bar = null;
        if (s.bossbar) {
            bar = BossBar.bossBar(
                    s.message("bossbar", "%time%", formatClock(totalMs), "%count%", "0"),
                    1f, BossBar.Color.GREEN, BossBar.Overlay.PROGRESS);
            p.showBossBar(bar);
        }

        sessions.put(id, new Session(wasInFarm ? fallback() : from, bar,
                rank.dropMultiplier(), rank.moneyMultiplier(), totalMs, now + totalMs));

        p.showTitle(Title.title(
                s.message("title-enter"),
                s.message("subtitle-enter", "%time%", formatLong(seconds))));
        p.sendMessage(s.message("entered", "%time%", formatLong(seconds)));
    }

    /** Keluar dari farm secara sukarela (/farmings leave). */
    public void leave(Player p) {
        Session ses = sessions.remove(p.getUniqueId());
        if (ses != null) {
            conclude(p.getUniqueId(), p, ses, "left", true, true);
            return;
        }
        // gak ada sesi, tapi lagi di farm world (mis. staff) -> tetap dikeluarin
        if (plugin.farmData().isFarmWorld(p.getWorld())) {
            p.teleport(fallback());
            p.sendMessage(plugin.settings().message("left"));
        } else {
            p.sendMessage(plugin.settings().message("not-in-farm"));
        }
    }

    /** Admin nendang pemain dari sesi. */
    public boolean adminEnd(Player target) {
        Session ses = sessions.remove(target.getUniqueId());
        if (ses == null) return false;
        conclude(target.getUniqueId(), target, ses, "left", true, true);
        return true;
    }

    /** Admin nambah waktu. */
    public boolean extend(Player target, long seconds) {
        Session ses = sessions.get(target.getUniqueId());
        if (ses == null) return false;
        ses.endMillis += seconds * 1000L;
        ses.totalMs += seconds * 1000L;
        ses.lastWarn = -1;
        return true;
    }

    // ---------------------------------------------------------------- mode admin (setting farm)

    /** Admin masuk farm buat setting: tanpa sesi, timer, cooldown, dan bebas build. */
    public AdminResult adminEnter(Player p) {
        FarmData data = plugin.farmData();
        Location spawn = data.spawn();
        if (spawn == null) return AdminResult.NO_SPAWN;

        UUID id = p.getUniqueId();
        if (sessions.containsKey(id)) return AdminResult.IN_SESSION;

        boolean wasInFarm = data.isFarmWorld(p.getWorld());
        Location from = wasInFarm ? adminReturn.get(id) : p.getLocation().clone();

        boolean teleported;
        entering.add(id);
        try {
            teleported = p.teleport(spawn);
        } finally {
            entering.remove(id);
        }
        if (!teleported) return AdminResult.FAILED;

        adminReturn.put(id, from); // from bisa null (dulu udah di farm) -> nanti balik ke spawn world utama
        return AdminResult.OK;
    }

    /** Keluar dari mode admin: balik ke lokasi sebelum masuk. false kalau lagi gak mode admin. */
    public boolean adminExit(Player p) {
        UUID id = p.getUniqueId();
        if (!adminReturn.containsKey(id)) return false;
        Location back = adminReturn.remove(id);
        p.teleport(safeReturn(back));
        return true;
    }

    // ---------------------------------------------------------------- ticker

    public void tick() {
        if (sessions.isEmpty()) return;
        Settings s = plugin.settings();
        long now = System.currentTimeMillis();
        List<UUID> expired = new ArrayList<>();

        for (Map.Entry<UUID, Session> entry : sessions.entrySet()) {
            Player p = Bukkit.getPlayer(entry.getKey());
            Session ses = entry.getValue();
            if (p == null || !p.isOnline()) {
                expired.add(entry.getKey());
                continue;
            }

            long remaining = ses.endMillis - now;
            if (remaining <= 0L) {
                expired.add(entry.getKey());
                continue;
            }

            if (ses.bar != null) {
                ses.bar.name(s.message("bossbar",
                        "%time%", formatClock(remaining),
                        "%count%", String.valueOf(ses.harvested)));
                ses.bar.progress((float) Math.max(0.0, Math.min(1.0, remaining / (double) ses.totalMs)));
                ses.bar.color(remaining <= 10_000L ? BossBar.Color.RED
                        : remaining <= 30_000L ? BossBar.Color.YELLOW : BossBar.Color.GREEN);
            }

            int secLeft = (int) ((remaining + 999L) / 1000L);
            if (secLeft != ses.lastWarn && s.warnAt.contains(secLeft)) {
                ses.lastWarn = secLeft;
                p.sendActionBar(s.message("warn", "%seconds%", String.valueOf(secLeft)));
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.7f, 1.2f);
            }
        }

        for (UUID id : expired) {
            Session ses = sessions.remove(id);
            if (ses != null) {
                conclude(id, Bukkit.getPlayer(id), ses, "expired", true, true);
            }
        }
    }

    // ---------------------------------------------------------------- events

    public void handleQuit(Player p) {
        adminReturn.remove(p.getUniqueId());
        Session ses = sessions.remove(p.getUniqueId());
        if (ses != null) {
            conclude(p.getUniqueId(), p, ses, null, true, false);
        }
    }

    public void handleJoin(Player p) {
        if (!plugin.farmData().isFarmWorld(p.getWorld())) return;
        if (p.hasPermission("farmings.bypass.time")) return;
        // masuk server langsung di farm world tanpa sesi -> pindahin keluar
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline() && plugin.farmData().isFarmWorld(p.getWorld()) && !sessions.containsKey(p.getUniqueId())) {
                p.teleport(fallback());
            }
        });
    }

    /** Pemain pindah dari farm world lewat cara lain (/spawn, /home, dll) -> sesi selesai. */
    public void handleWorldChange(Player p, World from) {
        if (!plugin.farmData().isFarmWorld(from)) return;
        adminReturn.remove(p.getUniqueId());
        Session ses = sessions.remove(p.getUniqueId());
        if (ses != null) {
            conclude(p.getUniqueId(), p, ses, "left", false, true);
        }
    }

    /** Server mati / plugin dimatiin: rampungin semua sesi (tanpa teleport). */
    public void shutdown() {
        Map<UUID, Session> copy = new HashMap<>(sessions);
        sessions.clear();
        adminReturn.clear();
        for (Map.Entry<UUID, Session> e : copy.entrySet()) {
            conclude(e.getKey(), Bukkit.getPlayer(e.getKey()), e.getValue(), null, false, false);
        }
    }

    // ---------------------------------------------------------------- internals

    /**
     * Rampungin sesi: simpan statistik + cooldown, kasih hadiah, sembunyiin bossbar,
     * teleport balik (opsional), kirim pesan (opsional).
     */
    private void conclude(UUID id, Player p, Session ses, String reasonKey, boolean teleport, boolean notify) {
        Settings s = plugin.settings();
        PlayerStore store = plugin.store();

        PlayerStore.Entry entry = store.get(id);
        entry.sessions++;
        entry.harvested += ses.harvested;
        if (p != null) entry.name = p.getName();
        if (s.cooldownSeconds > 0) {
            entry.cooldownUntil = System.currentTimeMillis() + s.cooldownSeconds * 1000L;
        }
        store.markDirty();

        if (p != null) {
            if (ses.bar != null) p.hideBossBar(ses.bar);
            if (teleport) p.teleport(safeReturn(ses.returnLoc));
        }

        runRewards(entry.name, ses);

        if (p != null && notify) {
            if (reasonKey != null) p.sendMessage(s.message(reasonKey));
            if (ses.harvested > 0) {
                p.sendMessage(s.message(s.rewardCommands.isEmpty() ? "summary" : "summary-reward",
                        "%count%", String.valueOf(ses.harvested),
                        "%money%", formatMoney(ses.money)));
            }
        }
    }

    private void runRewards(String playerName, Session ses) {
        Settings s = plugin.settings();
        if (s.rewardCommands.isEmpty() || ses.harvested <= 0) return;

        String money = formatMoney(ses.money);
        for (String template : s.rewardCommands) {
            String line = template
                    .replace("%player%", playerName)
                    .replace("%count%", String.valueOf(ses.harvested))
                    .replace("%money%", money);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), line);
        }
    }

    private Location safeReturn(Location loc) {
        if (loc == null || loc.getWorld() == null || plugin.farmData().isFarmWorld(loc.getWorld())) {
            return fallback();
        }
        return loc;
    }

    private Location fallback() {
        return Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    // ---------------------------------------------------------------- format

    public static String formatLong(long seconds) {
        long h = seconds / 3600L;
        long m = (seconds % 3600L) / 60L;
        long s = seconds % 60L;
        StringBuilder sb = new StringBuilder();
        if (h > 0) sb.append(h).append(" jam ");
        if (m > 0) sb.append(m).append(" menit ");
        if (s > 0 || sb.length() == 0) sb.append(s).append(" detik ");
        return sb.toString().trim();
    }

    public static String formatClock(long millis) {
        long total = (millis + 999L) / 1000L;
        return String.format(Locale.ROOT, "%d:%02d", total / 60L, total % 60L);
    }

    private static String formatMoney(double value) {
        if (Math.abs(value - Math.rint(value)) < 0.005) {
            return String.valueOf((long) Math.rint(value));
        }
        return String.format(Locale.ROOT, "%.2f", value);
    }
}
