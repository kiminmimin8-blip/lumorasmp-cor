package com.farmings;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

/** Event yang berhubungan dengan sesi member dan aturan di farm world. */
public final class WorldListener implements Listener {

    private final Farmings plugin;

    public WorldListener(Farmings plugin) {
        this.plugin = plugin;
    }

    // ================================================================ sesi

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.sessions().handleQuit(e.getPlayer());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        plugin.sessions().handleJoin(e.getPlayer());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        plugin.sessions().handleWorldChange(e.getPlayer(), e.getFrom());
    }

    /**
     * Masuk farm world HANYA lewat /farmings. Nutup jalan pintas kayak /back, /home, /tpa, /warp
     * yang bisa nge-bypass batas waktu dan cooldown.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        Settings s = plugin.settings();
        if (!s.blockOutsideTeleport) return;

        Location to = e.getTo();
        if (to == null || !plugin.farmData().isFarmWorld(to.getWorld())) return;

        Player p = e.getPlayer();
        if (plugin.sessions().canBeInFarm(p)) return;

        e.setCancelled(true);
        p.sendMessage(s.message("farm-only-command"));
    }

    // ================================================================ batasan build

    /** true kalau pemain ini kena batasan build di world tsb. */
    private boolean restricted(Player p, World world) {
        return plugin.settings().restrictBuild
                && plugin.farmData().isFarmWorld(world)
                && !plugin.sessions().canBuild(p);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (!restricted(p, e.getBlock().getWorld())) return;

        Settings s = plugin.settings();
        Block block = e.getBlock();
        Material type = block.getType();

        // crop farm: cuma boleh dipecahin kalau udah matang (nanti ditanam ulang otomatis)
        if (s.autoReplant.contains(type)) {
            if (s.onlyBreakMature && block.getBlockData() instanceof Ageable crop
                    && crop.getAge() < crop.getMaximumAge()) {
                e.setCancelled(true);
                p.sendActionBar(s.message("crop-not-mature"));
            }
            return;
        }
        if (s.allowedBreak.contains(type)) return;

        e.setCancelled(true);
        p.sendActionBar(s.message("build-denied"));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        if (!restricted(p, e.getBlockPlaced().getWorld())) return;

        // member gak boleh naruh block apa pun (farm nanam sendiri)
        e.setCancelled(true);
        p.sendActionBar(plugin.settings().message("build-denied"));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        if (restricted(e.getPlayer(), e.getBlock().getWorld())) {
            e.setCancelled(true);
            e.getPlayer().sendActionBar(plugin.settings().message("build-denied"));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (restricted(e.getPlayer(), e.getBlock().getWorld())) {
            e.setCancelled(true);
            e.getPlayer().sendActionBar(plugin.settings().message("build-denied"));
        }
    }

    // ================================================================ mob & hunger

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (!plugin.settings().noMobSpawn) return;
        if (!plugin.farmData().isFarmWorld(e.getLocation().getWorld())) return;

        switch (e.getSpawnReason()) {
            case NATURAL, CHUNK_GEN, JOCKEY, REINFORCEMENTS, TRAP -> e.setCancelled(true);
            default -> { }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHunger(FoodLevelChangeEvent e) {
        if (!plugin.settings().noHunger) return;
        if (e.getEntity() instanceof Player p && plugin.farmData().isFarmWorld(p.getWorld())) {
            e.setCancelled(true);
        }
    }

    // ================================================================ PvP

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!plugin.settings().disablePvp) return;
        if (!(e.getEntity() instanceof Player victim)) return;
        if (!plugin.farmData().isFarmWorld(victim.getWorld())) return;

        Entity damager = e.getDamager();
        if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Entity shooter) {
            damager = shooter;
        }
        if (damager instanceof Player) {
            e.setCancelled(true);
        }
    }
}
