package com.farmings;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.block.data.Ageable;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class Settings {

    /** Satu rank: lama sesi + pengali hasil panen + pengali uang. */
    public record Rank(int seconds, double dropMultiplier, double moneyMultiplier) {}

    private static final MiniMessage MM = MiniMessage.miniMessage();

    // crop
    final Set<Material> crops = EnumSet.noneOf(Material.class);
    final long defaultGrowMs;
    final int tickInterval;
    final boolean visualStages;
    final boolean blockBonemeal;
    final boolean protectFarmland;
    final boolean particles;
    final boolean sound;

    // sesi
    final int defaultSessionSeconds;
    final int cooldownSeconds;
    final int maxPlayers;
    final boolean bossbar;
    final Map<String, Rank> ranks = new LinkedHashMap<>();
    final Set<Integer> warnAt = new HashSet<>();

    // panen & hadiah
    final boolean autoPickup;
    final Map<Material, Double> cropValues = new EnumMap<>(Material.class);
    final List<String> rewardCommands;

    // aturan world
    final boolean restrictBuild;
    final boolean onlyBreakMature;
    final boolean blockOutsideTeleport;
    final boolean disablePvp;
    final boolean noMobSpawn;
    final boolean noHunger;
    final Set<Material> autoReplant = EnumSet.noneOf(Material.class);
    final Set<Material> allowedBreak = EnumSet.noneOf(Material.class);

    private final Map<Material, Long> growMs = new EnumMap<>(Material.class);
    private final FileConfiguration cfg;

    Settings(Farmings plugin) {
        FileConfiguration c = plugin.getConfig();
        this.cfg = c;

        defaultGrowMs = Math.max(1L, c.getLong("grow-time-seconds", 5L)) * 1000L;
        tickInterval = Math.max(1, c.getInt("tick-interval-ticks", 10));
        visualStages = c.getBoolean("visual-stages", true);
        blockBonemeal = c.getBoolean("block-bonemeal", true);
        protectFarmland = c.getBoolean("protect-farmland", true);
        particles = c.getBoolean("effects.particles", true);
        sound = c.getBoolean("effects.sound", false);

        defaultSessionSeconds = Math.max(1, c.getInt("session.default-seconds", 180));
        cooldownSeconds = Math.max(0, c.getInt("session.cooldown-seconds", 43200));
        maxPlayers = Math.max(0, c.getInt("session.max-players", 0));
        bossbar = c.getBoolean("session.bossbar", true);
        warnAt.addAll(c.getIntegerList("session.warn-at-seconds"));

        ConfigurationSection rankSection = c.getConfigurationSection("session.ranks");
        if (rankSection != null) {
            for (String key : rankSection.getKeys(false)) {
                if (rankSection.isConfigurationSection(key)) {
                    ConfigurationSection r = rankSection.getConfigurationSection(key);
                    ranks.put(key, new Rank(
                            Math.max(1, r.getInt("seconds", defaultSessionSeconds)),
                            Math.max(0.0, r.getDouble("drop-multiplier", 1.0)),
                            Math.max(0.0, r.getDouble("money-multiplier", 1.0))));
                } else {
                    // format lama: "vip: 300"
                    ranks.put(key, new Rank(Math.max(1, rankSection.getInt(key)), 1.0, 1.0));
                }
            }
        }

        autoPickup = c.getBoolean("harvest.auto-pickup", true);
        rewardCommands = List.copyOf(c.getStringList("rewards.commands"));

        restrictBuild = c.getBoolean("world.restrict-build", false);
        onlyBreakMature = c.getBoolean("world.only-break-mature", true);
        blockOutsideTeleport = c.getBoolean("world.block-outside-teleport", true);
        disablePvp = c.getBoolean("world.disable-pvp", true);
        noMobSpawn = c.getBoolean("world.no-mob-spawn", true);
        noHunger = c.getBoolean("world.no-hunger", true);

        loadMaterials(plugin, c.getStringList("crops"), crops, true);
        loadMaterials(plugin, c.getStringList("world.auto-replant"), autoReplant, true);
        loadMaterials(plugin, c.getStringList("world.allowed-break"), allowedBreak, false);

        ConfigurationSection per = c.getConfigurationSection("per-crop-seconds");
        if (per != null) {
            for (String key : per.getKeys(false)) {
                Material m = Material.matchMaterial(key);
                if (m != null && crops.contains(m)) {
                    growMs.put(m, Math.max(1L, per.getLong(key)) * 1000L);
                }
            }
        }

        ConfigurationSection values = c.getConfigurationSection("rewards.crop-values");
        if (values != null) {
            for (String key : values.getKeys(false)) {
                Material m = Material.matchMaterial(key);
                if (m == null) {
                    plugin.getLogger().warning("Material gak valid di rewards.crop-values: " + key);
                    continue;
                }
                cropValues.put(m, Math.max(0.0, values.getDouble(key)));
            }
        }
    }

    private static void loadMaterials(Farmings plugin, List<String> names, Set<Material> out, boolean requireAgeable) {
        for (String name : names) {
            Material m = Material.matchMaterial(name);
            if (m == null || !m.isBlock() || (requireAgeable && !(m.createBlockData() instanceof Ageable))) {
                plugin.getLogger().warning("Material gak valid di config.yml: " + name);
                continue;
            }
            out.add(m);
        }
    }

    long growMs(Material type) {
        return growMs.getOrDefault(type, defaultGrowMs);
    }

    double cropValue(Material type) {
        return cropValues.getOrDefault(type, 0.0);
    }

    /** Ambil pesan dari config (MiniMessage). Replacement berupa pasangan key, value. */
    Component message(String key, String... replacements) {
        String raw = cfg.getString("messages." + key); // 1 argumen = ikut default bawaan jar
        if (raw == null) raw = "";
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            raw = raw.replace(replacements[i], replacements[i + 1]);
        }
        return MM.deserialize(raw);
    }
}
