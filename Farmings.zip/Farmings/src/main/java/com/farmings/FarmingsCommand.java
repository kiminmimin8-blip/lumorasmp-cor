package com.farmings;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** /farmings -> masuk | leave -> keluar | time -> sisa waktu / cooldown | stats -> statistik | top -> leaderboard */
public final class FarmingsCommand implements CommandExecutor, TabCompleter {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private static final List<String> SUBS = List.of("leave", "time", "stats", "top");

    private final Farmings plugin;

    public FarmingsCommand(Farmings plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Command ini cuma buat pemain.");
            return true;
        }

        SessionManager sessions = plugin.sessions();
        if (args.length == 0) {
            sessions.enter(p);
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "leave", "keluar" -> sessions.leave(p);
            case "time", "waktu" -> showTime(p);
            case "stats", "statistik" -> showStats(p);
            case "top" -> showTop(p);
            default -> p.sendMessage(plugin.settings().message("farmings-usage"));
        }
        return true;
    }

    private void showTime(Player p) {
        Settings s = plugin.settings();
        SessionManager sessions = plugin.sessions();

        long remaining = sessions.remainingSeconds(p);
        if (remaining >= 0) {
            p.sendMessage(s.message("time-left", "%time%", SessionManager.formatLong(remaining)));
            return;
        }
        long cooldown = sessions.cooldownRemainingSeconds(p);
        if (cooldown > 0) {
            p.sendMessage(s.message("cooldown-status", "%time%", SessionManager.formatLong(cooldown)));
        } else {
            p.sendMessage(s.message("ready"));
        }
    }

    private void showStats(Player p) {
        PlayerStore.Entry entry = plugin.store().peek(p.getUniqueId());
        long harvested = entry == null ? 0L : entry.harvested;
        int sessionCount = entry == null ? 0 : entry.sessions;

        p.sendMessage(MM.deserialize("<gold>Statistik Farm lu"));
        p.sendMessage(MM.deserialize("<gray>Total panen: <white>" + harvested + " crop"));
        p.sendMessage(MM.deserialize("<gray>Jumlah sesi: <white>" + sessionCount));
        p.sendMessage(MM.deserialize("<gray>Waktu sesi lu: <white>"
                + SessionManager.formatLong(plugin.sessions().durationSeconds(p))));
        showTime(p);
    }

    private void showTop(Player p) {
        List<Map.Entry<UUID, PlayerStore.Entry>> top = plugin.store().top(10);
        if (top.isEmpty()) {
            p.sendMessage(MM.deserialize("<yellow>Belum ada yang panen di farm."));
            return;
        }
        p.sendMessage(MM.deserialize("<gold>Top Farmer <gray>(total crop dipanen)"));
        int rank = 1;
        for (Map.Entry<UUID, PlayerStore.Entry> e : top) {
            p.sendMessage(MM.deserialize("<yellow>" + rank++ + ". <white>" + MM.escapeTags(e.getValue().name)
                    + " <gray>- <green>" + e.getValue().harvested));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            return SUBS.stream().filter(x -> x.startsWith(prefix)).toList();
        }
        return List.of();
    }
}
