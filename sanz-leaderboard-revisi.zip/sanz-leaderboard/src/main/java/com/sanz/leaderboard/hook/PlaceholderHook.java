package com.sanz.leaderboard.hook;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.StatType;
import com.sanz.leaderboard.data.LeaderboardEntry;
import com.sanz.leaderboard.leaderboard.ValueFormatter;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

import java.util.Arrays;
import java.util.List;

/**
 * Registrasi expansion PlaceholderAPI -- OPSIONAL, cuma diinstansiasi kalau
 * plugin PlaceholderAPI ke-install (softdepend, dicek eksplisit di
 * SanzLeaderboard#onEnable() SEBELUM class ini disentuh sama sekali --
 * class Java baru di-classload pas pertama kali benar-benar dipakai,
 * bukan pas di-import, jadi aman dari NoClassDefFoundError selama
 * pengecekan itu ada).
 *
 * REVISI (permintaan: "biar bisa di edit dari config"): identifier
 * placeholder ("sanzleaderboard" secara default) SEKARANG dibaca dari
 * config.yml "placeholder.identifier", bukan hardcode. Ini yang bikin
 * placeholder kategori (termasuk "gems") jadi "diketahui" plugin luar
 * (TAB, DeluxeMenus, plugin scoreboard, dst) -- mereka baca string
 * placeholder yang PERSIS sama dengan yang diset admin di config ini,
 * dan admin bisa cek langsung dari config.yml tanpa buka kode.
 *
 * Placeholder yang didukung (%&lt;identifier&gt;_...%, default identifier "sanzleaderboard"):
 * - %sanzleaderboard_&lt;kategori&gt;%            -> value player, sudah diformat (lihat ValueFormatter)
 * - %sanzleaderboard_&lt;kategori&gt;_raw%        -> value mentah (angka polos, buat kalkulasi plugin lain)
 * - %sanzleaderboard_&lt;kategori&gt;_rank%       -> ranking player (1 = teratas)
 * - %sanzleaderboard_&lt;kategori&gt;_top_&lt;n&gt;_name%  -> nama player di posisi ke-n leaderboard
 * - %sanzleaderboard_&lt;kategori&gt;_top_&lt;n&gt;_value% -> value player di posisi ke-n (sudah diformat)
 *
 * &lt;kategori&gt; = salah satu configKey StatType: kills, deaths, playtime,
 * money, blocks_mined, blocks_placed, gems.
 *
 * Semua placeholder di sini baca dari CACHE (LeaderboardManager), bukan
 * query database langsung -- lihat javadoc LeaderboardManager untuk
 * alasannya (placeholder bisa di-request berkali-kali per detik dari
 * scoreboard/TAB plugin).
 */
public class PlaceholderHook extends PlaceholderExpansion {

    private final SanzLeaderboard plugin;

    public PlaceholderHook(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getIdentifier() {
        return plugin.getConfig().getString("placeholder.identifier", "sanzleaderboard");
    }

    @Override
    public String getAuthor() {
        return "Sanz SMP";
    }

    @Override
    public String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        // Tetap terdaftar walau PlaceholderAPI-nya sendiri di-reload,
        // gak perlu re-register manual tiap /papi reload.
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        if (player == null || params == null || params.isBlank()) return null;

        String[] parts = params.split("_");
        if (parts.length == 0) return null;

        // configKey kategori ada yang mengandung underscore sendiri
        // (blocks_mined, blocks_placed), jadi TIDAK bisa asumsi parts[0]
        // selalu kategori -- coba cocokkan dari kombinasi paling panjang
        // ke paling pendek supaya "blocks_mined_rank" match "blocks_mined"
        // dulu, bukan kepotong jadi "blocks".
        StatType type = null;
        String remainder = "";
        for (int len = parts.length; len >= 1; len--) {
            String candidate = String.join("_", Arrays.asList(parts).subList(0, len));
            StatType matched = StatType.fromConfigKey(candidate);
            if (matched != null) {
                type = matched;
                remainder = String.join("_", Arrays.asList(parts).subList(len, parts.length));
                break;
            }
        }
        if (type == null) return null; // kategori gak dikenal -- biar PlaceholderAPI tampilin placeholder mentah, bukan error

        if (!plugin.getLeaderboardManager().isEnabled(type)) {
            return noData();
        }

        var uuid = player.getUniqueId();

        if (remainder.isEmpty()) {
            if (!plugin.getLeaderboardManager().hasCachedValue(type, uuid)) return noData();
            return ValueFormatter.format(type, plugin.getLeaderboardManager().getCachedValue(type, uuid));
        }

        if (remainder.equals("raw")) {
            if (!plugin.getLeaderboardManager().hasCachedValue(type, uuid)) return noData();
            return String.valueOf(plugin.getLeaderboardManager().getCachedValue(type, uuid));
        }

        if (remainder.equals("rank")) {
            int rank = plugin.getLeaderboardManager().getCachedRank(type, uuid);
            return rank > 0 ? String.valueOf(rank) : noData();
        }

        if (remainder.startsWith("top_")) {
            return resolveTopPlaceholder(type, remainder);
        }

        return null;
    }

    /** Format remainder yang diharapkan: "top_<n>_name" atau "top_<n>_value". */
    private String resolveTopPlaceholder(StatType type, String remainder) {
        String[] segments = remainder.split("_");
        if (segments.length != 3) return null;

        int position;
        try {
            position = Integer.parseInt(segments[1]);
        } catch (NumberFormatException e) {
            return null;
        }
        if (position < 1) return null;

        List<LeaderboardEntry> top = plugin.getLeaderboardManager().getTop(type);
        if (position > top.size()) return noData();

        LeaderboardEntry entry = top.get(position - 1);
        return switch (segments[2]) {
            case "name" -> entry.getPlayerName();
            case "value" -> ValueFormatter.format(type, entry.getValue());
            default -> null;
        };
    }

    private String noData() {
        return plugin.getConfig().getString("placeholder.no-data", "-");
    }
}
