package com.sanz.leaderboard.data;

/**
 * Semua kategori stat yang ditrack leaderboard.
 * columnName = nama kolom di tabel SQLite player_stats.
 */
public enum StatType {
    KILLS("kills", "kills"),
    DEATHS("deaths", "deaths"),
    PLAYTIME("playtime", "playtime_seconds"),
    MONEY("money", "money_cache"),
    BLOCKS_MINED("blocks_mined", "blocks_mined"),
    BLOCKS_PLACED("blocks_placed", "blocks_placed"),
    GEMS("gems", "gems");

    private final String configKey;
    private final String columnName;

    StatType(String configKey, String columnName) {
        this.configKey = configKey;
        this.columnName = columnName;
    }

    public String configKey() {
        return configKey;
    }

    public String columnName() {
        return columnName;
    }

    public static StatType fromConfigKey(String key) {
        for (StatType type : values()) {
            if (type.configKey.equalsIgnoreCase(key)) {
                return type;
            }
        }
        return null;
    }
}
