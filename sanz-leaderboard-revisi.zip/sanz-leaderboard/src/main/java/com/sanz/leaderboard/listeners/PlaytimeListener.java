package com.sanz.leaderboard.listeners;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.StatType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Track lama sesi tiap player (dari join sampai quit), dan sync balance Vault
 * ke kolom money_cache pas join biar leaderboard money selalu update tanpa
 * perlu polling semua player terus-terusan.
 *
 * Waktu AFK (dicek lewat AFKTracker) gak dihitung sebagai playtime - tiap kali
 * di-flush (join/quit/berkala), kita cek status AFK saat itu: kalau lagi AFK,
 * durasi sejak checkpoint terakhir gak ditambahin ke playtime sama sekali.
 * Granularitasnya seukuran refresh-interval-seconds di config.
 */
public class PlaytimeListener implements Listener {

    private final SanzLeaderboard plugin;
    private final AFKTracker afkTracker;
    private final Map<UUID, Long> sessionCheckpoint = new ConcurrentHashMap<>();

    public PlaytimeListener(SanzLeaderboard plugin, AFKTracker afkTracker) {
        this.plugin = plugin;
        this.afkTracker = afkTracker;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        sessionCheckpoint.put(player.getUniqueId(), System.currentTimeMillis());
        afkTracker.markActive(player);

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            plugin.getDatabase().ensurePlayer(player.getUniqueId(), player.getName());

            if (plugin.getVaultHook().isEnabled()) {
                double balance = plugin.getVaultHook().getBalance(player);
                plugin.getDatabase().setValue(player.getUniqueId(), player.getName(), StatType.MONEY, balance);
            }
        });
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        Long checkpoint = sessionCheckpoint.remove(player.getUniqueId());
        afkTracker.remove(player.getUniqueId());
        if (checkpoint == null) return;

        long seconds = (System.currentTimeMillis() - checkpoint) / 1000L;
        boolean wasAfk = afkTracker.isAfk(player);

        // Sinkron balance final juga pas quit
        double balance = plugin.getVaultHook().isEnabled() ? plugin.getVaultHook().getBalance(player) : -1;

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            if (seconds > 0 && !wasAfk) {
                plugin.getDatabase().increment(player.getUniqueId(), player.getName(), StatType.PLAYTIME, seconds);
            }
            if (balance >= 0) {
                plugin.getDatabase().setValue(player.getUniqueId(), player.getName(), StatType.MONEY, balance);
            }
        });
    }

    /**
     * Dipanggil dari repeating task berkala, buat flush playtime player yang masih
     * online tanpa nunggu quit. Kalau player lagi AFK pas checkpoint ini, durasi sejak
     * checkpoint terakhir gak dihitung playtime.
     * Catatan: dipanggil dari thread async (sama kayak pola block-stats-buffer),
     * Player#getPlayer/hasMetadata di sini cuma baca data ringan.
     */
    public void flushOnlineSessions() {
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Long> entry : sessionCheckpoint.entrySet()) {
            UUID uuid = entry.getKey();
            Player player = plugin.getServer().getPlayer(uuid);
            if (player == null) continue;

            long seconds = (now - entry.getValue()) / 1000L;
            sessionCheckpoint.put(uuid, now);
            if (seconds <= 0) continue;

            boolean afk = afkTracker.isAfk(player);
            if (afk) continue;

            String name = player.getName();
            plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () ->
                    plugin.getDatabase().increment(uuid, name, StatType.PLAYTIME, seconds)
            );
        }
    }
}
