package com.sanz.leaderboard.hook;

import com.sanz.leaderboard.SanzLeaderboard;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.logging.Level;

/**
 * Hook ke Vault buat ambil balance player (money). Kalau Vault/plugin economy
 * gak ke-install, hook ini otomatis nonaktif dan kategori "money" gak nge-track apa-apa.
 */
public class VaultHook {

    private final SanzLeaderboard plugin;
    private Economy economy;

    public VaultHook(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    public boolean setup() {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
            plugin.getLogger().warning("Vault gak ketemu, kategori 'money' leaderboard gak akan ke-update otomatis.");
            return false;
        }
        try {
            RegisteredServiceProvider<Economy> rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
            if (rsp == null) {
                plugin.getLogger().warning("Gak ada economy provider yang registrasi ke Vault.");
                return false;
            }
            economy = rsp.getProvider();
            return true;
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Gagal setup Vault hook", e);
            return false;
        }
    }

    public boolean isEnabled() {
        return economy != null;
    }

    public double getBalance(OfflinePlayer player) {
        if (economy == null) return 0;
        try {
            return economy.getBalance(player);
        } catch (Exception e) {
            return 0;
        }
    }
}
