package com.audes.plugin.hud;

/**
 * Satu custom image (logo, dsb) yang di-render lewat font glyph —
 * teknik SAMA PERSIS dengan RankBadgeDefinition (lihat javadoc di
 * sana buat penjelasan lengkap soal Private Use Area + resource pack
 * requirement), bedanya cuma dipakai buat gambar besar standalone
 * (mis. logo server di scoreboard/tab), bukan badge kecil di depan nama.
 *
 * "character" HARUS persis sama dengan yang didaftarkan di
 * contents/assets/audes/font/images.json (dua default sudah disiapkan:
 * serverlogo -> \uF100, serverlogo2 -> \uF101).
 *
 * "bedrockCharacter" OPSIONAL -- Bedrock/Geyser gak pake JSON font
 * provider kayak Java, tapi atlas grid 16x16 per "halaman" unicode
 * (contoh: font/glyph_E1.png = U+E100-U+E1FF). Kalau image ini juga
 * di-daftarin di atlas Bedrock, isi karakter unicode versi Bedrock-nya
 * di sini (BEDA dari "character" versi Java, lihat AudesPlaceholders
 * buat gimana keduanya dipilih otomatis sesuai platform player).
 * Biarin null/kosong kalau image ini cuma didukung di Java (mis. shop
 * icon yang ukurannya terlalu variatif buat digabung ke atlas Bedrock).
 */
public record ImageDefinition(String id, String character, String bedrockCharacter) {
}
