package xyz.sanz.shop.service;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.entity.Player;
import xyz.sanz.shop.EconomyHook;
import xyz.sanz.shop.SanzShop;
import xyz.sanz.shop.model.ShopItem;
import xyz.sanz.shop.util.InventoryUtils;
import xyz.sanz.shop.util.Messages;

import java.util.HashMap;
import java.util.Map;

/**
 * Logika transaksi jual-beli murni, dipisah dari kode GUI supaya bisa dites/dipakai ulang
 * (mis. dari command langsung, bukan cuma dari klik inventory).
 */
public class ShopService {

    public enum Result {
        SUCCESS,
        NOT_ENOUGH_MONEY,
        INVENTORY_FULL,
        NOT_ENOUGH_ITEMS,
        NOT_BUYABLE,
        NOT_SELLABLE,
        NO_ECONOMY
    }

    private final SanzShop plugin;
    private final Messages messages;

    public ShopService(SanzShop plugin) {
        this.plugin = plugin;
        this.messages = plugin.getMessages();
    }

    public Result buy(Player player, ShopItem item, int qty) {
        if (!EconomyHook.isReady()) return Result.NO_ECONOMY;
        if (!item.isBuyable()) return Result.NOT_BUYABLE;

        double multiplier = plugin.getConfig().getDouble("economy.buy-multiplier", 1.0);
        double totalPrice = item.getBuyPrice() * qty * multiplier;
        int totalAmount = item.getAmount() * qty;

        Economy econ = EconomyHook.get();
        if (econ.getBalance(player) < totalPrice) return Result.NOT_ENOUGH_MONEY;
        if (!InventoryUtils.hasSpaceFor(player.getInventory(), item.getMaterial(), totalAmount)) {
            return Result.INVENTORY_FULL;
        }

        econ.withdrawPlayer(player, totalPrice);
        giveItems(player, item, totalAmount);
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);

        Map<String, String> ph = new HashMap<>();
        ph.put("%amount%", String.valueOf(totalAmount));
        ph.put("%item%", item.getDisplayName());
        ph.put("%price%", formatMoney(totalPrice));
        messages.send(player, "purchase-success", ph);
        return Result.SUCCESS;
    }

    public Result sell(Player player, ShopItem item, int qty) {
        if (!EconomyHook.isReady()) return Result.NO_ECONOMY;
        if (!item.isSellable()) return Result.NOT_SELLABLE;

        int totalAmount = item.getAmount() * qty;
        int owned = InventoryUtils.countMaterial(player.getInventory(), item.getMaterial());
        if (owned < totalAmount) return Result.NOT_ENOUGH_ITEMS;

        double multiplier = plugin.getConfig().getDouble("economy.sell-multiplier", 1.0);
        double totalPrice = item.getSellPrice() * qty * multiplier;

        InventoryUtils.removeMaterial(player.getInventory(), item.getMaterial(), totalAmount);
        EconomyHook.get().depositPlayer(player, totalPrice);
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 0.7f);

        Map<String, String> ph = new HashMap<>();
        ph.put("%amount%", String.valueOf(totalAmount));
        ph.put("%item%", item.getDisplayName());
        ph.put("%price%", formatMoney(totalPrice));
        messages.send(player, "sell-success", ph);
        return Result.SUCCESS;
    }

    private void giveItems(Player player, ShopItem item, int totalAmount) {
        int remaining = totalAmount;
        int maxStack = item.getMaterial().getMaxStackSize();
        while (remaining > 0) {
            int give = Math.min(maxStack, remaining);
            var stack = new org.bukkit.inventory.ItemStack(item.getMaterial(), give);
            player.getInventory().addItem(stack).values()
                    .forEach(leftover -> player.getWorld().dropItemNaturally(player.getLocation(), leftover));
            remaining -= give;
        }
    }

    public String formatMoney(double amount) {
        if (amount == Math.floor(amount)) {
            return String.format("%,.0f", amount);
        }
        return String.format("%,.2f", amount);
    }
}
