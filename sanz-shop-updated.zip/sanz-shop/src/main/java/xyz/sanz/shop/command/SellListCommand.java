package xyz.sanz.shop.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import xyz.sanz.shop.SanzShop;
import xyz.sanz.shop.gui.MenuBuilder;
import xyz.sanz.shop.model.ShopCategory;
import xyz.sanz.shop.model.ShopItem;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * /sellist [halaman]        -> daftar SEMUA item bisa dijual, flat (gak dikelompokin
 *                              per kategori lagi), urutan default = urutan kategori+item
 *                              di shops.yml
 * /sellist top [halaman]    -> diurutin dari harga jual TERMAHAL
 * /sellist murah [halaman]  -> diurutin dari harga jual TERMURAH
 *
 * Sengaja dibikin command chat (bukan GUI) -- ini cuma buat LIAT/CEK harga
 * jual, transaksi jual tetap lewat GUI /shop kategori masing-masing.
 */
public class SellListCommand implements CommandExecutor, TabCompleter {

    private static final int ITEMS_PER_PAGE = 10;

    private final SanzShop plugin;

    public SellListCommand(SanzShop plugin) {
        this.plugin = plugin;
    }

    private record Entry(ShopCategory category, ShopItem item) {
    }

    private List<Entry> allSellable() {
        List<Entry> all = new ArrayList<>();
        for (ShopCategory cat : plugin.getShopManager().getCategoryList()) {
            for (ShopItem item : cat.getItems()) {
                if (item.isSellable()) {
                    all.add(new Entry(cat, item));
                }
            }
        }
        return all;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        List<Entry> entries = allSellable();
        if (entries.isEmpty()) {
            sender.sendMessage(plugin.getMessages().prefix() + "§cGak ada item yang bisa dijual sama sekali saat ini.");
            return true;
        }

        String mode = "default";
        int pageArgIndex = 0;
        if (args.length > 0 && (args[0].equalsIgnoreCase("top") || args[0].equalsIgnoreCase("murah"))) {
            mode = args[0].equalsIgnoreCase("top") ? "top" : "murah";
            pageArgIndex = 1;
        }

        if (mode.equals("top")) {
            entries.sort(Comparator.comparingDouble((Entry e) -> e.item().getSellPrice()).reversed());
        } else if (mode.equals("murah")) {
            entries.sort(Comparator.comparingDouble(e -> e.item().getSellPrice()));
        }
        // mode "default": urutan asli (insertion order kategori+item), gak di-sort

        int page = 1;
        if (args.length > pageArgIndex) {
            try {
                page = Integer.parseInt(args[pageArgIndex]);
            } catch (NumberFormatException ignored) {
                // biarin default 1 kalau bukan angka
            }
        }

        showPage(sender, entries, mode, page);
        return true;
    }

    private void showPage(CommandSender sender, List<Entry> entries, String mode, int page) {
        int totalPages = Math.max(1, (int) Math.ceil(entries.size() / (double) ITEMS_PER_PAGE));
        page = Math.max(1, Math.min(page, totalPages));
        int from = (page - 1) * ITEMS_PER_PAGE;
        int to = Math.min(from + ITEMS_PER_PAGE, entries.size());

        String title = switch (mode) {
            case "top" -> "§e§lPaling Mahal";
            case "murah" -> "§e§lPaling Murah";
            default -> "§e§lSemua Item Bisa Dijual";
        };

        sender.sendMessage("§8§m                                                ");
        sender.sendMessage(title + " §8(Hal " + page + "/" + totalPages + ", total " + entries.size() + " item)");
        for (int i = from; i < to; i++) {
            Entry e = entries.get(i);
            sender.sendMessage("§7 - §f" + e.item().getDisplayName() + " §8(" + e.category().getTitle() + ") §8» §a"
                    + MenuBuilder.fmt(e.item().getSellPrice()) + " Coin");
        }
        if (page < totalPages) {
            String cmd = mode.equals("default") ? "/sellist" : "/sellist " + mode;
            sender.sendMessage("§7Halaman selanjutnya §8: §f" + cmd + " " + (page + 1));
        }
        sender.sendMessage("§8§m                                                ");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) return List.of();
        return List.of("top", "murah").stream()
                .filter(s -> s.startsWith(args[0].toLowerCase()))
                .toList();
    }
}
