package xyz.sanz.shop.resourcepack;

import net.kyori.adventure.resource.ResourcePackInfo;
import net.kyori.adventure.resource.ResourcePackRequest;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import xyz.sanz.shop.SanzShop;

import java.net.URI;
import java.util.UUID;

/**
 * Ngirim resource pack SanzShop (assets/sanz/... -- banner title GUI, lihat
 * config.yml shop.use-banner-titles) ke player pas join.
 *
 * SENGAJA pakai UUID TETAP (bukan random per-request) lewat fitur Paper
 * "multiple resource packs" (dari 1.20.3): tiap pack Paper dibedain lewat
 * UUID-nya sendiri, independen dari mekanisme resource-pack= di
 * server.properties (itu jalur protokol beda total, dari sebelum multi-pack
 * ada). Jadi 2-2nya bisa nempel bareng di client yang sama tanpa saling
 * override -- server.properties tetap ngurus pack utamanya sendiri, plugin
 * ini nambahin pack KEDUA di atasnya (default: STACK, bukan REPLACE).
 *
 * UUID tetap juga artinya kalau plugin reload/restart, pack yang sama
 * dikirim ulang dengan id yang SAMA -- klien nge-cache berdasar UUID+hash,
 * jadi kalau isi pack gak berubah (hash sama persis), client gak perlu
 * download ulang.
 */
public class ShopResourcePackModule implements Listener {

    /** UUID tetap khusus resource pack SanzShop -- JANGAN diubah setelah live,
     *  supaya client yang udah punya pack ini gak dikira pack baru beda. */
    public static final UUID SHOP_PACK_ID = UUID.fromString("5a6b6f6e-7a73-6873-6f70-706b675f7631");

    private final SanzShop plugin;
    private boolean enabled;
    private ResourcePackInfo packInfo;
    private boolean required;
    private Component promptMessage;

    public ShopResourcePackModule(SanzShop plugin) {
        this.plugin = plugin;
    }

    public void enable() {
        reloadSettings();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    /** Dipanggil ulang setelah /shopedit reload atau reload config manual. */
    public void reloadSettings() {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("resource-pack");
        if (section == null) {
            enabled = false;
            packInfo = null;
            return;
        }

        enabled = section.getBoolean("enabled", false);
        required = section.getBoolean("required", false);
        String urlStr = section.getString("url", "");
        String sha1 = section.getString("sha1", "");
        String promptStr = section.getString("prompt-message", "");
        // PENTING: prompt-message di config pakai kode legacy '&' (sama kayak
        // semua pesan lain di plugin ini, lihat Messages#color). MiniMessage
        // SENGAJA nolak keras (throw ParsingException, bukan cuma warning)
        // kalau nemu kode legacy ('&' ATAU '§') di dalam string yang
        // di-deserialize -- makanya WAJIB LegacyComponentSerializer di sini,
        // bukan MiniMessage, walau sama-sama dari paket Adventure.
        promptMessage = promptStr.isBlank() ? null : LegacyComponentSerializer.legacyAmpersand().deserialize(promptStr);

        if (!enabled) {
            packInfo = null;
            return;
        }

        if (urlStr.isBlank() || sha1.isBlank()) {
            plugin.getLogger().warning("resource-pack.enabled true tapi url/sha1 di config.yml masih kosong -- "
                    + "resource pack SanzShop TIDAK dikirim ke player sampai keduanya diisi. "
                    + "Upload pack ke hosting (mis. mc-packs.net), isi url + `sha1sum` filenya di sini.");
            enabled = false;
            packInfo = null;
            return;
        }

        if (!sha1.matches("[0-9a-fA-F]{40}")) {
            plugin.getLogger().warning("resource-pack.sha1 di config.yml panjangnya harus 40 karakter hex "
                    + "(hasil `sha1sum namafile.zip`), nilai sekarang: '" + sha1 + "' -- resource pack TIDAK dikirim.");
            enabled = false;
            packInfo = null;
            return;
        }

        try {
            packInfo = ResourcePackInfo.resourcePackInfo()
                    .id(SHOP_PACK_ID)
                    .uri(URI.create(urlStr))
                    .hash(sha1.toLowerCase())
                    .build();
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("resource-pack.url di config.yml bukan URL valid: " + urlStr
                    + " (" + e.getMessage() + ") -- resource pack TIDAK dikirim.");
            enabled = false;
            packInfo = null;
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!enabled || packInfo == null) return;
        send(event.getPlayer());
    }

    /** Kirim manual, misal dari command reload buat push ke semua player yang lagi online. */
    public void send(Player player) {
        if (!enabled || packInfo == null) return;

        ResourcePackRequest.Builder request = ResourcePackRequest.resourcePackRequest()
                .packs(packInfo)
                .required(required);
        if (promptMessage != null) {
            request.prompt(promptMessage);
        }

        player.sendResourcePacks(request.build());
    }
}
