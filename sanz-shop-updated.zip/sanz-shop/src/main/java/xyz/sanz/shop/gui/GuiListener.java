package xyz.sanz.shop.gui;

import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import xyz.sanz.shop.SanzShop;
import xyz.sanz.shop.ShopManager;
import xyz.sanz.shop.gui.holder.*;
import xyz.sanz.shop.model.ShopCategory;
import xyz.sanz.shop.model.ShopItem;
import xyz.sanz.shop.service.ShopService;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class GuiListener implements Listener {

    private final SanzShop plugin;

    /**
     * State "sedang mindahin slot": key = player, value = apa yang lagi dipegang.
     * itemIndex == -1 artinya ini mode pindah KATEGORI (categoryKey = key kategori
     * yang dipilih). itemIndex >= 0 artinya mode pindah ITEM (categoryKey = kategori
     * tempat item itu, itemIndex = index absolut di list item kategori itu).
     * Dibersihkan begitu ada pasangan kedua (langsung swap) atau player quit.
     */
    private final Map<UUID, PendingMove> pendingMoves = new HashMap<>();

    private record PendingMove(String categoryKey, int itemIndex) {
        boolean isCategoryMove() {
            return itemIndex < 0;
        }
    }

    public GuiListener(SanzShop plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onQuit(org.bukkit.event.player.PlayerQuitEvent e) {
        pendingMoves.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrag(InventoryDragEvent e) {
        InventoryHolder holder = e.getInventory().getHolder();
        if (holder instanceof BaseHolder) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(InventoryClickEvent e) {
        InventoryHolder holder = e.getInventory().getHolder();
        if (!(holder instanceof BaseHolder)) return;

        // Klik di inventory pemain sendiri (bagian bawah) selagi GUI kami terbuka: biarkan normal,
        // tapi jangan biarkan orang shift-click barang dari inventory-nya ke GUI toko.
        if (e.getClickedInventory() != null && e.getClickedInventory().equals(e.getView().getBottomInventory())) {
            if (e.isShiftClick()) e.setCancelled(true);
            return;
        }

        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player player)) return;

        int slot = e.getRawSlot();

        if (holder instanceof ShopMainHolder) {
            handleShopMainClick(player, slot);
        } else if (holder instanceof ShopCategoryHolder h) {
            handleShopCategoryClick(player, h, slot, e.getClick());
        } else if (holder instanceof ShopEditMainHolder) {
            handleEditMainClick(player, slot, e.getClick());
        } else if (holder instanceof ShopEditCategoryHolder h) {
            handleEditCategoryClick(player, h, slot, e.getClick());
        } else if (holder instanceof ShopEditItemHolder h) {
            handleEditItemClick(player, h, slot);
        } else if (holder instanceof ShopSearchHolder h) {
            handleShopSearchClick(player, h, slot, e.getClick());
        }
    }

    // ================= MENU BELANJA =================

    private void handleShopMainClick(Player player, int slot) {
        if (slot == 49) {
            player.closeInventory();
            return;
        }
        if (slot == 51) {
            plugin.getChatInputManager().request(player, "Ketik kata kunci pencarian item:",
                    (p, msg) -> MenuBuilder.openSearchMenu(p, plugin, msg, 0));
            return;
        }
        List<ShopCategory> cats = plugin.getShopManager().getCategoryList();
        int index = MenuBuilder.categoryIndexForSlot(slot, cats.size());
        if (index >= 0) {
            MenuBuilder.openCategoryMenu(player, plugin, cats.get(index).getKey(), 0);
        }
    }

    private void handleShopCategoryClick(Player player, ShopCategoryHolder h, int slot, ClickType click) {
        if (slot == MenuBuilder.SLOT_BACK) {
            MenuBuilder.openMainMenu(player, plugin);
            return;
        }
        if (slot == MenuBuilder.SLOT_PREV) {
            MenuBuilder.openCategoryMenu(player, plugin, h.getCategoryKey(), h.getPage() - 1);
            return;
        }
        if (slot == MenuBuilder.SLOT_NEXT) {
            MenuBuilder.openCategoryMenu(player, plugin, h.getCategoryKey(), h.getPage() + 1);
            return;
        }
        if (slot < 0 || slot >= MenuBuilder.PAGE_SIZE) return;

        ShopCategory cat = plugin.getShopManager().getCategory(h.getCategoryKey());
        if (cat == null) return;
        int index = h.getPage() * MenuBuilder.PAGE_SIZE + slot;
        if (index < 0 || index >= cat.getItems().size()) return;
        ShopItem item = cat.getItems().get(index);

        ShopService service = plugin.getShopService();
        ShopService.Result result;

        if (click == ClickType.LEFT || click == ClickType.SHIFT_LEFT) {
            int qty = click == ClickType.SHIFT_LEFT ? 64 : 1;
            result = service.buy(player, item, qty);
            reportResult(player, result);
        } else if (click == ClickType.RIGHT || click == ClickType.SHIFT_RIGHT) {
            int qty = click == ClickType.SHIFT_RIGHT ? 64 : 1;
            result = service.sell(player, item, qty);
            reportResult(player, result);
        } else {
            return;
        }

        // refresh tampilan (harga/jumlah tidak berubah tapi biar konsisten & inventory pemain ke-update)
        MenuBuilder.openCategoryMenu(player, plugin, h.getCategoryKey(), h.getPage());
    }

    private void reportResult(Player player, ShopService.Result result) {
        var msg = plugin.getMessages();
        switch (result) {
            case NOT_ENOUGH_MONEY -> player.sendMessage(msg.get("not-enough-money"));
            case INVENTORY_FULL -> player.sendMessage(msg.get("inventory-full"));
            case NOT_ENOUGH_ITEMS -> player.sendMessage(msg.get("no-items-to-sell"));
            case NOT_BUYABLE -> player.sendMessage(msg.get("cannot-buy"));
            case NOT_SELLABLE -> player.sendMessage(msg.get("cannot-sell"));
            case NO_ECONOMY -> player.sendMessage(msg.get("economy-missing"));
            case SUCCESS -> { /* pesan sukses + suara sukses sudah dikirim ShopService */ }
        }
        if (result != ShopService.Result.SUCCESS) {
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
        }
    }

    private void handleShopSearchClick(Player player, ShopSearchHolder h, int slot, ClickType click) {
        if (slot == MenuBuilder.SLOT_BACK) {
            player.closeInventory();
            return;
        }
        if (slot == MenuBuilder.SLOT_PREV) {
            MenuBuilder.reopenSearchMenu(player, plugin, h, h.getPage() - 1);
            return;
        }
        if (slot == MenuBuilder.SLOT_NEXT) {
            MenuBuilder.reopenSearchMenu(player, plugin, h, h.getPage() + 1);
            return;
        }
        if (slot < 0 || slot >= MenuBuilder.PAGE_SIZE) return;

        int index = h.getPage() * MenuBuilder.PAGE_SIZE + slot;
        List<ShopItem> matched = h.getMatchedItems();
        if (index < 0 || index >= matched.size()) return;
        ShopItem item = matched.get(index);

        ShopService service = plugin.getShopService();
        ShopService.Result result;

        if (click == ClickType.LEFT || click == ClickType.SHIFT_LEFT) {
            int qty = click == ClickType.SHIFT_LEFT ? 64 : 1;
            result = service.buy(player, item, qty);
            reportResult(player, result);
        } else if (click == ClickType.RIGHT || click == ClickType.SHIFT_RIGHT) {
            int qty = click == ClickType.SHIFT_RIGHT ? 64 : 1;
            result = service.sell(player, item, qty);
            reportResult(player, result);
        } else {
            return;
        }

        MenuBuilder.reopenSearchMenu(player, plugin, h, h.getPage());
    }

    // ================= MENU EDITOR: kategori =================

    private void handleEditMainClick(Player player, int slot, ClickType click) {
        if (!player.hasPermission("sanzshop.edit")) return;

        if (slot == 49) {
            player.closeInventory();
            return;
        }
        if (slot == MenuBuilder.SLOT_ADD) {
            startCreateCategoryFlow(player);
            return;
        }

        List<ShopCategory> cats = plugin.getShopManager().getCategoryList();
        int index = MenuBuilder.categoryIndexForSlot(slot, cats.size());
        if (index < 0) return;
        ShopCategory cat = cats.get(index);

        if (click == ClickType.SHIFT_LEFT) {
            handleCategoryMoveClick(player, cat);
            return;
        }
        if (click == ClickType.SHIFT_RIGHT) {
            plugin.getShopManager().deleteCategory(cat.getKey());
            player.sendMessage(plugin.getMessages().get("category-deleted").replace("%category%", cat.getTitle()));
            MenuBuilder.openEditMainMenu(player, plugin);
        } else {
            MenuBuilder.openEditCategoryMenu(player, plugin, cat.getKey(), 0);
        }
    }

    /**
     * Klik pertama (Shift+Klik Kiri) di kategori manapun: "pegang" kategori itu.
     * Klik kedua (Shift+Klik Kiri) di kategori LAIN: tuker slot dengan yang dipegang.
     * Klik kedua di kategori yang SAMA: batal.
     */
    private void handleCategoryMoveClick(Player player, ShopCategory clicked) {
        PendingMove pending = pendingMoves.get(player.getUniqueId());
        if (pending != null && pending.isCategoryMove()) {
            if (pending.categoryKey().equals(clicked.getKey())) {
                pendingMoves.remove(player.getUniqueId());
                player.sendMessage("§7Pemindahan slot kategori dibatalkan.");
            } else {
                plugin.getShopManager().swapCategoryOrder(pending.categoryKey(), clicked.getKey());
                pendingMoves.remove(player.getUniqueId());
                player.sendMessage("§aPosisi slot kategori berhasil ditukar.");
            }
            MenuBuilder.openEditMainMenu(player, plugin);
            return;
        }
        pendingMoves.put(player.getUniqueId(), new PendingMove(clicked.getKey(), -1));
        player.sendMessage("§e" + clicked.getTitle() + " §7dipilih untuk dipindah — Shift+Klik Kiri kategori lain buat tuker slot (Shift+Klik Kiri lagi di sini buat batal).");
    }

    private void startCreateCategoryFlow(Player player) {
        plugin.getChatInputManager().request(player, "§e➤ Masukkan ID unik untuk kategori baru §7(huruf kecil, tanpa spasi — contoh: §fnether_ore§7):", (p, keyInput) -> {
            String key = keyInput.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
            if (key.isEmpty() || plugin.getShopManager().categoryExists(key)) {
                p.sendMessage("§cID tidak valid atau sudah digunakan kategori lain. Proses dibatalkan.");
                MenuBuilder.openEditMainMenu(p, plugin);
                return;
            }
            plugin.getChatInputManager().request(p, "§e➤ Masukkan judul kategori §7(tampil di GUI — contoh: §fNether Ores§7):", (p2, titleInput) -> {
                Material icon = Material.CHEST;
                ItemStack hand = p2.getInventory().getItemInMainHand();
                if (hand != null && hand.getType() != Material.AIR) icon = hand.getType();

                plugin.getShopManager().createCategory(key, titleInput.trim(), icon);
                p2.sendMessage(plugin.getMessages().get("category-created").replace("%category%", titleInput.trim()));
                MenuBuilder.openEditMainMenu(p2, plugin);
            });
        });
    }

    // ================= MENU EDITOR: item dalam kategori =================

    private void handleEditCategoryClick(Player player, ShopEditCategoryHolder h, int slot, ClickType click) {
        if (!player.hasPermission("sanzshop.edit")) return;

        if (slot == MenuBuilder.SLOT_BACK) {
            MenuBuilder.openEditMainMenu(player, plugin);
            return;
        }
        if (slot == MenuBuilder.SLOT_PREV) {
            MenuBuilder.openEditCategoryMenu(player, plugin, h.getCategoryKey(), h.getPage() - 1);
            return;
        }
        if (slot == MenuBuilder.SLOT_NEXT) {
            MenuBuilder.openEditCategoryMenu(player, plugin, h.getCategoryKey(), h.getPage() + 1);
            return;
        }
        if (slot == MenuBuilder.SLOT_ADD) {
            startAddItemFlow(player, h.getCategoryKey(), h.getPage());
            return;
        }
        if (slot == MenuBuilder.SLOT_RENAME_CATEGORY) {
            ShopCategory cat = plugin.getShopManager().getCategory(h.getCategoryKey());
            if (cat == null) return;
            if (click == ClickType.SHIFT_LEFT || click == ClickType.SHIFT_RIGHT) {
                ItemStack hand = player.getInventory().getItemInMainHand();
                if (hand == null || hand.getType() == Material.AIR) {
                    player.sendMessage("§cGenggam sebuah item terlebih dahulu untuk dijadikan ikon kategori.");
                } else {
                    cat.setIcon(hand.getType());
                    plugin.getShopManager().save();
                    player.sendMessage("§aIkon kategori berhasil diperbarui menjadi §f" + hand.getType().name() + "§a.");
                }
                MenuBuilder.openEditCategoryMenu(player, plugin, h.getCategoryKey(), h.getPage());
            } else {
                plugin.getChatInputManager().request(player, "§e➤ Masukkan judul baru untuk kategori §f" + cat.getTitle() + "§e:", (p, input) -> {
                    cat.setTitle(input.trim());
                    plugin.getShopManager().save();
                    p.sendMessage("§aJudul kategori berhasil diperbarui.");
                    MenuBuilder.openEditCategoryMenu(p, plugin, h.getCategoryKey(), h.getPage());
                });
            }
            return;
        }
        if (slot < 0 || slot >= MenuBuilder.PAGE_SIZE) return;

        ShopCategory cat = plugin.getShopManager().getCategory(h.getCategoryKey());
        if (cat == null) return;
        int index = h.getPage() * MenuBuilder.PAGE_SIZE + slot;
        if (index < 0 || index >= cat.getItems().size()) return;

        if (click == ClickType.SHIFT_LEFT) {
            handleItemMoveClick(player, h, index);
            return;
        }
        if (click == ClickType.SHIFT_RIGHT) {
            ShopItem removed = cat.getItems().get(index);
            plugin.getShopManager().removeItem(h.getCategoryKey(), index);
            player.sendMessage(plugin.getMessages().get("item-removed")
                    .replace("%item%", removed.getDisplayName())
                    .replace("%category%", cat.getTitle()));
            MenuBuilder.openEditCategoryMenu(player, plugin, h.getCategoryKey(), h.getPage());
        } else {
            MenuBuilder.openEditItemMenu(player, plugin, h.getCategoryKey(), index, h.getPage());
        }
    }

    /**
     * Sama pola dengan handleCategoryMoveClick, tapi buat item di dalam SATU
     * kategori yang sama. Boleh beda halaman (index yang disimpan itu absolut,
     * bukan slot per-halaman) -- klik pertama di halaman 1, klik kedua di
     * halaman 2, tetep kesambung, tuker urutannya dalam List<ShopItem>.
     */
    private void handleItemMoveClick(Player player, ShopEditCategoryHolder h, int index) {
        PendingMove pending = pendingMoves.get(player.getUniqueId());
        if (pending != null && !pending.isCategoryMove() && pending.categoryKey().equals(h.getCategoryKey())) {
            if (pending.itemIndex() == index) {
                pendingMoves.remove(player.getUniqueId());
                player.sendMessage("§7Pemindahan slot item dibatalkan.");
            } else {
                plugin.getShopManager().swapItemOrder(h.getCategoryKey(), pending.itemIndex(), index);
                pendingMoves.remove(player.getUniqueId());
                player.sendMessage("§aPosisi slot item berhasil ditukar.");
            }
            MenuBuilder.openEditCategoryMenu(player, plugin, h.getCategoryKey(), h.getPage());
            return;
        }
        pendingMoves.put(player.getUniqueId(), new PendingMove(h.getCategoryKey(), index));
        player.sendMessage("§eItem dipilih untuk dipindah — Shift+Klik Kiri item/slot lain (boleh beda halaman) buat tuker slot (Shift+Klik Kiri lagi di sini buat batal).");
    }

    private void startAddItemFlow(Player player, String categoryKey, int returnPage) {
        plugin.getChatInputManager().request(player, "§e➤ Masukkan ID material untuk item baru §7(contoh: §fDIAMOND_SWORD§7):", (p, matInput) -> {
            Material mat = Material.matchMaterial(matInput.trim().toUpperCase(Locale.ROOT));
            if (mat == null) {
                p.sendMessage(plugin.getMessages().get("invalid-material"));
                MenuBuilder.openEditCategoryMenu(p, plugin, categoryKey, returnPage);
                return;
            }
            plugin.getChatInputManager().request(p, "§e➤ Masukkan harga beli §7(angka — isi §f0 §7jika item tidak dijual):", (p2, buyInput) -> {
                Double buy = parseDoubleSafe(buyInput);
                if (buy == null) {
                    p2.sendMessage(plugin.getMessages().get("invalid-number"));
                    MenuBuilder.openEditCategoryMenu(p2, plugin, categoryKey, returnPage);
                    return;
                }
                plugin.getChatInputManager().request(p2, "§e➤ Masukkan harga jual §7(angka — isi §f0 §7jika item tidak diterima):", (p3, sellInput) -> {
                    Double sell = parseDoubleSafe(sellInput);
                    if (sell == null) {
                        p3.sendMessage(plugin.getMessages().get("invalid-number"));
                        MenuBuilder.openEditCategoryMenu(p3, plugin, categoryKey, returnPage);
                        return;
                    }
                    String prettyName = prettyName(mat);
                    ShopItem created = plugin.getShopManager().addItem(categoryKey, mat, prettyName, 1, buy, sell);
                    if (created != null) {
                        ShopCategory targetCat = plugin.getShopManager().getCategory(categoryKey);
                        String catTitle = targetCat != null ? targetCat.getTitle() : categoryKey;
                        p3.sendMessage(plugin.getMessages().get("item-added")
                                .replace("%item%", prettyName)
                                .replace("%category%", catTitle));
                    }
                    MenuBuilder.openEditCategoryMenu(p3, plugin, categoryKey, returnPage);
                });
            });
        });
    }

    // ================= MENU EDITOR: satu item =================

    private void handleEditItemClick(Player player, ShopEditItemHolder h, int slot) {
        if (!player.hasPermission("sanzshop.edit")) return;

        ShopManager manager = plugin.getShopManager();
        ShopCategory cat = manager.getCategory(h.getCategoryKey());
        if (cat == null || h.getItemIndex() >= cat.getItems().size()) {
            player.closeInventory();
            return;
        }
        ShopItem item = cat.getItems().get(h.getItemIndex());

        switch (slot) {
            case 10 -> plugin.getChatInputManager().request(player, "§e➤ Masukkan nama tampilan baru untuk item ini:", (p, input) -> {
                item.setDisplayName(input.trim());
                manager.save();
                p.sendMessage(plugin.getMessages().get("item-updated").replace("%item%", item.getDisplayName()));
                MenuBuilder.openEditItemMenu(p, plugin, h.getCategoryKey(), h.getItemIndex(), h.getReturnPage());
            });
            case 11 -> plugin.getChatInputManager().request(player, "§e➤ Masukkan ID material baru §7(contoh: §fNETHERITE_INGOT§7):", (p, input) -> {
                Material mat = Material.matchMaterial(input.trim().toUpperCase(Locale.ROOT));
                if (mat == null) {
                    p.sendMessage(plugin.getMessages().get("invalid-material"));
                } else {
                    item.setMaterial(mat);
                    manager.save();
                    p.sendMessage(plugin.getMessages().get("item-updated").replace("%item%", item.getDisplayName()));
                }
                MenuBuilder.openEditItemMenu(p, plugin, h.getCategoryKey(), h.getItemIndex(), h.getReturnPage());
            });
            case 15 -> plugin.getChatInputManager().request(player, "§e➤ Masukkan harga beli baru §7(angka — §f0 §7= nonaktif):", (p, input) -> {
                Double v = parseDoubleSafe(input);
                if (v == null) {
                    p.sendMessage(plugin.getMessages().get("invalid-number"));
                } else {
                    item.setBuyPrice(v);
                    manager.save();
                    p.sendMessage(plugin.getMessages().get("item-updated").replace("%item%", item.getDisplayName()));
                }
                MenuBuilder.openEditItemMenu(p, plugin, h.getCategoryKey(), h.getItemIndex(), h.getReturnPage());
            });
            case 16 -> plugin.getChatInputManager().request(player, "§e➤ Masukkan harga jual baru §7(angka — §f0 §7= nonaktif):", (p, input) -> {
                Double v = parseDoubleSafe(input);
                if (v == null) {
                    p.sendMessage(plugin.getMessages().get("invalid-number"));
                } else {
                    item.setSellPrice(v);
                    manager.save();
                    p.sendMessage(plugin.getMessages().get("item-updated").replace("%item%", item.getDisplayName()));
                }
                MenuBuilder.openEditItemMenu(p, plugin, h.getCategoryKey(), h.getItemIndex(), h.getReturnPage());
            });
            case 20 -> plugin.getChatInputManager().request(player, "§e➤ Masukkan jumlah item per transaksi §7(angka bulat, minimal 1):", (p, input) -> {
                Integer v = parseIntSafe(input);
                if (v == null || v < 1) {
                    p.sendMessage(plugin.getMessages().get("invalid-number"));
                } else {
                    item.setAmount(v);
                    manager.save();
                    p.sendMessage(plugin.getMessages().get("item-updated").replace("%item%", item.getDisplayName()));
                }
                MenuBuilder.openEditItemMenu(p, plugin, h.getCategoryKey(), h.getItemIndex(), h.getReturnPage());
            });
            case 22 -> {
                manager.removeItem(h.getCategoryKey(), h.getItemIndex());
                player.sendMessage(plugin.getMessages().get("item-removed")
                        .replace("%item%", item.getDisplayName())
                        .replace("%category%", cat.getTitle()));
                MenuBuilder.openEditCategoryMenu(player, plugin, h.getCategoryKey(), h.getReturnPage());
            }
            case 24 -> MenuBuilder.openEditCategoryMenu(player, plugin, h.getCategoryKey(), h.getReturnPage());
            default -> { /* slot dekorasi, tidak ada aksi */ }
        }
    }

    // ================= CHAT INPUT =================

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        Player player = e.getPlayer();
        if (!plugin.getChatInputManager().isWaiting(player)) return;

        e.setCancelled(true);
        String message = PlainTextComponentSerializer.plainText().serialize(e.message());
        plugin.getChatInputManager().handleChat(player, message);
    }

    // ================= util =================

    private Double parseDoubleSafe(String s) {
        try {
            double v = Double.parseDouble(s.trim().replace(",", "."));
            return v < 0 ? null : v;
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private Integer parseIntSafe(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private String prettyName(Material m) {
        String[] parts = m.name().split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1).toLowerCase()).append(' ');
        }
        return sb.toString().trim();
    }
}
