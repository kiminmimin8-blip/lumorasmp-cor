package xyz.sanz.shop.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import xyz.sanz.shop.SanzShop;
import xyz.sanz.shop.gui.MenuBuilder;
import xyz.sanz.shop.service.RefundManager;

import java.util.HashMap;
import java.util.Map;

/**
 * /sellrefund -- buka GUI daftar penjualan yang masih dalam jendela refund (default 3 menit).
 * Klik salah satu entri buat batalin penjualannya: barang asli balik ke inventory,
 * uang hasil jualnya ditarik lagi dari saldo.
 */
public class SellRefundCommand implements CommandExecutor {

    private final SanzShop plugin;

    public SellRefundCommand(SanzShop plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (!player.hasPermission("sanzshop.use")) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return true;
        }

        RefundManager refunds = plugin.getRefundManager();
        Map<String, String> ph = new HashMap<>();
        ph.put("%window%", refunds.windowText());

        if (!refunds.isEnabled()) {
            plugin.getMessages().send(player, "refund-disabled", ph);
            return true;
        }
        if (refunds.active(player.getUniqueId()).isEmpty()) {
            plugin.getMessages().send(player, "refund-empty", ph);
            return true;
        }
        MenuBuilder.openRefundMenu(player, plugin);
        return true;
    }
}
