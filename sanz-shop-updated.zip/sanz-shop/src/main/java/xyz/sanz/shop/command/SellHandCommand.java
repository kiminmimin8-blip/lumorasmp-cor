package xyz.sanz.shop.command;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import xyz.sanz.shop.SanzShop;
import xyz.sanz.shop.ShopManager;
import xyz.sanz.shop.model.ShopItem;
import xyz.sanz.shop.service.ShopService;
import xyz.sanz.shop.util.InventoryUtils;

import java.util.Comparator;
import java.util.List;

/**
 * /sellhand -- jual SEMUA stok material yang lagi dipegang di tangan utama
 * (dihitung dari seluruh inventory, bukan cuma slot tangan, konsisten sama
 * cara ShopService#sell yang sudah ada -- klik jual di GUI juga ngambil dari
 * seluruh inventory, bukan cuma 1 slot). QoL command biar gak perlu buka GUI
 * & nyari kategori manual buat jual cepat.
 *
 * Kalau material yang dipegang kebetulan terdaftar di lebih dari 1 kategori
 * dengan harga beda (lihat catatan duplikat di ShopManager), otomatis pilih
 * harga jual yang PALING TINGGI -- paling menguntungkan buat player, dan
 * gak perlu nanya-nanya kategori mana yang dimaksud.
 */
public class SellHandCommand implements CommandExecutor {

    private final SanzShop plugin;

    public SellHandCommand(SanzShop plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (!player.hasPermission("sanzshop.use")) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return true;
        }

        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand.getType() == Material.AIR) {
            player.sendMessage(plugin.getMessages().prefix() + "§cGak ada item di tangan kamu.");
            return true;
        }

        List<ShopManager.ItemMatch> matches = plugin.getShopManager().findItemAcrossCategories(hand.getType().name());
        List<ShopManager.ItemMatch> sellable = matches.stream().filter(m -> m.item().isSellable()).toList();
        if (sellable.isEmpty()) {
            player.sendMessage(plugin.getMessages().get("cannot-sell"));
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
            return true;
        }

        ShopManager.ItemMatch best = sellable.stream()
                .max(Comparator.comparingDouble(m -> m.item().getSellPrice()))
                .orElseThrow();
        ShopItem item = best.item();

        int owned = InventoryUtils.countMaterial(player.getInventory(), item.getMaterial());
        int qty = owned / item.getAmount();
        if (qty <= 0) {
            player.sendMessage(plugin.getMessages().get("no-items-to-sell"));
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
            return true;
        }

        ShopService.Result result = plugin.getShopService().sell(player, item, qty);
        if (result != ShopService.Result.SUCCESS) {
            switch (result) {
                case NOT_ENOUGH_ITEMS -> player.sendMessage(plugin.getMessages().get("no-items-to-sell"));
                case NOT_SELLABLE -> player.sendMessage(plugin.getMessages().get("cannot-sell"));
                case NO_ECONOMY -> player.sendMessage(plugin.getMessages().get("economy-missing"));
                default -> { /* gak mungkin kejadian buat qty>0 selain kasus di atas */ }
            }
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
        }
        return true;
    }
}
