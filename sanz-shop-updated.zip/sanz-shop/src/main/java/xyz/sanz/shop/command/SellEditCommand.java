package xyz.sanz.shop.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import xyz.sanz.shop.SanzShop;
import xyz.sanz.shop.ShopManager;
import xyz.sanz.shop.gui.MenuBuilder;
import xyz.sanz.shop.model.ShopCategory;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /selledit <material> <harga>                 -> ubah harga jual, auto-cari
 *                                                 di semua kategori. Kalau
 *                                                 material yang sama ada di
 *                                                 >1 kategori (lihat catatan
 *                                                 duplikat QUARTZ_BLOCK/SPONGE
 *                                                 dkk di ShopManager), harus
 *                                                 pakai bentuk kedua di bawah.
 * /selledit <kategori> <material> <harga>      -> ubah harga jual di kategori spesifik.
 *
 * Cuma ubah harga JUAL (sellPrice) -- harga beli tetap lewat /shopedit setprice.
 * Perlu izin sanzshop.edit (sama kayak /shopedit).
 */
public class SellEditCommand implements CommandExecutor, TabCompleter {

    private final SanzShop plugin;

    public SellEditCommand(SanzShop plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("sanzshop.edit")) {
            sender.sendMessage(plugin.getMessages().get("no-permission"));
            return true;
        }

        if (args.length == 2) {
            return editAutoDetect(sender, args[0], args[1]);
        }
        if (args.length == 3) {
            return editWithCategory(sender, args[0], args[1], args[2]);
        }

        sender.sendMessage("§cPakai: /selledit <material> <harga_baru>");
        sender.sendMessage("§cAtau, kalau material-nya ada di >1 kategori: /selledit <kategori> <material> <harga_baru>");
        return true;
    }

    private boolean editAutoDetect(CommandSender sender, String materialArg, String priceArg) {
        Double price = parsePrice(sender, priceArg);
        if (price == null) return true;

        List<ShopManager.ItemMatch> matches = plugin.getShopManager().findItemAcrossCategories(materialArg);
        if (matches.isEmpty()) {
            sender.sendMessage("§cMaterial '" + materialArg.toUpperCase() + "' gak ketemu di kategori manapun.");
            return true;
        }
        if (matches.size() > 1) {
            sender.sendMessage("§eMaterial '" + materialArg.toUpperCase() + "' ada di " + matches.size() + " kategori, sebutin salah satu:");
            for (ShopManager.ItemMatch m : matches) {
                sender.sendMessage("§7 - §f/selledit " + m.categoryKey() + " " + materialArg + " " + priceArg
                        + " §8(sekarang: " + MenuBuilder.fmt(m.item().getSellPrice()) + " Coin di " + m.categoryTitle() + ")");
            }
            return true;
        }

        ShopManager.ItemMatch match = matches.get(0);
        applyEdit(sender, match.categoryKey(), match.categoryTitle(), materialArg, price);
        return true;
    }

    private boolean editWithCategory(CommandSender sender, String categoryArg, String materialArg, String priceArg) {
        Double price = parsePrice(sender, priceArg);
        if (price == null) return true;

        ShopCategory cat = plugin.getShopManager().getCategory(categoryArg.toLowerCase());
        if (cat == null) {
            sender.sendMessage("§cKategori '" + categoryArg + "' gak ketemu.");
            return true;
        }
        applyEdit(sender, cat.getKey(), cat.getTitle(), materialArg, price);
        return true;
    }

    private void applyEdit(CommandSender sender, String categoryKey, String categoryTitle, String materialArg, double price) {
        boolean ok = plugin.getShopManager().setItemSellPrice(categoryKey, materialArg, price);
        if (!ok) {
            sender.sendMessage("§cMaterial '" + materialArg.toUpperCase() + "' gak ketemu di kategori '" + categoryTitle + "'.");
            return;
        }
        sender.sendMessage("§aHarga jual " + materialArg.toUpperCase() + " di " + categoryTitle
                + " diubah jadi §f" + MenuBuilder.fmt(price) + " Coin§a.");
    }

    private Double parsePrice(CommandSender sender, String raw) {
        try {
            double v = Double.parseDouble(raw);
            if (v < 0) {
                sender.sendMessage("§cHarga gak boleh negatif. Pakai 0 kalau mau item-nya jadi gak bisa dijual.");
                return null;
            }
            return v;
        } catch (NumberFormatException e) {
            sender.sendMessage("§c'" + raw + "' bukan angka yang valid.");
            return null;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> cats = plugin.getShopManager().getCategories().keySet().stream()
                    .filter(k -> k.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
            List<String> mats = new ArrayList<>();
            for (ShopCategory cat : plugin.getShopManager().getCategoryList()) {
                for (var item : cat.getItems()) {
                    String name = item.getMaterial().name();
                    if (name.startsWith(args[0].toUpperCase()) && !mats.contains(name)) {
                        mats.add(name);
                    }
                }
            }
            List<String> combined = new ArrayList<>(cats);
            combined.addAll(mats);
            return combined;
        }
        if (args.length == 2) {
            ShopCategory cat = plugin.getShopManager().getCategory(args[0].toLowerCase());
            if (cat != null) {
                return cat.getItems().stream()
                        .map(i -> i.getMaterial().name())
                        .distinct()
                        .filter(n -> n.startsWith(args[1].toUpperCase()))
                        .collect(Collectors.toList());
            }
        }
        return List.of();
    }
}
