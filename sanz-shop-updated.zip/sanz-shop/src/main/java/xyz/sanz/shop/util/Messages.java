package xyz.sanz.shop.util;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import xyz.sanz.shop.SanzShop;

import java.util.Map;

/**
 * Helper baca pesan dari config.yml (section "messages") + translate warna & placeholder.
 */
public final class Messages {

    private final SanzShop plugin;

    public Messages(SanzShop plugin) {
        this.plugin = plugin;
    }

    private String raw(String key) {
        // getString(path) 1-arg -> kalau key gak ada di config.yml server (config lama yang gak
        // ikut ke-update), otomatis jatuh ke default bawaan config.yml di dalam jar, bukan ke `key`.
        String s = plugin.getConfig().getString("messages." + key);
        return s == null ? key : s;
    }

    public String prefix() {
        return color(raw("prefix"));
    }

    public String get(String key) {
        return color(prefix() + raw(key));
    }

    public String get(String key, Map<String, String> placeholders) {
        String msg = get(key);
        for (Map.Entry<String, String> e : placeholders.entrySet()) {
            msg = msg.replace(e.getKey(), e.getValue());
        }
        return msg;
    }

    public void send(CommandSender to, String key) {
        to.sendMessage(get(key));
    }

    public void send(CommandSender to, String key, Map<String, String> placeholders) {
        to.sendMessage(get(key, placeholders));
    }

    public static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}
