package com.sanz.duel.listener;

import com.sanz.duel.SanzDuel;
import com.sanz.duel.manager.DuelManager;
import com.sanz.duel.model.ActiveDuel;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.UUID;

public class DuelListener implements Listener {

    private final SanzDuel plugin;
    private final DuelManager duelManager;

    public DuelListener(SanzDuel plugin, DuelManager duelManager) {
        this.plugin = plugin;
        this.duelManager = duelManager;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        ActiveDuel duel = duelManager.getActiveDuel(victim.getUniqueId());
        if (duel == null) return;

        // Player yang lagi duel gak drop item / lose XP pas mati di dalem match; inventory-nya
        // dibalikin manual sama PlayerSnapshot pas endDuel jalan.
        event.getDrops().clear();
        event.setDroppedExp(0);
        event.deathMessage(null);

        UUID winner = duel.getOpponent(victim.getUniqueId());

        // Respawn player secepatnya biar snapshot restore-nya jalan mulus (perlu instance Player yang valid).
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            victim.spigot().respawn();
            duelManager.endDuel(duel, winner);
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        ActiveDuel duel = duelManager.getActiveDuel(player.getUniqueId());
        if (duel == null) return;

        UUID winner = duel.getOpponent(player.getUniqueId());
        Player opponent = plugin.getServer().getPlayer(winner);
        if (opponent != null) {
            opponent.sendMessage(Component.text("Lawan lu disconnect, lu menang duel!", NamedTextColor.GOLD));
        }
        duelManager.endDuel(duel, winner);
    }

    /** Cegah player yang gak lagi duel damage player lain yang lagi duel di arena, dan sebaliknya. */
    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        if (!(event.getDamager() instanceof Player damager)) return;

        boolean victimInDuel = duelManager.isInDuel(victim.getUniqueId());
        boolean damagerInDuel = duelManager.isInDuel(damager.getUniqueId());

        if (victimInDuel != damagerInDuel) {
            // Salah satu lagi duel, satunya bukan -> cegah damage lintas konteks.
            event.setCancelled(true);
            return;
        }

        if (victimInDuel) {
            ActiveDuel victimDuel = duelManager.getActiveDuel(victim.getUniqueId());
            ActiveDuel damagerDuel = duelManager.getActiveDuel(damager.getUniqueId());
            if (victimDuel != damagerDuel) {
                // Keduanya lagi duel tapi beda match -> tetep cegah friendly-fire silang arena.
                event.setCancelled(true);
            }
        }
    }
}
