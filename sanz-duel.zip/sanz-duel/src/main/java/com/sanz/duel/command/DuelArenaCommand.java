package com.sanz.duel.command;

import com.sanz.duel.SanzDuel;
import com.sanz.duel.manager.ArenaManager;
import com.sanz.duel.model.Arena;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DuelArenaCommand implements CommandExecutor, TabCompleter {

    private final SanzDuel plugin;
    private final ArenaManager arenaManager;

    public DuelArenaCommand(SanzDuel plugin, ArenaManager arenaManager) {
        this.plugin = plugin;
        this.arenaManager = arenaManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }

        if (args.length < 1) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "create" -> handleCreate(player, args);
            case "pos1" -> handlePos1(player);
            case "pos2" -> handlePos2(player);
            case "setspawn1" -> handleSetSpawn1(player);
            case "setspawn2" -> handleSetSpawn2(player);
            case "save" -> handleSave(player);
            case "list" -> handleList(player);
            case "delete" -> handleDelete(player, args);
            default -> sendHelp(player);
        }
        return true;
    }

    private void sendHelp(Player player) {
        player.sendMessage(Component.text("=== SanzDuel Arena Setup ===", NamedTextColor.GOLD));
        player.sendMessage(Component.text("/duelarena create <nama>", NamedTextColor.YELLOW));
        player.sendMessage(Component.text("/duelarena pos1  - set titik sudut 1 (posisi kamu sekarang)", NamedTextColor.YELLOW));
        player.sendMessage(Component.text("/duelarena pos2  - set titik sudut 2 (posisi kamu sekarang)", NamedTextColor.YELLOW));
        player.sendMessage(Component.text("/duelarena setspawn1 - set titik spawn player 1", NamedTextColor.YELLOW));
        player.sendMessage(Component.text("/duelarena setspawn2 - set titik spawn player 2", NamedTextColor.YELLOW));
        player.sendMessage(Component.text("/duelarena save  - simpen arena + ambil snapshot block", NamedTextColor.YELLOW));
        player.sendMessage(Component.text("/duelarena list", NamedTextColor.YELLOW));
        player.sendMessage(Component.text("/duelarena delete <nama>", NamedTextColor.YELLOW));
    }

    private void handleCreate(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(Component.text("Pakai: /duelarena create <nama>", NamedTextColor.RED));
            return;
        }
        String name = args[1];
        if (arenaManager.getArena(name) != null) {
            player.sendMessage(Component.text("Arena '" + name + "' udah ada.", NamedTextColor.RED));
            return;
        }

        SanzDuel.PendingArenaSetup setup = new SanzDuel.PendingArenaSetup();
        setup.name = name;
        plugin.getPendingSetups().put(player.getUniqueId(), setup);

        player.sendMessage(Component.text("Mulai setup arena '" + name + "'. Sekarang jalanin /duelarena pos1 dan /duelarena pos2 buat nentuin area, terus setspawn1/setspawn2, lalu /duelarena save.", NamedTextColor.GREEN));
    }

    private void handlePos1(Player player) {
        SanzDuel.PendingArenaSetup setup = plugin.getPendingSetups().get(player.getUniqueId());
        if (setup == null) {
            player.sendMessage(Component.text("Jalanin /duelarena create <nama> dulu.", NamedTextColor.RED));
            return;
        }
        setup.pos1 = player.getLocation().clone();
        player.sendMessage(Component.text("Pos1 di-set ke " + fmt(setup.pos1), NamedTextColor.GREEN));
    }

    private void handlePos2(Player player) {
        SanzDuel.PendingArenaSetup setup = plugin.getPendingSetups().get(player.getUniqueId());
        if (setup == null) {
            player.sendMessage(Component.text("Jalanin /duelarena create <nama> dulu.", NamedTextColor.RED));
            return;
        }
        setup.pos2 = player.getLocation().clone();
        player.sendMessage(Component.text("Pos2 di-set ke " + fmt(setup.pos2), NamedTextColor.GREEN));
    }

    // Spawn point disimpen langsung di config sementara pending, pake trik simpen di map terpisah lewat metadata sementara.
    private final java.util.Map<java.util.UUID, Location> pendingSpawn1 = new java.util.HashMap<>();
    private final java.util.Map<java.util.UUID, Location> pendingSpawn2 = new java.util.HashMap<>();

    private void handleSetSpawn1(Player player) {
        if (!plugin.getPendingSetups().containsKey(player.getUniqueId())) {
            player.sendMessage(Component.text("Jalanin /duelarena create <nama> dulu.", NamedTextColor.RED));
            return;
        }
        pendingSpawn1.put(player.getUniqueId(), player.getLocation().clone());
        player.sendMessage(Component.text("Spawn 1 di-set.", NamedTextColor.GREEN));
    }

    private void handleSetSpawn2(Player player) {
        if (!plugin.getPendingSetups().containsKey(player.getUniqueId())) {
            player.sendMessage(Component.text("Jalanin /duelarena create <nama> dulu.", NamedTextColor.RED));
            return;
        }
        pendingSpawn2.put(player.getUniqueId(), player.getLocation().clone());
        player.sendMessage(Component.text("Spawn 2 di-set.", NamedTextColor.GREEN));
    }

    private void handleSave(Player player) {
        SanzDuel.PendingArenaSetup setup = plugin.getPendingSetups().get(player.getUniqueId());
        if (setup == null) {
            player.sendMessage(Component.text("Jalanin /duelarena create <nama> dulu.", NamedTextColor.RED));
            return;
        }
        if (setup.pos1 == null || setup.pos2 == null) {
            player.sendMessage(Component.text("Set pos1 dan pos2 dulu sebelum save.", NamedTextColor.RED));
            return;
        }
        Location spawn1 = pendingSpawn1.get(player.getUniqueId());
        Location spawn2 = pendingSpawn2.get(player.getUniqueId());
        if (spawn1 == null || spawn2 == null) {
            player.sendMessage(Component.text("Set setspawn1 dan setspawn2 dulu sebelum save.", NamedTextColor.RED));
            return;
        }

        int minX = Math.min(setup.pos1.getBlockX(), setup.pos2.getBlockX());
        int minY = Math.min(setup.pos1.getBlockY(), setup.pos2.getBlockY());
        int minZ = Math.min(setup.pos1.getBlockZ(), setup.pos2.getBlockZ());
        int maxX = Math.max(setup.pos1.getBlockX(), setup.pos2.getBlockX());
        int maxY = Math.max(setup.pos1.getBlockY(), setup.pos2.getBlockY());
        int maxZ = Math.max(setup.pos1.getBlockZ(), setup.pos2.getBlockZ());

        Arena arena = new Arena(setup.name, setup.pos1.getWorld(), minX, minY, minZ, maxX, maxY, maxZ, spawn1, spawn2);
        long volume = arena.volume();

        player.sendMessage(Component.text("Ngambil snapshot " + volume + " block, mohon tunggu...", NamedTextColor.GRAY));

        try {
            arenaManager.takeSnapshot(arena);
            arenaManager.addArena(arena);
            arenaManager.save();
            plugin.getPendingSetups().remove(player.getUniqueId());
            pendingSpawn1.remove(player.getUniqueId());
            pendingSpawn2.remove(player.getUniqueId());
            player.sendMessage(Component.text("Arena '" + setup.name + "' berhasil disimpen (" + volume + " block).", NamedTextColor.GREEN));
        } catch (IOException e) {
            player.sendMessage(Component.text("Gagal nyimpen snapshot: " + e.getMessage(), NamedTextColor.RED));
            plugin.getLogger().severe("Gagal nyimpen snapshot arena '" + setup.name + "': " + e.getMessage());
        }
    }

    private void handleList(Player player) {
        if (arenaManager.getArenas().isEmpty()) {
            player.sendMessage(Component.text("Belum ada arena duel.", NamedTextColor.GRAY));
            return;
        }
        player.sendMessage(Component.text("=== Arena Duel ===", NamedTextColor.GOLD));
        for (Arena arena : arenaManager.getArenas()) {
            player.sendMessage(Component.text("- " + arena.getName() + " (" + arena.getState() + ", " + arena.volume() + " block)", NamedTextColor.YELLOW));
        }
    }

    private void handleDelete(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(Component.text("Pakai: /duelarena delete <nama>", NamedTextColor.RED));
            return;
        }
        Arena arena = arenaManager.getArena(args[1]);
        if (arena == null) {
            player.sendMessage(Component.text("Arena '" + args[1] + "' gak ketemu.", NamedTextColor.RED));
            return;
        }
        arenaManager.removeArena(args[1]);
        arenaManager.save();
        player.sendMessage(Component.text("Arena '" + args[1] + "' dihapus.", NamedTextColor.GREEN));
    }

    private String fmt(Location loc) {
        return loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ();
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> subcommands = List.of("create", "pos1", "pos2", "setspawn1", "setspawn2", "save", "list", "delete");
            String prefix = args[0].toLowerCase();
            return subcommands.stream()
                    .filter(s -> s.startsWith(prefix))
                    .collect(Collectors.toList());
        }

        // Argumen kedua cuma relevan buat "delete <nama_arena>" -> kasih daftar nama arena yang ada.
        if (args.length == 2 && args[0].equalsIgnoreCase("delete")) {
            String prefix = args[1].toLowerCase();
            return arenaManager.getArenas().stream()
                    .map(a -> a.getName())
                    .filter(name -> name.toLowerCase().startsWith(prefix))
                    .collect(Collectors.toList());
        }

        return new ArrayList<>();
    }
}
