package com.sanz.duel.model;

import java.util.UUID;

public class DuelRequest {

    private final UUID challenger;
    private final UUID target;
    private final long expiresAt;

    public DuelRequest(UUID challenger, UUID target, long expiresAtMillis) {
        this.challenger = challenger;
        this.target = target;
        this.expiresAt = expiresAtMillis;
    }

    public UUID getChallenger() {
        return challenger;
    }

    public UUID getTarget() {
        return target;
    }

    public boolean isExpired() {
        return System.currentTimeMillis() > expiresAt;
    }
}
