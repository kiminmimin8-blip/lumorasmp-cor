package com.sanz.duel.model;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/** Simpen kondisi player sebelum duel (inventory, health, lokasi, dll) biar bisa dibalikin abis selesai. */
public class PlayerSnapshot {

    private final ItemStack[] inventoryContents;
    private final ItemStack[] armorContents;
    private final ItemStack offHand;
    private final double health;
    private final int foodLevel;
    private final float saturation;
    private final int totalExperience;
    private final float exp;
    private final int level;
    private final GameMode gameMode;
    private final Location returnLocation;
    private final List<PotionEffect> potionEffects;

    public PlayerSnapshot(Player player) {
        this.inventoryContents = player.getInventory().getContents().clone();
        this.armorContents = player.getInventory().getArmorContents().clone();
        this.offHand = player.getInventory().getItemInOffHand().clone();
        this.health = player.getHealth();
        this.foodLevel = player.getFoodLevel();
        this.saturation = player.getSaturation();
        this.totalExperience = player.getTotalExperience();
        this.exp = player.getExp();
        this.level = player.getLevel();
        this.gameMode = player.getGameMode();
        this.returnLocation = player.getLocation().clone();
        this.potionEffects = new ArrayList<>(player.getActivePotionEffects());
    }

    public void restore(Player player) {
        player.getInventory().setContents(inventoryContents);
        player.getInventory().setArmorContents(armorContents);
        player.getInventory().setItemInOffHand(offHand);

        Collection<PotionEffect> current = player.getActivePotionEffects();
        for (PotionEffect effect : current) {
            player.removePotionEffect(effect.getType());
        }
        for (PotionEffect effect : potionEffects) {
            player.addPotionEffect(effect);
        }

        double maxHealth = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH) != null
                ? player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue() : 20.0;
        player.setHealth(Math.min(health, maxHealth));
        player.setFoodLevel(foodLevel);
        player.setSaturation(saturation);
        player.setTotalExperience(totalExperience);
        player.setExp(exp);
        player.setLevel(level);
        player.setGameMode(gameMode);
        player.teleport(returnLocation);
    }

    public Location getReturnLocation() {
        return returnLocation;
    }
}
