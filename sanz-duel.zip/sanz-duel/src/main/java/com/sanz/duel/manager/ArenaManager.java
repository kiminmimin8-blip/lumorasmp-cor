package com.sanz.duel.manager;

import com.sanz.duel.SanzDuel;
import com.sanz.duel.model.Arena;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.*;
import java.util.*;

public class ArenaManager {

    private final SanzDuel plugin;
    private final Map<String, Arena> arenas = new HashMap<>();
    private final File arenasFile;
    private final File snapshotFolder;

    public ArenaManager(SanzDuel plugin) {
        this.plugin = plugin;
        this.arenasFile = new File(plugin.getDataFolder(), "arenas.yml");
        this.snapshotFolder = new File(plugin.getDataFolder(), "snapshots");
        if (!snapshotFolder.exists()) snapshotFolder.mkdirs();
        load();
    }

    public Collection<Arena> getArenas() {
        return arenas.values();
    }

    public Arena getArena(String name) {
        return arenas.get(name.toLowerCase());
    }

    public void addArena(Arena arena) {
        arenas.put(arena.getName().toLowerCase(), arena);
    }

    public void removeArena(String name) {
        arenas.remove(name.toLowerCase());
        getSnapshotFile(name).delete();
    }

    /** Cari arena yang lagi kosong (gak dipake duel & gak lagi di-reset). */
    public Arena findFreeArena() {
        for (Arena arena : arenas.values()) {
            if (arena.isReady() && arena.getState() == Arena.State.AVAILABLE) {
                return arena;
            }
        }
        return null;
    }

    private File getSnapshotFile(String arenaName) {
        return new File(snapshotFolder, arenaName.toLowerCase() + ".snapshot");
    }

    /**
     * Ambil snapshot semua block di dalem area arena, simpen ke file.
     * Dipanggil sekali pas admin bikin/save arena.
     */
    public void takeSnapshot(Arena arena) throws IOException {
        World world = arena.getWorld();
        File file = getSnapshotFile(arena.getName());

        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            out.writeInt(arena.sizeX());
            out.writeInt(arena.sizeY());
            out.writeInt(arena.sizeZ());

            for (int x = arena.getMinX(); x <= arena.getMaxX(); x++) {
                for (int y = arena.getMinY(); y <= arena.getMaxY(); y++) {
                    for (int z = arena.getMinZ(); z <= arena.getMaxZ(); z++) {
                        BlockData data = world.getBlockAt(x, y, z).getBlockData();
                        out.writeUTF(data.getAsString());
                    }
                }
            }
        }
    }

    public boolean hasSnapshot(Arena arena) {
        return getSnapshotFile(arena.getName()).exists();
    }

    /**
     * Balikin arena ke kondisi snapshot awal. Dicicil per-tick (bukan sekaligus) biar gak bikin TPS drop.
     * onComplete dipanggil di main thread pas restore selesai.
     */
    public void restoreArena(Arena arena, Runnable onComplete) {
        File file = getSnapshotFile(arena.getName());
        if (!file.exists()) {
            plugin.getLogger().warning("Gak ada snapshot buat arena '" + arena.getName() + "', skip reset.");
            arena.setState(Arena.State.AVAILABLE);
            if (onComplete != null) onComplete.run();
            return;
        }

        arena.setState(Arena.State.RESETTING);
        World world = arena.getWorld();
        int blocksPerTick = Math.max(50, plugin.getConfig().getInt("arena-reset.blocks-per-tick", 300));

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            List<BlockEntry> entries = new ArrayList<>();
            try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
                int sizeX = in.readInt();
                int sizeY = in.readInt();
                int sizeZ = in.readInt();

                for (int x = 0; x < sizeX; x++) {
                    for (int y = 0; y < sizeY; y++) {
                        for (int z = 0; z < sizeZ; z++) {
                            String blockDataString = in.readUTF();
                            entries.add(new BlockEntry(
                                    arena.getMinX() + x,
                                    arena.getMinY() + y,
                                    arena.getMinZ() + z,
                                    blockDataString));
                        }
                    }
                }
            } catch (IOException e) {
                plugin.getLogger().severe("Gagal baca snapshot arena '" + arena.getName() + "': " + e.getMessage());
                Bukkit.getScheduler().runTask(plugin, () -> {
                    arena.setState(Arena.State.AVAILABLE);
                    if (onComplete != null) onComplete.run();
                });
                return;
            }

            // Balik ke main thread buat apply block changes secara bertahap per-tick.
            Bukkit.getScheduler().runTask(plugin, () -> applyInBatches(world, entries, blocksPerTick, arena, onComplete));
        });
    }

    private void applyInBatches(World world, List<BlockEntry> entries, int blocksPerTick, Arena arena, Runnable onComplete) {
        new org.bukkit.scheduler.BukkitRunnable() {
            int index = 0;

            @Override
            public void run() {
                int processed = 0;
                while (processed < blocksPerTick && index < entries.size()) {
                    BlockEntry entry = entries.get(index);
                    BlockData data = Bukkit.createBlockData(entry.blockDataString);
                    world.getBlockAt(entry.x, entry.y, entry.z).setBlockData(data, false);
                    index++;
                    processed++;
                }
                if (index >= entries.size()) {
                    cancel();
                    arena.setState(Arena.State.AVAILABLE);
                    if (onComplete != null) onComplete.run();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private record BlockEntry(int x, int y, int z, String blockDataString) {
    }

    public void load() {
        arenas.clear();
        if (!arenasFile.exists()) return;

        FileConfiguration config = YamlConfiguration.loadConfiguration(arenasFile);
        if (config.getConfigurationSection("arenas") == null) return;

        for (String name : config.getConfigurationSection("arenas").getKeys(false)) {
            String path = "arenas." + name + ".";
            String worldName = config.getString(path + "world");
            World world = worldName != null ? Bukkit.getWorld(worldName) : null;
            if (world == null) {
                plugin.getLogger().warning("Arena '" + name + "' nunjuk ke world '" + worldName + "' yang gak ketemu, di-skip.");
                continue;
            }

            int minX = config.getInt(path + "min.x");
            int minY = config.getInt(path + "min.y");
            int minZ = config.getInt(path + "min.z");
            int maxX = config.getInt(path + "max.x");
            int maxY = config.getInt(path + "max.y");
            int maxZ = config.getInt(path + "max.z");

            Location spawn1 = null;
            Location spawn2 = null;
            if (config.contains(path + "spawn1")) {
                spawn1 = new Location(world,
                        config.getDouble(path + "spawn1.x"),
                        config.getDouble(path + "spawn1.y"),
                        config.getDouble(path + "spawn1.z"),
                        (float) config.getDouble(path + "spawn1.yaw"),
                        (float) config.getDouble(path + "spawn1.pitch"));
            }
            if (config.contains(path + "spawn2")) {
                spawn2 = new Location(world,
                        config.getDouble(path + "spawn2.x"),
                        config.getDouble(path + "spawn2.y"),
                        config.getDouble(path + "spawn2.z"),
                        (float) config.getDouble(path + "spawn2.yaw"),
                        (float) config.getDouble(path + "spawn2.pitch"));
            }

            Arena arena = new Arena(name, world, minX, minY, minZ, maxX, maxY, maxZ, spawn1, spawn2);
            arenas.put(name.toLowerCase(), arena);
        }
    }

    public void save() {
        FileConfiguration config = new YamlConfiguration();
        for (Arena arena : arenas.values()) {
            String path = "arenas." + arena.getName() + ".";
            config.set(path + "world", arena.getWorld().getName());
            config.set(path + "min.x", arena.getMinX());
            config.set(path + "min.y", arena.getMinY());
            config.set(path + "min.z", arena.getMinZ());
            config.set(path + "max.x", arena.getMaxX());
            config.set(path + "max.y", arena.getMaxY());
            config.set(path + "max.z", arena.getMaxZ());

            if (arena.getSpawn1() != null) {
                Location s1 = arena.getSpawn1();
                config.set(path + "spawn1.x", s1.getX());
                config.set(path + "spawn1.y", s1.getY());
                config.set(path + "spawn1.z", s1.getZ());
                config.set(path + "spawn1.yaw", s1.getYaw());
                config.set(path + "spawn1.pitch", s1.getPitch());
            }
            if (arena.getSpawn2() != null) {
                Location s2 = arena.getSpawn2();
                config.set(path + "spawn2.x", s2.getX());
                config.set(path + "spawn2.y", s2.getY());
                config.set(path + "spawn2.z", s2.getZ());
                config.set(path + "spawn2.yaw", s2.getYaw());
                config.set(path + "spawn2.pitch", s2.getPitch());
            }
        }
        try {
            config.save(arenasFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Gagal nyimpen arenas.yml: " + e.getMessage());
        }
    }
}
