package com.sanz.duel;

import com.sanz.duel.command.DuelArenaCommand;
import com.sanz.duel.command.DuelCommand;
import com.sanz.duel.listener.DuelListener;
import com.sanz.duel.manager.ArenaManager;
import com.sanz.duel.manager.DuelManager;
import org.bukkit.plugin.java.JavaPlugin;

public class SanzDuel extends JavaPlugin {

    private ArenaManager arenaManager;
    private DuelManager duelManager;

    // Dipake command /duelarena buat nyimpen sementara pos1/pos2 yang lagi di-set admin sebelum di-save.
    private final java.util.Map<java.util.UUID, PendingArenaSetup> pendingSetups = new java.util.HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getDataFolder().mkdirs();

        this.arenaManager = new ArenaManager(this);
        this.duelManager = new DuelManager(this, arenaManager);

        DuelCommand duelCommand = new DuelCommand(this, duelManager, arenaManager);
        getCommand("duel").setExecutor(duelCommand);
        getCommand("duel").setTabCompleter(duelCommand);

        DuelArenaCommand duelArenaCommand = new DuelArenaCommand(this, arenaManager);
        getCommand("duelarena").setExecutor(duelArenaCommand);
        getCommand("duelarena").setTabCompleter(duelArenaCommand);

        getServer().getPluginManager().registerEvents(new DuelListener(this, duelManager), this);

        getLogger().info("SanzDuel aktif.");
    }

    @Override
    public void onDisable() {
        if (arenaManager != null) arenaManager.save();
    }

    public ArenaManager getArenaManager() {
        return arenaManager;
    }

    public DuelManager getDuelManager() {
        return duelManager;
    }

    public java.util.Map<java.util.UUID, PendingArenaSetup> getPendingSetups() {
        return pendingSetups;
    }

    /** Data sementara pas admin lagi nyusun arena baru (pos1/pos2) sebelum di-save permanen. */
    public static class PendingArenaSetup {
        public String name;
        public org.bukkit.Location pos1;
        public org.bukkit.Location pos2;
    }
}
