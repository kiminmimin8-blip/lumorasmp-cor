package com.sanz.duel.model;

import org.bukkit.entity.Player;

import java.util.UUID;

public class ActiveDuel {

    private final UUID player1;
    private final UUID player2;
    private final Arena arena;
    private final PlayerSnapshot snapshot1;
    private final PlayerSnapshot snapshot2;
    private boolean countdownFinished = false;

    public ActiveDuel(Player player1, Player player2, Arena arena, PlayerSnapshot snapshot1, PlayerSnapshot snapshot2) {
        this.player1 = player1.getUniqueId();
        this.player2 = player2.getUniqueId();
        this.arena = arena;
        this.snapshot1 = snapshot1;
        this.snapshot2 = snapshot2;
    }

    public UUID getPlayer1() {
        return player1;
    }

    public UUID getPlayer2() {
        return player2;
    }

    public UUID getOpponent(UUID uuid) {
        if (uuid.equals(player1)) return player2;
        if (uuid.equals(player2)) return player1;
        return null;
    }

    public boolean involves(UUID uuid) {
        return uuid.equals(player1) || uuid.equals(player2);
    }

    public Arena getArena() {
        return arena;
    }

    public PlayerSnapshot getSnapshot(UUID uuid) {
        if (uuid.equals(player1)) return snapshot1;
        if (uuid.equals(player2)) return snapshot2;
        return null;
    }

    public boolean isCountdownFinished() {
        return countdownFinished;
    }

    public void setCountdownFinished(boolean countdownFinished) {
        this.countdownFinished = countdownFinished;
    }
}
