package com.sanz.duel.command;

import com.sanz.duel.SanzDuel;
import com.sanz.duel.manager.ArenaManager;
import com.sanz.duel.manager.DuelManager;
import com.sanz.duel.model.ActiveDuel;
import com.sanz.duel.model.DuelRequest;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DuelCommand implements CommandExecutor, TabCompleter {

    private final SanzDuel plugin;
    private final DuelManager duelManager;
    private final ArenaManager arenaManager;

    public DuelCommand(SanzDuel plugin, DuelManager duelManager, ArenaManager arenaManager) {
        this.plugin = plugin;
        this.duelManager = duelManager;
        this.arenaManager = arenaManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }

        if (args.length < 1) {
            player.sendMessage(Component.text("Pakai: /duel <player|accept|deny|forfeit|stats|top>", NamedTextColor.RED));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "accept" -> handleAccept(player);
            case "deny" -> handleDeny(player);
            case "forfeit" -> handleForfeit(player);
            case "stats" -> handleStats(player, args);
            case "top" -> handleTop(player);
            default -> handleChallenge(player, args[0]);
        }
        return true;
    }

    private void handleChallenge(Player player, String targetName) {
        if (duelManager.isInDuel(player.getUniqueId())) {
            player.sendMessage(Component.text("Lu lagi di dalem duel, gak bisa nantang lagi.", NamedTextColor.RED));
            return;
        }

        Player target = Bukkit.getPlayer(targetName);
        if (target == null || !target.isOnline()) {
            player.sendMessage(Component.text("Player '" + targetName + "' gak online.", NamedTextColor.RED));
            return;
        }
        if (target.equals(player)) {
            player.sendMessage(Component.text("Gak bisa nantang diri sendiri.", NamedTextColor.RED));
            return;
        }
        if (duelManager.isInDuel(target.getUniqueId())) {
            player.sendMessage(Component.text(target.getName() + " lagi di dalem duel lain.", NamedTextColor.RED));
            return;
        }
        if (arenaManager.findFreeArena() == null) {
            player.sendMessage(Component.text("Gak ada arena duel yang kosong sekarang, coba lagi bentar.", NamedTextColor.RED));
            return;
        }

        duelManager.sendRequest(player, target);
        player.sendMessage(Component.text("Tantangan duel dikirim ke " + target.getName() + ".", NamedTextColor.GREEN));
        target.sendMessage(Component.text()
                .append(Component.text(player.getName() + " nantang lu duel! ", NamedTextColor.YELLOW))
                .append(Component.text("[Terima]", NamedTextColor.GREEN))
                .append(Component.text(" ketik /duel accept, atau /duel deny buat nolak.", NamedTextColor.GRAY))
                .build());
    }

    private void handleAccept(Player player) {
        DuelRequest request = duelManager.getPendingRequest(player.getUniqueId());
        if (request == null) {
            player.sendMessage(Component.text("Gak ada tantangan duel yang nunggu diterima.", NamedTextColor.RED));
            return;
        }
        Player challenger = Bukkit.getPlayer(request.getChallenger());
        if (challenger == null || !challenger.isOnline()) {
            player.sendMessage(Component.text("Player yang nantang lu udah offline.", NamedTextColor.RED));
            duelManager.clearRequest(player.getUniqueId());
            return;
        }
        if (duelManager.isInDuel(challenger.getUniqueId()) || duelManager.isInDuel(player.getUniqueId())) {
            player.sendMessage(Component.text("Salah satu dari kalian udah masuk duel lain.", NamedTextColor.RED));
            duelManager.clearRequest(player.getUniqueId());
            return;
        }

        duelManager.clearRequest(player.getUniqueId());
        boolean started = duelManager.startDuel(challenger, player);
        if (started) {
            challenger.sendMessage(Component.text("Duel dimulai lawan " + player.getName() + "!", NamedTextColor.GOLD));
            player.sendMessage(Component.text("Duel dimulai lawan " + challenger.getName() + "!", NamedTextColor.GOLD));
        }
    }

    private void handleDeny(Player player) {
        DuelRequest request = duelManager.getPendingRequest(player.getUniqueId());
        if (request == null) {
            player.sendMessage(Component.text("Gak ada tantangan duel yang nunggu ditolak.", NamedTextColor.RED));
            return;
        }
        duelManager.clearRequest(player.getUniqueId());
        player.sendMessage(Component.text("Tantangan duel ditolak.", NamedTextColor.GRAY));
        Player challenger = Bukkit.getPlayer(request.getChallenger());
        if (challenger != null) {
            challenger.sendMessage(Component.text(player.getName() + " nolak tantangan duel lu.", NamedTextColor.GRAY));
        }
    }

    private void handleForfeit(Player player) {
        ActiveDuel duel = duelManager.getActiveDuel(player.getUniqueId());
        if (duel == null) {
            player.sendMessage(Component.text("Lu gak lagi di dalem duel.", NamedTextColor.RED));
            return;
        }
        java.util.UUID winner = duel.getOpponent(player.getUniqueId());
        duelManager.endDuel(duel, winner);
        player.sendMessage(Component.text("Lu nyerah dari duel.", NamedTextColor.RED));
    }

    private void handleStats(Player player, String[] args) {
        Player target = player;
        if (args.length >= 2) {
            Player p = Bukkit.getPlayer(args[1]);
            if (p != null) target = p;
        }
        int wins = duelManager.getWins(target.getUniqueId());
        int losses = duelManager.getLosses(target.getUniqueId());
        player.sendMessage(Component.text(target.getName() + " - Menang: " + wins + " | Kalah: " + losses, NamedTextColor.AQUA));
    }

    private void handleTop(Player player) {
        Map<String, Integer> top = duelManager.getTopWins(10);
        if (top.isEmpty()) {
            player.sendMessage(Component.text("Belum ada data duel.", NamedTextColor.GRAY));
            return;
        }
        player.sendMessage(Component.text("=== Top Duel Wins ===", NamedTextColor.GOLD));
        int rank = 1;
        for (Map.Entry<String, Integer> entry : top.entrySet()) {
            player.sendMessage(Component.text(rank + ". " + entry.getKey() + " - " + entry.getValue() + " menang", NamedTextColor.YELLOW));
            rank++;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) {
            return new ArrayList<>();
        }
        String prefix = args[0].toLowerCase();

        List<String> options = new ArrayList<>(List.of("accept", "deny", "forfeit", "stats", "top"));
        // Tambahin nama player online juga, biar tab-complete langsung kasih target duel yang valid.
        Bukkit.getOnlinePlayers().forEach(p -> options.add(p.getName()));

        return options.stream()
                .filter(opt -> opt.toLowerCase().startsWith(prefix))
                .sorted()
                .collect(Collectors.toList());
    }
}
