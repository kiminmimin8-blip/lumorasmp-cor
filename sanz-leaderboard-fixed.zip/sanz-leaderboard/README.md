# SanzLeaderboard

Plugin leaderboard standalone buat Sanz SMP.

## Kategori yang ditrack

kills (player), **kills_mob (BARU)**, deaths, playtime, afktime, money, blocks_mined,
blocks_placed, gems.

**kills vs kills_mob:** `kills` cuma ngitung kill sesama player (PvP). `kills_mob`
kategori BARU, ngitung mob yang kamu bunuh (zombie, skeleton, dll) - dua leaderboard
terpisah, gak nyampur.

**playtime vs afktime:** waktu AKTIF main masuk `playtime`, waktu AFK (termasuk AFK
farm kalau kamu pakai AxAFKZone atau plugin AFK lain yang nge-set metadata "afk") masuk
`afktime` - keduanya kesimpan, gak ada yang dibuang. Mau gabung jadi satu angka "total
main" tinggal jumlahin dua placeholder-nya sendiri di TAB/scoreboard
(`%sanzleaderboard_playtime_raw%` + `%sanzleaderboard_afktime_raw%`).

## AFK Reward (BARU)

Kasih money/gems otomatis ke player yang lagi kedeteksi AFK. Diatur di `config.yml`:
```yaml
afk-reward:
  enabled: false      # ganti true buat aktifin
  interval-seconds: 60
  money: 0
  gems: 5
  notify-player: true
```
Deteksi AFK-nya pakai sistem yang SAMA kayak kategori `afktime` - kalau kamu pakai
AxAFKZone yang emang berbasis "zona AFK" tertentu (bukan idle global), reward ini
otomatis ngikutin logic itu juga, gak perlu setup zona terpisah.

## Hologram - format sepenuhnya dari config, ada animasi

Sebelumnya hologram cuma "header + list rata kiri", sekarang formatnya lengkap:
header multi-baris, rank 1 sampai top-size.hologram SELALU tampil semua (yang belum ada
data ditampilin sebagai placeholder garis putus-putus), divider, footer, dan **animasi**
(misal warna judul yang cycle) - semua diatur dari `config.yml` bagian `hologram.format`
dan `hologram.animation`, TANPA perlu ubah kode.

Placeholder yang bisa dipakai di header/rank-line/empty-rank-line/divider/footer:
`{category}` `{rank}` `{player}` `{value}` `{top1_player}` `{top1_value}` `{anim}`

Contoh hasil (default config, kategori "kills"):
```
sanz.xyz
leaderboard top kill
1. subah22   [ 20 ]
2. - - - - - - -    [   ]
3. - - - - - - -    [   ]
...
10. - - - - - - -    [   ]
-------------------------------
  1. subah22  [ 20 ]
```

Animasi (`hologram.animation.frames`) jalan di task TERPISAH dan lebih cepat
(`interval-ticks`, default tiap 0.5 detik) daripada refresh data leaderboard
(`refresh-interval-seconds`, default 30 detik) - jadi teksnya bisa "hidup" tanpa bikin
plugin query database tiap animasi maju 1 frame.

**Ganti nama kategori di hologram** (misal "kill" jadi "pembunuhan"): edit
`categories.<key>.short-name` di config.yml, gak perlu sentuh kode.

## Command

| Command | Fungsi |
|---|---|
| `/leaderboard` (`/lb`, `/top`) | Buka GUI - sekarang 9 kategori, GUI diperbesar biar muat semua |
| `/gems balance\|give\|take\|set` | Kelola gems |
| `/lbhologram create\|remove\|list <kategori>` | Kelola hologram |
| `/lbhologram purge [radius]` | Bersihin hologram numpuk/duplikat (default radius 5 block dari posisi kamu) |

## Catatan revisi penting

- **Fix hologram numpuk/spam di spawn**: sebelumnya tiap restart/reload server,
  hologram lama gak pernah kehapus (cuma nge-tumpuk TextDisplay baru di lokasi yang
  sama). Sekarang otomatis dibersihin sendiri tiap restore, dan ada `/lbhologram purge`
  buat beresin manual sisa-sisa yang udah kadung numpuk sebelum update ini.
- **Fix AFK zone (AxAFKZone) gak kehitung [v2]**: percobaan pertama pakai placeholder
  PlaceholderAPI `%axafkzone_afk%` TERNYATA GAK JALAN di server ini (AxAFKZone 1.12.0
  gak expose expansion PAPI apapun sama sekali, kebukti dari log server). Sekarang
  deteksi AFK zone baca LANGSUNG file `plugins/AxAFKZone/zones/*.yml` dan ngecek posisi
  player terhadap cuboid zona itu sendiri -- gak butuh PlaceholderAPI atau API AxAFKZone
  sama sekali. Configurable lewat `afk.detect-axafkzone-region` dan
  `afk.axafkzone-region-reload-seconds` (seberapa sering baca ulang folder zones, biar
  zona baru ke-detect tanpa restart) di config.yml.

## PlaceholderAPI (opsional)

Softdepend - kalau PlaceholderAPI ke-install, placeholder `%sanzleaderboard_...%`
otomatis aktif (identifier bisa diganti di config, gak perlu rebuild). Lihat komentar
lengkap di `config.yml` bagian `placeholder`.

## Cara build

Sandbox aku gak ada internet buat `mvn compile` - direview manual baris per baris,
termasuk cek semua exhaustive switch statement biar gak ada yang lupa nambahin case
buat kategori baru (kills_mob). Push ke GitHub, biarin Actions CI yang build, kirim log
error ke sini kalau ada yang kelewat.

**Cek dulu versi `paper-api` di `pom.xml`** kalau beda dari `1.21.11-R0.1-SNAPSHOT`.
