package com.sanz.leaderboard.commands;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.StatType;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/** Dev-revisi: implement TabCompleter -- sebelumnya command ini gak punya saran tab sama sekali. */
public class HologramCommand implements CommandExecutor, TabCompleter {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzLeaderboard plugin;

    public HologramCommand(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }

        if (args.length < 1) {
            sender.sendMessage(LEGACY.deserialize("&cUsage: /lbhologram <create|remove|list|purge> [kategori/radius]"));
            return true;
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("purge")) {
            double radius = 5.0;
            if (args.length >= 2) {
                try {
                    radius = Double.parseDouble(args[1]);
                } catch (NumberFormatException ignored) {
                    // pakai default kalau bukan angka valid
                }
            }
            int removed = plugin.getHologram().purgeArea(player.getLocation(), radius);
            player.sendMessage(LEGACY.deserialize("&aDibersihin &f" + removed
                    + " &ahologram numpuk/duplikat dalam radius &f" + radius + " &ablock di sekitar kamu."));
            return true;
        }

        if (sub.equals("list")) {
            var active = plugin.getHologram().listActive();
            if (active.isEmpty()) {
                player.sendMessage(LEGACY.deserialize("&7Belum ada hologram leaderboard yang aktif."));
                return true;
            }
            StringBuilder sb = new StringBuilder("&7Hologram aktif: &f");
            for (StatType type : active) {
                sb.append(type.configKey()).append(" ");
            }
            player.sendMessage(LEGACY.deserialize(sb.toString()));
            return true;
        }

        if (args.length < 2) {
            player.sendMessage(LEGACY.deserialize("&cUsage: /lbhologram " + sub + " <kategori>"));
            return true;
        }

        StatType type = StatType.fromConfigKey(args[1]);
        if (type == null) {
            player.sendMessage(LEGACY.deserialize("&cKategori gak valid."));
            return true;
        }

        switch (sub) {
            case "create" -> {
                plugin.getHologram().create(type, player.getLocation());
                player.sendMessage(LEGACY.deserialize("&aHologram &f" + type.configKey() + " &adibuat di posisi kamu sekarang."));
            }
            case "remove" -> {
                boolean removed = plugin.getHologram().remove(type);
                if (removed) {
                    player.sendMessage(LEGACY.deserialize("&aHologram &f" + type.configKey() + " &adihapus."));
                } else {
                    player.sendMessage(LEGACY.deserialize("&cGak ada hologram aktif buat kategori itu."));
                }
            }
            default -> player.sendMessage(LEGACY.deserialize("&cSub-command gak dikenal. Pakai: create, remove, list, purge"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("create", "remove", "list", "purge");
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("create") || args[0].equalsIgnoreCase("remove"))) {
            List<String> keys = new ArrayList<>();
            for (StatType type : StatType.values()) {
                keys.add(type.configKey());
            }
            return keys;
        }
        return List.of();
    }
}
