package com.sanz.leaderboard.leaderboard;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.LeaderboardEntry;
import com.sanz.leaderboard.data.StatType;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Nyimpen cache top-N tiap kategori di memory. Di-refresh berkala lewat task async
 * (interval diatur dari config.yml: refresh-interval-seconds).
 * GUI dan hologram baca dari cache ini, bukan query DB langsung, jadi ringan.
 *
 * Admin/OP di-exclude dari leaderboard manapun (kalau exclude-admins: true di config).
 * Cache-nya nyimpen sejumlah "cacheSize" (= max dari top-size.gui dan top-size.hologram),
 * GUI baca semuanya, hologram cuma ambil beberapa baris pertama.
 *
 * Dev-revisi: SEKARANG juga nyimpen rankCache & valueCache (rank+value SEMUA
 * player, bukan cuma yang masuk top-N) -- dipakai PlaceholderHook supaya
 * placeholder rank/value player biasa (yang mungkin gak masuk top-N) bisa
 * O(1) baca dari cache, TIDAK query SQLite langsung tiap placeholder
 * di-request (placeholder bisa diminta berkali-kali per detik dari
 * scoreboard/TAB plugin -- query DB sesering itu bakal berat).
 * Konsekuensinya: rank/value placeholder cuma seakurat refresh terakhir
 * (default tiap 30 detik, bukan real-time), sama seperti leaderboard
 * GUI/hologram yang sudah lebih dulu pakai pendekatan cache ini.
 */
public class LeaderboardManager {

    private final SanzLeaderboard plugin;
    private final Map<StatType, List<LeaderboardEntry>> cache = new ConcurrentHashMap<>(new EnumMap<>(StatType.class));
    private final Map<StatType, Map<UUID, Integer>> rankCache = new ConcurrentHashMap<>(new EnumMap<>(StatType.class));
    private final Map<StatType, Map<UUID, Double>> valueCache = new ConcurrentHashMap<>(new EnumMap<>(StatType.class));

    public LeaderboardManager(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    /** Dipanggil dari task async - query semua kategori aktif dan update cache. */
    public void refresh() {
        boolean excludeAdmins = plugin.getConfig().getBoolean("exclude-admins", true);
        int cacheSize = getCacheSize();

        for (StatType type : StatType.values()) {
            if (!plugin.getConfig().getBoolean("categories." + type.configKey() + ".enabled", true)) {
                continue;
            }

            // Satu query full-order per kategori -- dipakai buat DUA hal sekaligus:
            // (1) rank+value semua player (buat placeholder), (2) top-N buat GUI/hologram.
            // Lebih efisien daripada dua query terpisah seperti sebelumnya.
            List<LeaderboardEntry> all = plugin.getDatabase().getAllOrdered(type);

            Map<UUID, Integer> ranks = new HashMap<>();
            Map<UUID, Double> values = new HashMap<>();
            for (int i = 0; i < all.size(); i++) {
                LeaderboardEntry entry = all.get(i);
                ranks.put(entry.getUuid(), i + 1); // rank 1-based, dihitung dari SEMUA player (termasuk yang di-exclude dari tampilan)
                values.put(entry.getUuid(), entry.getValue());
            }
            rankCache.put(type, ranks);
            valueCache.put(type, values);

            List<LeaderboardEntry> filtered = all.stream()
                    .filter(entry -> !excludeAdmins || !isExcluded(entry.getUuid()))
                    .limit(cacheSize)
                    .collect(Collectors.toList());

            cache.put(type, filtered);
        }
    }

    private boolean isExcluded(UUID uuid) {
        Player online = Bukkit.getPlayer(uuid);
        if (online != null) {
            return online.isOp() || online.hasPermission("sanzleaderboard.exclude");
        }
        try {
            OfflinePlayer offline = Bukkit.getOfflinePlayer(uuid);
            return offline.isOp();
        } catch (Exception e) {
            return false;
        }
    }

    public int getGuiTopSize() {
        return plugin.getConfig().getInt("top-size.gui", 20);
    }

    public int getHologramTopSize() {
        return plugin.getConfig().getInt("top-size.hologram", 10);
    }

    private int getCacheSize() {
        return Math.max(getGuiTopSize(), getHologramTopSize());
    }

    /** Dipakai GUI - list lengkap sampai top-size.gui. */
    public List<LeaderboardEntry> getTop(StatType type) {
        return cache.getOrDefault(type, Collections.emptyList());
    }

    /** Dipakai hologram - cuma sebagian depan sampai top-size.hologram. */
    public List<LeaderboardEntry> getTopForHologram(StatType type) {
        List<LeaderboardEntry> full = getTop(type);
        int limit = getHologramTopSize();
        if (full.size() <= limit) return full;
        return full.subList(0, limit);
    }

    public String getDisplayName(StatType type) {
        return plugin.getConfig().getString("categories." + type.configKey() + ".display-name", type.name());
    }

    public String getFormat(StatType type) {
        return plugin.getConfig().getString("categories." + type.configKey() + ".format", "&7#{rank}. &f{player} &7- {value}");
    }

    public boolean isEnabled(StatType type) {
        return plugin.getConfig().getBoolean("categories." + type.configKey() + ".enabled", true);
    }

    /**
     * Dipakai PlaceholderHook: value player (RAW, belum diformat) dari cache
     * hasil refresh() terakhir. -1 kalau dikonversi ke sentinel bukan opsi
     * karena 0 valid, jadi pemanggil cek keberadaan lewat hasValue() dulu
     * kalau perlu bedain "belum ada data" vs "value-nya 0".
     */
    public double getCachedValue(StatType type, UUID uuid) {
        return valueCache.getOrDefault(type, Collections.emptyMap()).getOrDefault(uuid, 0.0);
    }

    public boolean hasCachedValue(StatType type, UUID uuid) {
        return valueCache.getOrDefault(type, Collections.emptyMap()).containsKey(uuid);
    }

    /** Rank 1-based dari cache hasil refresh() terakhir, -1 kalau player belum ada data sama sekali. */
    public int getCachedRank(StatType type, UUID uuid) {
        return rankCache.getOrDefault(type, Collections.emptyMap()).getOrDefault(uuid, -1);
    }
}
