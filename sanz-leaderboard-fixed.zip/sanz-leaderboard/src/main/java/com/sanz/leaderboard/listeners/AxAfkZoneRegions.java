package com.sanz.leaderboard.listeners;

import com.sanz.leaderboard.SanzLeaderboard;
import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * REVISI (ganti pendekatan total): percobaan sebelumnya baca status AFK zone lewat
 * placeholder PlaceholderAPI (%axafkzone_afk%) TERNYATA GAK BISA DIPAKAI di server
 * ini -- dari log kebukti AxAFKZone 1.12.0 SAMA SEKALI GAK expose expansion apapun
 * ke PlaceholderAPI (gak ada di /papi ecloud, gak ada di daftar "registered
 * expansion", dan gak ada toggle "hooks.placeholderapi" di config.yml-nya).
 * Jadi ketergantungan ke PlaceholderAPI buat ini DIHAPUS SEPENUHNYA.
 *
 * PENDEKATAN BARU (self-contained, gak butuh API/placeholder plugin lain sama
 * sekali): AxAFKZone nyimpen tiap zona yang dibikin admin sebagai file YAML di
 * plugins/AxAFKZone/zones/<nama-zona>.yml, dengan bagian:
 *   zone:
 *     location1: "<world>;<x>;<y>;<z>;<yaw>;<pitch>"
 *     location2: "<world>;<x>;<y>;<z>;<yaw>;<pitch>"
 * (lihat plugins/AxAFKZone/zones/afk.yml punya kamu sendiri - persis format ini).
 *
 * Class ini baca SEMUA file .yml di folder itu langsung dari disk, parse jadi
 * cuboid (world + min/max X/Y/Z), terus di-cache di memory. AFKTracker tinggal
 * tanya "player ini lagi di dalam salah satu zona gak?" lewat isInZone() --
 * murni matematika lokasi, gak nyentuh AxAFKZone punya kode/API sama sekali,
 * jadi PASTI jalan berapapun versi AxAFKZone-nya nanti (asal formatnya gak
 * ganti total).
 *
 * List zona di-refresh berkala (default tiap 5 menit, configurable lewat
 * afk.axafkzone-region-reload-seconds) supaya zona baru yang dibikin admin ikut
 * kebaca tanpa perlu restart server.
 */
public class AxAfkZoneRegions {

    /** Satu cuboid region hasil parse dari salah satu file zone AxAFKZone. */
    private record Region(String world, double minX, double maxX, double minY, double maxY, double minZ, double maxZ) {
        boolean contains(Location loc) {
            if (!loc.getWorld().getName().equals(world)) return false;
            double x = loc.getX(), y = loc.getY(), z = loc.getZ();
            return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
        }
    }

    private final SanzLeaderboard plugin;
    private final List<Region> regions = new CopyOnWriteArrayList<>();

    public AxAfkZoneRegions(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    /** True kalau lokasi ini ada di dalam salah satu zona AxAFKZone. */
    public boolean isInZone(Location location) {
        if (location == null || location.getWorld() == null) return false;
        for (Region region : regions) {
            if (region.contains(location)) return true;
        }
        return false;
    }

    /** Convenience overload buat AFKTracker. */
    public boolean isInZone(Player player) {
        return isInZone(player.getLocation());
    }

    /**
     * Baca ulang semua file zone dari plugins/AxAFKZone/zones/*.yml.
     * Aman dipanggil berkali-kali (dipanggil dari task berkala) - kalau
     * AxAFKZone gak ke-install, atau folder zones-nya belum ada, cuma nge-clear
     * list & keluar diem-diem (gak nge-spam warning tiap reload).
     */
    public void reload() {
        List<Region> fresh = new ArrayList<>();

        Plugin axAfkZone = plugin.getServer().getPluginManager().getPlugin("AxAFKZone");
        if (axAfkZone == null || !axAfkZone.isEnabled()) {
            regions.clear();
            return;
        }

        File zonesFolder = new File(axAfkZone.getDataFolder(), "zones");
        File[] files = zonesFolder.listFiles((dir, name) -> name.toLowerCase().endsWith(".yml"));
        if (files == null) {
            regions.clear();
            return;
        }

        for (File file : files) {
            try {
                YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
                String loc1 = yaml.getString("zone.location1");
                String loc2 = yaml.getString("zone.location2");
                if (loc1 == null || loc2 == null) continue;

                Region region = parseRegion(loc1, loc2);
                if (region != null) {
                    fresh.add(region);
                }
            } catch (Exception e) {
                plugin.getLogger().warning("[SanzLeaderboard] Gagal parse zone AxAFKZone dari file "
                        + file.getName() + ": " + e.getMessage());
            }
        }

        regions.clear();
        regions.addAll(fresh);
    }

    /** Parse "world;x;y;z;yaw;pitch" x2 jadi satu cuboid Region (auto sort min/max). */
    private Region parseRegion(String loc1, String loc2) {
        String[] a = loc1.split(";");
        String[] b = loc2.split(";");
        if (a.length < 4 || b.length < 4) return null;
        if (!a[0].equals(b[0])) return null; // beda world, gak valid

        double x1 = Double.parseDouble(a[1]);
        double y1 = Double.parseDouble(a[2]);
        double z1 = Double.parseDouble(a[3]);
        double x2 = Double.parseDouble(b[1]);
        double y2 = Double.parseDouble(b[2]);
        double z2 = Double.parseDouble(b[3]);

        return new Region(a[0],
                Math.min(x1, x2), Math.max(x1, x2),
                Math.min(y1, y2), Math.max(y1, y2),
                Math.min(z1, z2), Math.max(z1, z2));
    }

    public int zoneCount() {
        return regions.size();
    }
}
