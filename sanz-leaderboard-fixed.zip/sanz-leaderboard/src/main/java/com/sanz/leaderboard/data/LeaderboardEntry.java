package com.sanz.leaderboard.data;

import java.util.UUID;

/**
 * Satu baris hasil top-N: player + value stat-nya.
 */
public class LeaderboardEntry {

    private final UUID uuid;
    private final String playerName;
    private final double value;

    public LeaderboardEntry(UUID uuid, String playerName, double value) {
        this.uuid = uuid;
        this.playerName = playerName;
        this.value = value;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getPlayerName() {
        return playerName;
    }

    public double getValue() {
        return value;
    }
}
