package com.sanz.leaderboard.listeners;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.StatType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class CombatListener implements Listener {

    private final SanzLeaderboard plugin;

    public CombatListener(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        // Query DB itu I/O blocking, jangan dijalanin di main thread - lempar ke async
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            plugin.getDatabase().increment(victim.getUniqueId(), victim.getName(), StatType.DEATHS, 1);

            if (killer != null && !killer.getUniqueId().equals(victim.getUniqueId())) {
                plugin.getDatabase().increment(killer.getUniqueId(), killer.getName(), StatType.KILLS, 1);
            }
        });
    }
}
