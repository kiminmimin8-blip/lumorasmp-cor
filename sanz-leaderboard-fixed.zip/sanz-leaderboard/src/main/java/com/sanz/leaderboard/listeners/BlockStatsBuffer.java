package com.sanz.leaderboard.listeners;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.StatType;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Nampung hitungan block mined/placed di memory dulu (super murah, cuma increment angka),
 * baru di-flush ke database secara berkala. Ini biar server survival yang rame gak keteteran
 * nge-query SQLite tiap kali ada 1 block pecah/taruh.
 */
public class BlockStatsBuffer {

    private final SanzLeaderboard plugin;
    private final Map<UUID, AtomicLong> mined = new ConcurrentHashMap<>();
    private final Map<UUID, AtomicLong> placed = new ConcurrentHashMap<>();
    private final Map<UUID, String> nameCache = new ConcurrentHashMap<>();

    public BlockStatsBuffer(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    public void addMined(Player player) {
        nameCache.put(player.getUniqueId(), player.getName());
        mined.computeIfAbsent(player.getUniqueId(), k -> new AtomicLong()).incrementAndGet();
    }

    public void addPlaced(Player player) {
        nameCache.put(player.getUniqueId(), player.getName());
        placed.computeIfAbsent(player.getUniqueId(), k -> new AtomicLong()).incrementAndGet();
    }

    /** Dipanggil berkala (repeating task async) buat nulis semua buffer ke database sekaligus, terus di-reset. */
    public void flush() {
        if (mined.isEmpty() && placed.isEmpty()) return;

        for (Map.Entry<UUID, AtomicLong> entry : mined.entrySet()) {
            long amount = entry.getValue().getAndSet(0);
            if (amount > 0) {
                String name = nameCache.getOrDefault(entry.getKey(), "unknown");
                plugin.getDatabase().increment(entry.getKey(), name, StatType.BLOCKS_MINED, amount);
            }
        }
        for (Map.Entry<UUID, AtomicLong> entry : placed.entrySet()) {
            long amount = entry.getValue().getAndSet(0);
            if (amount > 0) {
                String name = nameCache.getOrDefault(entry.getKey(), "unknown");
                plugin.getDatabase().increment(entry.getKey(), name, StatType.BLOCKS_PLACED, amount);
            }
        }
    }
}
