package com.sanz.leaderboard.data;

/**
 * Semua kategori stat yang ditrack leaderboard.
 * columnName = nama kolom di tabel SQLite player_stats.
 *
 * Dev-revisi: PLAYTIME dan AFK_TIME sekarang DUA kategori terpisah --
 * sebelumnya cuma ada satu "playtime" yang otomatis SKIP waktu AFK (jadi
 * cuma ngitung waktu aktif). Sekarang waktu AFK itu TIDAK dibuang, tapi
 * dialihkan ke kolom sendiri (AFK_TIME), jadi ada 2 leaderboard: siapa
 * yang paling lama AKTIF main (PLAYTIME), dan siapa yang paling lama AFK
 * (AFK_TIME) -- keduanya dari sumber deteksi AFK yang sama (AFKTracker,
 * termasuk baca metadata AxAFKZone kalau plugin itu ke-install).
 */
public enum StatType {
    KILLS("kills", "kills"),
    KILLS_MOB("kills_mob", "kills_mob"),
    DEATHS("deaths", "deaths"),
    PLAYTIME("playtime", "playtime_seconds"),
    AFK_TIME("afktime", "afk_seconds"),
    MONEY("money", "money_cache"),
    BLOCKS_MINED("blocks_mined", "blocks_mined"),
    BLOCKS_PLACED("blocks_placed", "blocks_placed"),
    GEMS("gems", "gems");

    private final String configKey;
    private final String columnName;

    StatType(String configKey, String columnName) {
        this.configKey = configKey;
        this.columnName = columnName;
    }

    public String configKey() {
        return configKey;
    }

    public String columnName() {
        return columnName;
    }

    public static StatType fromConfigKey(String key) {
        for (StatType type : values()) {
            if (type.configKey.equalsIgnoreCase(key)) {
                return type;
            }
        }
        return null;
    }
}
