package com.sanz.leaderboard.leaderboard;

import com.sanz.leaderboard.data.StatType;

import java.text.NumberFormat;
import java.util.Locale;

public final class ValueFormatter {

    private ValueFormatter() {
    }

    public static String format(StatType type, double value) {
        return switch (type) {
            case PLAYTIME, AFK_TIME -> formatPlaytime((long) value);
            case MONEY -> formatMoney(value);
            default -> String.valueOf((long) value);
        };
    }

    private static String formatPlaytime(long totalSeconds) {
        long hours = totalSeconds / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        if (hours > 0) {
            return hours + "j " + minutes + "m";
        }
        return minutes + "m";
    }

    private static String formatMoney(double value) {
        NumberFormat nf = NumberFormat.getNumberInstance(new Locale("in", "ID"));
        nf.setMaximumFractionDigits(0);
        return nf.format(value);
    }
}
