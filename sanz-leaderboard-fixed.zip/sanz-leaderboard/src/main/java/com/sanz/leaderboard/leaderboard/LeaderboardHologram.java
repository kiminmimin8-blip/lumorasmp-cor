package com.sanz.leaderboard.leaderboard;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.LeaderboardEntry;
import com.sanz.leaderboard.data.StatType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.TextDisplay;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Hologram leaderboard pakai TextDisplay native. SEKARANG format-nya SEPENUHNYA
 * dari config.yml bagian "hologram.format" (header/rank-line/empty-rank-line/
 * divider/footer), plus animasi teks (misal warna judul yang cycle) yang di-drive
 * task terpisah lebih cepat dari refresh data biasa - JADI teks-nya bisa "hidup"
 * tanpa perlu query database ulang tiap animasi maju 1 frame.
 *
 * Placeholder yang didukung di semua bagian format:
 *   {category}    -> nama pendek kategori (dari categories.<key>.short-name di config)
 *   {rank}        -> nomor urut (1, 2, 3, ...)
 *   {player}      -> nama player di baris itu
 *   {value}       -> value player itu (sudah diformat)
 *   {top1_player} -> nama player rank #1 (buat footer highlight)
 *   {top1_value}  -> value player rank #1
 *   {anim}        -> frame animasi yang lagi aktif (dari hologram.animation.frames)
 *
 * BUG FIX (spam/duplikat hologram di spawn): sebelumnya spawnDisplay() dipanggil
 * langsung tiap plugin restart/reload (restoreAll()) TANPA ngecek apakah hologram
 * lama masih nyangkut di world. TextDisplay di-spawn dengan setPersistent(true),
 * jadi entity-nya IKUT TERSIMPAN di world walau plugin di-reload/server restart --
 * sementara activeDisplays (Map di RAM) itu KOSONG lagi tiap kali plugin baru
 * nyala. Akibatnya remove(type) di awal create() gak nemu apa-apa buat dihapus
 * (karena cuma cek Map di RAM), dan restoreAll() nge-spawn TextDisplay BARU di
 * lokasi yang PERSIS SAMA tanpa pernah hapus yang lama -- numpuk terus tiap
 * restart/reload, makanya keliatan "spam"/dobel-dobel nge-overlap di spawn.
 *
 * FIX: setiap TextDisplay hologram di-tag pakai scoreboard tag unik
 * (lihat TAG_PREFIX), DAN sebelum spawn di lokasi manapun, semua entity
 * TextDisplay yang nyangkut PERSIS di titik itu (radius kecil) dibersihkan
 * dulu -- baik yang ke-tag maupun yang enggak (hologram lama dari SEBELUM
 * fix ini juga otomatis kebersihin, karena lokasi persis sama gak mungkin
 * kebetulan ada TextDisplay builder lain di situ). Command
 * "/lbhologram purge" juga ditambahin buat bersih-bersih manual pakai
 * radius lebih besar di sekitar player, buat beresin sisa-sisa numpukan
 * yang udah kadung ada sebelum update ini di-pasang.
 */
public class LeaderboardHologram {

    /** Prefix scoreboard tag buat nandain TextDisplay yang di-spawn plugin ini (dipakai buat cleanup/purge). */
    private static final String TAG_PREFIX = "sanzlb_holo_";

    /** Radius (block) buat bersihin TextDisplay lama yang nyangkut PERSIS di titik spawn baru. */
    private static final double EXACT_SPOT_CLEANUP_RADIUS = 0.6;

    private final SanzLeaderboard plugin;
    private final Map<StatType, UUID> activeDisplays = new LinkedHashMap<>();
    private final File storageFile;
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();

    private int animationFrameIndex = 0;

    public LeaderboardHologram(SanzLeaderboard plugin) {
        this.plugin = plugin;
        this.storageFile = new File(plugin.getDataFolder(), "holograms.yml");
    }

    public boolean create(StatType type, Location rawLocation) {
        remove(type);

        double yOffset = plugin.getConfig().getDouble("hologram.y-offset", 1.5);
        Location location = rawLocation.clone().add(0, yOffset, 0);

        spawnDisplay(type, location);
        saveLocation(type, location);
        return true;
    }

    private void spawnDisplay(StatType type, Location location) {
        // Bersihin dulu TextDisplay lama (orphan dari restart/reload sebelumnya, ATAU
        // sisa create() yang di-panggil ulang) yang nyangkut PERSIS di titik ini,
        // SEBELUM spawn yang baru -- ini kunci fix-nya, lihat javadoc class di atas.
        purgeExactSpot(location);

        TextDisplay display = location.getWorld().spawn(location, TextDisplay.class, td -> {
            td.setBillboard(Display.Billboard.CENTER);
            td.setSeeThrough(false);
            td.setShadowed(true);
            td.setDefaultBackground(true);
            td.setAlignment(TextDisplay.TextAlignment.CENTER);
            td.text(buildComponent(type));
            td.setPersistent(true);
            td.addScoreboardTag(TAG_PREFIX + type.name());
        });

        activeDisplays.put(type, display.getUniqueId());
    }

    /** Hapus semua TextDisplay yang nyangkut persis di lokasi ini (radius kecil), tag atau enggak. */
    private void purgeExactSpot(Location location) {
        if (location.getWorld() == null) return;
        for (var entity : location.getWorld().getNearbyEntities(location,
                EXACT_SPOT_CLEANUP_RADIUS, EXACT_SPOT_CLEANUP_RADIUS, EXACT_SPOT_CLEANUP_RADIUS)) {
            if (entity instanceof TextDisplay) {
                entity.remove();
            }
        }
    }

    public boolean remove(StatType type) {
        UUID id = activeDisplays.remove(type);
        var entity = id != null ? plugin.getServer().getEntity(id) : null;
        if (entity != null) {
            entity.remove();
        }

        // removeLocation dulu, baru cek: kalau memang ada lokasi tersimpan buat kategori
        // ini, sekalian bersihin entity apapun yang masih nyangkut di situ (jaga-jaga ada
        // orphan yang gak lagi tercatat di activeDisplays sama sekali).
        YamlConfiguration yaml = loadYaml();
        if (yaml.contains(type.configKey())) {
            String worldName = yaml.getString(type.configKey() + ".world");
            var world = plugin.getServer().getWorld(worldName);
            if (world != null) {
                double x = yaml.getDouble(type.configKey() + ".x");
                double y = yaml.getDouble(type.configKey() + ".y");
                double z = yaml.getDouble(type.configKey() + ".z");
                purgeExactSpot(new Location(world, x, y, z));
            }
        }

        removeLocation(type);
        return id != null || entity != null;
    }

    /**
     * Purge manual: hapus TextDisplay hologram MILIK PLUGIN INI (yang ke-tag TAG_PREFIX)
     * dalam radius tertentu dari sebuah lokasi -- dipakai command "/lbhologram purge"
     * buat beres-beres cepat tanpa resiko kehapus TextDisplay builder lain yang kebetulan
     * ada di dekat situ.
     *
     * CATATAN buat numpukan hologram LAMA (yang di-spawn SEBELUM fix ini dipasang, jadi
     * belum ke-tag): itu otomatis kebersihin sendiri tanpa perlu command ini sama sekali,
     * begitu server di-restart atau plugin di-reload -- soalnya restoreAll() sekarang
     * bersihin dulu SEMUA TextDisplay (tag atau enggak) yang nyangkut persis di titik
     * lokasi tersimpan sebelum nge-spawn yang baru (lihat purgeExactSpot()).
     * Return jumlah entity yang dihapus.
     */
    public int purgeArea(Location center, double radius) {
        if (center.getWorld() == null) return 0;
        int count = 0;
        for (var entity : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (entity instanceof TextDisplay && entity.getScoreboardTags().stream().anyMatch(t -> t.startsWith(TAG_PREFIX))) {
                entity.remove();
                count++;
            }
        }
        return count;
    }

    public List<StatType> listActive() {
        return new ArrayList<>(activeDisplays.keySet());
    }

    /** Dipanggil tiap kali cache leaderboard di-refresh (data BARU) - re-render semua hologram. */
    public void updateAll() {
        for (Map.Entry<StatType, UUID> entry : activeDisplays.entrySet()) {
            var entity = plugin.getServer().getEntity(entry.getValue());
            if (entity instanceof TextDisplay display) {
                display.text(buildComponent(entry.getKey()));
            }
        }
    }

    /**
     * Dipanggil dari task animasi yang JAUH lebih sering (misal tiap 0.5 detik)
     * daripada refresh data (misal tiap 30 detik) - MURAH karena cuma maju 1 frame
     * animasi & re-render teks pakai data cache yang SAMA, TANPA query DB lagi.
     */
    public void tickAnimation() {
        if (activeDisplays.isEmpty()) return;
        if (!plugin.getConfig().getBoolean("hologram.animation.enabled", true)) return;

        List<?> frames = plugin.getConfig().getList("hologram.animation.frames");
        int frameCount = frames != null ? frames.size() : 0;
        if (frameCount == 0) return;

        animationFrameIndex = (animationFrameIndex + 1) % frameCount;
        updateAll();
    }

    private String currentAnimationFrame() {
        List<String> frames = plugin.getConfig().getStringList("hologram.animation.frames");
        if (frames.isEmpty()) return "";
        int index = animationFrameIndex % frames.size();
        return frames.get(index);
    }

    private Component buildComponent(StatType type) {
        List<LeaderboardEntry> top = plugin.getLeaderboardManager().getTopForHologram(type);
        int hologramSize = plugin.getLeaderboardManager().getHologramTopSize();

        String categoryShortName = plugin.getConfig().getString(
                "categories." + type.configKey() + ".short-name", type.configKey());
        String animFrame = currentAnimationFrame();

        StringBuilder sb = new StringBuilder();

        // Header - list of lines
        for (String line : plugin.getConfig().getStringList("hologram.format.header")) {
            appendLine(sb, applyGlobalPlaceholders(line, categoryShortName, animFrame));
        }

        // Rank lines 1..hologramSize - SELALU tampil semua slot, yang belum ada data
        // pakai template "empty-rank-line" (placeholder {rank} tetap kesubstitusi).
        String rankLineFormat = plugin.getConfig().getString("hologram.format.rank-line",
                "&f{rank}. {player}   &7[ &e{value} &7]");
        String emptyLineFormat = plugin.getConfig().getString("hologram.format.empty-rank-line",
                "&f{rank}. &8- - - - - - -    &7[   ]");

        for (int rank = 1; rank <= hologramSize; rank++) {
            String line;
            if (rank <= top.size()) {
                LeaderboardEntry e = top.get(rank - 1);
                line = rankLineFormat
                        .replace("{rank}", String.valueOf(rank))
                        .replace("{player}", e.getPlayerName())
                        .replace("{value}", ValueFormatter.format(type, e.getValue()));
            } else {
                line = emptyLineFormat.replace("{rank}", String.valueOf(rank));
            }
            appendLine(sb, applyGlobalPlaceholders(line, categoryShortName, animFrame));
        }

        // Divider
        String divider = plugin.getConfig().getString("hologram.format.divider", "");
        if (!divider.isEmpty()) {
            appendLine(sb, applyGlobalPlaceholders(divider, categoryShortName, animFrame));
        }

        // Footer - list of lines, support {top1_player} / {top1_value}
        String top1Player = !top.isEmpty() ? top.get(0).getPlayerName() : "-";
        String top1Value = !top.isEmpty() ? ValueFormatter.format(type, top.get(0).getValue()) : "-";

        for (String line : plugin.getConfig().getStringList("hologram.format.footer")) {
            String withTop1 = line.replace("{top1_player}", top1Player).replace("{top1_value}", top1Value);
            appendLine(sb, applyGlobalPlaceholders(withTop1, categoryShortName, animFrame));
        }

        if (sb.isEmpty()) {
            sb.append("&7(hologram.format kosong di config)");
        }

        return legacy.deserialize(sb.toString());
    }

    private void appendLine(StringBuilder sb, String line) {
        if (!sb.isEmpty()) sb.append("\n");
        sb.append(line);
    }

    private String applyGlobalPlaceholders(String line, String category, String animFrame) {
        return line.replace("{category}", category).replace("{anim}", animFrame);
    }

    // ==== Persistence sederhana pakai YAML config, dipanggil pas plugin enable buat restore ====

    private void saveLocation(StatType type, Location loc) {
        YamlConfiguration yaml = loadYaml();
        String path = type.configKey();
        yaml.set(path + ".world", loc.getWorld().getName());
        yaml.set(path + ".x", loc.getX());
        yaml.set(path + ".y", loc.getY());
        yaml.set(path + ".z", loc.getZ());
        try {
            yaml.save(storageFile);
        } catch (Exception e) {
            plugin.getLogger().warning("Gagal simpan lokasi hologram: " + e.getMessage());
        }
    }

    private void removeLocation(StatType type) {
        YamlConfiguration yaml = loadYaml();
        yaml.set(type.configKey(), null);
        try {
            yaml.save(storageFile);
        } catch (Exception e) {
            plugin.getLogger().warning("Gagal hapus lokasi hologram: " + e.getMessage());
        }
    }

    private YamlConfiguration loadYaml() {
        return YamlConfiguration.loadConfiguration(storageFile);
    }

    /** Dipanggil pas plugin enable, buat spawn ulang semua hologram yang udah pernah dibuat. */
    public void restoreAll() {
        if (!storageFile.exists()) return;
        YamlConfiguration yaml = loadYaml();

        for (StatType type : StatType.values()) {
            if (!yaml.contains(type.configKey())) continue;

            String worldName = yaml.getString(type.configKey() + ".world");
            var world = plugin.getServer().getWorld(worldName);
            if (world == null) {
                plugin.getLogger().warning("World '" + worldName + "' buat hologram " + type + " gak ketemu, skip restore.");
                continue;
            }

            double x = yaml.getDouble(type.configKey() + ".x");
            double y = yaml.getDouble(type.configKey() + ".y");
            double z = yaml.getDouble(type.configKey() + ".z");

            spawnDisplay(type, new Location(world, x, y, z));
        }
    }
}
