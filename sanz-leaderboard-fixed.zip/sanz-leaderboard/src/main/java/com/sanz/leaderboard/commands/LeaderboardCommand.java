package com.sanz.leaderboard.commands;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.StatType;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/** Dev-revisi: implement TabCompleter -- sebelumnya command ini gak punya saran tab sama sekali. */
public class LeaderboardCommand implements CommandExecutor, TabCompleter {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzLeaderboard plugin;

    public LeaderboardCommand(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }

        if (!player.hasPermission("sanzleaderboard.use")) {
            player.sendMessage(LEGACY.deserialize("&cKamu gak punya izin buat pakai command ini."));
            return true;
        }

        if (args.length == 0) {
            plugin.getGui().openMainMenu(player);
            return true;
        }

        StatType type = StatType.fromConfigKey(args[0]);
        if (type == null) {
            player.sendMessage(LEGACY.deserialize("&cKategori gak valid. Pilihan: " + validCategories()));
            return true;
        }

        if (!plugin.getLeaderboardManager().isEnabled(type)) {
            player.sendMessage(LEGACY.deserialize("&cKategori itu lagi dimatiin di config."));
            return true;
        }

        plugin.getGui().openCategory(player, type);
        return true;
    }

    private String validCategories() {
        return String.join(", ", categoryKeys());
    }

    private List<String> categoryKeys() {
        List<String> keys = new ArrayList<>();
        for (StatType type : StatType.values()) {
            keys.add(type.configKey());
        }
        return keys;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return categoryKeys();
        }
        return List.of();
    }
}
