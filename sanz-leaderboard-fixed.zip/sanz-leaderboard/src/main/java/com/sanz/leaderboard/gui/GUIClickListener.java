package com.sanz.leaderboard.gui;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.StatType;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class GUIClickListener implements Listener {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzLeaderboard plugin;

    public GUIClickListener(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        String title = plugin.getConfig().getString("gui.title", "&8&lSanz Leaderboard");
        String mainTitle = LEGACY.serialize(LEGACY.deserialize(title));

        String viewTitle = LEGACY.serialize(event.getView().title());

        boolean isMainMenu = viewTitle.equals(mainTitle);
        boolean isCategoryMenu = isCategoryTitle(viewTitle);

        if (!isMainMenu && !isCategoryMenu) return;
        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;

        if (isMainMenu) {
            for (StatType type : StatType.values()) {
                if (!plugin.getLeaderboardManager().isEnabled(type)) continue;
                String displayName = plugin.getLeaderboardManager().getDisplayName(type);
                ItemMeta meta = clicked.getItemMeta();
                if (meta != null && meta.hasDisplayName()
                        && LEGACY.serialize(meta.displayName()).equals(LEGACY.serialize(LEGACY.deserialize(displayName)))) {
                    plugin.getGui().openCategory(player, type);
                    return;
                }
            }
        } else {
            if (clicked.getType() == Material.ARROW) {
                plugin.getGui().openMainMenu(player);
            }
        }
    }

    private boolean isCategoryTitle(String viewTitle) {
        for (StatType type : StatType.values()) {
            String displayName = plugin.getLeaderboardManager().getDisplayName(type);
            if (viewTitle.equals(LEGACY.serialize(LEGACY.deserialize(displayName)))) {
                return true;
            }
        }
        return false;
    }
}
