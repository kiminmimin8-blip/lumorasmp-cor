package com.sanz.leaderboard.listeners;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.StatType;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Ngasih reward (money/gems) berkala ke player yang lagi kedeteksi AFK
 * (lewat AFKTracker yang sama dipakai buat kategori AFK_TIME - termasuk
 * baca metadata AxAFKZone kalau plugin itu ke-install, jadi "AFK zone"
 * di server kamu otomatis ke-reward juga tanpa perlu integrasi khusus).
 *
 * Diaktifin/diatur semua dari config.yml bagian "afk-reward" - gak perlu
 * ubah kode buat ganti jumlah reward atau interval-nya.
 */
public class AfkRewardManager {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final SanzLeaderboard plugin;
    private final AFKTracker afkTracker;
    private final Map<UUID, Long> lastRewardTick = new ConcurrentHashMap<>();

    public AfkRewardManager(SanzLeaderboard plugin, AFKTracker afkTracker) {
        this.plugin = plugin;
        this.afkTracker = afkTracker;
    }

    /** Dipanggil berkala (main thread) - cek semua player online, kasih reward kalau AFK & interval udah lewat. */
    public void tick() {
        if (!plugin.getConfig().getBoolean("afk-reward.enabled", false)) return;

        long intervalTicks = plugin.getConfig().getLong("afk-reward.interval-seconds", 60) * 20L;
        double moneyReward = plugin.getConfig().getDouble("afk-reward.money", 0);
        double gemsReward = plugin.getConfig().getDouble("afk-reward.gems", 0);
        boolean notify = plugin.getConfig().getBoolean("afk-reward.notify-player", true);

        long now = plugin.getServer().getCurrentTick();

        for (Player player : plugin.getServer().getOnlinePlayers()) {
            if (!afkTracker.isAfk(player)) {
                lastRewardTick.remove(player.getUniqueId());
                continue;
            }

            long last = lastRewardTick.getOrDefault(player.getUniqueId(), 0L);
            if (now - last < intervalTicks) continue;

            lastRewardTick.put(player.getUniqueId(), now);
            giveReward(player, moneyReward, gemsReward, notify);
        }
    }

    private void giveReward(Player player, double money, double gems, boolean notify) {
        boolean gotMoney = money > 0 && plugin.getVaultHook().isEnabled() && plugin.getVaultHook().deposit(player, money);
        boolean gotGems = gems > 0;

        if (gotGems) {
            plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () ->
                    plugin.getDatabase().increment(player.getUniqueId(), player.getName(), StatType.GEMS, gems)
            );
        }

        if (notify && (gotMoney || gotGems)) {
            StringBuilder msg = new StringBuilder("&7[AFK Reward] &aKamu dapet ");
            if (gotMoney) msg.append("&e$").append((long) money);
            if (gotMoney && gotGems) msg.append(" &7dan ");
            if (gotGems) msg.append("&a").append((long) gems).append(" gems");
            player.sendMessage(LEGACY.deserialize(msg.toString()));
        }
    }

    /** Dipanggil pas plugin disable, biar gak nyimpen sampah player yang udah quit. */
    public void clear() {
        lastRewardTick.clear();
    }
}
