package com.sanz.leaderboard.data;

import com.sanz.leaderboard.SanzLeaderboard;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Wrapper SQLite sederhana. Semua query dipanggil dari thread async
 * (dijamin di layer atas - listeners/manager), koneksi ini single-connection
 * dengan synchronized block biar aman dari race condition SQLite.
 */
public class Database {

    private final SanzLeaderboard plugin;
    private Connection connection;
    private final Object lock = new Object();

    public Database(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    public boolean connect() {
        try {
            File dataFolder = plugin.getDataFolder();
            if (!dataFolder.exists()) {
                dataFolder.mkdirs();
            }
            String fileName = plugin.getConfig().getString("storage.file", "database.db");
            File dbFile = new File(dataFolder, fileName);

            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());

            createTables();
            return true;
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Gagal konek ke database SQLite", e);
            return false;
        }
    }

    private void createTables() throws SQLException {
        String sql = """
                CREATE TABLE IF NOT EXISTS player_stats (
                    uuid TEXT PRIMARY KEY,
                    player_name TEXT NOT NULL,
                    kills INTEGER NOT NULL DEFAULT 0,
                    deaths INTEGER NOT NULL DEFAULT 0,
                    playtime_seconds INTEGER NOT NULL DEFAULT 0,
                    money_cache REAL NOT NULL DEFAULT 0,
                    blocks_mined INTEGER NOT NULL DEFAULT 0,
                    blocks_placed INTEGER NOT NULL DEFAULT 0,
                    shards INTEGER NOT NULL DEFAULT 0
                );
                """;
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql);
        }
    }

    public void disconnect() {
        synchronized (lock) {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Gagal nutup koneksi database", e);
            }
        }
    }

    /** Pastiin row buat player itu ada, kalau belum bikin baru. */
    public void ensurePlayer(UUID uuid, String name) {
        synchronized (lock) {
            String sql = "INSERT INTO player_stats (uuid, player_name) VALUES (?, ?) " +
                    "ON CONFLICT(uuid) DO UPDATE SET player_name = excluded.player_name;";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, uuid.toString());
                ps.setString(2, name);
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Gagal ensurePlayer buat " + name, e);
            }
        }
    }

    /** Nambah value ke satu kolom stat (increment). Aman dipanggil sering-sering. */
    public void increment(UUID uuid, String playerName, StatType type, double amount) {
        synchronized (lock) {
            String sql = "UPDATE player_stats SET " + type.columnName() + " = " + type.columnName() +
                    " + ? WHERE uuid = ?;";
            try {
                ensurePlayerInternal(uuid, playerName);
                try (PreparedStatement ps = connection.prepareStatement(sql)) {
                    ps.setDouble(1, amount);
                    ps.setString(2, uuid.toString());
                    ps.executeUpdate();
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Gagal increment " + type + " buat " + playerName, e);
            }
        }
    }

    /** Set langsung value stat (dipakai buat sync money dari Vault, atau command admin). */
    public void setValue(UUID uuid, String playerName, StatType type, double value) {
        synchronized (lock) {
            String sql = "UPDATE player_stats SET " + type.columnName() + " = ? WHERE uuid = ?;";
            try {
                ensurePlayerInternal(uuid, playerName);
                try (PreparedStatement ps = connection.prepareStatement(sql)) {
                    ps.setDouble(1, value);
                    ps.setString(2, uuid.toString());
                    ps.executeUpdate();
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Gagal set " + type + " buat " + playerName, e);
            }
        }
    }

    public double getValue(UUID uuid, StatType type) {
        synchronized (lock) {
            String sql = "SELECT " + type.columnName() + " FROM player_stats WHERE uuid = ?;";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return rs.getDouble(1);
                    }
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Gagal getValue " + type, e);
            }
            return 0;
        }
    }

    /** Ambil top-N buat satu kategori. Dipanggil dari LeaderboardManager secara berkala (async). */
    public List<LeaderboardEntry> getTop(StatType type, int limit) {
        List<LeaderboardEntry> result = new ArrayList<>();
        synchronized (lock) {
            String sql = "SELECT uuid, player_name, " + type.columnName() +
                    " FROM player_stats ORDER BY " + type.columnName() + " DESC LIMIT ?;";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setInt(1, limit);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        UUID uuid = UUID.fromString(rs.getString("uuid"));
                        String name = rs.getString("player_name");
                        double value = rs.getDouble(3);
                        result.add(new LeaderboardEntry(uuid, name, value));
                    }
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Gagal getTop " + type, e);
            }
        }
        return result;
    }

    private void ensurePlayerInternal(UUID uuid, String name) throws SQLException {
        // dipanggil dari dalam block synchronized yang udah lock, jadi langsung pakai connection
        String sql = "INSERT INTO player_stats (uuid, player_name) VALUES (?, ?) " +
                "ON CONFLICT(uuid) DO UPDATE SET player_name = excluded.player_name;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setString(2, name);
            ps.executeUpdate();
        }
    }
}
