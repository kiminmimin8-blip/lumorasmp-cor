package com.sanz.leaderboard.data;

import com.sanz.leaderboard.SanzLeaderboard;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Wrapper SQLite sederhana. Semua query dipanggil dari thread async
 * (dijamin di layer atas - listeners/manager), koneksi ini single-connection
 * dengan synchronized block biar aman dari race condition SQLite.
 */
public class Database {

    private final SanzLeaderboard plugin;
    private Connection connection;
    private final Object lock = new Object();

    public Database(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    public boolean connect() {
        try {
            File dataFolder = plugin.getDataFolder();
            if (!dataFolder.exists()) {
                dataFolder.mkdirs();
            }
            String fileName = plugin.getConfig().getString("storage.file", "database.db");
            File dbFile = new File(dataFolder, fileName);

            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());

            createTables();
            return true;
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Gagal konek ke database SQLite", e);
            return false;
        }
    }

    private void createTables() throws SQLException {
        String sql = """
                CREATE TABLE IF NOT EXISTS player_stats (
                    uuid TEXT PRIMARY KEY,
                    player_name TEXT NOT NULL,
                    kills INTEGER NOT NULL DEFAULT 0,
                    kills_mob INTEGER NOT NULL DEFAULT 0,
                    deaths INTEGER NOT NULL DEFAULT 0,
                    playtime_seconds INTEGER NOT NULL DEFAULT 0,
                    afk_seconds INTEGER NOT NULL DEFAULT 0,
                    money_cache REAL NOT NULL DEFAULT 0,
                    blocks_mined INTEGER NOT NULL DEFAULT 0,
                    blocks_placed INTEGER NOT NULL DEFAULT 0,
                    gems INTEGER NOT NULL DEFAULT 0
                );
                """;
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql);
        }
        migrateMissingColumns();
    }

    /**
     * Dev-revisi: database.db yang UDAH ADA dari sebelum kolom baru (afk_seconds,
     * kills_mob, dst) ditambah TIDAK bakal otomatis punya kolom itu -- "CREATE
     * TABLE IF NOT EXISTS" di atas gak ngaruh apa-apa ke tabel yang udah exist
     * (bukan migration tool). Makanya perlu ALTER TABLE eksplisit di sini.
     *
     * FIX: sebelumnya pakai "ALTER TABLE ... ADD COLUMN IF NOT EXISTS", tapi
     * native SQLite yang dipakai sqlite-jdbc 3.49.1.0 belum dukung syntax
     * "IF NOT EXISTS" buat ADD COLUMN -- migrasi ini SELALU gagal dengan
     * "SQL error or missing database (near "EXISTS": syntax error)" di server
     * manapun yang punya database.db lama. Akibatnya kolom kills_mob gak
     * pernah kebentuk sama sekali (bahkan CREATE TABLE-nya sendiri sebelum
     * ini juga gak nyebut kills_mob), jadi kill-mob tracking + leaderboard
     * KILLS_MOB error terus ("no such column: kills_mob").
     *
     * Sekarang dicek manual pakai PRAGMA table_info(player_stats) buat tau
     * kolom apa yang udah ada, baru ALTER TABLE ADD COLUMN (tanpa "IF NOT
     * EXISTS") untuk kolom yang belum ada. Aman dijalankan berkali-kali
     * karena kolom yang udah ada di-skip, gak akan kena "duplicate column".
     */
    private void migrateMissingColumns() {
        java.util.Set<String> existing = new java.util.HashSet<>();
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery("PRAGMA table_info(player_stats);")) {
            while (rs.next()) {
                existing.add(rs.getString("name").toLowerCase());
            }
        } catch (SQLException e) {
            plugin.getLogger().log(Level.WARNING, "Gagal baca struktur tabel player_stats buat migrasi kolom", e);
            return;
        }

        java.util.Map<String, String> requiredColumns = new java.util.LinkedHashMap<>();
        requiredColumns.put("kills_mob", "INTEGER NOT NULL DEFAULT 0");
        requiredColumns.put("afk_seconds", "INTEGER NOT NULL DEFAULT 0");

        for (var entry : requiredColumns.entrySet()) {
            String column = entry.getKey();
            if (existing.contains(column.toLowerCase())) {
                continue;
            }
            String sql = "ALTER TABLE player_stats ADD COLUMN " + column + " " + entry.getValue() + ";";
            try (Statement stmt = connection.createStatement()) {
                stmt.execute(sql);
                plugin.getLogger().info("Migrasi: kolom '" + column + "' ditambahin ke player_stats.");
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Gagal migrasi kolom " + column
                        + " (kategori terkait gak akan bisa nyimpen data sampai ini dibenerin manual)", e);
            }
        }
    }

    public void disconnect() {
        synchronized (lock) {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Gagal nutup koneksi database", e);
            }
        }
    }

    /** Pastiin row buat player itu ada, kalau belum bikin baru. */
    public void ensurePlayer(UUID uuid, String name) {
        synchronized (lock) {
            String sql = "INSERT INTO player_stats (uuid, player_name) VALUES (?, ?) " +
                    "ON CONFLICT(uuid) DO UPDATE SET player_name = excluded.player_name;";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, uuid.toString());
                ps.setString(2, name);
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Gagal ensurePlayer buat " + name, e);
            }
        }
    }

    /** Nambah value ke satu kolom stat (increment). Aman dipanggil sering-sering. */
    public void increment(UUID uuid, String playerName, StatType type, double amount) {
        synchronized (lock) {
            String sql = "UPDATE player_stats SET " + type.columnName() + " = " + type.columnName() +
                    " + ? WHERE uuid = ?;";
            try {
                ensurePlayerInternal(uuid, playerName);
                try (PreparedStatement ps = connection.prepareStatement(sql)) {
                    ps.setDouble(1, amount);
                    ps.setString(2, uuid.toString());
                    ps.executeUpdate();
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Gagal increment " + type + " buat " + playerName, e);
            }
        }
    }

    /** Set langsung value stat (dipakai buat sync money dari Vault, atau command admin). */
    public void setValue(UUID uuid, String playerName, StatType type, double value) {
        synchronized (lock) {
            String sql = "UPDATE player_stats SET " + type.columnName() + " = ? WHERE uuid = ?;";
            try {
                ensurePlayerInternal(uuid, playerName);
                try (PreparedStatement ps = connection.prepareStatement(sql)) {
                    ps.setDouble(1, value);
                    ps.setString(2, uuid.toString());
                    ps.executeUpdate();
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Gagal set " + type + " buat " + playerName, e);
            }
        }
    }

    public double getValue(UUID uuid, StatType type) {
        synchronized (lock) {
            String sql = "SELECT " + type.columnName() + " FROM player_stats WHERE uuid = ?;";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return rs.getDouble(1);
                    }
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Gagal getValue " + type, e);
            }
            return 0;
        }
    }

    /** Ambil top-N buat satu kategori. Dipanggil dari LeaderboardManager secara berkala (async). */
    public List<LeaderboardEntry> getTop(StatType type, int limit) {
        List<LeaderboardEntry> result = new ArrayList<>();
        synchronized (lock) {
            String sql = "SELECT uuid, player_name, " + type.columnName() +
                    " FROM player_stats ORDER BY " + type.columnName() + " DESC LIMIT ?;";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setInt(1, limit);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        UUID uuid = UUID.fromString(rs.getString("uuid"));
                        String name = rs.getString("player_name");
                        double value = rs.getDouble(3);
                        result.add(new LeaderboardEntry(uuid, name, value));
                    }
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Gagal getTop " + type, e);
            }
        }
        return result;
    }

    /**
     * Dev-revisi: ambil SEMUA player diurutkan (tanpa LIMIT), dipakai
     * LeaderboardManager buat bangun cache rank+value per player sekali
     * jalan (bukan query terpisah per player tiap ada placeholder
     * di-request) -- lihat javadoc LeaderboardManager.
     *
     * CATATAN SKALABILITAS (didokumentasikan, bukan silent gap): ini full
     * table scan tanpa LIMIT. Untuk SMP dengan ribuan player unik yang
     * pernah join, query ini bisa mulai berat kalau dipanggil tiap
     * refresh-interval-seconds. Untuk server ukuran normal (ratusan
     * player) harusnya masih ringan di SQLite. Kalau jadi masalah nyata,
     * pertimbangkan LIMIT eksplisit + rank dihitung cuma sampai batas itu
     * (placeholder rank di luar batas return "tidak ada data").
     */
    public List<LeaderboardEntry> getAllOrdered(StatType type) {
        List<LeaderboardEntry> result = new ArrayList<>();
        synchronized (lock) {
            String sql = "SELECT uuid, player_name, " + type.columnName() +
                    " FROM player_stats ORDER BY " + type.columnName() + " DESC;";
            try (PreparedStatement ps = connection.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    UUID uuid = UUID.fromString(rs.getString("uuid"));
                    String name = rs.getString("player_name");
                    double value = rs.getDouble(3);
                    result.add(new LeaderboardEntry(uuid, name, value));
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Gagal getAllOrdered " + type, e);
            }
        }
        return result;
    }

    private void ensurePlayerInternal(UUID uuid, String name) throws SQLException {
        // dipanggil dari dalam block synchronized yang udah lock, jadi langsung pakai connection
        String sql = "INSERT INTO player_stats (uuid, player_name) VALUES (?, ?) " +
                "ON CONFLICT(uuid) DO UPDATE SET player_name = excluded.player_name;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setString(2, name);
            ps.executeUpdate();
        }
    }
}
