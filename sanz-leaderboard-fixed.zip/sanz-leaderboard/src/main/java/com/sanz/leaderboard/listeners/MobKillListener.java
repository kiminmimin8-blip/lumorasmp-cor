package com.sanz.leaderboard.listeners;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.StatType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

/**
 * Kill mob (bukan player) - dipisah dari CombatListener yang khusus PlayerDeathEvent.
 * PENTING: EntityDeathEvent JUGA fire buat kematian player (PlayerDeathEvent adalah
 * subclass-nya), jadi WAJIB exclude victim yang Player di sini, biar gak double-count
 * sama CombatListener (yang udah nanganin kill player -> kategori KILLS terpisah).
 */
public class MobKillListener implements Listener {

    private final SanzLeaderboard plugin;

    public MobKillListener(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onEntityDeath(EntityDeathEvent event) {
        if (event.getEntity() instanceof Player) return; // player death udah dihandle CombatListener

        Player killer = event.getEntity().getKiller();
        if (killer == null) return;

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () ->
                plugin.getDatabase().increment(killer.getUniqueId(), killer.getName(), StatType.KILLS_MOB, 1)
        );
    }
}
