package com.sanz.leaderboard;

import com.sanz.leaderboard.commands.GemsCommand;
import com.sanz.leaderboard.commands.HologramCommand;
import com.sanz.leaderboard.commands.LeaderboardCommand;
import com.sanz.leaderboard.data.Database;
import com.sanz.leaderboard.gui.GUIClickListener;
import com.sanz.leaderboard.gui.LeaderboardGUI;
import com.sanz.leaderboard.hook.PlaceholderHook;
import com.sanz.leaderboard.hook.VaultHook;
import com.sanz.leaderboard.leaderboard.LeaderboardHologram;
import com.sanz.leaderboard.leaderboard.LeaderboardManager;
import com.sanz.leaderboard.listeners.AFKTracker;
import com.sanz.leaderboard.listeners.AfkRewardManager;
import com.sanz.leaderboard.listeners.BlockListener;
import com.sanz.leaderboard.listeners.BlockStatsBuffer;
import com.sanz.leaderboard.listeners.CombatListener;
import com.sanz.leaderboard.listeners.MobKillListener;
import com.sanz.leaderboard.listeners.PlaytimeListener;
import org.bukkit.plugin.java.JavaPlugin;

public class SanzLeaderboard extends JavaPlugin {

    private static SanzLeaderboard instance;

    private Database database;
    private VaultHook vaultHook;
    private LeaderboardManager leaderboardManager;
    private LeaderboardHologram hologram;
    private LeaderboardGUI gui;
    private BlockStatsBuffer blockStatsBuffer;
    private AFKTracker afkTracker;
    private PlaytimeListener playtimeListener;
    private AfkRewardManager afkRewardManager;
    private boolean placeholderApiHooked;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        database = new Database(this);
        if (!database.connect()) {
            getLogger().severe("Gagal konek ke database, plugin dimatiin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        vaultHook = new VaultHook(this);
        vaultHook.setup();

        leaderboardManager = new LeaderboardManager(this);
        hologram = new LeaderboardHologram(this);
        gui = new LeaderboardGUI(this);
        blockStatsBuffer = new BlockStatsBuffer(this);
        afkTracker = new AFKTracker(this);
        playtimeListener = new PlaytimeListener(this, afkTracker);
        afkRewardManager = new AfkRewardManager(this, afkTracker);

        registerListeners();
        registerCommands();
        setupPlaceholderApi();

        // Refresh pertama kali langsung, terus baru mulai task berkala
        getServer().getScheduler().runTaskAsynchronously(this, () -> {
            leaderboardManager.refresh();
            getServer().getScheduler().runTask(this, () -> {
                hologram.restoreAll();
                hologram.updateAll();
            });
        });

        startTasks();

        getLogger().info("SanzLeaderboard enabled - kills, kill mob, deaths, playtime+afktime (dengan AFK detection & reward), money, blocks, gems siap ditrack.");
    }

    @Override
    public void onDisable() {
        if (blockStatsBuffer != null) {
            blockStatsBuffer.flush();
        }
        if (playtimeListener != null) {
            playtimeListener.flushOnlineSessions();
        }
        if (afkRewardManager != null) {
            afkRewardManager.clear();
        }
        if (database != null) {
            database.disconnect();
        }
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new MobKillListener(this), this);
        getServer().getPluginManager().registerEvents(new BlockListener(blockStatsBuffer), this);
        getServer().getPluginManager().registerEvents(afkTracker, this);
        getServer().getPluginManager().registerEvents(playtimeListener, this);
        getServer().getPluginManager().registerEvents(new GUIClickListener(this), this);
    }

    private void registerCommands() {
        LeaderboardCommand leaderboardCommand = new LeaderboardCommand(this);
        getCommand("leaderboard").setExecutor(leaderboardCommand);
        getCommand("leaderboard").setTabCompleter(leaderboardCommand);

        GemsCommand gemsCommand = new GemsCommand(this);
        getCommand("gems").setExecutor(gemsCommand);
        getCommand("gems").setTabCompleter(gemsCommand);

        HologramCommand hologramCommand = new HologramCommand(this);
        getCommand("lbhologram").setExecutor(hologramCommand);
        getCommand("lbhologram").setTabCompleter(hologramCommand);
    }

    /**
     * PlaceholderAPI OPSIONAL (softdepend). Pengecekan
     * isPluginEnabled("PlaceholderAPI") ini WAJIB ada SEBELUM baris
     * "new PlaceholderHook(...)" -- kalau langsung instantiate tanpa cek,
     * begitu class PlaceholderHook di-classload (yang butuh class
     * PlaceholderExpansion dari jar PlaceholderAPI), server bakal lempar
     * NoClassDefFoundError kalau PlaceholderAPI ternyata gak ke-install.
     * Java baru classload sebuah class pas benar-benar dipakai (bukan
     * pas di-import), jadi selama pengecekan ini ada duluan, aman.
     */
    private void setupPlaceholderApi() {
        if (!getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            getLogger().info("[SanzLeaderboard] PlaceholderAPI tidak terdeteksi -- placeholder %sanzleaderboard_...% tidak akan aktif (opsional, plugin tetap jalan normal tanpa itu).");
            return;
        }
        try {
            new PlaceholderHook(this).register();
            placeholderApiHooked = true;
            getLogger().info("[SanzLeaderboard] Placeholder terdaftar ke PlaceholderAPI dengan identifier '"
                    + getConfig().getString("placeholder.identifier", "sanzleaderboard") + "'.");
        } catch (Exception e) {
            getLogger().warning("[SanzLeaderboard] Gagal register PlaceholderHook: " + e.getMessage());
        }
    }

    private void startTasks() {
        long refreshTicks = getConfig().getLong("refresh-interval-seconds", 30) * 20L;

        // Task async: flush buffer block stats + playtime + refresh cache leaderboard
        getServer().getScheduler().runTaskTimerAsynchronously(this, () -> {
            blockStatsBuffer.flush();
            playtimeListener.flushOnlineSessions();
            leaderboardManager.refresh();

            // Update hologram harus di main thread (interaksi entity)
            getServer().getScheduler().runTask(this, () -> hologram.updateAll());
        }, refreshTicks, refreshTicks);

        // Task animasi hologram - TERPISAH dan lebih cepat dari refresh data di atas,
        // biar teks bisa "hidup" (cycle warna dll) tanpa perlu query database ulang.
        long animationTicks = Math.max(1, getConfig().getLong("hologram.animation.interval-ticks", 10));
        getServer().getScheduler().runTaskTimer(this, hologram::tickAnimation, animationTicks, animationTicks);

        // Task AFK reward - cek tiap refresh-interval yang sama, kasih reward ke player yang lagi AFK
        getServer().getScheduler().runTaskTimer(this, afkRewardManager::tick, refreshTicks, refreshTicks);
    }

    public static SanzLeaderboard getInstance() {
        return instance;
    }

    public Database getDatabase() {
        return database;
    }

    public VaultHook getVaultHook() {
        return vaultHook;
    }

    public LeaderboardManager getLeaderboardManager() {
        return leaderboardManager;
    }

    public LeaderboardHologram getHologram() {
        return hologram;
    }

    public LeaderboardGUI getGui() {
        return gui;
    }

    public AFKTracker getAfkTracker() {
        return afkTracker;
    }

    public AfkRewardManager getAfkRewardManager() {
        return afkRewardManager;
    }
}
