package com.sanz.leaderboard.listeners;

import com.sanz.leaderboard.SanzLeaderboard;
import com.sanz.leaderboard.data.StatType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Track lama sesi tiap player (dari join sampai quit), dan sync balance Vault
 * ke kolom money_cache pas join biar leaderboard money selalu update tanpa
 * perlu polling semua player terus-terusan.
 *
 * Dev-revisi: status AFK (dicek lewat AFKTracker) SEKARANG dialihkan ke
 * kategori StatType.AFK_TIME, BUKAN dibuang begitu saja seperti sebelumnya.
 * Jadi ada 2 leaderboard: PLAYTIME (waktu aktif beneran main) dan AFK_TIME
 * (waktu AFK, termasuk AFK farm lewat AxAFKZone kalau plugin itu ke-install
 * dan nge-set metadata "afk"/"isAfk" ke true). Granularitasnya seukuran
 * refresh-interval-seconds di config (checkpoint di-flush berkala).
 */
public class PlaytimeListener implements Listener {

    private final SanzLeaderboard plugin;
    private final AFKTracker afkTracker;
    private final Map<UUID, Long> sessionCheckpoint = new ConcurrentHashMap<>();

    public PlaytimeListener(SanzLeaderboard plugin, AFKTracker afkTracker) {
        this.plugin = plugin;
        this.afkTracker = afkTracker;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        sessionCheckpoint.put(player.getUniqueId(), System.currentTimeMillis());
        afkTracker.markActive(player);

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            plugin.getDatabase().ensurePlayer(player.getUniqueId(), player.getName());

            if (plugin.getVaultHook().isEnabled()) {
                double balance = plugin.getVaultHook().getBalance(player);
                plugin.getDatabase().setValue(player.getUniqueId(), player.getName(), StatType.MONEY, balance);
            }
        });
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        Long checkpoint = sessionCheckpoint.remove(player.getUniqueId());
        afkTracker.remove(player.getUniqueId());
        if (checkpoint == null) return;

        long seconds = (System.currentTimeMillis() - checkpoint) / 1000L;
        boolean wasAfk = afkTracker.isAfk(player);
        StatType targetCategory = wasAfk ? StatType.AFK_TIME : StatType.PLAYTIME;

        // Sinkron balance final juga pas quit
        double balance = plugin.getVaultHook().isEnabled() ? plugin.getVaultHook().getBalance(player) : -1;

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            if (seconds > 0) {
                plugin.getDatabase().increment(player.getUniqueId(), player.getName(), targetCategory, seconds);
            }
            if (balance >= 0) {
                plugin.getDatabase().setValue(player.getUniqueId(), player.getName(), StatType.MONEY, balance);
            }
        });
    }

    /**
     * Dipanggil dari repeating task berkala, buat flush playtime/afktime player yang masih
     * online tanpa nunggu quit. Status AFK dicek PAS checkpoint ini -- durasi sejak checkpoint
     * terakhir masuk ke PLAYTIME kalau lagi aktif, atau AFK_TIME kalau lagi AFK, gak pernah
     * dibuang begitu aja.
     * Catatan: dipanggil dari thread async (sama kayak pola block-stats-buffer),
     * Player#getPlayer/hasMetadata di sini cuma baca data ringan.
     */
    public void flushOnlineSessions() {
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Long> entry : sessionCheckpoint.entrySet()) {
            UUID uuid = entry.getKey();
            Player player = plugin.getServer().getPlayer(uuid);
            if (player == null) continue;

            long seconds = (now - entry.getValue()) / 1000L;
            sessionCheckpoint.put(uuid, now);
            if (seconds <= 0) continue;

            boolean afk = afkTracker.isAfk(player);
            StatType targetCategory = afk ? StatType.AFK_TIME : StatType.PLAYTIME;

            String name = player.getName();
            plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () ->
                    plugin.getDatabase().increment(uuid, name, targetCategory, seconds)
            );
        }
    }
}
