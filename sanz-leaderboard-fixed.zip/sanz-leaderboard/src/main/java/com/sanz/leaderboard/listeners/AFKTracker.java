package com.sanz.leaderboard.listeners;

import com.sanz.leaderboard.SanzLeaderboard;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.metadata.MetadataValue;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Nge-track kapan terakhir player aktif (gerak/klik/command/chat), buat dipakai
 * PlaytimeListener nentuin apakah waktu itu dihitung playtime apa nggak.
 *
 * Selain deteksi internal (idle-timeout), plugin ini juga ikut baca metadata umum
 * yang biasa di-set plugin AFK lain (AxAFKZone, Essentials, dll) - kalau plugin lain
 * udah nandain player itu "afk"/"isAfk"/"AFK" = true, kita ikut anggap AFK juga,
 * tanpa perlu depend keras ke plugin itu.
 */
public class AFKTracker implements Listener {

    private static final String[] KNOWN_AFK_METADATA_KEYS = {"afk", "isAfk", "AFK", "isAFK"};

    private final SanzLeaderboard plugin;
    private final java.util.Map<UUID, AtomicLong> lastActivity = new ConcurrentHashMap<>();

    public AFKTracker(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    public void markActive(Player player) {
        lastActivity.computeIfAbsent(player.getUniqueId(), k -> new AtomicLong())
                .set(System.currentTimeMillis());
    }

    public void remove(UUID uuid) {
        lastActivity.remove(uuid);
    }

    /**
     * True kalau player dianggap AFK sekarang - baik lewat idle-timeout internal
     * atau lewat metadata dari plugin AFK lain (kalau ada).
     */
    public boolean isAfk(Player player) {
        if (!plugin.getConfig().getBoolean("afk.enabled", true)) {
            return false;
        }

        // Cek metadata dari plugin AFK lain dulu (AxAFKZone, dll)
        for (String key : KNOWN_AFK_METADATA_KEYS) {
            if (player.hasMetadata(key)) {
                for (MetadataValue value : player.getMetadata(key)) {
                    if (value.asBoolean()) {
                        return true;
                    }
                }
            }
        }

        // Fallback: idle-timeout internal
        AtomicLong last = lastActivity.get(player.getUniqueId());
        if (last == null) {
            return false;
        }
        long idleSeconds = (System.currentTimeMillis() - last.get()) / 1000L;
        long timeout = plugin.getConfig().getLong("afk.idle-timeout-seconds", 300);
        return idleSeconds >= timeout;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        // Cuma hitung kalau beneran pindah block, bukan cuma nengok (look-only movement)
        if (event.getFrom().getBlockX() != event.getTo().getBlockX()
                || event.getFrom().getBlockY() != event.getTo().getBlockY()
                || event.getFrom().getBlockZ() != event.getTo().getBlockZ()) {
            markActive(event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onInteract(PlayerInteractEvent event) {
        markActive(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        markActive(event.getPlayer());
    }
}
