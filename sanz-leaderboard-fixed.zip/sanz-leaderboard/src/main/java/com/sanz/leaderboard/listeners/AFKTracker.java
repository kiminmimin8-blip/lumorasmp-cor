package com.sanz.leaderboard.listeners;

import com.sanz.leaderboard.SanzLeaderboard;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.metadata.MetadataValue;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Nge-track kapan terakhir player aktif (gerak/klik/command/chat), buat dipakai
 * PlaytimeListener nentuin apakah waktu itu dihitung playtime apa nggak.
 *
 * BUG FIX (playtime & gems gak kehitung bener di AFK zone): sebelumnya deteksi
 * AxAFKZone di sini CUMA lewat Bukkit metadata ("afk"/"isAfk"/"AFK"/"isAFK"),
 * padahal AxAFKZone TIDAK PERNAH nge-set metadata itu ke player -- plugin itu
 * cuma expose status-nya lewat placeholder PlaceholderAPI (%axafkzone_afk%,
 * true/false). Akibatnya player yang lagi AFK farming di zona AxAFKZone gak
 * pernah kedetek AFK oleh plugin ini (sampe idle-timeout internal numpuk lama
 * banget / gak numpuk sama sekali kalau AxAFKZone-nya nge-trigger aksi
 * berkala yang ke-anggap "aktivitas"), sehingga: (1) waktu di zona AFK malah
 * kehitung ke PLAYTIME (bukan AFK_TIME), dan (2) afk-reward.gems gak pernah
 * ke-trigger karena isAfk() keburu return false.
 *
 * FIX: sekarang isAfk() cek placeholder %axafkzone_afk% (via PlaceholderAPI,
 * kalau plugin itu ke-install) SEBAGAI SUMBER UTAMA, baru fallback ke metadata
 * generik (buat plugin AFK lain yang emang beneran pakai metadata) dan
 * idle-timeout internal kalau semuanya gak ke-detect.
 */
public class AFKTracker implements Listener {

    private static final String[] KNOWN_AFK_METADATA_KEYS = {"afk", "isAfk", "AFK", "isAFK"};

    private final SanzLeaderboard plugin;
    private final java.util.Map<UUID, AtomicLong> lastActivity = new ConcurrentHashMap<>();

    public AFKTracker(SanzLeaderboard plugin) {
        this.plugin = plugin;
    }

    public void markActive(Player player) {
        lastActivity.computeIfAbsent(player.getUniqueId(), k -> new AtomicLong())
                .set(System.currentTimeMillis());
    }

    public void remove(UUID uuid) {
        lastActivity.remove(uuid);
    }

    /**
     * True kalau player dianggap AFK sekarang - baik lewat idle-timeout internal
     * atau lewat metadata dari plugin AFK lain (kalau ada).
     */
    public boolean isAfk(Player player) {
        if (!plugin.getConfig().getBoolean("afk.enabled", true)) {
            return false;
        }

        // Sumber utama: placeholder AxAFKZone lewat PlaceholderAPI (%axafkzone_afk%).
        // Ini yang SEBENERNYA valid buat AxAFKZone -- plugin itu gak pernah nge-set
        // metadata Bukkit, jadi cek metadata doang (di bawah) gak bakal pernah nangkep
        // status "lagi di zona AFK" dari AxAFKZone sama sekali.
        if (isAfkViaAxAfkZonePlaceholder(player)) {
            return true;
        }

        // Cek metadata dari plugin AFK lain (yang beneran pakai metadata, bukan AxAFKZone)
        for (String key : KNOWN_AFK_METADATA_KEYS) {
            if (player.hasMetadata(key)) {
                for (MetadataValue value : player.getMetadata(key)) {
                    if (value.asBoolean()) {
                        return true;
                    }
                }
            }
        }

        // Fallback: idle-timeout internal
        AtomicLong last = lastActivity.get(player.getUniqueId());
        if (last == null) {
            return false;
        }
        long idleSeconds = (System.currentTimeMillis() - last.get()) / 1000L;
        long timeout = plugin.getConfig().getLong("afk.idle-timeout-seconds", 300);
        return idleSeconds >= timeout;
    }

    /**
     * Cek status AFK lewat placeholder AxAFKZone (%axafkzone_afk%), kalau
     * PlaceholderAPI ke-install DAN fitur ini diaktifin di config
     * ("afk.detect-axafkzone-placeholder", default true). Placeholder-nya
     * sendiri bisa diganti dari config ("afk.axafkzone-placeholder") kalau
     * suatu saat AxAFKZone ganti nama placeholder-nya.
     *
     * Class PlaceholderAPI baru beneran ke-classload pas method di dalam
     * try-block ini eksekusi -- selama isPluginEnabled dicek duluan (dan
     * PlaceholderAPI emang softdepend di plugin.yml), aman dari
     * NoClassDefFoundError kalau PlaceholderAPI gak keinstall.
     */
    private boolean isAfkViaAxAfkZonePlaceholder(Player player) {
        if (!plugin.getConfig().getBoolean("afk.detect-axafkzone-placeholder", true)) {
            return false;
        }
        if (!plugin.getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            return false;
        }
        try {
            String placeholder = plugin.getConfig().getString("afk.axafkzone-placeholder", "%axafkzone_afk%");
            String result = PlaceholderAPI.setPlaceholders(player, placeholder);
            return result != null && result.trim().equalsIgnoreCase("true");
        } catch (Exception e) {
            return false;
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        // Cuma hitung kalau beneran pindah block, bukan cuma nengok (look-only movement)
        if (event.getFrom().getBlockX() != event.getTo().getBlockX()
                || event.getFrom().getBlockY() != event.getTo().getBlockY()
                || event.getFrom().getBlockZ() != event.getTo().getBlockZ()) {
            markActive(event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onInteract(PlayerInteractEvent event) {
        markActive(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        markActive(event.getPlayer());
    }
}
