package com.sanz.leaderboard.listeners;

import com.sanz.leaderboard.SanzLeaderboard;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.metadata.MetadataValue;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Nge-track kapan terakhir player aktif (gerak/klik/command/chat), buat dipakai
 * PlaytimeListener nentuin apakah waktu itu dihitung playtime apa nggak.
 *
 * BUG FIX v2 (playtime & gems gak kehitung bener di AFK zone): percobaan PERTAMA
 * (pakai placeholder PlaceholderAPI %axafkzone_afk%) TERBUKTI GAK JALAN di server
 * ini -- dari log kebukti AxAFKZone 1.12.0 emang gak expose expansion PAPI apapun
 * sama sekali (gak ada di eCloud pas di-download, dan gak ke-register pas
 * /papi reload walau plugin-nya sendiri enable normal).
 *
 * FIX v2: sekarang deteksi AFK zone pakai {@link AxAfkZoneRegions}, yang baca
 * LANGSUNG file plugins/AxAFKZone/zones/*.yml dan ngecek posisi player terhadap
 * cuboid zona itu sendiri -- murni matematika lokasi, TIDAK butuh PlaceholderAPI
 * atau API plugin lain sama sekali, jadi dijamin jalan independen dari fitur
 * placeholder AxAFKZone ada apa kagak. Metadata generik & idle-timeout internal
 * tetap dipertahankan sebagai fallback (buat plugin AFK lain yang mungkin beneran
 * pakai metadata, atau kalau AxAFKZone-nya gak ke-install).
 */
public class AFKTracker implements Listener {

    private static final String[] KNOWN_AFK_METADATA_KEYS = {"afk", "isAfk", "AFK", "isAFK"};

    private final SanzLeaderboard plugin;
    private final AxAfkZoneRegions axAfkZoneRegions;
    private final java.util.Map<UUID, AtomicLong> lastActivity = new ConcurrentHashMap<>();

    public AFKTracker(SanzLeaderboard plugin) {
        this.plugin = plugin;
        this.axAfkZoneRegions = new AxAfkZoneRegions(plugin);
    }

    /** Dipanggil pas plugin enable & dari task berkala buat baca ulang zona AxAFKZone. */
    public void reloadAxAfkZoneRegions() {
        axAfkZoneRegions.reload();
    }

    public AxAfkZoneRegions getAxAfkZoneRegions() {
        return axAfkZoneRegions;
    }

    public void markActive(Player player) {
        lastActivity.computeIfAbsent(player.getUniqueId(), k -> new AtomicLong())
                .set(System.currentTimeMillis());
    }

    public void remove(UUID uuid) {
        lastActivity.remove(uuid);
    }

    /**
     * True kalau player dianggap AFK sekarang - baik lewat idle-timeout internal,
     * lewat metadata dari plugin AFK lain (kalau ada), atau (yang paling relevan
     * buat AxAFKZone) karena posisi player lagi di dalam salah satu zona AxAFKZone.
     */
    public boolean isAfk(Player player) {
        if (!plugin.getConfig().getBoolean("afk.enabled", true)) {
            return false;
        }

        // Sumber utama buat AxAFKZone: cek posisi player terhadap cuboid zona yang
        // dibaca langsung dari plugins/AxAFKZone/zones/*.yml -- lihat javadoc class
        // di atas kenapa ini gantiin pendekatan placeholder yang gak jalan.
        if (plugin.getConfig().getBoolean("afk.detect-axafkzone-region", true)
                && axAfkZoneRegions.isInZone(player)) {
            return true;
        }

        // Cek metadata dari plugin AFK lain (yang beneran pakai metadata Bukkit)
        for (String key : KNOWN_AFK_METADATA_KEYS) {
            if (player.hasMetadata(key)) {
                for (MetadataValue value : player.getMetadata(key)) {
                    if (value.asBoolean()) {
                        return true;
                    }
                }
            }
        }

        // Fallback: idle-timeout internal
        AtomicLong last = lastActivity.get(player.getUniqueId());
        if (last == null) {
            return false;
        }
        long idleSeconds = (System.currentTimeMillis() - last.get()) / 1000L;
        long timeout = plugin.getConfig().getLong("afk.idle-timeout-seconds", 300);
        return idleSeconds >= timeout;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        // Cuma hitung kalau beneran pindah block, bukan cuma nengok (look-only movement)
        if (event.getFrom().getBlockX() != event.getTo().getBlockX()
                || event.getFrom().getBlockY() != event.getTo().getBlockY()
                || event.getFrom().getBlockZ() != event.getTo().getBlockZ()) {
            markActive(event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onInteract(PlayerInteractEvent event) {
        markActive(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        markActive(event.getPlayer());
    }
}
