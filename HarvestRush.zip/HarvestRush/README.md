# HarvestRush 1.0.0 (Paper 1.21.11)

## Build
Butuh JDK 21 + Maven:

    mvn clean package

Hasil: `target/HarvestRush-1.0.0.jar` -> taruh di `plugins/`.

## Setup cepat
1. Bangun farm di world khusus (farmland + air + crop udah ditanam admin).
2. Berdiri di titik spawn farm -> `/harvestrush setspawn` (world itu otomatis jadi farm world).
3. Kasih permission rank di LuckPerms, contoh: `harvestrush.rank.vip`.
4. Member masuk pakai `/farmings`. Admin masuk buat setting pakai `/harvestrush tp` (tanpa timer & cooldown), keluar pakai `/harvestrush exit`.
5. (Opsional) isi `rewards.commands` di config biar member dapat uang, contoh: `eco give %player% %money%`.

## Cara kerja
- Crop di farm world punya timer sendiri (default 5 detik) dan gak bisa matang sebelum itu.
- Member `/farmings` -> teleport ke spawn farm, sesi mulai (default 3 menit, rank bisa lebih).
- Crop yang di-break otomatis ditanam ulang (gratis).
- Admin di mode admin: sneak waktu break kalau mau bongkar farm tanpa ditanam ulang.
- Plugin ini gak ngatur siapa boleh break/place block. Atur lewat region/flag plugin lu sendiri.
- Bossbar hitung mundur + jumlah panen + peringatan di 30/10/5/3/2/1 detik.
- Waktu habis -> dibalikin ke lokasi semula (kalau hilang, ke spawn world utama).
- Setelah sesi ada cooldown (default 12 jam), disimpan di `players.yml` jadi aman walau restart.
- Teleport lain ke farm (/back, /home, /tpa, /warp) diblok; masuk cuma lewat /farmings.

## Fitur
- Rank: lama sesi, pengali drop, pengali uang
- Hasil panen langsung masuk inventory (auto-pickup)
- Hadiah uang tiap sesi lewat command console (bebas plugin ekonomi)
- Statistik + leaderboard (`/farmings stats`, `/farmings top`)
- Batas pemain barengan (`session.max-players`)
- Title saat masuk, bossbar, peringatan waktu
- Farm world: tanpa mob spawn, tanpa lapar, tanpa PvP

## Command
- `/farmings` masuk | `leave` | `time` (sisa waktu / cooldown) | `stats` | `top`
- `/harvestrush reload|info|setspawn|tp|exit|extend|end|resetcd|mature`

## Permission
- `harvestrush.use` (semua) - pakai /farmings
- `harvestrush.rank.<nama>` - rank sesuai `session.ranks` di config
- `harvestrush.bypass.time` / `.cooldown` (op) - tanpa batas waktu / tanpa cooldown
- `harvestrush.admin` (op) - command admin
