package com.harvestrush;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Data per pemain (players.yml): cooldown masuk farm + statistik panen. Aman waktu restart. */
public final class PlayerStore {

    public static final class Entry {
        public long cooldownUntil;
        public long harvested;
        public int sessions;
        public String name = "?";
    }

    private final HarvestRush plugin;
    private final File file;
    private final Map<UUID, Entry> entries = new HashMap<>();
    private boolean dirty;

    PlayerStore(HarvestRush plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yml.getConfigurationSection("players");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            UUID id;
            try {
                id = UUID.fromString(key);
            } catch (IllegalArgumentException ex) {
                continue;
            }
            ConfigurationSection e = section.getConfigurationSection(key);
            if (e == null) continue;

            Entry entry = new Entry();
            entry.cooldownUntil = e.getLong("cooldown");
            entry.harvested = e.getLong("harvested");
            entry.sessions = e.getInt("sessions");
            entry.name = e.getString("name", "?");
            entries.put(id, entry);
        }
    }

    /** Ambil entry, dibuat kalau belum ada. */
    public Entry get(UUID id) {
        return entries.computeIfAbsent(id, k -> new Entry());
    }

    /** Ambil entry tanpa bikin baru (null kalau belum ada). */
    public Entry peek(UUID id) {
        return entries.get(id);
    }

    public void markDirty() {
        dirty = true;
    }

    public void saveIfDirty() {
        if (dirty) save();
    }

    public void save() {
        long now = System.currentTimeMillis();
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, Entry> e : entries.entrySet()) {
            Entry v = e.getValue();
            // buang entry kosong yang cooldown-nya udah habis
            if (v.harvested == 0 && v.sessions == 0 && v.cooldownUntil <= now) continue;
            String base = "players." + e.getKey();
            yml.set(base + ".name", v.name);
            yml.set(base + ".cooldown", v.cooldownUntil);
            yml.set(base + ".harvested", v.harvested);
            yml.set(base + ".sessions", v.sessions);
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().warning("Gagal nyimpen players.yml: " + ex.getMessage());
        }
    }

    /** Leaderboard total panen (terbanyak dulu). */
    public List<Map.Entry<UUID, Entry>> top(int limit) {
        List<Map.Entry<UUID, Entry>> list = new ArrayList<>(entries.entrySet());
        list.removeIf(e -> e.getValue().harvested <= 0);
        list.sort((a, b) -> Long.compare(b.getValue().harvested, a.getValue().harvested));
        return list.subList(0, Math.min(limit, list.size()));
    }
}
