package com.harvestrush;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDropItemEvent;
import org.bukkit.event.block.BlockFertilizeEvent;
import org.bukkit.event.block.BlockGrowEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.event.world.WorldSaveEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** Semua kontrol pertumbuhan crop. Cuma aktif di farm world. */
public final class CropListener implements Listener {

    private final HarvestRush plugin;
    private final Random random = new Random();

    public CropListener(HarvestRush plugin) {
        this.plugin = plugin;
    }

    private boolean managed(World world) {
        return plugin.farmData().isFarmWorld(world);
    }

    // ================================================================ chunk data

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        plugin.crops().loadChunk(e.getChunk());
    }

    @EventHandler
    public void onChunkUnload(ChunkUnloadEvent e) {
        plugin.crops().unloadChunk(e.getChunk());
    }

    @EventHandler
    public void onWorldSave(WorldSaveEvent e) {
        plugin.crops().saveDirty();
    }

    // ================================================================ growth control

    /** Matiin pertumbuhan alami (random tick). Crop yang belum kedata langsung "diadopsi". */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onGrow(BlockGrowEvent e) {
        Block b = e.getBlock();
        Settings s = plugin.settings();
        if (!s.crops.contains(b.getType()) || !managed(b.getWorld())) return;
        if (!(b.getBlockData() instanceof Ageable ageable)) return;

        e.setCancelled(true);

        CropManager cm = plugin.crops();
        if (!cm.isTracked(b)) {
            cm.track(b, adoptedPlantedAt(ageable, s.growMs(b.getType())));
        }
    }

    /** Bone meal dari sumber lain (dispenser dll). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFertilize(BlockFertilizeEvent e) {
        Block b = e.getBlock();
        if (plugin.settings().crops.contains(b.getType()) && managed(b.getWorld())) {
            e.setCancelled(true);
        }
    }

    // ================================================================ planting / breaking

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Block b = e.getBlockPlaced();
        if (plugin.settings().crops.contains(b.getType()) && managed(b.getWorld())) {
            plugin.crops().track(b, System.currentTimeMillis());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        plugin.crops().untrack(b);

        Settings s = plugin.settings();
        if (!managed(b.getWorld()) || !s.autoReplant.contains(b.getType())) return;
        if (!(b.getBlockData() instanceof Ageable old)) return;

        Player player = e.getPlayer();
        boolean mature = old.getAge() >= old.getMaximumAge();
        boolean adminMode = plugin.sessions().isAdminMode(player);

        // hitung panen (cuma kepakai kalau pemainnya lagi sesi)
        if (mature) {
            plugin.sessions().recordHarvest(player, b.getType());
        }

        // Admin yang lagi mode admin + SNEAK = lagi bongkar farm, jangan ditanam ulang.
        if (adminMode && player.isSneaking()) return;

        // Tanam ulang otomatis (age 0) 1 tick setelah block-nya hilang, timer tumbuh mulai dari nol
        Ageable fresh = (Ageable) old.clone();
        fresh.setAge(0);
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!b.getType().isAir()) return;
            if (!fresh.isSupported(b)) {
                // biasanya: di bawahnya bukan farmland / soul sand, atau tempatnya kurang terang
                if (player.isOnline()) player.sendActionBar(plugin.settings().message("replant-failed"));
                return;
            }
            b.setBlockData(fresh, false);
            plugin.crops().track(b, System.currentTimeMillis());
        });
    }

    /** Bonus drop sesuai rank + hasil panen langsung masuk inventory (kalau auto-pickup nyala). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrops(BlockDropItemEvent e) {
        Block b = e.getBlock();
        Settings s = plugin.settings();
        if (!managed(b.getWorld()) || !s.autoReplant.contains(e.getBlockState().getType())) return;

        Player p = e.getPlayer();
        SessionManager sessions = plugin.sessions();
        if (!sessions.inSession(p)) return;

        List<Item> items = e.getItems();

        double mult = sessions.dropMultiplier(p);
        if (mult > 1.0) {
            for (Item item : items) {
                ItemStack stack = item.getItemStack();
                double value = stack.getAmount() * mult;
                int amount = (int) Math.floor(value);
                if (random.nextDouble() < value - amount) amount++;
                stack.setAmount(Math.max(1, Math.min(amount, stack.getMaxStackSize())));
                item.setItemStack(stack);
            }
        }

        if (s.autoPickup) {
            Iterator<Item> it = items.iterator();
            while (it.hasNext()) {
                Item item = it.next();
                Map<Integer, ItemStack> left = p.getInventory().addItem(item.getItemStack());
                if (left.isEmpty()) {
                    it.remove(); // masuk inventory, gak usah jatuh ke tanah
                } else {
                    item.setItemStack(left.values().iterator().next()); // inventory penuh: sisanya jatuh
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityChangeBlock(EntityChangeBlockEvent e) {
        Block b = e.getBlock();
        Settings s = plugin.settings();
        if (!managed(b.getWorld())) return;

        // mob/entity gak bisa ngerusak farmland
        if (s.protectFarmland && b.getType() == Material.FARMLAND && e.getTo() == Material.DIRT) {
            e.setCancelled(true);
            return;
        }

        // villager (dll) yang nanam crop -> ikut dilacak (tunggu 1 tick sampai block-nya berubah)
        if (s.crops.contains(e.getTo())) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (plugin.settings().crops.contains(b.getType())) {
                    plugin.crops().track(b, System.currentTimeMillis());
                }
            });
        }
    }

    // ================================================================ farmland & bone meal

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        Block b = e.getClickedBlock();
        if (b == null || !managed(b.getWorld())) return;
        Settings s = plugin.settings();

        // Farmland gak bisa diinjak
        if (e.getAction() == Action.PHYSICAL) {
            if (s.protectFarmland && b.getType() == Material.FARMLAND) {
                e.setCancelled(true);
            }
            return;
        }

        // Bone meal dilarang di crop biar wajib nunggu timer
        if (s.blockBonemeal
                && e.getAction() == Action.RIGHT_CLICK_BLOCK
                && s.crops.contains(b.getType())) {
            ItemStack item = e.getItem();
            if (item != null && item.getType() == Material.BONE_MEAL) {
                e.setCancelled(true);
                e.getPlayer().sendActionBar(s.message("bonemeal-disabled"));
            }
        }
    }

    // ================================================================ util

    /** Crop yang belum kedata: anggap umurnya sebanding dengan stage-nya sekarang. */
    private static long adoptedPlantedAt(Ageable a, long totalMs) {
        int max = Math.max(1, a.getMaximumAge());
        return System.currentTimeMillis() - (long) a.getAge() * totalMs / max;
    }
}
