package com.harvestrush;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;

/** Nyimpen farm world + titik spawn yang di-set admin (data.yml). */
public final class FarmData {

    private final HarvestRush plugin;
    private final File file;

    private String worldName;
    private double x;
    private double y;
    private double z;
    private float yaw;
    private float pitch;

    FarmData(HarvestRush plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        worldName = yml.getString("spawn.world");
        x = yml.getDouble("spawn.x");
        y = yml.getDouble("spawn.y");
        z = yml.getDouble("spawn.z");
        yaw = (float) yml.getDouble("spawn.yaw");
        pitch = (float) yml.getDouble("spawn.pitch");
    }

    public void setSpawn(Location loc) {
        worldName = loc.getWorld().getName();
        x = loc.getX();
        y = loc.getY();
        z = loc.getZ();
        yaw = loc.getYaw();
        pitch = loc.getPitch();
        save();
    }

    private void save() {
        YamlConfiguration yml = new YamlConfiguration();
        yml.set("spawn.world", worldName);
        yml.set("spawn.x", x);
        yml.set("spawn.y", y);
        yml.set("spawn.z", z);
        yml.set("spawn.yaw", (double) yaw);
        yml.set("spawn.pitch", (double) pitch);
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Gagal nyimpen data.yml: " + ex.getMessage());
        }
    }

    /** Spawn farm, atau null kalau belum di-set / world-nya belum termuat. */
    public Location spawn() {
        if (worldName == null) return null;
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        return new Location(world, x, y, z, yaw, pitch);
    }

    public boolean hasSpawn() {
        return worldName != null;
    }

    public String worldName() {
        return worldName;
    }

    public boolean isFarmWorld(World world) {
        return worldName != null && world != null && worldName.equals(world.getName());
    }
}
