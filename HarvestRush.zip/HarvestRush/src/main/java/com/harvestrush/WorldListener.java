package com.harvestrush;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

/** Event yang berhubungan dengan sesi member dan aturan di farm world. */
public final class WorldListener implements Listener {

    private final HarvestRush plugin;

    public WorldListener(HarvestRush plugin) {
        this.plugin = plugin;
    }

    // ================================================================ sesi

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.sessions().handleQuit(e.getPlayer());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        plugin.sessions().handleJoin(e.getPlayer());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        plugin.sessions().handleWorldChange(e.getPlayer(), e.getFrom());
    }

    /**
     * Masuk farm world HANYA lewat /farmings. Nutup jalan pintas kayak /back, /home, /tpa, /warp
     * yang bisa nge-bypass batas waktu dan cooldown.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        Settings s = plugin.settings();
        if (!s.blockOutsideTeleport) return;

        Location to = e.getTo();
        if (to == null || !plugin.farmData().isFarmWorld(to.getWorld())) return;

        Player p = e.getPlayer();
        if (plugin.sessions().canBeInFarm(p)) return;

        e.setCancelled(true);
        p.sendMessage(s.message("farm-only-command"));
    }

    // ================================================================ mob & hunger

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (!plugin.settings().noMobSpawn) return;
        if (!plugin.farmData().isFarmWorld(e.getLocation().getWorld())) return;

        switch (e.getSpawnReason()) {
            case NATURAL, CHUNK_GEN, JOCKEY, REINFORCEMENTS, TRAP -> e.setCancelled(true);
            default -> { }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHunger(FoodLevelChangeEvent e) {
        if (!plugin.settings().noHunger) return;
        if (e.getEntity() instanceof Player p && plugin.farmData().isFarmWorld(p.getWorld())) {
            e.setCancelled(true);
        }
    }

    // ================================================================ PvP

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!plugin.settings().disablePvp) return;
        if (!(e.getEntity() instanceof Player victim)) return;
        if (!plugin.farmData().isFarmWorld(victim.getWorld())) return;

        Entity damager = e.getDamager();
        if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Entity shooter) {
            damager = shooter;
        }
        if (damager instanceof Player) {
            e.setCancelled(true);
        }
    }
}
