package com.harvestrush;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;

public final class AdminCommand implements CommandExecutor, TabCompleter {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private static final List<String> SUBS = List.of("reload", "info", "setspawn", "tp", "exit", "extend", "end", "resetcd", "mature");

    private final HarvestRush plugin;

    public AdminCommand(HarvestRush plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("harvestrush.admin")) {
            send(sender, "<red>Lu gak punya izin buat ini.");
            return true;
        }

        String sub = args.length == 0 ? "help" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "reload" -> {
                plugin.reloadAll();
                send(sender, "<green>Config HarvestRush sudah di-reload.");
            }
            case "info" -> {
                Settings s = plugin.settings();
                FarmData data = plugin.farmData();
                send(sender, "<gold>HarvestRush <gray>- info");
                send(sender, "<gray>Farm world: <white>" + (data.hasSpawn() ? data.worldName() : "belum di-set"));
                send(sender, "<gray>Sesi aktif: <white>" + plugin.sessions().activeCount());
                send(sender, "<gray>Waktu sesi default: <white>" + SessionManager.formatLong(s.defaultSessionSeconds)
                        + " <gray>| cooldown: <white>" + SessionManager.formatLong(s.cooldownSeconds));
                for (var rank : s.ranks.entrySet()) {
                    Settings.Rank r = rank.getValue();
                    send(sender, "<gray>  rank <white>" + rank.getKey() + "<gray> (harvestrush.rank." + rank.getKey()
                            + "): <white>" + SessionManager.formatLong(r.seconds())
                            + " <gray>| drop x<white>" + r.dropMultiplier()
                            + " <gray>| uang x<white>" + r.moneyMultiplier());
                }
                send(sender, "<gray>Waktu tumbuh crop: <white>" + (s.defaultGrowMs / 1000L) + " detik"
                        + " <gray>| crop terlacak: <white>" + plugin.crops().trackedCount());
            }
            case "setspawn" -> {
                if (!(sender instanceof Player p)) {
                    send(sender, "<red>Command ini cuma buat pemain.");
                    return true;
                }
                Location loc = p.getLocation();
                plugin.farmData().setSpawn(loc);
                send(sender, "<green>Spawn farm di-set di world <white>" + loc.getWorld().getName()
                        + "<green>. Semua crop di world ini sekarang diatur plugin.");
            }
            case "extend" -> {
                if (args.length < 3) {
                    send(sender, "<red>Pakai: /harvestrush extend [player] [detik]");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    send(sender, "<red>Player gak ketemu / offline.");
                    return true;
                }
                long seconds;
                try {
                    seconds = Long.parseLong(args[2]);
                } catch (NumberFormatException ex) {
                    send(sender, "<red>Detik harus angka.");
                    return true;
                }
                if (seconds <= 0) {
                    send(sender, "<red>Detik harus lebih dari 0.");
                    return true;
                }
                if (plugin.sessions().extend(target, seconds)) {
                    send(sender, "<green>Waktu " + target.getName() + " ditambah " + SessionManager.formatLong(seconds) + ".");
                    target.sendMessage(plugin.settings().message("extended", "%time%", SessionManager.formatLong(seconds)));
                } else {
                    send(sender, "<red>Dia lagi gak di sesi farm.");
                }
            }
            case "end" -> {
                if (args.length < 2) {
                    send(sender, "<red>Pakai: /harvestrush end [player]");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    send(sender, "<red>Player gak ketemu / offline.");
                    return true;
                }
                if (plugin.sessions().adminEnd(target)) {
                    send(sender, "<green>Sesi " + target.getName() + " diakhiri.");
                } else {
                    send(sender, "<red>Dia lagi gak di sesi farm.");
                }
            }
            case "tp", "enter" -> {
                if (!(sender instanceof Player p)) {
                    send(sender, "<red>Command ini cuma buat pemain.");
                    return true;
                }
                switch (plugin.sessions().adminEnter(p)) {
                    case OK -> send(sender, "<green>Masuk farm (mode admin: tanpa timer & cooldown).  "
                            + "Keluar: <white>/harvestrush exit");
                    case NO_SPAWN -> send(sender, "<red>Spawn farm belum di-set. Pakai /harvestrush setspawn dulu.");
                    case IN_SESSION -> send(sender, "<red>Lu lagi di sesi member. Pakai /farmings leave dulu.");
                    case FAILED -> send(sender, "<red>Teleport gagal (dibatalin plugin lain).");
                }
            }
            case "exit" -> {
                if (!(sender instanceof Player p)) {
                    send(sender, "<red>Command ini cuma buat pemain.");
                    return true;
                }
                if (plugin.sessions().adminExit(p)) {
                    send(sender, "<green>Keluar dari farm, balik ke tempat semula.");
                } else {
                    send(sender, "<yellow>Lu lagi gak di mode admin farm.");
                }
            }
            case "resetcd" -> {
                if (args.length < 2) {
                    send(sender, "<red>Pakai: /harvestrush resetcd [player]");
                    return true;
                }
                OfflinePlayer target = Bukkit.getOfflinePlayerIfCached(args[1]);
                if (target == null) {
                    send(sender, "<red>Player gak dikenal (belum pernah main).");
                    return true;
                }
                PlayerStore.Entry entry = plugin.store().peek(target.getUniqueId());
                if (entry == null || entry.cooldownUntil <= System.currentTimeMillis()) {
                    send(sender, "<yellow>Dia lagi gak kena cooldown.");
                    return true;
                }
                entry.cooldownUntil = 0L;
                plugin.store().markDirty();
                send(sender, "<green>Cooldown " + args[1] + " di-reset.");
            }
            case "mature" -> {
                if (!(sender instanceof Player p)) {
                    send(sender, "<red>Command ini cuma buat pemain.");
                    return true;
                }
                int radius = 5;
                if (args.length >= 2) {
                    try {
                        radius = Integer.parseInt(args[1]);
                    } catch (NumberFormatException ex) {
                        send(sender, "<red>Radius harus angka.");
                        return true;
                    }
                }
                radius = Math.max(1, Math.min(20, radius));

                Block center = p.getLocation().getBlock();
                int count = 0;
                for (int dx = -radius; dx <= radius; dx++) {
                    for (int dy = -radius; dy <= radius; dy++) {
                        for (int dz = -radius; dz <= radius; dz++) {
                            if (plugin.crops().forceMature(center.getRelative(dx, dy, dz))) count++;
                        }
                    }
                }
                send(sender, "<green>" + count + " crop dimatangin (radius " + radius + ").");
            }
            default -> {
                send(sender, "<gold>/harvestrush reload <gray>- reload config");
                send(sender, "<gold>/harvestrush info <gray>- info plugin");
                send(sender, "<gold>/harvestrush setspawn <gray>- set farm world + spawn di posisi lu");
                send(sender, "<gold>/harvestrush tp <gray>- masuk farm buat setting (tanpa timer & cooldown)");
                send(sender, "<gold>/harvestrush exit <gray>- keluar dari mode admin farm");
                send(sender, "<gold>/harvestrush extend [player] [detik] <gray>- tambah waktu sesi");
                send(sender, "<gold>/harvestrush end [player] <gray>- akhiri sesi pemain");
                send(sender, "<gold>/harvestrush resetcd [player] <gray>- reset cooldown masuk farm");
                send(sender, "<gold>/harvestrush mature [radius] <gray>- matangin crop di sekitar lu");
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (!sender.hasPermission("harvestrush.admin")) return List.of();
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            return SUBS.stream().filter(x -> x.startsWith(prefix)).toList();
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (sub.equals("extend") || sub.equals("end") || sub.equals("resetcd")) return null; // nama player (default)
            if (sub.equals("mature")) return List.of("5", "10", "20");
        }
        return List.of();
    }

    private static void send(CommandSender sender, String miniMessage) {
        sender.sendMessage(MM.deserialize(miniMessage));
    }
}
