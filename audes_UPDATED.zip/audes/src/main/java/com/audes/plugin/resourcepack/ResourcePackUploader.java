package com.audes.plugin.resourcepack;

import java.io.File;

/**
 * Dev15: kontrak umum buat SEMUA provider hosting resource pack --
 * dibikin setelah insiden storage LobFile penuh nunjukin kita gak boleh
 * hardcode ke satu provider aja (persis kayak ItemsAdder yang support
 * banyak provider hosting, gak mihak satu doang). Nambah provider baru
 * di masa depan (misal ResourcePack.Host, atau CDN sendiri) tinggal
 * bikin class baru implements ResourcePackUploader + daftarin satu
 * baris di ResourcePackModule.resolveUploader() -- gak perlu ubah
 * apa pun di alur regenerate()/generateLocalZipOnly().
 *
 * Implementasi yang ada sekarang: LobFileUploader, CatboxUploader.
 * Keduanya level "kepentingan"-nya SAMA di kode -- yang beda cuma
 * default di config.yml (resource-pack.hosting-mode), yang boleh
 * server owner ganti kapan aja tanpa compile ulang.
 */
public interface ResourcePackUploader {

    /**
     * Upload synchronous -- WAJIB dipanggil dari thread async (caller,
     * lihat ResourcePackModule, sudah di dalam AsyncUtil.runAsyncThenSync
     * heavyWork), karena ini I/O jaringan yang bisa makan waktu lama.
     */
    UploadResult upload(File zipFile);

    /** Nama provider buat ditampilin di log (mis. "LobFile", "Catbox"). */
    String providerName();

    record UploadResult(boolean success, String url, String error) {
        public static UploadResult ok(String url) {
            return new UploadResult(true, url, null);
        }

        public static UploadResult fail(String error) {
            return new UploadResult(false, null, error);
        }
    }
}
