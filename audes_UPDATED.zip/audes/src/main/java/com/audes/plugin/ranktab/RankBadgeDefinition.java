package com.audes.plugin.ranktab;

/**
 * Satu badge rank (icon custom lewat font glyph). Dev-update: sekarang
 * pakai aset ASLI dari tim (Haykal), bukan placeholder ItemsAdder-porting
 * lagi -- didaftarin di minecraft:font/default.json (BUKAN font custom
 * audes:rank_badges), biar gak butuh MiniMessage <font:> tag sama sekali,
 * konsisten sama teknik shop icon di ImageRegistry.
 *
 * "character" adalah 1 karakter dari Private Use Area Unicode
 * (U+E800-U+E80E dipakai di sini, lihat
 * contents/assets/minecraft/font/default.json) yang di-render jadi badge
 * image lewat custom font provider — BUKAN icon di UI item (beda total
 * dari resource-pack model item).
 *
 * PENTING: karakter ini HANYA tampil benar kalau player sudah terima
 * resource pack Audes (custom font-nya ada di situ). Player yang belum
 * terima pack (baru join, belum accept prompt) akan lihat kotak
 * "tofu"/karakter hilang, BUKAN badge.
 *
 * "bedrockCharacter" OPSIONAL -- Bedrock/Geyser gak pake JSON font
 * provider kayak Java, tapi atlas grid 16x16 per "halaman" unicode
 * (font/glyph_E1.png). Kalau badge ini juga didaftarin di atlas
 * Bedrock, isi karakter unicode versi Bedrock-nya di sini (BEDA dari
 * "character" versi Java). Biarin null kalau badge ini cuma didukung
 * di Java -- TabListManager bakal skip badge (bukan crash) buat
 * player Bedrock kalau field ini null.
 */
public record RankBadgeDefinition(String id, String character, String bedrockCharacter) {
}
