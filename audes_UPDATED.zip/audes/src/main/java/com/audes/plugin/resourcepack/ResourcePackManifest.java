package com.audes.plugin.resourcepack;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Menjawab prioritas #3 di daftar-fitur-itemsadder.md ("Manifest resource
 * pack + apply model ke item/block/furniture") dan poin risiko yang sudah
 * diperingatkan Dev4 di STATUS-DEV4.md: "typo di config.yml modelKey bisa
 * bikin item invisible tanpa warning".
 *
 * Tugas kelas ini SATU hal saja: tahu modelKey mana yang benar-benar punya
 * file item model definition di contents/, supaya ToolFactory/
 * BlockItemFactory/FurnitureItemFactory bisa memutuskan apply setItemModel()
 * atau tetap fallback vanilla DENGAN peringatan jelas -- bukan silent fail.
 *
 * FORMAT YANG DI-SCAN: mengikuti item model definition resmi Minecraft
 * 1.21.4+ (assets/&lt;namespace&gt;/items/&lt;path&gt;.json), BUKAN model
 * lama assets/&lt;namespace&gt;/models/item/. modelKey di config.yml
 * (mis. "audes:tools/pedang_petir") dipetakan ke file
 * contents/assets/audes/items/tools/pedang_petir.json.
 *
 * Belum berlaku untuk BLOCK (Mojang/Paper belum expose block model
 * override resmi per hari riset ini ditulis -- lihat catatan di
 * BlockDefinition), jadi custom block TETAP pakai teknik note+instrument
 * sampai API itu ada, manifest ini cuma dipakai block untuk validasi
 * ITEM di tangan (BlockItemFactory#create), bukan block yang sudah
 * ter-place di dunia.
 */
/**
 * Menjawab prioritas #3 di daftar-fitur-itemsadder.md ("Manifest resource
 * pack + apply model ke item/block/furniture") dan poin risiko yang sudah
 * diperingatkan Dev4 di STATUS-DEV4.md: "typo di config.yml modelKey bisa
 * bikin item invisible tanpa warning".
 *
 * Tugas kelas ini SATU hal saja: tahu modelKey mana yang benar-benar punya
 * file item model definition di contents/, supaya ToolFactory/
 * BlockItemFactory/FurnitureItemFactory bisa memutuskan apply setItemModel()
 * atau tetap fallback vanilla DENGAN peringatan jelas -- bukan silent fail.
 *
 * FORMAT YANG DI-SCAN untuk item: mengikuti item model definition resmi
 * Minecraft 1.21.4+ (assets/&lt;namespace&gt;/items/&lt;path&gt;.json),
 * BUKAN model lama assets/&lt;namespace&gt;/models/item/. modelKey di
 * config.yml (mis. "audes:tools/pedang_petir") dipetakan ke file
 * contents/assets/audes/items/tools/pedang_petir.json.
 *
 * Belum berlaku untuk BLOCK (Mojang/Paper belum expose block model
 * override resmi per hari riset ini ditulis -- lihat catatan di
 * BlockDefinition), jadi custom block TETAP pakai teknik note+instrument
 * sampai API itu ada, manifest ini cuma dipakai block untuk validasi
 * ITEM di tangan (BlockItemFactory#create), bukan block yang sudah
 * ter-place di dunia.
 *
 * Dev6: tambah scan KEDUA untuk asset "equipment" (armor trim/model
 * layer, format resmi 1.21.2+: assets/&lt;namespace&gt;/equipment/
 * &lt;path&gt;.json) -- dipakai ArmorItemFactory buat validasi
 * "asset_id" komponen equippable, TERPISAH dari set item model di atas
 * karena lokasi foldernya beda dan namespace:path yang sama BISA berarti
 * dua file berbeda di dua folder itu (item model vs equipment layer).
 */
public class ResourcePackManifest {

    private final Logger logger;

    // volatile: rebuild() jalan di thread async (lihat ResourcePackModule),
    // sedangkan hasModel()/warnMissingOnce() dipanggil dari main thread
    // (saat create() item). Swap referensi Set utuh (bukan mutasi in-place)
    // supaya tidak butuh lock -- pembaca selalu lihat snapshot yang konsisten.
    private volatile Set<String> availableModelKeys = Set.of();
    private volatile Set<String> availableEquipmentKeys = Set.of();

    // Supaya warning "modelKey tidak ketemu" cuma muncul SEKALI per key,
    // bukan tiap kali item itu di-create ulang (mis. tiap /audes give
    // dipanggil berkali-kali) -- itu akan membanjiri console log.
    private final Set<String> warnedMissingKeys = ConcurrentHashMap.newKeySet();
    private final Set<String> warnedMissingEquipmentKeys = ConcurrentHashMap.newKeySet();

    public ResourcePackManifest(Logger logger) {
        this.logger = logger;
    }

    /**
     * Scan ulang contents/assets/&lt;namespace&gt;/items/**\/*.json DAN
     * contents/assets/&lt;namespace&gt;/equipment/**\/*.json sekaligus.
     * WAJIB dipanggil dari thread async (I/O jalan-jalan ke filesystem),
     * lihat AsyncUtil di ResourcePackModule.
     *
     * @return jumlah modelKey item yang ditemukan (buat log info di caller;
     *         jumlah equipment key bisa diambil lewat equipmentModelCount()
     *         setelah rebuild ini selesai).
     */
    public int rebuild(File contentsFolder) {
        availableEquipmentKeys = Set.copyOf(scanNamespacedJson(contentsFolder, "equipment"));
        warnedMissingEquipmentKeys.clear();

        Set<String> found = scanNamespacedJson(contentsFolder, "items");
        // Dev-fix (crate visual bug): sebelum ini, modelKey dianggap "ada"
        // cuma karena file items/<path>.json-nya ketemu -- TIDAK pernah
        // dicek apakah model 3D & texture yang DIRUJUK di dalam file itu
        // beneran ada. Kalau deploy contents/ ke server cuma sebagian
        // (mis. folder items/ ke-upload tapi models/item/ atau textures/
        // ketinggalan), modelKey ini tetap dianggap valid, ItemDisplay
        // tetap di-spawn, dan hasilnya BUKAN warning jelas melainkan
        // checkerboard ungu-hitam ("missing texture") di client -- silent
        // sampai ada yang lapor manual. validateChain() di bawah nutup
        // celah ini: modelKey yang rantainya putus di mana pun (item ->
        // model -> texture) DIKELUARKAN dari availableModelKeys, supaya
        // caller (BlockItemFactory/ToolFactory/FurnitureItemFactory/
        // CustomBlockListener) fallback ke vanilla + warning jelas,
        // BUKAN spawn entity dengan model yang bakal tampil rusak.
        found = validateChain(contentsFolder, found);
        this.availableModelKeys = Set.copyOf(found);
        // Reset supaya kalau admin nambah aset yang tadinya hilang lalu
        // restart/reload, warning bisa muncul lagi kalau MASIH hilang
        // (bukan macet permanen dari rebuild sebelumnya).
        warnedMissingKeys.clear();
        return found.size();
    }

    private Set<String> scanNamespacedJson(File contentsFolder, String subfolder) {
        Set<String> found = new HashSet<>();
        File assetsDir = new File(contentsFolder, "assets");

        File[] namespaceDirs = assetsDir.isDirectory() ? assetsDir.listFiles(File::isDirectory) : null;
        if (namespaceDirs != null) {
            for (File namespaceDir : namespaceDirs) {
                File subDir = new File(namespaceDir, subfolder);
                if (!subDir.isDirectory()) continue;

                Path subRoot = subDir.toPath();
                try (var stream = Files.walk(subRoot)) {
                    stream.filter(p -> p.toString().endsWith(".json"))
                            .forEach(p -> {
                                String rel = subRoot.relativize(p).toString()
                                        .replace(File.separatorChar, '/');
                                String path = rel.substring(0, rel.length() - ".json".length());
                                found.add(namespaceDir.getName() + ":" + path);
                            });
                } catch (IOException e) {
                    logger.warning("[Audes] Gagal scan contents/assets/" + namespaceDir.getName()
                            + "/" + subfolder + "/: " + e.getMessage());
                }
            }
        }
        return found;
    }

    /**
     * Cek tiap modelKey kandidat: parse file items/&lt;path&gt;.json-nya,
     * ikutin field "model" sampai ke file models/item/&lt;path&gt;.json
     * (kalau tipe-nya "minecraft:model"), lalu cek semua texture yang
     * dirujuk di situ ("textures": {...}) beneran ada PNG-nya di
     * textures/&lt;path&gt;.png. Kalau ADA link mana pun di rantai ini
     * yang putus, key-nya DIBUANG dari hasil (bukan cuma dicatat) --
     * caller harus fallback vanilla, bukan render model yang rusak.
     *
     * Sengaja permisif untuk bentuk model yang belum dikenali (mis.
     * "minecraft:generated" polos tanpa nested "model", atau composite
     * model dengan banyak cabang) -- daripada false-positive buang key
     * yang sebenarnya valid, kasus begini DILOLOSKAN begitu saja (tidak
     * divalidasi lebih dalam). Ini best-effort, bukan validator lengkap
     * spek item model 1.21.4+.
     */
    private Set<String> validateChain(File contentsFolder, Set<String> candidateKeys) {
        Set<String> valid = new HashSet<>();
        File assetsDir = new File(contentsFolder, "assets");
        for (String key : candidateKeys) {
            int sep = key.indexOf(':');
            if (sep < 0) { valid.add(key); continue; } // format aneh, jangan sok tau
            String namespace = key.substring(0, sep);
            String itemPath = key.substring(sep + 1);
            File itemFile = new File(new File(assetsDir, namespace), "items/" + itemPath + ".json");

            try (FileReader reader = new FileReader(itemFile)) {
                JsonObject itemJson = JsonParser.parseReader(reader).getAsJsonObject();
                JsonObject modelObj = itemJson.has("model") ? itemJson.getAsJsonObject("model") : null;
                if (modelObj == null) { valid.add(key); continue; } // bentuk gak dikenal, loloskan

                String problem = null;
                if (modelObj.has("model") && modelObj.get("model").isJsonPrimitive()) {
                    // type minecraft:model (atau sejenis) -- ikutin ke file model terpisah
                    String modelRef = modelObj.get("model").getAsString();
                    problem = checkModelFile(assetsDir, modelRef);
                } else if (modelObj.has("textures")) {
                    // textures langsung nempel di sini (mis. minecraft:generated)
                    problem = checkTextures(assetsDir, modelObj.getAsJsonObject("textures"));
                }

                if (problem != null) {
                    logger.warning("[Audes] modelKey '" + key + "' PUTUS rantainya: " + problem
                            + " -- item.json ADA tapi model/texture yang dirujuk di dalamnya TIDAK, jadi "
                            + "key ini dianggap TIDAK TERSEDIA (fallback vanilla) supaya tidak render "
                            + "sebagai checkerboard rusak di client.");
                } else {
                    valid.add(key);
                }
            } catch (Exception e) {
                logger.warning("[Audes] Gagal parse " + itemFile.getPath() + " buat validasi rantai model: "
                        + e.getMessage() + " -- key '" + key + "' dianggap tidak tersedia.");
            }
        }
        return valid;
    }

    /** @return null kalau OK, atau pesan masalah kalau model file/texture-nya putus. */
    private String checkModelFile(File assetsDir, String modelRef) {
        int sep = modelRef.indexOf(':');
        String namespace = sep < 0 ? "minecraft" : modelRef.substring(0, sep);
        String path = sep < 0 ? modelRef : modelRef.substring(sep + 1);
        File modelFile = new File(new File(assetsDir, namespace), "models/" + path + ".json");
        if (!modelFile.isFile()) {
            return "file model '" + namespace + ":" + path + "' tidak ketemu di models/" + path + ".json";
        }
        try (FileReader reader = new FileReader(modelFile)) {
            JsonObject modelJson = JsonParser.parseReader(reader).getAsJsonObject();
            if (modelJson.has("textures")) {
                return checkTextures(assetsDir, modelJson.getAsJsonObject("textures"));
            }
        } catch (Exception e) {
            return "file model '" + namespace + ":" + path + "' ada tapi gagal di-parse (" + e.getMessage() + ")";
        }
        return null;
    }

    /** @return null kalau semua texture di object ini ada PNG-nya, atau pesan masalah kalau tidak. */
    private String checkTextures(File assetsDir, JsonObject textures) {
        for (var entry : textures.entrySet()) {
            JsonElement value = entry.getValue();
            if (!value.isJsonPrimitive()) continue; // skip referensi bersarang aneh (jarang)
            String ref = value.getAsString();
            if (ref.startsWith("#")) continue; // referensi ke slot texture lain, bukan file
            int sep = ref.indexOf(':');
            String namespace = sep < 0 ? "minecraft" : ref.substring(0, sep);
            String path = sep < 0 ? ref : ref.substring(sep + 1);
            File textureFile = new File(new File(assetsDir, namespace), "textures/" + path + ".png");
            if (!textureFile.isFile()) {
                return "texture '" + namespace + ":" + path + "' tidak ketemu di textures/" + path + ".png";
            }
        }
        return null;
    }

    public boolean hasModel(String modelKey) {
        return modelKey != null && !modelKey.isBlank() && availableModelKeys.contains(modelKey);
    }

    public boolean hasEquipmentModel(String assetId) {
        return assetId != null && !assetId.isBlank() && availableEquipmentKeys.contains(assetId);
    }

    public int equipmentModelCount() {
        return availableEquipmentKeys.size();
    }

    /**
     * Log peringatan SEKALI per modelKey kalau dikonfigurasi di config.yml
     * tapi tidak ada file item model definition yang cocok di contents/.
     * Dipanggil dari factory (Tool/Block/Furniture) tiap kali create() jalan
     * dan modelKey tidak ketemu -- warnedMissingKeys yang menjaga supaya
     * cuma keluar sekali per key per rebuild.
     */
    public void warnMissingOnce(String modelKey, String contextLabel) {
        if (modelKey == null || modelKey.isBlank()) return;
        if (warnedMissingKeys.add(modelKey)) {
            logger.warning("[Audes] modelKey '" + modelKey + "' dipakai di " + contextLabel
                    + " tapi file-nya tidak ketemu di contents/assets/<namespace>/items/<path>.json "
                    + "-- cek typo di config.yml, atau aset memang belum dibuat. Item ini sementara "
                    + "tampil pakai material vanilla apa adanya (bukan invisible/error).");
        }
    }

    /** Sama seperti warnMissingOnce() tapi untuk asset equipment (armor), folder beda. */
    public void warnMissingEquipmentOnce(String assetId, String contextLabel) {
        if (assetId == null || assetId.isBlank()) return;
        if (warnedMissingEquipmentKeys.add(assetId)) {
            logger.warning("[Audes] asset equipment '" + assetId + "' dipakai di " + contextLabel
                    + " tapi file-nya tidak ketemu di contents/assets/<namespace>/equipment/<path>.json "
                    + "-- cek typo di config.yml, atau aset memang belum dibuat. Armor ini sementara "
                    + "tampil polos tanpa layer custom (bukan invisible/error).");
        }
    }
}
