package com.audes.plugin.resourcepack;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Dev15: provider hosting KEDUA (lihat ResourcePackUploader) di samping
 * LobFileUploader -- BUKAN pengganti, sengaja gak mihak satu provider
 * (pola sama kayak ItemsAdder yang support banyak provider hosting).
 * Server owner pilih lewat "resource-pack.hosting-mode" di config.yml.
 *
 * KENAPA DITAMBAH: akun LobFile lama kehabisan storage ("Not enough
 * storage space on your account", lihat log server) -- daripada nunggu
 * akun baru, provider kedua ini jadi jalan pintas sementara/permanen.
 * mc-packs.net (opsi lain yang sempet dipertimbangkan) ternyata cuma
 * web-form manual -- gak ada API/API-key sama sekali, jadi gak bisa
 * dipanggil otomatis tiap /audes reload kayak alur kita sekarang.
 * Catbox punya API multipart beneran DAN limit 200MB per file (pack
 * kita sekarang ±38MB, masih jauh dari limit).
 *
 * API: https://catbox.moe/tools.php -- POST multipart/form-data ke
 * https://catbox.moe/user/api.php, field "reqtype"=fileupload,
 * "userhash" (OPSIONAL -- kalau kosong upload tetap jalan anonim,
 * userhash cuma dipakai supaya file bisa di-manage/dihapus lewat akun),
 * "fileToUpload"=file. Response BUKAN JSON kayak LobFile -- sukses
 * balikin URL polos di body (mis. "https://files.catbox.moe/abc123.zip"),
 * gagal balikin teks error polos (mis. "File too large").
 */
public class CatboxUploader implements ResourcePackUploader {

    private static final String UPLOAD_URL = "https://catbox.moe/user/api.php";
    // Sama kayak LobFileUploader dulu -- upload bisa lambat untuk pack
    // besar di koneksi server yang pas-pasan, timeout digenerosikan.
    private static final Duration UPLOAD_TIMEOUT = Duration.ofMinutes(10);
    // Limit hard Catbox, lihat guard ukuran di ResourcePackGenerator
    // (BLOCK_SIZE_BYTES sekarang ikut angka ini, bukan 250MB native MC lagi).
    private static final long CATBOX_MAX_BYTES = 200L * 1024 * 1024;

    private final String userhash;

    /** @param userhash boleh null/kosong -- upload tetap jalan anonim, cuma gak bisa di-manage lewat akun Catbox. */
    public CatboxUploader(String userhash) {
        this.userhash = userhash;
    }

    @Override
    public String providerName() {
        return "Catbox";
    }

    /**
     * Upload synchronous -- WAJIB dipanggil dari thread async (caller,
     * lihat ResourcePackModule, sudah di dalam AsyncUtil.runAsyncThenSync
     * heavyWork), karena ini I/O jaringan yang bisa makan waktu lama.
     */
    @Override
    public UploadResult upload(File zipFile) {
        if (!zipFile.exists()) {
            return UploadResult.fail("File pack '" + zipFile.getAbsolutePath() + "' tidak ditemukan, upload dibatalkan.");
        }
        if (zipFile.length() > CATBOX_MAX_BYTES) {
            // Guard tambahan di sini juga (bukan cuma ResourcePackGenerator) --
            // kalau constants di dua tempat kebetulan out-of-sync suatu saat,
            // upload tetap gagal EKSPLISIT dengan pesan jelas, bukan ke-reject
            // diam-diam sama Catbox dengan error yang membingungkan.
            return UploadResult.fail("Ukuran pack (" + (zipFile.length() / (1024 * 1024))
                    + "MB) melebihi limit Catbox 200MB.");
        }

        try {
            byte[] fileBytes = Files.readAllBytes(zipFile.toPath());
            String boundary = "AudesBoundary" + UUID.randomUUID();
            byte[] body = buildMultipartBody(boundary, zipFile.getName(), fileBytes);

            HttpClient client = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(30))
                    .build();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(UPLOAD_URL))
                    .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                    .timeout(UPLOAD_TIMEOUT)
                    .POST(HttpRequest.BodyPublishers.ofByteArray(body))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            return parseResponse(response.statusCode(), response.body());
        } catch (IOException e) {
            return UploadResult.fail("Gagal koneksi ke Catbox: " + e.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return UploadResult.fail("Upload ke Catbox diinterupsi.");
        } catch (Exception e) {
            // Sengaja tangkap Exception umum di sini (bukan cuma IOException) --
            // sama alasannya kayak LobFileUploader dulu: kegagalan tak terduga
            // gak boleh bikin plugin crash, cukup dilaporkan jelas.
            return UploadResult.fail("Upload ke Catbox gagal tak terduga: " + e.getMessage());
        }
    }

    private UploadResult parseResponse(int statusCode, String responseBody) {
        if (responseBody == null || responseBody.isBlank()) {
            return UploadResult.fail("HTTP " + statusCode + ": respons kosong dari Catbox.");
        }
        String trimmed = responseBody.trim();
        // Catbox TIDAK balikin JSON kayak LobFile -- sukses = body-nya persis
        // URL file (selalu diawali https://files.catbox.moe/), apa pun selain
        // itu (termasuk HTTP non-200) dianggap pesan error dan ditampilkan apa adanya.
        if (statusCode == 200 && trimmed.startsWith("https://files.catbox.moe/")) {
            return UploadResult.ok(trimmed);
        }
        return UploadResult.fail("HTTP " + statusCode + ": " + trimmed);
    }

    private byte[] buildMultipartBody(String boundary, String filename, byte[] fileBytes) throws IOException {
        List<byte[]> parts = new ArrayList<>();

        parts.add(textField(boundary, "reqtype", "fileupload"));
        if (userhash != null && !userhash.isBlank()) {
            parts.add(textField(boundary, "userhash", userhash));
        }

        String fileHead = "--" + boundary + "\r\n"
                + "Content-Disposition: form-data; name=\"fileToUpload\"; filename=\"" + filename + "\"\r\n"
                + "Content-Type: application/zip\r\n\r\n";
        parts.add(fileHead.getBytes(StandardCharsets.UTF_8));
        parts.add(fileBytes);
        parts.add(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));

        int total = 0;
        for (byte[] p : parts) {
            total += p.length;
        }
        byte[] out = new byte[total];
        int pos = 0;
        for (byte[] p : parts) {
            System.arraycopy(p, 0, out, pos, p.length);
            pos += p.length;
        }
        return out;
    }

    private byte[] textField(String boundary, String name, String value) {
        String field = "--" + boundary + "\r\n"
                + "Content-Disposition: form-data; name=\"" + name + "\"\r\n\r\n"
                + value + "\r\n";
        return field.getBytes(StandardCharsets.UTF_8);
    }
}
