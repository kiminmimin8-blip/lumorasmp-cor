package com.audes.plugin.prefix;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registry in-memory untuk definisi prefix per rank, plus rank aktif
 * tiap player.
 *
 * FASE 2 — integrasi LuckPerms udah masuk (sebelumnya FASE 1 manual
 * doang). Kalau LuckPerms ke-detect di server DAN
 * "prefix.luckperms-integration: true" di config.yml, getRank() bakal
 * ambil primary group LuckPerms player itu dulu. Rank itu harus PERSIS
 * sama namanya kayak salah satu key di "prefix:"/"rank-badges:" config
 * (mis. grup LuckPerms "owner" -> otomatis kepake definisi "owner" di
 * sini). Kalau grup LuckPerms-nya gak ada definisinya di Audes, atau
 * LuckPerms gak ke-detect/dimatiin, fallback ke rank manual (/audes
 * setrank) seperti FASE 1, dan kalau itu juga kosong -> defaultRankKey.
 *
 * /audes setrank TETAP jalan sebagai override manual (misal buat rank
 * sementara/testing) -- override ini prioritasnya di ATAS LuckPerms,
 * lihat urutan pengecekan di getRank().
 */
public class PrefixManager {

    private final Plugin plugin;
    private final Map<String, PrefixDefinition> definitions = new LinkedHashMap<>();
    private final Map<UUID, String> playerRank = new ConcurrentHashMap<>();
    private String defaultRankKey = "default";
    private boolean luckPermsIntegration = false;
    private boolean luckPermsAvailable = false;

    public PrefixManager(Plugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig(ConfigurationSection prefixSection) {
        definitions.clear();
        if (prefixSection == null) return;

        for (String rankKey : prefixSection.getKeys(false)) {
            ConfigurationSection s = prefixSection.getConfigurationSection(rankKey);
            if (s == null) continue;

            PrefixDefinition def = new PrefixDefinition(
                    rankKey,
                    s.getString("text", ""),
                    s.getBoolean("show-in-chat", true),
                    s.getBoolean("show-in-tablist", true),
                    s.getBoolean("show-above-head", false)
            );
            definitions.put(rankKey, def);
        }

        luckPermsIntegration = plugin.getConfig().getBoolean("prefix.luckperms-integration", false);
        luckPermsAvailable = luckPermsIntegration && Bukkit.getPluginManager().getPlugin("LuckPerms") != null;
        if (luckPermsIntegration && !luckPermsAvailable) {
            plugin.getLogger().warning("[Audes] prefix.luckperms-integration diaktifin di config, "
                    + "tapi plugin LuckPerms gak ke-detect di server. Fallback ke rank manual (/audes setrank).");
        }
    }

    public PrefixDefinition getDefinitionFor(Player player) {
        String rank = getRank(player);
        return definitions.getOrDefault(rank, definitions.get(defaultRankKey));
    }

    public String getRank(Player player) {
        // 1) Override manual (/audes setrank) menang di atas LuckPerms --
        //    kalau admin pernah nge-set manual buat player ini, itu dipakai.
        String manual = playerRank.get(player.getUniqueId());
        if (manual != null) return manual;

        // 2) LuckPerms primary group, KALAU integrasinya aktif & grup itu
        //    beneran punya definisi rank di Audes (bukan grup LuckPerms
        //    lain yang gak relevan/gak ada prefix-nya di config Audes).
        if (luckPermsAvailable) {
            String lpGroup = getLuckPermsPrimaryGroup(player);
            if (lpGroup != null && definitions.containsKey(lpGroup)) {
                return lpGroup;
            }
        }

        // 3) Fallback default.
        return defaultRankKey;
    }

    private String getLuckPermsPrimaryGroup(Player player) {
        try {
            LuckPerms api = LuckPermsProvider.get();
            User user = api.getUserManager().getUser(player.getUniqueId());
            if (user == null) return null; // belum ke-load, jarang kejadian buat player online
            return user.getPrimaryGroup();
        } catch (IllegalStateException e) {
            // LuckPermsProvider belum siap (mis. dipanggil kepagian pas startup)
            return null;
        }
    }

    /** Override manual -- prioritasnya DI ATAS LuckPerms, lihat getRank(). */
    public void setRank(Player player, String rankKey) {
        playerRank.put(player.getUniqueId(), rankKey);
    }

    /** Hapus override manual, balik ngikut LuckPerms (kalau aktif) atau default. */
    public void clearPlayer(Player player) {
        playerRank.remove(player.getUniqueId());
    }

    public boolean hasRankDefinition(String rankKey) {
        return definitions.containsKey(rankKey);
    }

    public Map<String, PrefixDefinition> getAllDefinitions() {
        return definitions;
    }

    public boolean isLuckPermsIntegrationActive() {
        return luckPermsAvailable;
    }
}
