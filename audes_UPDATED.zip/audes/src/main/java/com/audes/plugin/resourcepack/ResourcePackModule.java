package com.audes.plugin.resourcepack;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import com.audes.plugin.util.AsyncUtil;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.HandlerList;

import java.io.File;
import java.io.IOException;

/**
 * Generator + host resource pack untuk custom item model Audes.
 *
 * Dev4: diimplementasikan berdasarkan skeleton/TODO Dev3.
 * Dev5: manifest (ResourcePackManifest) ditambahkan, prioritas #3 di
 * daftar-fitur-itemsadder.md.
 *
 * Dev14: HOSTING DIGANTI TOTAL. Sampai Dev13, mode default adalah
 * self-host lewat ResourcePackServer (HTTP server bawaan JDK, mirip
 * cara lama ItemsAdder). Ini DIHAPUS, digantikan upload otomatis ke
 * provider eksternal -- self-host webserver kita rawan kelas bug yang
 * SAMA seperti insiden generated.zip ItemsAdder tim (race condition
 * nulis file resourcepack bersamaan saat reload sementara masih ada
 * yang download); upload sekali ke provider luar menghilangkan kelas
 * masalah ini karena kita tidak lagi jaga server hidup sendiri.
 *
 * Dev15: BUKAN cuma satu provider. Insiden akun LobFile kehabisan
 * storage nunjukin hardcode ke satu provider itu titik gagal tunggal --
 * jadi sekarang ada kontrak umum ResourcePackUploader, dan provider mana
 * yang dipakai murni pilihan config, gak ada yang "prioritas utama" di
 * kode (persis pola ItemsAdder yang juga support banyak provider
 * hosting). Nambah provider baru = bikin class baru implements
 * ResourcePackUploader + satu baris di resolveUploader() di bawah.
 *
 * Mode hosting sekarang ("resource-pack.hosting-mode" di config.yml):
 * - "lobfile": generate zip lalu upload ke LobFile, API key dari
 *   secret.yml (field "lobfile-api-key").
 * - "catbox" (default): upload ke Catbox (https://catbox.moe), limit
 *   200MB/file, "userhash" di secret.yml OPSIONAL (kosong = anonim).
 * - "external-url": tim sudah punya CDN/hosting sendiri (Dropbox link,
 *   S3, dst) -- isi manual di "resource-pack.external-url", plugin tidak
 *   upload apa pun, cuma pakai URL itu langsung.
 * Semua field rahasia (API key/userhash) di secret.yml, TIDAK di
 * config.yml, biar gak ke-commit ke git kalau config di-share -- pola
 * sama seperti secret.yml ItemsAdder.
 *
 * Alur enable():
 * 1. Cek folder data/contents/ ada isinya atau tidak. Kalau kosong/tidak
 *    ada, modul tetap "aktif" (bukan error) tapi cuma log info.
 * 2. Generate zip dari contents/ WAJIB async (I/O berat: baca banyak
 *    file + hitung SHA-1 + rebuild manifest, lihat prinsip async di
 *    AsyncUtil).
 * 3. Guard ukuran: 250MB block (generate gagal eksplisit), 100MB warning.
 * 4. Hosting sesuai mode di atas (JUGA async, upload jaringan I/O berat).
 * 5. Kirim ke player saat join lewat ResourcePackJoinListener (Adventure
 *    ResourcePackRequest, native Paper, hash-validated).
 *
 * Dev14 juga menutup TODO Dev13: /audes reload sekarang manggil
 * regenerate() (public), dipanggil dari AudesCommand.handleReload --
 * jadi update aset di contents/ + API key baru di secret.yml bisa
 * langsung dipakai tanpa restart plugin/server.
 */
public class ResourcePackModule implements AudesModule {

    private final AudesPlugin plugin;
    private final ResourcePackManifest manifest;
    private ResourcePackJoinListener joinListener;

    public ResourcePackModule(AudesPlugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.manifest = manifest;
    }

    public ResourcePackManifest getManifest() {
        return manifest;
    }

    @Override
    public String getName() {
        return "resource-pack";
    }

    @Override
    public void enable() {
        regenerate();
    }

    /**
     * Versi ringkas regenerate() buat mode defer-to-rspm: generate zip lokal
     * + rebuild manifest (biar /audes checkmodels tetap akurat), TANPA upload
     * ke LobFile/external-url dan TANPA daftarin join listener (RSPM yang
     * pegang bagian itu). Sama-sama async kayak alur normal, alasannya sama:
     * baca semua file contents/ + hitung SHA-1 itu I/O berat.
     */
    private void generateLocalZipOnly(File contentsFolder, File outputZip) {
        AsyncUtil.runAsyncThenSync(
                plugin,
                () -> {
                    int modelCount = manifest.rebuild(contentsFolder);
                    ResourcePackGenerator.Result zipResult;
                    try {
                        File externalPacksFolder = new File(plugin.getDataFolder(), "external-packs");
                        zipResult = new ResourcePackGenerator().generate(contentsFolder, outputZip, externalPacksFolder, plugin.getLogger());
                    } catch (Exception e) {
                        plugin.getLogger().severe("[Audes] Gagal generate resource pack: " + e.getMessage());
                        zipResult = null;
                    }
                    return new GenerateOutcome(zipResult, modelCount, null);
                },
                outcome -> {
                    if (outcome.zipResult() == null) {
                        plugin.getLogger().severe("[Audes] Generate resource pack gagal, RSPM gak bakal dapet update pack baru.");
                        return;
                    }
                    plugin.getLogger().info("[Audes] audes-pack.zip lokal ke-generate ("
                            + outcome.modelCount() + " modelKey, " + (outcome.zipResult().sizeBytes() / 1024)
                            + "KB) -- siap dibaca RSPM lewat compatible_plugins/audes.yml.");
                }
        );
    }

    /**
     * Generate ulang pack + rebuild manifest + (re-)upload/apply hosting,
     * lalu re-register join listener dengan URL/hash terbaru. Dipanggil
     * dari enable() (startup) DAN dari AudesCommand /audes reload (Dev14,
     * dulu jadi TODO -- lihat catatan kelas di atas).
     */
    public void regenerate() {
        // Aktif/nonaktifnya modul ini diatur lewat "modules.resource-pack"
        // di config.yml (konsisten dengan modul lain, lihat ModuleManager)
        // -- tidak ada toggle kedua di dalam sini supaya tidak membingungkan.
        File contentsFolder = new File(plugin.getDataFolder(), "contents");
        if (!contentsFolder.exists()) {
            contentsFolder.mkdirs();
            plugin.getLogger().info("[Audes] Folder 'contents/' dibuat kosong di " + contentsFolder.getAbsolutePath()
                    + " -- isi struktur namespace aset resource pack di sini, lalu /audes reload untuk generate.");
            return;
        }

        File outputZip = new File(plugin.getDataFolder(), "audes-pack.zip");

        // Dev-fix: kalau ResourcePackManager (RSPM) ke-detect aktif DI SERVER
        // DAN "resource-pack.defer-to-rspm" true (default), Audes CUKUP
        // generate audes-pack.zip lokal (yang emang dibaca RSPM lewat adapter
        // compatible_plugins/audes.yml) -- TIDAK upload ke LobFile/manapun,
        // TIDAK kirim ResourcePackRequest sendiri ke player. RSPM yang jadi
        // satu-satunya pengirim pack ke player (dia udah gabung + self-host +
        // convert Bedrock sendiri). Ini nyegah 2 masalah sekaligus: (1) Audes
        // gak lagi gantung ke kuota LobFile buat item/block/logo-nya tampil,
        // (2) gak ada 2 sistem yang rebutan ngirim pack beda ke player yang
        // sama (kalau join listener Audes nyala bareng RSPM, salah satu bisa
        // ketiban/nimpa yang lain tergantung urutan eksekusi).
        boolean deferToRspm = plugin.getConfig().getBoolean("resource-pack.defer-to-rspm", true);
        boolean rspmActive = plugin.getServer().getPluginManager().getPlugin("ResourcePackManager") != null;
        if (deferToRspm && rspmActive) {
            if (joinListener != null) {
                HandlerList.unregisterAll(joinListener);
                joinListener = null;
            }
            plugin.getLogger().info("[Audes] ResourcePackManager kedetect aktif, Audes SKIP upload/kirim pack sendiri "
                    + "(cukup generate audes-pack.zip lokal buat RSPM). Matiin ini lewat "
                    + "'resource-pack.defer-to-rspm: false' di config.yml kalau mau Audes tetap kirim sendiri.");
            generateLocalZipOnly(contentsFolder, outputZip);
            return;
        }

        String hostingMode = plugin.getConfig().getString("resource-pack.hosting-mode", "catbox");
        String externalUrl = plugin.getConfig().getString("resource-pack.external-url", "");
        boolean required = plugin.getConfig().getBoolean("resource-pack.required", false);
        String promptMessage = plugin.getConfig().getString("resource-pack.prompt-message", "");

        // Lepas listener lama SEBELUM regenerate -- kalau ini dipanggil dari
        // /audes reload (bukan startup pertama), listener lama masih nempel
        // dengan URL/hash pack yang mau digantikan.
        if (joinListener != null) {
            HandlerList.unregisterAll(joinListener);
            joinListener = null;
        }

        // "external-url" bukan ResourcePackUploader (gak ada yang di-upload,
        // URL-nya statis dari config) -- provider yang BENERAN upload
        // di-resolve di sini, satu kali, dipakai di heavyWork bawah.
        // resolveUploader() null artinya mode = "external-url" ATAU mode
        // gak dikenal (dibedain lagi di bawah dengan pesan error jelas).
        ResourcePackUploader uploader = resolveUploader(hostingMode);

        // Lepas listener lama SEBELUM regenerate -- kalau ini dipanggil dari
        // /audes reload (bukan startup pertama), listener lama masih nempel
        // dengan URL/hash pack yang mau digantikan.
        if (joinListener != null) {
            HandlerList.unregisterAll(joinListener);
            joinListener = null;
        }

        // Generate + hosting WAJIB async -- I/O berat (baca semua file contents/
        // + hitung SHA-1 + rebuild manifest + upload jaringan ke provider
        // terpilih), semuanya digabung di satu heavyWork task yang sama.
        AsyncUtil.runAsyncThenSync(
                plugin,
                () -> {
                    // Rebuild manifest DULUAN, terlepas dari sukses/gagalnya zip di bawah --
                    // supaya validasi modelKey tetap jalan meski generate zip gagal
                    // (mis. lewat batas 250MB), bukan ikut gagal total.
                    int modelCount = manifest.rebuild(contentsFolder);
                    ResourcePackGenerator.Result zipResult;
                    try {
                        File externalPacksFolder = new File(plugin.getDataFolder(), "external-packs");
                        zipResult = new ResourcePackGenerator().generate(contentsFolder, outputZip, externalPacksFolder, plugin.getLogger());
                    } catch (Exception e) {
                        plugin.getLogger().severe("[Audes] Gagal generate resource pack: " + e.getMessage());
                        zipResult = null;
                    }

                    ResourcePackUploader.UploadResult uploadResult = null;
                    if (zipResult != null && uploader != null) {
                        // Upload di dalam heavyWork yang sama -- jaringan sama-sama I/O
                        // berat, tidak boleh blocking main thread server. Kode di sini
                        // gak peduli provider-nya apa -- itu keuntungan pakai interface.
                        uploadResult = uploader.upload(outputZip);
                    }
                    return new GenerateOutcome(zipResult, modelCount, uploadResult);
                },
                outcome -> {
                    plugin.getLogger().info("[Audes] Manifest resource pack: " + outcome.modelCount()
                            + " item model terdaftar dari contents/assets/*/items/, "
                            + manifest.equipmentModelCount() + " equipment model dari contents/assets/*/equipment/.");

                    ResourcePackGenerator.Result result = outcome.zipResult();
                    if (result == null) {
                        // Generate gagal (sudah di-log di atas dengan pesan jelas,
                        // bukan silent fail) -- modul tetap "hidup" tapi tanpa kirim pack.
                        // Manifest tetap ke-rebuild jadi setItemModel() tetap bisa
                        // apply untuk model yang asetnya ada, meski pack belum terkirim.
                        return;
                    }

                    if (result.overWarnThreshold()) {
                        plugin.getLogger().warning("[Audes] Resource pack berukuran " + (result.sizeBytes() / (1024 * 1024))
                                + "MB, sudah lewat ambang -- pertimbangkan kompresi aset/texture "
                                + "supaya player koneksi lambat tidak gagal download (lihat bagian 8 dokumen rencana).");
                    }
                    plugin.getLogger().info("[Audes] Resource pack ter-generate (generate ke-" + result.version()
                            + ", " + (result.sizeBytes() / 1024) + "KB, sha1=" + result.sha1Hex() + ").");

                    String url;
                    if (uploader != null) {
                        ResourcePackUploader.UploadResult uploadResult = outcome.uploadResult();
                        if (uploadResult == null || !uploadResult.success()) {
                            String reason = uploadResult != null ? uploadResult.error() : "hasil upload tidak ada (bug internal).";
                            plugin.getLogger().severe("[Audes] Gagal upload resource pack ke " + uploader.providerName() + ": " + reason
                                    + " -- pack TIDAK dikirim ke player sampai upload berhasil. Cek secret.yml, "
                                    + "atau ganti 'resource-pack.hosting-mode' ke provider lain, lalu /audes reload lagi.");
                            return;
                        }
                        url = uploadResult.url();
                        plugin.getLogger().info("[Audes] Resource pack ter-upload ke " + uploader.providerName() + ": " + url);
                    } else if ("external-url".equalsIgnoreCase(hostingMode)) {
                        if (externalUrl == null || externalUrl.isBlank()) {
                            plugin.getLogger().severe("[Audes] resource-pack.hosting-mode = external-url tapi "
                                    + "'external-url' kosong -- isi URL CDN/hosting pack di config.yml.");
                            return;
                        }
                        url = externalUrl;
                    } else {
                        plugin.getLogger().severe("[Audes] resource-pack.hosting-mode = '" + hostingMode
                                + "' tidak dikenal -- pakai 'lobfile', 'catbox', atau 'external-url'.");
                        return;
                    }

                    joinListener = new ResourcePackJoinListener(plugin, url, result.sha1Hex(), required, promptMessage);
                    plugin.getServer().getPluginManager().registerEvents(joinListener, plugin);
                    plugin.getLogger().info("[Audes] Resource pack siap dikirim ke player dari: " + url);
                }
        );
    }

    /**
     * Satu-satunya tempat yang tau daftar provider yang ada -- nambah
     * provider baru cukup nambah satu "case" di sini, gak nyentuh
     * regenerate() sama sekali. Return null buat mode yang BUKAN provider
     * upload ("external-url") -- caller bedain itu dari mode gak dikenal
     * lewat pengecekan string yang sama, lihat blok error di regenerate().
     */
    private ResourcePackUploader resolveUploader(String hostingMode) {
        return switch (hostingMode == null ? "" : hostingMode.toLowerCase()) {
            case "lobfile" -> new LobFileUploader(loadSecret("lobfile-api-key"));
            case "catbox" -> new CatboxUploader(loadSecret("catbox-userhash"));
            default -> null;
        };
    }

    /**
     * secret.yml TERPISAH dari config.yml (pola sama seperti ItemsAdder) --
     * supaya API key/userhash tidak ikut ke-share/ke-commit kalau admin
     * bagi config.yml ke orang lain (mis. minta bantuan debug di
     * forum/Discord). Satu file dipakai BERSAMA oleh semua provider
     * (masing-masing field-nya sendiri) -- generic lewat "key", bukan
     * satu method per provider, biar nambah provider baru gak nambah
     * boilerplate loading di sini juga. File + SEMUA field provider yang
     * dikenal di-scaffold sekaligus pas pertama kali dibuat (kosong
     * semua), jadi server owner tinggal isi yang dia pakai, gak perlu
     * tau dulu field mana yang relevan buat mode yang dia pilih.
     */
    private String loadSecret(String key) {
        File secretFile = new File(plugin.getDataFolder(), "secret.yml");
        if (!secretFile.exists()) {
            try {
                secretFile.getParentFile().mkdirs();
                secretFile.createNewFile();
                YamlConfiguration fresh = new YamlConfiguration();
                fresh.set("lobfile-api-key", "");
                fresh.set("catbox-userhash", "");
                fresh.save(secretFile);
                plugin.getLogger().info("[Audes] File 'secret.yml' dibuat di " + secretFile.getAbsolutePath()
                        + " -- isi field sesuai provider yang dipilih di 'resource-pack.hosting-mode': "
                        + "'lobfile-api-key' (daftar & 'Continuous Uploading' di https://lobfile.com/) atau "
                        + "'catbox-userhash' (opsional, https://catbox.moe/user/login.php -- boleh kosong buat anonim).");
            } catch (IOException e) {
                plugin.getLogger().severe("[Audes] Gagal bikin secret.yml: " + e.getMessage());
                return "";
            }
        }
        YamlConfiguration secret = YamlConfiguration.loadConfiguration(secretFile);
        return secret.getString(key, "");
    }

    @Override
    public void disable() {
        if (joinListener != null) {
            HandlerList.unregisterAll(joinListener);
            joinListener = null;
        }
    }

    /** Hasil gabungan satu siklus heavyWork: zip pack (nullable kalau gagal) + jumlah model + hasil upload (nullable kalau mode "external-url" / zip gagal). */
    private record GenerateOutcome(ResourcePackGenerator.Result zipResult, int modelCount, ResourcePackUploader.UploadResult uploadResult) {
    }
}
