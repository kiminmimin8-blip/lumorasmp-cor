package com.audes.plugin.hud;

/**
 * Satu custom image (logo, shop icon, dsb) yang di-render lewat font
 * glyph — teknik SAMA PERSIS dengan RankBadgeDefinition (lihat javadoc
 * di sana buat penjelasan lengkap soal Private Use Area + resource
 * pack requirement), bedanya cuma dipakai buat gambar besar standalone
 * (mis. logo server di scoreboard/tab, atau icon GUI shop), bukan
 * badge kecil di depan nama.
 *
 * "character" HARUS persis sama dengan yang didaftarkan di font json
 * yang sesuai (lihat "fontId").
 *
 * "fontId" -- nama file font json TANPA extension di
 * contents/assets/audes/font/, mis. "images" untuk
 * contents/assets/audes/font/images.json (isinya serverlogo dkk), atau
 * "shop" untuk contents/assets/audes/font/shop.json (isinya semua
 * shop_* icon). WAJIB cocok, karena tag MiniMessage yang dikirim ke
 * client (lihat AudesPlaceholders) pakai field ini buat nentuin
 * <font:audes:fontId> -- kalau salah, codepoint-nya valid tapi dicari
 * di font json yang SALAH, hasilnya glyph tidak ketemu di client
 * (kotak rusak/kosong), padahal config & resource pack sama-sama
 * "benar" sendiri-sendiri. Bug persis ini yang bikin semua shop_* icon
 * rusak sebelum field ini ditambahkan (dulu semua image, termasuk
 * shop_*, dipaksa pakai font "images" yang cuma isi 2 logo).
 *
 * "bedrockCharacter" OPSIONAL -- Bedrock/Geyser gak pake JSON font
 * provider kayak Java, tapi atlas grid 16x16 per "halaman" unicode
 * (contoh: font/glyph_E1.png = U+E100-U+E1FF). Kalau image ini juga
 * di-daftarin di atlas Bedrock, isi karakter unicode versi Bedrock-nya
 * di sini (BEDA dari "character" versi Java, lihat AudesPlaceholders
 * buat gimana keduanya dipilih otomatis sesuai platform player).
 * Biarin null/kosong kalau image ini cuma didukung di Java (mis. shop
 * icon yang ukurannya terlalu variatif buat digabung ke atlas Bedrock).
 */
public record ImageDefinition(String id, String character, String bedrockCharacter, String fontId) {
}
