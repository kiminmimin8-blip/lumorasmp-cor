package com.sanz.dungeon;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /dungeon                    -> GUI teleport (semua player)
 * /dungeon shop                -> shop dungeon tempat kamu berdiri sekarang (semua player)
 * /dungeon wand|save|setspawn|create|delete|list|edit -> khusus admin
 * /dungeon shopedit [id]        -> khusus admin, GUI kategori+trade shop 1 dungeon
 *                                  (tanpa id = dungeon tempat kamu berdiri)
 * /dungeon shopreload           -> khusus admin, reload shop.yml dari disk
 * /dungeon reload               -> khusus admin, reload config.yml dari disk
 * /dungeon stats [player]       -> statistik dungeon (semua player)
 * /dungeon top [kills|time|deaths|entries] -> leaderboard (semua player)
 * /dungeon info|tp|players|kick|show -> khusus admin (lihat README)
 */
public class DungeonCommand implements CommandExecutor, TabCompleter {

    private static final List<String> ADMIN_SUBCOMMANDS = List.of(
            "wand", "save", "setspawn", "create", "delete", "list", "edit", "shopedit", "shopreload", "reload",
            "info", "tp", "players", "kick", "show", "close", "open", "lbreset"
    );

    private static final List<String> PUBLIC_SUBCOMMANDS = List.of("shop", "stats", "top");
    private static final List<String> ID_ARG_SUBCOMMANDS = List.of(
            "save", "setspawn", "delete", "shopedit", "info", "tp", "players", "show", "close", "open"
    );

    private final DungeonManager manager;
    private final DungeonWandListener wandListener;
    private final DungeonGUI gui;
    private final DungeonEditGUI editGUI;
    private final DungeonShopGUI shopGUI;
    private final ShopEditGUI shopEditGUI;
    private final DungeonShopManager shopManager;
    private final WarpDungeonConfig config;
    private final DungeonTeleporter teleporter;
    private final DungeonTracker tracker;
    private final DungeonStats stats;
    private final DungeonRegionViewer viewer;
    private final DungeonRewards rewards;

    public DungeonCommand(DungeonManager manager, DungeonWandListener wandListener, DungeonGUI gui,
                           DungeonEditGUI editGUI, DungeonShopGUI shopGUI, ShopEditGUI shopEditGUI,
                           DungeonShopManager shopManager, WarpDungeonConfig config,
                           DungeonTeleporter teleporter, DungeonTracker tracker,
                           DungeonStats stats, DungeonRegionViewer viewer, DungeonRewards rewards) {
        this.manager = manager;
        this.wandListener = wandListener;
        this.gui = gui;
        this.editGUI = editGUI;
        this.shopGUI = shopGUI;
        this.shopEditGUI = shopEditGUI;
        this.shopManager = shopManager;
        this.config = config;
        this.teleporter = teleporter;
        this.tracker = tracker;
        this.stats = stats;
        this.viewer = viewer;
        this.rewards = rewards;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }

        // tanpa argumen = buka GUI teleport, kebuka buat semua player
        if (args.length == 0) {
            p.openInventory(gui.build(p));
            return true;
        }

        String sub = args[0].toLowerCase();

        // /dungeon shop kebuka buat semua player, bukan cuma admin.
        // Shop sekarang PER-DUNGEON, jadi dicari dulu kamu lagi berdiri di
        // dungeon mana. Kalau shop-nya cuma punya 1 kategori, langsung
        // loncat ke window trading (openMerchant) - kalau lebih dari 1,
        // muncul dulu GUI pemilihan kategori.
        if (sub.equals("shop")) {
            Dungeon d = manager.getDungeonAt(p.getLocation());
            if (d == null) {
                p.sendMessage(config.getMsgShopNotInDungeon());
                return true;
            }
            DungeonShop shop = shopManager.getOrCreate(d.getId());
            List<ShopCategory> cats = shop.getCategories();
            if (cats.isEmpty()) {
                p.sendMessage(config.getMsgShopEmpty());
            } else if (cats.size() == 1) {
                p.openMerchant(shopGUI.buildMerchant(cats.get(0)), true);
            } else {
                p.openInventory(shopGUI.buildCategorySelect(shop));
            }
            return true;
        }

        if (sub.equals("stats")) {
            showStats(p, args.length >= 2 ? args[1] : null);
            return true;
        }
        if (sub.equals("top")) {
            showTop(p, args.length >= 2 ? args[1].toLowerCase() : "kills");
            return true;
        }

        // subcommand di bawah ini semua khusus admin
        if (!p.hasPermission("dungeon.admin")) {
            p.sendMessage(config.getMsgNoPermission());
            return true;
        }

        switch (sub) {
            case "wand" -> {
                p.getInventory().addItem(wandListener.createWand());
                p.sendMessage(ChatColor.GREEN + "Dungeon wand dikasih. Klik kiri = titik 1, klik kanan = titik 2.");
            }
            case "create" -> {
                if (args.length < 2) { p.sendMessage(ChatColor.RED + "Pakai: /dungeon create <id>"); return true; }
                String id = args[1];
                if (manager.exists(id)) { p.sendMessage(ChatColor.RED + "Dungeon '" + id + "' udah ada."); return true; }
                manager.createDungeon(id);
                p.sendMessage(ChatColor.GREEN + "Dungeon '" + id + "' dibuat. Lanjut /dungeon wand -> /dungeon save " + id + " buat set region-nya.");
            }
            case "delete" -> {
                if (args.length < 2) { p.sendMessage(ChatColor.RED + "Pakai: /dungeon delete <id>"); return true; }
                String id = args[1];
                if (!manager.exists(id)) { p.sendMessage(ChatColor.RED + "Dungeon '" + id + "' gak ketemu."); return true; }
                manager.deleteDungeon(id);
                p.sendMessage(ChatColor.GREEN + "Dungeon '" + id + "' dihapus.");
            }
            case "save" -> {
                if (args.length < 2) { p.sendMessage(ChatColor.RED + "Pakai: /dungeon save <id>"); return true; }
                String id = args[1];
                Dungeon d = manager.get(id);
                if (d == null) { p.sendMessage(ChatColor.RED + "Dungeon '" + id + "' gak ketemu, /dungeon create dulu."); return true; }

                Location p1 = manager.getPoint1(p);
                Location p2 = manager.getPoint2(p);
                if (p1 == null || p2 == null) {
                    p.sendMessage(ChatColor.RED + "Set titik 1 & 2 dulu pakai /dungeon wand.");
                    return true;
                }
                if (!p1.getWorld().equals(p2.getWorld())) {
                    p.sendMessage(ChatColor.RED + "Titik 1 & 2 harus di world yang sama.");
                    return true;
                }

                d.setRegion(p1.getWorld(),
                        p1.getBlockX(), p1.getBlockY(), p1.getBlockZ(),
                        p2.getBlockX(), p2.getBlockY(), p2.getBlockZ());
                manager.save();
                manager.clearSelection(p);
                p.sendMessage(ChatColor.GREEN + "Region dungeon '" + id + "' disimpan & langsung ke-protect.");
            }
            case "setspawn" -> {
                if (args.length < 2) { p.sendMessage(ChatColor.RED + "Pakai: /dungeon setspawn <id>"); return true; }
                String id = args[1];
                Dungeon d = manager.get(id);
                if (d == null) { p.sendMessage(ChatColor.RED + "Dungeon '" + id + "' gak ketemu."); return true; }
                d.setSpawn(p.getLocation());
                manager.save();
                p.sendMessage(ChatColor.GREEN + "Titik teleport masuk dungeon '" + id + "' diset ke posisi kamu sekarang.");
            }
            case "list" -> {
                if (manager.getAll().isEmpty()) {
                    p.sendMessage(ChatColor.YELLOW + "Belum ada dungeon.");
                    return true;
                }
                p.sendMessage(ChatColor.YELLOW + "Daftar dungeon:");
                for (Dungeon d : manager.getAll()) {
                    String status = d.isPremium() ? ChatColor.GOLD + "premium (" + d.getPrice() + " " + d.getCurrency() + ")" : ChatColor.GREEN + "free";
                    String region = d.isRegionSet() ? ChatColor.GREEN + "region OK" : ChatColor.RED + "region belum diset";
                    String spawn = d.isSpawnSet() ? ChatColor.GREEN + "spawn OK" : ChatColor.RED + "spawn belum diset";
                    String open = d.isClosed() ? ChatColor.RED + "DITUTUP" : ChatColor.GREEN + "buka";
                    p.sendMessage(" - " + ChatColor.WHITE + d.getId() + ChatColor.GRAY + " | " + status + ChatColor.GRAY + " | " + region + ChatColor.GRAY + " | " + spawn + ChatColor.GRAY + " | " + open);
                }
            }
            case "edit" -> p.openInventory(editGUI.buildList());
            case "shopedit" -> {
                String dungeonId;
                if (args.length >= 2) {
                    dungeonId = args[1];
                    if (!manager.exists(dungeonId)) {
                        p.sendMessage(ChatColor.RED + "Dungeon '" + dungeonId + "' gak ketemu. Pakai /dungeon list buat liat id yang valid.");
                        return true;
                    }
                } else {
                    Dungeon here = manager.getDungeonAt(p.getLocation());
                    if (here == null) {
                        p.sendMessage(ChatColor.RED + "Kamu lagi gak di dalam dungeon manapun. Pakai: /dungeon shopedit <id>");
                        return true;
                    }
                    dungeonId = here.getId();
                }
                DungeonShop shop = shopManager.getOrCreate(dungeonId);
                p.openInventory(shopEditGUI.buildCategoryList(shop));
            }
            case "shopreload" -> {
                shopManager.reload();
                p.sendMessage(ChatColor.GREEN + "shop.yml di-reload dari disk (" + shopManager.countTotalReadyTrades() + " trade siap total).");
            }
            case "reload" -> {
                config.reload();
                p.sendMessage(ChatColor.GREEN + "config.yml di-reload dari disk.");
            }
            case "info" -> {
                Dungeon d = resolveDungeon(p, args);
                if (d == null) return true;
                showInfo(p, d);
            }
            case "tp" -> {
                if (args.length < 2) { p.sendMessage(ChatColor.RED + "Pakai: /dungeon tp <id>"); return true; }
                Dungeon d = manager.get(args[1]);
                if (d == null) { p.sendMessage(ChatColor.RED + "Dungeon '" + args[1] + "' gak ketemu."); return true; }
                // force = lewati syarat, tiket, dan hitung mundur
                teleporter.enter(p, d, true);
            }
            case "players" -> showPlayers(p, args.length >= 2 ? args[1] : null);
            case "kick" -> {
                if (args.length < 2) { p.sendMessage(ChatColor.RED + "Pakai: /dungeon kick <player>"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { p.sendMessage(ChatColor.RED + "Player '" + args[1] + "' gak lagi online."); return true; }
                if (tracker.getSession(target.getUniqueId()) == null) {
                    p.sendMessage(ChatColor.RED + target.getName() + " lagi gak di dalam dungeon.");
                    return true;
                }
                Location exit = DungeonTracker.exitLocation();
                target.teleportAsync(exit);
                p.sendMessage(ChatColor.GREEN + target.getName() + " dikeluarin dari dungeon (dikirim ke spawn world).");
            }
            case "close" -> {
                if (args.length < 2) { p.sendMessage(ChatColor.RED + "Pakai: /dungeon close <id> [alasan]"); return true; }
                Dungeon d = manager.get(args[1]);
                if (d == null) { p.sendMessage(ChatColor.RED + "Dungeon '" + args[1] + "' gak ketemu."); return true; }
                String reason = args.length >= 3 ? String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length)) : "";
                d.setClosed(true);
                d.setClosedReason(reason);
                manager.save();
                p.sendMessage(ChatColor.GREEN + "Dungeon '" + d.getId() + "' ditutup"
                        + (reason.isBlank() ? "." : " (alasan: " + reason + ").")
                        + " Yang lagi di dalam gak dikeluarin.");
            }
            case "open" -> {
                if (args.length < 2) { p.sendMessage(ChatColor.RED + "Pakai: /dungeon open <id>"); return true; }
                Dungeon d = manager.get(args[1]);
                if (d == null) { p.sendMessage(ChatColor.RED + "Dungeon '" + args[1] + "' gak ketemu."); return true; }
                d.setClosed(false);
                d.setClosedReason("");
                manager.save();
                p.sendMessage(ChatColor.GREEN + "Dungeon '" + d.getId() + "' dibuka lagi.");
            }
            case "lbreset" -> {
                if (args.length < 2 || !args[1].equalsIgnoreCase("confirm")) {
                    p.sendMessage(ChatColor.RED + "Ini bakal nutup periode leaderboard SEKARANG: hadiah juara dibagiin & kill periode direset.");
                    p.sendMessage(ChatColor.RED + "Kalau yakin, ketik: /dungeon lbreset confirm");
                    return true;
                }
                if (rewards.forceReset()) {
                    p.sendMessage(ChatColor.GREEN + "Periode leaderboard ditutup. Lihat hasilnya di /dungeon top last");
                } else {
                    p.sendMessage(ChatColor.RED + "Leaderboard periodik lagi off (leaderboard.reset di config.yml).");
                }
            }
            case "show" -> {
                Dungeon d = resolveDungeon(p, args);
                if (d == null) return true;
                if (viewer.show(p, d, 15)) {
                    p.sendMessage(ChatColor.GREEN + "Batas dungeon '" + d.getId() + "' ditampilin 15 detik (partikel putih).");
                } else {
                    p.sendMessage(ChatColor.RED + "Region dungeon itu belum diset, atau kamu beda world sama dungeon-nya.");
                }
            }
            default -> p.sendMessage(ChatColor.RED + "Subcommand gak dikenal. Pakai: /dungeon <shop|stats|top|wand|save|setspawn|create|delete|list|info|tp|players|kick|show|close|open|lbreset|edit|shopedit|shopreload|reload>");
        }
        return true;
    }

    // ---------- helper ----------

    /** id dari args[1], atau dungeon tempat admin lagi berdiri kalau id gak dikasih. */
    private Dungeon resolveDungeon(Player p, String[] args) {
        if (args.length >= 2) {
            Dungeon d = manager.get(args[1]);
            if (d == null) p.sendMessage(ChatColor.RED + "Dungeon '" + args[1] + "' gak ketemu. Pakai /dungeon list buat liat id yang valid.");
            return d;
        }
        Dungeon here = manager.getDungeonAt(p.getLocation());
        if (here == null) p.sendMessage(ChatColor.RED + "Kamu lagi gak di dalam dungeon manapun. Pakai: /dungeon " + "<subcommand> <id>");
        return here;
    }

    private void showInfo(Player p, Dungeon d) {
        p.sendMessage(ChatColor.GOLD + "=== Dungeon: " + ChatColor.WHITE + d.getId() + ChatColor.GOLD + " ===");
        p.sendMessage(ChatColor.YELLOW + "Nama: " + ChatColor.WHITE + d.getDisplayName());
        p.sendMessage(ChatColor.YELLOW + "Tipe: " + ChatColor.WHITE
                + (d.isPremium() ? "Premium (" + d.getPrice() + " " + d.getCurrency() + " / masuk)" : "Free"));
        if (d.isRegionSet()) {
            int sx = d.getX2() - d.getX1() + 1;
            int sy = d.getY2() - d.getY1() + 1;
            int sz = d.getZ2() - d.getZ1() + 1;
            p.sendMessage(ChatColor.YELLOW + "Region: " + ChatColor.WHITE + d.getWorldName() + " "
                    + d.getX1() + "," + d.getY1() + "," + d.getZ1() + " -> "
                    + d.getX2() + "," + d.getY2() + "," + d.getZ2()
                    + ChatColor.GRAY + " (" + sx + "x" + sy + "x" + sz + " block)");
        } else {
            p.sendMessage(ChatColor.YELLOW + "Region: " + ChatColor.RED + "belum diset");
        }
        p.sendMessage(ChatColor.YELLOW + "Spawn: " + (d.isSpawnSet() ? ChatColor.GREEN + "OK" : ChatColor.RED + "belum diset"));
        p.sendMessage(ChatColor.YELLOW + "Status: " + (d.isClosed()
                ? ChatColor.RED + "DITUTUP" + (d.getClosedReason().isBlank() ? "" : " (" + d.getClosedReason() + ")")
                : ChatColor.GREEN + "Terbuka"));
        p.sendMessage(ChatColor.YELLOW + "Cooldown: " + ChatColor.WHITE
                + (d.getCooldownSeconds() > 0 ? DungeonTracker.formatDuration(d.getCooldownSeconds()) : "tanpa cooldown"));
        p.sendMessage(ChatColor.YELLOW + "Maks pemain: " + ChatColor.WHITE
                + (d.getMaxPlayers() > 0 ? String.valueOf(d.getMaxPlayers()) : "tanpa batas"));
        p.sendMessage(ChatColor.YELLOW + "Level minimal: " + ChatColor.WHITE
                + (d.getMinLevel() > 0 ? String.valueOf(d.getMinLevel()) : "tanpa syarat"));
        p.sendMessage(ChatColor.YELLOW + "Permission: " + ChatColor.WHITE
                + (d.getPermission().isBlank() ? "tanpa permission" : d.getPermission()));
        p.sendMessage(ChatColor.YELLOW + "Pemain di dalam: " + ChatColor.WHITE + tracker.countInside(d.getId()));
    }

    private void showPlayers(Player p, String onlyId) {
        boolean any = false;
        for (Dungeon d : manager.getAll()) {
            if (onlyId != null && !d.getId().equalsIgnoreCase(onlyId)) continue;
            List<String> names = tracker.namesInside(d.getId());
            if (names.isEmpty() && onlyId == null) continue;
            any = true;
            String list = names.isEmpty() ? "(kosong)" : String.join(", ", names);
            p.sendMessage(ChatColor.YELLOW + d.getId() + ChatColor.GRAY + " [" + names.size() + "]: " + ChatColor.WHITE + list);
        }
        if (!any) p.sendMessage(ChatColor.YELLOW + "Gak ada yang lagi di dalam dungeon.");
    }

    private void showStats(Player p, String targetName) {
        DungeonStats.Entry e;
        String who;
        if (targetName == null) {
            e = stats.get(p.getUniqueId());
            who = p.getName();
        } else {
            e = stats.findByName(targetName);
            who = targetName;
        }
        if (e == null) {
            p.sendMessage(ChatColor.RED + "Belum ada data statistik dungeon buat " + who + ".");
            return;
        }
        p.sendMessage(ChatColor.GOLD + "=== Statistik Dungeon: " + ChatColor.WHITE + e.name + ChatColor.GOLD + " ===");
        p.sendMessage(ChatColor.YELLOW + "Total kill: " + ChatColor.WHITE + e.kills);
        p.sendMessage(ChatColor.YELLOW + "Kill periode ini: " + ChatColor.WHITE + e.periodKills);
        p.sendMessage(ChatColor.YELLOW + "Total mati: " + ChatColor.WHITE + e.deaths);
        p.sendMessage(ChatColor.YELLOW + "Masuk dungeon: " + ChatColor.WHITE + e.entries + "x");
        p.sendMessage(ChatColor.YELLOW + "Total waktu di dalam: " + ChatColor.WHITE + DungeonTracker.formatDuration(e.seconds));
    }

    private void showTop(Player p, String type) {
        if (!DungeonStats.TYPES.contains(type)) {
            p.sendMessage(ChatColor.RED + "Kategori gak dikenal. Pilih: " + String.join(", ", DungeonStats.TYPES));
            return;
        }
        if (type.equals("last")) {
            List<DungeonStats.Winner> winners = stats.getLastWinners();
            if (winners.isEmpty()) {
                p.sendMessage(ChatColor.YELLOW + "Belum ada juara dari periode sebelumnya.");
                return;
            }
            p.sendMessage(ChatColor.GOLD + "=== Juara periode lalu ===");
            for (DungeonStats.Winner w : winners) {
                p.sendMessage(ChatColor.YELLOW + "#" + w.rank + " " + ChatColor.WHITE + w.name + ChatColor.GRAY + " - " + ChatColor.AQUA + w.kills + " kill");
            }
            return;
        }
        List<DungeonStats.Entry> top = stats.top(type, 10);
        if (top.isEmpty()) {
            p.sendMessage(ChatColor.YELLOW + "Belum ada data buat leaderboard ini.");
            return;
        }
        String title;
        switch (type) {
            case "time": title = "Waktu terlama di dungeon"; break;
            case "deaths": title = "Paling sering mati"; break;
            case "entries": title = "Paling sering masuk"; break;
            case "period": title = "Kill terbanyak periode ini"; break;
            default: title = "Kill terbanyak"; break;
        }
        p.sendMessage(ChatColor.GOLD + "=== Top 10: " + title + " ===");
        int rank = 1;
        for (DungeonStats.Entry e : top) {
            long value = DungeonStats.value(e, type);
            String shown = type.equals("time") ? DungeonTracker.formatDuration(value) : String.valueOf(value);
            p.sendMessage(ChatColor.YELLOW + String.valueOf(rank) + ". " + ChatColor.WHITE + e.name + ChatColor.GRAY + " - " + ChatColor.AQUA + shown);
            rank++;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        boolean isAdmin = sender.hasPermission("dungeon.admin");

        if (args.length == 1) {
            List<String> options = new ArrayList<>(PUBLIC_SUBCOMMANDS);
            if (isAdmin) options.addAll(ADMIN_SUBCOMMANDS);
            return options.stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }

        String sub = args[0].toLowerCase();

        if (args.length == 2 && sub.equals("top")) {
            return DungeonStats.TYPES.stream()
                    .filter(s -> s.startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (args.length == 2 && (sub.equals("stats") || (isAdmin && sub.equals("kick")))) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
        }

        if (!isAdmin) return new ArrayList<>();

        if (args.length == 2 && sub.equals("lbreset")) {
            return List.of("confirm");
        }
        if (args.length == 2 && ID_ARG_SUBCOMMANDS.contains(sub)) {
            return manager.getAll().stream()
                    .map(Dungeon::getId)
                    .filter(id -> id.startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
        }
        return new ArrayList<>();
    }
}
