package com.sanz.dungeon;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/**
 * /dungeon show <id> - gambar kotak region dungeon pakai partikel selama
 * beberapa detik, biar admin bisa cek batasnya tanpa WorldEdit.
 * Cuma titik dalam jarak 48 block dari admin yang digambar (client gak
 * nge-render partikel yang lebih jauh dari itu).
 */
public class DungeonRegionViewer {

    private static final double VIEW_DISTANCE_SQ = 48.0 * 48.0;

    private final Plugin plugin;

    public DungeonRegionViewer(Plugin plugin) {
        this.plugin = plugin;
    }

    /** @return false kalau region belum diset / beda world sama player. */
    public boolean show(Player p, Dungeon d, int seconds) {
        if (!d.isRegionSet()) return false;
        World w = Bukkit.getWorld(d.getWorldName());
        if (w == null || !w.equals(p.getWorld())) return false;

        final int maxRuns = Math.max(1, seconds * 2); // tiap 10 tick
        final int[] runs = {0};
        p.getScheduler().runAtFixedRate(plugin, task -> {
            if (!p.isOnline() || runs[0] >= maxRuns) {
                task.cancel();
                return;
            }
            runs[0]++;
            draw(p, d);
        }, null, 1L, 10L);
        return true;
    }

    private void draw(Player p, Dungeon d) {
        double x1 = d.getX1();
        double y1 = d.getY1();
        double z1 = d.getZ1();
        double x2 = d.getX2() + 1.0;
        double y2 = d.getY2() + 1.0;
        double z2 = d.getZ2() + 1.0;

        // 4 garis bawah
        line(p, x1, y1, z1, x2, y1, z1);
        line(p, x1, y1, z2, x2, y1, z2);
        line(p, x1, y1, z1, x1, y1, z2);
        line(p, x2, y1, z1, x2, y1, z2);
        // 4 garis atas
        line(p, x1, y2, z1, x2, y2, z1);
        line(p, x1, y2, z2, x2, y2, z2);
        line(p, x1, y2, z1, x1, y2, z2);
        line(p, x2, y2, z1, x2, y2, z2);
        // 4 tiang vertikal
        line(p, x1, y1, z1, x1, y2, z1);
        line(p, x2, y1, z1, x2, y2, z1);
        line(p, x1, y1, z2, x1, y2, z2);
        line(p, x2, y1, z2, x2, y2, z2);
    }

    private void line(Player p, double ax, double ay, double az, double bx, double by, double bz) {
        double dx = bx - ax;
        double dy = by - ay;
        double dz = bz - az;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        int steps = (int) Math.max(1.0, Math.min(len, 400.0));
        Location pl = p.getLocation();

        for (int i = 0; i <= steps; i++) {
            double t = (double) i / (double) steps;
            double x = ax + dx * t;
            double y = ay + dy * t;
            double z = az + dz * t;

            double ox = x - pl.getX();
            double oy = y - pl.getY();
            double oz = z - pl.getZ();
            if (ox * ox + oy * oy + oz * oz > VIEW_DISTANCE_SQ) continue;

            p.spawnParticle(Particle.END_ROD, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
        }
    }
}
