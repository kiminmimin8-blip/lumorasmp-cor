package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class DungeonGUI {

    private final DungeonManager manager;
    private final DungeonTracker tracker;
    private final DungeonTeleporter teleporter;

    public DungeonGUI(DungeonManager manager, DungeonTracker tracker, DungeonTeleporter teleporter) {
        this.manager = manager;
        this.tracker = tracker;
        this.teleporter = teleporter;
    }

    public Inventory build(Player viewer) {
        List<Dungeon> all = new ArrayList<>(manager.getAll());
        all.sort(Comparator.comparing(Dungeon::getId));

        // auto-assign slot buat dungeon yg belum punya slot
        int nextFree = 0;
        List<Integer> usedSlots = all.stream()
                .map(Dungeon::getGuiSlot)
                .filter(s -> s >= 0)
                .toList();

        int maxSlot = 8; // minimal 1 baris
        for (Dungeon d : all) {
            if (d.getGuiSlot() >= 0) {
                maxSlot = Math.max(maxSlot, d.getGuiSlot());
            }
        }
        int size = ((maxSlot / 9) + 1) * 9;
        if (size < 27) size = 27;
        if (size > 54) size = 54;

        DungeonGUIHolder holder = new DungeonGUIHolder();
        Inventory inv = Bukkit.createInventory(holder, size, ChatColor.DARK_PURPLE + "Dungeon");
        holder.setInventory(inv);

        for (Dungeon d : all) {
            int slot = d.getGuiSlot();
            if (slot < 0 || slot >= size || inv.getItem(slot) != null) {
                while (nextFree < size && (inv.getItem(nextFree) != null || usedSlots.contains(nextFree))) nextFree++;
                slot = nextFree;
                if (slot >= size) continue; // GUI penuh
            }

            inv.setItem(slot, buildIcon(d, viewer));
            holder.map(slot, d.getId());
        }

        return inv;
    }

    private ItemStack buildIcon(Dungeon d, Player viewer) {
        ItemStack item = new ItemStack(d.getDisplayItem());
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + d.getDisplayName());

        List<String> lore = new ArrayList<>();
        for (String line : d.getDescription()) {
            lore.add(ChatColor.GRAY + line);
        }
        lore.add("");
        if (d.isPremium()) {
            lore.add(ChatColor.GOLD + "Premium - " + d.getPrice() + " " + d.getCurrency() + " / masuk");
        } else {
            lore.add(ChatColor.GREEN + "Gratis");
        }

        // jumlah pemain di dalam (+ batas kalau ada)
        int inside = tracker.countInside(d.getId());
        String playersText = d.getMaxPlayers() > 0 ? inside + "/" + d.getMaxPlayers() : String.valueOf(inside);
        lore.add(ChatColor.GRAY + "Pemain di dalam: " + ChatColor.WHITE + playersText);

        // syarat masuk - merah kalau kamu belum memenuhi, hijau kalau udah
        if (d.getMinLevel() > 0) {
            boolean ok = viewer.getLevel() >= d.getMinLevel();
            lore.add((ok ? ChatColor.GREEN : ChatColor.RED) + "Level minimal: " + d.getMinLevel());
        }
        if (!d.getPermission().isBlank()) {
            boolean ok = viewer.hasPermission(d.getPermission());
            lore.add(ok ? ChatColor.GREEN + "Akses khusus: punya" : ChatColor.RED + "Butuh akses khusus");
        }
        if (d.getCooldownSeconds() > 0) {
            long left = teleporter.getCooldownLeft(viewer, d);
            if (left > 0) {
                lore.add(ChatColor.RED + "Cooldown: " + DungeonTracker.formatDuration(left));
            } else {
                lore.add(ChatColor.GRAY + "Cooldown: " + DungeonTracker.formatDuration(d.getCooldownSeconds()) + " / masuk");
            }
        }

        lore.add("");
        if (d.isClosed()) {
            String reason = d.getClosedReason();
            lore.add(ChatColor.RED + "DITUTUP" + (reason.isBlank() ? "" : ": " + reason));
        } else if (!d.isRegionSet() || !d.isSpawnSet()) {
            lore.add(ChatColor.RED + "(belum siap - hubungi admin)");
        } else {
            lore.add(ChatColor.YELLOW + "Klik buat teleport");
        }
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }
}
