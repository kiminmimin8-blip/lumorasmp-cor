# LastManStanding (Paper 1.21.11, Java 21)

Event PvP survival: pemain masuk lewat `/event`, nunggu dan cari resource sendiri, admin mulai manual, border mengecil otomatis, yang terakhir hidup menang.

## Build

```
mvn clean package
```

Hasilnya `target/LastManStanding-1.0.0.jar`, taruh di folder `plugins/`. Butuh Java 21.

## Setup (sekali aja)

1. Siapin world khusus event. Pemain boleh nambang dan bangun, jadi world-nya bakal berubah. Border juga per-world.
2. Berdiri di titik masuk event: `/event setlobby`
3. Berdiri di tengah area (jadi pusat border): `/event setcenter` (harus satu world dengan titik masuk)
4. Taruh chest loot di beberapa tempat:
   - Pasang chest (atau barrel), isi dengan item yang lumayan
   - Lihat chest itu (maks 6 block), lalu `/event chest add`
   - Isi berubah? Lihat chest itu lagi dan `/event chest add` lagi buat update snapshot
   - `/event chest remove` buat hapus, `/event chest list` buat lihat semua
5. Atur `plugins/LastManStanding/config.yml`, lalu `/event reload`

## Command

| Command | Fungsi |
|---|---|
| `/event` | masuk event (pemain, cuma bisa kalau admin udah `/event on`) |
| `/event keluar` / `status` | pemain |
| `/event on` / `off` | buka event biar pemain bisa masuk / tutup dan balikin semua pemain (admin) |
| `/event mulai` | mulai event: tulisan "Event dimulai 3, 2, 1" lalu PvP on (admin) |
| `/event stop` | hentikan event dan balikin semua pemain (admin) |
| `/event setlobby` / `setcenter` | set lokasi (admin) |
| `/event chest add` / `remove` / `list` | kelola chest loot (admin) |
| `/event setloot` | opsional: loot airdrop dari inventory (admin) |
| `/event reload` | reload config (admin) |

`/lms` dan `/lastman` bisa dipakai sebagai alias. Permission: `lms.play` (default semua), `lms.admin` (default op).

## Alur

0. **Buka**: admin `/event on`. Border dipasang dan chest loot diisi. Sebelum ini `/event` ditolak.
1. **Nunggu**: pemain `/event`, masuk ke titik masuk, inventory aslinya disimpan lalu dikosongin. PvP mati. Mereka cari resource sendiri dan boleh `/rtp`. 
2. **Mulai**: admin `/event mulai` (minimal 2 pemain), tulisan "Event dimulai 3", "2", "1" muncul di layar, lalu PvP on.
3. **Border**: mulai dari 1000 block, mengecil 10 block tiap 20 detik. Setelah 100 block ke bawah mengecil 2 block tiap 10 detik. Semua bisa diubah di `border.shrink`. Berhenti di `border.min-size` (default 10).
4. **Eliminasi**: mati berarti jadi spectator. Item jatuh jadi loot.
5. **Menang**: sisa 1 pemain. Hadiah dijalankan, kembang api, chest loot dikosongin, semua dibalikin ke lokasi dan inventory awal.

## Aturan di dalam event

- Cuma command di `game.allowed-commands` yang boleh (default: `/rtp`, `/lobby`, `/home`, plus `/event`). Sisanya diblok, termasuk `/sethome /ec /vault /enderchest /warp /kits /ah /order /shop /sellrefund /team /back`. Admin bebas.
- `/lobby` atau `/home` (atau teleport lain keluar dari world event) otomatis dianggap keluar dari event. Inventory event dijatuhkan di titik terakhir, inventory asli dibalikin.
- `/back` nggak bisa dipakai dari dalam, dan orang di luar nggak bisa masuk world event lewat `/back`, `/tpa`, dll. Satu-satunya jalan masuk adalah `/event` (`game.block-outside-entry`).
- Portal nether dan end nggak bisa dibuat atau dipakai di world event (api di frame obsidian, ender eye di frame end diblok).
- Chest loot terdaftar nggak bisa dihancurin pemain.

## Config (semua bisa diatur)

Semua ada di `config.yml`, lalu `/event reload`. Aturan border dan pengaturan sesi yang lagi jalan baru kepakai di event berikutnya.

| Bagian | Isinya |
|---|---|
| `game` | min/max pemain, hitung mundur, proteksi, PvP pas nunggu, batas waktu, jeda akhir, hunger, boleh nambang/bangun, command yang diizinkan, portal, tinggi spectator, jumlah top kill, dll |
| `border` | ukuran awal, ukuran minimum, jeda sebelum mulai mengecil, damage, buffer, warning, daftar aturan `shrink` (above/amount/interval) |
| `bossbar` / `actionbar` / `titles` | nyala/mati, warna, gaya, waktu tampil |
| `sounds` | tiap sound (ID vanilla, volume, pitch), bisa dimatiin satu-satu |
| `celebration` | kembang api pemenang: jumlah, jeda, tipe, warna, power |
| `airdrop`, `rewards` | chest random opsional, command hadiah |
| `messages` | semua teks |

## Hadiah

Isi di `config.yml` bagian `rewards`, command dijalankan console dan `%player%` diganti nama pemain:

```yaml
rewards:
  winner-commands:
    - "eco give %player% 5000"
  participation-commands: []
  kill-commands: []
```

## Keamanan data pemain

Kondisi asli pemain (inventory, lokasi, gamemode, health, XP, efek) disimpan di `plugins/LastManStanding/saved/<uuid>.yml` dan dihapus setelah dibalikin.
Kalau pemain disconnect atau server crash di tengah event, datanya tetap dibalikin otomatis pas dia login lagi.

## Catatan

- Block yang dihancurin atau dipasang pemain nggak di-rollback otomatis. Pakai world event yang bisa di-reset.
- Command lain seperti `/rtp` jalan dari plugin lain di server lu. Plugin ini cuma mengizinkannya.
- Opsional: `start.rtp-all: true` buat nyebar semua pemain acak pas `/event mulai`, `airdrop.enabled: true` buat chest random berkala.
