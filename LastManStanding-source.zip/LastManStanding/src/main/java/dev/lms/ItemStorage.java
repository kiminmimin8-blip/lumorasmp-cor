package dev.lms;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/** Simpan/baca array ItemStack ke yml (item custom + NBT/PDC ikut kebawa lewat serialisasi Bukkit). */
final class ItemStorage {

    record Loaded(ItemStack[] storage, ItemStack[] armor, ItemStack[] extra) {
    }

    private ItemStorage() {
    }

    static void save(File file, ItemStack[] storage, ItemStack[] armor, ItemStack[] extra) throws IOException {
        YamlConfiguration y = new YamlConfiguration();
        y.set("storage", Arrays.asList(storage));
        y.set("armor", Arrays.asList(armor));
        y.set("extra", Arrays.asList(extra));
        file.getParentFile().mkdirs();
        y.save(file);
    }

    static Loaded load(File file) {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        return new Loaded(
                toArray(y.getList("storage"), 36),
                toArray(y.getList("armor"), 4),
                toArray(y.getList("extra"), 1));
    }

    static ItemStack[] toArray(List<?> list, int size) {
        ItemStack[] out = new ItemStack[size];
        if (list != null) {
            for (int i = 0; i < Math.min(size, list.size()); i++) {
                if (list.get(i) instanceof ItemStack item) {
                    out[i] = item;
                }
            }
        }
        return out;
    }

    static ItemStack[] cloneAll(ItemStack[] src) {
        ItemStack[] out = new ItemStack[src.length];
        for (int i = 0; i < src.length; i++) {
            out[i] = src[i] == null ? null : src[i].clone();
        }
        return out;
    }
}
