package dev.lms;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * Snapshot kondisi pemain sebelum masuk event. Disimpan ke disk (saved/UUID.yml),
 * jadi kalau pemain disconnect atau server crash, datanya tetap balik pas login lagi.
 */
final class SavedState {

    private final Location location;
    private final GameMode gameMode;
    private final double health;
    private final int food;
    private final float saturation;
    private final float exp;
    private final int level;
    private final ItemStack[] storage;
    private final ItemStack[] armor;
    private final ItemStack[] extra;
    private final List<PotionEffect> effects;

    private SavedState(Location location, GameMode gameMode, double health, int food, float saturation,
                       float exp, int level, ItemStack[] storage, ItemStack[] armor, ItemStack[] extra,
                       List<PotionEffect> effects) {
        this.location = location;
        this.gameMode = gameMode;
        this.health = health;
        this.food = food;
        this.saturation = saturation;
        this.exp = exp;
        this.level = level;
        this.storage = storage;
        this.armor = armor;
        this.extra = extra;
        this.effects = effects;
    }

    static File file(LMSPlugin plugin, UUID id) {
        return new File(new File(plugin.getDataFolder(), "saved"), id + ".yml");
    }

    static boolean exists(LMSPlugin plugin, UUID id) {
        return file(plugin, id).exists();
    }

    static SavedState capture(Player p) {
        PlayerInventory inv = p.getInventory();
        return new SavedState(
                p.getLocation().clone(),
                p.getGameMode(),
                p.getHealth(),
                p.getFoodLevel(),
                p.getSaturation(),
                p.getExp(),
                p.getLevel(),
                ItemStorage.cloneAll(inv.getStorageContents()),
                ItemStorage.cloneAll(inv.getArmorContents()),
                ItemStorage.cloneAll(inv.getExtraContents()),
                new ArrayList<>(p.getActivePotionEffects()));
    }

    void save(LMSPlugin plugin, UUID id) {
        YamlConfiguration y = new YamlConfiguration();
        LocUtil.write(y, "location", location);
        y.set("gamemode", gameMode.name());
        y.set("health", health);
        y.set("food", food);
        y.set("saturation", (double) saturation);
        y.set("exp", (double) exp);
        y.set("level", level);
        y.set("storage", Arrays.asList(storage));
        y.set("armor", Arrays.asList(armor));
        y.set("extra", Arrays.asList(extra));
        y.set("effects", new ArrayList<>(effects));
        try {
            File f = file(plugin, id);
            f.getParentFile().mkdirs();
            y.save(f);
        } catch (IOException e) {
            plugin.getLogger().severe("Gagal simpan state pemain " + id + ": " + e.getMessage());
        }
    }

    static SavedState load(LMSPlugin plugin, UUID id) {
        File f = file(plugin, id);
        if (!f.exists()) {
            return null;
        }
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        GameMode gm;
        try {
            gm = GameMode.valueOf(y.getString("gamemode", "SURVIVAL"));
        } catch (IllegalArgumentException e) {
            gm = GameMode.SURVIVAL;
        }
        List<PotionEffect> effects = new ArrayList<>();
        List<?> rawEffects = y.getList("effects");
        if (rawEffects != null) {
            for (Object o : rawEffects) {
                if (o instanceof PotionEffect pe) {
                    effects.add(pe);
                }
            }
        }
        return new SavedState(
                LocUtil.read(y, "location"),
                gm,
                y.getDouble("health", 20.0),
                y.getInt("food", 20),
                (float) y.getDouble("saturation", 5.0),
                (float) y.getDouble("exp", 0.0),
                y.getInt("level", 0),
                ItemStorage.toArray(y.getList("storage"), 36),
                ItemStorage.toArray(y.getList("armor"), 4),
                ItemStorage.toArray(y.getList("extra"), 1),
                effects);
    }

    /** Balikin kondisi pemain lalu hapus filenya. Kalau file nggak ada, pemain cuma direset dan dipindah ke spawn. */
    static void restoreAndDelete(LMSPlugin plugin, Player p) {
        restoreAndDelete(plugin, p, true);
    }

    /**
     * Versi dengan pilihan teleport. teleport=false dipakai kalau pemain sudah pergi sendiri lewat command lain
     * (misal /lobby atau /home): inventory dan kondisinya dibalikin, tapi lokasinya dibiarkan di tujuan baru.
     */
    static void restoreAndDelete(LMSPlugin plugin, Player p, boolean teleport) {
        UUID id = p.getUniqueId();
        SavedState state = load(plugin, id);
        if (state == null) {
            PlayerUtil.reset(p, GameMode.SURVIVAL);
            if (teleport) {
                PlayerUtil.teleport(p, plugin.getServer().getWorlds().get(0).getSpawnLocation());
            }
            return;
        }
        state.apply(p, teleport);
        File f = file(plugin, id);
        if (f.exists() && !f.delete()) {
            plugin.getLogger().warning("Gagal hapus file state " + f.getName());
        }
    }

    private void apply(Player p, boolean teleport) {
        PlayerUtil.reset(p, GameMode.SURVIVAL);
        if (teleport) {
            Location target = location != null ? location : p.getServer().getWorlds().get(0).getSpawnLocation();
            PlayerUtil.teleport(p, target);
        }

        PlayerInventory inv = p.getInventory();
        inv.setStorageContents(ItemStorage.cloneAll(storage));
        inv.setArmorContents(ItemStorage.cloneAll(armor));
        inv.setExtraContents(ItemStorage.cloneAll(extra));

        for (PotionEffect effect : effects) {
            p.addPotionEffect(effect);
        }
        p.setLevel(level);
        p.setExp(exp);
        p.setFoodLevel(food);
        p.setSaturation(saturation);
        p.setHealth(Math.max(1.0, Math.min(health, PlayerUtil.maxHealth(p))));
        p.setGameMode(gameMode);
    }
}
