package dev.lms;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;

import java.util.ArrayList;

final class PlayerUtil {

    /** True selama teleport yang dilakukan plugin ini sendiri, supaya listener teleport mengabaikannya. */
    private static boolean internalTeleport;

    private PlayerUtil() {
    }

    static boolean isInternalTeleport() {
        return internalTeleport;
    }

    /** Teleport dari plugin ini (masuk event, restore, dll), nggak dianggap pemain keluar/masuk lewat command lain. */
    static void teleport(Player p, Location target) {
        internalTeleport = true;
        try {
            p.teleport(target);
        } finally {
            internalTeleport = false;
        }
    }

    static void clearInventory(Player p) {
        PlayerInventory inv = p.getInventory();
        inv.clear();
        inv.setArmorContents(new ItemStack[4]);
        inv.setExtraContents(new ItemStack[1]);
        inv.setItemInOffHand(new ItemStack(Material.AIR));
    }

    /** Bersihin pemain total: inventory, efek, health, lapar, xp, lalu set gamemode. */
    static void reset(Player p, GameMode gameMode) {
        clearInventory(p);
        for (PotionEffect effect : new ArrayList<>(p.getActivePotionEffects())) {
            p.removePotionEffect(effect.getType());
        }
        p.setHealth(maxHealth(p));
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setExhaustion(0f);
        p.setLevel(0);
        p.setExp(0f);
        p.setFireTicks(0);
        p.setFallDistance(0f);
        p.setGameMode(gameMode);
    }

    static double maxHealth(Player p) {
        AttributeInstance max = p.getAttribute(Attribute.MAX_HEALTH);
        return max != null ? max.getValue() : 20.0;
    }
}
