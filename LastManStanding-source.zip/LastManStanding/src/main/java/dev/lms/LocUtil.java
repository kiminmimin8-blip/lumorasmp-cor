package dev.lms;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

/** Simpan/baca Location manual (tanpa serialisasi Bukkit) biar aman kalau world belum ke-load. */
final class LocUtil {

    private LocUtil() {
    }

    static void write(ConfigurationSection section, String path, Location loc) {
        if (loc == null || loc.getWorld() == null) {
            return;
        }
        section.set(path + ".world", loc.getWorld().getName());
        section.set(path + ".x", loc.getX());
        section.set(path + ".y", loc.getY());
        section.set(path + ".z", loc.getZ());
        section.set(path + ".yaw", (double) loc.getYaw());
        section.set(path + ".pitch", (double) loc.getPitch());
    }

    /** Return null kalau data nggak ada atau world-nya nggak ke-load. */
    static Location read(ConfigurationSection section, String path) {
        String worldName = section.getString(path + ".world");
        if (worldName == null) {
            return null;
        }
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            return null;
        }
        return new Location(world,
                section.getDouble(path + ".x"),
                section.getDouble(path + ".y"),
                section.getDouble(path + ".z"),
                (float) section.getDouble(path + ".yaw"),
                (float) section.getDouble(path + ".pitch"));
    }
}
