package dev.lms;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class LMSPlugin extends JavaPlugin {

    private Messages messages;
    private ArenaData arena;
    private KitManager kits;
    private ChestManager chests;
    private Game game;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        messages = new Messages(this);
        arena = new ArenaData(this);
        kits = new KitManager(this);
        chests = new ChestManager(this);
        game = new Game(this);

        arena.load();
        kits.load();
        chests.load();

        getServer().getPluginManager().registerEvents(new GameListener(this), this);

        PluginCommand cmd = getCommand("event");
        if (cmd != null) {
            LMSCommand executor = new LMSCommand(this);
            cmd.setExecutor(executor);
            cmd.setTabCompleter(executor);
        }
        getLogger().info("LastManStanding aktif. Arena siap: " + arena.isReady() + ", chest loot: " + chests.size());
    }

    @Override
    public void onDisable() {
        if (game != null) {
            game.stop(true);
        }
    }

    public Messages messages() {
        return messages;
    }

    public ArenaData arena() {
        return arena;
    }

    public KitManager kits() {
        return kits;
    }

    public ChestManager chests() {
        return chests;
    }

    public Game game() {
        return game;
    }
}
