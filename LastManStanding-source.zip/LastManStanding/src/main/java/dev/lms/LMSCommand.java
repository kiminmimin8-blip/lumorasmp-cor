package dev.lms;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** /event (alias /lms). Tanpa argumen = masuk event. */
public final class LMSCommand implements CommandExecutor, TabCompleter {

    private static final List<String> PLAYER_SUBS = List.of("join", "keluar", "status", "help");
    private static final List<String> ADMIN_SUBS = List.of("on", "off", "mulai", "stop", "setlobby", "setcenter", "setloot", "chest", "reload");
    private static final List<String> CHEST_SUBS = List.of("add", "remove", "list");

    private final LMSPlugin plugin;

    public LMSCommand(LMSPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean requireAdmin(CommandSender s) {
        if (s.hasPermission("lms.admin")) {
            return true;
        }
        plugin.messages().send(s, "no-permission");
        return false;
    }

    private Player requirePlayer(CommandSender s) {
        if (s instanceof Player p) {
            return p;
        }
        plugin.messages().send(s, "players-only");
        return null;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Messages m = plugin.messages();
        Game game = plugin.game();
        String sub = args.length == 0 ? "join" : args[0].toLowerCase(Locale.ROOT);

        switch (sub) {
            case "join", "masuk" -> {
                Player p = requirePlayer(sender);
                if (p == null) {
                    return true;
                }
                if (!p.hasPermission("lms.play")) {
                    m.send(p, "no-permission");
                    return true;
                }
                game.join(p);
            }
            case "keluar", "leave" -> {
                Player p = requirePlayer(sender);
                if (p != null) {
                    game.leave(p);
                }
            }
            case "status" -> m.send(sender, "status",
                    "state", game.getState().name(),
                    "players", game.participantCount(),
                    "alive", game.aliveCount());
            case "on", "open", "buka" -> {
                if (!requireAdmin(sender)) {
                    return true;
                }
                String error = game.openEvent();
                if (error == null) {
                    m.send(sender, "on-ok");
                } else {
                    m.send(sender, error);
                }
            }
            case "off", "close", "tutup" -> {
                if (!requireAdmin(sender)) {
                    return true;
                }
                game.stop(false);
                m.send(sender, "off-ok");
            }
            case "mulai", "start" -> {
                if (!requireAdmin(sender)) {
                    return true;
                }
                String error = game.startEvent();
                if (error == null) {
                    m.send(sender, "start-ok");
                } else {
                    m.send(sender, error, "min", game.minPlayers());
                }
            }
            case "stop", "berhenti" -> {
                if (!requireAdmin(sender)) {
                    return true;
                }
                game.stop(false);
                m.send(sender, "stopped-ok");
            }
            case "setlobby", "setspawn" -> {
                if (!requireAdmin(sender)) {
                    return true;
                }
                Player p = requirePlayer(sender);
                if (p == null) {
                    return true;
                }
                Location center = plugin.arena().getCenter();
                if (center != null && !center.getWorld().equals(p.getWorld())) {
                    m.send(p, "world-mismatch", "world", center.getWorld().getName());
                    return true;
                }
                plugin.arena().setLobby(p.getLocation());
                m.send(p, "setlobby-ok");
            }
            case "setcenter" -> {
                if (!requireAdmin(sender)) {
                    return true;
                }
                Player p = requirePlayer(sender);
                if (p == null) {
                    return true;
                }
                Location lobby = plugin.arena().getLobby();
                if (lobby != null && !lobby.getWorld().equals(p.getWorld())) {
                    m.send(p, "world-mismatch", "world", lobby.getWorld().getName());
                    return true;
                }
                plugin.arena().setCenter(p.getLocation());
                m.send(p, "setcenter-ok");
                if (p.getWorld().equals(Bukkit.getWorlds().get(0))) {
                    m.send(p, "main-world-warning");
                }
            }
            case "setloot" -> {
                if (!requireAdmin(sender)) {
                    return true;
                }
                Player p = requirePlayer(sender);
                if (p != null) {
                    int count = plugin.kits().saveLoot(p);
                    if (count >= 0) {
                        m.send(p, "setloot-ok", "count", count);
                    }
                }
            }
            case "chest" -> {
                if (!requireAdmin(sender)) {
                    return true;
                }
                Player p = requirePlayer(sender);
                if (p != null) {
                    handleChest(p, args);
                }
            }
            case "reload" -> {
                if (!requireAdmin(sender)) {
                    return true;
                }
                plugin.reloadConfig();
                plugin.arena().load();
                plugin.kits().load();
                plugin.chests().load();
                m.send(sender, "reload-ok");
            }
            default -> {
                for (String line : m.lines("help")) {
                    sender.sendMessage(m.legacy(line));
                }
            }
        }
        return true;
    }

    /** /event chest add|remove|list. add/remove bekerja ke block yang lagi dilihat (maks 6 block). */
    private void handleChest(Player p, String[] args) {
        Messages m = plugin.messages();
        ChestManager chests = plugin.chests();
        String action = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "list";

        switch (action) {
            case "add" -> {
                Block target = p.getTargetBlockExact(Math.max(1, plugin.getConfig().getInt("game.chest-target-distance", 6)));
                if (target == null) {
                    m.send(p, "chest-look");
                    return;
                }
                boolean existed = chests.isRegistered(target);
                if (chests.add(target)) {
                    m.send(p, existed ? "chest-updated" : "chest-added", "count", chests.size());
                } else {
                    m.send(p, "chest-look");
                }
            }
            case "remove" -> {
                Block target = p.getTargetBlockExact(Math.max(1, plugin.getConfig().getInt("game.chest-target-distance", 6)));
                if (target != null && chests.remove(target)) {
                    m.send(p, "chest-removed", "count", chests.size());
                } else {
                    m.send(p, "chest-not-found");
                }
            }
            default -> {
                m.send(p, "chest-list-header", "count", chests.size());
                for (String line : chests.describe()) {
                    p.sendMessage(m.legacy(line));
                }
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            List<String> options = new ArrayList<>(PLAYER_SUBS);
            if (sender.hasPermission("lms.admin")) {
                options.addAll(ADMIN_SUBS);
            }
            options.removeIf(s -> !s.startsWith(prefix));
            return options;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("chest") && sender.hasPermission("lms.admin")) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            List<String> options = new ArrayList<>(CHEST_SUBS);
            options.removeIf(s -> !s.startsWith(prefix));
            return options;
        }
        return List.of();
    }
}
