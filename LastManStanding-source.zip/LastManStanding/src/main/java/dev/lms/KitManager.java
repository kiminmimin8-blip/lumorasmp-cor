package dev.lms;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Kit pemain dan pool loot airdrop.
 * Prioritas: kit.yml / loot.yml (dari /lms setkit, /lms setloot) lalu fallback ke config.yml.
 */
public final class KitManager {

    private final LMSPlugin plugin;
    private ItemStack[] storage = new ItemStack[36];
    private ItemStack[] armor = new ItemStack[4];
    private ItemStack[] extra = new ItemStack[1];
    private final List<ItemStack> loot = new ArrayList<>();

    public KitManager(LMSPlugin plugin) {
        this.plugin = plugin;
    }

    private File kitFile() {
        return new File(plugin.getDataFolder(), "kit.yml");
    }

    private File lootFile() {
        return new File(plugin.getDataFolder(), "loot.yml");
    }

    public void load() {
        // Kit
        File kf = kitFile();
        if (kf.exists()) {
            ItemStorage.Loaded l = ItemStorage.load(kf);
            storage = l.storage();
            armor = l.armor();
            extra = l.extra();
        } else {
            buildKitFromConfig();
        }

        // Loot
        loot.clear();
        File lf = lootFile();
        if (lf.exists()) {
            for (ItemStack item : ItemStorage.load(lf).storage()) {
                if (item != null && item.getType() != Material.AIR) {
                    loot.add(item);
                }
            }
        } else {
            for (String s : plugin.getConfig().getStringList("airdrop.items")) {
                ItemStack item = parse(s);
                if (item != null) {
                    loot.add(item);
                }
            }
        }
    }

    private void buildKitFromConfig() {
        storage = new ItemStack[36];
        armor = new ItemStack[4];
        extra = new ItemStack[1];
        ConfigurationSection k = plugin.getConfig().getConfigurationSection("kit");
        if (k == null) {
            return;
        }
        // Urutan armor Bukkit: boots, leggings, chestplate, helmet
        armor[3] = parse(k.getString("helmet"));
        armor[2] = parse(k.getString("chestplate"));
        armor[1] = parse(k.getString("leggings"));
        armor[0] = parse(k.getString("boots"));
        extra[0] = parse(k.getString("offhand"));
        int i = 0;
        for (String s : k.getStringList("items")) {
            ItemStack item = parse(s);
            if (item != null && i < storage.length) {
                storage[i++] = item;
            }
        }
    }

    /** Format: MATERIAL[:jumlah][|ENCHANT:level,ENCHANT:level] */
    private ItemStack parse(String spec) {
        if (spec == null || spec.isBlank()) {
            return null;
        }
        String[] parts = spec.trim().split("\\|");
        String[] head = parts[0].split(":");
        Material material = Material.matchMaterial(head[0].trim());
        if (material == null || material == Material.AIR) {
            plugin.getLogger().warning("Material tidak dikenal di config: " + head[0]);
            return null;
        }
        int amount = 1;
        if (head.length > 1) {
            try {
                amount = Math.max(1, Integer.parseInt(head[1].trim()));
            } catch (NumberFormatException ignored) {
                // pakai 1
            }
        }
        ItemStack item = new ItemStack(material, amount);
        if (parts.length > 1) {
            for (String ench : parts[1].split(",")) {
                String[] e = ench.trim().split(":");
                Enchantment enchantment = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(e[0].trim().toLowerCase(Locale.ROOT)));
                if (enchantment == null) {
                    plugin.getLogger().warning("Enchant tidak dikenal di config: " + e[0]);
                    continue;
                }
                int level = 1;
                if (e.length > 1) {
                    try {
                        level = Integer.parseInt(e[1].trim());
                    } catch (NumberFormatException ignored) {
                        // pakai 1
                    }
                }
                item.addUnsafeEnchantment(enchantment, level);
            }
        }
        return item;
    }

    /** Kasih kit ke pemain (inventory harus sudah dikosongkan). */
    public void give(Player p) {
        PlayerInventory inv = p.getInventory();
        inv.setStorageContents(ItemStorage.cloneAll(storage));
        inv.setArmorContents(ItemStorage.cloneAll(armor));
        inv.setExtraContents(ItemStorage.cloneAll(extra));
    }

    public List<ItemStack> loot() {
        return loot;
    }

    public boolean saveKit(Player admin) {
        PlayerInventory inv = admin.getInventory();
        try {
            ItemStorage.save(kitFile(), inv.getStorageContents(), inv.getArmorContents(), inv.getExtraContents());
        } catch (IOException e) {
            plugin.getLogger().severe("Gagal simpan kit.yml: " + e.getMessage());
            return false;
        }
        load();
        return true;
    }

    /** Return jumlah item loot yang tersimpan, atau -1 kalau gagal. */
    public int saveLoot(Player admin) {
        PlayerInventory inv = admin.getInventory();
        try {
            ItemStorage.save(lootFile(), inv.getStorageContents(), new ItemStack[4], new ItemStack[1]);
        } catch (IOException e) {
            plugin.getLogger().severe("Gagal simpan loot.yml: " + e.getMessage());
            return -1;
        }
        load();
        return loot.size();
    }
}
