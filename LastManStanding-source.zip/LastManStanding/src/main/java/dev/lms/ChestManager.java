package dev.lms;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.block.Container;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Chest loot buatan admin yang tersebar di map.
 * Admin isi chest-nya dulu, lalu /lms chest add sambil lihat chest itu: isinya di-snapshot ke chests.yml.
 * Tiap ronde dimulai, semua chest terdaftar diisi ulang sesuai snapshot. Pas ronde selesai, isinya dikosongin.
 */
public final class ChestManager {

    private record Entry(String world, int x, int y, int z, Material type, ItemStack[] items) {
        boolean at(Block b) {
            return b.getX() == x && b.getY() == y && b.getZ() == z && b.getWorld().getName().equals(world);
        }
    }

    private final LMSPlugin plugin;
    private final File file;
    private final List<Entry> entries = new ArrayList<>();

    public ChestManager(LMSPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "chests.yml");
    }

    public void load() {
        entries.clear();
        if (!file.exists()) {
            return;
        }
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String key : y.getKeys(false)) {
            ConfigurationSection s = y.getConfigurationSection(key);
            if (s == null || s.getString("world") == null) {
                continue;
            }
            Material type = Material.matchMaterial(s.getString("type", "CHEST"));
            if (type == null) {
                type = Material.CHEST;
            }
            List<?> raw = s.getList("items");
            ItemStack[] items = ItemStorage.toArray(raw, raw == null ? 0 : raw.size());
            entries.add(new Entry(s.getString("world"), s.getInt("x"), s.getInt("y"), s.getInt("z"), type, items));
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        int i = 0;
        for (Entry e : entries) {
            ConfigurationSection s = y.createSection("c" + i++);
            s.set("world", e.world());
            s.set("x", e.x());
            s.set("y", e.y());
            s.set("z", e.z());
            s.set("type", e.type().name());
            s.set("items", Arrays.asList(e.items()));
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Gagal simpan chests.yml: " + ex.getMessage());
        }
    }

    private static Inventory inventoryOf(Block b) {
        BlockState state = b.getState();
        if (state instanceof Chest chest) {
            return chest.getBlockInventory();
        }
        if (state instanceof Container container) {
            return container.getInventory();
        }
        return null;
    }

    public int size() {
        return entries.size();
    }

    public boolean isRegistered(Block b) {
        for (Entry e : entries) {
            if (e.at(b)) {
                return true;
            }
        }
        return false;
    }

    /** Daftarkan chest (atau barrel) dan snapshot isinya. Kalau sudah terdaftar, snapshot-nya diperbarui. */
    public boolean add(Block b) {
        Inventory inv = inventoryOf(b);
        if (inv == null) {
            return false;
        }
        ItemStack[] snapshot = ItemStorage.cloneAll(inv.getContents());
        entries.removeIf(e -> e.at(b));
        entries.add(new Entry(b.getWorld().getName(), b.getX(), b.getY(), b.getZ(), b.getType(), snapshot));
        save();
        return true;
    }

    public boolean remove(Block b) {
        boolean removed = entries.removeIf(e -> e.at(b));
        if (removed) {
            save();
        }
        return removed;
    }

    public List<String> describe() {
        List<String> out = new ArrayList<>();
        int i = 1;
        for (Entry e : entries) {
            int count = 0;
            for (ItemStack item : e.items()) {
                if (item != null && item.getType() != Material.AIR) {
                    count++;
                }
            }
            out.add("&7#" + i++ + " &f" + e.world() + " &7X:" + e.x() + " Y:" + e.y() + " Z:" + e.z()
                    + " &8(" + count + " slot terisi)");
        }
        return out;
    }

    /** Isi ulang semua chest terdaftar sesuai snapshot. Return jumlah chest yang berhasil diisi. */
    public int refillAll() {
        int filled = 0;
        for (Entry e : entries) {
            World w = Bukkit.getWorld(e.world());
            if (w == null) {
                continue;
            }
            Block b = w.getBlockAt(e.x(), e.y(), e.z());
            if (!(b.getState() instanceof Container)) {
                b.setType(e.type());
            }
            Inventory inv = inventoryOf(b);
            if (inv == null) {
                plugin.getLogger().warning("Chest di " + e.world() + " " + e.x() + "," + e.y() + "," + e.z()
                        + " nggak bisa diisi (block bukan container).");
                continue;
            }
            inv.clear();
            for (int i = 0; i < Math.min(inv.getSize(), e.items().length); i++) {
                if (e.items()[i] != null) {
                    inv.setItem(i, e.items()[i].clone());
                }
            }
            filled++;
        }
        return filled;
    }

    /** Kosongin semua chest terdaftar (dipanggil pas ronde selesai biar isinya nggak bisa dijarah di luar event). */
    public void clearAll() {
        for (Entry e : entries) {
            World w = Bukkit.getWorld(e.world());
            if (w == null) {
                continue;
            }
            Inventory inv = inventoryOf(w.getBlockAt(e.x(), e.y(), e.z()));
            if (inv != null) {
                inv.clear();
            }
        }
    }
}
