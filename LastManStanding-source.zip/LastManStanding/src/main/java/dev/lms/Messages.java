package dev.lms;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.List;
import java.util.Locale;

/** Semua teks diambil dari config.yml (section messages) supaya gampang diedit. */
public final class Messages {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final LMSPlugin plugin;

    public Messages(LMSPlugin plugin) {
        this.plugin = plugin;
    }

    /** Placeholder dikirim berpasangan: "player", nama, "count", 5, ... */
    public String raw(String key, Object... kv) {
        String s = plugin.getConfig().getString("messages." + key);
        if (s == null) {
            s = "&c[pesan hilang: " + key + "]";
        }
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("{" + kv[i] + "}", String.valueOf(kv[i + 1]));
        }
        return s;
    }

    public Component plain(String key, Object... kv) {
        return LEGACY.deserialize(raw(key, kv));
    }

    public Component prefixed(String key, Object... kv) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        return LEGACY.deserialize(prefix + raw(key, kv));
    }

    public void send(CommandSender to, String key, Object... kv) {
        to.sendMessage(prefixed(key, kv));
    }

    public List<String> lines(String key) {
        return plugin.getConfig().getStringList("messages." + key);
    }

    public Component legacy(String text) {
        return LEGACY.deserialize(text);
    }

    /** Title biasa. Waktu tampil diatur di titles.normal. */
    public void title(Player p, String titleKey, String subtitleKey, Object... kv) {
        showTitle(p, "titles.normal", 200, 2000, 400, titleKey, subtitleKey, kv);
    }

    /** Title singkat (hampir tanpa fade) buat hitung mundur 3, 2, 1 yang ganti tiap detik. */
    public void titleFast(Player p, String titleKey, String subtitleKey, Object... kv) {
        showTitle(p, "titles.countdown", 0, 900, 100, titleKey, subtitleKey, kv);
    }

    private void showTitle(Player p, String path, int fadeIn, int stay, int fadeOut,
                           String titleKey, String subtitleKey, Object... kv) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("titles.enabled", true)) {
            return;
        }
        Component title = plain(titleKey, kv);
        Component subtitle = subtitleKey == null ? Component.empty() : plain(subtitleKey, kv);
        p.showTitle(Title.title(title, subtitle, Title.Times.times(
                Duration.ofMillis(c.getLong(path + ".fade-in", fadeIn)),
                Duration.ofMillis(c.getLong(path + ".stay", stay)),
                Duration.ofMillis(c.getLong(path + ".fade-out", fadeOut)))));
    }

    /** Putar sound dari config (sounds.[key]). ID sound pakai format vanilla, misal block.note_block.pling. */
    public void sound(Player p, String key) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("sounds.enabled", true)) {
            return;
        }
        String id = c.getString("sounds." + key + ".sound", "");
        if (id == null || id.isBlank()) {
            return;
        }
        try {
            p.playSound(Sound.sound(Key.key(id.trim().toLowerCase(Locale.ROOT)), Sound.Source.MASTER,
                    (float) c.getDouble("sounds." + key + ".volume", 1.0),
                    (float) c.getDouble("sounds." + key + ".pitch", 1.0)));
        } catch (RuntimeException ex) {
            plugin.getLogger().warning("Sound nggak valid di config (sounds." + key + "): " + id);
        }
    }

    public static String time(int seconds) {
        if (seconds < 0) {
            seconds = 0;
        }
        return String.format("%d:%02d", seconds / 60, seconds % 60);
    }
}
