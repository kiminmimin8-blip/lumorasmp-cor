package dev.lms;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.world.PortalCreateEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Locale;

public final class GameListener implements Listener {

    private final LMSPlugin plugin;

    public GameListener(LMSPlugin plugin) {
        this.plugin = plugin;
    }

    private Game game() {
        return plugin.game();
    }

    private boolean inGame(Player p) {
        return game().isParticipant(p.getUniqueId());
    }

    private boolean inEventWorld(World w) {
        return w != null && w.equals(game().getEventWorld());
    }

    private boolean portalsBlocked(World w) {
        return inEventWorld(w) && plugin.getConfig().getBoolean("game.block-portals", true);
    }

    // ------------------------------------------------------------ kematian & respawn

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getPlayer();
        if (!inGame(p)) {
            return;
        }
        e.deathMessage(null);
        e.setKeepInventory(false);
        e.setKeepLevel(false);
        e.setDroppedExp(0);
        if (!plugin.getConfig().getBoolean("game.drop-items-on-death", true)) {
            e.getDrops().clear();
        }
        game().onDeath(p, p.getKiller());

        // Skip layar "You died" supaya pemain langsung balik ke spawn event atau jadi spectator
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline() && p.isDead()) {
                p.spigot().respawn();
            }
        });
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        game().onRespawn(e);
    }

    // ------------------------------------------------------------ damage & PvP

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && inGame(p) && game().isDamageBlocked()) {
            e.setCancelled(true);
        }
    }

    /** PvP mati selama nunggu dan hitung mundur, baru nyala pas event dimulai. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPvp(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim) || !inGame(victim)) {
            return;
        }
        Player attacker = null;
        if (e.getDamager() instanceof Player a) {
            attacker = a;
        } else if (e.getDamager() instanceof Projectile proj && proj.getShooter() instanceof Player shooter) {
            attacker = shooter;
        }
        if (attacker != null && game().isPvpBlocked()) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onFood(FoodLevelChangeEvent e) {
        if (!(e.getEntity() instanceof Player p) || !inGame(p)) {
            return;
        }
        boolean ending = game().getState() == Game.State.ENDING;
        if (ending || !plugin.getConfig().getBoolean("game.hunger", true)) {
            e.setCancelled(true);
        }
    }

    // ------------------------------------------------------------ block & item

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (!inGame(p)) {
            return;
        }
        boolean allowed = game().getState() != Game.State.ENDING
                && plugin.getConfig().getBoolean("game.allow-block-break", true)
                && !game().isAirdrop(e.getBlock())
                && !(plugin.getConfig().getBoolean("game.protect-loot-chests", true)
                        && plugin.chests().isRegistered(e.getBlock()));
        if (!allowed) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        if (!inGame(p)) {
            return;
        }
        boolean allowed = game().getState() != Game.State.ENDING
                && plugin.getConfig().getBoolean("game.allow-block-place", true);
        if (!allowed) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        Player p = e.getPlayer();
        if (inGame(p) && game().getState() == Game.State.ENDING) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && inGame(p) && game().getState() == Game.State.ENDING) {
            e.setCancelled(true);
        }
    }

    // ------------------------------------------------------------ command

    /** Selama ikut event, cuma command di game.allowed-commands (default: rtp, lobby, home) yang boleh. */
    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!inGame(p) || p.hasPermission("lms.admin")
                || !plugin.getConfig().getBoolean("game.restrict-commands", true)) {
            return;
        }
        String label = e.getMessage().substring(1).split(" ")[0].toLowerCase(Locale.ROOT);
        int colon = label.indexOf(':');
        if (colon >= 0) {
            label = label.substring(colon + 1);
        }
        List<String> allowed = plugin.getConfig().getStringList("game.allowed-commands");
        for (String a : allowed) {
            if (a.equalsIgnoreCase(label)) {
                return;
            }
        }
        e.setCancelled(true);
        plugin.messages().send(p, "command-blocked");
    }

    // ------------------------------------------------------------ teleport: masuk/keluar world event

    /**
     * Orang di luar event nggak bisa masuk ke world event lewat cara lain (misal /back atau /tpa).
     * Satu-satunya jalan masuk adalah /event.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTeleportIn(PlayerTeleportEvent e) {
        Player p = e.getPlayer();
        Location to = e.getTo();
        if (to == null || PlayerUtil.isInternalTeleport()) {
            return;
        }
        if (!plugin.getConfig().getBoolean("game.block-outside-entry", true)) {
            return;
        }
        World eventWorld = game().getEventWorld();
        if (eventWorld == null || !eventWorld.equals(to.getWorld()) || eventWorld.equals(e.getFrom().getWorld())) {
            return;
        }
        if (inGame(p) || p.hasPermission("lms.admin")) {
            return;
        }
        e.setCancelled(true);
        plugin.messages().send(p, "entry-blocked");
    }

    /** Peserta yang pergi dari world event (lewat /lobby, /home, dll) otomatis dianggap keluar dari event. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleportOut(PlayerTeleportEvent e) {
        Player p = e.getPlayer();
        Location to = e.getTo();
        if (to == null || PlayerUtil.isInternalTeleport() || !inGame(p)) {
            return;
        }
        World eventWorld = game().getEventWorld();
        if (eventWorld == null || eventWorld.equals(to.getWorld())) {
            return;
        }
        game().onTeleportOut(p, e.getFrom());
    }

    // ------------------------------------------------------------ portal nether / end

    @EventHandler(ignoreCancelled = true)
    public void onPlayerPortal(PlayerPortalEvent e) {
        if (portalsBlocked(e.getFrom().getWorld())) {
            e.setCancelled(true);
            plugin.messages().send(e.getPlayer(), "portal-blocked");
        }
    }

    /** Portal nether (api di frame obsidian) nggak bisa dibuat di world event. */
    @EventHandler(ignoreCancelled = true)
    public void onPortalCreate(PortalCreateEvent e) {
        if (portalsBlocked(e.getWorld())) {
            e.setCancelled(true);
            if (e.getEntity() instanceof Player p) {
                plugin.messages().send(p, "portal-blocked");
            }
        }
    }

    /** Portal end (ender eye di frame) juga diblok. */
    @EventHandler(ignoreCancelled = true)
    public void onEnderEye(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null) {
            return;
        }
        if (e.getClickedBlock().getType() != Material.END_PORTAL_FRAME) {
            return;
        }
        ItemStack item = e.getItem();
        if (item == null || item.getType() != Material.ENDER_EYE) {
            return;
        }
        if (portalsBlocked(e.getClickedBlock().getWorld())) {
            e.setCancelled(true);
            plugin.messages().send(e.getPlayer(), "portal-blocked");
        }
    }

    // ------------------------------------------------------------ join / quit

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        game().onQuit(e.getPlayer());
    }

    /** Kalau pemain sempat disconnect/crash di tengah event, kondisi aslinya dibalikin pas login. */
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!SavedState.exists(plugin, p.getUniqueId())) {
            return;
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline() && !inGame(p) && SavedState.exists(plugin, p.getUniqueId())) {
                SavedState.restoreAndDelete(plugin, p);
                plugin.messages().send(p, "restored");
            }
        }, 10L);
    }
}
