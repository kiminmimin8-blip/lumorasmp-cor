package dev.lms;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.DyeColor;
import org.bukkit.FireworkEffect;
import org.bukkit.GameMode;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Satu sesi event Last Man Standing.
 *
 * <ul>
 *   <li>WAITING: sesi terbuka. Pemain masuk lewat /event, nunggu dan cari resource (PvP mati).</li>
 *   <li>STARTING: admin /event mulai, hitung mundur 3-2-1 di layar.</li>
 *   <li>RUNNING: PvP on, border mengecil per langkah (mis. 10 block tiap 20 detik).</li>
 *   <li>ENDING: ada pemenang, tunggu sebentar lalu semua dibalikin.</li>
 * </ul>
 */
public final class Game {

    public enum State { WAITING, STARTING, RUNNING, ENDING }

    /** Selama ukuran border lebih besar dari 'above', border mengecil 'amount' block tiap 'interval' detik. */
    private record ShrinkRule(double above, double amount, int interval) {
    }

    private record BorderBackup(Location center, double size, double damage, double buffer, int warning) {
    }

    private final LMSPlugin plugin;
    private final Random random = new Random();

    private final Set<UUID> participants = new LinkedHashSet<>();
    private final Set<UUID> alive = new LinkedHashSet<>();
    private final Set<UUID> pendingSpectators = new HashSet<>();
    private final Map<UUID, Integer> kills = new HashMap<>();
    private final Map<UUID, String> names = new HashMap<>();
    private final List<Block> airdrops = new ArrayList<>();
    private final List<ShrinkRule> rules = new ArrayList<>();

    private State state = State.WAITING;
    private boolean sessionOpen;
    private int chestCount;
    private int countdown;
    private int elapsed;
    private int startCount;
    private int protectionLeft;
    private int protectionTotal;

    // Langkah pengecilan border
    private int currentRule = -1;
    private double logicalSize;
    private double stepFrom;
    private double stepTarget;
    private int stepTimeLeft;
    private int stepTotal;
    private boolean stepNative;
    private boolean borderFinal;
    private int borderDelayLeft;

    private BukkitTask countdownTask;
    private BukkitTask gameTask;
    private BukkitTask cleanupTask;
    private BossBar bossBar;
    private World arenaWorld;
    private BorderBackup borderBackup;

    public Game(LMSPlugin plugin) {
        this.plugin = plugin;
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    // ------------------------------------------------------------------ status

    public State getState() {
        return state;
    }

    public boolean isSessionOpen() {
        return sessionOpen;
    }

    /** World tempat event berlangsung (null kalau sesi lagi nggak dibuka). */
    public World getEventWorld() {
        return sessionOpen ? arenaWorld : null;
    }

    public boolean isParticipant(UUID id) {
        return participants.contains(id);
    }

    public boolean isAlive(UUID id) {
        return alive.contains(id);
    }

    public int participantCount() {
        return participants.size();
    }

    public int aliveCount() {
        return alive.size();
    }

    public int minPlayers() {
        return Math.max(1, cfg().getInt("game.min-players", 2));
    }

    public boolean isAirdrop(Block block) {
        return airdrops.contains(block);
    }

    /** Semua damage ditahan: setelah ada pemenang, atau selama proteksi awal. */
    public boolean isDamageBlocked() {
        return state == State.ENDING || (state == State.RUNNING && protectionLeft > 0);
    }

    /** PvP mati selama nunggu, hitung mundur, dan proteksi awal. */
    public boolean isPvpBlocked() {
        if (state == State.WAITING || state == State.STARTING) {
            return !cfg().getBoolean("game.pvp-while-waiting", false);
        }
        return state != State.RUNNING || protectionLeft > 0;
    }

    // ------------------------------------------------------------------ sesi: buka, masuk, keluar

    /** /event on (admin): buka event. Return null kalau berhasil, atau key pesan error. */
    public String openEvent() {
        if (!plugin.arena().isReady()) {
            return "arena-not-ready";
        }
        if (sessionOpen || state != State.WAITING) {
            return "event-already-open";
        }
        openSession();
        return null;
    }

    /** Border dipasang dan chest loot diisi. Event tetap terbuka sampai selesai atau admin /event off. */
    private void openSession() {
        Location center = plugin.arena().getCenter();
        arenaWorld = center.getWorld();
        setupBorder(center);
        chestCount = plugin.chests().refillAll();
        bossBar = BossBar.bossBar(Component.empty(), 1f, barColor("waiting", BossBar.Color.YELLOW), barOverlay());
        airdrops.clear();
        sessionOpen = true;
    }

    public void join(Player p) {
        Messages m = plugin.messages();
        UUID id = p.getUniqueId();
        if (!plugin.arena().isReady()) {
            m.send(p, "arena-not-ready");
            return;
        }
        if (!sessionOpen) {
            m.send(p, "event-closed");
            return;
        }
        if (state != State.WAITING) {
            m.send(p, "game-in-progress");
            return;
        }
        if (participants.contains(id)) {
            m.send(p, "already-joined");
            return;
        }
        if (participants.size() >= cfg().getInt("game.max-players", 100)) {
            m.send(p, "game-full");
            return;
        }

        // Simpan kondisi asli (jangan timpa kalau masih ada file lama yang belum sempat direstore)
        if (!SavedState.exists(plugin, id)) {
            SavedState.capture(p).save(plugin, id);
        }

        participants.add(id);
        names.put(id, p.getName());
        PlayerUtil.reset(p, GameMode.SURVIVAL);
        PlayerUtil.teleport(p, plugin.arena().getLobby());
        if (cfg().getBoolean("bossbar.enabled", true)) {
            p.showBossBar(bossBar);
        }

        m.send(p, "joined-self");
        if (chestCount > 0) {
            m.send(p, "loot-chests", "count", chestCount);
        }
        toParticipants("player-joined", "player", p.getName(), "count", participants.size());
        refreshWaitingBar();
    }

    /** /event keluar: pemain dibalikin ke lokasi dan inventory aslinya. */
    public void leave(Player p) {
        UUID id = p.getUniqueId();
        if (!participants.contains(id)) {
            plugin.messages().send(p, "not-in-game");
            return;
        }
        boolean wasAlive = state == State.RUNNING && alive.contains(id);
        discardInventory(p, p.getLocation());
        removeParticipant(p, true, true);
        plugin.messages().send(p, "left-self");
        afterDeparture(p.getName(), wasAlive);
    }

    /** Pemain disconnect. Datanya tetap aman di disk dan direstore pas login lagi. */
    public void onQuit(Player p) {
        UUID id = p.getUniqueId();
        if (!participants.contains(id)) {
            return;
        }
        boolean wasAlive = state == State.RUNNING && alive.contains(id);
        discardInventory(p, p.getLocation());
        removeParticipant(p, false, false);
        afterDeparture(p.getName(), wasAlive);
    }

    /**
     * Pemain pergi dari world event lewat command lain (/lobby, /home, dll).
     * Inventory event dijatuhkan di titik asal, inventory asli dibalikin, tujuan teleport-nya dibiarkan.
     */
    public void onTeleportOut(Player p, Location from) {
        UUID id = p.getUniqueId();
        if (!participants.contains(id)) {
            return;
        }
        boolean wasAlive = state == State.RUNNING && alive.contains(id);
        discardInventory(p, from);
        removeParticipant(p, true, false);
        plugin.messages().send(p, "left-event");
        afterDeparture(p.getName(), wasAlive);
    }

    private void removeParticipant(Player p, boolean restore, boolean teleport) {
        UUID id = p.getUniqueId();
        participants.remove(id);
        alive.remove(id);
        pendingSpectators.remove(id);
        if (bossBar != null) {
            p.hideBossBar(bossBar);
        }
        if (restore) {
            SavedState.restoreAndDelete(plugin, p, teleport);
        }
    }

    private void afterDeparture(String name, boolean wasAlive) {
        switch (state) {
            case WAITING -> {
                if (!participants.isEmpty()) {
                    toParticipants("player-left", "player", name, "count", participants.size());
                }
                refreshWaitingBar();
            }
            case STARTING -> {
                if (participants.size() < minPlayers()) {
                    cancelCountdown();
                } else {
                    toParticipants("player-left", "player", name, "count", participants.size());
                }
            }
            case RUNNING -> {
                if (wasAlive) {
                    toParticipants("player-forfeit", "player", name, "left", alive.size());
                }
                checkWin();
            }
            default -> {
            }
        }
    }

    private void refreshWaitingBar() {
        if (state == State.WAITING) {
            setBar(plugin.messages().plain("bossbar-waiting", "count", participants.size()), 1f, barColor("waiting", BossBar.Color.YELLOW));
        }
    }

    // ------------------------------------------------------------------ mulai (admin) + hitung mundur

    /** /event mulai. Return null kalau berhasil, atau key pesan error. */
    public String startEvent() {
        if (!sessionOpen || state != State.WAITING) {
            return "cannot-start-state";
        }
        if (participants.size() < minPlayers()) {
            return "cannot-start-players";
        }
        state = State.STARTING;
        countdown = Math.max(1, cfg().getInt("game.start-countdown", 3));
        showCountdown(countdown);
        countdownTask = Bukkit.getScheduler().runTaskTimer(plugin, this::countdownTick, 20L, 20L);
        return null;
    }

    private void countdownTick() {
        if (state != State.STARTING) {
            cancelTask(countdownTask);
            countdownTask = null;
            return;
        }
        countdown--;
        if (countdown <= 0) {
            cancelTask(countdownTask);
            countdownTask = null;
            begin();
            return;
        }
        showCountdown(countdown);
    }

    /** Tulisan besar di depan muka: "Event dimulai 3", "2", "1". */
    private void showCountdown(int n) {
        forEachOnline(p -> {
            plugin.messages().titleFast(p, "countdown-title", "countdown-subtitle", "seconds", n);
            plugin.messages().sound(p, n <= 1 ? "countdown-last" : "countdown");
        });
    }

    private void cancelCountdown() {
        cancelTask(countdownTask);
        countdownTask = null;
        state = State.WAITING;
        toParticipants("start-cancelled");
        refreshWaitingBar();
    }

    private void begin() {
        participants.removeIf(id -> Bukkit.getPlayer(id) == null);
        if (participants.size() < minPlayers()) {
            state = State.WAITING;
            toParticipants("start-cancelled");
            refreshWaitingBar();
            return;
        }

        state = State.RUNNING;
        elapsed = 0;
        alive.clear();
        alive.addAll(participants);
        pendingSpectators.clear();
        kills.clear();
        for (UUID id : participants) {
            kills.put(id, 0);
        }
        startCount = participants.size();

        loadRules();
        logicalSize = cfg().getDouble("border.initial-size", 1000);
        currentRule = -1;
        borderFinal = false;
        borderDelayLeft = 0;

        protectionTotal = Math.max(0, cfg().getInt("game.protection-seconds", 0));
        protectionLeft = protectionTotal;

        // Opsional: sebar semua pemain secara acak pas mulai (default mati, pemain /rtp sendiri pas nunggu)
        if (cfg().getBoolean("start.rtp-all", false)) {
            List<Location> spawns = generateSpawns(plugin.arena().getCenter(), participants.size());
            int i = 0;
            for (UUID id : participants) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) {
                    PlayerUtil.teleport(p, spawns.get(i++ % spawns.size()));
                }
            }
        }

        forEachOnline(p -> {
            plugin.messages().title(p, "title-start", "subtitle-start");
            plugin.messages().sound(p, "start");
        });
        if (protectionTotal > 0) {
            toParticipants("game-start-protected", "protection", protectionTotal);
        } else {
            toParticipants("pvp-on");
            armBorder();
        }

        gameTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    // ------------------------------------------------------------------ border

    private void loadRules() {
        rules.clear();
        for (Map<?, ?> raw : cfg().getMapList("border.shrink")) {
            rules.add(new ShrinkRule(
                    num(raw.get("above"), 0),
                    Math.max(0.1, num(raw.get("amount"), 10)),
                    Math.max(1, (int) num(raw.get("interval"), 20))));
        }
        if (rules.isEmpty()) {
            rules.add(new ShrinkRule(0, 10, 20));
        }
    }

    private static double num(Object o, double def) {
        return o instanceof Number n ? n.doubleValue() : def;
    }

    private static String fmt(double v) {
        return v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v);
    }

    private void setupBorder(Location center) {
        WorldBorder b = arenaWorld.getWorldBorder();
        if (borderBackup == null) {
            borderBackup = new BorderBackup(b.getCenter(), b.getSize(), b.getDamageAmount(),
                    b.getDamageBuffer(), b.getWarningDistance());
        }
        b.setCenter(center.getX(), center.getZ());
        b.setSize(cfg().getDouble("border.initial-size", 1000));
        b.setDamageAmount(cfg().getDouble("border.damage-amount", 2.0));
        b.setDamageBuffer(cfg().getDouble("border.damage-buffer", 0.0));
        b.setWarningDistance(cfg().getInt("border.warning-distance", 10));
    }

    private void restoreBorder() {
        if (borderBackup == null || arenaWorld == null) {
            return;
        }
        WorldBorder b = arenaWorld.getWorldBorder();
        b.setCenter(borderBackup.center());
        b.setSize(borderBackup.size());
        b.setDamageAmount(borderBackup.damage());
        b.setDamageBuffer(borderBackup.buffer());
        b.setWarningDistance(borderBackup.warning());
        borderBackup = null;
    }

    private int ruleIndexFor(double size) {
        for (int i = 0; i < rules.size(); i++) {
            if (size > rules.get(i).above()) {
                return i;
            }
        }
        return rules.size() - 1;
    }

    /** Dipanggil saat PvP on: langsung mulai mengecil, atau tunggu border.start-delay dulu. */
    private void armBorder() {
        int delay = Math.max(0, cfg().getInt("border.start-delay", 0));
        if (delay > 0) {
            borderDelayLeft = delay;
            toParticipants("border-delay-info", "seconds", delay);
        } else {
            beginStep();
        }
    }

    /** Mulai satu langkah pengecilan sesuai aturan yang berlaku untuk ukuran border sekarang. */
    private void beginStep() {
        double minSize = Math.max(1, cfg().getDouble("border.min-size", 10));
        if (logicalSize <= minSize + 0.001) {
            if (!borderFinal) {
                borderFinal = true;
                toParticipants("border-final");
            }
            return;
        }
        int idx = ruleIndexFor(logicalSize);
        ShrinkRule rule = rules.get(idx);
        if (idx != currentRule) {
            currentRule = idx;
            toParticipants("border-rule", "amount", fmt(rule.amount()), "interval", rule.interval());
        }
        stepFrom = logicalSize;
        stepTarget = Math.max(minSize, logicalSize - rule.amount());
        logicalSize = stepTarget;
        stepTotal = rule.interval();
        stepTimeLeft = stepTotal;
        stepNative = tryNativeShrink(arenaWorld.getWorldBorder(), stepTarget, stepTotal);
    }

    /**
     * Pakai WorldBorder#setSize(double, long) lewat reflection supaya tetap compile di berbagai versi API
     * (di beberapa versi method ini deprecated). Return false kalau nggak tersedia, nanti dihandle manual.
     */
    private boolean tryNativeShrink(WorldBorder border, double size, long seconds) {
        try {
            Method m = WorldBorder.class.getMethod("setSize", double.class, long.class);
            m.invoke(border, size, seconds);
            return true;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            plugin.getLogger().warning("setSize(size, detik) tidak tersedia, pakai mode manual: " + ex.getMessage());
            return false;
        }
    }

    // ------------------------------------------------------------------ main loop (tiap 1 detik)

    private void tick() {
        if (state != State.RUNNING) {
            return;
        }
        elapsed++;

        int maxTime = cfg().getInt("game.max-game-time", 0);
        if (maxTime > 0 && elapsed >= maxTime) {
            timeUp();
            return;
        }
        maybeAirdrop();

        if (protectionLeft > 0) {
            protectionLeft--;
            if (protectionLeft == 0) {
                toParticipants("pvp-enabled");
                playAll("pvp-enabled");
                armBorder();
            } else {
                setBar(plugin.messages().plain("bossbar-protection", "seconds", protectionLeft),
                        (float) protectionLeft / Math.max(1, protectionTotal), barColor("protection", BossBar.Color.GREEN));
                actionBar();
                return;
            }
        } else if (borderDelayLeft > 0) {
            borderDelayLeft--;
            if (borderDelayLeft == 0) {
                beginStep();
            }
        } else if (!borderFinal) {
            stepTimeLeft--;
            if (!stepNative) {
                // Fallback manual kalau API setSize(size, detik) nggak ada di versi Paper ini
                double t = 1.0 - (double) Math.max(0, stepTimeLeft) / Math.max(1, stepTotal);
                arenaWorld.getWorldBorder().setSize(stepFrom + (stepTarget - stepFrom) * t);
            }
            if (stepTimeLeft <= 0) {
                beginStep();
            }
        }

        updateBorderBar();
        actionBar();
    }

    private void updateBorderBar() {
        double size = arenaWorld.getWorldBorder().getSize();
        double initial = Math.max(1, cfg().getDouble("border.initial-size", 1000));
        Messages m = plugin.messages();
        if (borderFinal) {
            setBar(m.plain("bossbar-final", "size", (int) Math.round(size), "alive", alive.size()), 1f,
                    barColor("final", BossBar.Color.PURPLE));
            return;
        }
        if (borderDelayLeft > 0) {
            setBar(m.plain("bossbar-border-delay", "seconds", borderDelayLeft, "size", (int) Math.round(size),
                    "alive", alive.size()), 1f, barColor("border-delay", BossBar.Color.BLUE));
            return;
        }
        double low = cfg().getDouble("bossbar.low-border-size", 100);
        BossBar.Color color = size > initial / 2 ? barColor("border-high", BossBar.Color.GREEN)
                : size > low ? barColor("border-mid", BossBar.Color.YELLOW)
                : barColor("border-low", BossBar.Color.RED);
        setBar(m.plain("bossbar-border", "size", (int) Math.round(size), "alive", alive.size()),
                (float) (size / initial), color);
    }

    private void setBar(Component name, float progress, BossBar.Color color) {
        if (bossBar == null || !cfg().getBoolean("bossbar.enabled", true)) {
            return;
        }
        bossBar.name(name);
        bossBar.progress(Math.max(0f, Math.min(1f, progress)));
        bossBar.color(color);
    }

    private BossBar.Color barColor(String key, BossBar.Color def) {
        String v = cfg().getString("bossbar.colors." + key, def.name());
        try {
            return BossBar.Color.valueOf(v.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException | NullPointerException ex) {
            return def;
        }
    }

    private BossBar.Overlay barOverlay() {
        String v = cfg().getString("bossbar.overlay", "PROGRESS");
        try {
            return BossBar.Overlay.valueOf(v.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException | NullPointerException ex) {
            return BossBar.Overlay.PROGRESS;
        }
    }

    private void actionBar() {
        if (!cfg().getBoolean("actionbar.enabled", true)) {
            return;
        }
        final int border = (int) Math.round(arenaWorld.getWorldBorder().getSize());
        final String time = Messages.time(elapsed);
        forEachOnline(p -> p.sendActionBar(plugin.messages().plain("actionbar",
                "alive", alive.size(), "total", startCount,
                "kills", kills.getOrDefault(p.getUniqueId(), 0),
                "border", border, "time", time)));
    }

    // ------------------------------------------------------------------ spawn acak (opsional, start.rtp-all)

    private List<Location> generateSpawns(Location center, int n) {
        if ("RING".equalsIgnoreCase(cfg().getString("spawn.mode", "RTP"))) {
            return ringSpawns(center, n);
        }
        return rtpSpawns(center, n);
    }

    /** Mode RTP: tiap pemain di-teleport ke titik acak di seluruh area border, dengan jarak minimal antar pemain. */
    private List<Location> rtpSpawns(Location center, int n) {
        World world = center.getWorld();
        double initial = cfg().getDouble("border.initial-size", 1000);
        double half = Math.max(5, initial / 2 - cfg().getDouble("spawn.edge-margin", 20));
        double minDist = cfg().getDouble("spawn.min-distance", 40);

        List<Location> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            Location chosen = null;
            for (int attempt = 0; attempt < 80 && chosen == null; attempt++) {
                // 50 percobaan pertama patuh min-distance, sisanya dilonggarkan kalau area sempit
                double need = attempt < 50 ? minDist : minDist / 4;
                Location cand = findSafe(world,
                        center.getX() + (random.nextDouble() * 2 - 1) * half,
                        center.getZ() + (random.nextDouble() * 2 - 1) * half);
                if (cand != null && farEnough(cand, out, need)) {
                    chosen = cand;
                }
            }
            if (chosen == null) {
                int y = world.getHighestBlockYAt(center.getBlockX(), center.getBlockZ());
                chosen = new Location(world, center.getBlockX() + 0.5, y + 1, center.getBlockZ() + 0.5);
            }
            out.add(chosen);
        }
        return out;
    }

    private static boolean farEnough(Location cand, List<Location> others, double minDist) {
        for (Location o : others) {
            double dx = cand.getX() - o.getX();
            double dz = cand.getZ() - o.getZ();
            if (dx * dx + dz * dz < minDist * minDist) {
                return false;
            }
        }
        return true;
    }

    /** Mode RING: sebar pemain melingkar di sekitar titik pusat. */
    private List<Location> ringSpawns(Location center, int n) {
        World world = center.getWorld();
        double initial = cfg().getDouble("border.initial-size", 1000);
        double radius = Math.min(cfg().getDouble("arena.spawn-radius", 70), initial / 2 - 5);
        radius = Math.max(radius, 3);
        double offset = random.nextDouble() * Math.PI * 2;

        List<Location> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            Location loc = null;
            for (int attempt = 0; attempt < 15 && loc == null; attempt++) {
                double jitter = attempt == 0 ? 0 : (random.nextDouble() - 0.5) * 0.6;
                double angle = offset + (Math.PI * 2 * i / n) + jitter;
                double r = radius * (0.6 + random.nextDouble() * 0.4);
                loc = findSafe(world, center.getX() + Math.cos(angle) * r, center.getZ() + Math.sin(angle) * r);
            }
            if (loc == null) {
                int y = world.getHighestBlockYAt(center.getBlockX(), center.getBlockZ());
                loc = new Location(world, center.getBlockX() + 0.5, y + 1, center.getBlockZ() + 0.5);
            }
            out.add(loc);
        }
        return out;
    }

    /** Titik di atas permukaan yang aman (bukan air/lava/daun/kaktus), atau null. */
    private Location findSafe(World world, double x, double z) {
        int bx = (int) Math.floor(x);
        int bz = (int) Math.floor(z);
        int y = world.getHighestBlockYAt(bx, bz, HeightMap.MOTION_BLOCKING_NO_LEAVES);
        Block ground = world.getBlockAt(bx, y, bz);
        Material type = ground.getType();
        if (ground.isLiquid() || Tag.LEAVES.isTagged(type)
                || type == Material.LAVA || type == Material.CACTUS
                || type == Material.MAGMA_BLOCK || type == Material.FIRE
                || type == Material.CAMPFIRE || type == Material.SOUL_CAMPFIRE
                || type == Material.SWEET_BERRY_BUSH || type == Material.POWDER_SNOW) {
            return null;
        }
        return new Location(world, bx + 0.5, y + 1, bz + 0.5, random.nextFloat() * 360f, 0f);
    }

    // ------------------------------------------------------------------ airdrop (opsional)

    private void maybeAirdrop() {
        if (!cfg().getBoolean("airdrop.enabled", false)) {
            return;
        }
        int interval = cfg().getInt("airdrop.interval-seconds", 300);
        if (interval > 0 && elapsed % interval == 0) {
            spawnAirdrop();
        }
    }

    private void spawnAirdrop() {
        if (arenaWorld == null) {
            return;
        }
        List<ItemStack> pool = plugin.kits().loot();
        if (pool.isEmpty()) {
            return;
        }
        WorldBorder b = arenaWorld.getWorldBorder();
        double half = Math.max(4, b.getSize() / 2 - 4);
        Location c = b.getCenter();

        for (int attempt = 0; attempt < 15; attempt++) {
            double x = c.getX() + (random.nextDouble() * 2 - 1) * half;
            double z = c.getZ() + (random.nextDouble() * 2 - 1) * half;
            Location spot = findSafe(arenaWorld, x, z);
            if (spot == null) {
                continue;
            }
            Block block = spot.getBlock();
            block.setType(Material.CHEST);
            if (!(block.getState() instanceof Chest chest)) {
                block.setType(Material.AIR);
                continue;
            }
            Inventory inv = chest.getBlockInventory();
            int count = Math.max(1, cfg().getInt("airdrop.items-per-chest", 5));
            for (int i = 0; i < count; i++) {
                ItemStack item = pool.get(random.nextInt(pool.size())).clone();
                inv.setItem(random.nextInt(inv.getSize()), item);
            }
            airdrops.add(block);
            arenaWorld.strikeLightningEffect(spot);
            toParticipants("airdrop", "x", block.getX(), "y", block.getY(), "z", block.getZ());
            return;
        }
    }

    private void removeAirdrops() {
        for (Block block : airdrops) {
            if (block.getType() == Material.CHEST && block.getState() instanceof Chest chest) {
                chest.getBlockInventory().clear();
                block.setType(Material.AIR);
            }
        }
        airdrops.clear();
    }

    // ------------------------------------------------------------------ eliminasi & pemenang

    /** Dipanggil dari PlayerDeathEvent. Hanya berpengaruh kalau event lagi RUNNING. */
    public void onDeath(Player victim, Player killer) {
        UUID id = victim.getUniqueId();
        if (state != State.RUNNING || !alive.remove(id)) {
            return;
        }
        pendingSpectators.add(id);

        if (killer != null && !killer.getUniqueId().equals(id) && alive.contains(killer.getUniqueId())) {
            kills.merge(killer.getUniqueId(), 1, Integer::sum);
            runCommands("rewards.kill-commands", killer);
            toParticipants("player-killed", "player", victim.getName(), "killer", killer.getName(), "left", alive.size());
        } else {
            toParticipants("player-died", "player", victim.getName(), "left", alive.size());
        }
        plugin.messages().sound(victim, "death");
        checkWin();
    }

    /** Pemain yang mati pas RUNNING jadi spectator; yang mati pas nunggu respawn di spawn event. */
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        if (!participants.contains(id)) {
            return;
        }
        if (state == State.WAITING || state == State.STARTING) {
            Location lobby = plugin.arena().getLobby();
            if (lobby != null) {
                e.setRespawnLocation(lobby);
            }
            return;
        }
        pendingSpectators.remove(id);
        e.setRespawnLocation(spectatorSpot());
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline() && participants.contains(id)) {
                p.setGameMode(GameMode.SPECTATOR);
                plugin.messages().send(p, "spectating");
            }
        });
    }

    private Location spectatorSpot() {
        Location c = plugin.arena().getCenter();
        World w = c.getWorld();
        int y = w.getHighestBlockYAt(c.getBlockX(), c.getBlockZ());
        return new Location(w, c.getX(), y + cfg().getDouble("game.spectator-height", 15), c.getZ());
    }

    private void checkWin() {
        if (state != State.RUNNING || alive.size() > 1) {
            return;
        }
        UUID winner = alive.isEmpty() ? null : alive.iterator().next();
        endGame(winner, false);
    }

    private void timeUp() {
        UUID best = null;
        int bestKills = -1;
        for (UUID id : alive) {
            int k = kills.getOrDefault(id, 0);
            if (k > bestKills) {
                bestKills = k;
                best = id;
            }
        }
        endGame(best, true);
    }

    private void endGame(UUID winnerId, boolean timeUp) {
        if (state != State.RUNNING) {
            return;
        }
        state = State.ENDING;
        cancelTask(gameTask);
        gameTask = null;

        Player winner = winnerId == null ? null : Bukkit.getPlayer(winnerId);
        Messages m = plugin.messages();

        if (timeUp) {
            toParticipants("time-up");
        }
        if (winner != null) {
            int k = kills.getOrDefault(winnerId, 0);
            Component msg = m.prefixed("winner-broadcast", "player", winner.getName(), "kills", k);
            if (cfg().getBoolean("game.broadcast-winner-server", true)) {
                Bukkit.broadcast(msg);
            } else {
                forEachOnline(p -> p.sendMessage(msg));
            }
            forEachOnline(p -> m.title(p, "title-winner", "subtitle-winner", "player", winner.getName()));
            setBar(m.plain("bossbar-end", "player", winner.getName()), 1f, barColor("end", BossBar.Color.YELLOW));
            runCommands("rewards.winner-commands", winner);
            celebrate(winner);
        } else {
            toParticipants("no-winner");
            setBar(m.plain("bossbar-end-none"), 1f, barColor("end-none", BossBar.Color.WHITE));
        }

        showTopKills();
        forEachOnline(p -> runCommands("rewards.participation-commands", p));
        playAll("winner");

        int delay = Math.max(3, cfg().getInt("game.end-delay", 10));
        cleanupTask = Bukkit.getScheduler().runTaskLater(plugin, this::cleanup, delay * 20L);
    }

    private void showTopKills() {
        int limit = cfg().getInt("game.top-kills-count", 3);
        if (limit <= 0) {
            return;
        }
        List<Map.Entry<UUID, Integer>> top = kills.entrySet().stream()
                .filter(e -> e.getValue() > 0)
                .sorted((a, b) -> Integer.compare(b.getValue(), a.getValue()))
                .limit(limit)
                .toList();
        if (top.isEmpty()) {
            return;
        }
        toParticipants("top-kills-header");
        int rank = 1;
        for (Map.Entry<UUID, Integer> e : top) {
            toParticipants("top-kills-line", "rank", rank++, "player", names.getOrDefault(e.getKey(), "?"),
                    "kills", e.getValue());
        }
    }

    private void celebrate(Player winner) {
        if (!cfg().getBoolean("celebration.fireworks", true)) {
            return;
        }
        final int total = Math.max(1, cfg().getInt("celebration.count", 8));
        final long interval = Math.max(1, cfg().getLong("celebration.interval-ticks", 15));
        final int power = Math.max(0, Math.min(3, cfg().getInt("celebration.power", 1)));
        final boolean flicker = cfg().getBoolean("celebration.flicker", true);
        final FireworkEffect.Type type = enumOf(FireworkEffect.Type.class,
                cfg().getString("celebration.type", "BALL_LARGE"), FireworkEffect.Type.BALL_LARGE);
        final List<Color> colors = dyeColors("celebration.colors", List.of(Color.AQUA, Color.YELLOW));
        final List<Color> fade = dyeColors("celebration.fade", List.of(Color.WHITE));

        new BukkitRunnable() {
            int shots = 0;

            @Override
            public void run() {
                if (!winner.isOnline() || shots++ >= total) {
                    cancel();
                    return;
                }
                Location loc = winner.getLocation().add((random.nextDouble() - 0.5) * 4, 1, (random.nextDouble() - 0.5) * 4);
                Firework fw = loc.getWorld().spawn(loc, Firework.class);
                FireworkMeta meta = fw.getFireworkMeta();
                meta.addEffect(FireworkEffect.builder()
                        .with(type)
                        .withColor(colors)
                        .withFade(fade)
                        .flicker(flicker)
                        .build());
                meta.setPower(power);
                fw.setFireworkMeta(meta);
            }
        }.runTaskTimer(plugin, 0L, interval);
    }

    private static <E extends Enum<E>> E enumOf(Class<E> type, String name, E def) {
        if (name == null) {
            return def;
        }
        try {
            return Enum.valueOf(type, name.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return def;
        }
    }

    /** Baca daftar nama warna dye dari config; nama yang salah dilewati. */
    private List<Color> dyeColors(String path, List<Color> def) {
        List<Color> out = new ArrayList<>();
        for (String name : cfg().getStringList(path)) {
            DyeColor dye = enumOf(DyeColor.class, name, null);
            if (dye != null) {
                out.add(dye.getFireworkColor());
            }
        }
        return out.isEmpty() ? def : out;
    }

    // ------------------------------------------------------------------ cleanup / stop

    /** Tutup sesi: border, chest loot, airdrop, item di tanah, dan semua pemain dibalikin ke kondisi awal. */
    private void cleanup() {
        cancelTask(countdownTask);
        cancelTask(gameTask);
        cancelTask(cleanupTask);
        countdownTask = null;
        gameTask = null;
        cleanupTask = null;

        if (bossBar != null) {
            for (UUID id : participants) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) {
                    p.hideBossBar(bossBar);
                }
            }
            bossBar = null;
        }

        removeAirdrops();
        plugin.chests().clearAll();
        clearGroundItems();
        restoreBorder();

        for (UUID id : new ArrayList<>(participants)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                SavedState.restoreAndDelete(plugin, p);
                plugin.messages().send(p, "restored");
            }
        }

        participants.clear();
        alive.clear();
        pendingSpectators.clear();
        kills.clear();
        names.clear();
        protectionLeft = 0;
        borderFinal = false;
        borderDelayLeft = 0;
        chestCount = 0;
        sessionOpen = false;
        arenaWorld = null;
        state = State.WAITING;
    }

    /** Hapus item yang berserakan di area event (bukan seluruh world, supaya aman kalau arena ada di world bersama). */
    private void clearGroundItems() {
        if (arenaWorld == null || !cfg().getBoolean("game.clear-ground-items", true)) {
            return;
        }
        Location c = plugin.arena().getCenter();
        if (c == null) {
            return;
        }
        double reach = cfg().getDouble("border.initial-size", 1000) / 2 + 10;
        for (Item item : arenaWorld.getEntitiesByClass(Item.class)) {
            Location l = item.getLocation();
            if (Math.abs(l.getX() - c.getX()) <= reach && Math.abs(l.getZ() - c.getZ()) <= reach) {
                item.remove();
            }
        }
    }

    /** Hentikan event paksa (admin atau server mati) dan restore semua pemain. */
    public void stop(boolean silent) {
        if (!sessionOpen && participants.isEmpty()) {
            return;
        }
        if (!silent) {
            toParticipants("game-stopped");
        }
        cleanup();
    }

    // ------------------------------------------------------------------ helper

    /** Item event milik pemain yang keluar: jatuh di titik asal (kalau diaktifkan) lalu inventory dikosongin. */
    private void discardInventory(Player p, Location at) {
        if (state != State.ENDING && cfg().getBoolean("game.drop-items-on-death", true)) {
            PlayerInventory inv = p.getInventory();
            List<ItemStack> all = new ArrayList<>();
            all.addAll(Arrays.asList(inv.getStorageContents()));
            all.addAll(Arrays.asList(inv.getArmorContents()));
            all.addAll(Arrays.asList(inv.getExtraContents()));
            for (ItemStack item : all) {
                if (item != null && item.getType() != Material.AIR) {
                    at.getWorld().dropItemNaturally(at, item);
                }
            }
        }
        PlayerUtil.clearInventory(p);
    }

    private void runCommands(String path, Player p) {
        for (String cmd : cfg().getStringList(path)) {
            String line = cmd.replace("%player%", p.getName());
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), line);
        }
    }

    private void toParticipants(String key, Object... kv) {
        Component c = plugin.messages().prefixed(key, kv);
        forEachOnline(p -> p.sendMessage(c));
    }

    private void playAll(String key) {
        forEachOnline(p -> plugin.messages().sound(p, key));
    }

    private void forEachOnline(Consumer<Player> action) {
        for (UUID id : new ArrayList<>(participants)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                action.accept(p);
            }
        }
    }

    private static void cancelTask(BukkitTask task) {
        if (task != null) {
            task.cancel();
        }
    }
}
