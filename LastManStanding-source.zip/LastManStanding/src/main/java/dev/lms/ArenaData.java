package dev.lms;

import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;

/** Lokasi lobby dan pusat arena, disimpan di data.yml (terpisah dari config biar komentar config aman). */
public final class ArenaData {

    private final LMSPlugin plugin;
    private final File file;
    private Location lobby;
    private Location center;

    public ArenaData(LMSPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
    }

    public void load() {
        lobby = null;
        center = null;
        if (!file.exists()) {
            return;
        }
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        lobby = LocUtil.read(y, "lobby");
        center = LocUtil.read(y, "center");
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        if (lobby != null) {
            LocUtil.write(y, "lobby", lobby);
        }
        if (center != null) {
            LocUtil.write(y, "center", center);
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Gagal simpan data.yml: " + e.getMessage());
        }
    }

    public void setLobby(Location loc) {
        this.lobby = loc.clone();
        save();
    }

    public void setCenter(Location loc) {
        this.center = loc.clone();
        save();
    }

    public Location getLobby() {
        return lobby == null ? null : lobby.clone();
    }

    public Location getCenter() {
        return center == null ? null : center.clone();
    }

    public boolean isReady() {
        return lobby != null && lobby.getWorld() != null && center != null && center.getWorld() != null;
    }
}
