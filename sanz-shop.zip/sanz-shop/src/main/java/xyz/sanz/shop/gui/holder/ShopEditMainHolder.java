package xyz.sanz.shop.gui.holder;

/** GUI: daftar kategori dalam mode edit (klik kiri = edit kategori, shift+klik kanan = hapus). */
public class ShopEditMainHolder extends BaseHolder {
}
