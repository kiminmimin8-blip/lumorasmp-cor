package xyz.sanz.shop.gui.holder;

/** GUI: daftar item dalam satu kategori, mode edit (klik kiri = edit item, shift+klik kanan = hapus). */
public class ShopEditCategoryHolder extends BaseHolder {

    private final String categoryKey;
    private final int page;

    public ShopEditCategoryHolder(String categoryKey, int page) {
        this.categoryKey = categoryKey;
        this.page = page;
    }

    public String getCategoryKey() {
        return categoryKey;
    }

    public int getPage() {
        return page;
    }
}
