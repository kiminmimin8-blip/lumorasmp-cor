package xyz.sanz.shop.gui.holder;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/**
 * Semua GUI custom di plugin ini pakai holder yang extends class ini, supaya
 * GuiListener bisa langsung tahu "ini inventory kepunyaan SanzShop" lewat instanceof,
 * tanpa perlu bandingin title (title bisa berubah-ubah & rawan salah tangkap).
 */
public abstract class BaseHolder implements InventoryHolder {

    private Inventory inventory;

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
