package xyz.sanz.shop;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;

/**
 * Hook sederhana ke Vault, supaya SanzShop bisa jalan di atas economy plugin
 * apa pun yang sudah dipakai di server (EssentialsX, CMI, dll) tanpa perlu tahu detailnya.
 */
public final class EconomyHook {

    private static Economy economy;

    private EconomyHook() {}

    public static boolean setup(SanzShop plugin) {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        economy = rsp.getProvider();
        return economy != null;
    }

    public static Economy get() {
        return economy;
    }

    public static boolean isReady() {
        return economy != null;
    }
}
