package xyz.sanz.shop.gui.holder;

/** GUI: detail edit satu item (nama, material, harga beli/jual, jumlah, hapus). */
public class ShopEditItemHolder extends BaseHolder {

    private final String categoryKey;
    private final int itemIndex;
    private final int returnPage;

    public ShopEditItemHolder(String categoryKey, int itemIndex, int returnPage) {
        this.categoryKey = categoryKey;
        this.itemIndex = itemIndex;
        this.returnPage = returnPage;
    }

    public String getCategoryKey() {
        return categoryKey;
    }

    public int getItemIndex() {
        return itemIndex;
    }

    public int getReturnPage() {
        return returnPage;
    }
}
