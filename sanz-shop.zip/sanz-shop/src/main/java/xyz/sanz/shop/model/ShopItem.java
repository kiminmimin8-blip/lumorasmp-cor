package xyz.sanz.shop.model;

import org.bukkit.Material;

/**
 * Representasi satu baris item di dalam sebuah kategori shop.
 * Data ini yang di-render jadi ItemStack di GUI, dan yang diedit lewat shop editor.
 */
public class ShopItem {

    private Material material;
    private String displayName;
    private int amount;
    private double buyPrice;
    private double sellPrice;

    public ShopItem(Material material, String displayName, int amount, double buyPrice, double sellPrice) {
        this.material = material;
        this.displayName = displayName;
        this.amount = Math.max(1, amount);
        this.buyPrice = Math.max(0, buyPrice);
        this.sellPrice = Math.max(0, sellPrice);
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = Math.max(1, amount);
    }

    public double getBuyPrice() {
        return buyPrice;
    }

    public void setBuyPrice(double buyPrice) {
        this.buyPrice = Math.max(0, buyPrice);
    }

    public double getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(double sellPrice) {
        this.sellPrice = Math.max(0, sellPrice);
    }

    /** buyPrice 0 dianggap "tidak dijual" oleh shop (hanya bisa dijual pemain, tidak dibeli). */
    public boolean isBuyable() {
        return buyPrice > 0;
    }

    /** sellPrice 0 dianggap "tidak diterima" shop saat pemain mau jual. */
    public boolean isSellable() {
        return sellPrice > 0;
    }
}
