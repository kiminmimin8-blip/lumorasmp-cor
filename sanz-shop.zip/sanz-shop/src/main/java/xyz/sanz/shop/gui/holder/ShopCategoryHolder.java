package xyz.sanz.shop.gui.holder;

/** GUI: daftar item di dalam satu kategori (mode belanja: klik kiri beli, klik kanan jual). */
public class ShopCategoryHolder extends BaseHolder {

    private final String categoryKey;
    private final int page;

    public ShopCategoryHolder(String categoryKey, int page) {
        this.categoryKey = categoryKey;
        this.page = page;
    }

    public String getCategoryKey() {
        return categoryKey;
    }

    public int getPage() {
        return page;
    }
}
