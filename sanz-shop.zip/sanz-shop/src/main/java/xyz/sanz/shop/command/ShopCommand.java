package xyz.sanz.shop.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import xyz.sanz.shop.SanzShop;
import xyz.sanz.shop.gui.MenuBuilder;
import xyz.sanz.shop.model.ShopCategory;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ShopCommand implements CommandExecutor, TabCompleter {

    private final SanzShop plugin;

    public ShopCommand(SanzShop plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (!player.hasPermission("sanzshop.use")) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return true;
        }

        if (args.length == 0) {
            MenuBuilder.openMainMenu(player, plugin);
            return true;
        }

        String key = args[0].toLowerCase();
        ShopCategory cat = plugin.getShopManager().getCategory(key);
        if (cat == null) {
            player.sendMessage(plugin.getMessages().prefix() + "§cKategori '" + key + "' tidak ditemukan. Ketik §f/shop§c untuk melihat seluruh kategori yang tersedia.");
            return true;
        }
        MenuBuilder.openCategoryMenu(player, plugin, key, 0);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) return List.of();
        String partial = args[0].toLowerCase();
        List<String> out = new ArrayList<>(plugin.getShopManager().getCategories().keySet().stream()
                .filter(k -> k.startsWith(partial))
                .collect(Collectors.toList()));
        return out;
    }
}
