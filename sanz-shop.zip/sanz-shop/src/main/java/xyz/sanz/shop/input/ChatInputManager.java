package xyz.sanz.shop.input;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import xyz.sanz.shop.SanzShop;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Menangkap 1 baris chat berikutnya dari seorang pemain sebagai input teks untuk
 * shop editor (ganti nama, ganti harga, ganti material, dsb), supaya tidak perlu
 * bikin custom text-input GUI (anvil hack dkk) yang lebih ribet & rapuh antar versi.
 *
 * Alur pakai:
 *   1. GUI editor manggil request(player, "Ketik harga beli baru:", (p, msg) -> { ... });
 *   2. Inventory pemain otomatis ketutup, lalu nunggu chat berikutnya.
 *   3. GuiListener#onChat meneruskan pesan itu ke sini lewat handleChat().
 */
public class ChatInputManager {

    @FunctionalInterface
    public interface InputHandler {
        void onInput(Player player, String message);
    }

    private final SanzShop plugin;
    private final Map<UUID, InputHandler> waiting = new ConcurrentHashMap<>();

    public ChatInputManager(SanzShop plugin) {
        this.plugin = plugin;
    }

    public void request(Player player, String promptMessage, InputHandler handler) {
        player.closeInventory();
        player.sendMessage("§8[§6Sanz Market§8] §r" + promptMessage);
        player.sendMessage("§7Ketik §ccancel§7 kapan saja untuk membatalkan proses ini.");
        waiting.put(player.getUniqueId(), handler);
    }

    public boolean isWaiting(Player player) {
        return waiting.containsKey(player.getUniqueId());
    }

    public void cancel(Player player) {
        waiting.remove(player.getUniqueId());
    }

    /** @return true jika pesan ini "diambil" sebagai input editor (harus di-cancel oleh chat event). */
    public boolean handleChat(Player player, String message) {
        InputHandler handler = waiting.remove(player.getUniqueId());
        if (handler == null) return false;

        if (message.equalsIgnoreCase("cancel")) {
            player.sendMessage("§cProses dibatalkan.");
            return true;
        }

        // Chat event Bukkit sering dipanggil dari thread async — lempar balik ke main thread
        // supaya aman manipulasi Inventory/Bukkit API di dalam handler.
        Bukkit.getScheduler().runTask(plugin, () -> handler.onInput(player, message));
        return true;
    }
}
