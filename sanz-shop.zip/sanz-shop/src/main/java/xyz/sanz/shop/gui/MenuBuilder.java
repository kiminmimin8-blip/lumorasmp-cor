package xyz.sanz.shop.gui;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import xyz.sanz.shop.SanzShop;
import xyz.sanz.shop.ShopManager;
import xyz.sanz.shop.gui.holder.*;
import xyz.sanz.shop.model.ShopCategory;
import xyz.sanz.shop.model.ShopItem;
import xyz.sanz.shop.util.Messages;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Factory buat semua tampilan GUI SanzShop: menu belanja & menu editor.
 * Semua inventory pakai holder dari package gui.holder supaya GuiListener gampang
 * bedain "ini menu apa" tanpa parsing title.
 */
public final class MenuBuilder {

    public static final int PAGE_SIZE = 45; // slot 0..44 = konten, slot 45..53 = navigasi
    public static final int SLOT_PREV = 45;
    public static final int SLOT_BACK = 49;
    public static final int SLOT_NEXT = 53;
    public static final int SLOT_ADD = 47;
    public static final int SLOT_RENAME_CATEGORY = 51;

    private static final String DIVIDER = "&8&m                    ";

    // key kategori/menu -> karakter private-use-area yang di-mapping ke banner PNG
    // lewat assets/sanz/font/banners.json di resource pack "sanz-market-rp".
    private static final Map<String, String> BANNER_CHARS = Map.ofEntries(
            Map.entry("main", "\uF800"),
            Map.entry("edit_main", "\uF801"),
            Map.entry("ore", "\uF802"),
            Map.entry("minerals", "\uF803"),
            Map.entry("blocks", "\uF804"),
            Map.entry("farming", "\uF805"),
            Map.entry("foods", "\uF806"),
            Map.entry("dyes", "\uF807"),
            Map.entry("redstone", "\uF808"),
            Map.entry("tools", "\uF809"),
            Map.entry("drops_common", "\uF80A"),
            Map.entry("drops_rare", "\uF80B"),
            Map.entry("misc", "\uF80C")
    );
    private static final Key BANNER_FONT = Key.key("sanz", "banners");

    /**
     * Judul GUI: pakai banner gambar custom (kalau resource pack terpasang & diaktifkan
     * di config), atau fallback ke teks biasa yang selalu jalan tanpa resource pack.
     */
    private static Component buildTitle(SanzShop plugin, String bannerKey, String legacyFallback) {
        boolean useBanner = plugin.getConfig().getBoolean("shop.use-banner-titles", true);
        String bannerChar = BANNER_CHARS.get(bannerKey);
        if (useBanner && bannerChar != null) {
            return Component.text(bannerChar).font(BANNER_FONT);
        }
        return LegacyComponentSerializer.legacySection().deserialize(legacyFallback);
    }

    private MenuBuilder() {}

    // ================= MENU BELANJA =================

    public static void openMainMenu(Player player, SanzShop plugin) {
        String legacyTitle = Messages.color(plugin.getConfig().getString("shop.main-menu-title", "&8&lSanz Market"));
        Component title = buildTitle(plugin, "main", legacyTitle);
        ShopMainHolder holder = new ShopMainHolder();
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        List<ShopCategory> cats = plugin.getShopManager().getCategoryList();
        for (int i = 0; i < cats.size() && i < PAGE_SIZE; i++) {
            inv.setItem(i, buildCategoryIcon(cats.get(i), false));
        }
        fillBottomRow(inv);
        inv.setItem(49, namedItem(Material.RED_SHULKER_BOX, "&c&lTutup Menu", List.of("&7Keluar dari Sanz Market.")));

        player.openInventory(inv);
    }

    public static void openCategoryMenu(Player player, SanzShop plugin, String categoryKey, int page) {
        ShopCategory cat = plugin.getShopManager().getCategory(categoryKey);
        if (cat == null) {
            player.sendMessage(plugin.getMessages().prefix() + "&cKategori tidak ditemukan. Silakan periksa kembali daftar kategori.");
            return;
        }
        String prefix = Messages.color(plugin.getConfig().getString("shop.category-menu-prefix", "&8&lSanz Market &7» &r"));
        String legacyTitle = prefix + cat.getTitle();
        if (legacyTitle.length() > 32) legacyTitle = legacyTitle.substring(0, 32);
        Component title = buildTitle(plugin, categoryKey, legacyTitle);

        int totalPages = Math.max(1, (int) Math.ceil(cat.getItems().size() / (double) PAGE_SIZE));
        page = Math.max(0, Math.min(page, totalPages - 1));

        ShopCategoryHolder holder = new ShopCategoryHolder(categoryKey, page);
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        List<ShopItem> items = cat.getItems();
        int from = page * PAGE_SIZE;
        int to = Math.min(from + PAGE_SIZE, items.size());
        for (int i = from; i < to; i++) {
            inv.setItem(i - from, buildShopItemIcon(items.get(i)));
        }

        fillNav(inv, page, totalPages, "&aBelanja");
        player.openInventory(inv);
    }

    // ================= MENU EDITOR =================

    public static void openEditMainMenu(Player player, SanzShop plugin) {
        String legacyTitle = Messages.color(plugin.getConfig().getString("shop.edit-main-title", "&8&l[EDIT] Sanz Market"));
        Component title = buildTitle(plugin, "edit_main", legacyTitle);
        ShopEditMainHolder holder = new ShopEditMainHolder();
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        List<ShopCategory> cats = plugin.getShopManager().getCategoryList();
        for (int i = 0; i < cats.size() && i < PAGE_SIZE; i++) {
            inv.setItem(i, buildCategoryIcon(cats.get(i), true));
        }
        fillBottomRow(inv);
        inv.setItem(SLOT_ADD, namedItem(Material.LIME_DYE, "&a&l+ Buat Kategori Baru", List.of(
                DIVIDER,
                "&7Menambahkan kategori kosong baru",
                "&7ke dalam katalog toko.",
                "",
                "&a▸ &fKlik &7— Buat kategori (via chat)"
        )));
        inv.setItem(49, namedItem(Material.RED_SHULKER_BOX, "&c&lKeluar dari Editor", List.of("&7Menutup mode pengelolaan toko.")));

        player.openInventory(inv);
    }

    public static void openEditCategoryMenu(Player player, SanzShop plugin, String categoryKey, int page) {
        ShopCategory cat = plugin.getShopManager().getCategory(categoryKey);
        if (cat == null) {
            player.sendMessage(plugin.getMessages().prefix() + "&cKategori tidak ditemukan. Silakan periksa kembali daftar kategori.");
            return;
        }
        String prefix = Messages.color(plugin.getConfig().getString("shop.edit-category-prefix", "&8&l[EDIT] &7» &r"));
        String legacyTitle = prefix + cat.getTitle();
        if (legacyTitle.length() > 32) legacyTitle = legacyTitle.substring(0, 32);
        Component title = buildTitle(plugin, categoryKey, legacyTitle);

        int totalPages = Math.max(1, (int) Math.ceil(cat.getItems().size() / (double) PAGE_SIZE));
        page = Math.max(0, Math.min(page, totalPages - 1));

        ShopEditCategoryHolder holder = new ShopEditCategoryHolder(categoryKey, page);
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        List<ShopItem> items = cat.getItems();
        int from = page * PAGE_SIZE;
        int to = Math.min(from + PAGE_SIZE, items.size());
        for (int i = from; i < to; i++) {
            inv.setItem(i - from, buildEditItemIcon(items.get(i)));
        }

        fillNav(inv, page, totalPages, "&e[EDIT] " + ChatColor.stripColor(cat.getTitle()));
        inv.setItem(SLOT_ADD, namedItem(Material.LIME_DYE, "&a&l+ Tambah Item ke Katalog", List.of(
                DIVIDER,
                "&7Menambahkan entri item baru",
                "&7ke dalam kategori ini.",
                "",
                "&a▸ &fKlik &7— Tambah item (via chat)"
        )));
        inv.setItem(SLOT_RENAME_CATEGORY, namedItem(Material.NAME_TAG, "&e&lKelola Informasi Kategori", List.of(
                DIVIDER,
                "&7Judul saat ini: &f" + cat.getTitle(),
                "&7Ikon saat ini: &f" + cat.getIcon().name(),
                "",
                "&e▸ &fKlik &7— Ganti judul kategori",
                "&e▸ &fShift + Klik &7— Ganti ikon (pakai item di tangan)"
        )));

        player.openInventory(inv);
    }

    public static void openEditItemMenu(Player player, SanzShop plugin, String categoryKey, int itemIndex, int returnPage) {
        ShopCategory cat = plugin.getShopManager().getCategory(categoryKey);
        if (cat == null || itemIndex < 0 || itemIndex >= cat.getItems().size()) {
            player.sendMessage(plugin.getMessages().prefix() + "&cItem tidak ditemukan atau sudah tidak tersedia.");
            return;
        }
        ShopItem item = cat.getItems().get(itemIndex);

        String title = Messages.color("&8&l[EDIT ITEM] &7» &r" + item.getDisplayName());
        if (title.length() > 32) title = title.substring(0, 32);

        ShopEditItemHolder holder = new ShopEditItemHolder(categoryKey, itemIndex, returnPage);
        Inventory inv = Bukkit.createInventory(holder, 27, title);
        holder.setInventory(inv);

        // filler
        ItemStack filler = namedItem(Material.BLACK_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        inv.setItem(4, buildEditItemIcon(item));
        inv.setItem(10, namedItem(Material.OAK_SIGN, "&e&lGanti Nama Tampilan", List.of(
                DIVIDER,
                "&7Nama saat ini:",
                "&f" + item.getDisplayName(),
                "",
                "&e▸ &fKlik &7— Ganti nama (via chat)"
        )));
        inv.setItem(11, namedItem(Material.IRON_PICKAXE, "&e&lGanti Jenis Material", List.of(
                DIVIDER,
                "&7Material saat ini:",
                "&f" + item.getMaterial().name(),
                "",
                "&e▸ &fKlik &7— Ganti material (via chat)",
                "&7Gunakan ID resmi Minecraft,",
                "&7contoh: &fDIAMOND_SWORD"
        )));
        inv.setItem(15, namedItem(Material.GOLD_NUGGET, "&6&lAtur Harga Beli", List.of(
                DIVIDER,
                "&7Harga saat ini: &6" + fmt(item.getBuyPrice()) + " Coin",
                "",
                "&e▸ &fKlik &7— Ubah harga (via chat)",
                "&7Isi &c0 &7untuk menonaktifkan pembelian."
        )));
        inv.setItem(16, namedItem(Material.EMERALD, "&a&lAtur Harga Jual", List.of(
                DIVIDER,
                "&7Harga saat ini: &a" + fmt(item.getSellPrice()) + " Coin",
                "",
                "&e▸ &fKlik &7— Ubah harga (via chat)",
                "&7Isi &c0 &7untuk menonaktifkan penjualan."
        )));
        inv.setItem(20, namedItem(Material.HOPPER, "&b&lAtur Jumlah per Transaksi", List.of(
                DIVIDER,
                "&7Jumlah saat ini: &f" + item.getAmount() + " item",
                "",
                "&e▸ &fKlik &7— Ubah jumlah (via chat)",
                "&7Contoh: isi 16 agar 1x transaksi",
                "&7setara dengan 16 item."
        )));
        inv.setItem(22, namedItem(Material.RED_SHULKER_BOX, "&c&lHapus Item dari Katalog", List.of(
                DIVIDER,
                "&7Tindakan ini akan menghapus item",
                "&7secara permanen dari kategori ini.",
                "",
                "&c▸ &fKlik &7— Hapus sekarang"
        )));
        inv.setItem(24, namedItem(Material.ARROW, "&f&lKembali ke Daftar Item", List.of(
                "&7Kembali tanpa mengubah data lain."
        )));

        player.openInventory(inv);
    }

    // ================= ITEM BUILDERS =================

    private static ItemStack buildCategoryIcon(ShopCategory cat, boolean editMode) {
        List<String> lore = new ArrayList<>();
        lore.add(DIVIDER);
        lore.add("&7Total Item &8: &e" + cat.getItems().size());
        lore.add(DIVIDER);
        lore.add("");
        if (editMode) {
            lore.add("&e▸ &fKlik &7— Kelola kategori ini");
            lore.add("&c▸ &fShift + Klik Kanan &7— Hapus kategori");
        } else {
            lore.add("&a▸ &fKlik &7— Jelajahi kategori ini");
        }
        return namedItem(cat.getIcon(), "&6&l" + cat.getTitle(), lore);
    }

    private static ItemStack buildShopItemIcon(ShopItem item) {
        List<String> lore = new ArrayList<>();
        lore.add(DIVIDER);
        if (item.isBuyable()) {
            lore.add("&7Harga Beli &8: &6" + fmt(item.getBuyPrice()) + " Coin &8(&7" + item.getAmount() + "x&8)");
        } else {
            lore.add("&7Harga Beli &8: &8Tidak Tersedia");
        }
        if (item.isSellable()) {
            lore.add("&7Harga Jual &8: &a" + fmt(item.getSellPrice()) + " Coin &8(&7" + item.getAmount() + "x&8)");
        } else {
            lore.add("&7Harga Jual &8: &8Tidak Diterima");
        }
        lore.add(DIVIDER);
        lore.add("");
        if (item.isBuyable()) {
            lore.add("&6▸ &fKlik Kiri &7— Beli " + item.getAmount() + " item");
            lore.add("&6▸ &fShift + Klik Kiri &7— Beli " + (item.getAmount() * 64) + " item");
        }
        if (item.isSellable()) {
            lore.add("&a▸ &fKlik Kanan &7— Jual " + item.getAmount() + " item");
            lore.add("&a▸ &fShift + Klik Kanan &7— Jual " + (item.getAmount() * 64) + " item");
        }
        ItemStack stack = namedItem(item.getMaterial(), "&f&l" + item.getDisplayName(), lore);
        stack.setAmount(Math.max(1, Math.min(64, item.getAmount())));
        return stack;
    }

    private static ItemStack buildEditItemIcon(ShopItem item) {
        List<String> lore = List.of(
                DIVIDER,
                "&7Material &8: &f" + item.getMaterial().name(),
                "&7Jumlah / Transaksi &8: &f" + item.getAmount(),
                "&7Harga Beli &8: &6" + fmt(item.getBuyPrice()) + " Coin",
                "&7Harga Jual &8: &a" + fmt(item.getSellPrice()) + " Coin",
                DIVIDER,
                "",
                "&e▸ &fKlik &7— Kelola item ini",
                "&c▸ &fShift + Klik Kanan &7— Hapus item"
        );
        ItemStack stack = namedItem(item.getMaterial(), "&f&l" + item.getDisplayName(), lore);
        stack.setAmount(Math.max(1, Math.min(64, item.getAmount())));
        return stack;
    }

    private static void fillBottomRow(Inventory inv) {
        ItemStack filler = namedItem(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int i = PAGE_SIZE; i < 54; i++) inv.setItem(i, filler);
    }

    private static void fillNav(Inventory inv, int page, int totalPages, String centerLabel) {
        fillBottomRow(inv);

        if (page > 0) {
            inv.setItem(SLOT_PREV, namedItem(Material.ARROW, "&e&l« Halaman Sebelumnya", List.of("&7Menuju halaman &f" + page + " &7dari &f" + totalPages)));
        }
        if (page < totalPages - 1) {
            inv.setItem(SLOT_NEXT, namedItem(Material.ARROW, "&e&lHalaman Berikutnya »", List.of("&7Menuju halaman &f" + (page + 2) + " &7dari &f" + totalPages)));
        }
        inv.setItem(SLOT_BACK, namedItem(Material.OAK_DOOR, "&f&l" + centerLabel, List.of(
                "&7Halaman &f" + (page + 1) + " &7dari &f" + totalPages,
                "",
                "&a▸ &fKlik &7— Kembali ke menu utama"
        )));
    }

    private static ItemStack namedItem(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material == null ? Material.STONE : material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Messages.color(name));
            List<String> colored = new ArrayList<>();
            for (String line : lore) colored.add(Messages.color(line));
            meta.setLore(colored);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private static String fmt(double v) {
        if (v == Math.floor(v)) return String.format("%,.0f", v);
        return String.format("%,.2f", v);
    }
}
