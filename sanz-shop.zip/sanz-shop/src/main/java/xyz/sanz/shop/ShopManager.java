package xyz.sanz.shop;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import xyz.sanz.shop.model.ShopCategory;
import xyz.sanz.shop.model.ShopItem;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

/**
 * Pusat penyimpanan & manajemen data toko (kategori + item di dalamnya).
 * Sumber data: plugins/SanzShop/shops.yml (di-copy dari resource bawaan saat pertama kali jalan).
 * Semua perubahan lewat shop editor akan langsung dipanggil save() supaya persisten.
 */
public class ShopManager {

    private final SanzShop plugin;
    private final File file;
    private final Map<String, ShopCategory> categories = new LinkedHashMap<>();

    public ShopManager(SanzShop plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "shops.yml");
    }

    public void load() {
        if (!file.exists()) {
            plugin.saveResource("shops.yml", false);
        }

        categories.clear();
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection catsSec = cfg.getConfigurationSection("categories");
        if (catsSec == null) {
            plugin.getLogger().warning("shops.yml tidak punya section 'categories'. Toko kosong.");
            return;
        }

        for (String key : catsSec.getKeys(false)) {
            ConfigurationSection catSec = catsSec.getConfigurationSection(key);
            if (catSec == null) continue;

            String title = catSec.getString("title", key);
            Material icon = parseMaterial(catSec.getString("icon", "CHEST"), Material.CHEST);
            ShopCategory category = new ShopCategory(key, title, icon);

            List<?> rawItems = catSec.getMapList("items");
            for (Object rawObj : rawItems) {
                if (!(rawObj instanceof Map<?, ?> raw)) continue;
                try {
                    Material mat = parseMaterial(String.valueOf(raw.get("material")), Material.STONE);
                    Object nameObj = raw.get("name");
                    String name = nameObj != null ? String.valueOf(nameObj) : prettyName(mat);
                    int amount = raw.get("amount") != null ? toInt(raw.get("amount")) : 1;
                    double buy = raw.get("buy") != null ? toDouble(raw.get("buy")) : 0;
                    double sell = raw.get("sell") != null ? toDouble(raw.get("sell")) : 0;
                    category.getItems().add(new ShopItem(mat, name, amount, buy, sell));
                } catch (Exception ex) {
                    plugin.getLogger().log(Level.WARNING, "Gagal load 1 item di kategori '" + key + "': " + raw, ex);
                }
            }
            categories.put(key, category);
        }

        plugin.getLogger().info("Berhasil memuat " + categories.size() + " kategori shop (" + countAllItems() + " item).");
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (ShopCategory cat : categories.values()) {
            String base = "categories." + cat.getKey();
            cfg.set(base + ".title", cat.getTitle());
            cfg.set(base + ".icon", cat.getIcon().name());

            List<Map<String, Object>> itemMaps = new ArrayList<>();
            for (ShopItem item : cat.getItems()) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("material", item.getMaterial().name());
                m.put("name", item.getDisplayName());
                m.put("amount", item.getAmount());
                m.put("buy", item.getBuyPrice());
                m.put("sell", item.getSellPrice());
                itemMaps.add(m);
            }
            cfg.set(base + ".items", itemMaps);
        }

        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Gagal menyimpan shops.yml", e);
        }
    }

    // ---------- helpers ----------

    private int toInt(Object o) {
        if (o instanceof Number n) return n.intValue();
        return Integer.parseInt(String.valueOf(o).trim());
    }

    private double toDouble(Object o) {
        if (o instanceof Number n) return n.doubleValue();
        return Double.parseDouble(String.valueOf(o).trim());
    }

    private Material parseMaterial(String name, Material fallback) {
        if (name == null) return fallback;
        Material m = Material.matchMaterial(name.trim());
        return m != null ? m : fallback;
    }

    private String prettyName(Material m) {
        String[] parts = m.name().split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1).toLowerCase()).append(' ');
        }
        return sb.toString().trim();
    }

    public int countAllItems() {
        int total = 0;
        for (ShopCategory c : categories.values()) total += c.getItems().size();
        return total;
    }

    // ---------- akses & CRUD ----------

    public Map<String, ShopCategory> getCategories() {
        return categories;
    }

    public List<ShopCategory> getCategoryList() {
        return new ArrayList<>(categories.values());
    }

    public ShopCategory getCategory(String key) {
        return categories.get(key);
    }

    public boolean categoryExists(String key) {
        return categories.containsKey(key);
    }

    public ShopCategory createCategory(String key, String title, Material icon) {
        ShopCategory cat = new ShopCategory(key, title, icon);
        categories.put(key, cat);
        save();
        return cat;
    }

    public boolean deleteCategory(String key) {
        boolean removed = categories.remove(key) != null;
        if (removed) save();
        return removed;
    }

    public ShopItem addItem(String categoryKey, Material material, String name, int amount, double buy, double sell) {
        ShopCategory cat = categories.get(categoryKey);
        if (cat == null) return null;
        ShopItem item = new ShopItem(material, name, amount, buy, sell);
        cat.getItems().add(item);
        save();
        return item;
    }

    public boolean removeItem(String categoryKey, int index) {
        ShopCategory cat = categories.get(categoryKey);
        if (cat == null) return false;
        if (index < 0 || index >= cat.getItems().size()) return false;
        cat.getItems().remove(index);
        save();
        return true;
    }
}
