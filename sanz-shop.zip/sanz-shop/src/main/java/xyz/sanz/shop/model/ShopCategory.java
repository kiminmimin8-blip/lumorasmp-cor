package xyz.sanz.shop.model;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.List;

/**
 * Satu kategori toko (mis. "Ores", "Farming", "Redstone").
 * Key harus unik & tanpa spasi — dipakai sebagai identifier internal (mis. di /shop <key>).
 */
public class ShopCategory {

    private final String key;
    private String title;
    private Material icon;
    private final List<ShopItem> items = new ArrayList<>();

    public ShopCategory(String key, String title, Material icon) {
        this.key = key;
        this.title = title;
        this.icon = icon;
    }

    public String getKey() {
        return key;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Material getIcon() {
        return icon;
    }

    public void setIcon(Material icon) {
        this.icon = icon;
    }

    public List<ShopItem> getItems() {
        return items;
    }
}
