package xyz.sanz.shop.util;

import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class InventoryUtils {

    private InventoryUtils() {}

    public static int countMaterial(Inventory inv, Material material) {
        int total = 0;
        for (ItemStack stack : inv.getContents()) {
            if (stack != null && stack.getType() == material) {
                total += stack.getAmount();
            }
        }
        return total;
    }

    /** Hapus sejumlah `amount` material dari inventory. Asumsikan sudah dicek cukup lewat countMaterial(). */
    public static void removeMaterial(Inventory inv, Material material, int amount) {
        int remaining = amount;
        ItemStack[] contents = inv.getContents();
        for (int i = 0; i < contents.length && remaining > 0; i++) {
            ItemStack stack = contents[i];
            if (stack == null || stack.getType() != material) continue;
            int take = Math.min(stack.getAmount(), remaining);
            int newAmount = stack.getAmount() - take;
            remaining -= take;
            // set eksplisit lewat setItem() supaya gak bergantung pada apakah getContents()
            // mengembalikan referensi live atau salinan (beda-beda antar implementasi server).
            if (newAmount <= 0) {
                inv.setItem(i, null);
            } else {
                stack.setAmount(newAmount);
                inv.setItem(i, stack);
            }
        }
    }

    /** Cek apakah inventory cukup ruang untuk menampung `amount` item material tertentu (stack size 64 default). */
    public static boolean hasSpaceFor(Inventory inv, Material material, int amount) {
        int maxStack = material.getMaxStackSize();
        int freeSlots = 0;
        int extraSpace = 0;
        for (ItemStack stack : inv.getContents()) {
            if (stack == null || stack.getType() == Material.AIR) {
                freeSlots++;
            } else if (stack.getType() == material && stack.getAmount() < maxStack) {
                extraSpace += (maxStack - stack.getAmount());
            }
        }
        long capacity = (long) freeSlots * maxStack + extraSpace;
        return capacity >= amount;
    }
}
