package xyz.sanz.shop;

import org.bukkit.plugin.java.JavaPlugin;
import xyz.sanz.shop.command.ShopCommand;
import xyz.sanz.shop.command.ShopEditCommand;
import xyz.sanz.shop.gui.GuiListener;
import xyz.sanz.shop.input.ChatInputManager;
import xyz.sanz.shop.service.ShopService;
import xyz.sanz.shop.util.Messages;

public class SanzShop extends JavaPlugin {

    private ShopManager shopManager;
    private ChatInputManager chatInputManager;
    private ShopService shopService;
    private Messages messages;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.messages = new Messages(this);

        if (!EconomyHook.setup(this)) {
            getLogger().warning("Vault / economy plugin tidak ditemukan! Fitur beli & jual akan gagal sampai Vault + economy plugin terpasang.");
        }

        this.shopManager = new ShopManager(this);
        this.shopManager.load();

        this.shopService = new ShopService(this);
        this.chatInputManager = new ChatInputManager(this);

        getServer().getPluginManager().registerEvents(new GuiListener(this), this);

        var shopCmd = getCommand("shop");
        if (shopCmd != null) shopCmd.setExecutor(new ShopCommand(this));

        var editCmd = getCommand("shopedit");
        if (editCmd != null) editCmd.setExecutor(new ShopEditCommand(this));

        getLogger().info("SanzShop aktif — " + shopManager.getCategories().size() + " kategori, "
                + shopManager.countAllItems() + " item siap dijual di Sanz Market.");
    }

    @Override
    public void onDisable() {
        if (shopManager != null) shopManager.save();
    }

    public ShopManager getShopManager() {
        return shopManager;
    }

    public ChatInputManager getChatInputManager() {
        return chatInputManager;
    }

    public ShopService getShopService() {
        return shopService;
    }

    public Messages getMessages() {
        return messages;
    }
}
