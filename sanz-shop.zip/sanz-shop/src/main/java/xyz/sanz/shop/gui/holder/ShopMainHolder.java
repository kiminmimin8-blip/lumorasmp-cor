package xyz.sanz.shop.gui.holder;

/** GUI: daftar kategori toko (mode belanja, bukan edit). */
public class ShopMainHolder extends BaseHolder {
}
