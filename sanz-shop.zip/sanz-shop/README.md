# SanzShop

Plugin toko in-game untuk Sanz SMP (Paper/Purpur 1.21.11), lengkap dengan **shop editor** in-game.
Dibuat dari data `shop_audes-1.xlsx` yang sudah dirapikan: armor dihapus, Ore vs Minerals & Gems
dipisah, Farming cuma isi item yang bisa di-farm (termasuk bamboo).

## Kategori bawaan (680 item)

| Key            | Judul               | Jumlah |
|----------------|----------------------|-------:|
| `ore`          | Ores                 | 14 |
| `minerals`     | Minerals & Gems      | 26 |
| `blocks`       | Blocks               | 435 |
| `farming`      | Farming              | 54 |
| `foods`        | Foods                | 17 |
| `dyes`         | Dyes & Flowers       | 24 |
| `redstone`     | Redstone             | 28 |
| `tools`        | Tools                | 15 |
| `drops_common` | Mob Drops (Umum)     | 12 |
| `drops_rare`   | Mob Drops (Langka)   | 14 |
| `misc`         | Miscellaneous        | 41 |

Semua data ada di `src/main/resources/shops.yml` (jadi default config saat plugin pertama kali jalan,
di-copy ke `plugins/SanzShop/shops.yml`).

## Requirement

- Paper/Purpur 1.21.11
- **Vault** + economy plugin apa pun (EssentialsX, CMI, dll) — wajib untuk beli/jual jalan.

## Build

Project ini Maven biasa. Kalau mau dibangun manual:

```bash
mvn clean package
```

Hasil jar ada di `target/SanzShop-1.0.0.jar`.

Kalau mau pakai GitHub Actions (sudah disediakan di `.github/workflows/build.yml`, pola extract-zip-lalu-build
kayak plugin sanz lainnya): tinggal push repo ini ke GitHub, workflow otomatis jalan tiap push ke `main`
dan artifact jar bisa didownload dari tab Actions.

## Command

| Command | Permission | Fungsi |
|---|---|---|
| `/shop` | `sanzshop.use` (default: true) | Buka menu utama toko |
| `/shop <kategori>` | `sanzshop.use` | Langsung buka satu kategori, contoh `/shop farming` |
| `/shopedit` | `sanzshop.edit` (default: op) | Buka GUI shop editor |
| `/shopedit reload` | `sanzshop.edit` | Muat ulang `shops.yml` dari disk |
| `/shopedit additem <kategori> <MATERIAL> <hargaBeli> <hargaJual> [nama...]` | `sanzshop.edit` | Tambah item cepat lewat command |
| `/shopedit removeitem <kategori> <MATERIAL>` | `sanzshop.edit` | Hapus item cepat lewat command |
| `/shopedit setprice <kategori> <MATERIAL> <hargaBeli> <hargaJual>` | `sanzshop.edit` | Ubah harga cepat lewat command |

## Cara belanja (GUI shop)

Di dalam kategori:
- **Klik Kiri** → beli 1x jumlah per-transaksi item itu
- **Shift + Klik Kiri** → beli 64x jumlah per-transaksi
- **Klik Kanan** → jual 1x jumlah per-transaksi
- **Shift + Klik Kanan** → jual 64x jumlah per-transaksi

Item dengan harga beli/jual = 0 otomatis tidak bisa dibeli/dijual (misal item langka yang cuma
boleh dijual, bukan dibeli).

## Shop Editor (`/shopedit`)

Fitur lengkap tanpa perlu edit YAML manual:

**Level kategori** (menu utama editor)
- Klik kategori → buka daftar item kategori itu
- Shift + Klik Kanan pada kategori → hapus kategori (beserta semua isinya)
- Tombol **+ Buat Kategori Baru** → diminta ketik ID & judul lewat chat

**Level item** (dalam satu kategori, mode edit)
- Klik item → buka detail edit item itu
- Shift + Klik Kanan pada item → hapus item itu langsung
- Tombol **+ Tambah Item ke Katalog** → diminta ketik material, harga beli, harga jual lewat chat
- Tombol **Kelola Informasi Kategori** → klik biasa ganti judul, Shift+Klik ganti ikon (pakai item di tangan)

**Detail item**
- Ubah nama tampilan
- Ubah material (ID item Minecraft, contoh `NETHERITE_INGOT`)
- Ubah harga beli
- Ubah harga jual
- Ubah jumlah item per transaksi
- Hapus item

Semua perubahan langsung tersimpan ke `shops.yml` setiap kali selesai edit — tidak perlu command
save terpisah.

## Struktur data `shops.yml`

```yaml
categories:
  ore:
    title: "Ores"
    icon: IRON_ORE
    items:
      - material: COAL_ORE
        name: "Coal Ore"
        amount: 1
        buy: 12
        sell: 3
```

- `amount` = jumlah item per satu "transaksi" (klik kiri/kanan tanpa shift)
- `buy: 0` → item tidak bisa dibeli
- `sell: 0` → item tidak bisa dijual ke shop

## Resource Pack pendamping (opsional)

Ada resource pack terpisah (`sanz-market-rp`) yang reskin tampilan GUI chest semua menu
plugin ini (menu belanja, kategori, shop editor) biar senada tema gelap+emas "Sanz Market".
Cuma kosmetik — plugin tetap jalan normal tanpa resource pack ini. Lihat README di dalam
folder resource pack itu buat cara pasangnya.

## Catatan build di sandbox ini

**Update 29 Agustus 2026** — versi tools di-update ke rilis terbaru: GitHub Actions
(`checkout@v7`, `setup-java@v6`, `upload-artifact@v7`), `maven-shade-plugin` (3.6.2),
`VaultAPI` (1.7.1).


**Update penting**: plugin ini sempat di-compile salah target versi (Paper API 1.20.4),
padahal server Sanz SMP jalan di **1.21.11**. Sudah diperbaiki:
- `pom.xml`: `paper-api` versi `1.21.11-R0.1-SNAPSHOT`
- `plugin.yml`: `api-version: '1.21'`
- `AsyncPlayerChatEvent` (deprecated) diganti `io.papermc.paper.event.player.AsyncChatEvent`
  di `GuiListener` — dicek lewat dokumentasi resmi Paper 1.21.11, bukan asumsi.
- Signature API lain yang dipakai (`setDisplayName`, `setLore`, `Bukkit.createInventory`
  dengan `Component` title) sudah dicek tetap valid & tidak deprecated di 1.21.11.

Kode ditulis manual (bukan hasil kompilasi otomatis) karena sandbox pembuatan file ini tidak
punya akses internet untuk fetch Paper API / Vault API dari Maven. Sudah dicek dan diperbaiki:
- Semua kurung `{}` `()` di tiap file seimbang.
- Alur logika GUI & command ditelusuri ulang baris per baris, file per file.
- **Bug ditemukan & diperbaiki**: menu utama shop & editor sempat dibuat dengan ukuran
  inventory 45 slot tapi ada tombol yang dipasang di slot 47/49 (di luar jangkauan) —
  sudah diperbaiki jadi 54 slot dengan baris navigasi konsisten seperti menu lainnya.
- **Data dibersihkan**: 554 field harga di `shops.yml` yang kebawa nilai `-1` dari
  spreadsheet sumber (dipakai sebagai penanda "tidak dijual") sudah dinormalisasi jadi
  `0`, sesuai konvensi yang didokumentasikan di atas.

Tetap wajib di-build & ditest di server beneran lewat GitHub Actions (pola yang biasa dipakai)
sebelum dipasang ke Sanz SMP production, terutama buat mastiin cocok sama versi Paper/Vault yang
lagi jalan di server.
