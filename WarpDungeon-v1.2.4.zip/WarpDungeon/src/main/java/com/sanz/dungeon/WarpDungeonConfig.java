package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

/**
 * Bungkus config.yml - semua yang sebelumnya ke-hardcode di kode Java
 * (waktu dungeon, setting world border, proteksi mana yang nyala, daftar
 * command yang diblokir, currency shop, pesan-pesan) sekarang diambil dari
 * sini, jadi bisa diedit lewat panel tanpa compile ulang.
 *
 * Key baru di v1.1 selalu punya nilai default di kode ini, jadi config.yml
 * lama di server (yang gak ke-overwrite pas update jar) tetep jalan normal.
 */
public class WarpDungeonConfig {

    private static final Map<String, String> DEFAULT_MESSAGES = new HashMap<>();

    static {
        DEFAULT_MESSAGES.put("command-blocked", "&cCommand itu gak bisa dipakai di dalam dungeon.");
        DEFAULT_MESSAGES.put("no-permission", "&cKamu gak punya izin buat command ini.");
        DEFAULT_MESSAGES.put("shop-not-in-dungeon", "&cKamu harus di dalam dungeon dulu buat buka shopnya.");
        DEFAULT_MESSAGES.put("shop-empty", "&cDungeon ini belum ada shop-nya.");

        DEFAULT_MESSAGES.put("enter-title", "&6&l%dungeon%");
        DEFAULT_MESSAGES.put("enter-subtitle", "&7Hati-hati di dalam sana...");
        DEFAULT_MESSAGES.put("leave-title", "&e&lKeluar dungeon");
        DEFAULT_MESSAGES.put("leave-subtitle", "&7%time% di dalam, %kills% kill");
        DEFAULT_MESSAGES.put("leave-summary", "&7Kamu keluar dari &e%dungeon% &7setelah &f%time% &7dan &c%kills% kill&7.");
        DEFAULT_MESSAGES.put("hud-format", "&6%dungeon% &8| &7Waktu &a%time% &8| &7Kill &c%kills% &8| &7Pemain &b%players%");

        DEFAULT_MESSAGES.put("entry-blocked", "&cKamu cuma bisa masuk dungeon lewat &f/dungeon&c.");
        DEFAULT_MESSAGES.put("dungeon-closed", "&cDungeon ini lagi ditutup: &f%reason%");
        DEFAULT_MESSAGES.put("closed-default-reason", "Lagi maintenance.");
        DEFAULT_MESSAGES.put("afk-warning", "&eKamu kelihatan AFK. Gerak dalam &f%seconds% detik &eatau kamu dikeluarin dari dungeon.");
        DEFAULT_MESSAGES.put("afk-kick", "&cKamu dikeluarin dari dungeon karena AFK terlalu lama.");
        DEFAULT_MESSAGES.put("drop-blocked", "&cKamu gak bisa buang item di dalam dungeon.");
        DEFAULT_MESSAGES.put("reward-delivered", "&aHadiah dungeon kamu udah dikirim!");
        DEFAULT_MESSAGES.put("leaderboard-header", "&6&lJuara Kill Dungeon periode lalu:");
        DEFAULT_MESSAGES.put("leaderboard-line", "&e#%rank% &f%player% &7- &c%kills% kill");
        DEFAULT_MESSAGES.put("not-ready", "&cDungeon ini belum siap.");
        DEFAULT_MESSAGES.put("need-permission", "&cKamu belum punya akses buat dungeon ini.");
        DEFAULT_MESSAGES.put("need-level", "&cButuh minimal level &f%level% &cbuat masuk dungeon ini.");
        DEFAULT_MESSAGES.put("on-cooldown", "&cTunggu &f%time% &clagi buat masuk dungeon ini.");
        DEFAULT_MESSAGES.put("dungeon-full", "&cDungeon ini penuh (&f%max% &cpemain).");
        DEFAULT_MESSAGES.put("not-enough-money", "&cUang kamu gak cukup. Butuh &f%price%&c.");
        DEFAULT_MESSAGES.put("charge-failed", "&cGagal charge tiket, coba lagi.");
        DEFAULT_MESSAGES.put("ticket-paid", "&aTiket &f%price% &akepotong.");
        DEFAULT_MESSAGES.put("teleported", "&aTeleport ke dungeon &f%dungeon%&a.");
        DEFAULT_MESSAGES.put("teleport-failed", "&cTeleport gagal, tiket kamu dikembaliin.");

        DEFAULT_MESSAGES.put("warmup-start", "&eTeleport ke &f%dungeon% &edalam &f%seconds% detik&e. Jangan gerak!");
        DEFAULT_MESSAGES.put("warmup-tick", "&eTeleport dalam &f%seconds%&e...");
        DEFAULT_MESSAGES.put("warmup-cancel-move", "&cTeleport dibatalin karena kamu gerak.");
        DEFAULT_MESSAGES.put("warmup-cancel-damage", "&cTeleport dibatalin karena kamu kena damage.");
        DEFAULT_MESSAGES.put("warmup-already", "&cKamu lagi nunggu teleport.");
    }

    /** 1 milestone kill: pesan ke player + command console yang dijalanin. */
    public static class Milestone {
        public final String message;
        public final List<String> commands;

        public Milestone(String message, List<String> commands) {
            this.message = message == null ? "" : message;
            this.commands = commands;
        }
    }

    private final Plugin plugin;

    private long dungeonTime;

    private double borderInset;
    private int borderWarningDistance;
    private int borderWarningTime;
    private double borderDamageAmount;
    private double borderDamageBuffer;

    private boolean protectBlockBreak;
    private boolean protectBlockPlace;
    private boolean allowPvp;
    private boolean protectExplosion;
    private boolean blockEnderpearl;
    private boolean blockElytra;
    private boolean blockFirework;
    private boolean onlyMythicMobsSpawn;
    private boolean protectBucket;
    private boolean protectMobGriefing;
    private boolean protectFire;
    private boolean protectDecorations;
    private boolean blockOutsideTeleport;
    private boolean blockItemDrop;
    private double leaveMargin;

    private boolean afkEnabled;
    private int afkTimeoutSeconds;
    private int afkWarnSeconds;

    private boolean milestonesEnabled;
    private Map<Long, Milestone> milestones;

    private String leaderboardMode;
    private String leaderboardZone;
    private int leaderboardTopSize;
    private boolean leaderboardBroadcast;
    private Map<Integer, List<String>> leaderboardRewards;

    private int warmupSeconds;
    private boolean warmupCancelOnMove;
    private boolean warmupCancelOnDamage;

    private boolean hudEnabled;
    private boolean titlesEnabled;
    private String soundEnter;
    private String soundLeave;

    private boolean deathKeepInventory;
    private boolean deathKeepLevel;
    private List<String> killCommands;

    private Set<String> blockedCommands;
    private Set<String> blockedTeamSubcommands;
    private List<String> shopCurrencies;

    public WarpDungeonConfig(Plugin plugin) {
        this.plugin = plugin;
        plugin.saveDefaultConfig();
        load();
    }

    /** Dipanggil dari /dungeon reload - baca ulang config.yml dari disk. */
    public void reload() {
        plugin.reloadConfig();
        load();
    }

    private void load() {
        FileConfiguration c = plugin.getConfig();

        dungeonTime = c.getLong("dungeon-time", 1000L);

        borderInset = Math.max(0.0, c.getDouble("world-border.inset", 10.0));
        borderWarningDistance = c.getInt("world-border.warning-distance", 0);
        borderWarningTime = c.getInt("world-border.warning-time", 0);
        borderDamageAmount = c.getDouble("world-border.damage-amount", 0.0);
        borderDamageBuffer = c.getDouble("world-border.damage-buffer", 0.0);

        protectBlockBreak = c.getBoolean("protection.block-break", true);
        protectBlockPlace = c.getBoolean("protection.block-place", true);
        allowPvp = c.getBoolean("protection.allow-pvp", false);
        protectExplosion = c.getBoolean("protection.explosion-damage-block", true);
        blockEnderpearl = c.getBoolean("protection.block-enderpearl", true);
        blockElytra = c.getBoolean("protection.block-elytra", true);
        blockFirework = c.getBoolean("protection.block-firework", true);
        // Key lama "only-mythicmobs-spawn" (default nyala) SENGAJA diabaikan: filternya
        // ikut ngehapus mob MythicMobs yang asli. Key baru default MATI, jadi semua
        // mob boleh spawn di dalam dungeon (termasuk mob random/vanilla).
        onlyMythicMobsSpawn = c.getBoolean("protection.remove-non-mythic-mobs", false);
        protectBucket = c.getBoolean("protection.block-bucket", true);
        protectMobGriefing = c.getBoolean("protection.block-mob-griefing", true);
        protectFire = c.getBoolean("protection.block-fire", true);
        protectDecorations = c.getBoolean("protection.block-decorations", true);
        blockOutsideTeleport = c.getBoolean("protection.block-outside-teleport", true);
        blockItemDrop = c.getBoolean("protection.block-item-drop", true);
        leaveMargin = Math.max(0.0, c.getDouble("region.leave-margin", 3.0));
        Dungeon.setFullHeight(c.getBoolean("region.full-height", true));

        afkEnabled = c.getBoolean("afk.enabled", true);
        afkTimeoutSeconds = Math.max(60, c.getInt("afk.timeout-minutes", 10) * 60);
        afkWarnSeconds = Math.max(0, c.getInt("afk.warn-seconds", 30));

        milestonesEnabled = c.getBoolean("milestones.enabled", true);
        milestones = new TreeMap<>();
        ConfigurationSection ms = c.getConfigurationSection("milestones.kills");
        if (ms != null) {
            for (String key : ms.getKeys(false)) {
                long threshold;
                try {
                    threshold = Long.parseLong(key.trim());
                } catch (NumberFormatException ex) {
                    continue;
                }
                milestones.put(threshold, new Milestone(ms.getString(key + ".message", ""), ms.getStringList(key + ".commands")));
            }
        }

        String mode = c.getString("leaderboard.reset", "weekly");
        leaderboardMode = mode == null ? "weekly" : mode.trim().toLowerCase();
        if (!leaderboardMode.equals("weekly") && !leaderboardMode.equals("monthly")) leaderboardMode = "off";
        leaderboardZone = c.getString("leaderboard.timezone", "Asia/Jakarta");
        leaderboardTopSize = Math.max(1, c.getInt("leaderboard.top-size", 3));
        leaderboardBroadcast = c.getBoolean("leaderboard.broadcast", true);
        leaderboardRewards = new TreeMap<>();
        ConfigurationSection rs = c.getConfigurationSection("leaderboard.rewards");
        if (rs != null) {
            for (String key : rs.getKeys(false)) {
                int rank;
                try {
                    rank = Integer.parseInt(key.trim());
                } catch (NumberFormatException ex) {
                    continue;
                }
                leaderboardRewards.put(rank, rs.getStringList(key));
            }
        }

        warmupSeconds = Math.max(0, c.getInt("teleport.warmup-seconds", 3));
        warmupCancelOnMove = c.getBoolean("teleport.cancel-on-move", true);
        warmupCancelOnDamage = c.getBoolean("teleport.cancel-on-damage", true);

        hudEnabled = c.getBoolean("hud.enabled", true);
        titlesEnabled = c.getBoolean("titles.enabled", true);
        soundEnter = c.getString("sounds.enter", "entity.enderman.teleport");
        soundLeave = c.getString("sounds.leave", "entity.experience_orb.pickup");

        deathKeepInventory = c.getBoolean("death.keep-inventory", false);
        deathKeepLevel = c.getBoolean("death.keep-level", false);
        killCommands = c.getStringList("rewards.kill-commands");

        blockedCommands = lowerSet(c.getStringList("blocked-commands"));
        blockedTeamSubcommands = lowerSet(c.getStringList("blocked-team-subcommands"));

        shopCurrencies = c.getStringList("shop-currencies").stream()
                .map(String::toLowerCase)
                .collect(Collectors.toList());
        if (shopCurrencies.isEmpty()) shopCurrencies = List.of("money");
    }

    private Set<String> lowerSet(List<String> raw) {
        return new HashSet<>(raw.stream().map(String::toLowerCase).collect(Collectors.toList()));
    }

    private String color(String s) {
        return Colors.apply(s);
    }

    /**
     * Ambil pesan dari config.yml (messages.<key>) lalu ganti placeholder.
     * Pemakaian: msg("on-cooldown", "%time%", "01:30")  -> pasangan kunci, nilai.
     */
    public String msg(String key, String... replacements) {
        String raw = plugin.getConfig().getString("messages." + key);
        if (raw == null) raw = DEFAULT_MESSAGES.get(key);
        if (raw == null) raw = "&c[pesan '" + key + "' belum ada di config.yml]";
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            raw = raw.replace(replacements[i], replacements[i + 1]);
        }
        return color(raw);
    }

    /** Format HUD actionbar mentah (masih pake kode &, placeholder belum diganti). */
    public String getHudFormat() {
        String raw = plugin.getConfig().getString("hud.format");
        if (raw == null) raw = DEFAULT_MESSAGES.get("hud-format");
        return raw;
    }

    public long getDungeonTime() { return dungeonTime; }

    public double getBorderInset() { return borderInset; }
    public int getBorderWarningDistance() { return borderWarningDistance; }
    public int getBorderWarningTime() { return borderWarningTime; }
    public double getBorderDamageAmount() { return borderDamageAmount; }
    public double getBorderDamageBuffer() { return borderDamageBuffer; }

    public boolean isProtectBlockBreak() { return protectBlockBreak; }
    public boolean isProtectBlockPlace() { return protectBlockPlace; }
    public boolean isAllowPvp() { return allowPvp; }
    public boolean isProtectExplosion() { return protectExplosion; }
    public boolean isBlockEnderpearl() { return blockEnderpearl; }
    public boolean isBlockElytra() { return blockElytra; }
    public boolean isBlockFirework() { return blockFirework; }
    public boolean isOnlyMythicMobsSpawn() { return onlyMythicMobsSpawn; }
    public boolean isProtectBucket() { return protectBucket; }
    public boolean isProtectMobGriefing() { return protectMobGriefing; }
    public boolean isProtectFire() { return protectFire; }
    public boolean isProtectDecorations() { return protectDecorations; }
    public boolean isBlockOutsideTeleport() { return blockOutsideTeleport; }
    public boolean isBlockItemDrop() { return blockItemDrop; }
    public double getLeaveMargin() { return leaveMargin; }

    public boolean isAfkEnabled() { return afkEnabled; }
    public int getAfkTimeoutSeconds() { return afkTimeoutSeconds; }
    public int getAfkWarnSeconds() { return afkWarnSeconds; }

    public boolean isMilestonesEnabled() { return milestonesEnabled; }
    public Map<Long, Milestone> getMilestones() { return milestones; }

    /** "weekly", "monthly", atau "off". */
    public String getLeaderboardMode() { return leaderboardMode; }
    public String getLeaderboardZone() { return leaderboardZone; }
    public int getLeaderboardTopSize() { return leaderboardTopSize; }
    public boolean isLeaderboardBroadcast() { return leaderboardBroadcast; }
    public Map<Integer, List<String>> getLeaderboardRewards() { return leaderboardRewards; }

    public int getWarmupSeconds() { return warmupSeconds; }
    public boolean isWarmupCancelOnMove() { return warmupCancelOnMove; }
    public boolean isWarmupCancelOnDamage() { return warmupCancelOnDamage; }

    public boolean isHudEnabled() { return hudEnabled; }
    public boolean isTitlesEnabled() { return titlesEnabled; }
    public String getSoundEnter() { return soundEnter; }
    public String getSoundLeave() { return soundLeave; }

    public boolean isDeathKeepInventory() { return deathKeepInventory; }
    public boolean isDeathKeepLevel() { return deathKeepLevel; }
    public List<String> getKillCommands() { return killCommands; }

    public Set<String> getBlockedCommands() { return blockedCommands; }
    public Set<String> getBlockedTeamSubcommands() { return blockedTeamSubcommands; }
    public List<String> getShopCurrencies() { return shopCurrencies; }

    // getter lama, tetep dipertahankan biar kode yang udah ada gak perlu diubah
    public String getMsgCommandBlocked() { return msg("command-blocked"); }
    public String getMsgNoPermission() { return msg("no-permission"); }
    public String getMsgShopNotInDungeon() { return msg("shop-not-in-dungeon"); }
    public String getMsgShopEmpty() { return msg("shop-empty"); }
}
