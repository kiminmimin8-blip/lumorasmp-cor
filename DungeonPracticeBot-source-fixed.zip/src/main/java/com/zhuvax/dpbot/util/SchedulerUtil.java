package com.zhuvax.dpbot.util;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;

import java.util.function.Consumer;

/**
 * Small wrapper so the rest of the plugin never has to care whether it's
 * running on Folia (regionized) or a normal Paper/Spigot server.
 */
public final class SchedulerUtil {

    private static Boolean folia;

    private SchedulerUtil() {
    }

    public static boolean isFolia() {
        if (folia == null) {
            try {
                Class.forName("io.papermc.paper.threadedregions.RegionizedServer");
                folia = true;
            } catch (ClassNotFoundException e) {
                folia = false;
            }
        }
        return folia;
    }

    /** Run a task tied to a specific location (used for spawning entities). */
    public static void runAtLocation(Plugin plugin, Location location, Runnable task) {
        if (isFolia()) {
            plugin.getServer().getRegionScheduler().run(plugin, location, t -> task.run());
        } else {
            plugin.getServer().getScheduler().runTask(plugin, task);
        }
    }

    /** Run a task tied to a specific location after a delay, in ticks. */
    public static void runAtLocationLater(Plugin plugin, Location location, long delayTicks, Runnable task) {
        if (isFolia()) {
            plugin.getServer().getRegionScheduler().runDelayed(plugin, location, t -> task.run(), Math.max(1, delayTicks));
        } else {
            plugin.getServer().getScheduler().runTaskLater(plugin, task, delayTicks);
        }
    }

    /** Run a task tied to a specific entity (used for entity-bound follow-up logic). */
    public static void runOnEntity(Plugin plugin, Entity entity, Runnable task) {
        if (isFolia()) {
            entity.getScheduler().run(plugin, t -> task.run(), null);
        } else {
            plugin.getServer().getScheduler().runTask(plugin, task);
        }
    }

    public static void consumeOnEntity(Plugin plugin, Entity entity, Consumer<Entity> task) {
        if (isFolia()) {
            entity.getScheduler().run(plugin, t -> task.accept(entity), null);
        } else {
            plugin.getServer().getScheduler().runTask(plugin, () -> task.accept(entity));
        }
    }

    /** Run a task tied to an entity after a delay, in ticks (e.g. swap a weapon back). */
    public static void runOnEntityLater(Plugin plugin, Entity entity, long delayTicks, Runnable task) {
        if (isFolia()) {
            entity.getScheduler().runDelayed(plugin, t -> task.run(), null, Math.max(1, delayTicks));
        } else {
            plugin.getServer().getScheduler().runTaskLater(plugin, task, delayTicks);
        }
    }

    /**
     * Repeating task bound to an entity (used for leash-radius checks). Returns a handle
     * you can cancel later (e.g. when the bot dies or is removed).
     */
    public interface TaskHandle {
        void cancel();
    }

    public static TaskHandle runOnEntityRepeating(Plugin plugin, Entity entity, long delayTicks, long periodTicks, Runnable task) {
        if (isFolia()) {
            io.papermc.paper.threadedregions.scheduler.ScheduledTask scheduled =
                    entity.getScheduler().runAtFixedRate(plugin, t -> task.run(), null, Math.max(1, delayTicks), Math.max(1, periodTicks));
            return () -> {
                if (scheduled != null) scheduled.cancel();
            };
        } else {
            org.bukkit.scheduler.BukkitTask bukkitTask =
                    plugin.getServer().getScheduler().runTaskTimer(plugin, task, delayTicks, periodTicks);
            return bukkitTask::cancel;
        }
    }
}
