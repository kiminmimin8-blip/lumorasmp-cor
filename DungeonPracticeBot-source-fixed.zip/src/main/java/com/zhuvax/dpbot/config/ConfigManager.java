package com.zhuvax.dpbot.config;

import com.zhuvax.dpbot.difficulty.Difficulty;
import com.zhuvax.dpbot.loot.LootEntry;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ConfigManager {

    private final JavaPlugin plugin;
    private FileConfiguration config;
    private FileConfiguration messages;
    private File messagesFile;

    public ConfigManager(JavaPlugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        config = plugin.getConfig();

        messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        if (!messagesFile.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        messages = YamlConfiguration.loadConfiguration(messagesFile);
    }

    public FileConfiguration raw() {
        return config;
    }

    // ---------------- Messages ----------------

    public String msg(String key) {
        String prefix = messages.getString("prefix", "");
        return prefix + messages.getString(key, key);
    }

    public String msg(String key, String placeholder, String value) {
        return msg(key).replace("{" + placeholder + "}", value);
    }

    // ---------------- Combat AI (strafe / w-tap / block / jitter) ----------------

    public boolean combatAiEnabled() {
        return config.getBoolean("combat-ai.enabled", true);
    }

    public int strafeSwitchMinTicks() {
        return config.getInt("combat-ai.strafe-switch-min-ticks", 8);
    }

    public int strafeSwitchMaxTicks() {
        return config.getInt("combat-ai.strafe-switch-max-ticks", 18);
    }

    public double strafeDistance() {
        return config.getDouble("combat-ai.strafe-distance", 2.4);
    }

    public int wtapMinTicks() {
        return config.getInt("combat-ai.wtap-min-ticks", 12);
    }

    public int wtapMaxTicks() {
        return config.getInt("combat-ai.wtap-max-ticks", 30);
    }

    public int wtapDurationTicks() {
        return config.getInt("combat-ai.wtap-duration-ticks", 4);
    }

    public double engageRange() {
        return config.getDouble("combat-ai.engage-range", 8.0);
    }

    public double blockDamageReduction() {
        return config.getDouble("combat-ai.block-damage-reduction", 0.55);
    }

    public int blockDurationTicks() {
        return config.getInt("combat-ai.block-duration-ticks", 5);
    }

    public int blockRerollTicks() {
        return config.getInt("combat-ai.block-reroll-ticks", 8);
    }

    public double hitJitterFraction() {
        return config.getDouble("combat-ai.hit-jitter-fraction", 0.3);
    }

    public int weaponSwapDurationTicks() {
        return config.getInt("combat-ai.weapon-swap-duration-ticks", 12);
    }

    public int comboMinHits() {
        return config.getInt("combat-ai.combo-min-hits", 2);
    }

    public int comboMaxHits() {
        return config.getInt("combat-ai.combo-max-hits", 4);
    }

    public double comboChainMultiplier() {
        return config.getDouble("combat-ai.combo-chain-multiplier", 0.5);
    }

    public double comboRecoveryMultiplier() {
        return config.getDouble("combat-ai.combo-recovery-multiplier", 1.8);
    }

    // ---------------- Crystal PvP ----------------

    public boolean crystalPvpEnabled() {
        return config.getBoolean("crystal-pvp.enabled", true);
    }

    public long crystalCooldownTicks() {
        return config.getLong("crystal-pvp.cooldown-ticks", 60);
    }

    public double crystalMinRange() {
        return config.getDouble("crystal-pvp.min-range", 1.2);
    }

    public double crystalMaxRange() {
        return config.getDouble("crystal-pvp.max-range", 5.0);
    }

    public double crystalAttemptChance() {
        return config.getDouble("crystal-pvp.attempt-chance", 0.35);
    }

    public int crystalDetonateDelayMinTicks() {
        return config.getInt("crystal-pvp.detonate-delay-min-ticks", 4);
    }

    public int crystalDetonateDelayMaxTicks() {
        return config.getInt("crystal-pvp.detonate-delay-max-ticks", 10);
    }

    public float crystalExplosionPower() {
        return (float) config.getDouble("crystal-pvp.explosion-power", 6.0);
    }

    public boolean crystalBreakBlocks() {
        return config.getBoolean("crystal-pvp.break-blocks", false);
    }

    public long crystalRestoreBlockDelayTicks() {
        return config.getLong("crystal-pvp.restore-block-delay-ticks", 40);
    }

    public double crystalSelfDamageReduction() {
        return config.getDouble("crystal-pvp.self-damage-reduction", 0.4);
    }

    // ---------------- Anchor PvP ----------------

    public boolean anchorPvpEnabled() {
        return config.getBoolean("anchor-pvp.enabled", true);
    }

    public long anchorCooldownTicks() {
        return config.getLong("anchor-pvp.cooldown-ticks", 100);
    }

    public double anchorMinRange() {
        return config.getDouble("anchor-pvp.min-range", 1.2);
    }

    public double anchorMaxRange() {
        return config.getDouble("anchor-pvp.max-range", 5.0);
    }

    public double anchorAttemptChance() {
        return config.getDouble("anchor-pvp.attempt-chance", 0.25);
    }

    public int anchorDetonateDelayMinTicks() {
        return config.getInt("anchor-pvp.detonate-delay-min-ticks", 4);
    }

    public int anchorDetonateDelayMaxTicks() {
        return config.getInt("anchor-pvp.detonate-delay-max-ticks", 10);
    }

    public float anchorExplosionPower() {
        return (float) config.getDouble("anchor-pvp.explosion-power", 8.0);
    }

    public boolean anchorBreakBlocks() {
        return config.getBoolean("anchor-pvp.break-blocks", false);
    }

    public long anchorRestoreBlockDelayTicks() {
        return config.getLong("anchor-pvp.restore-block-delay-ticks", 40);
    }

    // ---------------- Bot defaults (apply to every named bot) ----------------

    public String nameFormat() {
        return config.getString("bot.name-format", "&6{name}");
    }

    public int attackCooldownTicks() {
        return config.getInt("bot.attack-cooldown-ticks", 10);
    }

    public boolean fallDamage() {
        return config.getBoolean("bot.fall-damage", false);
    }

    public Difficulty loadDifficulty(String key) {
        String path = "difficulty." + key.toUpperCase();
        if (!config.isConfigurationSection(path)) {
            return Difficulty.byName(key);
        }
        return new Difficulty(
                key.toUpperCase(),
                config.getDouble(path + ".health", 20.0),
                config.getDouble(path + ".damage-multiplier", 1.0),
                config.getDouble(path + ".reach", 3.5),
                config.getInt(path + ".attack-speed-ticks", 12),
                config.getDouble(path + ".block-chance", 0.1)
        );
    }

    // ---------------- Shared loot table (applies to every bot's death) ----------------

    public List<LootEntry> lootTable() {
        List<LootEntry> entries = new ArrayList<>();
        List<Map<?, ?>> rawList = config.getMapList("loot-table");
        for (Map<?, ?> row : rawList) {
            try {
                Material material = Material.valueOf(String.valueOf(row.get("material")).toUpperCase());
                int min = row.get("min-amount") != null ? ((Number) row.get("min-amount")).intValue() : 1;
                int max = row.get("max-amount") != null ? ((Number) row.get("max-amount")).intValue() : min;
                double chance = row.get("chance") != null ? ((Number) row.get("chance")).doubleValue() : 1.0;
                entries.add(new LootEntry(material, min, max, chance));
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Item loot tidak valid di config loot-table: " + row);
            }
        }
        return entries;
    }
}
