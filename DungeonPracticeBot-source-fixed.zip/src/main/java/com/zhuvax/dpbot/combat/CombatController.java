package com.zhuvax.dpbot.combat;

import com.zhuvax.dpbot.bot.BotDefinitionManager;
import com.zhuvax.dpbot.bot.PracticeBot;
import com.zhuvax.dpbot.config.ConfigManager;
import com.zhuvax.dpbot.util.SchedulerUtil;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Drives everything about a bot's fight: movement (circle-strafing, W-tap),
 * block/parry windows, crystal/anchor abilities, and now the attack itself.
 * <p>
 * Bots are Mannequin entities (for real player skins), which have NO built-in
 * AI, pathfinding, or auto-attack - unlike the old Zombie-based bots. So this
 * controller owns 100% of movement (teleport-based, not Pathfinder) and
 * calls {@link LivingEntity#attack(org.bukkit.entity.Entity)} directly to
 * land hits on a combo-aware schedule, instead of hoping vanilla AI happens
 * to connect.
 */
public class CombatController {

    private final JavaPlugin plugin;
    private final ConfigManager cfg;
    private final BotDefinitionManager botDefManager;

    private final Map<UUID, BotCombatState> states = new HashMap<>();
    private final Map<UUID, SchedulerUtil.TaskHandle> tasks = new HashMap<>();

    public CombatController(JavaPlugin plugin, ConfigManager cfg, BotDefinitionManager botDefManager) {
        this.plugin = plugin;
        this.cfg = cfg;
        this.botDefManager = botDefManager;
    }

    public void attach(PracticeBot bot) {
        if (!cfg.combatAiEnabled()) return;
        LivingEntity entity = bot.getEntity();
        UUID id = entity.getUniqueId();
        states.put(id, new BotCombatState());
        SchedulerUtil.TaskHandle handle = SchedulerUtil.runOnEntityRepeating(plugin, entity, 4L, 2L, () -> tick(bot));
        tasks.put(id, handle);
    }

    public void detach(UUID id) {
        SchedulerUtil.TaskHandle handle = tasks.remove(id);
        if (handle != null) handle.cancel();
        states.remove(id);
    }

    public boolean isBlocking(UUID id) {
        BotCombatState state = states.get(id);
        return state != null && state.blocking && System.currentTimeMillis() < state.blockingUntilMillis;
    }

    private void tick(PracticeBot bot) {
        LivingEntity entity = bot.getEntity();
        if (entity == null || entity.isDead() || !entity.isValid()) return;
        UUID id = entity.getUniqueId();
        BotCombatState state = states.get(id);
        if (state == null) return;

        Player target = acquireTarget(entity);
        long now = System.currentTimeMillis();

        if (target == null) {
            state.blocking = false;
            return;
        }

        double distance = entity.getLocation().distance(target.getLocation());
        double reach = bot.getDifficulty().getReach();
        double engageRange = cfg.engageRange();

        // Block/parry roll, independent of movement
        if (now >= state.nextBlockRollMillis) {
            state.nextBlockRollMillis = now + cfg.blockRerollTicks() * 50L;
            if (!state.blocking && distance <= reach + 1.5) {
                if (ThreadLocalRandom.current().nextDouble() < bot.getDifficulty().getBlockChance()) {
                    state.blocking = true;
                    state.blockingUntilMillis = now + cfg.blockDurationTicks() * 50L;
                }
            }
        }
        if (state.blocking && now >= state.blockingUntilMillis) {
            state.blocking = false;
        }

        // Attack: this is what actually deals damage now (Mannequin has no
        // vanilla melee goal to fall back on), on a combo-aware schedule.
        if (distance <= reach && now >= state.nextAttackMillis) {
            entity.attack(target);
            state.nextAttackMillis = now + comboAdjustedCooldownMillis(state, bot.getDifficulty().getAttackSpeedTicks());
        }

        // Crystal PvP: independent of melee engage range, checked first since
        // it can trigger from slightly further out than melee strafing does.
        if (cfg.crystalPvpEnabled() && crystalAllowedFor(bot) && now >= state.nextCrystalMillis) {
            if (distance >= cfg.crystalMinRange() && distance <= cfg.crystalMaxRange()) {
                if (ThreadLocalRandom.current().nextDouble() < cfg.crystalAttemptChance()) {
                    boolean used = CrystalAbility.tryPlaceAndDetonate(plugin, cfg, entity, target);
                    if (used) {
                        state.nextCrystalMillis = now + cfg.crystalCooldownTicks() * 50L;
                    }
                }
            }
        }

        // Anchor PvP: same idea, separate cooldown/toggle, bigger blast.
        if (cfg.anchorPvpEnabled() && anchorAllowedFor(bot) && now >= state.nextAnchorMillis) {
            if (distance >= cfg.anchorMinRange() && distance <= cfg.anchorMaxRange()) {
                if (ThreadLocalRandom.current().nextDouble() < cfg.anchorAttemptChance()) {
                    boolean used = AnchorAbility.tryPlaceAndDetonate(plugin, cfg, entity, target);
                    if (used) {
                        state.nextAnchorMillis = now + cfg.anchorCooldownTicks() * 50L;
                    }
                }
            }
        }

        if (distance > engageRange) {
            walkToward(entity, target, 1.0);
            return;
        }

        // Strafe direction toggle
        if (now >= state.nextStrafeSwitchMillis) {
            state.strafeDir *= -1;
            state.nextStrafeSwitchMillis = now + randomTicks(cfg.strafeSwitchMinTicks(), cfg.strafeSwitchMaxTicks());
        }

        // W-tap window toggle
        if (state.wtapping) {
            if (now >= state.wtapUntilMillis) {
                state.wtapping = false;
                state.nextWtapMillis = now + randomTicks(cfg.wtapMinTicks(), cfg.wtapMaxTicks());
            }
        } else if (now >= state.nextWtapMillis) {
            state.wtapping = true;
            state.wtapUntilMillis = now + cfg.wtapDurationTicks() * 50L;
        }

        Location desired = computeDesiredPoint(entity, target, reach, state);
        if (desired != null) {
            double speed = state.wtapping ? 1.35 : 1.15;
            moveToward(entity, desired, speed);
        }
    }

    /**
     * Picks the next attack cooldown based on where we are in the current
     * combo: mid-combo hits are fast (chain multiplier), the hit that
     * finishes a combo gets a longer recovery pause and a fresh randomized
     * combo length is picked for next time.
     */
    private long comboAdjustedCooldownMillis(BotCombatState state, int baseCooldownTicks) {
        int hits = state.comboHits + 1;
        if (state.comboTarget <= 0) {
            state.comboTarget = ThreadLocalRandom.current().nextInt(cfg.comboMinHits(), cfg.comboMaxHits() + 1);
        }

        double multiplier;
        if (hits >= state.comboTarget) {
            multiplier = cfg.comboRecoveryMultiplier();
            state.comboHits = 0;
            state.comboTarget = ThreadLocalRandom.current().nextInt(cfg.comboMinHits(), cfg.comboMaxHits() + 1);
        } else {
            multiplier = cfg.comboChainMultiplier();
            state.comboHits = hits;
        }

        double fraction = cfg.hitJitterFraction();
        double jitter = fraction > 0.0001 ? 1.0 + ThreadLocalRandom.current().nextDouble(-fraction, fraction) : 1.0;
        long ticks = Math.max(1, Math.round(baseCooldownTicks * multiplier * jitter));
        return ticks * 50L;
    }

    private boolean crystalAllowedFor(PracticeBot bot) {
        var def = botDefManager.get(bot.getName());
        return def == null || def.isCrystalPvpEnabled();
    }

    private boolean anchorAllowedFor(PracticeBot bot) {
        var def = botDefManager.get(bot.getName());
        return def == null || def.isAnchorPvpEnabled();
    }

    private Player acquireTarget(LivingEntity entity) {
        Collection<Player> nearby = entity.getLocation().getNearbyPlayers(cfg.engageRange());
        Player closest = null;
        double best = Double.MAX_VALUE;
        for (Player p : nearby) {
            if (p.getGameMode() == GameMode.SPECTATOR || p.getGameMode() == GameMode.CREATIVE) continue;
            double d = p.getLocation().distanceSquared(entity.getLocation());
            if (d < best) {
                best = d;
                closest = p;
            }
        }
        return closest;
    }

    /** Manual movement toward an arbitrary point, since Mannequin has no Pathfinder. */
    private void moveToward(LivingEntity entity, Location target, double speedMultiplier) {
        Location current = entity.getLocation();
        if (current.getWorld() == null || !current.getWorld().equals(target.getWorld())) return;

        Vector toTarget = target.toVector().subtract(current.toVector());
        toTarget.setY(0);
        double dist = toTarget.length();
        if (dist < 0.05) return;

        double stepDistance = Math.min(dist, 0.28 * speedMultiplier);
        Vector step = toTarget.normalize().multiply(stepDistance);

        Location next = current.clone().add(step);
        next.setY(groundedY(next));

        float yaw = yawTowards(current, target);
        next.setYaw(yaw);
        next.setPitch(0f);

        entity.teleport(next);
    }

    private void walkToward(LivingEntity entity, Player target, double speedMultiplier) {
        moveToward(entity, target.getLocation(), speedMultiplier);
    }

    /** Simple ground snap: don't let manual movement float or clip into the floor. */
    private double groundedY(Location loc) {
        if (loc.getWorld() == null) return loc.getY();
        org.bukkit.block.Block below = loc.getWorld().getBlockAt(loc.getBlockX(), loc.getBlockY() - 1, loc.getBlockZ());
        org.bukkit.block.Block feet = loc.getWorld().getBlockAt(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
        if (feet.getType().isSolid()) {
            // stepped into a block - try one block up (basic step-up)
            return loc.getBlockY() + 1;
        }
        if (!below.getType().isSolid()) {
            // no ground under the new spot - let gravity handle it, don't force position
            return loc.getY();
        }
        return loc.getBlockY();
    }

    private float yawTowards(Location from, Location to) {
        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        return (float) (Math.toDegrees(Math.atan2(-dx, dz)));
    }

    private Location computeDesiredPoint(LivingEntity entity, Player target, double reach, BotCombatState state) {
        Location botLoc = entity.getLocation();
        Location targetLoc = target.getLocation();
        if (botLoc.getWorld() == null || !botLoc.getWorld().equals(targetLoc.getWorld())) return null;

        Vector dirToBot = botLoc.toVector().subtract(targetLoc.toVector());
        dirToBot.setY(0);
        if (dirToBot.lengthSquared() < 0.0001) {
            dirToBot = new Vector(1, 0, 0);
        } else {
            dirToBot.normalize();
        }

        Vector perpendicular = new Vector(-dirToBot.getZ(), 0, dirToBot.getX()).multiply(state.strafeDir);

        // Keep the orbit tight enough to stay within melee reach while we
        // nudge the bot sideways.
        double radius = state.wtapping ? reach * 0.9 : reach * 0.35;
        double strafeAmount = state.wtapping ? cfg.strafeDistance() * 0.25 : Math.min(cfg.strafeDistance(), reach * 0.35);

        Vector offset = dirToBot.clone().multiply(radius).add(perpendicular.multiply(strafeAmount));
        Location dest = targetLoc.clone().add(offset);
        dest.setY(botLoc.getY());
        return dest;
    }

    private long randomTicks(int minTicks, int maxTicks) {
        int lo = Math.min(minTicks, maxTicks);
        int hi = Math.max(minTicks, maxTicks);
        int ticks = hi <= lo ? lo : ThreadLocalRandom.current().nextInt(lo, hi + 1);
        return ticks * 50L;
    }
}
