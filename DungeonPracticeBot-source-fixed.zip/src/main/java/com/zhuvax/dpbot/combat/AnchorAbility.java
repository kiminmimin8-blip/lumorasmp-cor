package com.zhuvax.dpbot.combat;

import com.zhuvax.dpbot.config.ConfigManager;
import com.zhuvax.dpbot.util.SchedulerUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.type.RespawnAnchor;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Simulates "anchor PvP": a charged respawn anchor placed near the target,
 * then detonated shortly after - same idea as {@link CrystalAbility} but
 * with a respawn anchor instead of an end crystal, and a bigger blast.
 * <p>
 * We don't try to replicate the exact vanilla "explodes when used outside
 * the Nether" trigger (that requires a real player right-click + dimension
 * check) - it's simulated directly with a scheduled explosion instead, same
 * as the crystal ability, for reliability across versions.
 */
public final class AnchorAbility {

    private AnchorAbility() {
    }

    public static boolean tryPlaceAndDetonate(JavaPlugin plugin, ConfigManager cfg, LivingEntity bot, Player target) {
        Block base = findPlacementBlock(target);
        if (base == null) return false;

        BlockState originalState = base.getState();
        base.setType(Material.RESPAWN_ANCHOR, false);
        if (base.getBlockData() instanceof RespawnAnchor anchor) {
            anchor.setCharges(anchor.getMaximumCharges());
            base.setBlockData(anchor);
        }

        Location blastLoc = base.getLocation().add(0.5, 0.5, 0.5);
        if (blastLoc.getWorld() == null) {
            originalState.update(true, false);
            return false;
        }

        org.bukkit.inventory.EntityEquipment eq = bot.getEquipment();
        org.bukkit.inventory.ItemStack primaryWeapon = eq != null ? eq.getItemInMainHand().clone() : null;
        if (eq != null) {
            eq.setItemInMainHand(new org.bukkit.inventory.ItemStack(Material.RESPAWN_ANCHOR));
        }

        int delayTicks = ThreadLocalRandom.current()
                .nextInt(cfg.anchorDetonateDelayMinTicks(), Math.max(cfg.anchorDetonateDelayMinTicks() + 1, cfg.anchorDetonateDelayMaxTicks() + 1));

        SchedulerUtil.runAtLocationLater(plugin, blastLoc, delayTicks, () -> {
            if (base.getType() == Material.RESPAWN_ANCHOR) {
                base.setType(Material.AIR, false);
            }
            blastLoc.getWorld().createExplosion(blastLoc, cfg.anchorExplosionPower(), false, cfg.anchorBreakBlocks(), bot);

            if (eq != null && primaryWeapon != null && bot.isValid()) {
                eq.setItemInMainHand(primaryWeapon);
            }

            SchedulerUtil.runAtLocationLater(plugin, base.getLocation(), cfg.anchorRestoreBlockDelayTicks(),
                    () -> originalState.update(true, false));
        });

        return true;
    }

    private static Block findPlacementBlock(Player target) {
        Block feet = target.getLocation().getBlock();
        BlockFace[] faces = {BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};

        for (BlockFace face : faces) {
            Block candidate = feet.getRelative(face);
            if (isValidBase(candidate)) {
                return candidate;
            }
        }
        return isValidBase(feet) ? feet : null;
    }

    private static boolean isValidBase(Block block) {
        if (!block.getType().isAir()) return false;
        Block below = block.getRelative(BlockFace.DOWN);
        return below.getType().isSolid();
    }
}
