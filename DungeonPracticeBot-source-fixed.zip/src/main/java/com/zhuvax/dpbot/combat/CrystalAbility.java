package com.zhuvax.dpbot.combat;

import com.zhuvax.dpbot.config.ConfigManager;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Handles the "place obsidian, place crystal, detonate" cycle bots use to
 * do crystal PvP damage. Blocks are placed and later restored automatically
 * so it doesn't permanently grief the arena.
 */
public final class CrystalAbility {

    private CrystalAbility() {
    }

    public static boolean tryPlaceAndDetonate(JavaPlugin plugin, ConfigManager cfg, LivingEntity bot, Player target) {
        Block base = findPlacementBlock(target);
        if (base == null) return false;

        BlockState originalState = base.getState();
        base.setType(Material.OBSIDIAN, false);

        Location crystalLoc = base.getLocation().add(0.5, 1.0, 0.5);
        if (crystalLoc.getWorld() == null) {
            originalState.update(true, false);
            return false;
        }

        EnderCrystal crystal = (EnderCrystal) crystalLoc.getWorld().spawnEntity(crystalLoc, EntityType.END_CRYSTAL);
        crystal.setShowingBottom(false);

        org.bukkit.inventory.EntityEquipment eq = bot.getEquipment();
        org.bukkit.inventory.ItemStack primaryWeapon = eq != null ? eq.getItemInMainHand().clone() : null;
        if (eq != null) {
            eq.setItemInMainHand(new org.bukkit.inventory.ItemStack(Material.OBSIDIAN));
        }

        int delayTicks = ThreadLocalRandom.current()
                .nextInt(cfg.crystalDetonateDelayMinTicks(), Math.max(cfg.crystalDetonateDelayMinTicks() + 1, cfg.crystalDetonateDelayMaxTicks() + 1));

        com.zhuvax.dpbot.util.SchedulerUtil.runAtLocationLater(plugin, crystalLoc, delayTicks, () -> {
            if (crystal.isValid()) {
                crystal.remove();
            }
            crystalLoc.getWorld().createExplosion(crystalLoc, cfg.crystalExplosionPower(), false, cfg.crystalBreakBlocks(), bot);

            if (eq != null && primaryWeapon != null && bot.isValid()) {
                eq.setItemInMainHand(primaryWeapon);
            }

            com.zhuvax.dpbot.util.SchedulerUtil.runAtLocationLater(plugin, base.getLocation(), cfg.crystalRestoreBlockDelayTicks(),
                    () -> originalState.update(true, false));
        });

        return true;
    }

    /**
     * Looks for an air block at the target's feet level, adjacent to them,
     * that has solid ground underneath so obsidian placed there won't just
     * fall or float uselessly.
     */
    private static Block findPlacementBlock(Player target) {
        Block feet = target.getLocation().getBlock();
        BlockFace[] faces = {BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};

        for (BlockFace face : faces) {
            Block candidate = feet.getRelative(face);
            if (isValidCrystalBase(candidate)) {
                return candidate;
            }
        }
        // fall back to directly at their feet if all sides are blocked
        return isValidCrystalBase(feet) ? feet : null;
    }

    private static boolean isValidCrystalBase(Block block) {
        if (!block.getType().isAir()) return false;
        Block below = block.getRelative(BlockFace.DOWN);
        return below.getType().isSolid();
    }
}
