package com.zhuvax.dpbot.bot;

import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.EnumMap;
import java.util.Map;

public class Kit {

    private final String name;
    private final Map<EquipmentSlot, ItemStack> gear = new EnumMap<>(EquipmentSlot.class);

    public Kit(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Map<EquipmentSlot, ItemStack> getGear() {
        return gear;
    }

    public ItemStack getGear(EquipmentSlot slot) {
        return gear.get(slot);
    }

    public void setGear(EquipmentSlot slot, ItemStack item) {
        if (item == null || item.getType().isAir()) {
            gear.remove(slot);
        } else {
            gear.put(slot, item.clone());
        }
    }

    public Kit copy() {
        Kit clone = new Kit(name);
        for (Map.Entry<EquipmentSlot, ItemStack> e : gear.entrySet()) {
            clone.gear.put(e.getKey(), e.getValue().clone());
        }
        return clone;
    }
}
