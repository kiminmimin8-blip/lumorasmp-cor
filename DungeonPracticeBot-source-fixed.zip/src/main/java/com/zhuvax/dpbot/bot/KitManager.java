package com.zhuvax.dpbot.bot;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class KitManager {

    private final JavaPlugin plugin;
    private File file;
    private FileConfiguration yaml;

    private final Map<String, Kit> kits = new LinkedHashMap<>();

    public KitManager(JavaPlugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        file = new File(plugin.getDataFolder(), "kits.yml");
        if (!file.exists()) {
            try {
                plugin.getDataFolder().mkdirs();
                file.createNewFile();
            } catch (java.io.IOException e) {
                plugin.getLogger().warning("Gagal bikin kits.yml: " + e.getMessage());
            }
        }
        yaml = YamlConfiguration.loadConfiguration(file);

        kits.clear();
        ConfigurationSection kitsSection = yaml.getConfigurationSection("kits");
        if (kitsSection != null) {
            for (String name : kitsSection.getKeys(false)) {
                Kit kit = new Kit(name);
                ConfigurationSection gearSection = kitsSection.getConfigurationSection(name + ".gear");
                if (gearSection != null) {
                    for (EquipmentSlot slot : EquipmentSlot.values()) {
                        if (gearSection.contains(slot.name())) {
                            ItemStack item = gearSection.getItemStack(slot.name());
                            if (item != null) kit.setGear(slot, item);
                        }
                    }
                }
                kits.put(name, kit);
            }
        }

        if (kits.isEmpty()) {
            kits.put("Default", new Kit("Default"));
            save();
        }
    }

    public void save() {
        for (Map.Entry<String, Kit> e : kits.entrySet()) {
            String base = "kits." + e.getKey() + ".gear";
            yaml.set("kits." + e.getKey(), null);
            for (Map.Entry<EquipmentSlot, ItemStack> g : e.getValue().getGear().entrySet()) {
                yaml.set(base + "." + g.getKey().name(), g.getValue());
            }
            if (e.getValue().getGear().isEmpty()) {
                yaml.set("kits." + e.getKey() + ".placeholder", true);
            }
        }
        try {
            yaml.save(file);
        } catch (java.io.IOException e) {
            plugin.getLogger().warning("Gagal nyimpen kits.yml: " + e.getMessage());
        }
    }

    public Kit getOrCreate(String name) {
        return kits.computeIfAbsent(name, Kit::new);
    }

    public Kit get(String name) {
        return kits.get(name);
    }

    public boolean exists(String name) {
        return kits.containsKey(name);
    }

    public boolean delete(String name) {
        if (name.equalsIgnoreCase("Default")) return false;
        boolean removed = kits.remove(name) != null;
        if (removed) {
            yaml.set("kits." + name, null);
            save();
        }
        return removed;
    }

    public Map<String, Kit> all() {
        return new TreeMap<>(kits);
    }
}
