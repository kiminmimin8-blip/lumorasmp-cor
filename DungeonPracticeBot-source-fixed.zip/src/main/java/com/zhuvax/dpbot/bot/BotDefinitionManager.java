package com.zhuvax.dpbot.bot;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * Registry of every named bot the server owner has created (max 30),
 * persisted to bots.yml. Each bot's full config lives in {@link BotDefinition}.
 */
public class BotDefinitionManager {

    public static final int MAX_BOTS = 50;

    private final JavaPlugin plugin;
    private File file;
    private FileConfiguration yaml;
    private final Map<String, BotDefinition> definitions = new LinkedHashMap<>();

    public BotDefinitionManager(JavaPlugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        file = new File(plugin.getDataFolder(), "bots.yml");
        if (!file.exists()) {
            try {
                plugin.getDataFolder().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("Gagal bikin bots.yml: " + e.getMessage());
            }
        }
        yaml = YamlConfiguration.loadConfiguration(file);

        definitions.clear();
        ConfigurationSection botsSection = yaml.getConfigurationSection("bots");
        if (botsSection == null) return;

        for (String name : botsSection.getKeys(false)) {
            ConfigurationSection s = botsSection.getConfigurationSection(name);
            if (s == null) continue;
            BotDefinition def = new BotDefinition(name);

            def.setDifficultyName(s.getString("difficulty", "MEDIUM"));
            def.setSkinName(s.getString("skin", null));
            def.setHealth(s.getDouble("health", 40.0));
            def.setKnockbackImmune(s.getBoolean("knockback-immune", false));
            def.setFireImmune(s.getBoolean("fire-immune", true));
            def.setCritChance(s.getDouble("crit-chance", 0.15));
            def.setTotemCount(s.getInt("totem-count", 0));
            def.setLeashRadius(s.getDouble("leash-radius", 250.0));
            def.setRespawnDelayTicks(s.getLong("respawn-delay-ticks", 600));
            def.setCrystalPvpEnabled(s.getBoolean("crystal-pvp-enabled", true));
            def.setAnchorPvpEnabled(s.getBoolean("anchor-pvp-enabled", true));

            if (s.contains("secondary-weapon")) {
                def.setSecondaryWeapon(s.getItemStack("secondary-weapon"));
            }

            ConfigurationSection gearSection = s.getConfigurationSection("gear");
            if (gearSection != null) {
                for (EquipmentSlot slot : EquipmentSlot.values()) {
                    if (gearSection.contains(slot.name())) {
                        ItemStack item = gearSection.getItemStack(slot.name());
                        if (item != null) def.setGear(slot, item);
                    }
                }
            }

            if (s.contains("spawn.world")) {
                World world = Bukkit.getWorld(s.getString("spawn.world"));
                if (world != null) {
                    def.setSpawnLocation(new Location(world,
                            s.getDouble("spawn.x"), s.getDouble("spawn.y"), s.getDouble("spawn.z"),
                            (float) s.getDouble("spawn.yaw", 0.0), 0f));
                }
            }

            definitions.put(name, def);
        }
    }

    public void save() {
        yaml.set("bots", null);
        for (Map.Entry<String, BotDefinition> e : definitions.entrySet()) {
            String base = "bots." + e.getKey();
            BotDefinition def = e.getValue();

            yaml.set(base + ".difficulty", def.getDifficultyName());
            yaml.set(base + ".skin", def.getSkinName());
            yaml.set(base + ".health", def.getHealth());
            yaml.set(base + ".knockback-immune", def.isKnockbackImmune());
            yaml.set(base + ".fire-immune", def.isFireImmune());
            yaml.set(base + ".crit-chance", def.getCritChance());
            yaml.set(base + ".totem-count", def.getTotemCount());
            yaml.set(base + ".leash-radius", def.getLeashRadius());
            yaml.set(base + ".respawn-delay-ticks", def.getRespawnDelayTicks());
            yaml.set(base + ".crystal-pvp-enabled", def.isCrystalPvpEnabled());
            yaml.set(base + ".anchor-pvp-enabled", def.isAnchorPvpEnabled());
            yaml.set(base + ".secondary-weapon", def.getSecondaryWeapon());

            for (Map.Entry<EquipmentSlot, ItemStack> g : def.getGear().entrySet()) {
                yaml.set(base + ".gear." + g.getKey().name(), g.getValue());
            }

            Location loc = def.getSpawnLocation();
            if (loc != null && loc.getWorld() != null) {
                yaml.set(base + ".spawn.world", loc.getWorld().getName());
                yaml.set(base + ".spawn.x", loc.getX());
                yaml.set(base + ".spawn.y", loc.getY());
                yaml.set(base + ".spawn.z", loc.getZ());
                yaml.set(base + ".spawn.yaw", (double) loc.getYaw());
            }
        }
        try {
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal nyimpen bots.yml: " + e.getMessage());
        }
    }

    public boolean exists(String name) {
        return definitions.containsKey(name);
    }

    public BotDefinition get(String name) {
        return definitions.get(name);
    }

    /** Returns the new definition, or null if the 30-bot cap is already hit. */
    public BotDefinition create(String name) {
        if (definitions.size() >= MAX_BOTS) return null;
        BotDefinition def = new BotDefinition(name);
        definitions.put(name, def);
        save();
        return def;
    }

    public boolean delete(String name) {
        boolean removed = definitions.remove(name) != null;
        if (removed) {
            yaml.set("bots." + name, null);
            save();
        }
        return removed;
    }

    /** Renames a bot definition in place, keeping every other setting. Fails if the new name is taken. */
    public boolean rename(String oldName, String newName) {
        if (!definitions.containsKey(oldName) || definitions.containsKey(newName)) return false;
        BotDefinition old = definitions.remove(oldName);
        BotDefinition renamed = new BotDefinition(newName);
        renamed.setDifficultyName(old.getDifficultyName());
        renamed.setSkinName(old.getSkinName());
        renamed.setHealth(old.getHealth());
        renamed.setKnockbackImmune(old.isKnockbackImmune());
        renamed.setFireImmune(old.isFireImmune());
        renamed.setCritChance(old.getCritChance());
        renamed.setTotemCount(old.getTotemCount());
        renamed.setLeashRadius(old.getLeashRadius());
        renamed.setRespawnDelayTicks(old.getRespawnDelayTicks());
        renamed.setCrystalPvpEnabled(old.isCrystalPvpEnabled());
        renamed.setAnchorPvpEnabled(old.isAnchorPvpEnabled());
        renamed.setSecondaryWeapon(old.getSecondaryWeapon());
        renamed.setSpawnLocation(old.getSpawnLocation());
        for (var e : old.getGear().entrySet()) {
            renamed.setGear(e.getKey(), e.getValue());
        }
        definitions.put(newName, renamed);
        yaml.set("bots." + oldName, null);
        save();
        return true;
    }

    public void markDirty(String name) {
        save();
    }

    public Map<String, BotDefinition> all() {
        return new TreeMap<>(definitions);
    }

    public int count() {
        return definitions.size();
    }
}
