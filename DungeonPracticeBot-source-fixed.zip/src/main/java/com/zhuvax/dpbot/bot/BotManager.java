package com.zhuvax.dpbot.bot;

import com.zhuvax.dpbot.combat.CombatController;
import com.zhuvax.dpbot.config.ConfigManager;
import com.zhuvax.dpbot.difficulty.Difficulty;
import com.zhuvax.dpbot.util.SchedulerUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;

/**
 * Central registry: every bot is just a named bot now (no more separate
 * "dungeon bot" vs "normal bot" split). Up to {@link BotDefinitionManager#MAX_BOTS}
 * can be created; each one carries its own full BotDefinition.
 */
public class BotManager {

    private final JavaPlugin plugin;
    private final ConfigManager cfg;
    public final NamespacedKey KEY_NAME;
    public final NamespacedKey KEY_EGG;

    private final BotDefinitionManager botDefManager;
    private final KitManager kitManager;
    private final CombatController combatController;

    private final Map<String, PracticeBot> liveBots = new HashMap<>();
    private final Map<String, Integer> totemCharges = new HashMap<>();
    private final Map<String, SchedulerUtil.TaskHandle> leashTasks = new HashMap<>();

    public BotManager(JavaPlugin plugin, ConfigManager cfg) {
        this.plugin = plugin;
        this.cfg = cfg;
        this.KEY_NAME = new NamespacedKey(plugin, "dpbot_name");
        this.KEY_EGG = new NamespacedKey(plugin, "dpbot_egg");
        this.botDefManager = new BotDefinitionManager(plugin);
        this.kitManager = new KitManager(plugin);
        this.combatController = new CombatController(plugin, cfg, botDefManager);
    }

    public BotDefinitionManager getBotDefManager() {
        return botDefManager;
    }

    public KitManager getKitManager() {
        return kitManager;
    }

    public CombatController getCombatController() {
        return combatController;
    }

    // ---------------- Creation / deletion ----------------

    public BotDefinition createBot(String name) {
        return botDefManager.create(name);
    }

    public boolean deleteBot(String name) {
        removeEntity(name);
        return botDefManager.delete(name);
    }

    // ---------------- Live state ----------------

    public boolean isAlive(String name) {
        PracticeBot bot = liveBots.get(name);
        return bot != null && bot.isAlive();
    }

    public PracticeBot getLive(String name) {
        return liveBots.get(name);
    }

    public Map<String, PracticeBot> allLive() {
        return liveBots;
    }

    public String nameOf(Entity entity) {
        return entity.getPersistentDataContainer().get(KEY_NAME, PersistentDataType.STRING);
    }

    public ItemStack createEggItem(String botName) {
        ItemStack egg = new ItemStack(Material.ZOMBIE_SPAWN_EGG);
        var meta = egg.getItemMeta();
        meta.setDisplayName("§aBot Egg: §e" + botName);
        meta.setLore(java.util.List.of(
                "§7Klik kanan ke tanah buat spawn bot ini",
                "§7(gak butuh permission command)"
        ));
        meta.getPersistentDataContainer().set(KEY_EGG, PersistentDataType.STRING, botName);
        egg.setItemMeta(meta);
        return egg;
    }

    public String eggBotName(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(KEY_EGG, PersistentDataType.STRING);
    }

    public int getTotemCharges(String name) {
        return totemCharges.getOrDefault(name, 0);
    }

    public boolean consumeTotemCharge(String name) {
        int remaining = getTotemCharges(name);
        if (remaining <= 0) return false;
        totemCharges.put(name, remaining - 1);
        return true;
    }

    // ---------------- Spawn / despawn ----------------

    public void spawnEntity(String name, Location at) {
        BotDefinition def = botDefManager.get(name);
        if (def == null) return;

        SchedulerUtil.runAtLocation(plugin, at, () -> {
            LivingEntity entity = (LivingEntity) at.getWorld().spawnEntity(at, EntityType.MANNEQUIN);
            Difficulty difficulty = Difficulty.byName(def.getDifficultyName());

            entity.getPersistentDataContainer().set(KEY_NAME, PersistentDataType.STRING, name);

            if (entity.getAttribute(Attribute.MAX_HEALTH) != null) {
                entity.getAttribute(Attribute.MAX_HEALTH).setBaseValue(def.getHealth());
                entity.setHealth(def.getHealth());
            }
            if (entity.getAttribute(Attribute.KNOCKBACK_RESISTANCE) != null) {
                entity.getAttribute(Attribute.KNOCKBACK_RESISTANCE).setBaseValue(def.isKnockbackImmune() ? 1.0 : 0.0);
            }

            entity.setCustomName(cfg.nameFormat().replace("{name}", name).replace('&', '§'));
            entity.setCustomNameVisible(true);
            entity.setRemoveWhenFarAway(false);
            entity.setPersistent(true);
            entity.setFireTicks(0);
            entity.setFallDistance(0f);

            if (entity instanceof org.bukkit.entity.Mannequin mannequin) {
                mannequin.setImmovable(false);
                if (def.getSkinName() != null) {
                    try {
                        com.destroystokyo.paper.profile.PlayerProfile playerProfile = plugin.getServer().createProfile(def.getSkinName());
                        mannequin.setProfile(io.papermc.paper.datacomponent.item.ResolvableProfile.resolvableProfile(playerProfile));
                    } catch (Exception e) {
                        plugin.getLogger().warning("Gagal set skin buat bot " + name + ": " + e.getMessage());
                    }
                }
            }

            EntityEquipment eq = entity.getEquipment();
            if (eq != null) {
                for (EquipmentSlot slot : EquipmentSlot.values()) {
                    ItemStack gearItem = def.getGear(slot);
                    if (gearItem != null) {
                        eq.setItem(slot, gearItem);
                        eq.setDropChance(slot, 0f);
                    }
                }
                if (eq.getItemInMainHand().getType().isAir()) {
                    eq.setItemInMainHand(new ItemStack(Material.IRON_SWORD));
                    eq.setItemInMainHandDropChance(0f);
                }
                if (eq.getItemInOffHand().getType().isAir()) {
                    boolean cpvpMode = def.isCrystalPvpEnabled() && def.isAnchorPvpEnabled();
                    if (def.getTotemCount() > 0) {
                        ItemStack totemStack = new ItemStack(Material.TOTEM_OF_UNDYING);
                        totemStack.setAmount(Math.min(64, def.getTotemCount()));
                        eq.setItemInOffHand(totemStack);
                    } else if (cpvpMode) {
                        eq.setItemInOffHand(new ItemStack(Material.END_CRYSTAL));
                    } else {
                        eq.setItemInOffHand(new ItemStack(Material.SHIELD));
                    }
                    eq.setItemInOffHandDropChance(0f);
                }
            }

            totemCharges.put(name, def.getTotemCount());

            PracticeBot bot = new PracticeBot(entity, name, difficulty);
            liveBots.put(name, bot);
            combatController.attach(bot);

            SchedulerUtil.TaskHandle oldLeash = leashTasks.remove(name);
            if (oldLeash != null) oldLeash.cancel();

            Location home = def.getSpawnLocation();
            if (home != null) {
                SchedulerUtil.TaskHandle handle = SchedulerUtil.runOnEntityRepeating(plugin, entity, 40L, 40L, () -> {
                    PracticeBot live = liveBots.get(name);
                    if (live == null || !live.isAlive()) return;
                    LivingEntity e = live.getEntity();
                    if (!e.getWorld().equals(home.getWorld())) return;
                    BotDefinition liveDef = botDefManager.get(name);
                    double radius = liveDef != null ? liveDef.getLeashRadius() : 250.0;
                    if (e.getLocation().distance(home) > radius) {
                        e.teleport(home);
                    }
                });
                leashTasks.put(name, handle);
            }
        });
    }

    public void removeEntity(String name) {
        SchedulerUtil.TaskHandle leash = leashTasks.remove(name);
        if (leash != null) leash.cancel();

        PracticeBot bot = liveBots.remove(name);
        if (bot != null) {
            combatController.detach(bot.getEntity().getUniqueId());
            if (bot.isAlive()) {
                SchedulerUtil.consumeOnEntity(plugin, bot.getEntity(), e -> e.remove());
            }
        }
    }

    public void clearDead(String name) {
        SchedulerUtil.TaskHandle leash = leashTasks.remove(name);
        if (leash != null) leash.cancel();
        PracticeBot bot = liveBots.remove(name);
        if (bot != null) {
            combatController.detach(bot.getEntity().getUniqueId());
        }
    }

    // ---------------- Kits ----------------

    public void applyGearSlotLive(String name, EquipmentSlot slot, ItemStack item) {
        PracticeBot live = liveBots.get(name);
        if (live == null || !live.isAlive()) return;
        SchedulerUtil.consumeOnEntity(plugin, live.getEntity(), e -> {
            EntityEquipment eq = ((LivingEntity) e).getEquipment();
            if (eq == null) return;
            eq.setItem(slot, item);
            eq.setDropChance(slot, 0f);
        });
    }

    public boolean renameBot(String oldName, String newName) {
        boolean wasAlive = isAlive(oldName);
        Location loc = wasAlive ? liveBots.get(oldName).getEntity().getLocation() : null;

        if (wasAlive) {
            removeEntity(oldName);
        }
        boolean renamed = botDefManager.rename(oldName, newName);
        if (renamed && wasAlive && loc != null) {
            spawnEntity(newName, loc);
        }
        return renamed;
    }

    public boolean applyKit(String botName, String kitName) {
        BotDefinition def = botDefManager.get(botName);
        Kit kit = kitManager.get(kitName);
        if (def == null || kit == null) return false;

        for (EquipmentSlot slot : EquipmentSlot.values()) {
            def.setGear(slot, kit.getGear(slot));
        }
        botDefManager.save();

        PracticeBot live = liveBots.get(botName);
        if (live != null && live.isAlive()) {
            SchedulerUtil.consumeOnEntity(plugin, live.getEntity(), e -> {
                EntityEquipment eq = ((LivingEntity) e).getEquipment();
                if (eq == null) return;
                for (EquipmentSlot slot : EquipmentSlot.values()) {
                    eq.setItem(slot, kit.getGear(slot));
                    eq.setDropChance(slot, 0f);
                }
                if (eq.getItemInMainHand().getType().isAir()) {
                    eq.setItemInMainHand(new ItemStack(Material.IRON_SWORD));
                }
                if (eq.getItemInOffHand().getType().isAir()) {
                    eq.setItemInOffHand(new ItemStack(Material.SHIELD));
                }
            });
        }
        return true;
    }

    public void removeAll() {
        for (String name : new java.util.ArrayList<>(liveBots.keySet())) {
            removeEntity(name);
        }
    }
}
