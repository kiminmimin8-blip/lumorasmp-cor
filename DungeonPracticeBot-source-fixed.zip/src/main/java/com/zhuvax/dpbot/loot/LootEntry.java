package com.zhuvax.dpbot.loot;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class LootEntry {

    private final Material material;
    private final int minAmount;
    private final int maxAmount;
    private final double chance;

    private static final Random RANDOM = new Random();

    public LootEntry(Material material, int minAmount, int maxAmount, double chance) {
        this.material = material;
        this.minAmount = minAmount;
        this.maxAmount = maxAmount;
        this.chance = chance;
    }

    /**
     * Rolls this entry independently. Returns an ItemStack if it hits, or null if it doesn't.
     */
    public ItemStack roll() {
        if (RANDOM.nextDouble() > chance) {
            return null;
        }
        int amount = minAmount == maxAmount
                ? minAmount
                : minAmount + RANDOM.nextInt((maxAmount - minAmount) + 1);
        if (amount <= 0 || material == null) {
            return null;
        }
        return new ItemStack(material, amount);
    }

    public static List<ItemStack> rollAll(List<LootEntry> entries) {
        List<ItemStack> results = new ArrayList<>();
        for (LootEntry entry : entries) {
            ItemStack item = entry.roll();
            if (item != null) {
                results.add(item);
            }
        }
        return results;
    }
}
