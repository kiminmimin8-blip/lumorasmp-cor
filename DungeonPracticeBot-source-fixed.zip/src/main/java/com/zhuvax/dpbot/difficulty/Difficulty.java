package com.zhuvax.dpbot.difficulty;

public class Difficulty {

    public static final Difficulty EASY = new Difficulty("EASY", 20.0, 0.6, 3.0, 16, 0.05);
    public static final Difficulty MEDIUM = new Difficulty("MEDIUM", 20.0, 1.0, 3.5, 12, 0.10);
    public static final Difficulty HARD = new Difficulty("HARD", 26.0, 1.4, 4.0, 8, 0.20);

    private final String name;
    private final double health;
    private final double damageMultiplier;
    private final double reach;
    private final int attackSpeedTicks;
    private final double blockChance;

    public Difficulty(String name, double health, double damageMultiplier, double reach, int attackSpeedTicks, double blockChance) {
        this.name = name;
        this.health = health;
        this.damageMultiplier = damageMultiplier;
        this.reach = reach;
        this.attackSpeedTicks = attackSpeedTicks;
        this.blockChance = blockChance;
    }

    public static Difficulty byName(String name) {
        if (name == null) return MEDIUM;
        return switch (name.toUpperCase()) {
            case "EASY" -> EASY;
            case "HARD" -> HARD;
            default -> MEDIUM;
        };
    }

    public String getName() {
        return name;
    }

    public double getHealth() {
        return health;
    }

    public double getDamageMultiplier() {
        return damageMultiplier;
    }

    public double getReach() {
        return reach;
    }

    public int getAttackSpeedTicks() {
        return attackSpeedTicks;
    }

    public double getBlockChance() {
        return blockChance;
    }
}
