package com.zhuvax.dpbot.gui;

import com.zhuvax.dpbot.bot.BotDefinition;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/** Click an enchant to set/adjust its level on the gear item in the given bot+slot. */
public class EnchantPickerGui {

    public static final int SLOT_DONE = 49;

    public static Inventory open(Player player, BotDefinition def, EquipmentSlot slot) {
        GuiHolders.EnchantPickerHolder holder = new GuiHolders.EnchantPickerHolder();
        holder.botName = def.getName();
        holder.slot = slot;
        Inventory inv = Bukkit.createInventory(holder, 54, "§dEnchant: " + def.getName() + " (" + slot.name().toLowerCase() + ")");
        holder.setInventory(inv);
        render(inv, holder, def, slot);
        player.openInventory(inv);
        return inv;
    }

    public static void render(Inventory inv, GuiHolders.EnchantPickerHolder holder, BotDefinition def, EquipmentSlot slot) {
        inv.clear();
        holder.slotToEnchant.clear();
        ItemStack item = def.getGear(slot);

        int i = 0;
        for (Enchantment enchant : Registry.ENCHANTMENT) {
            if (i >= 45) break; // leave the bottom row for navigation
            int level = item != null ? item.getEnchantmentLevel(enchant) : 0;
            inv.setItem(i, enchantIcon(enchant, level));
            holder.slotToEnchant.put(i, enchant);
            i++;
        }

        ItemStack done = new ItemStack(Material.EMERALD_BLOCK);
        ItemMeta meta = done.getItemMeta();
        meta.setDisplayName("§aDone");
        meta.setLore(List.of());
        done.setItemMeta(meta);
        inv.setItem(SLOT_DONE, done);
    }

    private static ItemStack enchantIcon(Enchantment enchant, int level) {
        ItemStack stack = new ItemStack(level > 0 ? Material.ENCHANTED_BOOK : Material.BOOK);
        ItemMeta meta = stack.getItemMeta();
        String key = enchant.getKey().getKey().replace('_', ' ');
        meta.setDisplayName((level > 0 ? "§a" : "§7") + capitalize(key) + (level > 0 ? " §f" + level : ""));
        meta.setLore(List.of(
                "§7Level sekarang: §f" + level,
                "§7Left-click: +1  Right-click: -1",
                "§7Shift-click: ±10 (bebas lewat batas vanilla)"
        ));
        stack.setItemMeta(meta);
        return stack;
    }

    private static String capitalize(String s) {
        String[] parts = s.split(" ");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(' ');
        }
        return sb.toString().trim();
    }
}
