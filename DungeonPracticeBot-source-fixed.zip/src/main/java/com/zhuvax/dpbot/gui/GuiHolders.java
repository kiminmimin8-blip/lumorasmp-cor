package com.zhuvax.dpbot.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class GuiHolders {

    private GuiHolders() {
    }

    public static class BotSettingsHolder implements InventoryHolder {
        private Inventory inventory;
        public String botName;

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        public void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }
    }

    public static class BotGearHolder implements InventoryHolder {
        private Inventory inventory;
        public String botName;

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        public void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }
    }

    public static class EnchantPickerHolder implements InventoryHolder {
        private Inventory inventory;
        public String botName;
        public org.bukkit.inventory.EquipmentSlot slot;
        public final java.util.Map<Integer, org.bukkit.enchantments.Enchantment> slotToEnchant = new java.util.HashMap<>();

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        public void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }
    }

    public static class BotListHolder implements InventoryHolder {
        private Inventory inventory;
        public final java.util.Map<Integer, String> slotToBot = new java.util.HashMap<>();

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        public void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }
    }

    public static class KitListHolder implements InventoryHolder {
        private Inventory inventory;
        public final java.util.Map<Integer, String> slotToKit = new java.util.HashMap<>();

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        public void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }
    }

    public static class KitGearHolder implements InventoryHolder {
        private Inventory inventory;
        public String kitName;

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        public void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }
    }
}
