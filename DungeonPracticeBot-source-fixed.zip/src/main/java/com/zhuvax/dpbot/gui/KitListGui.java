package com.zhuvax.dpbot.gui;

import com.zhuvax.dpbot.bot.Kit;
import com.zhuvax.dpbot.bot.KitManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.Map;

public class KitListGui {

    public static Inventory open(Player player, KitManager kitManager) {
        GuiHolders.KitListHolder holder = new GuiHolders.KitListHolder();
        Map<String, Kit> kits = kitManager.all();
        int size = Math.max(9, ((kits.size() / 9) + 1) * 9);
        Inventory inv = Bukkit.createInventory(holder, size, "§6§lPilih / Edit Kit");
        holder.setInventory(inv);

        int slot = 0;
        for (Kit kit : kits.values()) {
            ItemStack icon = representativeIcon(kit);
            inv.setItem(slot, icon);
            holder.slotToKit.put(slot, kit.getName());
            slot++;
        }

        player.openInventory(inv);
        return inv;
    }

    private static ItemStack representativeIcon(Kit kit) {
        ItemStack mainhand = kit.getGear(EquipmentSlot.HAND);
        ItemStack base = (mainhand != null) ? mainhand.clone() : new ItemStack(Material.CHEST);
        ItemMeta meta = base.getItemMeta();
        meta.setDisplayName("§e" + kit.getName());
        meta.setLore(List.of(
                "§7Click: edit gear kit ini",
                "§7Pakai /bot kit apply <nama> <bot> buat apply"
        ));
        base.setItemMeta(meta);
        return base;
    }
}
