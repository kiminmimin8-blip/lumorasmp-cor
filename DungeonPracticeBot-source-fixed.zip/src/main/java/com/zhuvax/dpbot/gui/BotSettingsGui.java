package com.zhuvax.dpbot.gui;

import com.zhuvax.dpbot.bot.BotDefinition;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class BotSettingsGui {

    public static final int SLOT_HP = 10;
    public static final int SLOT_KNOCKBACK = 11;
    public static final int SLOT_FIRE = 12;
    public static final int SLOT_CRIT = 13;
    public static final int SLOT_TOTEM = 14;
    public static final int SLOT_LEASH = 15;
    public static final int SLOT_RESPAWN = 16;
    public static final int SLOT_CRYSTAL = 17;
    public static final int SLOT_ANCHOR = 19;
    public static final int SLOT_MODE = 20;
    public static final int SLOT_DIFFICULTY = 21;
    public static final int SLOT_GEAR = 22;
    public static final int SLOT_DELETE = 24;
    public static final int SLOT_BACK = 25;
    public static final int SLOT_CLOSE = 26;

    public static Inventory open(Player player, BotDefinition def) {
        GuiHolders.BotSettingsHolder holder = new GuiHolders.BotSettingsHolder();
        holder.botName = def.getName();
        Inventory inv = Bukkit.createInventory(holder, 27, "§4§lSetting Bot: " + def.getName());
        holder.setInventory(inv);
        render(inv, def);
        player.openInventory(inv);
        return inv;
    }

    public static void render(Inventory inv, BotDefinition s) {
        inv.clear();
        inv.setItem(SLOT_HP, item(Material.REDSTONE_BLOCK, "§cHealth: §f" + s.getHealth(),
                "§7Left-click: +2  Right-click: -2"));
        inv.setItem(SLOT_KNOCKBACK, item(s.isKnockbackImmune() ? Material.SHIELD : Material.FEATHER,
                "§bKnockback Immune: " + onOff(s.isKnockbackImmune()),
                "§7Click untuk toggle"));
        inv.setItem(SLOT_FIRE, item(s.isFireImmune() ? Material.FIRE_CHARGE : Material.WATER_BUCKET,
                "§6Fire Immune: " + onOff(s.isFireImmune()),
                "§7Click untuk toggle"));
        inv.setItem(SLOT_CRIT, item(Material.DIAMOND_SWORD, "§dCrit Chance: §f" + Math.round(s.getCritChance() * 100) + "%",
                "§7Left-click: +5%  Right-click: -5%"));
        inv.setItem(SLOT_TOTEM, item(Material.TOTEM_OF_UNDYING, "§eTotem Charges: §f" + s.getTotemCount() + " §7(max " + BotDefinition.MAX_TOTEM + ")",
                "§7Berapa kali bot bisa 'nyelametin diri' dari kematian",
                "§7Click: +10 (reset ke 10 kalau udah max)"));
        inv.setItem(SLOT_LEASH, item(Material.COMPASS, "§aLeash Radius: §f" + Math.round(s.getLeashRadius()) + " block",
                "§7Kalau bot lewat radius ini dari rumahnya, balik ke spawn",
                "§7Left-click: +10  Right-click: -10"));
        inv.setItem(SLOT_RESPAWN, item(Material.CLOCK, "§9Respawn Delay: §f" + (s.getRespawnDelayTicks() / 20) + "s",
                "§7Cuma jalan kalau bot ini punya fixed spawn (/bot setspawn)",
                "§7Left-click: +5s  Right-click: -5s"));
        inv.setItem(SLOT_CRYSTAL, item(s.isCrystalPvpEnabled() ? Material.END_CRYSTAL : Material.OBSIDIAN,
                "§dCrystal PvP: " + onOff(s.isCrystalPvpEnabled()),
                "§7Bot bisa naro obsidian+crystal & detonasi",
                "§7Click untuk toggle"));
        inv.setItem(SLOT_ANCHOR, item(s.isAnchorPvpEnabled() ? Material.RESPAWN_ANCHOR : Material.GLOWSTONE,
                "§6Anchor PvP: " + onOff(s.isAnchorPvpEnabled()),
                "§7Bot bisa naro respawn anchor & detonasi",
                "§7Click untuk toggle"));
        boolean cpvpMode = s.isCrystalPvpEnabled() && s.isAnchorPvpEnabled();
        inv.setItem(SLOT_MODE, item(cpvpMode ? Material.FIRE_CHARGE : Material.IRON_SWORD,
                "§cMode: " + (cpvpMode ? "§6CPvP" : "§bSPvP"),
                "§7SPvP = melee doang (crystal & anchor off)",
                "§7CPvP = melee + crystal & anchor on",
                "§7Click buat ganti mode cepat"));
        inv.setItem(SLOT_DIFFICULTY, item(Material.NETHER_STAR, "§eDifficulty: §f" + s.getDifficultyName(),
                "§7Ngaruh ke damage, attack speed, reach, block chance",
                "§7Click buat cycle Easy → Medium → Hard"));
        inv.setItem(SLOT_GEAR, item(Material.NETHERITE_CHESTPLATE, "§5Edit Gear",
                "§7Atur helmet/chest/legs/boots/hand/offhand",
                "§7+ secondary weapon buat combo-swap",
                "§7Klik kanan item buat pilih enchant & level"));
        inv.setItem(SLOT_DELETE, item(Material.BARRIER, "§4Delete Bot",
                "§7Shift-click buat beneran hapus bot ini",
                "§7(config-nya ikut kehapus, gak bisa di-undo)"));
        inv.setItem(SLOT_BACK, item(Material.ARROW, "§7Back ke daftar bot"));
        inv.setItem(SLOT_CLOSE, item(Material.BARRIER, "§cClose"));
    }

    private static String onOff(boolean b) {
        return b ? "§aON" : "§cOFF";
    }

    private static ItemStack item(Material mat, String name, String... lore) {
        ItemStack stack = new ItemStack(mat);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(name);
        if (lore.length > 0) {
            meta.setLore(List.of(lore));
        }
        stack.setItemMeta(meta);
        return stack;
    }
}
