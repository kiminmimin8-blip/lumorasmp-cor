package com.zhuvax.dpbot.gui;

import com.zhuvax.dpbot.bot.BotDefinition;
import com.zhuvax.dpbot.bot.BotDefinitionManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.Map;

/** Shown for /bot edit - every created bot, click one to open its settings. */
public class BotListGui {

    public static Inventory open(Player player, BotDefinitionManager botDefManager) {
        GuiHolders.BotListHolder holder = new GuiHolders.BotListHolder();
        Map<String, BotDefinition> defs = botDefManager.all();
        int size = Math.max(9, ((defs.size() / 9) + 1) * 9);
        Inventory inv = Bukkit.createInventory(holder, size,
                "§6§lBots (" + defs.size() + "/" + BotDefinitionManager.MAX_BOTS + ")");
        holder.setInventory(inv);

        int slot = 0;
        for (BotDefinition def : defs.values()) {
            inv.setItem(slot, icon(def));
            holder.slotToBot.put(slot, def.getName());
            slot++;
        }

        player.openInventory(inv);
        return inv;
    }

    private static ItemStack icon(BotDefinition def) {
        ItemStack mainhand = def.getGear(EquipmentSlot.HAND);
        ItemStack base = (mainhand != null) ? mainhand.clone() : new ItemStack(Material.ZOMBIE_HEAD);
        ItemMeta meta = base.getItemMeta();
        meta.setDisplayName("§e" + def.getName());
        meta.setLore(List.of(
                "§7HP: §f" + def.getHealth(),
                "§7Fixed spawn: " + (def.getSpawnLocation() != null ? "§aYes" : "§cNo (ad-hoc)"),
                "§7Click buat edit setting bot ini"
        ));
        base.setItemMeta(meta);
        return base;
    }
}
