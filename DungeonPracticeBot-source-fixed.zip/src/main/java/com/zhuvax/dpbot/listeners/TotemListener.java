package com.zhuvax.dpbot.listeners;

import com.zhuvax.dpbot.bot.BotManager;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class TotemListener implements Listener {

    private final BotManager botManager;

    public TotemListener(BotManager botManager) {
        this.botManager = botManager;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        String name = botManager.nameOf(event.getEntity());
        if (name == null) return;
        if (!(event.getEntity() instanceof LivingEntity entity)) return;

        double remainingHealth = entity.getHealth() - event.getFinalDamage();
        if (remainingHealth > 0) return; // not lethal, nothing to do

        if (!botManager.consumeTotemCharge(name)) return; // no charges left, let it die normally

        event.setCancelled(true);

        double maxHealth = entity.getAttribute(Attribute.MAX_HEALTH) != null
                ? entity.getAttribute(Attribute.MAX_HEALTH).getValue()
                : 20.0;
        entity.setHealth(Math.min(maxHealth, maxHealth * 0.2));
        entity.setFireTicks(0);
        entity.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1));
        entity.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 100, 1));
        entity.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, entity.getLocation().add(0, 1, 0), 30, 0.5, 0.5, 0.5, 0.5);
        entity.getWorld().playSound(entity.getLocation(), Sound.ITEM_TOTEM_USE, 1f, 1f);
        depleteOffhandTotem(entity);
    }

    private void depleteOffhandTotem(LivingEntity entity) {
        org.bukkit.inventory.EntityEquipment eq = entity.getEquipment();
        if (eq == null) return;
        org.bukkit.inventory.ItemStack offhand = eq.getItemInOffHand();
        if (offhand.getType() != org.bukkit.Material.TOTEM_OF_UNDYING) return;

        String name = botManager.nameOf(entity);
        int remainingCharges = name != null ? botManager.getTotemCharges(name) : 0;

        int remainingStack = offhand.getAmount() - 1;
        if (remainingStack <= 0) {
            eq.setItemInOffHand(remainingCharges > 0
                    ? offhandTotemStack(remainingCharges)
                    : new org.bukkit.inventory.ItemStack(org.bukkit.Material.SHIELD));
        } else {
            offhand.setAmount(remainingStack);
            eq.setItemInOffHand(offhand);
        }
    }

    private org.bukkit.inventory.ItemStack offhandTotemStack(int amount) {
        org.bukkit.inventory.ItemStack stack = new org.bukkit.inventory.ItemStack(org.bukkit.Material.TOTEM_OF_UNDYING);
        stack.setAmount(Math.min(64, amount));
        return stack;
    }
}
