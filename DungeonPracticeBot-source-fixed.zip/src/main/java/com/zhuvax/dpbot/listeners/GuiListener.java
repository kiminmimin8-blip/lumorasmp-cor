package com.zhuvax.dpbot.listeners;

import com.zhuvax.dpbot.bot.BotDefinition;
import com.zhuvax.dpbot.bot.BotManager;
import com.zhuvax.dpbot.config.ConfigManager;
import com.zhuvax.dpbot.gui.BotGearGui;
import com.zhuvax.dpbot.gui.BotListGui;
import com.zhuvax.dpbot.gui.BotSettingsGui;
import com.zhuvax.dpbot.gui.EnchantPickerGui;
import com.zhuvax.dpbot.gui.GuiHolders;
import com.zhuvax.dpbot.gui.KitGearGui;
import com.zhuvax.dpbot.gui.KitListGui;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public class GuiListener implements Listener {

    private final ConfigManager cfg;
    private final BotManager botManager;

    public GuiListener(ConfigManager cfg, BotManager botManager) {
        this.cfg = cfg;
        this.botManager = botManager;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getInventory().getHolder() instanceof GuiHolders.BotSettingsHolder holder) {
            handleSettingsClick(event, holder);
        } else if (event.getInventory().getHolder() instanceof GuiHolders.BotGearHolder holder) {
            handleGearClick(event, holder);
        } else if (event.getInventory().getHolder() instanceof GuiHolders.BotListHolder holder) {
            handleBotListClick(event, holder);
        } else if (event.getInventory().getHolder() instanceof GuiHolders.KitListHolder holder) {
            handleKitListClick(event, holder);
        } else if (event.getInventory().getHolder() instanceof GuiHolders.KitGearHolder holder) {
            handleKitGearClick(event, holder);
        } else if (event.getInventory().getHolder() instanceof GuiHolders.EnchantPickerHolder holder) {
            handleEnchantPickerClick(event, holder);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof GuiHolders.BotSettingsHolder) {
            event.setCancelled(true);
            return;
        }
        if (event.getInventory().getHolder() instanceof GuiHolders.BotGearHolder) {
            for (int slot : event.getRawSlots()) {
                if (slot < event.getInventory().getSize() && !BotGearGui.EDITABLE_SLOTS.containsKey(slot)
                        && slot != BotGearGui.SLOT_SECONDARY_WEAPON) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
        if (event.getInventory().getHolder() instanceof GuiHolders.KitGearHolder) {
            for (int slot : event.getRawSlots()) {
                if (slot < event.getInventory().getSize() && !KitGearGui.EDITABLE_SLOTS.containsKey(slot)) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
        if (event.getInventory().getHolder() instanceof GuiHolders.KitListHolder
                || event.getInventory().getHolder() instanceof GuiHolders.BotListHolder
                || event.getInventory().getHolder() instanceof GuiHolders.EnchantPickerHolder) {
            event.setCancelled(true);
        }
    }

    // ---------------- Bot settings ----------------

    private void handleSettingsClick(InventoryClickEvent event, GuiHolders.BotSettingsHolder holder) {
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getView().getTopInventory())) {
            return;
        }

        BotDefinition def = botManager.getBotDefManager().get(holder.botName);
        if (def == null) return;

        boolean right = event.getClick() == ClickType.RIGHT || event.getClick() == ClickType.SHIFT_RIGHT;

        switch (event.getSlot()) {
            case BotSettingsGui.SLOT_HP -> def.setHealth(def.getHealth() + (right ? -2 : 2));
            case BotSettingsGui.SLOT_KNOCKBACK -> def.setKnockbackImmune(!def.isKnockbackImmune());
            case BotSettingsGui.SLOT_FIRE -> def.setFireImmune(!def.isFireImmune());
            case BotSettingsGui.SLOT_CRIT -> def.setCritChance(def.getCritChance() + (right ? -0.05 : 0.05));
            case BotSettingsGui.SLOT_TOTEM -> def.cycleTotemCount();
            case BotSettingsGui.SLOT_LEASH -> def.setLeashRadius(def.getLeashRadius() + (right ? -10 : 10));
            case BotSettingsGui.SLOT_RESPAWN -> def.setRespawnDelayTicks(def.getRespawnDelayTicks() + (right ? -100 : 100));
            case BotSettingsGui.SLOT_CRYSTAL -> def.setCrystalPvpEnabled(!def.isCrystalPvpEnabled());
            case BotSettingsGui.SLOT_ANCHOR -> def.setAnchorPvpEnabled(!def.isAnchorPvpEnabled());
            case BotSettingsGui.SLOT_MODE -> {
                boolean nowCpvp = def.isCrystalPvpEnabled() && def.isAnchorPvpEnabled();
                boolean toCpvp = !nowCpvp;
                def.setCrystalPvpEnabled(toCpvp);
                def.setAnchorPvpEnabled(toCpvp);
            }
            case BotSettingsGui.SLOT_DIFFICULTY -> {
                String next = switch (def.getDifficultyName()) {
                    case "EASY" -> "MEDIUM";
                    case "MEDIUM" -> "HARD";
                    default -> "EASY";
                };
                def.setDifficultyName(next);
            }
            case BotSettingsGui.SLOT_DELETE -> {
                boolean shift = event.getClick() == ClickType.SHIFT_LEFT || event.getClick() == ClickType.SHIFT_RIGHT;
                if (!shift) {
                    player.sendMessage("§cShift-click item ini buat beneran hapus bot §e" + holder.botName + "§c.");
                    return;
                }
                botManager.deleteBot(holder.botName);
                player.sendMessage("§aBot §e" + holder.botName + " §adihapus.");
                BotListGui.open(player, botManager.getBotDefManager());
                return;
            }
            case BotSettingsGui.SLOT_GEAR -> {
                BotGearGui.open(player, def);
                return;
            }
            case BotSettingsGui.SLOT_BACK -> {
                BotListGui.open(player, botManager.getBotDefManager());
                return;
            }
            case BotSettingsGui.SLOT_CLOSE -> {
                player.closeInventory();
                return;
            }
            default -> {
                return;
            }
        }

        botManager.getBotDefManager().save();
        BotSettingsGui.render(event.getInventory(), def);
    }

    private void handleGearClick(InventoryClickEvent event, GuiHolders.BotGearHolder holder) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        boolean clickedTop = event.getClickedInventory() != null
                && event.getClickedInventory().equals(event.getView().getTopInventory());
        if (!clickedTop) return;

        int slot = event.getSlot();
        boolean editable = BotGearGui.EDITABLE_SLOTS.containsKey(slot) || slot == BotGearGui.SLOT_SECONDARY_WEAPON;
        boolean isSave = slot == BotGearGui.SLOT_SAVE;
        boolean isBack = slot == BotGearGui.SLOT_BACK;

        if (!editable && !isSave && !isBack) {
            event.setCancelled(true);
            return;
        }

        if (editable && event.getClick() == ClickType.RIGHT && event.getCurrentItem() != null
                && !event.getCurrentItem().getType().isAir() && slot != BotGearGui.SLOT_SECONDARY_WEAPON) {
            event.setCancelled(true);
            BotDefinition def = botManager.getBotDefManager().get(holder.botName);
            var eqSlot = BotGearGui.EDITABLE_SLOTS.get(slot);
            if (def != null && eqSlot != null) {
                def.setGear(eqSlot, event.getCurrentItem());
                botManager.getBotDefManager().save();
                EnchantPickerGui.open(player, def, eqSlot);
            }
            return;
        }

        if (isSave) {
            event.setCancelled(true);
            BotDefinition def = botManager.getBotDefManager().get(holder.botName);
            if (def != null) {
                BotGearGui.saveFrom(event.getInventory(), def);
                botManager.getBotDefManager().save();
                player.sendMessage("§aGear bot §e" + holder.botName + " §adisimpen.");
                BotSettingsGui.open(player, def);
            }
            return;
        }
        if (isBack) {
            event.setCancelled(true);
            BotDefinition def = botManager.getBotDefManager().get(holder.botName);
            if (def != null) {
                BotSettingsGui.open(player, def);
            }
        }
    }

    // ---------------- Bot list (/bot edit) ----------------

    private void handleBotListClick(InventoryClickEvent event, GuiHolders.BotListHolder holder) {
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getView().getTopInventory())) {
            return;
        }
        String botName = holder.slotToBot.get(event.getSlot());
        if (botName == null) return;
        BotDefinition def = botManager.getBotDefManager().get(botName);
        if (def == null) return;
        BotSettingsGui.open(player, def);
    }

    // ---------------- Kits ----------------

    private void handleKitListClick(InventoryClickEvent event, GuiHolders.KitListHolder holder) {
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getView().getTopInventory())) {
            return;
        }

        String kitName = holder.slotToKit.get(event.getSlot());
        if (kitName == null) return;

        if (!player.hasPermission("dpbot.kit.manage")) {
            player.sendMessage(cfg.msg("no-permission"));
            return;
        }
        KitGearGui.open(player, botManager.getKitManager(), kitName);
    }

    private void handleKitGearClick(InventoryClickEvent event, GuiHolders.KitGearHolder holder) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        boolean clickedTop = event.getClickedInventory() != null
                && event.getClickedInventory().equals(event.getView().getTopInventory());
        if (!clickedTop) return;

        int slot = event.getSlot();
        boolean editable = KitGearGui.EDITABLE_SLOTS.containsKey(slot);
        boolean isSave = slot == KitGearGui.SLOT_SAVE;
        boolean isBack = slot == KitGearGui.SLOT_BACK;

        if (!editable && !isSave && !isBack) {
            event.setCancelled(true);
            return;
        }
        if (isSave) {
            event.setCancelled(true);
            KitGearGui.saveFrom(event.getInventory(), botManager.getKitManager(), holder.kitName);
            player.sendMessage("§aKit §e" + holder.kitName + " §adisimpen.");
            KitListGui.open(player, botManager.getKitManager());
            return;
        }
        if (isBack) {
            event.setCancelled(true);
            KitListGui.open(player, botManager.getKitManager());
        }
    }

    // ---------------- Enchant picker ----------------

    private void handleEnchantPickerClick(InventoryClickEvent event, GuiHolders.EnchantPickerHolder holder) {
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getView().getTopInventory())) {
            return;
        }

        BotDefinition def = botManager.getBotDefManager().get(holder.botName);
        if (def == null) return;

        if (event.getSlot() == EnchantPickerGui.SLOT_DONE) {
            BotGearGui.open(player, def);
            return;
        }

        var enchant = holder.slotToEnchant.get(event.getSlot());
        if (enchant == null) return;

        var item = def.getGear(holder.slot);
        if (item == null) return;

        boolean right = event.getClick() == ClickType.RIGHT || event.getClick() == ClickType.SHIFT_RIGHT;
        boolean shift = event.getClick() == ClickType.SHIFT_LEFT || event.getClick() == ClickType.SHIFT_RIGHT;
        int step = shift ? 10 : 1;
        int delta = right ? -step : step;

        int currentLevel = item.getEnchantmentLevel(enchant);
        int newLevel = Math.max(0, Math.min(255, currentLevel + delta));

        if (newLevel <= 0) {
            item.removeEnchantment(enchant);
        } else {
            item.addUnsafeEnchantment(enchant, newLevel);
        }
        def.setGear(holder.slot, item);
        botManager.getBotDefManager().save();
        botManager.applyGearSlotLive(holder.botName, holder.slot, item);

        EnchantPickerGui.render(event.getInventory(), holder, def, holder.slot);
    }
}
