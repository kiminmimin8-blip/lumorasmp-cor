package com.zhuvax.dpbot.listeners;

import com.zhuvax.dpbot.bot.BotDefinition;
import com.zhuvax.dpbot.bot.BotManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustEvent;

public class FireImmuneListener implements Listener {

    private final BotManager botManager;

    public FireImmuneListener(BotManager botManager) {
        this.botManager = botManager;
    }

    @EventHandler
    public void onCombust(EntityCombustEvent event) {
        String name = botManager.nameOf(event.getEntity());
        if (name == null) return;

        BotDefinition def = botManager.getBotDefManager().get(name);
        boolean immune = def == null || def.isFireImmune();
        if (immune) {
            event.setCancelled(true);
            event.getEntity().setFireTicks(0);
        }
    }
}
