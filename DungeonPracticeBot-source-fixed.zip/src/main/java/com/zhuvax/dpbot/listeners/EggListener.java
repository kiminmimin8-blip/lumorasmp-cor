package com.zhuvax.dpbot.listeners;

import com.zhuvax.dpbot.bot.BotManager;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/** Lets anyone holding a bot egg (given by an admin via /bot egg) spawn that bot, no command permission needed. */
public class EggListener implements Listener {

    private final BotManager botManager;

    public EggListener(BotManager botManager) {
        this.botManager = botManager;
    }

    @EventHandler
    public void onUseEgg(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK && event.getAction() != Action.RIGHT_CLICK_AIR) return;

        ItemStack item = event.getItem();
        String botName = botManager.eggBotName(item);
        if (botName == null) return;

        event.setCancelled(true);
        Player player = event.getPlayer();

        if (!botManager.getBotDefManager().exists(botName)) {
            player.sendMessage("§cBot §e" + botName + " §cudah gak ada lagi.");
            return;
        }
        if (botManager.isAlive(botName)) {
            player.sendMessage("§cBot §e" + botName + " §csudah hidup di suatu tempat.");
            return;
        }

        Location spawnAt = event.getClickedBlock() != null
                ? event.getClickedBlock().getLocation().add(0.5, 1.0, 0.5)
                : player.getLocation();

        botManager.spawnEntity(botName, spawnAt);
        player.sendMessage("§aBot §e" + botName + " §adi-spawn!");

        if (player.getGameMode() != GameMode.CREATIVE) {
            item.setAmount(item.getAmount() - 1);
        }
    }
}
