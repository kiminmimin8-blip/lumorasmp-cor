package com.zhuvax.dpbot.listeners;

import com.zhuvax.dpbot.bot.BotDefinition;
import com.zhuvax.dpbot.bot.BotManager;
import com.zhuvax.dpbot.config.ConfigManager;
import com.zhuvax.dpbot.loot.LootEntry;
import com.zhuvax.dpbot.util.SchedulerUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public class BotDeathListener implements Listener {

    private final JavaPlugin plugin;
    private final BotManager botManager;
    private final ConfigManager cfg;

    public BotDeathListener(JavaPlugin plugin, BotManager botManager, ConfigManager cfg) {
        this.plugin = plugin;
        this.botManager = botManager;
        this.cfg = cfg;
    }

    @EventHandler
    public void onBotDeath(EntityDeathEvent event) {
        String name = botManager.nameOf(event.getEntity());
        if (name == null) return;

        // Replace vanilla drops with our shared loot table
        event.getDrops().clear();
        event.setDroppedExp(0);

        List<LootEntry> table = cfg.lootTable();
        List<ItemStack> loot = LootEntry.rollAll(table);
        Location deathLoc = event.getEntity().getLocation();
        for (ItemStack item : loot) {
            deathLoc.getWorld().dropItemNaturally(deathLoc, item);
        }

        Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(cfg.msg("bot-died", "name", name)));

        BotDefinition def = botManager.getBotDefManager().get(name);
        botManager.clearDead(name);

        if (def != null && def.getSpawnLocation() != null) {
            Location spawn = def.getSpawnLocation();
            SchedulerUtil.runAtLocationLater(plugin, spawn, def.getRespawnDelayTicks(),
                    () -> botManager.spawnEntity(name, spawn));
        }
    }
}
