package com.zhuvax.dpbot.listeners;

import com.zhuvax.dpbot.bot.BotManager;
import com.zhuvax.dpbot.config.ConfigManager;
import org.bukkit.Sound;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

public class BlockListener implements Listener {

    private final BotManager botManager;
    private final ConfigManager cfg;

    public BlockListener(BotManager botManager, ConfigManager cfg) {
        this.botManager = botManager;
        this.cfg = cfg;
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (botManager.nameOf(event.getEntity()) == null) return;

        boolean blocking = botManager.getCombatController().isBlocking(event.getEntity().getUniqueId());
        if (!blocking) return;

        double reduction = cfg.blockDamageReduction();
        event.setDamage(event.getDamage() * (1.0 - reduction));
        event.getEntity().getWorld().playSound(event.getEntity().getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 1f);
    }
}
