package com.zhuvax.dpbot.listeners;

import com.zhuvax.dpbot.bot.BotDefinition;
import com.zhuvax.dpbot.bot.BotManager;
import com.zhuvax.dpbot.bot.PracticeBot;
import com.zhuvax.dpbot.config.ConfigManager;
import com.zhuvax.dpbot.util.SchedulerUtil;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Modifies damage dealt BY our bots. Attack TIMING (including the combo
 * burst/recovery pattern) is now decided entirely by CombatController, which
 * calls LivingEntity#attack(Entity) directly - so every event that reaches
 * here is already a "real", intentionally-timed hit. This listener just
 * adjusts the damage number and handles the crit/weapon-swap flourish:
 * 1. Crit chance + damage multiplier from the bot's difficulty/settings.
 * 2. Weapon combo-swap: on a crit, briefly swaps to the bot's configured
 *    "secondary weapon" then swaps back.
 */
public class CombatListener implements Listener {

    private final JavaPlugin plugin;
    private final BotManager botManager;
    private final ConfigManager cfg;

    public CombatListener(JavaPlugin plugin, BotManager botManager, ConfigManager cfg) {
        this.plugin = plugin;
        this.botManager = botManager;
        this.cfg = cfg;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onBotAttack(EntityDamageByEntityEvent event) {
        String name = botManager.nameOf(event.getDamager());
        if (name == null) return;
        if (!(event.getEntity() instanceof Player)) return;

        double multiplier = resolveDamageMultiplier(name);
        double damage = event.getDamage() * multiplier;

        BotDefinition def = botManager.getBotDefManager().get(name);
        if (def != null && ThreadLocalRandom.current().nextDouble() < def.getCritChance()) {
            damage *= 1.5;
            event.getEntity().getWorld().spawnParticle(Particle.CRIT, event.getEntity().getLocation().add(0, 1, 0), 15, 0.3, 0.3, 0.3);
            event.getEntity().getWorld().playSound(event.getEntity().getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 1f);

            if (event.getDamager() instanceof LivingEntity botEntity && def.getSecondaryWeapon() != null) {
                swapToSecondaryWeapon(botEntity, def.getSecondaryWeapon());
            }
        }

        event.setDamage(damage);
    }

    private void swapToSecondaryWeapon(LivingEntity bot, ItemStack secondary) {
        EntityEquipment eq = bot.getEquipment();
        if (eq == null) return;

        ItemStack primary = eq.getItemInMainHand().clone();
        eq.setItemInMainHand(secondary.clone());

        SchedulerUtil.runOnEntityLater(plugin, bot, cfg.weaponSwapDurationTicks(), () -> {
            EntityEquipment liveEq = bot.getEquipment();
            if (liveEq != null && bot.isValid()) {
                liveEq.setItemInMainHand(primary);
            }
        });
    }

    private double resolveDamageMultiplier(String name) {
        PracticeBot bot = botManager.getLive(name);
        return bot != null ? bot.getDifficulty().getDamageMultiplier() : 1.0;
    }
}
