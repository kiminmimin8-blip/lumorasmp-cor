package com.zhuvax.dpbot.commands;

import com.zhuvax.dpbot.bot.BotDefinition;
import com.zhuvax.dpbot.bot.BotDefinitionManager;
import com.zhuvax.dpbot.bot.BotManager;
import com.zhuvax.dpbot.config.ConfigManager;
import com.zhuvax.dpbot.gui.BotListGui;
import com.zhuvax.dpbot.gui.KitListGui;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BotCommand implements CommandExecutor, TabCompleter {

    private final BotManager botManager;
    private final ConfigManager cfg;

    public BotCommand(BotManager botManager, ConfigManager cfg) {
        this.botManager = botManager;
        this.cfg = cfg;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "create" -> handleCreate(sender, args);
            case "delete" -> handleDelete(sender, args);
            case "list" -> handleList(sender);
            case "spawn" -> handleSpawn(sender, args);
            case "remove" -> handleRemove(sender, args);
            case "setspawn" -> handleSetSpawn(sender, args);
            case "edit" -> handleEdit(sender);
            case "difficulty" -> handleDifficulty(sender, args);
            case "enchant" -> handleEnchant(sender, args);
            case "rename" -> handleRename(sender, args);
            case "skin" -> handleSkin(sender, args);
            case "egg" -> handleEgg(sender, args);
            case "kit" -> handleKit(sender, args);
            case "help" -> sendHelp(sender);
            case "reload" -> handleReload(sender);
            case "removeall" -> handleRemoveAll(sender);
            default -> sendHelp(sender);
        }
        return true;
    }

    private void handleCreate(CommandSender sender, String[] args) {
        if (!sender.hasPermission("dpbot.manage")) {
            sender.sendMessage(cfg.msg("no-permission"));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage("§eUsage: /bot create <nama>");
            return;
        }
        String name = args[1];
        if (botManager.getBotDefManager().exists(name)) {
            sender.sendMessage("§cBot §e" + name + " §csudah ada.");
            return;
        }
        BotDefinition def = botManager.createBot(name);
        if (def == null) {
            sender.sendMessage("§cGagal bikin bot - udah mentok di limit " + BotDefinitionManager.MAX_BOTS + " bot.");
            return;
        }
        sender.sendMessage("§aBot §e" + name + " §adibuat. Pakai /bot spawn " + name + " atau /bot setspawn " + name + " buat mulai.");
    }

    private void handleDelete(CommandSender sender, String[] args) {
        if (!sender.hasPermission("dpbot.manage")) {
            sender.sendMessage(cfg.msg("no-permission"));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage("§eUsage: /bot delete <nama>");
            return;
        }
        boolean removed = botManager.deleteBot(args[1]);
        sender.sendMessage(removed ? "§aBot §e" + args[1] + " §adihapus." : "§cBot §e" + args[1] + " §ctidak ditemukan.");
    }

    private void handleList(CommandSender sender) {
        var all = botManager.getBotDefManager().all();
        if (all.isEmpty()) {
            sender.sendMessage("§7Belum ada bot. Bikin dulu pakai /bot create <nama>.");
            return;
        }
        sender.sendMessage("§6Bots (" + all.size() + "/" + BotDefinitionManager.MAX_BOTS + "):");
        for (BotDefinition def : all.values()) {
            boolean alive = botManager.isAlive(def.getName());
            String spawnInfo = def.getSpawnLocation() != null ? "§afixed spawn" : "§7ad-hoc";
            sender.sendMessage("  §e" + def.getName() + " §7- " + (alive ? "§aalive" : "§8offline") + " §7(" + spawnInfo + "§7)");
        }
    }

    private void handleSpawn(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(cfg.msg("player-only"));
            return;
        }
        if (!player.hasPermission("dpbot.manage")) {
            player.sendMessage(cfg.msg("no-permission"));
            return;
        }
        if (args.length < 2) {
            player.sendMessage("§eUsage: /bot spawn <nama>");
            return;
        }
        String name = args[1];
        if (!botManager.getBotDefManager().exists(name)) {
            player.sendMessage("§cBot §e" + name + " §ctidak ada. Bikin dulu pakai /bot create " + name);
            return;
        }
        if (botManager.isAlive(name)) {
            player.sendMessage("§cBot §e" + name + " §csudah hidup.");
            return;
        }
        botManager.spawnEntity(name, player.getLocation());
        player.sendMessage("§aBot §e" + name + " §adi-spawn.");
    }

    private void handleRemove(CommandSender sender, String[] args) {
        if (!sender.hasPermission("dpbot.use")) {
            sender.sendMessage(cfg.msg("no-permission"));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage("§eUsage: /bot remove <nama>");
            return;
        }
        String name = args[1];
        if (!botManager.isAlive(name)) {
            sender.sendMessage("§cBot §e" + name + " §clagi gak hidup.");
            return;
        }
        botManager.removeEntity(name);
        sender.sendMessage("§aBot §e" + name + " §adihapus dari world.");
    }

    private void handleSetSpawn(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(cfg.msg("player-only"));
            return;
        }
        if (!player.hasPermission("dpbot.manage")) {
            player.sendMessage(cfg.msg("no-permission"));
            return;
        }
        if (args.length < 2) {
            player.sendMessage("§eUsage: /bot setspawn <nama>");
            return;
        }
        String name = args[1];
        BotDefinition def = botManager.getBotDefManager().get(name);
        if (def == null) {
            player.sendMessage("§cBot §e" + name + " §ctidak ada. Bikin dulu pakai /bot create " + name);
            return;
        }
        Location loc = player.getLocation();
        def.setSpawnLocation(loc);
        botManager.getBotDefManager().save();

        if (botManager.isAlive(name)) {
            botManager.removeEntity(name);
        }
        botManager.spawnEntity(name, loc);
        player.sendMessage("§aSpawn tetap bot §e" + name + " §adi-set di posisi kamu. Bot ini bakal auto-respawn di sini tiap mati ("
                + (def.getRespawnDelayTicks() / 20) + "s).");
    }

    private void handleEdit(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(cfg.msg("player-only"));
            return;
        }
        if (!player.hasPermission("dpbot.manage")) {
            player.sendMessage(cfg.msg("no-permission"));
            return;
        }
        BotListGui.open(player, botManager.getBotDefManager());
    }

    private void handleSkin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("dpbot.manage")) {
            sender.sendMessage(cfg.msg("no-permission"));
            return;
        }
        if (args.length < 3) {
            sender.sendMessage("§eUsage: /bot skin <nama> <username minecraft|clear>");
            return;
        }
        String name = args[1];
        BotDefinition def = botManager.getBotDefManager().get(name);
        if (def == null) {
            sender.sendMessage("§cBot §e" + name + " §ctidak ditemukan.");
            return;
        }
        String skin = args[2].equalsIgnoreCase("clear") ? null : args[2];
        def.setSkinName(skin);
        botManager.getBotDefManager().save();

        if (botManager.isAlive(name)) {
            botManager.removeEntity(name);
            var loc = botManager.getBotDefManager().get(name).getSpawnLocation();
            if (loc == null && sender instanceof Player p) loc = p.getLocation();
            if (loc != null) botManager.spawnEntity(name, loc);
        }

        sender.sendMessage(skin != null
                ? "§aBot §e" + name + " §asekarang pakai skin §e" + skin + "§a (respawn kalau lagi hidup)."
                : "§aSkin bot §e" + name + " §adihapus, balik ke default.");
    }

    private void handleEnchant(CommandSender sender, String[] args) {
        if (!sender.hasPermission("dpbot.manage")) {
            sender.sendMessage(cfg.msg("no-permission"));
            return;
        }
        if (args.length < 5) {
            sender.sendMessage("§eUsage: /bot enchant <bot> <helmet|chest|legs|boots|mainhand|offhand> <enchant> <level>");
            sender.sendMessage("§7Level boleh di atas batas normal vanilla (misal Protection 10, Sharpness 20).");
            return;
        }
        String botName = args[1];
        BotDefinition def = botManager.getBotDefManager().get(botName);
        if (def == null) {
            sender.sendMessage("§cBot §e" + botName + " §ctidak ditemukan.");
            return;
        }

        EquipmentSlot slot = parseSlot(args[2]);
        if (slot == null) {
            sender.sendMessage("§cSlot tidak valid. Pilihan: helmet, chest, legs, boots, mainhand, offhand.");
            return;
        }

        Enchantment enchant = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(args[3].toLowerCase()));
        if (enchant == null) {
            sender.sendMessage("§cEnchant §e" + args[3] + " §ctidak dikenal. Pakai nama vanilla, contoh: sharpness, protection, unbreaking.");
            return;
        }

        int level;
        try {
            level = Integer.parseInt(args[4]);
        } catch (NumberFormatException e) {
            sender.sendMessage("§cLevel harus angka.");
            return;
        }
        if (level < 1 || level > 255) {
            sender.sendMessage("§cLevel harus antara 1 - 255.");
            return;
        }

        ItemStack item = def.getGear(slot);
        if (item == null) {
            item = defaultItemFor(slot);
        }
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(enchant, level, true); // true = ignore vanilla level restriction
        item.setItemMeta(meta);
        def.setGear(slot, item);
        botManager.getBotDefManager().save();
        botManager.applyGearSlotLive(botName, slot, item);

        sender.sendMessage("§aBot §e" + botName + " §a: " + slot.name().toLowerCase() + " dikasih §e"
                + enchant.getKey().getKey() + " " + level + "§a.");
    }

    private EquipmentSlot parseSlot(String raw) {
        return switch (raw.toLowerCase()) {
            case "helmet", "head" -> EquipmentSlot.HEAD;
            case "chest", "chestplate" -> EquipmentSlot.CHEST;
            case "legs", "leggings" -> EquipmentSlot.LEGS;
            case "boots" -> EquipmentSlot.FEET;
            case "mainhand", "hand" -> EquipmentSlot.HAND;
            case "offhand" -> EquipmentSlot.OFF_HAND;
            default -> null;
        };
    }

    private ItemStack defaultItemFor(EquipmentSlot slot) {
        Material material = switch (slot) {
            case HEAD -> Material.DIAMOND_HELMET;
            case CHEST -> Material.DIAMOND_CHESTPLATE;
            case LEGS -> Material.DIAMOND_LEGGINGS;
            case FEET -> Material.DIAMOND_BOOTS;
            case HAND -> Material.DIAMOND_SWORD;
            case OFF_HAND -> Material.SHIELD;
            default -> Material.AIR;
        };
        return new ItemStack(material);
    }

    private void handleRename(CommandSender sender, String[] args) {
        if (!sender.hasPermission("dpbot.manage")) {
            sender.sendMessage(cfg.msg("no-permission"));
            return;
        }
        if (args.length < 3) {
            sender.sendMessage("§eUsage: /bot rename <nama-lama> <nama-baru>");
            return;
        }
        String oldName = args[1];
        String newName = args[2];
        if (!botManager.getBotDefManager().exists(oldName)) {
            sender.sendMessage("§cBot §e" + oldName + " §ctidak ditemukan.");
            return;
        }
        if (botManager.getBotDefManager().exists(newName)) {
            sender.sendMessage("§cSudah ada bot bernama §e" + newName + "§c.");
            return;
        }
        boolean ok = botManager.renameBot(oldName, newName);
        sender.sendMessage(ok ? "§aBot §e" + oldName + " §adiganti nama jadi §e" + newName + "§a."
                : "§cGagal rename.");
    }

    private void handleEgg(CommandSender sender, String[] args) {
        if (!sender.hasPermission("dpbot.manage")) {
            sender.sendMessage(cfg.msg("no-permission"));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage("§eUsage: /bot egg <nama> [player]");
            return;
        }
        String name = args[1];
        if (!botManager.getBotDefManager().exists(name)) {
            sender.sendMessage("§cBot §e" + name + " §ctidak ditemukan.");
            return;
        }

        Player target;
        if (args.length >= 3) {
            target = org.bukkit.Bukkit.getPlayerExact(args[2]);
            if (target == null) {
                sender.sendMessage("§cPlayer §e" + args[2] + " §ctidak online.");
                return;
            }
        } else if (sender instanceof Player p) {
            target = p;
        } else {
            sender.sendMessage("§eDari console, sebutkan playernya: /bot egg <nama> <player>");
            return;
        }

        target.getInventory().addItem(botManager.createEggItem(name));
        sender.sendMessage("§aBot Egg §e" + name + " §adikasih ke §e" + target.getName() + "§a.");
        if (!target.equals(sender)) {
            target.sendMessage("§aKamu dapet Bot Egg §e" + name + "§a. Klik kanan ke tanah buat spawn.");
        }
    }

    private void handleDifficulty(CommandSender sender, String[] args) {
        if (!sender.hasPermission("dpbot.manage")) {
            sender.sendMessage(cfg.msg("no-permission"));
            return;
        }
        if (args.length < 3) {
            sender.sendMessage("§eUsage: /bot difficulty <nama> <easy|medium|hard>");
            return;
        }
        String name = args[1];
        String key = args[2].toUpperCase();
        if (!key.equals("EASY") && !key.equals("MEDIUM") && !key.equals("HARD")) {
            sender.sendMessage(cfg.msg("difficulty-invalid"));
            return;
        }
        BotDefinition def = botManager.getBotDefManager().get(name);
        if (def == null) {
            sender.sendMessage("§cBot §e" + name + " §ctidak ditemukan.");
            return;
        }
        def.setDifficultyName(key);
        botManager.getBotDefManager().save();
        sender.sendMessage(cfg.msg("difficulty-changed", "difficulty", key));
    }

    private void handleKit(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§eUsage: /bot kit <list|create|delete|gui|apply> [nama] [bot]");
            return;
        }
        String sub = args[1].toLowerCase();
        var kitManager = botManager.getKitManager();

        switch (sub) {
            case "list" -> {
                String names = String.join(", ", kitManager.all().keySet());
                sender.sendMessage("§6Kits: §f" + (names.isEmpty() ? "(kosong)" : names));
            }
            case "create" -> {
                if (!sender.hasPermission("dpbot.kit.manage")) {
                    sender.sendMessage(cfg.msg("no-permission"));
                    return;
                }
                if (args.length < 3) {
                    sender.sendMessage("§eUsage: /bot kit create <nama>");
                    return;
                }
                String name = args[2];
                if (kitManager.exists(name)) {
                    sender.sendMessage("§cKit §e" + name + " §csudah ada.");
                    return;
                }
                kitManager.getOrCreate(name);
                kitManager.save();
                sender.sendMessage("§aKit §e" + name + " §adibuat. Edit gear-nya lewat /bot kit gui.");
            }
            case "delete" -> {
                if (!sender.hasPermission("dpbot.kit.manage")) {
                    sender.sendMessage(cfg.msg("no-permission"));
                    return;
                }
                if (args.length < 3) {
                    sender.sendMessage("§eUsage: /bot kit delete <nama>");
                    return;
                }
                boolean removed = kitManager.delete(args[2]);
                sender.sendMessage(removed ? "§aKit §e" + args[2] + " §adihapus." : "§cGagal hapus (kit gak ada atau itu kit Default).");
            }
            case "gui" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(cfg.msg("player-only"));
                    return;
                }
                if (!player.hasPermission("dpbot.kit.manage")) {
                    player.sendMessage(cfg.msg("no-permission"));
                    return;
                }
                KitListGui.open(player, kitManager);
            }
            case "apply" -> {
                if (args.length < 4) {
                    sender.sendMessage("§eUsage: /bot kit apply <nama> <bot>");
                    return;
                }
                if (!sender.hasPermission("dpbot.manage")) {
                    sender.sendMessage(cfg.msg("no-permission"));
                    return;
                }
                String kitName = args[2];
                String botName = args[3];
                if (!kitManager.exists(kitName)) {
                    sender.sendMessage("§cKit §e" + kitName + " §ctidak ditemukan.");
                    return;
                }
                if (!botManager.getBotDefManager().exists(botName)) {
                    sender.sendMessage("§cBot §e" + botName + " §ctidak ditemukan.");
                    return;
                }
                botManager.applyKit(botName, kitName);
                sender.sendMessage("§aKit §e" + kitName + " §adipakai buat bot §e" + botName + "§a.");
            }
            default -> sender.sendMessage("§eUsage: /bot kit <list|create|delete|gui|apply> [nama] [bot]");
        }
    }

    private void handleReload(CommandSender sender) {
        if (!sender.hasPermission("dpbot.admin")) {
            sender.sendMessage(cfg.msg("no-permission"));
            return;
        }
        cfg.load();
        botManager.getBotDefManager().load();
        botManager.getKitManager().load();
        sender.sendMessage("§aConfig di-reload.");
    }

    private void handleRemoveAll(CommandSender sender) {
        if (!sender.hasPermission("dpbot.admin")) {
            sender.sendMessage(cfg.msg("no-permission"));
            return;
        }
        botManager.removeAll();
        sender.sendMessage("§aSemua bot yang lagi hidup udah dihapus dari world (config-nya tetep ada).");
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage("""
                §6DungeonPracticeBot Commands:
                §e/bot create <nama> §7- Bikin bot baru (max 30)
                §e/bot delete <nama> §7- Hapus bot & config-nya
                §e/bot list §7- Lihat semua bot
                §e/bot spawn <nama> §7- Spawn sekali di posisi kamu (mati = hilang)
                §e/bot setspawn <nama> §7- Set rumah tetap di posisi kamu (auto-respawn tiap mati)
                §e/bot remove <nama> §7- Hapus bot dari world (config tetep ada)
                §e/bot edit §7- Buka GUI daftar bot, klik buat edit setting
                §e/bot difficulty <nama> <easy|medium|hard> §7- Ganti difficulty bot
                §e/bot enchant <nama> <slot> <enchant> <level> §7- Enchant custom (bisa di atas vanilla max)
                §e/bot rename <lama> <baru> §7- Ganti nama bot
                §e/bot skin <nama> <username|clear> §7- Pakein skin player asli
                §e/bot egg <nama> [player] §7- Kasih item buat spawn bot tanpa command
                §e/bot kit list|create|gui|apply §7- Kelola & pakai kit gear
                §e/bot help §7- Tampilkan menu ini""");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> options = new ArrayList<>();
        var botNames = botManager.getBotDefManager().all().keySet();

        if (args.length == 1) {
            options.addAll(Arrays.asList("create", "delete", "list", "spawn", "remove", "setspawn",
                    "edit", "difficulty", "enchant", "rename", "skin", "egg", "kit", "help"));
            if (sender.hasPermission("dpbot.admin")) {
                options.addAll(Arrays.asList("reload", "removeall"));
            }
        } else if (args.length == 2) {
            switch (args[0].toLowerCase()) {
                case "delete", "spawn", "remove", "setspawn", "difficulty", "enchant", "rename", "egg", "skin" -> options.addAll(botNames);
                case "kit" -> options.addAll(Arrays.asList("list", "create", "delete", "gui", "apply"));
                default -> {
                }
            }
        } else if (args.length == 3) {
            if (args[0].equalsIgnoreCase("difficulty")) {
                options.addAll(Arrays.asList("easy", "medium", "hard"));
            } else if (args[0].equalsIgnoreCase("enchant")) {
                options.addAll(Arrays.asList("helmet", "chest", "legs", "boots", "mainhand", "offhand"));
            } else if (args[0].equalsIgnoreCase("kit")
                    && (args[1].equalsIgnoreCase("delete") || args[1].equalsIgnoreCase("apply"))) {
                options.addAll(botManager.getKitManager().all().keySet());
            }
        } else if (args.length == 4 && args[0].equalsIgnoreCase("kit") && args[1].equalsIgnoreCase("apply")) {
            options.addAll(botNames);
        }

        String current = args[args.length - 1].toLowerCase();
        options.removeIf(o -> !o.toLowerCase().startsWith(current));
        return options;
    }
}
