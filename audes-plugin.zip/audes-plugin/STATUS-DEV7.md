# STATUS-DEV7.md

## Yang dikerjakan sesi ini: Custom Ore ✅
Prioritas Sedang #1 di `daftar-fitur-itemsadder.md` ("perluasan kecil dari
custom block yang sudah ada" — sesuai perkiraan Dev6, memang effort
kecil-menengah karena tinggal nambah field & logic di modul block yang
sudah solid).

- **`ToolTier`** (baru): enum WOOD/GOLD/STONE/IRON/DIAMOND/NETHERITE +
  NONE, urutan sesuai tier mining vanilla asli (GOLD di bawah STONE).
  `fromItemStack()` deteksi tier dari nama Material yang dipegang player
  (cek suffix `_PICKAXE`).
- **`BlockDefinition`** — 3 field baru: `requiredToolTier`, `xpMin`,
  `xpMax`. Semua default ke "tidak ada efek" (NONE/0/0) supaya block
  yang sudah ada di config lama TETAP jalan sama persis (backward
  compatible, tidak perlu migrasi config).
- **`CustomBlockListener.onBreak()`**:
  - Cek `requiredToolTier` PALING AWAL (sebelum logic hardness) — kalau
    tool tidak cukup, block tidak bisa di-mining sama sekali (bukan
    "hancur tapi kosong"), meniru vanilla ore tier lock. Creative bypass
    seperti biasa.
  - `dropLoot()` sekarang terima Fortune level dari tool (`getEnchantmentLevel`)
    dan kasih 1 roll tambahan per level Fortune per entri loot table.
    **Ini aproksimasi**, bukan replika persis algoritma fortune vanilla —
    didokumentasikan jelas di javadoc supaya tidak disangka 1:1.
  - `dropExperience()` (baru) — spawn ExperienceOrb kalau `xpMax > 0`.

## COMPILE RISK sesi ini (pola sama seperti Dev5/Dev6 — belum diverifikasi)
1. `Enchantment.FORTUNE` — Bukkit pernah migrasi penamaan enchantment
   constant (era 1.20.5/1.21) dari field statis lama ke sistem
   registry-based. Kalau nama ini salah di paper-api 1.21.11, cek
   `jd.papermc.io` untuk nama yang benar (kemungkinan besar tetap
   `FORTUNE`, tapi belum terverifikasi).
2. `ExperienceOrb` spawn via `world.spawn(location, ExperienceOrb.class, consumer)`
   — pola ini sudah dipakai Dev5/Dev6 untuk entity lain (ItemDisplay,
   Interaction) dan lolos compile, jadi risiko rendah, tapi tetap dicatat
   untuk kelengkapan.

## Keterbatasan yang sengaja belum diselesaikan
- Fortune bonus dan XP drop TIDAK menghormati Silk Touch (vanilla: ore
  yang di-mining Silk Touch drop block itu sendiri, bukan raw material,
  dan tidak drop XP). Belum ada dukungan Silk Touch di modul block sama
  sekali. TODO kalau tim butuh parity persis dengan vanilla.
- `ToolTier.fromItemStack()` cuma cek suffix nama Material `_PICKAXE`,
  belum ada dukungan pickaxe custom (mis. custom tool dari `tools:`
  config yang base material-nya PICKAXE) — kalau ada tool custom
  berbasis pickaxe, tier-nya dihitung dari base material vanilla-nya
  saja, bukan dari `attributes.damage-bonus` atau field custom lain.

## Rekomendasi urutan kerja dev berikutnya
Sesuai urutan di `daftar-fitur-itemsadder.md` bagian "Sisa prioritas
Sedang":
1. Compile ulang, cek 2 poin risiko di atas.
2. **Emoji di chat/buku/hologram** — value tinggi buat branding server,
   effort sedang (listener chat + replace token, mirip prinsip
   `PrefixListener`).
3. **Custom furniture animasi** — cek dulu apakah cukup pakai aset
   `.mcmeta` resource-pack-side tanpa kode Java tambahan.
4. Custom HUD/GUI, custom animated entities — effort lebih besar,
   evaluasi ulang relevansi buat EcoCPvP dulu sebelum dikerjakan.
