# STATUS-DEV9.md

## Yang dikerjakan sesi ini: Custom Furniture "Animasi" ✅ (interpretasi diklarifikasi)
Prioritas Sedang #1 di sisa checklist. Dev6/7/8 sudah menduga fitur ini
mungkin "cukup resource-pack-side" — **dugaan itu BENAR untuk sebagian
fitur, tapi ada bagian lain yang memang butuh kode**. Diklarifikasi di
javadoc `FurnitureDefinition`:

1. **Animasi tekstur murni** (api berkedip, air mengalir, dll) — MURNI
   resource-pack-side lewat file `.mcmeta` (frametime + frames array).
   TIDAK BUTUH kode Java sama sekali, client otomatis animasikan. TIDAK
   ADA YANG DIKERJAKAN DI SESI INI untuk bagian ini karena memang tidak
   ada kode yang perlu ditulis — cukup tim isi aset `.mcmeta` di
   `contents/`.
2. **Toggle-state terpicu interaksi** (lampu nyala/mati, furniture
   berubah bentuk saat diklik) — INI YANG DIKERJAKAN sesi ini, karena
   butuh server tahu kapan player klik dan model mana yang aktif.

## Detail implementasi
- **`FurnitureDefinition`** — 2 field baru: `states` (List<String>
  modelKey, default kosong = furniture statis, backward compatible) dan
  `toggleSoundKey`.
- **`FurnitureItemFactory`** — `createWithState(def, stateIndex)` +
  `resolveModelKey()` (pilih modelKey dari `states` kalau tidak kosong,
  fallback ke `modelKey` lama kalau kosong). `applyState()` update
  ItemDisplay yang SUDAH di-place (tidak spawn ulang entity) + simpan
  state index ke PDC ItemDisplay (persist lewat restart, karena entity
  PDC ikut ke-save otomatis oleh server).
- **`FurnitureListener.onToggleState()`** (baru) — pasang di
  `PlayerInteractEntityEvent` (BEDA dari `PlayerInteractEvent` yang
  dipakai `onPlace()` untuk nge-place furniture baru; klik ke entity
  yang sudah ada butuh event jenis lain). Cycle state index modulo
  `states.size()`, cuma aktif kalau `states.size() >= 2`.

## COMPILE RISK sesi ini
Rendah — semua API yang dipakai (`PlayerInteractEntityEvent`,
`PersistentDataType.INTEGER`, `ItemDisplay#setItemStack`) sudah lama &
stabil, dan `ItemDisplay`/PDC entity sudah dipakai Dev5 di modul ini
juga (lolos compile). Risiko utama justru di LOGIKA, bukan compile:
- `onToggleState` dan `onAttack` (breaking furniture) SAMA-SAMA
  menangani interaksi ke entity `Interaction`. Belum ada pengujian
  manual apakah klik kanan vs klik kiri/attack benar-benar tidak saling
  tumpang tindih di client Bedrock (Geyser) — perlu ditest khusus di
  server LumoraSMP yang cross-play Java+Bedrock, karena mapping
  klik-kanan/klik-kiri di Bedrock kadang beda nuansa dari Java (dicatat
  sebagai risiko, bukan bug yang sudah dikonfirmasi).

## Keterbatasan yang sengaja belum diselesaikan
- Tidak ada rate-limit/cooldown toggle — player bisa spam klik kanan
  buat toggle berkali-kali per detik. Dampaknya cuma visual (bukan
  exploit ekonomi/gameplay), jadi belum dianggap prioritas, tapi dicatat
  buat dev berikutnya kalau ternyata mengganggu.
- Toggle state TIDAK dibatasi permission — siapa saja yang bisa
  klik-kanan furniture (termasuk bukan yang nge-place) bisa toggle-nya.
  Kalau tim butuh proteksi (mis. cuma owner lahan yang bisa toggle),
  perlu integrasi ke plugin claim/protection yang dipakai LumoraSMP
  (belum diketahui plugin apa dari riset sejauh ini).

## Rekomendasi urutan kerja dev berikutnya
1. **Compile ulang** — ini WAJIB sekarang, sudah 5 sesi (Dev6-9) numpuk
   perubahan tanpa verifikasi compile ulang sejak Dev6.
2. Kalau compile sukses, test manual toggle-state di server beneran
   (termasuk dari client Bedrock kalau memungkinkan).
3. Lanjut ke **Custom HUD/GUI** atau **Custom animated entities**
   (sisa prioritas Sedang terakhir di `daftar-fitur-itemsadder.md`),
   atau evaluasi ulang prioritas bareng tim berdasarkan kebutuhan
   LumoraSMP yang paling mendesak sekarang.
