# Status Kerja Dev4 — lanjutan dari Dev3

Melanjutkan skeleton Dev3 sesuai urutan prioritas di STATUS-DEV3.md. Belum
di-compile juga (environment saya tidak ada akses internet ke Maven), tapi
semua perubahan ditulis manual dengan hati-hati mengikuti API Paper/Adventure
yang saya tahu untuk 1.21.11.

## ⚠️ Langkah pertama dev berikutnya: TETAP compile duluan

`mvn clean package` di mesin dengan internet. Yang paling mungkin bermasalah:
- `ResourcePackInfo.resourcePackInfo(UUID, URI, String)` — cek signature
  persis di versi Adventure yang ke-resolve oleh paper-api 1.21.11 (ada
  kemungkinan overload berbeda antar versi, saya tulis berdasarkan API yang
  saya tahu terakhir, bisa saja berubah).
- `com.sun.net.httpserver.HttpServer` — ini bagian dari JDK (`jdk.httpserver`
  module), BUKAN dependency Maven. Kalau build pakai JDK yang di-strip modul
  (jarang, tapi ada di beberapa distribusi minimal), ini bisa gagal — kalau
  terjadi, ganti ke library HTTP server ringan lain atau modul JDK eksplisit
  di `module-info`/manifest.

## Sudah dikerjakan (urutan sesuai prioritas Dev3)

1. **Fix `pom.xml`** — `paper.api.version` diganti ke `1.21.11-R0.1-SNAPSHOT`
   (dikonfirmasi ini versi API release, bukan pre-release, untuk 1.21.11 di
   repo resmi PaperMC). Kalau pindah ke 26.1.x/26.2.x nanti, cek ulang versi
   yang benar-benar dipublikasi — jangan asal tebak formatnya.

2. **Command `/audes give <player> <tool_id>`** — di `AudesCommand.java`,
   manggil `CustomToolsModule.getFactory().create()` lalu `addItem()`.
   Tab-complete otomatis list player online + tool id dari registry.

3. **Command `/audes setrank <player> <rank>`** — set rank di
   `PrefixManager`, langsung panggil `PrefixListener.updateAboveHead()`
   (independen dari rank-tab), lalu fire `AudesRankChangeEvent` supaya
   rank-tab ikut update real-time kalau modul itu aktif.

4. **`show-above-head`** — diimplementasikan di `PrefixListener` pakai
   scoreboard Team TERPISAH (prefix nama `audes_head_`) dari team yang
   dipakai `TabListManager` (`%02d_%s`) supaya tidak bentrok, sesuai
   catatan Dev3. Update saat join & quit, plus method publik
   `updateAboveHead()` yang dipanggil command setrank.

5. **Registry efek custom tool** (`tools/effect/`) — refactor dari
   hardcoded if-else di `CustomToolListener` ke `ToolEffectRegistry`
   (strategy pattern). `LightningStrikeEffect` jadi contoh pertama.
   Nambah efek baru sekarang: bikin class `implements ToolEffect`,
   daftarkan sekali di constructor `ToolEffectRegistry`, TIDAK perlu
   sentuh `CustomToolListener` lagi.

6. **Modul Resource Pack** (`resourcepack/`) — dari stub jadi implementasi
   fungsional:
   - `ResourcePackGenerator` — zip folder `plugins/Audes/contents/`,
     guard EKSPLISIT (bukan silent fail) 250MB block / 100MB warning,
     hitung SHA-1 buat hash validation.
   - `ResourcePackServer` — self-host HTTP server pakai
     `com.sun.net.httpserver.HttpServer` bawaan JDK (tanpa dependency
     tambahan), serve `/pack.zip`. Alternatif: `self-host: false` +
     `external-url` kalau tim mau pakai CDN sendiri.
   - `ResourcePackJoinListener` — kirim ke player saat join pakai
     Adventure `ResourcePackRequest` (native Paper 1.20.3+, hash-validated,
     BUKAN `Player#setResourcePack(String,byte[])` lama).
   - Semua proses generate WAJIB async (pakai `AsyncUtil` yang sudah ada).
   - Config baru di `config.yml` bagian `resource-pack:` (self-host, port,
     public-address, external-url, required, prompt-message).

## Yang masih kurang (lanjutan prioritas)

1. **Compile & fix error** — tetap blocker #1, lihat catatan di atas.
2. **Manifest resource pack** — `ResourcePackGenerator` baru zip mentah,
   belum ada mapping "tool_id → model key → apakah aset-nya benar ada di
   contents/". Tanpa ini, `ToolFactory.create()` masih belum aman diisi
   `setItemModel()` (typo di config.yml modelKey bisa bikin item invisible
   tanpa warning). Prioritas besar berikutnya.
3. **`/audes reload` masih belum full hot-reload** — termasuk belum
   trigger regenerate resource pack kalau aset di `contents/` diubah saat
   server jalan. Masih perlu restart plugin/server untuk sekarang.
4. **Firewall/NAT untuk self-host** — `ResourcePackServer` cuma bind ke
   port lokal, TIDAK ngecek apakah port itu benar-benar accessible dari
   luar. Kalau server di belakang NAT/tanpa IP publik langsung, self-host
   ini akan terlihat "jalan" di log tapi client tetap gagal download.
   Perlu didokumentasikan jelas ke tim (bukan cuma developer) supaya tidak
   bingung kalau ini terjadi.
5. **Custom vanilla armor texture** (dari riset ItemsAdder di
   `rencana-audes.md` bagian 7) — belum ada modul untuk ini sama sekali,
   masih di luar cakupan kerja Dev3/Dev4 sejauh ini.
6. Keputusan tim yang masih pending dari dokumen rencana bagian 6 (bahasa/
   framework, format config, model lisensi, struktur final `contents/`)
   belum berubah sejak laporan Dev3.
