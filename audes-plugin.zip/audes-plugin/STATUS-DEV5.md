# STATUS-DEV5.md

## Yang dikerjakan sesi ini
3 fitur prioritas Tinggi yang masih tersisa di "Ringkasan prioritas kerja
berikutnya" (daftar-fitur-itemsadder.md), plus 1 revisi desain:

### 1. Manifest resource pack + apply model ke item/block/furniture ✅
- `ResourcePackManifest` (baru): scan `contents/assets/<namespace>/items/<path>.json`
  jadi daftar modelKey yang valid, di-rebuild async bareng generate zip
  (di `ResourcePackModule`).
- `ToolFactory`, `BlockItemFactory`, `FurnitureItemFactory` sekarang query
  manifest ini sebelum `meta.setItemModel(...)`. Kalau modelKey dikonfigurasi
  tapi asetnya tidak ketemu → **warning sekali** di log (bukan silent
  fail/invisible item) — ini langsung jawab risiko yang Dev4 catat soal
  typo modelKey.
- `FurnitureItemFactory.spawn()` sekarang pakai `create(def)` buat visual
  ItemDisplay, jadi furniture yang sudah ditaruh ikut tampil bermodel,
  bukan cuma item di tangan.
- **Belum berlaku untuk BLOCK yang sudah di-place** (Paper/Mojang belum
  expose block model override resmi) — cuma ITEM block-nya yang kebagian
  model custom. Tetap pakai teknik note+instrument untuk block di dunia.

### 2. Custom item trigger/on-use effect — 6 efek baru ✅
- **Revisi desain**: `ToolEffect.trigger(Player)` diubah jadi
  `trigger(ToolEffectContext)` — versi lama tidak mungkin bikin efek yang
  butuh tahu siapa yang diserang (poison ke korban, dsb) karena cuma dikasih
  attacker. `ToolEffectContext` bawa `user`, `target`, `originalDamage`.
- Efek baru: `PotionEffectOnHitEffect` (generik, dipakai untuk 3 varian:
  POISON/WEAKNESS/SLOWNESS), `IgniteTargetEffect`, `KnockbackBurstEffect`,
  `LifestealEffect`.
- Satu tool sekarang boleh punya **lebih dari satu efek** —
  `ToolDefinition.onUseEffectKey` (String) → `onUseEffectKeys` (List),
  dipisah koma di config.yml. Backward compatible (config lama isi 1 key
  tetap jalan).

### 3. Custom block properties: hardness + loot table ✅
- **Hardness**: pendekatan "jumlah hit" (bukan durasi presisi — Bukkit API
  tidak punya event per-tick "masih menambang", meniru itu butuh manipulasi
  packet/NMS yang melanggar prinsip arsitektur tim). `def.hardness()`
  dibulatkan jadi jumlah `BlockBreakEvent` yang harus lolos sebelum block
  beneran hancur, tracked di `pendingHits` map. Creative mode selalu
  instant-break. Action bar kasih feedback "2/3" dst supaya player tahu ini
  disengaja, bukan lag.
- **Loot table**: `BlockLootEntry` (material, chance, min, max), dievaluasi
  independen per entri (bisa drop lebih dari 1 jenis sekaligus). Config
  `loot-table` kosong/tidak diisi → fallback ke behavior lama (drop item
  block itu sendiri).

## Keterbatasan yang SENGAJA belum diselesaikan (didokumentasikan di kode)
- Hardness hit-based tidak memperhitungkan efficiency/haste tool.
- `pendingHits` bisa nyisa entry basi kalau player berhenti menambang di
  tengah jalan — dampak kecil, belum ada cleanup otomatis.
- `LifestealEffect` heal-cap dipatok ke 20.0 (bukan max health aktual)
  karena nama konstanta `Attribute` untuk max-health berubah antar versi
  Paper API dan belum diverifikasi — lihat komentar di file itu.
- Manifest resource pack baru ke-rebuild saat `enable()`/restart, belum ada
  `/audes resourcepack regenerate` buat trigger ulang tanpa restart (sudah
  dicatat sejak STATUS-DEV4 juga, masih belum dikerjakan siapa pun).

## COMPILE RISK — BELUM PERNAH DI-COMPILE (sama seperti sesi sebelumnya)
Tidak ada akses internet/Maven di sesi ini, jadi seperti Dev1/Dev3/Dev4,
kode ini ditulis manual tanpa verifikasi compiler. Yang paling perlu
dicek pertama kali `mvn compile`:
1. `PotionEffectType.POISON` / `WEAKNESS` / `SLOWNESS` — nama konstanta ini
   yang dipakai, TAPI Bukkit API pernah rename beberapa nama potion effect
   (era migrasi 1.20.5/1.21). Kalau gagal compile di sini, cek nama yang
   benar di API paper-api 1.21.11 yang ke-install.
2. `Player#sendActionBar(Component)` di `CustomBlockListener` — pastikan
   import `net.kyori.adventure.text.Component` benar-benar tersedia di
   classpath (biasanya sudah lewat Paper API, tapi belum diverifikasi
   compile).
3. `ItemMeta#setItemModel(NamespacedKey)` — sudah dipakai Dev-Dev sebelumnya
   sebagai asumsi API 1.21.4+, sekarang benar-benar dipanggil (bukan cuma
   di-comment). Kalau versi paper-api yang dipasang belum punya method ini,
   ini akan gagal compile di 3 file (ToolFactory, BlockItemFactory,
   FurnitureItemFactory) sekaligus.

## Rekomendasi urutan kerja dev berikutnya
1. **Compile pertama kali** — prioritas paling tinggi di atas segalanya,
   tim ini sudah 5 sesi nulis kode tanpa pernah compile sekali pun.
2. Kalau lolos compile: test manual di server lokal 1.21.11 untuk 3 fitur
   di atas, khususnya hardness (paling berisiko punya UX yang aneh).
3. Baru lanjut fitur prioritas Sedang berikutnya di daftar-fitur-itemsadder.md
   (custom animasi furniture, custom armor texture).
