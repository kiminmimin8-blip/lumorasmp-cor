package com.audes.plugin.block;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

/**
 * Tingkatan tool untuk syarat mining custom ore (mis. "butuh pickaxe
 * minimal besi buat mining ore ini"), meniru sistem tier vanilla
 * (mis. diamond ore butuh iron pickaxe).
 *
 * Urutan di sini SENGAJA taruh GOLD di bawah STONE — ini sesuai tier
 * mining vanilla asli (pickaxe emas cepat tapi lemah, setara wood untuk
 * keperluan syarat block, BUKAN performa/durability).
 */
public enum ToolTier {
    NONE(0),
    WOOD(1),
    GOLD(1),
    STONE(2),
    IRON(3),
    DIAMOND(4),
    NETHERITE(5);

    private final int rank;

    ToolTier(int rank) {
        this.rank = rank;
    }

    public boolean meetsRequirement(ToolTier required) {
        return this.rank >= required.rank;
    }

    /**
     * Deteksi tier dari ItemStack yang dipegang player, berdasarkan
     * prefix nama Material (mis. "IRON_PICKAXE" -> IRON). Bukan pickaxe
     * sama sekali -> NONE (dianggap tidak punya tool yang layak).
     */
    public static ToolTier fromItemStack(ItemStack item) {
        if (item == null) return NONE;
        String name = item.getType().name();
        if (!name.endsWith("_PICKAXE")) return NONE;

        if (name.startsWith("WOODEN_")) return WOOD;
        if (name.startsWith("GOLDEN_")) return GOLD;
        if (name.startsWith("STONE_")) return STONE;
        if (name.startsWith("IRON_")) return IRON;
        if (name.startsWith("DIAMOND_")) return DIAMOND;
        if (name.startsWith("NETHERITE_")) return NETHERITE;
        return NONE;
    }

    public static ToolTier fromConfigName(String name, ToolTier fallback) {
        if (name == null || name.isBlank()) return fallback;
        try {
            return ToolTier.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }
}
