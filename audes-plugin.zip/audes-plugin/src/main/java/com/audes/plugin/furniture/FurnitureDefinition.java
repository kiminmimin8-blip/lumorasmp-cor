package com.audes.plugin.furniture;

import org.bukkit.Material;

import java.util.List;

/**
 * Representasi satu custom furniture dari config.yml bagian "furniture:".
 *
 * Beda pendekatan dari BlockDefinition/ToolDefinition: furniture di sini
 * bukan block ataupun item yang dipegang, tapi ENTITY (ItemDisplay untuk
 * visual + Interaction untuk hitbox) yang di-spawn ke dunia — lihat
 * FurnitureItemFactory untuk detail teknik & alasannya.
 *
 * "displayMaterial" dipakai sebagai item yang ditampilkan ItemDisplay.
 * Belum ada tekstur custom asli (sama seperti tool & block), jadi untuk
 * sekarang isi dengan material vanilla yang paling mirip (mis. OAK_PLANKS
 * untuk kursi kayu polos) sampai ResourcePackModule + modelKey benar-benar
 * dipakai.
 *
 * "states" (Dev9 — "custom furniture animasi"): daftar modelKey opsional
 * yang bisa di-cycle player lewat klik kanan ke furniture yang SUDAH
 * di-place (lihat FurnitureListener#onToggleState). Kosong (default) =
 * furniture statis biasa, behavior lama tidak berubah.
 *
 * PENTING — INI BUKAN "animasi" dalam arti tekstur bergerak otomatis
 * (mis. api berkedip, air mengalir): itu MURNI resource-pack-side lewat
 * file .mcmeta (frametime + frames array) di
 * contents/assets/<namespace>/textures/... TIDAK BUTUH kode Java sama
 * sekali — client Minecraft otomatis animasikan texture atlas kalau ada
 * .mcmeta yang benar, terlepas dari plugin ini ada atau tidak. "states"
 * di sini adalah TOGGLE model TERPICU INTERAKSI (mis. lampu nyala/mati,
 * kursi berubah bentuk saat diduduki-duduki), yang MEMANG butuh kode
 * server karena harus tahu kapan player klik dan model mana yang aktif
 * sekarang — dua hal yang beda konsep meski sama-sama disebut "animasi"
 * di riset fitur ItemsAdder.
 */
public record FurnitureDefinition(
        String id,
        Material displayMaterial,
        String displayName,
        String modelKey,
        float scale,
        double interactionWidth,
        double interactionHeight,
        String placeSoundKey,
        String breakSoundKey,
        List<String> states,
        String toggleSoundKey
) {
}
