package com.audes.plugin.tools;

import org.bukkit.Material;

import java.util.List;

/**
 * Representasi satu custom tool dari config.yml bagian "tools:".
 *
 * "modelKey" disimpan sebagai String path (mis. "audes:tools/pedang_petir")
 * mengikuti konvensi namespace ala ItemsAdder. Dev5: SUDAH dipakai untuk
 * apply custom texture lewat ToolFactory + ResourcePackManifest — lihat
 * catatan di ToolFactory untuk kapan setItemModel() benar-benar jalan
 * vs fallback vanilla.
 *
 * "onUseEffectKeys" (Dev5, sebelumnya field tunggal "onUseEffectKey"):
 * daftar key efek dari ToolEffectRegistry, BOLEH lebih dari satu (dipisah
 * koma di config.yml, mis. "LIGHTNING_STRIKE_CHANCE_5,LIFESTEAL_CHANCE_25")
 * — semua dijalankan tiap kali tool dipakai menyerang, masing-masing
 * dengan chance internalnya sendiri. List kosong (bukan null) kalau tool
 * tidak punya efek on-use, supaya pemanggil tidak perlu null-check.
 *
 * "commandBinding" (boleh null) adalah command yang dijalankan sebagai
 * console saat player right-click pakai tool ini (lihat
 * CustomToolListener#onInteract). Placeholder "%player%" diganti nama
 * player yang pakai. Belum ada cooldown — spam klik kanan = spam command,
 * lihat TODO di CustomToolListener kalau ini jadi masalah nyata.
 */
public record ToolDefinition(
        String id,
        Material material,
        String displayName,
        String modelKey,
        double damageBonus,
        double durabilityMultiplier,
        List<String> onUseEffectKeys,
        String commandBinding
) {
}
