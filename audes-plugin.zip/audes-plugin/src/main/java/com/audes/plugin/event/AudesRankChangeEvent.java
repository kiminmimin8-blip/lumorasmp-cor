package com.audes.plugin.event;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * Dipicu setiap kali rank seorang player berubah (lewat command admin,
 * integrasi permission plugin nanti, dsb). Modul rank-tab dengarkan
 * event ini supaya tab list ter-update real-time tanpa perlu polling
 * terus-menerus tiap tick (lihat config "update-interval-ticks" sebagai
 * fallback/periodic refresh, bukan satu-satunya jalur).
 */
public class AudesRankChangeEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Player player;
    private final String oldRank;
    private final String newRank;

    public AudesRankChangeEvent(Player player, String oldRank, String newRank) {
        this.player = player;
        this.oldRank = oldRank;
        this.newRank = newRank;
    }

    public Player getPlayer() {
        return player;
    }

    public String getOldRank() {
        return oldRank;
    }

    public String getNewRank() {
        return newRank;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
