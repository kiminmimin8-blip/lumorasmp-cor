package com.audes.plugin.block;

import org.bukkit.Instrument;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class BlockRegistry {

    private final Plugin plugin;
    private final Map<String, BlockDefinition> blocks = new LinkedHashMap<>();

    public BlockRegistry(Plugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig(ConfigurationSection blocksSection) {
        blocks.clear();
        if (blocksSection == null) return;

        for (String id : blocksSection.getKeys(false)) {
            ConfigurationSection s = blocksSection.getConfigurationSection(id);
            if (s == null) continue;

            Instrument instrument;
            try {
                instrument = Instrument.valueOf(s.getString("instrument", "PIANO").toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("[Audes] Instrument tidak valid untuk block '" + id
                        + "', di-skip. Cek config.yml (daftar valid: enum org.bukkit.Instrument).");
                continue;
            }

            int note = s.getInt("note", 0);
            if (note < 0 || note > 24) {
                plugin.getLogger().warning("[Audes] Note di luar rentang 0-24 untuk block '" + id
                        + "' (nilai config: " + note + "), di-clamp ke rentang valid.");
                note = Math.max(0, Math.min(24, note));
            }

            List<BlockLootEntry> lootTable = parseLootTable(s, id);

            ToolTier requiredToolTier = ToolTier.fromConfigName(s.getString("required-tool-tier"), ToolTier.NONE);
            int xpMin = Math.max(0, s.getInt("xp-min", 0));
            int xpMax = Math.max(xpMin, s.getInt("xp-max", xpMin));

            BlockDefinition def = new BlockDefinition(
                    id,
                    instrument,
                    note,
                    s.getString("display-name", id),
                    s.getString("model", null),
                    s.getDouble("hardness", 1.0),
                    s.getString("break-sound", null),
                    s.getString("place-sound", null),
                    lootTable,
                    requiredToolTier,
                    xpMin,
                    xpMax
            );
            blocks.put(id, def);
        }

        plugin.getLogger().info("[Audes] " + blocks.size() + " custom block termuat dari config.");
    }

    /**
     * Dev5: parse "loot-table:" (list of map) jadi List&lt;BlockLootEntry&gt;.
     * List kosong = drop item block itu sendiri (behavior lama, backward
     * compatible untuk config yang belum diisi loot-table).
     *
     * Entri yang tidak valid (material salah, dsb) di-skip SATU-SATU
     * dengan warning yang jelas menyebut block id + index entri, bukan
     * bikin seluruh block gagal dimuat gara-gara satu entri salah ketik.
     */
    private List<BlockLootEntry> parseLootTable(ConfigurationSection s, String blockId) {
        List<Map<?, ?>> rawList = s.getMapList("loot-table");
        if (rawList.isEmpty()) return List.of();

        List<BlockLootEntry> entries = new ArrayList<>();
        int index = 0;
        for (Map<?, ?> raw : rawList) {
            index++;
            Object materialRaw = raw.get("material");
            if (materialRaw == null) {
                plugin.getLogger().warning("[Audes] loot-table block '" + blockId + "' entri #" + index
                        + " tidak punya 'material', entri ini di-skip.");
                continue;
            }

            Material material;
            try {
                material = Material.valueOf(materialRaw.toString().toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("[Audes] loot-table block '" + blockId + "' entri #" + index
                        + " material '" + materialRaw + "' tidak valid, entri ini di-skip.");
                continue;
            }

            double chance = raw.get("chance") instanceof Number n ? n.doubleValue() : 1.0;
            chance = Math.max(0.0, Math.min(1.0, chance));

            int min = raw.get("min") instanceof Number n ? n.intValue() : 1;
            int max = raw.get("max") instanceof Number n ? n.intValue() : min;
            if (max < min) {
                plugin.getLogger().warning("[Audes] loot-table block '" + blockId + "' entri #" + index
                        + " punya max (" + max + ") < min (" + min + "), max di-samakan dengan min.");
                max = min;
            }
            min = Math.max(0, min);
            max = Math.max(0, max);

            entries.add(new BlockLootEntry(material, chance, min, max));
        }
        return List.copyOf(entries);
    }

    public Optional<BlockDefinition> get(String id) {
        return Optional.ofNullable(blocks.get(id));
    }

    public Map<String, BlockDefinition> getAll() {
        return blocks;
    }
}
