package com.audes.plugin.tools.effect;

import org.bukkit.block.Block;

/**
 * Efek "on-use": ada peluang menyambar target block pandangan player
 * dengan petir visual (tidak merusak, strikeLightningEffect saja —
 * sengaja bukan strikeLightning() supaya tidak nyalain fire/damage
 * yang tidak diinginkan sebagai efek kosmetik senjata).
 *
 * Efek ini tidak butuh context.target() (pakai target block pandangan
 * player, bukan entity yang diserang) -- tetap valid dipicu dari
 * onDamage() karena context.user() selalu ada.
 */
public class LightningStrikeEffect implements ToolEffect {

    private final double chance;

    public LightningStrikeEffect(double chance) {
        this.chance = chance;
    }

    @Override
    public void trigger(ToolEffectContext context) {
        if (Math.random() >= chance) return;

        Block target = context.user().getTargetBlockExact(5);
        if (target == null) return;

        context.user().getWorld().strikeLightningEffect(target.getLocation());
    }
}
