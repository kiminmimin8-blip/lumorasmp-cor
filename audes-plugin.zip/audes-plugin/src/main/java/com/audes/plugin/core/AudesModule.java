package com.audes.plugin.core;

/**
 * Kontrak dasar untuk setiap modul Audes (custom tools, prefix, rank tab,
 * resource pack, dst).
 *
 * Prinsip arsitektur (lihat bagian 3 dokumen rencana):
 * - Modul dipisah supaya bug di satu modul tidak menjatuhkan seluruh plugin.
 * - enable()/disable() WAJIB membungkus logic-nya sendiri dengan try-catch
 *   di level pemanggil (ModuleManager) supaya satu modul yang gagal tidak
 *   mematikan modul lain atau seluruh plugin.
 */
public interface AudesModule {

    /**
     * Nama unik modul, dipakai untuk logging dan untuk key di config.yml
     * (bagian "modules:").
     */
    String getName();

    /**
     * Dipanggil saat plugin onEnable(), hanya jika modul ini di-set true
     * di config.yml. Implementasi TIDAK BOLEH melempar exception ke luar
     * tanpa ditangani sendiri kalau memungkinkan — tapi kalau memang gagal,
     * biarkan exception naik supaya ModuleManager bisa mencatat &
     * mengisolasi modul ini (bukan seluruh plugin).
     */
    void enable();

    /**
     * Dipanggil saat plugin onDisable() atau saat modul di-reload.
     * Wajib melepas semua listener/task yang didaftarkan di enable().
     */
    void disable();
}
