package com.audes.plugin.armor;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.Plugin;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public class ArmorRegistry {

    private final Plugin plugin;
    private final Map<String, ArmorDefinition> armors = new LinkedHashMap<>();

    public ArmorRegistry(Plugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig(ConfigurationSection section) {
        armors.clear();
        if (section == null) return;

        for (String id : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(id);
            if (s == null) continue;

            String materialName = s.getString("base-material", "");
            Material material;
            try {
                material = Material.valueOf(materialName.toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("[Audes] base-material '" + materialName + "' tidak valid untuk armor '"
                        + id + "', di-skip. Cek config.yml.");
                continue;
            }

            EquipmentSlot slot = slotFromMaterial(material);
            if (slot == null) {
                plugin.getLogger().warning("[Audes] base-material '" + materialName + "' untuk armor '" + id
                        + "' bukan armor piece (harus HELMET/CHESTPLATE/LEGGINGS/BOOTS), di-skip.");
                continue;
            }

            boolean dyeable = material.name().startsWith("LEATHER_");
            if (s.getBoolean("dyeable", false) && !dyeable) {
                plugin.getLogger().warning("[Audes] armor '" + id
                        + "' set dyeable: true tapi base-material bukan LEATHER_*, diabaikan (dyeable dipaksa false).");
            }

            ArmorDefinition def = new ArmorDefinition(
                    id,
                    material,
                    slot,
                    s.getString("display-name", id),
                    s.getString("asset", null),
                    dyeable
            );
            armors.put(id, def);
        }

        plugin.getLogger().info("[Audes] " + armors.size() + " custom armor termuat dari config.");
    }

    /**
     * Infer slot equip dari akhiran nama material vanilla. Return null
     * kalau material bukan salah satu dari 4 jenis armor piece yang
     * dikenal (mis. kalau admin salah isi "DIAMOND_SWORD" di config).
     */
    private EquipmentSlot slotFromMaterial(Material material) {
        String name = material.name();
        if (name.endsWith("_HELMET")) return EquipmentSlot.HEAD;
        if (name.endsWith("_CHESTPLATE")) return EquipmentSlot.CHEST;
        if (name.endsWith("_LEGGINGS")) return EquipmentSlot.LEGS;
        if (name.endsWith("_BOOTS")) return EquipmentSlot.FEET;
        if (name.equals("TURTLE_HELMET")) return EquipmentSlot.HEAD;
        return null;
    }

    public Optional<ArmorDefinition> get(String id) {
        return Optional.ofNullable(armors.get(id));
    }

    public Map<String, ArmorDefinition> getAll() {
        return armors;
    }
}
