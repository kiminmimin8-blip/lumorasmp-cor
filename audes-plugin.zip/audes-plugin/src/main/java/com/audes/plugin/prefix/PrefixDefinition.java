package com.audes.plugin.prefix;

/**
 * Representasi satu definisi prefix (per rank/grup) yang dibaca dari
 * config.yml bagian "prefix:".
 */
public record PrefixDefinition(
        String rankKey,
        String text,
        boolean showInChat,
        boolean showInTabList,
        boolean showAboveHead
) {
}
