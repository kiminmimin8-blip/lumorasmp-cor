package com.audes.plugin.emoji;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.Plugin;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

public class EmojiRegistry {

    private final Plugin plugin;
    private final Map<String, EmojiDefinition> emoji = new LinkedHashMap<>();

    // Regex GABUNGAN semua shortcode terdaftar, di-build ulang tiap
    // loadFromConfig() -- satu pass regex per pesan chat, BUKAN loop
    // .replace() per shortcode satu-satu (jauh lebih murah kalau
    // shortcode terdaftar banyak, dan chat event jalan tiap pesan).
    private Pattern combinedPattern = Pattern.compile("(?!)"); // pattern yang tidak pernah match kalau kosong

    public EmojiRegistry(Plugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig(ConfigurationSection section) {
        emoji.clear();
        if (section == null) {
            rebuildPattern();
            return;
        }

        for (String shortcode : section.getKeys(false)) {
            String replacement = section.getString(shortcode);
            if (replacement == null || replacement.isBlank()) {
                plugin.getLogger().warning("[Audes] emoji '" + shortcode + "' tidak punya value, di-skip.");
                continue;
            }
            emoji.put(shortcode, new EmojiDefinition(shortcode, replacement));
        }

        rebuildPattern();
        plugin.getLogger().info("[Audes] " + emoji.size() + " emoji termuat dari config.");
    }

    private void rebuildPattern() {
        if (emoji.isEmpty()) {
            combinedPattern = Pattern.compile("(?!)");
            return;
        }
        // Urutkan shortcode terpanjang duluan supaya ":fire2:" tidak
        // ke-match sebagian jadi ":fire:" kalau kebetulan ada dua
        // shortcode yang salah satunya prefix dari yang lain.
        String joined = emoji.keySet().stream()
                .sorted((a, b) -> b.length() - a.length())
                .map(Pattern::quote)
                .reduce((a, b) -> a + "|" + b)
                .orElse("(?!)");
        combinedPattern = Pattern.compile(":(" + joined + "):");
    }

    public Pattern getCombinedPattern() {
        return combinedPattern;
    }

    public Optional<EmojiDefinition> get(String shortcode) {
        return Optional.ofNullable(emoji.get(shortcode));
    }

    public Map<String, EmojiDefinition> getAll() {
        return emoji;
    }
}
