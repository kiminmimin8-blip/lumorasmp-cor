package com.audes.plugin.block;

import org.bukkit.Material;

/**
 * Satu entri loot table custom block: kalau block ini hancur, entri ini
 * dievaluasi SENDIRI-SENDIRI (bukan weighted-random pilih-satu ala vanilla
 * loot table pool) — jadi satu block boleh drop lebih dari satu jenis item
 * sekaligus kalau beberapa entri "chance"-nya kena semua. Model independen
 * ini dipilih karena lebih gampang dipahami & dikonfigurasi dibanding
 * sistem weight/pool bertingkat ala vanilla, meski jadi tidak 100% identik
 * semantiknya — didokumentasikan di sini supaya tidak jadi "salah paham
 * senyap" antara config.yml dan behavior sebenarnya.
 *
 * chance: 0.0-1.0. minAmount/maxAmount: jumlah item per drop kalau chance
 * kena (maxAmount >= minAmount, divalidasi & di-clamp di BlockRegistry).
 */
public record BlockLootEntry(
        Material material,
        double chance,
        int minAmount,
        int maxAmount
) {
}
