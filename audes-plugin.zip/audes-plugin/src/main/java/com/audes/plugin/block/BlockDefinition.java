package com.audes.plugin.block;

import org.bukkit.Instrument;

import java.util.List;

/**
 * Representasi satu custom block dari config.yml bagian "blocks:".
 *
 * TEKNIK VISUAL SEMENTARA: seperti pendekatan ItemsAdder generasi awal
 * (sebelum ada block model API resmi dari Mojang/Paper), custom block di
 * Audes fase ini memakai NOTE_BLOCK sebagai "kanvas" — kombinasi
 * instrument (16 pilihan) x note (0-24) dipakai untuk membedakan block
 * secara suara, BUKAN tekstur. Ini bukan solusi final, cuma jembatan
 * sampai ada block model override resmi (saat ini API item model 1.21.4+
 * cuma berlaku untuk ITEM, belum ada padanan resmi untuk BLOCK — lihat
 * catatan riset di rencana-audes.md bagian 8).
 *
 * "modelKey" tetap disimpan sekarang mengikuti konvensi namespace ala
 * ItemsAdder, dipakai untuk apply model ke ITEM block (lihat
 * BlockItemFactory), bukan block yang sudah di-place.
 *
 * "hardness" (Dev5): SEKARANG DITERAPKAN lewat pendekatan "jumlah hit",
 * BUKAN durasi waktu presisi — lihat javadoc CustomBlockListener untuk
 * alasan & keterbatasannya (server ini murni pakai Paper API, tidak
 * manipulasi packet mining-progress).
 *
 * "lootTable" (Dev5): daftar drop custom (lihat BlockLootEntry). Kalau
 * KOSONG (default, backward compatible), block tetap drop item block
 * itu sendiri seperti sebelumnya — behavior lama tidak berubah untuk
 * config yang belum diisi loot-table.
 *
 * "requiredToolTier"/"xpMin"/"xpMax" (Dev7 — fitur "custom ore"):
 * dua field opsional yang bikin block ini berperilaku kayak ore vanilla
 * (butuh pickaxe minimal tier tertentu, drop XP orb, loot table
 * dipengaruhi Fortune). requiredToolTier = ToolTier.NONE berarti tidak
 * ada syarat (behavior lama, semua block existing otomatis begini kalau
 * config tidak diisi field "required-tool-tier"). xpMin/xpMax = 0 berarti
 * tidak drop XP sama sekali.
 */
public record BlockDefinition(
        String id,
        Instrument instrument,
        int note,
        String displayName,
        String modelKey,
        double hardness,
        String breakSoundKey,
        String placeSoundKey,
        List<BlockLootEntry> lootTable,
        ToolTier requiredToolTier,
        int xpMin,
        int xpMax
) {
}
