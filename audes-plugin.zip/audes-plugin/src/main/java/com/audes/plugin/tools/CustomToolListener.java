package com.audes.plugin.tools;

import com.audes.plugin.tools.effect.ToolEffectContext;
import com.audes.plugin.tools.effect.ToolEffectRegistry;
import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/**
 * Menangani behavior custom tool lewat event system Bukkit resmi
 * (bukan lewat reflection/NMS), sesuai prinsip arsitektur di bagian 3
 * dokumen rencana.
 *
 * Dev4: dispatch efek "on-use" sekarang lewat ToolEffectRegistry
 * (strategy pattern) alih-alih hardcoded if-else, sesuai TODO Dev3.
 * Nambah efek baru = daftar di ToolEffectRegistry, file ini tidak perlu
 * diubah lagi.
 *
 * Dev5: REVISI — dulu efek cuma dikasih Player (attacker), sekarang
 * dibungkus ToolEffectContext yang juga bawa target/korban serangan +
 * damage asli, supaya efek seperti poison/ignite/knockback-ke-korban
 * bisa dibuat (lihat ToolEffectContext). Satu tool juga sekarang boleh
 * punya LEBIH DARI SATU efek on-use (onUseEffectKeys, bukan key tunggal).
 */
public class CustomToolListener implements Listener {

    private final ToolRegistry registry;
    private final ToolFactory factory;
    private final ToolEffectRegistry effectRegistry;

    public CustomToolListener(ToolRegistry registry, ToolFactory factory, ToolEffectRegistry effectRegistry) {
        this.registry = registry;
        this.factory = factory;
        this.effectRegistry = effectRegistry;
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof LivingEntity victim)) return;

        ItemStack hand = player.getInventory().getItemInMainHand();
        String toolId = factory.getToolId(hand);
        if (toolId == null) return;

        registry.get(toolId).ifPresent(def -> {
            if (def.damageBonus() != 0.0) {
                event.setDamage(event.getDamage() + def.damageBonus());
            }
            if (!def.onUseEffectKeys().isEmpty()) {
                // originalDamage diambil SETELAH damage-bonus di atas diterapkan,
                // supaya efek seperti lifesteal scale dari damage final tool ini
                // (bukan damage dasar sebelum bonus).
                ToolEffectContext context = new ToolEffectContext(player, victim, event.getDamage());
                for (String effectKey : def.onUseEffectKeys()) {
                    dispatchOnUseEffect(effectKey, context);
                }
            }
        });
    }

    @EventHandler
    public void onDurabilityChange(PlayerItemDamageEvent event) {
        ItemStack item = event.getItem();
        String toolId = factory.getToolId(item);
        if (toolId == null) return;

        registry.get(toolId).ifPresent(def -> {
            if (def.durabilityMultiplier() != 1.0 && def.durabilityMultiplier() > 0) {
                int scaledDamage = (int) Math.round(event.getDamage() / def.durabilityMultiplier());
                event.setDamage(Math.max(1, scaledDamage));
            }
        });
    }

    /**
     * Dev1: eksekusi command binding saat player right-click pakai custom
     * tool. Cuma mainhand yang diproses (offhand di-skip) supaya command
     * tidak double-trigger di event yang sama-sama fire untuk kedua tangan.
     *
     * TODO(Dev lain): belum ada cooldown per player/per tool. Kalau nanti
     * ada command binding yang "berat" (mis. spawn mob, kasih item), spam
     * klik kanan bisa jadi masalah — tambahkan cooldown map (Player -> waktu
     * terakhir) sebelum command binding dipakai buat command production.
     */
    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack hand = player.getInventory().getItemInMainHand();
        String toolId = factory.getToolId(hand);
        if (toolId == null) return;

        registry.get(toolId).ifPresent(def -> {
            if (def.commandBinding() == null || def.commandBinding().isBlank()) return;
            String command = def.commandBinding().replace("%player%", player.getName());
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
        });
    }

    private void dispatchOnUseEffect(String effectKey, ToolEffectContext context) {
        effectRegistry.get(effectKey).ifPresentOrElse(
                effect -> effect.trigger(context),
                () -> {
                    // Key ada di config tapi tidak terdaftar di registry — jangan silent
                    // fail total, tapi juga jangan spam log tiap hit. Cukup sekali per
                    // startup lewat warning di ToolRegistry.loadFromConfig kalau perlu
                    // divalidasi lebih ketat nanti.
                }
        );
    }
}
