package com.audes.plugin.resourcepack;

import com.sun.net.httpserver.HttpServer;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Logger;

/**
 * Self-host resource pack pakai com.sun.net.httpserver.HttpServer (bawaan
 * JDK, TANPA dependency pihak ketiga) supaya tim tidak wajib bayar
 * hosting/CDN eksternal di fase awal.
 *
 * Kenapa ini opsi penting (lihat catatan bug bagian 8 dokumen rencana):
 * masalah CDN pihak ketiga (mis. Cloudflare) bisa bikin client gagal
 * download walau server Minecraft-nya sehat. Self-host langsung dari
 * server sendiri menghindari lapisan kegagalan itu — TAPI tim wajib
 * pastikan port yang dipakai di sini accessible dari luar (firewall/NAT)
 * kalau server di-hosting bukan di VPS dengan IP publik langsung.
 *
 * Alternatif: kalau tim punya CDN/hosting terpercaya, isi
 * "resource-pack.external-url" di config.yml dan set "self-host: false"
 * — modul ResourcePackModule akan pakai URL itu langsung, server HTTP
 * ini tidak akan dijalankan sama sekali.
 */
public class ResourcePackServer {

    private final File packFile;
    private final int port;
    private final Logger logger;
    private HttpServer server;
    private ExecutorService executor;

    public ResourcePackServer(File packFile, int port, Logger logger) {
        this.packFile = packFile;
        this.port = port;
        this.logger = logger;
    }

    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/pack.zip", exchange -> {
            try {
                if (!packFile.exists()) {
                    exchange.sendResponseHeaders(404, -1);
                    exchange.close();
                    return;
                }
                byte[] bytes = Files.readAllBytes(packFile.toPath());
                exchange.getResponseHeaders().add("Content-Type", "application/zip");
                exchange.sendResponseHeaders(200, bytes.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(bytes);
                }
            } catch (IOException e) {
                logger.warning("[Audes] ResourcePackServer gagal serve request: " + e);
            } finally {
                exchange.close();
            }
        });
        executor = Executors.newFixedThreadPool(2);
        server.setExecutor(executor);
        server.start();
        logger.info("[Audes] Resource pack HTTP server jalan di port " + port + " (endpoint: /pack.zip).");
    }

    public void stop() {
        if (server != null) {
            server.stop(0);
        }
        if (executor != null) {
            executor.shutdownNow();
        }
    }
}
