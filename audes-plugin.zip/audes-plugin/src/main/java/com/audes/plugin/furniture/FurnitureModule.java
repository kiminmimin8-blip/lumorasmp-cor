package com.audes.plugin.furniture;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import com.audes.plugin.resourcepack.ResourcePackManifest;
import org.bukkit.event.HandlerList;

public class FurnitureModule implements AudesModule {

    private final AudesPlugin plugin;
    private final ResourcePackManifest manifest;
    private FurnitureRegistry registry;
    private FurnitureItemFactory factory;
    private FurnitureListener listener;

    public FurnitureModule(AudesPlugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.manifest = manifest;
    }

    @Override
    public String getName() {
        return "furniture";
    }

    @Override
    public void enable() {
        registry = new FurnitureRegistry(plugin);
        registry.loadFromConfig(plugin.getConfig().getConfigurationSection("furniture"));
        factory = new FurnitureItemFactory(plugin, manifest);
        listener = new FurnitureListener(registry, factory);
        plugin.getServer().getPluginManager().registerEvents(listener, plugin);
    }

    @Override
    public void disable() {
        if (listener != null) {
            HandlerList.unregisterAll(listener);
        }
    }

    public FurnitureRegistry getRegistry() {
        return registry;
    }

    public FurnitureItemFactory getFactory() {
        return factory;
    }
}
