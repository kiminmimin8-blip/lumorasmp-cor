package com.audes.plugin.tools.effect;

import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/**
 * Dev5 — REVISI dari desain lama: sebelumnya ToolEffect#trigger(Player)
 * cuma dikasih attacker, jadi efek yang butuh tahu SIAPA yang diserang
 * (poison/weakness/ignite/knockback ke korban, dsb) tidak mungkin dibuat
 * tanpa ubah interface. Ini kelihatan pas nambah efek baru untuk prioritas
 * "Custom item trigger/on-use effect" di daftar-fitur-itemsadder.md —
 * makanya interface-nya direvisi di sini, bukan ditambal.
 *
 * user   = player yang pakai/pegang tool (selalu ada, tidak pernah null).
 * target = entity yang diserang (LivingEntity dari EntityDamageByEntityEvent).
 *          TIDAK pernah null untuk efek yang dipicu dari onDamage() saat ini
 *          (CustomToolListener sudah filter event.getEntity() instanceof
 *          LivingEntity sebelum dispatch), tapi tetap diperlakukan sebagai
 *          boleh null di tiap effect (defensive) supaya aman kalau nanti
 *          ada jalur trigger baru yang tidak selalu punya target jelas
 *          (mis. on-use tanpa menyerang siapa pun).
 * originalDamage = damage HASIL SEBELUM efek ini jalan (termasuk
 *          damage-bonus tool kalau ada), berguna untuk efek seperti
 *          lifesteal yang scale dari damage yang dikeluarkan.
 */
public record ToolEffectContext(Player user, LivingEntity target, double originalDamage) {
}
