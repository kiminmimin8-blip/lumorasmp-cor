package com.audes.plugin.tools.effect;

/**
 * Efek "on-use": sembuhkan attacker sebagian dari damage yang baru saja
 * dikeluarkan (context.originalDamage()), dengan peluang tertentu.
 *
 * KETERBATASAN YANG DIKETAHUI (didokumentasikan, bukan silent bug):
 * cap heal dipatok ke 20.0 (max health VANILLA default), BUKAN max health
 * aktual attacker. Attribute max-health yang benar butuh
 * LivingEntity#getAttribute(Attribute...), tapi nama konstanta Attribute
 * untuk max-health SEMPAT berubah antar versi Paper API (era 1.20.5/1.21
 * migrasi dari GENERIC_MAX_HEALTH ke sistem baru) — daripada menebak nama
 * yang mungkin salah dan gagal compile, sengaja dipakai konstanta 20.0
 * sebagai fallback aman. Dampaknya: player dengan max health lebih dari
 * 20 (mis. dari efek/atribut lain) tidak akan ke-heal melebihi 20 lewat
 * efek ini. Perbaiki di sini kalau tim sudah verifikasi nama Attribute
 * yang benar untuk 1.21.11 saat compile.
 */
public class LifestealEffect implements ToolEffect {

    private static final double VANILLA_DEFAULT_MAX_HEALTH = 20.0;

    private final double chance;
    private final double healFraction;

    public LifestealEffect(double chance, double healFraction) {
        this.chance = chance;
        this.healFraction = healFraction;
    }

    @Override
    public void trigger(ToolEffectContext context) {
        if (context.user() == null) return;
        if (Math.random() >= chance) return;
        if (context.originalDamage() <= 0) return;

        double healAmount = context.originalDamage() * healFraction;
        double newHealth = Math.min(VANILLA_DEFAULT_MAX_HEALTH, context.user().getHealth() + healAmount);
        context.user().setHealth(newHealth);
    }
}
