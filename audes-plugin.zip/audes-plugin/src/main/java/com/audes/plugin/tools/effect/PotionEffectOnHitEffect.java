package com.audes.plugin.tools.effect;

import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Efek "on-use" GENERIK: beri PotionEffect ke target yang kena serang,
 * dengan peluang tertentu. Satu class ini dipakai untuk banyak varian
 * (poison, weakness, slowness, dst) lewat instance berbeda yang
 * didaftarkan di ToolEffectRegistry dengan parameter beda-beda —
 * TIDAK perlu bikin class terpisah per jenis potion.
 *
 * COMPILE RISK (belum pernah di-compile, sama seperti file lain di
 * project ini — lihat STATUS-DEV*.md): nama konstanta PotionEffectType
 * (POISON/WEAKNESS/SLOWNESS) mengikuti nama minecraft:id resmi yang
 * seharusnya sudah jadi standar di API Paper 1.20.5+/1.21.x, tapi WAJIB
 * diverifikasi saat compile — versi Bukkit API lama pernah pakai nama
 * lama seperti "SLOW" untuk slowness sebelum di-alias/rename.
 */
public class PotionEffectOnHitEffect implements ToolEffect {

    private final PotionEffectType type;
    private final double chance;
    private final int durationTicks;
    private final int amplifier;

    public PotionEffectOnHitEffect(PotionEffectType type, double chance, int durationTicks, int amplifier) {
        this.type = type;
        this.chance = chance;
        this.durationTicks = durationTicks;
        this.amplifier = amplifier;
    }

    @Override
    public void trigger(ToolEffectContext context) {
        if (context.target() == null) return;
        if (Math.random() >= chance) return;

        context.target().addPotionEffect(new PotionEffect(type, durationTicks, amplifier));
    }
}
