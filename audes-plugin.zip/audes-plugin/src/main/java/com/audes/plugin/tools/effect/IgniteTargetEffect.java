package com.audes.plugin.tools.effect;

/**
 * Efek "on-use": ada peluang menyalakan target yang diserang selama N tick.
 * Pakai LivingEntity#setFireTicks() (API resmi, bukan reflection), dan
 * TIDAK pernah MENGURANGI fire ticks yang sudah lebih lama dari target
 * (mis. kena efek ini 2x berturut-turut) — lihat Math.max di trigger().
 */
public class IgniteTargetEffect implements ToolEffect {

    private final double chance;
    private final int fireTicks;

    public IgniteTargetEffect(double chance, int fireTicks) {
        this.chance = chance;
        this.fireTicks = fireTicks;
    }

    @Override
    public void trigger(ToolEffectContext context) {
        if (context.target() == null) return;
        if (Math.random() >= chance) return;

        context.target().setFireTicks(Math.max(context.target().getFireTicks(), fireTicks));
    }
}
