package com.audes.plugin.core;

import com.audes.plugin.AudesPlugin;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Mengatur siklus hidup semua modul Audes.
 *
 * Isolasi bug: kalau satu modul gagal enable(), modul itu ditandai
 * "failed" dan di-skip, tapi modul lain tetap jalan dan plugin tetap
 * hidup. Ini langsung menjawab poin bug pattern ItemsAdder yang paling
 * sering dilaporkan: "plugin nonaktif sendiri tanpa exception handling
 * yang baik" (lihat bagian 4 dokumen rencana).
 */
public class ModuleManager {

    private final AudesPlugin plugin;
    private final Map<String, AudesModule> modules = new LinkedHashMap<>();
    private final Map<String, Boolean> status = new LinkedHashMap<>();

    public ModuleManager(AudesPlugin plugin) {
        this.plugin = plugin;
    }

    public void register(AudesModule module) {
        modules.put(module.getName(), module);
    }

    /**
     * Enable semua modul yang terdaftar & di-set true di config.yml
     * ("modules:" section). Dipanggil dari AudesPlugin#onEnable().
     */
    public void enableAll() {
        for (AudesModule module : modules.values()) {
            String key = module.getName();
            boolean enabledInConfig = plugin.getConfig()
                    .getBoolean("modules." + key, true);

            if (!enabledInConfig) {
                plugin.getLogger().info("[Audes] Modul '" + key + "' dinonaktifkan lewat config.yml, di-skip.");
                status.put(key, false);
                continue;
            }

            try {
                module.enable();
                status.put(key, true);
                plugin.getLogger().info("[Audes] Modul '" + key + "' berhasil di-enable.");
            } catch (Throwable t) {
                // Sengaja tangkap Throwable (bukan cuma Exception) supaya
                // Error sekalipun (mis. NoClassDefFoundError akibat versi
                // server yang belum kompatibel) tidak menjatuhkan plugin.
                status.put(key, false);
                plugin.getLogger().severe("[Audes] Modul '" + key + "' GAGAL di-enable, modul ini dinonaktifkan "
                        + "tapi plugin tetap jalan. Penyebab: " + t);
                t.printStackTrace();
            }
        }
    }

    public void disableAll() {
        for (Map.Entry<String, Boolean> entry : status.entrySet()) {
            if (!Boolean.TRUE.equals(entry.getValue())) continue;
            AudesModule module = modules.get(entry.getKey());
            try {
                module.disable();
            } catch (Throwable t) {
                plugin.getLogger().severe("[Audes] Error saat disable modul '" + module.getName() + "': " + t);
            }
        }
    }

    public boolean isActive(String moduleName) {
        return Boolean.TRUE.equals(status.get(moduleName));
    }
}
