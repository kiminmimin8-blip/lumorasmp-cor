package com.audes.plugin.furniture;

import com.audes.plugin.resourcepack.ResourcePackManifest;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

/**
 * Membuat item furniture (placeable) dan pasangan entity representasinya
 * di dunia: ItemDisplay (visual) + Interaction (hitbox klik/serang).
 *
 * BEDA DENGAN CUSTOM BLOCK (lihat BlockItemFactory): furniture di sini
 * murni ENTITY, bukan block asli.
 * - TIDAK butuh workaround PersistentDataContainer di Chunk — entity
 *   sudah punya PDC sendiri secara native (Entity implements
 *   PersistentDataHolder), dan otomatis ikut ke-save/load bareng
 *   chunk-nya oleh server tanpa kode tambahan.
 * - Bisa diposisikan bebas (termasuk offset dari grid block) dan di-scale
 *   lewat Transformation — ini keunggulan teknik ItemDisplay (Paper
 *   1.19.4+) dibanding trik ArmorStand yang dipakai furniture plugin
 *   generasi sebelumnya.
 * - Konsekuensi: kalau ada command/plugin lain yang mass-remove entity
 *   (mis. "/kill @e" tanpa filter), furniture bisa hilang tanpa lewat
 *   FurnitureListener (lihat TODO di sana).
 */
public class FurnitureItemFactory {

    public static final String FURNITURE_ID_KEY = "furniture_id";
    private static final String LINK_KEY = "furniture_link";
    private static final String STATE_KEY = "furniture_state";

    private final Plugin plugin;
    private final NamespacedKey furnitureIdKey;
    private final NamespacedKey linkKey;
    private final NamespacedKey stateKey;
    private final ResourcePackManifest manifest;

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    public FurnitureItemFactory(Plugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.furnitureIdKey = new NamespacedKey(plugin, FURNITURE_ID_KEY);
        this.linkKey = new NamespacedKey(plugin, LINK_KEY);
        this.stateKey = new NamespacedKey(plugin, STATE_KEY);
        this.manifest = manifest;
    }

    /**
     * Bikin ItemStack yang kalau di-place jadi furniture ini, pakai
     * state awal (index 0 -- kalau def.states() tidak kosong, ini
     * berarti states.get(0); kalau kosong, pakai def.modelKey() biasa).
     */
    public ItemStack create(FurnitureDefinition def) {
        return createWithState(def, 0);
    }

    /**
     * Dev9: sama seperti create(), tapi pakai modelKey dari state
     * tertentu kalau def.states() diisi. Dipakai FurnitureListener saat
     * toggle state furniture yang sudah di-place (lihat applyState()).
     */
    public ItemStack createWithState(FurnitureDefinition def, int stateIndex) {
        ItemStack item = new ItemStack(def.displayMaterial());
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(LEGACY.deserialize(def.displayName()));
            meta.getPersistentDataContainer().set(furnitureIdKey, PersistentDataType.STRING, def.id());
            applyModelIfAvailable(meta, resolveModelKey(def, stateIndex));
            item.setItemMeta(meta);
        }
        return item;
    }

    private String resolveModelKey(FurnitureDefinition def, int stateIndex) {
        if (def.states().isEmpty()) return def.modelKey();
        int safeIndex = ((stateIndex % def.states().size()) + def.states().size()) % def.states().size();
        return def.states().get(safeIndex);
    }

    private void applyModelIfAvailable(ItemMeta meta, String modelKey) {
        if (modelKey == null || modelKey.isBlank()) return;

        if (!manifest.hasModel(modelKey)) {
            manifest.warnMissingOnce(modelKey, "furniture (FurnitureItemFactory)");
            return;
        }

        NamespacedKey key = NamespacedKey.fromString(modelKey);
        if (key == null) {
            plugin.getLogger().warning("[Audes] modelKey '" + modelKey
                    + "' di furniture bukan format 'namespace:path' yang valid, di-skip.");
            return;
        }
        meta.setItemModel(key);
    }

    public String getFurnitureId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        return meta.getPersistentDataContainer().get(furnitureIdKey, PersistentDataType.STRING);
    }

    /**
     * Spawn ItemDisplay (visual) + Interaction (hitbox) di lokasi tertentu,
     * saling terhubung lewat PDC berisi UUID satu sama lain supaya break
     * salah satunya bisa menemukan & membersihkan pasangannya.
     */
    public void spawn(Location location, FurnitureDefinition def) {
        ItemDisplay display = location.getWorld().spawn(location, ItemDisplay.class, entity -> {
            // Pakai create(def) (bukan "new ItemStack(def.displayMaterial())" polos)
            // supaya visual di dunia ikut pakai setItemModel() kalau asetnya ada --
            // konsisten dengan item yang dipegang player di inventory.
            entity.setItemStack(create(def));
            entity.setTransformation(new Transformation(
                    new Vector3f(0f, 0f, 0f),
                    new AxisAngle4f(0f, 0f, 0f, 1f),
                    new Vector3f(def.scale(), def.scale(), def.scale()),
                    new AxisAngle4f(0f, 0f, 0f, 1f)
            ));
            entity.getPersistentDataContainer().set(furnitureIdKey, PersistentDataType.STRING, def.id());
            entity.getPersistentDataContainer().set(stateKey, PersistentDataType.INTEGER, 0);
        });

        Interaction interaction = location.getWorld().spawn(location, Interaction.class, entity -> {
            entity.setInteractionWidth((float) def.interactionWidth());
            entity.setInteractionHeight((float) def.interactionHeight());
            entity.setResponsive(true);
            entity.getPersistentDataContainer().set(furnitureIdKey, PersistentDataType.STRING, def.id());
            entity.getPersistentDataContainer().set(linkKey, PersistentDataType.STRING,
                    display.getUniqueId().toString());
        });

        display.getPersistentDataContainer().set(linkKey, PersistentDataType.STRING,
                interaction.getUniqueId().toString());
    }

    public NamespacedKey furnitureIdKey() {
        return furnitureIdKey;
    }

    public NamespacedKey linkKey() {
        return linkKey;
    }

    public NamespacedKey stateKey() {
        return stateKey;
    }

    /**
     * Dev9: baca state index yang tersimpan di ItemDisplay (default 0
     * kalau belum pernah di-set -- mis. furniture lama yang di-place
     * sebelum fitur states ada).
     */
    public int getState(ItemDisplay display) {
        Integer value = display.getPersistentDataContainer().get(stateKey, PersistentDataType.INTEGER);
        return value != null ? value : 0;
    }

    /**
     * Dev9: ganti visual ItemDisplay yang SUDAH di-place ke state index
     * tertentu (tidak spawn ulang entity, cuma update item stack-nya
     * pakai model dari def.states().get(stateIndex)) dan catat index
     * barunya ke PDC supaya persist lewat restart server.
     */
    public void applyState(ItemDisplay display, FurnitureDefinition def, int stateIndex) {
        int safeIndex = def.states().isEmpty() ? 0
                : ((stateIndex % def.states().size()) + def.states().size()) % def.states().size();
        display.setItemStack(createWithState(def, safeIndex));
        display.getPersistentDataContainer().set(stateKey, PersistentDataType.INTEGER, safeIndex);
    }
}
