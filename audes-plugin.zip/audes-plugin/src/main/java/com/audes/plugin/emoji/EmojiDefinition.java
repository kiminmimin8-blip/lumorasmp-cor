package com.audes.plugin.emoji;

/**
 * Satu definisi emoji dari config.yml bagian "emoji:". "replacement"
 * disimpan mentah (string legacy '&' color code) supaya bisa berwarna,
 * di-convert ke Component saat dipakai (lihat EmojiManager).
 *
 * CATATAN SOAL "buku/hologram" di fitur asli ItemsAdder: implementasi
 * ini SENGAJA baru mencakup CHAT (lihat EmojiListener). Audes belum
 * punya modul book/hologram sama sekali, jadi "emoji di buku/hologram"
 * dari fitur asli ItemsAdder belum relevan untuk diimplementasikan --
 * TAPI EmojiManager#apply() sengaja dibuat generik (terima & kembalikan
 * Component, bukan spesifik ke chat) supaya kalau nanti ada modul book
 * atau integrasi hologram (mis. DecentHolograms lewat placeholder),
 * tinggal panggil method yang sama tanpa perlu bikin sistem emoji kedua.
 */
public record EmojiDefinition(
        String shortcode, // tanpa titik dua, mis. "smile" untuk token ":smile:"
        String replacement
) {
}
