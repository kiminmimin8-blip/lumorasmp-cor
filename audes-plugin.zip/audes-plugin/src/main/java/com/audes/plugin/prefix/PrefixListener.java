package com.audes.plugin.prefix;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

/**
 * Menerapkan prefix ke chat (via AsyncChatEvent, bukan legacy
 * AsyncPlayerChatEvent yang deprecated), ke player list name saat
 * join, dan ke nametag di atas kepala (show-above-head). Update tab
 * list detail (grouping/urutan) ditangani modul rank-tab (RankTabModule)
 * lewat team terpisah — di sini cuma pasang nama dasar supaya kedua
 * modul tidak saling override.
 *
 * Dev4: nametag above-head pakai scoreboard Team sendiri dengan prefix
 * nama "audes_head_" supaya TIDAK bentrok dengan nama team yang dipakai
 * TabListManager (pola "%02d_%s" di rank-tab) — sesuai catatan Dev3.
 * Modul ini jalan independen; kalau rank-tab modul dimatikan lewat
 * config, above-head tetap berfungsi karena tidak bergantung ke
 * TabListManager sama sekali.
 *
 * Format warna pakai kode legacy '&' di config.yml supaya gampang
 * ditulis tim non-teknis, di-convert ke Component pakai
 * LegacyComponentSerializer.
 */
public class PrefixListener implements Listener {

    private static final String HEAD_TEAM_PREFIX = "audes_head_";

    private final PrefixManager prefixManager;
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&')
            .build();

    public PrefixListener(PrefixManager prefixManager) {
        this.prefixManager = prefixManager;
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        PrefixDefinition def = prefixManager.getDefinitionFor(player);
        if (def == null || !def.showInChat()) return;

        Component prefixComponent = LEGACY.deserialize(def.text());
        Component original = event.message();

        event.renderer((source, sourceDisplayName, message, viewer) ->
                prefixComponent.append(sourceDisplayName).append(Component.text(": ")).append(message));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        PrefixDefinition def = prefixManager.getDefinitionFor(player);
        if (def == null) return;

        // Tab list name dasar; grouping & urutan lengkap di-handle RankTabModule.
        if (def.showInTabList()) {
            Component name = LEGACY.deserialize(def.text()).append(Component.text(player.getName()));
            player.playerListName(name);
        }

        updateAboveHead(player);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        removeFromHeadTeam(event.getPlayer());
    }

    /**
     * Pasang/lepas nametag above-head sesuai definisi prefix player saat ini.
     * Dipanggil saat join, dan WAJIB dipanggil lagi oleh caller manapun yang
     * mengubah rank player (mis. command /audes setrank) supaya nametag
     * ikut ter-update real-time tanpa nunggu rejoin.
     */
    public void updateAboveHead(Player player) {
        PrefixDefinition def = prefixManager.getDefinitionFor(player);
        Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();

        // Lepas dulu dari head-team lama kalau ada (rank bisa berubah).
        Team existing = findHeadTeam(board, player);
        if (existing != null) {
            existing.removeEntry(player.getName());
        }

        if (def == null || !def.showAboveHead()) {
            return;
        }

        String teamName = HEAD_TEAM_PREFIX + safeSuffix(def.rankKey());
        Team team = board.getTeam(teamName);
        if (team == null) {
            team = board.registerNewTeam(teamName);
        }
        team.prefix(LEGACY.deserialize(def.text()));
        if (!team.hasEntry(player.getName())) {
            team.addEntry(player.getName());
        }
    }

    private void removeFromHeadTeam(Player player) {
        Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();
        Team team = findHeadTeam(board, player);
        if (team != null) {
            team.removeEntry(player.getName());
        }
    }

    private Team findHeadTeam(Scoreboard board, Player player) {
        Team team = board.getEntryTeam(player.getName());
        // Cuma anggap "milik kita" kalau namanya memang head-team Audes —
        // supaya tidak salah lepas player dari team rank-tab atau team
        // plugin lain yang kebetulan dia ikuti juga.
        return (team != null && team.getName().startsWith(HEAD_TEAM_PREFIX)) ? team : null;
    }

    // Nama team dibatasi panjang di beberapa versi; jaga tetap pendek & aman.
    private String safeSuffix(String rankKey) {
        return rankKey.length() > 10 ? rankKey.substring(0, 10) : rankKey;
    }
}
