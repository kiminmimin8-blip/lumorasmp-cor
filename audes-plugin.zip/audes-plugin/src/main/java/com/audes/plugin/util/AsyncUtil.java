package com.audes.plugin.util;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Helper kecil untuk pola "kerjakan berat di async thread, apply hasil
 * di main thread" — dipakai semua modul yang butuh I/O atau kerja berat
 * (load config besar, nanti resource pack generator, dsb), sesuai
 * prinsip async di bagian 3 dokumen rencana.
 *
 * PENTING: JANGAN PERNAH sentuh Bukkit API (world, entity, inventory,
 * dst) dari dalam `heavyWork`. Bukkit API hanya boleh dipanggil dari
 * `onMainThread`.
 */
public final class AsyncUtil {

    private AsyncUtil() {}

    public static <T> void runAsyncThenSync(Plugin plugin, Supplier<T> heavyWork, Consumer<T> onMainThread) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            T result;
            try {
                result = heavyWork.get();
            } catch (Throwable t) {
                plugin.getLogger().severe("[Audes] Async task gagal: " + t);
                t.printStackTrace();
                return;
            }
            Bukkit.getScheduler().runTask(plugin, () -> onMainThread.accept(result));
        });
    }
}
