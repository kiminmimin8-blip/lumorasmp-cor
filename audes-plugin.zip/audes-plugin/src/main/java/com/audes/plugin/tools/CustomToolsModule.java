package com.audes.plugin.tools;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import com.audes.plugin.resourcepack.ResourcePackManifest;
import com.audes.plugin.tools.effect.ToolEffectRegistry;
import org.bukkit.event.HandlerList;

public class CustomToolsModule implements AudesModule {

    private final AudesPlugin plugin;
    private final ResourcePackManifest manifest;
    private ToolRegistry registry;
    private ToolFactory factory;
    private ToolEffectRegistry effectRegistry;
    private CustomToolListener listener;

    public CustomToolsModule(AudesPlugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.manifest = manifest;
    }

    @Override
    public String getName() {
        return "custom-tools";
    }

    @Override
    public void enable() {
        registry = new ToolRegistry(plugin);
        registry.loadFromConfig(plugin.getConfig().getConfigurationSection("tools"));
        factory = new ToolFactory(plugin, manifest);
        effectRegistry = new ToolEffectRegistry();
        listener = new CustomToolListener(registry, factory, effectRegistry);
        plugin.getServer().getPluginManager().registerEvents(listener, plugin);
    }

    @Override
    public void disable() {
        if (listener != null) {
            HandlerList.unregisterAll(listener);
        }
    }

    public ToolRegistry getRegistry() {
        return registry;
    }

    public ToolFactory getFactory() {
        return factory;
    }

    public ToolEffectRegistry getEffectRegistry() {
        return effectRegistry;
    }
}
