package com.audes.plugin.emoji;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import org.bukkit.event.HandlerList;

public class EmojiModule implements AudesModule {

    private final AudesPlugin plugin;
    private EmojiRegistry registry;
    private EmojiManager manager;
    private EmojiListener listener;

    public EmojiModule(AudesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getName() {
        return "emoji";
    }

    @Override
    public void enable() {
        registry = new EmojiRegistry(plugin);
        registry.loadFromConfig(plugin.getConfig().getConfigurationSection("emoji"));
        manager = new EmojiManager(registry);
        listener = new EmojiListener(manager);
        plugin.getServer().getPluginManager().registerEvents(listener, plugin);
    }

    @Override
    public void disable() {
        if (listener != null) {
            HandlerList.unregisterAll(listener);
        }
    }

    public EmojiRegistry getRegistry() {
        return registry;
    }

    /** Dipakai modul lain nanti (book/hologram) kalau butuh substitusi emoji juga. */
    public EmojiManager getManager() {
        return manager;
    }
}
