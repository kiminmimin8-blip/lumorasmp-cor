package com.audes.plugin.ranktab;

import com.audes.plugin.event.AudesRankChangeEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class RankTabListener implements Listener {

    private final TabListManager tabListManager;

    public RankTabListener(TabListManager tabListManager) {
        this.tabListManager = tabListManager;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        tabListManager.updatePlayer(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        tabListManager.removePlayer(event.getPlayer());
    }

    /**
     * Real-time update: begitu rank player berubah (lihat
     * AudesRankChangeEvent), tab list langsung disusun ulang tanpa
     * nunggu periodic refresh berikutnya.
     */
    @EventHandler
    public void onRankChange(AudesRankChangeEvent event) {
        Player player = event.getPlayer();
        tabListManager.updatePlayer(player);
    }
}
