package com.audes.plugin.resourcepack;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import com.audes.plugin.util.AsyncUtil;
import org.bukkit.event.HandlerList;

import java.io.File;

/**
 * Generator + host resource pack untuk custom item model Audes.
 *
 * Dev4: diimplementasikan berdasarkan skeleton/TODO Dev3. Alur:
 * 1. enable() cek folder data/contents/ ada isinya atau tidak. Kalau
 *    kosong/tidak ada, modul tetap "aktif" (bukan error) tapi cuma
 *    log info supaya tim yang belum siapkan aset custom tidak
 *    dianggap modul ini gagal.
 * 2. Generate zip dari contents/ WAJIB async (ResourcePackGenerator
 *    baca banyak file + hitung SHA-1, keduanya I/O berat, lihat
 *    prinsip async di AsyncUtil/bagian 3 dokumen rencana).
 * 3. Guard ukuran: 250MB block (generate gagal eksplisit, bukan silent
 *    fail), 100MB warning di log.
 * 4. Hosting: self-host via ResourcePackServer (HTTP server bawaan JDK)
 *    KECUALI config "resource-pack.self-host" = false, dalam hal ini
 *    pakai "resource-pack.external-url" langsung (tim sudah punya
 *    CDN/hosting sendiri).
 * 5. Kirim ke player saat join lewat ResourcePackJoinListener
 *    (Adventure ResourcePackRequest, native Paper, hash-validated).
 *
 * Dev5: manifest sekarang SUDAH ADA (ResourcePackManifest) -- prioritas #3
 * di daftar-fitur-itemsadder.md. Manifest di-rebuild di sini (di dalam
 * heavyWork async, sama-sama I/O seperti generate zip) lalu ToolFactory/
 * BlockItemFactory/FurnitureItemFactory query manifest ini tiap create()
 * untuk tahu apakah modelKey mereka benar-benar punya aset di contents/.
 *
 * TODO untuk dev berikutnya:
 * - /audes reload belum trigger regenerate pack ATAU rebuild manifest,
 *   kalau tim update aset di contents/ sambil server jalan, saat ini
 *   masih perlu restart plugin/server. Prioritas kecil untuk ditambah
 *   nanti sebagai /audes resourcepack regenerate.
 */
public class ResourcePackModule implements AudesModule {

    private final AudesPlugin plugin;
    private final ResourcePackManifest manifest;
    private ResourcePackServer server;
    private ResourcePackJoinListener joinListener;

    public ResourcePackModule(AudesPlugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.manifest = manifest;
    }

    @Override
    public String getName() {
        return "resource-pack";
    }

    @Override
    public void enable() {
        // Aktif/nonaktifnya modul ini diatur lewat "modules.resource-pack"
        // di config.yml (konsisten dengan modul lain, lihat ModuleManager)
        // -- tidak ada toggle kedua di dalam sini supaya tidak membingungkan.
        File contentsFolder = new File(plugin.getDataFolder(), "contents");
        if (!contentsFolder.exists()) {
            contentsFolder.mkdirs();
            plugin.getLogger().info("[Audes] Folder 'contents/' dibuat kosong di " + contentsFolder.getAbsolutePath()
                    + " -- isi struktur namespace aset resource pack di sini, lalu restart plugin untuk generate.");
            return;
        }

        File outputZip = new File(plugin.getDataFolder(), "audes-pack.zip");
        boolean selfHost = plugin.getConfig().getBoolean("resource-pack.self-host", true);
        int port = plugin.getConfig().getInt("resource-pack.port", 8231);
        String publicAddress = plugin.getConfig().getString("resource-pack.public-address", "");
        String externalUrl = plugin.getConfig().getString("resource-pack.external-url", "");
        boolean required = plugin.getConfig().getBoolean("resource-pack.required", false);
        String promptMessage = plugin.getConfig().getString("resource-pack.prompt-message", "");

        // Generate WAJIB async -- I/O berat (baca semua file contents/ + hitung SHA-1
        // + sekarang juga rebuild manifest, sama-sama I/O jadi digabung di task yang sama).
        AsyncUtil.runAsyncThenSync(
                plugin,
                () -> {
                    // Rebuild manifest DULUAN, terlepas dari sukses/gagalnya zip di bawah --
                    // supaya validasi modelKey tetap jalan meski generate zip gagal
                    // (mis. lewat batas 250MB), bukan ikut gagal total.
                    int modelCount = manifest.rebuild(contentsFolder);
                    ResourcePackGenerator.Result zipResult;
                    try {
                        zipResult = new ResourcePackGenerator().generate(contentsFolder, outputZip);
                    } catch (Exception e) {
                        plugin.getLogger().severe("[Audes] Gagal generate resource pack: " + e.getMessage());
                        zipResult = null;
                    }
                    return new GenerateOutcome(zipResult, modelCount);
                },
                outcome -> {
                    plugin.getLogger().info("[Audes] Manifest resource pack: " + outcome.modelCount()
                            + " item model terdaftar dari contents/assets/*/items/, "
                            + manifest.equipmentModelCount() + " equipment model dari contents/assets/*/equipment/.");

                    ResourcePackGenerator.Result result = outcome.zipResult();
                    if (result == null) {
                        // Generate gagal (sudah di-log di atas dengan pesan jelas,
                        // bukan silent fail) -- modul tetap "hidup" tapi tanpa kirim pack.
                        // Manifest tetap ke-rebuild jadi setItemModel() tetap bisa
                        // apply untuk model yang asetnya ada, meski pack belum terkirim.
                        return;
                    }

                    if (result.overWarnThreshold()) {
                        plugin.getLogger().warning("[Audes] Resource pack berukuran " + (result.sizeBytes() / (1024 * 1024))
                                + "MB, sudah lewat ambang 100MB -- pertimbangkan kompresi aset/texture "
                                + "supaya player koneksi lambat tidak gagal download (lihat bagian 8 dokumen rencana).");
                    }
                    plugin.getLogger().info("[Audes] Resource pack ter-generate (" + (result.sizeBytes() / 1024)
                            + "KB, sha1=" + result.sha1Hex() + ").");

                    String url;
                    if (selfHost) {
                        if (publicAddress == null || publicAddress.isBlank()) {
                            plugin.getLogger().severe("[Audes] resource-pack.self-host aktif tapi 'public-address' "
                                    + "belum diisi di config.yml -- pack TIDAK bisa dikirim ke player karena URL tidak "
                                    + "diketahui. Isi IP/domain publik server di config, lalu reload.");
                            return;
                        }
                        try {
                            server = new ResourcePackServer(outputZip, port, plugin.getLogger());
                            server.start();
                        } catch (Exception e) {
                            plugin.getLogger().severe("[Audes] Gagal start ResourcePackServer di port " + port + ": " + e);
                            return;
                        }
                        url = "http://" + publicAddress + ":" + port + "/pack.zip";
                    } else {
                        if (externalUrl == null || externalUrl.isBlank()) {
                            plugin.getLogger().severe("[Audes] resource-pack.self-host = false tapi 'external-url' "
                                    + "kosong -- isi URL CDN/hosting pack di config.yml.");
                            return;
                        }
                        url = externalUrl;
                    }

                    joinListener = new ResourcePackJoinListener(url, result.sha1Hex(), required, promptMessage);
                    plugin.getServer().getPluginManager().registerEvents(joinListener, plugin);
                    plugin.getLogger().info("[Audes] Resource pack siap dikirim ke player dari: " + url);
                }
        );
    }

    @Override
    public void disable() {
        if (joinListener != null) {
            HandlerList.unregisterAll(joinListener);
        }
        if (server != null) {
            server.stop();
        }
    }

    /** Hasil gabungan satu siklus heavyWork: zip pack (nullable kalau gagal) + jumlah model termuat. */
    private record GenerateOutcome(ResourcePackGenerator.Result zipResult, int modelCount) {
    }
}
