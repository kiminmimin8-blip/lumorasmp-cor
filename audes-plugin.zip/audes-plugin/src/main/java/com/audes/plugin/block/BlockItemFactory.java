package com.audes.plugin.block;

import com.audes.plugin.resourcepack.ResourcePackManifest;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

/**
 * Membuat ItemStack untuk custom block (item yang bisa di-place), dan
 * mengelola pencatatan "block di lokasi ini custom block Audes yang
 * mana".
 *
 * KENAPA LEWAT CHUNK, BUKAN LEWAT BLOCK ITU SENDIRI: NOTE_BLOCK bukan
 * TileState/BlockEntity, jadi tidak punya PersistentDataContainer
 * sendiri seperti chest/furnace. Solusinya (teknik yang sama dipakai
 * library CustomBlockData yang lazim di ekosistem Paper): simpan data
 * di PersistentDataContainer milik Chunk, dengan satu NamespacedKey unik
 * per koordinat block. Ini API resmi Paper, bukan reflection/NMS.
 *
 * KETERBATASAN YANG SUDAH DIKETAHUI (didokumentasikan biar dev
 * berikutnya tidak kaget):
 * - Data ini TIDAK otomatis terhapus kalau block dihancurkan lewat cara
 *   di luar BlockBreakEvent normal (mis. explosion, piston, WorldEdit).
 *   CustomBlockListener baru menangani BlockBreakEvent — penanganan
 *   explosion/piston/dsb masih TODO, sama seperti reload penuh yang
 *   masih pending di modul lain.
 * - PDC per-koordinat berarti banyak key kecil menumpuk di satu chunk
 *   kalau banyak custom block dipasang rapat. Untuk skala LumoraSMP
 *   (server survival, bukan ribuan block per chunk) ini masih wajar,
 *   tapi kalau nanti dipakai skala besar, pertimbangkan struktur data
 *   terkompresi (mis. satu key berisi map serialized) alih-alih satu
 *   key per block.
 */
public class BlockItemFactory {

    public static final String BLOCK_ID_KEY = "block_id";
    private static final String CHUNK_KEY_PREFIX = "audes_block_";

    private final Plugin plugin;
    private final NamespacedKey blockIdKey;
    private final ResourcePackManifest manifest;

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    public BlockItemFactory(Plugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.blockIdKey = new NamespacedKey(plugin, BLOCK_ID_KEY);
        this.manifest = manifest;
    }

    /**
     * Bikin ItemStack yang kalau di-place jadi custom block ini.
     *
     * Dev5: setItemModel() sekarang diterapkan ke ITEM-nya (yang dipegang
     * di inventory/hotbar) kalau manifest konfirmasi asetnya ada -- ini
     * membuat item di tangan/inventory tampil dengan tekstur custom.
     * TIDAK mengubah tampilan block yang SUDAH di-place di dunia (itu
     * masih pakai teknik note+instrument di CustomBlockListener), karena
     * Paper/Mojang belum expose block model override resmi per riset ini
     * ditulis (lihat catatan di BlockDefinition).
     */
    public ItemStack create(BlockDefinition def) {
        ItemStack item = new ItemStack(Material.NOTE_BLOCK);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(LEGACY.deserialize(def.displayName()));
            meta.getPersistentDataContainer().set(blockIdKey, PersistentDataType.STRING, def.id());
            applyModelIfAvailable(meta, def.modelKey());
            item.setItemMeta(meta);
        }
        return item;
    }

    private void applyModelIfAvailable(ItemMeta meta, String modelKey) {
        if (modelKey == null || modelKey.isBlank()) return;

        if (!manifest.hasModel(modelKey)) {
            manifest.warnMissingOnce(modelKey, "block (BlockItemFactory)");
            return;
        }

        NamespacedKey key = NamespacedKey.fromString(modelKey);
        if (key == null) {
            plugin.getLogger().warning("[Audes] modelKey '" + modelKey
                    + "' di block bukan format 'namespace:path' yang valid, di-skip.");
            return;
        }
        meta.setItemModel(key);
    }

    /** Return block id kalau item ini custom block Audes, null kalau bukan. */
    public String getBlockId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        return meta.getPersistentDataContainer().get(blockIdKey, PersistentDataType.STRING);
    }

    /** Catat bahwa block di lokasi ini adalah custom block dengan id tertentu. */
    public void markPlaced(Location location, String blockId) {
        Chunk chunk = location.getChunk();
        chunk.getPersistentDataContainer().set(chunkBlockKey(location), PersistentDataType.STRING, blockId);
    }

    /** Ambil kembali block id yang tercatat di lokasi ini, null kalau bukan custom block. */
    public String getPlacedBlockId(Location location) {
        Chunk chunk = location.getChunk();
        return chunk.getPersistentDataContainer().get(chunkBlockKey(location), PersistentDataType.STRING);
    }

    /**
     * Hapus catatan saat block di-break. WAJIB dipanggil setiap kali block
     * hilang dari dunia (lihat batasan explosion/piston di javadoc kelas),
     * supaya PDC chunk tidak menumpuk key basi selamanya.
     */
    public void clearPlaced(Location location) {
        Chunk chunk = location.getChunk();
        chunk.getPersistentDataContainer().remove(chunkBlockKey(location));
    }

    private NamespacedKey chunkBlockKey(Location location) {
        // Koordinat LOKAL dalam chunk (0-15) untuk x/z supaya key pendek &
        // konsisten. Y dibiarkan absolut (bisa negatif di dunia modern,
        // mis. -64) — karakter "-" valid di NamespacedKey key seperti
        // namespace vanilla lain yang memakainya.
        int localX = location.getBlockX() & 0xF;
        int y = location.getBlockY();
        int localZ = location.getBlockZ() & 0xF;
        return new NamespacedKey(plugin, CHUNK_KEY_PREFIX + localX + "_" + y + "_" + localZ);
    }
}
