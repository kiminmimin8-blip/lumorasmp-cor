package com.audes.plugin.emoji;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextReplacementConfig;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

/**
 * Satu titik masuk untuk substitusi emoji ke Component APAPUN (chat
 * sekarang, book/hologram nanti kalau modulnya ada -- lihat catatan di
 * EmojiDefinition). Sengaja dipisah dari EmojiListener supaya reusable.
 *
 * TEKNIK: pakai Component#replaceText(TextReplacementConfig) dari
 * Adventure API -- satu pass regex (lihat EmojiRegistry#getCombinedPattern)
 * yang match SEMUA shortcode terdaftar sekaligus, bukan N kali replaceText
 * terpisah per shortcode. Ini penting buat performa karena method ini
 * dipanggil di jalur chat (AsyncChatEvent), yang jalan tiap kali ada
 * pesan chat di server.
 *
 * COMPILE RISK (belum diverifikasi, ikuti pola jujur project):
 * Component#replaceText(TextReplacementConfig) diasumsikan tersedia di
 * versi Adventure yang di-bundle Paper 1.21.11. Method ini API Adventure
 * yang relatif lama & stabil (bukan komponen baru ala equippable/item
 * model), jadi risiko lebih rendah dibanding compile risk Dev6/Dev7,
 * tapi tetap dicatat sesuai konvensi.
 */
public class EmojiManager {

    private final EmojiRegistry registry;
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    public EmojiManager(EmojiRegistry registry) {
        this.registry = registry;
    }

    public Component apply(Component input) {
        if (registry.getAll().isEmpty()) return input;

        TextReplacementConfig config = TextReplacementConfig.builder()
                .match(registry.getCombinedPattern())
                .replacement((matchResult, builder) -> {
                    String shortcode = matchResult.group(1);
                    return registry.get(shortcode)
                            .map(def -> LEGACY.deserialize(def.replacement()))
                            .orElse(Component.text(matchResult.group())); // fallback: tampil apa adanya kalau somehow tidak ketemu
                })
                .build();

        return input.replaceText(config);
    }
}
