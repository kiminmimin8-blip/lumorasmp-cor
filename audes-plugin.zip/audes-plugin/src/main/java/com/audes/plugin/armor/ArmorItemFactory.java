package com.audes.plugin.armor;

import com.audes.plugin.resourcepack.ResourcePackManifest;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Color;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.components.EquippableComponent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

/**
 * Membuat item custom armor lewat komponen native "equippable"
 * (org.bukkit.inventory.meta.components.EquippableComponent, Paper API
 * 1.21.2+). Base item TETAP armor vanilla asli (lihat catatan di
 * ArmorDefinition kenapa) -- yang di-custom cuma tampilannya lewat
 * assetId, dipetakan resource pack ke
 * contents/assets/&lt;namespace&gt;/equipment/&lt;path&gt;.json.
 *
 * COMPILE RISK (belum pernah di-compile saat ditulis, ikuti pola jujur
 * project ini): method EquippableComponent#setModel(NamespacedKey) dan
 * ItemMeta#getEquippable()/setEquippable(...) diasumsikan tersedia di
 * paper-api 1.21.11 berdasarkan riset dokumentasi, TAPI kalau versi
 * paper-api yang ke-resolve beda, ini bisa gagal compile mirip
 * ItemMeta#setItemModel() yang sudah dipakai Dev5 (dan itu ternyata
 * lolos compile, jadi API sejenis kemungkinan besar juga ada).
 */
public class ArmorItemFactory {

    public static final String ARMOR_ID_KEY = "armor_id";

    private final Plugin plugin;
    private final NamespacedKey armorIdKey;
    private final ResourcePackManifest manifest;
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    public ArmorItemFactory(Plugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.armorIdKey = new NamespacedKey(plugin, ARMOR_ID_KEY);
        this.manifest = manifest;
    }

    public ItemStack create(ArmorDefinition def) {
        ItemStack item = new ItemStack(def.baseMaterial());
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(LEGACY.deserialize(def.displayName()));
        meta.getPersistentDataContainer().set(armorIdKey, PersistentDataType.STRING, def.id());

        if (def.dyeable() && meta instanceof LeatherArmorMeta leatherMeta) {
            // Warna dasar netral (putih) supaya tekstur custom di resource
            // pack (assetId) yang mendominasi tampilan, bukan tint leather
            // vanilla yang random/coklat default. Admin bisa override lewat
            // /audes armordye nanti kalau dibutuhkan (belum ada command-nya,
            // TODO untuk dev berikutnya kalau tim butuh recolor per-item).
            leatherMeta.setColor(Color.WHITE);
        }

        applyEquippableIfAvailable(meta, def);

        item.setItemMeta(meta);
        return item;
    }

    private void applyEquippableIfAvailable(ItemMeta meta, ArmorDefinition def) {
        String assetId = def.assetId();
        if (assetId == null || assetId.isBlank()) return;

        if (!manifest.hasEquipmentModel(assetId)) {
            manifest.warnMissingEquipmentOnce(assetId, "armor (ArmorItemFactory, id=" + def.id() + ")");
            return;
        }

        NamespacedKey key = NamespacedKey.fromString(assetId);
        if (key == null) {
            plugin.getLogger().warning("[Audes] asset '" + assetId + "' di armor '" + def.id()
                    + "' bukan format 'namespace:path' yang valid, di-skip.");
            return;
        }

        EquippableComponent component = meta.getEquippable();
        component.setSlot(def.slot());
        component.setModel(key);
        meta.setEquippable(component);
    }

    /** Return armor id kalau item ini custom armor Audes, null kalau bukan. */
    public String getArmorId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        return meta.getPersistentDataContainer().get(armorIdKey, PersistentDataType.STRING);
    }
}
