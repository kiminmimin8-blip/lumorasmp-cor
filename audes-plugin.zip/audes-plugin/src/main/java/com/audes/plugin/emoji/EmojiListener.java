package com.audes.plugin.emoji;

import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

/**
 * KENAPA PRIORITY LOWEST (PENTING, baca sebelum ubah urutan priority di
 * modul manapun yang pegang AsyncChatEvent):
 *
 * PrefixListener.onChat() (priority LOW) pakai event.renderer(...) buat
 * nempelin prefix ke pesan -- renderer itu MENGGANTIKAN seluruh cara
 * pesan di-render, bukan cuma nambah di depan. Kalau EmojiListener juga
 * pasang event.renderer(...) sendiri, salah satu bakal KETIMPA yang lain
 * tergantung urutan eksekusi (event terakhir yang set renderer yang
 * menang) -- ini bakal jadi bug tersembunyi yang gampang kebongkar
 * kalau urutan register modul berubah tanpa sengaja.
 *
 * Solusinya: EmojiListener TIDAK PERNAH sentuh event.renderer() sama
 * sekali. Cukup mutasi event.message() lewat event.message(newValue) di
 * priority LEBIH RENDAH dari PrefixListener (LOWEST < LOW), supaya pesan
 * sudah ke-substitusi emoji-nya SEBELUM PrefixListener baca message()
 * untuk di-render ke renderer-nya. Modul lain yang nanti mau nambah
 * listener AsyncChatEvent WAJIB ikut pola ini: transformasi konten
 * pesan lewat event.message(), reservasi event.renderer() cuma untuk
 * modul yang benar-benar butuh custom render (kayak PrefixListener).
 */
public class EmojiListener implements Listener {

    private final EmojiManager manager;

    public EmojiListener(EmojiManager manager) {
        this.manager = manager;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent event) {
        event.message(manager.apply(event.message()));
    }
}
