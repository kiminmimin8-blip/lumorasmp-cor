package com.audes.plugin.tools;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.Plugin;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class ToolRegistry {

    private final Plugin plugin;
    private final Map<String, ToolDefinition> tools = new LinkedHashMap<>();

    public ToolRegistry(Plugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig(ConfigurationSection toolsSection) {
        tools.clear();
        if (toolsSection == null) return;

        for (String id : toolsSection.getKeys(false)) {
            ConfigurationSection s = toolsSection.getConfigurationSection(id);
            if (s == null) continue;

            Material material;
            try {
                material = Material.valueOf(s.getString("material", "STICK").toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("[Audes] Material tidak valid untuk tool '" + id
                        + "', di-skip. Cek config.yml.");
                continue;
            }

            List<String> onUseEffectKeys = parseEffectKeys(s.getString("on-use-effect", null));

            ToolDefinition def = new ToolDefinition(
                    id,
                    material,
                    s.getString("display-name", id),
                    s.getString("model", null),
                    s.getDouble("attributes.damage-bonus", 0.0),
                    s.getDouble("attributes.durability-multiplier", 1.0),
                    onUseEffectKeys,
                    s.getString("command", null)
            );
            tools.put(id, def);
        }

        plugin.getLogger().info("[Audes] " + tools.size() + " custom tool termuat dari config.");
    }

    /**
     * Dev5: "on-use-effect" sekarang boleh berisi lebih dari satu key,
     * dipisah koma (mis. "LIGHTNING_STRIKE_CHANCE_5,LIFESTEAL_CHANCE_25").
     * Backward compatible dengan config lama yang cuma isi satu key —
     * hasil split-nya tetap list berisi satu elemen.
     */
    private List<String> parseEffectKeys(String raw) {
        if (raw == null || raw.isBlank()) return List.of();
        return Arrays.stream(raw.split(","))
                .map(String::trim)
                .filter(key -> !key.isEmpty())
                .toList();
    }

    public Optional<ToolDefinition> get(String id) {
        return Optional.ofNullable(tools.get(id));
    }

    public Map<String, ToolDefinition> getAll() {
        return tools;
    }
}
