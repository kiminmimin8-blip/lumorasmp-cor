package com.audes.plugin.prefix;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import org.bukkit.event.HandlerList;

public class PrefixModule implements AudesModule {

    private final AudesPlugin plugin;
    private final PrefixManager manager = new PrefixManager();
    private PrefixListener listener;

    public PrefixModule(AudesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getName() {
        return "prefix";
    }

    @Override
    public void enable() {
        manager.loadFromConfig(plugin.getConfig().getConfigurationSection("prefix"));
        listener = new PrefixListener(manager);
        plugin.getServer().getPluginManager().registerEvents(listener, plugin);
    }

    @Override
    public void disable() {
        if (listener != null) {
            HandlerList.unregisterAll(listener);
        }
    }

    public PrefixManager getManager() {
        return manager;
    }

    public PrefixListener getListener() {
        return listener;
    }
}
