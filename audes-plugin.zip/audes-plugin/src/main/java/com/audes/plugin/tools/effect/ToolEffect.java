package com.audes.plugin.tools.effect;

/**
 * Kontrak satu efek "on-use" custom tool (dipicu dari CustomToolListener
 * saat tool dipakai untuk menyerang). Dipisah dari listener supaya
 * nambah efek baru = bikin class baru + daftarkan di ToolEffectRegistry,
 * TIDAK perlu edit CustomToolListener (lihat TODO Dev3 di file itu).
 *
 * Dev5: signature direvisi dari trigger(Player) jadi trigger(ToolEffectContext)
 * -- lihat javadoc ToolEffectContext untuk alasannya (efek generasi
 * sebelumnya tidak bisa akses target/korban serangan sama sekali).
 */
public interface ToolEffect {

    /**
     * Dijalankan tiap kali tool dengan efek ini dipakai menyerang.
     * Implementasi bertanggung jawab sendiri atas probabilitas/cooldown-nya
     * (mis. cek chance internal) supaya registry tidak perlu tahu detail itu.
     */
    void trigger(ToolEffectContext context);
}
