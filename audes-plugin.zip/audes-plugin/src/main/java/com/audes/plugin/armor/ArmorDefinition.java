package com.audes.plugin.armor;

import org.bukkit.Material;
import org.bukkit.inventory.EquipmentSlot;

/**
 * Representasi satu custom armor dari config.yml bagian "armor:".
 *
 * TEKNIK YANG DIPAKAI: komponen native "equippable" (Paper API
 * EquippableComponent, resmi sejak 1.21.2, dikonfirmasi kompatibel di
 * riset ItemsAdder untuk 1.21.11 -- lihat rencana-audes.md bagian 7,
 * catatan Dev4 soal dua jalur armor texture "shader-based (1.17+)" vs
 * "native (1.21.2+)"). Kita pakai jalur NATIVE saja di modul ini:
 * - Base item TETAP armor vanilla asli (mis. LEATHER_HELMET) supaya
 *   armor value/toughness/enchantability ikut hitungan vanilla apa
 *   adanya -- kita cuma override TAMPILANNYA lewat assetId.
 * - assetId dipetakan resource pack ke
 *   contents/assets/&lt;namespace&gt;/equipment/&lt;path&gt;.json,
 *   yang mendefinisikan layer tekstur per bagian tubuh (humanoid,
 *   humanoid_leggings, dst) -- BEDA lokasi dari item model biasa,
 *   makanya ResourcePackManifest punya scan folder terpisah untuk ini.
 *
 * TIDAK diimplementasikan sengaja di modul ini: jalur shader-based
 * (dye leather armor + custom color trick untuk versi lama sebelum
 * 1.21.2). Alasan: LumoraSMP target 1.21.11/26.1.2 (lihat rencana-audes.md
 * bagian 1), semua sudah pasti native-compatible, jadi jalur lama tidak
 * perlu effort tambahan kecuali server tim nanti support versi jauh
 * lebih lama juga.
 */
public record ArmorDefinition(
        String id,
        Material baseMaterial,   // HARUS armor piece vanilla (leather/iron/.../netherite HELMET/CHESTPLATE/LEGGINGS/BOOTS)
        EquipmentSlot slot,      // diturunkan dari baseMaterial saat load, disimpan di sini biar tidak infer ulang tiap dipakai
        String displayName,
        String assetId,          // "namespace:path" -> contents/assets/<namespace>/equipment/<path>.json
        boolean dyeable           // kalau true, base material HARUS leather armor; dipakai untuk beri warna dasar via ItemMeta
) {
}
