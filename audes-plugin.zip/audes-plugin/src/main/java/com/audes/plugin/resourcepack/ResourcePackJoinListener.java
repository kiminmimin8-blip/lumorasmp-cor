package com.audes.plugin.resourcepack;

import net.kyori.adventure.resource.ResourcePackInfo;
import net.kyori.adventure.resource.ResourcePackRequest;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.net.URI;
import java.util.UUID;

/**
 * Kirim resource pack ke player saat join, pakai Adventure
 * ResourcePackRequest (API native Paper sejak 1.20.3, BUKAN
 * Player#setResourcePack(String,byte[]) yang lama/deprecated) —
 * mendukung hash validation supaya client tidak skip re-download pack
 * yang sudah berubah (poin penting di TODO Dev3 no. 3).
 *
 * "required" dan pesan prompt dibaca dari config supaya tim bisa atur
 * apakah player WAJIB terima pack sebelum masuk server, atau opsional.
 */
public class ResourcePackJoinListener implements Listener {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').build();

    private final String packUrl;
    private final String sha1Hex;
    private final boolean required;
    private final String promptMessage;

    public ResourcePackJoinListener(String packUrl, String sha1Hex, boolean required, String promptMessage) {
        this.packUrl = packUrl;
        this.sha1Hex = sha1Hex;
        this.required = required;
        this.promptMessage = promptMessage;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        ResourcePackInfo info = ResourcePackInfo.resourcePackInfo(UUID.randomUUID(), URI.create(packUrl), sha1Hex);

        Component prompt = (promptMessage != null && !promptMessage.isBlank())
                ? LEGACY.deserialize(promptMessage)
                : null;

        ResourcePackRequest.Builder builder = ResourcePackRequest.resourcePackRequest()
                .packs(info)
                .required(required);
        if (prompt != null) {
            builder.prompt(prompt);
        }

        player.sendResourcePacks(builder.build());
    }
}
