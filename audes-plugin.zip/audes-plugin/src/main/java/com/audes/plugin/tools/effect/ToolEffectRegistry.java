package com.audes.plugin.tools.effect;

import org.bukkit.potion.PotionEffectType;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Tempat daftar semua efek "on-use" custom tool yang dikenal plugin.
 *
 * Cara nambah efek baru (TIDAK perlu sentuh CustomToolListener):
 * 1. Bikin class baru implements ToolEffect di package ini (atau reuse
 *    PotionEffectOnHitEffect kalau cuma butuh potion effect standar).
 * 2. Daftarkan key-nya di constructor bawah ini.
 * 3. Pakai key itu di config.yml pada field "on-use-effect" tool terkait
 *    (boleh lebih dari satu, dipisah koma — lihat ToolRegistry).
 *
 * Dev5: nambah 6 efek baru (prioritas "Custom item trigger/on-use effect"
 * di daftar-fitur-itemsadder.md) di atas fondasi strategy pattern yang
 * sudah dibangun Dev4. Nama key sengaja tetap menyertakan chance di
 * dalamnya (konsisten dengan pola "LIGHTNING_STRIKE_CHANCE_5" yang sudah
 * ada) supaya admin server langsung tahu peluangnya dari config.yml tanpa
 * perlu buka kode.
 */
public class ToolEffectRegistry {

    private final Map<String, ToolEffect> effects = new LinkedHashMap<>();

    public ToolEffectRegistry() {
        // Efek bawaan — dipindah dari hardcoded if-else lama di CustomToolListener.
        register("LIGHTNING_STRIKE_CHANCE_5", new LightningStrikeEffect(0.05));

        // Dev5: efek potion generik (satu class, banyak instance parameter beda).
        register("POISON_CHANCE_15", new PotionEffectOnHitEffect(PotionEffectType.POISON, 0.15, 60, 0));
        register("WEAKNESS_CHANCE_20", new PotionEffectOnHitEffect(PotionEffectType.WEAKNESS, 0.20, 100, 0));
        register("SLOWNESS_CHANCE_20", new PotionEffectOnHitEffect(PotionEffectType.SLOWNESS, 0.20, 60, 1));

        // Dev5: efek lain di luar potion.
        register("IGNITE_CHANCE_10", new IgniteTargetEffect(0.10, 60));
        register("KNOCKBACK_BURST_CHANCE_10", new KnockbackBurstEffect(0.10, 1.2));
        register("LIFESTEAL_CHANCE_25", new LifestealEffect(0.25, 0.20));

        // TODO(Dev lain): daftarkan efek baru di sini, contoh:
        // register("FREEZE_TARGET_CHANCE_10", new FreezeTargetEffect(0.10));
    }

    public void register(String key, ToolEffect effect) {
        effects.put(key, effect);
    }

    public Optional<ToolEffect> get(String key) {
        if (key == null) return Optional.empty();
        return Optional.ofNullable(effects.get(key));
    }
}
