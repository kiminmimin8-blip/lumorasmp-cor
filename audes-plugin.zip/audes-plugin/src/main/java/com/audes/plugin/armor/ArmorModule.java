package com.audes.plugin.armor;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import com.audes.plugin.resourcepack.ResourcePackManifest;

/**
 * Custom armor texture -- prioritas Sedang di daftar-fitur-itemsadder.md,
 * direkomendasikan Dev5 di STATUS-DEV5.md.
 *
 * Beda dari CustomBlockModule/FurnitureModule: modul ini TIDAK PERLU
 * listener sama sekali. Karena base item tetap armor vanilla asli (lihat
 * ArmorDefinition), player equip lewat cara normal (klik kanan atau
 * shift-click ke armor slot) sudah otomatis ditangani game vanilla --
 * kita cuma perlu menyiapkan ItemStack-nya lewat ArmorItemFactory
 * (dipanggil dari /audes givearmor), sisanya biar vanilla yang urus.
 */
public class ArmorModule implements AudesModule {

    private final AudesPlugin plugin;
    private final ResourcePackManifest manifest;
    private ArmorRegistry registry;
    private ArmorItemFactory factory;

    public ArmorModule(AudesPlugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.manifest = manifest;
    }

    @Override
    public String getName() {
        return "armor";
    }

    @Override
    public void enable() {
        registry = new ArmorRegistry(plugin);
        registry.loadFromConfig(plugin.getConfig().getConfigurationSection("armor"));
        factory = new ArmorItemFactory(plugin, manifest);
    }

    @Override
    public void disable() {
        // Tidak ada listener/task yang perlu dilepas.
    }

    public ArmorRegistry getRegistry() {
        return registry;
    }

    public ArmorItemFactory getFactory() {
        return factory;
    }
}
