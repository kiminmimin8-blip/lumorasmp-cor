package com.audes.plugin.prefix;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registry in-memory untuk definisi prefix per rank, plus rank aktif
 * tiap player.
 *
 * FASE 1 — belum integrasi LuckPerms/Vault (lihat bagian 6 dokumen
 * rencana, "belum diputuskan"). Rank di-set manual lewat command admin
 * atau default ke "default". Kalau tim memutuskan integrasi LuckPerms
 * nanti, ganti bagian getRank()/setRank() ini untuk baca dari LuckPerms
 * API, sisanya (format, tampilan chat/tab/above-head) tidak perlu
 * berubah karena sudah dipisah lewat PrefixDefinition.
 */
public class PrefixManager {

    private final Map<String, PrefixDefinition> definitions = new LinkedHashMap<>();
    private final Map<UUID, String> playerRank = new ConcurrentHashMap<>();
    private String defaultRankKey = "default";

    public void loadFromConfig(ConfigurationSection prefixSection) {
        definitions.clear();
        if (prefixSection == null) return;

        for (String rankKey : prefixSection.getKeys(false)) {
            ConfigurationSection s = prefixSection.getConfigurationSection(rankKey);
            if (s == null) continue;

            PrefixDefinition def = new PrefixDefinition(
                    rankKey,
                    s.getString("text", ""),
                    s.getBoolean("show-in-chat", true),
                    s.getBoolean("show-in-tablist", true),
                    s.getBoolean("show-above-head", false)
            );
            definitions.put(rankKey, def);
        }
    }

    public PrefixDefinition getDefinitionFor(Player player) {
        String rank = playerRank.getOrDefault(player.getUniqueId(), defaultRankKey);
        return definitions.getOrDefault(rank, definitions.get(defaultRankKey));
    }

    public String getRank(Player player) {
        return playerRank.getOrDefault(player.getUniqueId(), defaultRankKey);
    }

    public void setRank(Player player, String rankKey) {
        playerRank.put(player.getUniqueId(), rankKey);
    }

    public void clearPlayer(Player player) {
        playerRank.remove(player.getUniqueId());
    }

    public boolean hasRankDefinition(String rankKey) {
        return definitions.containsKey(rankKey);
    }

    public Map<String, PrefixDefinition> getAllDefinitions() {
        return definitions;
    }
}
