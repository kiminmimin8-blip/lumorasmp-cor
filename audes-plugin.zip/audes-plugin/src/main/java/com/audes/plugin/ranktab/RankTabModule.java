package com.audes.plugin.ranktab;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import com.audes.plugin.prefix.PrefixModule;
import org.bukkit.event.HandlerList;
import org.bukkit.scheduler.BukkitTask;

public class RankTabModule implements AudesModule {

    private final AudesPlugin plugin;
    private final PrefixModule prefixModule;
    private TabListManager tabListManager;
    private RankTabListener listener;
    private BukkitTask periodicTask;

    public RankTabModule(AudesPlugin plugin, PrefixModule prefixModule) {
        this.plugin = plugin;
        this.prefixModule = prefixModule;
    }

    @Override
    public String getName() {
        return "rank-tab";
    }

    @Override
    public void enable() {
        tabListManager = new TabListManager(prefixModule.getManager());
        tabListManager.setGroupOrder(plugin.getConfig().getStringList("rank-tab.group-order"));
        tabListManager.setFormat(plugin.getConfig().getString("rank-tab.format", "%prefix%%player_name%"));

        listener = new RankTabListener(tabListManager);
        plugin.getServer().getPluginManager().registerEvents(listener, plugin);

        // Periodic refresh sebagai fallback, BUKAN sumber utama update
        // (sumber utama = AudesRankChangeEvent, real-time).
        long interval = plugin.getConfig().getLong("rank-tab.update-interval-ticks", 20L);
        periodicTask = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            plugin.getServer().getOnlinePlayers().forEach(tabListManager::updatePlayer);
        }, interval, interval);
    }

    @Override
    public void disable() {
        if (listener != null) {
            HandlerList.unregisterAll(listener);
        }
        if (periodicTask != null) {
            periodicTask.cancel();
        }
    }
}
