package com.audes.plugin.tools.effect;

import org.bukkit.util.Vector;

/**
 * Efek "on-use": dorongan knockback TAMBAHAN ke target (di luar knockback
 * vanilla bawaan serangan), dengan peluang tertentu. Arah dihitung dari
 * posisi attacker ke target supaya selalu "menjauh dari penyerang",
 * bukan arah acak.
 *
 * CATATAN JUJUR: strength ditambahkan LANGSUNG ke velocity target yang
 * ada sekarang (bukan di-set ulang dari nol), supaya tidak "menghapus"
 * momentum lain yang sedang berlaku (mis. lagi jatuh/lompat). Konsekuensi:
 * kalau efek ini kena berkali-kali beruntun, dorongannya bisa akumulatif
 * dan terasa berlebihan — belum ada cooldown per-target untuk mencegah
 * ini, sama seperti keterbatasan command binding tool (lihat TODO di
 * CustomToolListener).
 */
public class KnockbackBurstEffect implements ToolEffect {

    private final double chance;
    private final double strength;

    public KnockbackBurstEffect(double chance, double strength) {
        this.chance = chance;
        this.strength = strength;
    }

    @Override
    public void trigger(ToolEffectContext context) {
        if (context.target() == null || context.user() == null) return;
        if (Math.random() >= chance) return;

        Vector direction = context.target().getLocation().toVector()
                .subtract(context.user().getLocation().toVector());
        if (direction.lengthSquared() < 1.0E-4) {
            // Attacker & target di posisi (nyaris) sama persis -- hindari
            // normalize() dari vector nol (NaN/Infinity), pakai arah atas saja.
            direction = new Vector(0, 1, 0);
        } else {
            direction = direction.normalize();
        }
        direction.setY(Math.max(direction.getY(), 0.3));

        context.target().setVelocity(context.target().getVelocity().add(direction.multiply(strength)));
    }
}
