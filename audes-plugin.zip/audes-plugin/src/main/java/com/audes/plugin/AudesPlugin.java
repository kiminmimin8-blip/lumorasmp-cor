package com.audes.plugin;

import com.audes.plugin.armor.ArmorModule;
import com.audes.plugin.block.CustomBlockModule;
import com.audes.plugin.core.ModuleManager;
import com.audes.plugin.emoji.EmojiModule;
import com.audes.plugin.furniture.FurnitureModule;
import com.audes.plugin.prefix.PrefixModule;
import com.audes.plugin.ranktab.RankTabModule;
import com.audes.plugin.resourcepack.ResourcePackManifest;
import com.audes.plugin.resourcepack.ResourcePackModule;
import com.audes.plugin.tools.CustomToolsModule;
import org.bukkit.plugin.java.JavaPlugin;

public class AudesPlugin extends JavaPlugin {

    private ModuleManager moduleManager;
    private PrefixModule prefixModule;
    private CustomToolsModule customToolsModule;
    private ResourcePackModule resourcePackModule;
    private CustomBlockModule customBlockModule;
    private FurnitureModule furnitureModule;
    private ArmorModule armorModule;
    private EmojiModule emojiModule;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        moduleManager = new ModuleManager(this);

        // Dev5: satu instance ResourcePackManifest dibagi ke semua modul yang
        // bikin item (tools/block/furniture) + ResourcePackModule yang
        // mengisinya. TIDAK masalah kalau resource-pack module enable()
        // belakangan/gagal -- manifest mulai dari kosong (Set.of()) dan
        // factory lain otomatis fallback vanilla + warning, bukan error.
        ResourcePackManifest resourcePackManifest = new ResourcePackManifest(getLogger());

        // Urutan register penting: prefix harus register duluan karena
        // rank-tab bergantung ke PrefixManager miliknya (lihat
        // RankTabModule constructor).
        prefixModule = new PrefixModule(this);
        customToolsModule = new CustomToolsModule(this, resourcePackManifest);
        resourcePackModule = new ResourcePackModule(this, resourcePackManifest);
        customBlockModule = new CustomBlockModule(this, resourcePackManifest);
        furnitureModule = new FurnitureModule(this, resourcePackManifest);
        armorModule = new ArmorModule(this, resourcePackManifest);
        emojiModule = new EmojiModule(this);

        moduleManager.register(prefixModule);
        moduleManager.register(new RankTabModule(this, prefixModule));
        moduleManager.register(customToolsModule);
        moduleManager.register(resourcePackModule);
        moduleManager.register(customBlockModule);
        moduleManager.register(furnitureModule);
        moduleManager.register(armorModule);
        moduleManager.register(emojiModule);

        moduleManager.enableAll();

        AudesCommand command = new AudesCommand(this, moduleManager, prefixModule, customToolsModule,
                customBlockModule, furnitureModule, armorModule);
        getCommand("audes").setExecutor(command);
        getCommand("audes").setTabCompleter(command);

        getLogger().info("[Audes] Plugin aktif.");
    }

    @Override
    public void onDisable() {
        if (moduleManager != null) {
            moduleManager.disableAll();
        }
        getLogger().info("[Audes] Plugin nonaktif.");
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public PrefixModule getPrefixModule() {
        return prefixModule;
    }

    public CustomToolsModule getCustomToolsModule() {
        return customToolsModule;
    }

    public ResourcePackModule getResourcePackModule() {
        return resourcePackModule;
    }

    public CustomBlockModule getCustomBlockModule() {
        return customBlockModule;
    }

    public FurnitureModule getFurnitureModule() {
        return furnitureModule;
    }

    public ArmorModule getArmorModule() {
        return armorModule;
    }

    public EmojiModule getEmojiModule() {
        return emojiModule;
    }
}
