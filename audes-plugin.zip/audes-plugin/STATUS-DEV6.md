# STATUS-DEV6.md

## Konfirmasi penting: compile PERTAMA sukses 🎉
Jar `Audes-0_1_0-SNAPSHOT.jar` yang di-upload user berisi 44 class file,
cocok sama 32 source file hasil kerja Dev1-5 — artinya semua asumsi API
berisiko yang dicatat di STATUS-DEV5.md (`setItemModel`, nama
`PotionEffectType`, `Player#sendActionBar`) TERNYATA BENAR dan lolos
compile. Ini validasi besar buat pendekatan "tulis manual + dokumentasikan
risiko compile" yang dipakai sejak Dev1.

## Yang dikerjakan sesi ini: Custom Armor Texture ✅
Fitur prioritas Sedang di `daftar-fitur-itemsadder.md`, direkomendasikan
Dev5 di STATUS-DEV5.md poin 3.

- **Teknik**: base item TETAP armor vanilla asli (`base-material` di
  config, harus salah satu `*_HELMET/*_CHESTPLATE/*_LEGGINGS/*_BOOTS`),
  tampilannya di-override lewat komponen native `equippable`
  (`org.bukkit.inventory.meta.components.EquippableComponent`, Paper API
  1.21.2+). Ini jalur "native" yang dicatat Dev4 di riset ItemsAdder —
  jalur "shader-based" (armor dye trick untuk versi <1.21.2) SENGAJA
  tidak diimplementasikan karena target server 1.21.11/26.1.2 sudah pasti
  native-compatible.
- **`ArmorRegistry`**: infer `EquipmentSlot` otomatis dari akhiran nama
  material (`_HELMET`→HEAD, dst), jadi admin tidak perlu isi slot manual
  di config dan tidak bisa salah ketik jadi slot yang tidak cocok.
- **`ArmorItemFactory`**: pakai `ResourcePackManifest` yang di-extend
  sesi ini dengan scan KEDUA khusus folder
  `contents/assets/<ns>/equipment/*.json` (terpisah dari scan `items/`
  yang sudah ada Dev5 — lokasi file beda meski format namespace:path-nya
  mirip). modelKey/asset tidak ketemu → warning sekali di log, armor
  tetap kepakai tapi tampil polos vanilla (bukan silent fail).
- **`ArmorModule`**: TIDAK punya listener sama sekali — equip armor
  custom ini otomatis jalan lewat mekanisme vanilla (klik kanan/
  shift-click ke armor slot), karena base item-nya memang armor asli.
  Ini modul paling sederhana dari semua modul item yang ada sejauh ini.
- **Command**: `/audes givearmor <player> <armor_id>` + tab-complete.
- **Config**: section `armor:` baru + `modules.armor: true`.

## COMPILE RISK sesi ini (belum diverifikasi, ikuti pola jujur project)
1. `EquippableComponent#setSlot(EquipmentSlot)` dan `#setModel(NamespacedKey)`
   — asumsi nama method berdasarkan riset dokumentasi Paper untuk
   komponen "equippable" 1.21.2+. Kalau nama method beda di versi
   paper-api yang ke-resolve, ini gagal compile di `ArmorItemFactory`.
2. `ItemMeta#getEquippable()` / `#setEquippable(EquippableComponent)` —
   sama, asumsi method langsung ada di interface `ItemMeta` (mengikuti
   pola `setItemModel()` yang sudah terbukti ada dan lolos compile).
3. `LeatherArmorMeta#setColor(Color)` — ini API lama & stabil, risiko
   rendah, disebut di sini cuma buat kelengkapan daftar.

## Rekomendasi urutan kerja dev berikutnya
1. **Compile ulang** — cek 3 poin risiko di atas duluan. Kalau
   `EquippableComponent` gagal ketemu, kemungkinan besar cuma soal nama
   method yang meleset dikit (cek `jd.papermc.io` untuk versi
   1.21.11-R0.1-SNAPSHOT), bukan berarti fiturnya tidak ada di API.
2. Test manual: equip armor custom, konfirmasi armor value vanilla
   (defense point) tetap kehitung normal — ini poin desain utama modul
   ini, kalau ternyata component override malah bikin armor value hilang,
   perlu investigasi lebih lanjut.
3. Lanjut fitur prioritas Sedang lain di `daftar-fitur-itemsadder.md`:
   custom item command binding (sebenarnya sudah ada versi kecilnya di
   `tools:` config field `command`, cek apakah itu cukup atau perlu
   diperluas ke block/furniture juga), emoji di chat, atau custom ore
   (perluasan dari custom block yang sudah ada, effort kecil-menengah
   karena arsitektur `BlockRegistry`/`CustomBlockListener` sudah siap).
