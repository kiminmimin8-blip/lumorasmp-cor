# Status Kerja Dev3 — Plugin Audes (skeleton awal)

Dikerjakan berdasarkan `rencana-audes.md` (versi dengan tabel tim & lampiran
riset bug). Ini laporan handoff — belum full fitur, tapi fondasi arsitektur
sudah jalan sesuai prinsip di bagian 3 dokumen rencana.

## ⚠️ Catatan penting: BELUM PERNAH DI-COMPILE

Environment saya (Dev3/Claude) tidak punya akses internet, jadi Maven tidak
bisa download dependency `paper-api` dari repo PaperMC untuk verifikasi
compile. Semua kode ditulis manual mengikuti API Paper yang saya tahu
(termasuk Adventure API untuk chat/component, bukan legacy string chat).
**Langkah pertama dev berikutnya: jalankan `mvn clean package` di mesin
dengan internet, dan perbaiki error compile kalau ada** (kemungkinan
besar di bagian Adventure/Kyori import, karena API itu paling sering
berubah versi-ke-versi).

## Sudah dibangun

**Struktur project**
- `pom.xml` — Maven, target Java 21, dependency `paper-api` (versi di
  properties masih `1.21.4-R0.1-SNAPSHOT`, **cek & sesuaikan** ke versi API
  paper yang benar-benar tersedia untuk 1.21.11 / 26.1.2 di repo PaperMC
  saat kalian build).
- `plugin.yml`, `config.yml` (default, termasuk contoh 1 tool & 2 prefix).

**Core (`core/`)**
- `AudesModule` — interface kontrak modul.
- `ModuleManager` — enable/disable semua modul, isolasi bug per modul
  (kalau satu modul `Throwable` saat enable, modul itu di-skip, modul lain
  & plugin tetap jalan). Ini implementasi langsung dari prinsip di bagian 3
  & bug pattern "plugin nonaktif sendiri" di bagian 4/8 dokumen rencana.

**Prefix (`prefix/`)** — fungsional untuk chat & tab-list dasar
- `PrefixDefinition`, `PrefixManager` (load dari config, rank in-memory
  per player — BELUM integrasi LuckPerms, lihat "Belum diputuskan" di
  dokumen rencana bagian 6).
- `PrefixListener` — pasang prefix di chat (pakai `AsyncChatEvent`, bukan
  API lama yang deprecated) dan di tab-list name saat join.
- **Belum**: `show-above-head` (butuh scoreboard `Team.prefix()` +
  attach ke player display, beda jalur dari tab-list team yang dipakai
  rank-tab — jangan bentrok nama team-nya).

**Rank Tab (`ranktab/`)** — fungsional dasar
- `TabListManager` — grouping + urutan tab list pakai scoreboard Team
  (trik nama team menentukan sorting).
- `RankTabListener` — update saat join/quit, dan real-time lewat
  `AudesRankChangeEvent` custom.
- Periodic refresh dari config `update-interval-ticks` sebagai fallback,
  bukan sumber utama.
- **Belum**: command/API buat trigger `AudesRankChangeEvent` — sekarang
  event-nya ADA tapi belum ada yang men-dispatch dari command admin.
  Perlu ditambah command mis. `/audes setrank <player> <rank>` yang
  manggil `PrefixManager.setRank()` lalu fire event ini.

**Custom Tools (`tools/`)** — behavior/attribute jalan, texture belum
- `ToolDefinition`, `ToolRegistry` (load dari config).
- `ToolFactory` — buat ItemStack dengan tanda PersistentDataContainer
  (bukan lore/NBT manual yang rapuh).
- `CustomToolListener` — damage bonus & durability multiplier via event
  resmi (`EntityDamageByEntityEvent`, `PlayerItemDamageEvent`), bukan
  reflection/NMS, sesuai prinsip bagian 3.
- On-use effect baru contoh 1 kasus hardcoded (`LIGHTNING_STRIKE_CHANCE_5`)
  buat nunjukin pola — **TODO: refactor ke registry efek (strategy
  pattern)** supaya nambah efek baru gak perlu edit `CustomToolListener`
  terus-terusan.
- **Belum ada command** untuk kasih/spawn custom tool ke player (mis.
  `/audes give <player> <tool_id>`) — `ToolFactory.create()` sudah siap
  dipanggil, tinggal disambung ke command.

**Resource Pack (`resourcepack/`)** — SENGAJA STUB, belum diimplementasikan
- Ini prioritas modul berikutnya. Lihat komentar panjang di
  `ResourcePackModule.java` — isinya ringkasan bug pattern dari riset
  (issue #5213, #5289, #5205, batas ukuran 100MB/250MB, masalah CDN) yang
  jadi alasan kenapa modul ini harus dirancang hati-hati, bukan asal-copy
  pola ItemsAdder.
- **Konsekuensi**: custom tools sekarang tampil dengan material vanilla
  apa adanya, TIDAK ada custom texture, karena `meta.setItemModel(...)`
  di `ToolFactory.create()` masih di-comment jadi TODO.

**Command (`AudesCommand.java`)**
- `/audes info` — jalan, nampilin status tiap modul (aktif/gagal).
- `/audes reload` — HANYA reload `config.yml` ke memory, **BELUM**
  re-run `disableAll()`/`enableAll()` di modul (sengaja ditahan karena
  berisiko duplikat listener/task kalau belum ditest). Kalau mau full
  hot-reload, ini prioritas kecil yang gampang dikerjakan dev manapun.

## Yang masih kurang (urutan prioritas realistis)

1. **Compile & fix error** di mesin dengan internet (Maven perlu
   download `paper-api`). Ini blocker paling awal sebelum lanjut apapun.
2. **Command untuk trigger fitur**: `/audes give`, `/audes setrank` —
   tanpa ini, modul tools & rank-tab tidak bisa dites manual di server.
3. **`show-above-head` untuk prefix** (belum ada, lihat catatan prefix
   di atas).
4. **Registry efek untuk custom tools** (refactor dari hardcoded
   if-else di `CustomToolListener`).
5. **Modul Resource Pack** — prioritas besar berikutnya, karena riset
   bug (bagian 8 dokumen rencana) nunjukin ini sumber masalah terbanyak
   di kompetitor. Skeleton `ResourcePackModule` sudah ada catatan TODO
   detail di dalam file-nya.
6. **Keputusan tim yang masih pending** (bagian 6 dokumen rencana) yang
   belum kepengaruh di kode ini: bahasa/framework (saya pakai Java murni
   sesuai default, belum Kotlin), format config (saya pakai YAML ala
   ItemsAdder), model lisensi, struktur folder `contents/` (baru relevan
   begitu Resource Pack Module mulai dikerjakan).

## Cara pakai file ini untuk dev berikutnya

Semua source ada di `src/main/java/com/audes/plugin/`, dipisah per modul
sesuai folder (`core`, `prefix`, `ranktab`, `tools`, `resourcepack`,
`event`, `util`). Baca dulu komentar TODO di tiap file sebelum ubah —
saya taruh alasan desain di situ (bukan cuma "apa"-nya tapi "kenapa"-nya)
biar gampang dilanjutin tanpa perlu tanya ulang ke saya.
