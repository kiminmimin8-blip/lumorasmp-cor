# Status Kerja Dev1 — lanjutan dari Dev4

Melanjutkan kerjaan yang sempat terputus (lihat screenshot percakapan sebelumnya:
"BlockItemFactory" + "CustomBlockListener" baru mulai ditulis lalu kena limit).
Prioritas #1 di `daftar-fitur-itemsadder.md`: **custom block dasar**.

Sama seperti Dev4: BELUM sempat di-compile di environment saya (tidak ada akses
internet ke Maven di sini juga). Kode ditulis mengikuti API Paper 1.21.11 yang
saya tahu, dan mengikuti persis pola arsitektur modul yang sudah ada
(`CustomToolsModule` sebagai referensi utama).

## ⚠️ Langkah pertama dev berikutnya: TETAP compile duluan

`mvn clean package`. Yang paling mungkin perlu dicek:
- `org.bukkit.block.data.type.NoteBlock` — pastikan `event.getBlock().getBlockData()`
  benar-benar bisa di-cast ke ini untuk `Material.NOTE_BLOCK` di versi Paper API
  yang ke-resolve (harusnya iya, ini API block data standar sejak 1.13, tapi
  tetap perlu diverifikasi karena saya tidak bisa compile).
- `org.bukkit.Note` constructor `new Note(int)` — cek signature persis, ada
  kemungkinan constructor lain (`Note(int, Tone, boolean)`) yang lebih dipakai
  di beberapa versi.
- `Chunk#getPersistentDataContainer()` — pastikan ini tersedia di paper-api
  1.21.11 (harusnya sudah lama ada, tapi ini bagian penting dari desain modul
  ini jadi wajib divalidasi sebelum lanjut fitur lain yang bergantung ke sini).

## Sudah dikerjakan

Modul baru **`custom-block`** (package `com.audes.plugin.block/`), lengkap
dengan pola yang sama seperti modul lain (`AudesModule`, isolasi bug lewat
`ModuleManager`, tidak ada reflection/NMS):

1. **`BlockDefinition`** — record: id, instrument, note (0-24), display name,
   modelKey (disiapkan buat migrasi nanti), hardness (disiapkan, BELUM
   diterapkan), break-sound, place-sound.

2. **`BlockRegistry`** — load dari config.yml bagian `blocks:`, validasi
   instrument enum & clamp note ke rentang 0-24, konsisten dengan pola
   `ToolRegistry.loadFromConfig()`.

3. **`BlockItemFactory`** — dua tanggung jawab:
   - Bikin ItemStack custom block (Material.NOTE_BLOCK + PDC `block_id`,
     sama pola dengan `ToolFactory`).
   - **Pencatatan block yang sudah di-place**: karena NOTE_BLOCK bukan
     TileState (tidak punya PDC sendiri kayak chest/furnace), data "block di
     lokasi X adalah block id Y" disimpan di **PersistentDataContainer milik
     Chunk**, dengan satu NamespacedKey per koordinat lokal block (teknik yang
     sama dipakai library populer `CustomBlockData` di ekosistem Paper — bukan
     saya karang sendiri, ini pattern yang sudah terbukti dipakai luas).

4. **`CustomBlockListener`** — `BlockPlaceEvent` (apply instrument+note ke
   block data, catat ke PDC chunk) dan `BlockBreakEvent` (cegah drop vanilla,
   drop item custom, bersihkan PDC chunk). Kalau block id di item/chunk sudah
   tidak ada di config (dihapus admin), TIDAK silent-fail — kasih pesan ke
   player supaya jelas kenapa block-nya "polos".

5. **`CustomBlockModule`** — wiring standar (`enable()`/`disable()`,
   unregister listener saat disable), didaftarkan di `AudesPlugin` dan
   `ModuleManager` seperti modul lain.

6. **Command `/audes giveblock <player> <block_id>`** di `AudesCommand.java`,
   pola sama persis dengan `/audes give` (tab-complete player online + block
   id dari registry).

7. **`config.yml`** — section baru `blocks:` dengan contoh (`contoh_batu_audes`)
   dan komentar yang menjelaskan kenapa teknik note+instrument dipakai
   sementara (bukan tekstur asli — jujur soal keterbatasannya, bukan diam-diam).

8. **`plugin.yml`** — update usage command + permission baru
   `audes.block.place` (BARU DIDEKLARASIKAN, belum dicek di kode manapun —
   lihat "Yang masih kurang" poin 2).

9. **Custom item command binding** (prioritas #4 di checklist, effort kecil
   karena registry sudah siap) — tambah field `command` di `ToolDefinition`
   & `ToolRegistry`, handler baru `onInteract()` di `CustomToolListener`:
   right-click pakai tool yang punya `command` di config akan menjalankan
   command itu sebagai console, dengan placeholder `%player%`. Contoh dipakai
   di `config.yml` (`contoh_pedang_petir` sekarang kasih golden apple pas
   di-klik kanan).

10. **Custom furniture statis** (prioritas #2 di checklist), package baru
    `com.audes.plugin.furniture/`:
    - `FurnitureDefinition` — record: id, display material, display name,
      modelKey (disiapkan buat migrasi), scale, interaction width/height,
      place/break sound.
    - `FurnitureRegistry` — load dari config.yml bagian `furniture:`.
    - `FurnitureItemFactory` — bikin item placeable (pola sama dengan
      Tool/Block factory), DAN spawn pasangan entity `ItemDisplay` (visual)
      + `Interaction` (hitbox) yang saling terhubung lewat PDC berisi UUID
      satu sama lain.
    - `FurnitureListener` — klik kanan ke block dengan item furniture di
      tangan → spawn di sisi block yang diklik, kurangi 1 item (kecuali
      creative). Serang entity Interaction-nya → hapus pasangan
      ItemDisplay+Interaction, drop item furniture custom.
    - `FurnitureModule` — wiring standar, didaftarkan di `AudesPlugin`.
    - Command `/audes givefurniture <player> <furniture_id>`.
    - **PENTING soal arsitektur**: furniture TIDAK pakai workaround PDC-di-
      Chunk seperti custom block, karena entity (ItemDisplay/Interaction)
      sudah native `PersistentDataHolder` — jauh lebih simpel & robust
      dibanding pendekatan block. Trade-off: rentan ke command mass-kill
      entity (lihat kekurangan poin 9 di bawah).

## Yang masih kurang (jujur, biar tidak ada yang kaget)

1. **Compile & fix error** — tetap blocker #1, lihat catatan di atas.
2. **Permission belum ditegakkan** — `audes.block.place` dideklarasikan di
   `plugin.yml` tapi TIDAK dicek di `CustomBlockListener` maupun command
   `giveblock`. Sama seperti `audes.tools.use` di modul tools yang juga belum
   ditegakkan — ini utang lama, bukan hal baru yang saya perkenalkan, tapi
   perlu diselesaikan bareng kalau tim mau permission benar-benar berfungsi.
3. **Hardness belum diterapkan** — field ada di config & `BlockDefinition`,
   tapi waktu hancur block masih 100% default vanilla NOTE_BLOCK. Override
   presisi butuh handling `BlockDamageEvent` + kalkulasi tool/enchantment,
   sengaja belum dikerjakan supaya scope modul ini tetap fokus dulu.
4. **Loot table custom belum ada** — break selalu drop 1 item custom block-nya
   sendiri, belum ada sistem drop table terpisah/random.
5. **Block yang hilang lewat explosion/piston/WorldEdit TIDAK membersihkan PDC
   chunk** — cuma `BlockBreakEvent` yang ditangani. Kalau server pakai TNT
   atau piston di dekat custom block, data di chunk bisa jadi basi (block
   sudah hilang tapi PDC masih mencatat ada). Perlu listener tambahan kalau
   ini jadi masalah nyata di gameplay LumoraSMP.
6. **Belum ada texture asli** — masih note+instrument seperti dijelaskan di
   `BlockDefinition`. Ini nunggu modul resource pack + (kalau sudah ada)
   block model API resmi, sama seperti keterbatasan `ToolFactory`.
7. **Command binding belum ada cooldown** — spam klik kanan = spam command,
   lihat TODO di `CustomToolListener#onInteract`. Aman untuk command ringan
   (mis. pesan/give sekali), berisiko untuk command berat.
8. **Furniture belum tahan terhadap mass-remove entity** — `/kill @e`,
   plugin lain, atau force-unload chunk yang tidak wajar bisa menghapus
   salah satu dari pasangan ItemDisplay/Interaction tanpa lewat
   `FurnitureListener`, meninggalkan pasangannya "yatim" (visual tanpa
   hitbox, atau sebaliknya). Belum ada cleanup task berkala untuk kasus ini.
9. **Furniture belum bisa dirotasi saat place** — selalu spawn dengan
   transformasi default, tidak mengikuti arah pandang player. Interaksi
   rotasi (mis. klik kanan tambahan buat muter arah) belum ada.
10. Keputusan tim yang masih pending dari dokumen rencana bagian 6 (bahasa/
    framework, format config, model lisensi, struktur final `contents/`)
    belum berubah sejak laporan Dev3/Dev4.
