# STATUS-DEV8.md

## Yang dikerjakan sesi ini: Emoji Chat ✅ (sebagian dari fitur asli)
Prioritas Sedang #1 di sisa checklist `daftar-fitur-itemsadder.md`.

- **Cakupan**: CUMA chat. Fitur asli ItemsAdder juga cover buku dan
  hologram, tapi Audes belum punya modul book/hologram sama sekali,
  jadi itu belum relevan diimplementasikan. `EmojiManager#apply()`
  sengaja generik (Component in, Component out) supaya modul book/
  hologram nanti tinggal reuse, bukan bikin sistem emoji kedua.
- **`EmojiRegistry`**: build SATU regex gabungan dari semua shortcode
  terdaftar (bukan loop replace per shortcode) — penting karena ini
  jalan di jalur chat, dipanggil tiap pesan.
- **`EmojiManager`**: pakai `Component#replaceText(TextReplacementConfig)`
  dari Adventure API buat substitusi dalam satu pass.
- **`EmojiListener`**: **PALING PENTING dari sesi ini** — priority
  `LOWEST`, sengaja TIDAK PERNAH sentuh `event.renderer()`. Alasan detail
  ada di javadoc class itu sendiri, ringkasnya: `PrefixListener.onChat()`
  (priority `LOW`) pakai `event.renderer()` yang MENGGANTIKAN seluruh
  render pesan. Kalau EmojiListener juga pasang renderer sendiri, salah
  satu bakal ketimpa yang lain (bug tersembunyi tergantung timing/urutan
  registrasi). Solusinya: emoji cuma mutasi `event.message()` di priority
  LEBIH RENDAH (LOWEST < LOW) supaya subtitusi kelar SEBELUM
  PrefixListener baca message() buat di-render.
- **ATURAN untuk dev berikutnya yang mau nambah listener AsyncChatEvent
  lain**: WAJIB ikuti pola ini juga (transform via `event.message()`,
  jangan sentuh `event.renderer()` kecuali benar-benar butuh custom
  render kayak PrefixListener). Kalau tidak, resiko konflik silent
  seperti dijelaskan di atas.

## COMPILE RISK sesi ini
`Component#replaceText(TextReplacementConfig)` — API Adventure yang
relatif stabil/lama dibanding `EquippableComponent` (Dev6) atau
`Enchantment.FORTUNE` (Dev7), risiko compile fail lebih rendah, tapi
tetap belum diverifikasi langsung di environment ini.

## Keterbatasan yang sengaja belum diselesaikan
- Emoji cuma simbol teks (mis. "&e:D"), BUKAN ikon/gambar custom.
  Ikon custom butuh custom font resource pack (private-use-area unicode
  char), yang belum diimplementasikan — lihat catatan di config.yml
  bagian emoji.
- Belum ada command `/audes` buat list emoji available ke player (mis.
  `/emoji list`) — saat ini player harus tahu shortcode-nya sendiri
  (dari dokumentasi/pengumuman server).

## Rekomendasi urutan kerja dev berikutnya
Sesuai `daftar-fitur-itemsadder.md`:
1. Compile ulang.
2. **Custom furniture animasi** — cek dulu apakah cukup pakai aset
   `.mcmeta` resource-pack-side tanpa kode Java tambahan (dugaan Dev6/7,
   belum diverifikasi langsung).
3. Custom HUD/GUI, custom animated entities — effort lebih besar,
   evaluasi ulang relevansi buat EcoCPvP.
