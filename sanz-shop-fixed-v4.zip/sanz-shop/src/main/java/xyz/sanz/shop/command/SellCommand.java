package xyz.sanz.shop.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import xyz.sanz.shop.SanzShop;
import xyz.sanz.shop.gui.MenuBuilder;

import java.util.List;

/**
 * /sell -- command utama yang paling sering dicoba pemain duluan (kebiasaan dari
 * plugin shop lain), tapi sebelum ini SanzShop cuma punya /sellhand, /sellist, dkk --
 * jadi /sell selalu "Unknown command" tanpa ada log error apa pun (makanya di server
 * log gak ada bekasnya walau pemain jelas-jelas ngetik /sell).
 *
 * Sekarang /sell jadi command "pintu masuk", niru kebiasaan plugin shop lain (mis.
 * plugin Sell) yang /sell-nya langsung buka GUI, bukan cuma jual diam-diam:
 *   /sell            -> BUKA GUI "jual cepat" per kategori (SellGuiHolder) --
 *                        klik 1 kategori = jual semua item kategori itu di inventory sekaligus
 *   /sell hand       -> jual stok item yang lagi dipegang (perilaku lama /sell tanpa argumen)
 *   /sell list       -> sama kayak /sellist (buka GUI browsing semua item yang bisa dijual satuan)
 */
public class SellCommand implements CommandExecutor, TabCompleter {

    private final SanzShop plugin;

    public SellCommand(SanzShop plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }

        if (args.length == 0) {
            if (!player.hasPermission("sanzshop.use")) {
                player.sendMessage(plugin.getMessages().get("no-permission"));
                return true;
            }
            MenuBuilder.openSellGuiMenu(player, plugin);
            return true;
        }

        if (args[0].equalsIgnoreCase("hand")) {
            SellHandCommand.sellHeldItem(player, plugin);
            return true;
        }

        if (args[0].equalsIgnoreCase("list")) {
            if (!player.hasPermission("sanzshop.use")) {
                player.sendMessage(plugin.getMessages().get("no-permission"));
                return true;
            }
            MenuBuilder.openSellListMenu(player, plugin, "default", 0);
            return true;
        }

        player.sendMessage(plugin.getMessages().prefix() + "§cGunakan: §f/sell §7(buka GUI jual cepat)§c, §f/sell hand §7(jual di tangan) §catau §f/sell list");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("hand", "list").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .toList();
        }
        return List.of();
    }
}
