package xyz.sanz.shop.gui.holder;

/**
 * GUI: /sell (tanpa argumen) -- menu "jual cepat" per kategori, beda konsep dari
 * SellListHolder (yang browsing item satuan lintas kategori, /sell list). Di sini
 * tiap ikon = 1 kategori toko; klik ikon = langsung jual SEMUA item dari kategori itu
 * yang ada di inventory pemain sekaligus (bukan jual 1 per 1). Gak butuh state
 * tambahan karena isi menu selalu di-generate ulang fresh dari inventory pemain saat
 * ini tiap kali dibuka/direfresh -- lihat MenuBuilder#openSellGuiMenu.
 */
public class SellGuiHolder extends BaseHolder {
}
