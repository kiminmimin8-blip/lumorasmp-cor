package xyz.sanz.shop.service;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import xyz.sanz.shop.EconomyHook;
import xyz.sanz.shop.SanzShop;
import xyz.sanz.shop.model.ShopCategory;
import xyz.sanz.shop.model.ShopItem;
import xyz.sanz.shop.util.InventoryUtils;
import xyz.sanz.shop.util.Messages;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Logika transaksi jual-beli murni, dipisah dari kode GUI supaya bisa dites/dipakai ulang
 * (mis. dari command langsung, bukan cuma dari klik inventory).
 */
public class ShopService {

    public enum Result {
        SUCCESS,
        NOT_ENOUGH_MONEY,
        INVENTORY_FULL,
        NOT_ENOUGH_ITEMS,
        NOT_BUYABLE,
        NOT_SELLABLE,
        NO_ECONOMY,
        /** Player punya materialnya, tapi yang kurang itu gara-gara sebagian dilindungi (item bagus). */
        PROTECTED_ITEMS,
        /** Vault nolak transaksinya (deposit/withdraw gagal) -- item dikembalikan, gak ada yang ilang. */
        ECONOMY_ERROR
    }

    private final SanzShop plugin;
    private final Messages messages;

    public ShopService(SanzShop plugin) {
        this.plugin = plugin;
        this.messages = plugin.getMessages();
    }

    /** Proteksi item bagus (enchant/nama/lore/isi) aktif? Lihat sell.protect-valuable-items di config.yml. */
    public boolean isProtectionEnabled() {
        return plugin.getConfig().getBoolean("sell.protect-valuable-items", true);
    }

    /** Jumlah `material` di inventory player yang BOLEH dijual (item bagus gak dihitung kalau proteksi aktif). */
    public int countSellable(Player player, Material material) {
        return InventoryUtils.countSellable(player.getInventory(), material, isProtectionEnabled());
    }

    public Result buy(Player player, ShopItem item, int qty) {
        if (!EconomyHook.isReady()) return Result.NO_ECONOMY;
        if (!item.isBuyable()) return Result.NOT_BUYABLE;

        double totalPrice = buyTotal(item, qty);
        int totalAmount = item.getAmount() * qty;

        Economy econ = EconomyHook.get();
        if (econ.getBalance(player) < totalPrice) return Result.NOT_ENOUGH_MONEY;
        if (!InventoryUtils.hasSpaceFor(player.getInventory(), item.getMaterial(), totalAmount)) {
            return Result.INVENTORY_FULL;
        }

        EconomyResponse resp = econ.withdrawPlayer(player, totalPrice);
        if (!resp.transactionSuccess()) return Result.ECONOMY_ERROR;

        InventoryUtils.giveItems(player, item.getMaterial(), totalAmount);
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);

        Map<String, String> ph = new HashMap<>();
        ph.put("%amount%", String.valueOf(totalAmount));
        ph.put("%item%", item.getDisplayName());
        ph.put("%price%", formatMoney(totalPrice));
        messages.send(player, "purchase-success", ph);
        return Result.SUCCESS;
    }

    /**
     * Jual `qty` x (item.getAmount()) item dari SLOT PENYIMPANAN player (hotbar + tas).
     * Yang ikut kejual cuma item yang lolos proteksi; item bagus (enchant/nama/lore/isi)
     * dilewati. Barang yang kejual dicatat persis (utuh) di RefundManager buat /sellrefund.
     */
    public Result sell(Player player, ShopItem item, int qty) {
        return sell(player, item, qty, true);
    }

    /**
     * Sama kayak sell(player, item, qty), tapi bisa matiin notifikasi (suara + pesan chat
     * per-item). Dipakai buat jual borongan lewat /sell GUI (lihat sellCategory/sellAll di
     * bawah) -- transaksi & pencatatan refund tetap jalan normal persis kayak jual biasa,
     * cuma pesan chat-nya diskip di sini karena GUI ngirim 1 pesan ringkasan sendiri di
     * akhir (biar chat gak kebanjiran kalau borongan banyak jenis item sekaligus).
     */
    public Result sell(Player player, ShopItem item, int qty, boolean notify) {
        if (!EconomyHook.isReady()) return Result.NO_ECONOMY;
        if (!item.isSellable()) return Result.NOT_SELLABLE;

        Material material = item.getMaterial();
        boolean protect = isProtectionEnabled();
        Inventory inv = player.getInventory();
        int totalAmount = item.getAmount() * qty;

        if (InventoryUtils.countSellable(inv, material, protect) < totalAmount) {
            boolean hasProtected = protect && InventoryUtils.countProtected(inv, material) > 0;
            return hasProtected ? Result.PROTECTED_ITEMS : Result.NOT_ENOUGH_ITEMS;
        }

        double multiplier = plugin.getConfig().getDouble("economy.sell-multiplier", 1.0);
        double totalPrice = item.getSellPrice() * qty * multiplier;

        List<ItemStack> removed = InventoryUtils.removeSellable(inv, material, totalAmount, protect);
        EconomyResponse resp = EconomyHook.get().depositPlayer(player, totalPrice);
        if (!resp.transactionSuccess()) {
            // uang gagal masuk -> balikin barangnya, jangan sampai player rugi
            InventoryUtils.giveOrDrop(player, removed);
            return Result.ECONOMY_ERROR;
        }

        plugin.getRefundManager().record(player, item.getDisplayName(), material, totalAmount, totalPrice, removed);

        if (notify) {
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 0.7f);

            Map<String, String> ph = new HashMap<>();
            ph.put("%amount%", String.valueOf(totalAmount));
            ph.put("%item%", item.getDisplayName());
            ph.put("%price%", formatMoney(totalPrice));
            messages.send(player, "sell-success", ph);

            // kasih tau kalau ada stack sejenis yang sengaja gak ikut kejual karena dilindungi
            if (protect) {
                int skipped = InventoryUtils.countProtected(inv, material);
                if (skipped > 0) {
                    Map<String, String> ph2 = new HashMap<>();
                    ph2.put("%protected%", String.valueOf(skipped));
                    ph2.put("%item%", item.getDisplayName());
                    messages.send(player, "sell-protected-notice", ph2);
                }
            }
        }
        return Result.SUCCESS;
    }

    /** Ringkasan hasil jual borongan (dipakai /sell GUI): total uang, total item kejual, & total item yang dilewati karena dilindungi. */
    public record CategorySellResult(double totalMoney, int totalItemsSold, int protectedSkipped) {}

    /**
     * Jual SEMUA item sellable dari 1 kategori yang ada di slot penyimpanan pemain,
     * sekali panggil -- dipakai /sell GUI pas klik ikon 1 kategori. Iterasi tiap ShopItem
     * sellable di kategori itu, hitung stok yang boleh dijual (protect-valuable-items tetap
     * berlaku), langsung sell() kalau ada stoknya (notify=false, biar GUI yang ngirim 1
     * pesan ringkasan di akhir, bukan spam per jenis item).
     */
    public CategorySellResult sellCategory(Player player, ShopCategory category) {
        double totalMoney = 0;
        int totalItemsSold = 0;
        int protectedSkipped = 0;
        boolean protect = isProtectionEnabled();
        double multiplier = plugin.getConfig().getDouble("economy.sell-multiplier", 1.0);

        for (ShopItem item : category.getItems()) {
            if (!item.isSellable()) continue;
            int owned = countSellable(player, item.getMaterial());
            int qty = owned / item.getAmount();
            if (qty > 0) {
                Result result = sell(player, item, qty, false);
                if (result == Result.SUCCESS) {
                    totalItemsSold += item.getAmount() * qty;
                    totalMoney += item.getSellPrice() * qty * multiplier;
                }
            }
            if (protect) {
                protectedSkipped += InventoryUtils.countProtected(player.getInventory(), item.getMaterial());
            }
        }
        return new CategorySellResult(totalMoney, totalItemsSold, protectedSkipped);
    }

    /** Sama kayak sellCategory tapi lintas banyak kategori sekaligus -- tombol "Jual Semua Kategori" di /sell GUI. */
    public CategorySellResult sellAll(Player player, List<ShopCategory> categories) {
        double totalMoney = 0;
        int totalItemsSold = 0;
        int protectedSkipped = 0;
        for (ShopCategory cat : categories) {
            CategorySellResult r = sellCategory(player, cat);
            totalMoney += r.totalMoney();
            totalItemsSold += r.totalItemsSold();
            protectedSkipped += r.protectedSkipped();
        }
        return new CategorySellResult(totalMoney, totalItemsSold, protectedSkipped);
    }

    /**
     * Kirim pesan error yang sesuai buat hasil buy/sell yang GAGAL (sekaligus isi placeholder
     * %item%, %price%, dll yang dulu gak pernah keganti dan muncul mentah di chat).
     * `qty` = jumlah transaksi yang dicoba (kelipatan item.getAmount()).
     */
    public void reportFailure(Player player, ShopItem item, int qty, Result result) {
        if (result == Result.SUCCESS) return;

        Map<String, String> ph = new HashMap<>();
        ph.put("%item%", item.getDisplayName());
        ph.put("%amount%", String.valueOf(item.getAmount() * qty));

        switch (result) {
            case NOT_ENOUGH_MONEY -> {
                ph.put("%price%", formatMoney(buyTotal(item, qty)));
                messages.send(player, "not-enough-money", ph);
            }
            case INVENTORY_FULL -> messages.send(player, "inventory-full", ph);
            case NOT_ENOUGH_ITEMS -> messages.send(player, "no-items-to-sell", ph);
            case PROTECTED_ITEMS -> {
                ph.put("%protected%", String.valueOf(InventoryUtils.countProtected(player.getInventory(), item.getMaterial())));
                ph.put("%sellable%", String.valueOf(countSellable(player, item.getMaterial())));
                messages.send(player, "sell-protected", ph);
            }
            case NOT_BUYABLE -> messages.send(player, "cannot-buy", ph);
            case NOT_SELLABLE -> messages.send(player, "cannot-sell", ph);
            case NO_ECONOMY -> messages.send(player, "economy-missing", ph);
            case ECONOMY_ERROR -> messages.send(player, "economy-error", ph);
            default -> { /* SUCCESS udah di-return di atas */ }
        }
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
    }

    private double buyTotal(ShopItem item, int qty) {
        double multiplier = plugin.getConfig().getDouble("economy.buy-multiplier", 1.0);
        return item.getBuyPrice() * qty * multiplier;
    }

    public String formatMoney(double amount) {
        if (amount == Math.floor(amount)) {
            return String.format("%,.0f", amount);
        }
        return String.format("%,.2f", amount);
    }
}
