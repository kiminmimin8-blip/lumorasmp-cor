package com.audes.plugin.hud;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.Plugin;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Load "images:" dari config.yml. Sama persis pola-nya dengan
 * RankBadgeRegistry (lihat javadoc di sana) -- codepoint di config
 * WAJIB 1 karakter Private Use Area yang PERSIS sama dengan yang
 * didaftarkan di contents/assets/audes/font/images.json. Registry ini
 * TIDAK generate font JSON otomatis (keterbatasan disengaja, sama
 * alasannya dengan RankBadgeRegistry).
 */
public class ImageRegistry {

    private final Plugin plugin;
    private final Map<String, ImageDefinition> images = new LinkedHashMap<>();

    public ImageRegistry(Plugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig(ConfigurationSection section) {
        images.clear();
        if (section == null) return;

        for (String id : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(id);
            if (s == null) continue;

            String codepoint = s.getString("codepoint");
            if (codepoint == null || codepoint.isEmpty()) {
                plugin.getLogger().warning("[Audes] image '" + id + "' tidak punya 'codepoint' valid, "
                        + "di-skip. Isi 1 karakter Private Use Area, contoh: \"\\uF100\" (lihat contoh bawaan di config.yml).");
                continue;
            }
            if (codepoint.length() != 1) {
                plugin.getLogger().warning("[Audes] image '" + id + "' punya 'codepoint' lebih dari 1 "
                        + "karakter ('" + codepoint + "'), cuma karakter pertama yang dipakai.");
                codepoint = codepoint.substring(0, 1);
            }

            String bedrockCodepoint = s.getString("bedrock_codepoint");
            if (bedrockCodepoint != null && bedrockCodepoint.length() != 1) {
                bedrockCodepoint = bedrockCodepoint.isEmpty() ? null : bedrockCodepoint.substring(0, 1);
            }

            // "font" eksplisit di config menang. Kalau kosong, infer dari
            // prefix id -- konvensi tim: id yang diawali "shop_" hidup di
            // font/shop.json (font id "shop"), selain itu default ke
            // font/images.json (font id "images", lihat javadoc
            // ImageDefinition soal kenapa field ini penting).
            String fontId = s.getString("font");
            if (fontId == null || fontId.isBlank()) {
                fontId = id.startsWith("shop_") ? "shop" : "images";
            }

            images.put(id, new ImageDefinition(id, codepoint, bedrockCodepoint, fontId));
        }
    }

    public Optional<ImageDefinition> get(String id) {
        return Optional.ofNullable(images.get(id));
    }

    public Map<String, ImageDefinition> getAll() {
        return images;
    }
}
