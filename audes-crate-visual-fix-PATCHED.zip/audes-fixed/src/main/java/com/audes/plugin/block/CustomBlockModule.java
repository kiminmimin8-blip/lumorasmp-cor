package com.audes.plugin.block;

import com.audes.plugin.AudesPlugin;
import com.audes.plugin.core.AudesModule;
import com.audes.plugin.resourcepack.ResourcePackManifest;
import org.bukkit.event.HandlerList;

public class CustomBlockModule implements AudesModule {

    private final AudesPlugin plugin;
    private final ResourcePackManifest manifest;
    private BlockRegistry registry;
    private BlockItemFactory factory;
    private CustomBlockListener listener;

    public CustomBlockModule(AudesPlugin plugin, ResourcePackManifest manifest) {
        this.plugin = plugin;
        this.manifest = manifest;
    }

    @Override
    public String getName() {
        return "custom-block";
    }

    @Override
    public void enable() {
        registry = new BlockRegistry(plugin);
        registry.loadFromConfig(plugin.getConfig().getConfigurationSection("blocks"));
        factory = new BlockItemFactory(plugin, manifest);
        listener = new CustomBlockListener(plugin, registry, factory, manifest);
        plugin.getServer().getPluginManager().registerEvents(listener, plugin);
    }

    @Override
    public void disable() {
        if (listener != null) {
            HandlerList.unregisterAll(listener);
        }
    }

    public BlockRegistry getRegistry() {
        return registry;
    }

    public BlockItemFactory getFactory() {
        return factory;
    }
}
