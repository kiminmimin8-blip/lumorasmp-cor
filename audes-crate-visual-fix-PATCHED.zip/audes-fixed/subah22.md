# subah22 — Changelog & Status Plugin Audes

Satu file ini gantiin semua `STATUS-DEV1.md` s.d. `STATUS-DEV15.md` +
`REVISI.md` yang sebelumnya kepisah-pisah. Isinya ringkasan tiap sesi
dev, urut dari awal, biar tim (atau sesi Claude berikutnya) tinggal baca
satu tempat.

**Catatan yang berlaku di SEMUA sesi**: kode ditulis manual mengikuti API
Paper/Adventure yang diketahui, TANPA akses internet buat `mvn package`
dan TANPA server Paper sungguhan buat testing langsung. Setiap sesi
mendokumentasikan asumsi API yang berisiko secara eksplisit (bukan
silent gap) — kalau ada error compile, cek dulu bagian sesi terkait di
bawah sebelum nebak dari nol.

---

## Dev3 — Skeleton awal
Fondasi project: `pom.xml`, struktur modul (`ModuleManager`, interface
`AudesModule`), `AudesPlugin` + `AudesCommand` dasar. Belum ada fitur
konkret, baru arsitektur.

## Dev1 — Custom block dasar (lanjutan Dev4 yang keputus)
`BlockItemFactory` + `CustomBlockListener` — teknik NOTE_BLOCK +
instrument/note sebagai "id" block custom (karena Paper belum punya
block model API resmi). Place/break lewat PDC (persistent data
container), bukan parsing nama/lore.

## Dev4 — Lanjutan skeleton
Resource pack module tahap awal: generator zip + self-host webserver
(`ResourcePackServer`, DIHAPUS di Dev14 — lihat bawah) + join listener
pakai Adventure `ResourcePackRequest`.

## Dev5 — Manifest resource pack + apply model
`ResourcePackManifest`: scan `contents/assets/<namespace>/items/*.json`
jadi daftar model valid. `ToolFactory`/`BlockItemFactory`/
`FurnitureItemFactory` query manifest sebelum `setItemModel()` — kalau
modelKey dikonfigurasi tapi aset tidak ada → warning log sekali (bukan
silent fail/invisible item).

## Dev6 — ✅ Compile pertama SUKSES + Custom Armor Texture
Konfirmasi: `Audes-0_1_0-SNAPSHOT.jar` pertama berhasil di-compile (44
class file cocok 32 source file Dev1-5). Fitur baru: armor custom lewat
`EquippableComponent` (base item tetap armor vanilla asli, visual
di-override).

## Dev7 — Custom Ore
`ToolTier` enum (WOOD→NETHERITE) + `requiredToolTier`/`xpMin`/`xpMax` di
`BlockDefinition`. Backward compatible (default = tidak ada efek).

## Dev8 — Emoji Chat
`EmojiRegistry` (satu regex gabungan, bukan loop per-shortcode) +
`EmojiManager` (Adventure `Component#replaceText`) + `EmojiListener`
(priority LOWEST). Cakupan cuma chat (belum ada modul book/hologram).

## Dev9 — Custom Furniture "Animasi" (toggle-state)
Animasi tekstur murni = resource-pack-side (`.mcmeta`), tidak butuh
kode. Yang butuh kode: toggle-state terpicu interaksi (lampu
nyala/mati dll) — ini yang dibangun.

## Dev10 — ✅ Compile kedua SUKSES + Custom GUI
54 class file, semua modul Dev6-9 lengkap. Fitur baru: `GuiDefinition` +
`GuiButtonDefinition` generik di config `guis:`, tombol jalanin command
list. Keterbatasan didokumentasikan: command tombol jalan sebagai
player (GUI admin-only gagal) — ditutup Dev12.

## Dev11 — Isi Resource Pack (aset nyata)
Sebelumnya semua `modelKey` fallback vanilla karena aset belum ada.
Sesi ini isi placeholder valid (PNG 16x16/64x32 via PIL, bukan file
kosong) untuk semua contoh di config.yml bawaan + `pack.mcmeta`
(`pack_format: 75`).

## Dev12 — Nutup keterbatasan GUI (Dev10)
Opt-in run-as-console PER BARIS command di tombol GUI: prefix
`[console] ` di awal baris → dijalankan lewat
`Bukkit.dispatchCommand(consoleSender, ...)`. Default tidak berubah.

## Dev13 — 4 modul baru + 2 fitur extend
`emote/` (`/emote <id>`, teks ngambang animasi), `structure/`
(`/audes givestructure`, custom tree/decoration multi-block),
`vehicle/`, `entity/`, `hud/` (custom scoreboard/actionbar — sempat
kelupaan di pass pertama, ditambahkan setelah ditanya user).

## Dev14 — Hosting resource pack diganti + Key & Crate item
- **Hosting**: self-host webserver (`ResourcePackServer`) DIHAPUS
  total, diganti auto-upload ke **LobFile** (layanan yang sama dipakai
  ItemsAdder buat "Continuous Uploading") — alasan: self-host rawan
  race condition kalau `/audes reload` dipanggil pas ada yang masih
  download (persis insiden `generated.zip` korup di ItemsAdder tim).
  Config baru: `resource-pack.hosting-mode` (`lobfile` / `external-url`),
  API key di `secret.yml` terpisah dari `config.yml`.
- **`/audes reload`** sekarang beneran regenerate pack (dulu cuma
  reload config file, TODO Dev13 ditutup).
- **7 Key item** (legendary/mythic/vote/earth/fire/water/wind) — texture
  PNG asli di-copy dari archive backup ItemsAdder lama tim, SIAP PAKAI.
- **7 Crate block** — pakai teknik note+instrument yang sudah ada.
  Visual BELUM custom (keterbatasan block-model, lihat Dev1). Mekanisme
  buka-crate (roll loot pakai key) BELUM ada — dulu di ItemsAdder pun
  itu kerjaan plugin terpisah (ExcellentCrates), bukan ItemsAdder
  sendiri.
- Field `lore` baru ditambah ke `ToolDefinition`/`ToolRegistry`/
  `ToolFactory` (belum ada sebelumnya).

## Dev15 — Bedrock support tahap 1 (deteksi player, BUKAN convert pack)
- `bedrock/BedrockPlayerDetector` + `bedrock/FloodgateBridge` — deteksi
  player Bedrock lewat Floodgate (soft-dependency, aman kalau Floodgate
  gak ter-install). `FloodgateBridge` sengaja kelas terpisah supaya JVM
  gak coba load `FloodgateApi` kecuali Floodgate konfirmasi ada.
- `ResourcePackJoinListener` skip total kirim pack Java ke player
  Bedrock (mencegah ke-kick kalau `required: true`, dan pack Java emang
  gak bisa diproses Bedrock).
- **BELUM dikerjakan** (keterbatasan riil, bukan gap kerja): visual
  custom item/block belum ikut ke Bedrock — butuh Geyser custom mapping
  manual + resource pack Bedrock terpisah (format beda total). Ada bug
  upstream masih open di Geyser (per riset saat itu) untuk format
  item_model 1.21.4+ yang Audes pakai.

## Setelah Dev15 — Klarifikasi soal crate
Sempat dibangun modul `crate/` (mekanisme buka-crate: konsumsi key +
roll loot table) — **DIHAPUS lagi** setelah dikonfirmasi tim sudah
pakai **ExcellentCrates** buat urusan reward/gacha. Audes CUKUP
nyediain **custom block**-nya (sudah ada dari Dev14: `crate4_block`,
`crate5_block`, `crate6_block`, `earth_crate_block`, dst) — ExcellentCrates
bind ke block itu lewat `/crate create` diarahkan ke lokasinya, TIDAK
butuh entity, TIDAK butuh kode tambahan apa pun di Audes. Kalau
suatu saat ExcellentCrates dilepas dan mau full self-contained lagi di
Audes, modul `crate/` yang dihapus ini bisa dibangun ulang (pola
lengkapnya: `CrateDefinition`/`CrateLootEntry`/`CrateRegistry`/
`CrateInteractListener`/`CrateModule`, weighted single-pick loot,
opsional reward berupa custom tool lewat `reward-tool-id`) — tapi
JANGAN dipasang lagi selama ExcellentCrates masih aktif, bisa rebutan
event klik kanan di block yang sama.

---

## Dev16 — Badge/logo rank di tab list
Diporting dari ItemsAdder namespace "sanzranks" (sebenarnya aset plugin
BetterRanks yang nempel font ItemsAdder — teknik font-glyph-nya generik,
diporting tanpa perlu plugin BetterRanks). 17 texture badge asli
(owner/admin/staff/dev/helper/builder/verified/player + 8 zodiac)
di-copy dari archive, dibungkus jadi 1 font provider
(`contents/assets/audes/font/rank_badges.json`, codepoint Private Use
Area U+F000-U+F010).

- **`RankBadgeDefinition`/`RankBadgeRegistry`** (baru) — load
  "rank-badges:" config, key HARUS sama dengan key rank di "prefix:".
- **`TabListManager`** — prepend badge (Component + `.font()`) SEBELUM
  prefix teks di nama tab list. Di-skip buat player Bedrock
  (`BedrockPlayerDetector`, lihat Dev15) karena font custom cuma ada di
  resource pack Java yang gak pernah dikirim ke mereka.
- **BELUM DITES visual** — height/ascent font pakai default generik (8/7),
  kemungkinan perlu di-tuning manual di server sungguhan kalau ukuran
  badge kelihatan gak pas.
- **Scoreboard sidebar TIDAK disentuh** (di luar scope kalimat "logo di
  scoreboard" kalau yang dimaksud beneran scoreboard sidebar, bukan tab
  list) — Audes belum punya modul scoreboard sidebar sama sekali, cuma
  bossbar/actionbar (HudModule). Kabari kalau ini juga perlu.

## Dev17 — File convert Bedrock buat Geyser-Spigot
Folder `bedrock/` (baru): mapping custom item Geyser v2
(`custom_mappings/audes_keys.json`) + resource pack Bedrock siap-pasang
(`audes_bedrock_pack.zip`), khusus buat 7 key item. Cara pasang ada di
`bedrock/README.md`.

Block/furniture/armor BELUM ikut ter-convert -- bukan kelupaan, tapi
aset sumbernya di sisi Java sendiri belum ada (block masih teknik
note+instrument, belum ada model/texture asli buat di-convert).
Formatnya diambil dari dokumentasi resmi GeyserMC per Juli 2026, belum
pernah dites di server Geyser sungguhan.

## Dev18 — Fix checkerboard ungu-hitam di crate block (visual bug live)
Bug report: 7 crate block (`crate4/5/6`, `earth/fire/water/wind_crate`)
tampil checkerboard ungu-hitam ("missing texture") di dunia, padahal log
cuma nunjukin warning modelKey buat `audes:blocks/crateN` (bukan
`audes:blocks/crates/crateN`) — dua hal beda yang sempat ketuker analisa
awal:

1. **Warning log (7 baris "modelKey tidak ketemu")** — field `model:` di
   config.yml crate block salah nunjuk (`audes:blocks/crate4` bukannya
   `audes:blocks/crates/crate4`, kurang subfolder `crates/`). Ini cuma
   soal icon item-di-tangan, BUKAN penyebab checkerboard. **Fix**: 7
   field `model:` di config.yml disamain ke path yang beneran ada
   (`audes:blocks/crates/<nama>`, sama kayak `visual-model:`).

2. **Checkerboard di block yang sudah ditanam (bug utama)** — disebabkan
   `ResourcePackManifest` cuma cek file `items/<path>.json` ADA, TIDAK
   pernah cek apakah `model` & `textures` yang DIRUJUK di dalam file itu
   beneran ada. Kalau deploy `contents/` ke server cuma sebagian (folder
   `items/` ke-upload, `models/item/` atau `textures/block/` ketinggalan),
   manifest tetap bilang OK → `CustomBlockListener.spawnVisual()` tetap
   spawn `ItemDisplay` dengan model itu → client render checkerboard
   karena model/texture yang dirujuk gak ada di pack yang dia-download.
   Silent, gak ada log jelas yang nunjuk ke akar masalahnya. **Fix**:
   `ResourcePackManifest.rebuild()` sekarang manggil `validateChain()`
   setelah scan awal — parse tiap `items/*.json`, ikutin field `model`
   ke file model terpisah (`models/item/**.json`), lalu cek semua
   `textures` yang dirujuk di situ beneran ada PNG-nya. Kalau ADA link
   yang putus di mana pun, modelKey itu DIKELUARKAN dari
   `availableModelKeys` (bukan cuma dicatat) — jadi caller (Block/Tool/
   FurnitureItemFactory, CustomBlockListener) otomatis fallback ke
   vanilla + log warning yang JELAS nyebutin file mana yang hilang,
   bukan diem-diem render rusak. Pakai Gson (`com.google.gson`, udah
   kebawa dari `paper-api` scope provided, tidak nambah dependency baru).

**Belum ditutup** (out of scope sesi ini, catat biar gak lupa):
- Validasi rantai yang sama BELUM diterapkan ke `equipment/` (armor
  layer) — pola bug yang sama bisa juga kejadian di situ kalau deploy
  parsial. Kalau muncul laporan armor polos/rusak, cek ini duluan.
- `validateChain()` cuma nyusurin SATU level composite model
  (`"model": {"type": "minecraft:model", "model": "..."}` →
  `models/item/**.json`). Kalau suatu saat dipakai model berlapis
  (`condition`/`select`/`range_dispatch` dengan banyak cabang model),
  validasi ini belum nyusurin semua cabangnya — sengaja permisif
  (loloskan) daripada false-positive.
- Root cause DEPLOYMENT masih perlu ditindaklanjuti manual di server:
  pastikan seluruh `contents/assets/audes/{items,models,textures}/blocks/
  crates/` ke-upload utuh ke `plugins/Audes/contents/`, lalu `/audes
  reload`. Fix di atas cuma mencegah bug ini SILENT lagi ke depannya —
  tidak otomatis nge-upload aset yang emang belum ada di server.

## Dev19 — Fix icon shop rusak (font id ketuker) + info soal logo di GUI
Lanjutan laporan bug visual (Dev18), user konfirmasi logo & shop icon di
GUI profile juga rusak "checkerboard/missing texture".

**Shop icon (bug kode, sudah di-fix)**: SEMUA image lewat `%audes_img_*%`
(termasuk 24+ `shop_*` icon) dikirim ke client dibungkus tag MiniMessage
`<font:audes:images>` yang DI-HARDCODE, padahal `shop_*` glyph
didaftarkan di file font TERPISAH (`contents/assets/audes/font/shop.json`,
font id `audes:shop`) -- bukan di `font/images.json` (font id
`audes:images`, isinya cuma 2 logo server). Client nyari codepoint shop
di font "images" yang gak ada isinya → glyph gak ketemu → kotak
rusak/kosong persis kayak checkerboard. **Fix**: `ImageDefinition`
sekarang punya field `fontId`; `ImageRegistry` infer otomatis dari
prefix id (`shop_*` → font `shop`, selain itu → font `images`, bisa
di-override eksplisit lewat `font:` di config kalau suatu saat ada
kategori baru); `AudesPlaceholders` pakai `imageDef.fontId()` buat
bangun tag, bukan hardcode `images` lagi.

**Logo di panel GUI (bukan bug kode, konfigurasi eksternal)**: screenshot
nunjukin teks `%img_serverlogo%` MENTAH gak ke-replace sama sekali (beda
dari shop icon yang ke-replace tapi salah font). Placeholder Audes yang
BENAR itu `%audes_img_serverlogo%` (WAJIB prefix `audes_`, standar
penamaan PlaceholderAPI per-plugin -- lihat `getIdentifier()` di
`AudesPlaceholders`). GUI/menu yang nampilin panel profile itu (DeluxeMenus
atau sejenisnya, bukan bagian dari source Audes) kemungkinan konfigurasi-nya
masih pakai `%img_serverlogo%` tanpa prefix, jadi PlaceholderAPI gak
tau harus rute ke Audes sama sekali -- tampil mentah. **Perlu dicek
manual** di config GUI-nya (bukan sesuatu yang bisa di-fix dari source
Audes ini karena file config GUI-nya tidak ada di sini).

## Dev20 — Rank badge sekarang bisa dipakai GUI luar (dulu cuma tab list)
Lanjutan Dev19, user tanya soal "rank" -- di screenshot GUI profile,
field "RANK:" nampilin kotak tofu, bukan badge.

**Akar masalah**: badge rank (Dev16) SEBELUM ini cuma bisa dipakai
otomatis lewat `TabListManager` (tab list nama player) — TIDAK ADA
placeholder resmi buat GUI/menu lain nampilin badge yang sama. Kalau
GUI profile itu coba nempel karakter PUA badge secara manual (tanpa
`<font:audes:rank_badges>` yang bener), hasilnya PASTI kotak tofu,
karena font vanilla gak punya glyph di Private Use Area itu — behavior
ini SUDAH didokumentasikan dari awal di javadoc `RankBadgeDefinition`
(bukan celah baru), cuma emang belum ada jalan resmi buat GUI lain
manfaatinnya dengan benar.

**Fix**: tambah placeholder baru `%audes_rank_badge%` di
`AudesPlaceholders` — resolve badge rank player yang login, dibungkus
`<font:audes:rank_badges>` PERSIS sama kayak yang dipakai
`TabListManager` (satu sumber kebenaran, gak ada font id kedua yang
bisa ketuker kayak insiden shop di Dev19), skip ke string kosong buat
player Bedrock (konsisten sama alasan TabListManager skip Bedrock).
Wiring baru: `AudesPlugin` sekarang nyimpen referensi `RankTabModule`
(dulu langsung di-`register()` tanpa disimpan ke field, jadi gak bisa
diakses dari luar) + `RankTabModule.getBadgeRegistry()` ditambahin.

**Perlu ditindaklanjuti manual**: ganti isi field "RANK:" di config GUI
profile itu (DeluxeMenus/sejenisnya, bukan bagian source Audes) supaya
pakai `%audes_rank_badge%` yang baru ini, bukan cara lama yang bikin
tofu.

## Belum dikerjakan sama sekali (per akhir Dev15)
- Mekanisme buka crate (roll loot table pakai key, consume key,
  animasi/efek) — item & block-nya ada (Dev14), logikanya belum.
- Resource pack Bedrock + Geyser custom mapping (visual parity penuh).
- Compile & test di server sungguhan — SELALU jadi langkah wajib
  pertama sebelum production, di setiap sesi.
