package xyz.sanz.shop.command;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import xyz.sanz.shop.ShopSell;
import xyz.sanz.shop.ShopManager;
import xyz.sanz.shop.gui.MenuBuilder;
import xyz.sanz.shop.model.ShopCategory;
import xyz.sanz.shop.model.ShopItem;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * /shopedit             -> buka GUI editor
 * /shopedit reload      -> muat ulang shops.yml dari disk
 * /shopedit additem <kategori> <MATERIAL> <hargaBeli> <hargaJual> [nama...]
 * /shopedit removeitem <kategori> <MATERIAL>
 * /shopedit setprice <kategori> <MATERIAL> <hargaBeli> <hargaJual>
 *
 * Command ini pelengkap GUI shop editor — dipakai kalau mau edit cepat lewat console/chat
 * tanpa buka inventory, misalnya buat scripting atau edit massal.
 */
public class ShopEditCommand implements CommandExecutor, TabCompleter {

    private final ShopSell plugin;

    public ShopEditCommand(ShopSell plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("sanzshop.edit")) {
            sender.sendMessage(plugin.getMessages().get("no-permission"));
            return true;
        }

        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Buka GUI editor cuma bisa in-game. Pakai subcommand kalau dari console.");
                return true;
            }
            MenuBuilder.openEditMainMenu(player, plugin);
            return true;
        }

        ShopManager manager = plugin.getShopManager();
        String sub = args[0].toLowerCase();

        switch (sub) {
            case "reload" -> {
                plugin.reloadConfig();
                manager.load();
                plugin.getResourcePackModule().reloadSettings();
                sender.sendMessage(plugin.getMessages().get("reloaded"));
            }
            case "additem" -> {
                if (args.length < 5) {
                    sender.sendMessage("§cPakai: /shopedit additem <kategori> <MATERIAL> <hargaBeli> <hargaJual> [nama...]");
                    return true;
                }
                ShopCategory cat = manager.getCategory(args[1].toLowerCase());
                if (cat == null) {
                    sender.sendMessage("§cKategori tidak ditemukan.");
                    return true;
                }
                Material mat = Material.matchMaterial(args[2].toUpperCase(Locale.ROOT));
                if (mat == null) {
                    sender.sendMessage(plugin.getMessages().get("invalid-material"));
                    return true;
                }
                double buy, sell;
                try {
                    buy = Double.parseDouble(args[3]);
                    sell = Double.parseDouble(args[4]);
                } catch (NumberFormatException ex) {
                    sender.sendMessage(plugin.getMessages().get("invalid-number"));
                    return true;
                }
                String name = args.length > 5 ? String.join(" ", List.of(args).subList(5, args.length)) : prettyName(mat);
                manager.addItem(cat.getKey(), mat, name, 1, buy, sell);
                sender.sendMessage(plugin.getMessages().get("item-added").replace("%item%", name).replace("%category%", cat.getTitle()));
            }
            case "removeitem" -> {
                if (args.length < 3) {
                    sender.sendMessage("§cPakai: /shopedit removeitem <kategori> <MATERIAL>");
                    return true;
                }
                ShopCategory cat = manager.getCategory(args[1].toLowerCase());
                if (cat == null) {
                    sender.sendMessage("§cKategori tidak ditemukan.");
                    return true;
                }
                Material mat = Material.matchMaterial(args[2].toUpperCase(Locale.ROOT));
                if (mat == null) {
                    sender.sendMessage(plugin.getMessages().get("invalid-material"));
                    return true;
                }
                int index = -1;
                for (int i = 0; i < cat.getItems().size(); i++) {
                    if (cat.getItems().get(i).getMaterial() == mat) { index = i; break; }
                }
                if (index == -1) {
                    sender.sendMessage("§cItem itu tidak ada di kategori ini.");
                    return true;
                }
                ShopItem removed = cat.getItems().get(index);
                manager.removeItem(cat.getKey(), index);
                sender.sendMessage(plugin.getMessages().get("item-removed").replace("%item%", removed.getDisplayName()).replace("%category%", cat.getTitle()));
            }
            case "setprice" -> {
                if (args.length < 5) {
                    sender.sendMessage("§cPakai: /shopedit setprice <kategori> <MATERIAL> <hargaBeli> <hargaJual>");
                    return true;
                }
                ShopCategory cat = manager.getCategory(args[1].toLowerCase());
                if (cat == null) {
                    sender.sendMessage("§cKategori tidak ditemukan.");
                    return true;
                }
                Material mat = Material.matchMaterial(args[2].toUpperCase(Locale.ROOT));
                if (mat == null) {
                    sender.sendMessage(plugin.getMessages().get("invalid-material"));
                    return true;
                }
                ShopItem target = cat.getItems().stream().filter(i -> i.getMaterial() == mat).findFirst().orElse(null);
                if (target == null) {
                    sender.sendMessage("§cItem itu tidak ada di kategori ini.");
                    return true;
                }
                try {
                    target.setBuyPrice(Double.parseDouble(args[3]));
                    target.setSellPrice(Double.parseDouble(args[4]));
                } catch (NumberFormatException ex) {
                    sender.sendMessage(plugin.getMessages().get("invalid-number"));
                    return true;
                }
                manager.save();
                sender.sendMessage(plugin.getMessages().get("item-updated").replace("%item%", target.getDisplayName()));
            }
            default -> sender.sendMessage("§cSubcommand tidak dikenal. Pakai: reload / additem / removeitem / setprice, atau /shopedit tanpa argumen untuk buka GUI.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filterStart(List.of("reload", "additem", "removeitem", "setprice"), args[0]);
        }
        if (args.length == 2 && List.of("additem", "removeitem", "setprice").contains(args[0].toLowerCase())) {
            return filterStart(new ArrayList<>(plugin.getShopManager().getCategories().keySet()), args[1]);
        }
        return List.of();
    }

    private List<String> filterStart(List<String> options, String partial) {
        String p = partial.toLowerCase();
        return options.stream().filter(s -> s.toLowerCase().startsWith(p)).collect(Collectors.toList());
    }

    private String prettyName(Material m) {
        String[] parts = m.name().split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1).toLowerCase()).append(' ');
        }
        return sb.toString().trim();
    }
}
