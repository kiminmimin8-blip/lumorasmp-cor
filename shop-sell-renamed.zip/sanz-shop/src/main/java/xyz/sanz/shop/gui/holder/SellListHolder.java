package xyz.sanz.shop.gui.holder;

import xyz.sanz.shop.model.ShopItem;

import java.util.List;

/**
 * GUI: /sellist -- browsing SEMUA item bisa dijual, flat lintas kategori,
 * dengan mode urutan: "default" (urutan shops.yml), "top" (termahal dulu),
 * "murah" (termurah dulu). Klik kiri/kanan tetap bisa beli/jual langsung,
 * sama kayak menu kategori & hasil pencarian.
 */
public class SellListHolder extends BaseHolder {

    private final String mode;
    private final int page;
    private final List<ShopItem> items;

    public SellListHolder(String mode, int page, List<ShopItem> items) {
        this.mode = mode;
        this.page = page;
        this.items = items;
    }

    public String getMode() {
        return mode;
    }

    public int getPage() {
        return page;
    }

    public List<ShopItem> getItems() {
        return items;
    }
}
