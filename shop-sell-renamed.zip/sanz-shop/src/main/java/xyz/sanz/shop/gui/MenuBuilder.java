package xyz.sanz.shop.gui;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import xyz.sanz.shop.ShopSell;
import xyz.sanz.shop.ShopManager;
import xyz.sanz.shop.gui.holder.*;
import xyz.sanz.shop.model.ShopCategory;
import xyz.sanz.shop.model.SellRecord;
import xyz.sanz.shop.model.ShopItem;
import xyz.sanz.shop.service.RefundManager;
import xyz.sanz.shop.service.ShopService;
import xyz.sanz.shop.util.Messages;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Factory buat semua tampilan GUI ShopSell: menu belanja & menu editor.
 * Semua inventory pakai holder dari package gui.holder supaya GuiListener gampang
 * bedain "ini menu apa" tanpa parsing title.
 */
public final class MenuBuilder {

    public static final int PAGE_SIZE = 45; // slot 0..44 = konten, slot 45..53 = navigasi
    public static final int SLOT_PREV = 45;
    public static final int SLOT_BACK = 49;
    public static final int SLOT_NEXT = 53;
    public static final int SLOT_ADD = 47;
    public static final int SLOT_RENAME_CATEGORY = 51;

    private static final String DIVIDER = "&8&m                    ";

    /**
     * Susun slot kategori jadi piramida menyempit (bukan garis lurus row demi
     * row) -- lebar baris pertama maks 7 (biar ada border kiri-kanan di grid
     * 9 kolom), tiap baris berikutnya -1 lebih sempit, dipusatkan horizontal
     * DAN vertikal di area konten (slot 0-44, 5 baris x 9 kolom). Sisa slot
     * yang gak kepakai diisi kaca filler di fillCategoryBorder().
     *
     * Contoh 18 kategori -> baris lebar 7, 6, 5 (total pas 18), taro di
     * baris tengah (baris ke-2,3,4 dari 5 baris konten), baris paling atas
     * & paling bawah full border.
     */
    /**
     * Kebalikan dari buildCategorySlots: dikasih slot yang diklik, balikin index
     * kategori di list (buat GuiListener nentuin kategori mana yang diklik,
     * sekarang slot udah gak sama dengan index lagi gara-gara layout piramida).
     * Balikin -1 kalau slot itu cuma border/filler, gak ada kategori di situ.
     */
    public static int categoryIndexForSlot(int slot, int totalCategories) {
        int[] slots = buildCategorySlots(totalCategories);
        for (int i = 0; i < slots.length; i++) {
            if (slots[i] == slot) return i;
        }
        return -1;
    }

    static int[] buildCategorySlots(int count) {
        List<Integer> rowWidths = new ArrayList<>();
        int remaining = count;
        int width = Math.min(7, Math.max(1, remaining));
        while (remaining > 0) {
            int w = Math.min(width, remaining);
            rowWidths.add(w);
            remaining -= w;
            width = Math.max(1, width - 1);
        }
        int contentRows = 5; // slot 0-44 = 5 baris x 9 kolom
        int startRow = Math.max(0, (contentRows - rowWidths.size()) / 2);

        int[] slots = new int[count];
        int idx = 0;
        for (int r = 0; r < rowWidths.size() && (startRow + r) < contentRows; r++) {
            int w = rowWidths.get(r);
            int rowIndex = startRow + r;
            int pad = (9 - w) / 2;
            for (int c = 0; c < w && idx < count; c++) {
                slots[idx++] = rowIndex * 9 + pad + c;
            }
        }
        // fallback kalau kategori kebanyakan sampai gak muat piramida (kepotong di atas) -- taro sisanya lurus dari slot 0 ke atas yang belum kepakai, drpd ke-skip
        if (idx < count) {
            boolean[] used = new boolean[45];
            for (int i = 0; i < idx; i++) used[slots[i]] = true;
            for (int s = 0; s < 45 && idx < count; s++) {
                if (!used[s]) slots[idx++] = s;
            }
        }
        return slots;
    }

    private static void fillCategoryBorder(Inventory inv, int[] usedSlots) {
        boolean[] used = new boolean[45];
        for (int s : usedSlots) used[s] = true;
        ItemStack filler = namedItem(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int s = 0; s < 45; s++) {
            if (!used[s]) inv.setItem(s, filler);
        }
    }

    // key kategori/menu -> karakter private-use-area yang di-mapping ke banner PNG
    // lewat assets/sanz/font/banners.json di resource pack "sanz-market-rp".
    private static final Map<String, String> BANNER_CHARS = Map.ofEntries(
            Map.entry("main", "\uF800"),
            Map.entry("edit_main", "\uF801"),
            Map.entry("ore", "\uF802"),
            Map.entry("minerals", "\uF803"),
            Map.entry("blocks", "\uF804"),
            Map.entry("farming", "\uF805"),
            Map.entry("foods", "\uF806"),
            Map.entry("dyes", "\uF807"),
            Map.entry("redstone", "\uF808"),
            Map.entry("drops_common", "\uF80A"),
            Map.entry("drops_rare", "\uF80B"),
            Map.entry("misc", "\uF80C")
    );
    private static final Key BANNER_FONT = Key.key("sanz", "banners");

    /**
     * Judul GUI: pakai banner gambar custom (kalau resource pack terpasang & diaktifkan
     * di config), atau fallback ke teks biasa yang selalu jalan tanpa resource pack.
     */
    private static Component buildTitle(ShopSell plugin, String bannerKey, String legacyFallback) {
        boolean useBanner = plugin.getConfig().getBoolean("shop.use-banner-titles", true);
        String bannerChar = BANNER_CHARS.get(bannerKey);
        if (useBanner && bannerChar != null) {
            return Component.text(bannerChar).font(BANNER_FONT);
        }
        return LegacyComponentSerializer.legacySection().deserialize(legacyFallback);
    }

    private MenuBuilder() {}

    // ================= MENU BELANJA =================

    public static void openMainMenu(Player player, ShopSell plugin) {
        String legacyTitle = Messages.color(plugin.getConfig().getString("shop.main-menu-title", "&8&lSanz Market"));
        Component title = buildTitle(plugin, "main", legacyTitle);
        ShopMainHolder holder = new ShopMainHolder();
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        List<ShopCategory> cats = plugin.getShopManager().getCategoryList();
        int[] slots = buildCategorySlots(cats.size());
        for (int i = 0; i < cats.size(); i++) {
            inv.setItem(slots[i], buildCategoryIcon(cats.get(i), false));
        }
        fillCategoryBorder(inv, slots);
        fillBottomRow(inv);
        inv.setItem(49, namedItem(Material.BARRIER, "&c&lTutup Menu", List.of("&7Keluar dari Sanz Market.")));
        inv.setItem(51, namedItem(Material.COMPASS, "&b&lCari Item", List.of(
                DIVIDER,
                "&7Cari item lewat nama, dari",
                "&7semua kategori sekaligus.",
                DIVIDER,
                "",
                "&e▸ &fKlik &7— Ketik kata kunci di chat"
        )));

        player.openInventory(inv);
    }

    public static void openCategoryMenu(Player player, ShopSell plugin, String categoryKey, int page) {
        ShopCategory cat = plugin.getShopManager().getCategory(categoryKey);
        if (cat == null) {
            player.sendMessage(plugin.getMessages().prefix() + "&cKategori tidak ditemukan. Silakan periksa kembali daftar kategori.");
            return;
        }
        String prefix = Messages.color(plugin.getConfig().getString("shop.category-menu-prefix", "&8&lSanz Market &7» &r"));
        String legacyTitle = prefix + cat.getTitle();
        if (legacyTitle.length() > 32) legacyTitle = legacyTitle.substring(0, 32);
        Component title = buildTitle(plugin, categoryKey, legacyTitle);

        int totalPages = Math.max(1, (int) Math.ceil(cat.getItems().size() / (double) PAGE_SIZE));
        page = Math.max(0, Math.min(page, totalPages - 1));

        ShopCategoryHolder holder = new ShopCategoryHolder(categoryKey, page);
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        List<ShopItem> items = cat.getItems();
        int from = page * PAGE_SIZE;
        int to = Math.min(from + PAGE_SIZE, items.size());
        for (int i = from; i < to; i++) {
            inv.setItem(i - from, buildShopItemIcon(items.get(i)));
        }

        fillNav(inv, page, totalPages, "&aBelanja");
        player.openInventory(inv);
    }

    /**
     * /shop search <keyword> -- cari item lintas SEMUA kategori (cocokin ke
     * nama tampilan ATAU nama material, case-insensitive, substring biasa).
     * Klik kiri/kanan tetap bisa beli/jual langsung dari hasil pencarian,
     * sama kayak di menu kategori biasa.
     */
    public static void openSearchMenu(Player player, ShopSell plugin, String query, int page) {
        String q = query.toLowerCase();
        List<ShopItem> matched = new ArrayList<>();
        for (ShopCategory cat : plugin.getShopManager().getCategoryList()) {
            for (ShopItem item : cat.getItems()) {
                String plain = ChatColor.stripColor(Messages.color(item.getDisplayName())).toLowerCase();
                if (plain.contains(q) || item.getMaterial().name().toLowerCase().contains(q)) {
                    matched.add(item);
                }
            }
        }
        openSearchMenuWithResults(player, plugin, query, page, matched);
    }

    private static void openSearchMenuWithResults(Player player, ShopSell plugin, String query, int page, List<ShopItem> matched) {
        String legacyTitle = "&8&lCari: &f" + query;
        if (legacyTitle.length() > 32) legacyTitle = legacyTitle.substring(0, 32);
        Component title = LegacyComponentSerializer.legacyAmpersand().deserialize(legacyTitle);

        int totalPages = Math.max(1, (int) Math.ceil(matched.size() / (double) PAGE_SIZE));
        page = Math.max(0, Math.min(page, totalPages - 1));

        ShopSearchHolder holder = new ShopSearchHolder(query, page, matched);
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        int from = page * PAGE_SIZE;
        int to = Math.min(from + PAGE_SIZE, matched.size());
        for (int i = from; i < to; i++) {
            inv.setItem(i - from, buildShopItemIcon(matched.get(i)));
        }
        if (matched.isEmpty()) {
            inv.setItem(22, namedItem(Material.BARRIER, "&cGak ada item ketemu", List.of(
                    "&7Gak ada item yang namanya cocok",
                    "&7dengan kata kunci '" + query + "'."
            )));
        }

        fillNav(inv, page, totalPages, "&bHasil Pencarian");
        player.openInventory(inv);
    }

    /** Dipanggil GuiListener pas ganti halaman -- pakai ulang matchedItems yang udah ada, gak nyari ulang. */
    public static void reopenSearchMenu(Player player, ShopSell plugin, ShopSearchHolder oldHolder, int newPage) {
        openSearchMenuWithResults(player, plugin, oldHolder.getQuery(), newPage, oldHolder.getMatchedItems());
    }

    /**
     * /sellist [top|murah] [halaman] -- browsing GUI semua item bisa dijual,
     * flat lintas kategori. "top" = termahal dulu, "murah" = termurah dulu,
     * default = urutan shops.yml apa adanya.
     */
    public static void openSellListMenu(Player player, ShopSell plugin, String mode, int page) {
        List<ShopItem> all = new ArrayList<>();
        for (ShopCategory cat : plugin.getShopManager().getCategoryList()) {
            for (ShopItem item : cat.getItems()) {
                if (item.isSellable()) all.add(item);
            }
        }
        if (mode.equals("top")) {
            all.sort(java.util.Comparator.comparingDouble(ShopItem::getSellPrice).reversed());
        } else if (mode.equals("murah")) {
            all.sort(java.util.Comparator.comparingDouble(ShopItem::getSellPrice));
        }
        openSellListMenuWithResults(player, plugin, mode, page, all);
    }

    private static void openSellListMenuWithResults(Player player, ShopSell plugin, String mode, int page, List<ShopItem> items) {
        String label = switch (mode) {
            case "top" -> "Paling Mahal";
            case "murah" -> "Paling Murah";
            default -> "Semua Item";
        };
        Component title = LegacyComponentSerializer.legacyAmpersand().deserialize("&8&lJual: &f" + label);

        int totalPages = Math.max(1, (int) Math.ceil(items.size() / (double) PAGE_SIZE));
        page = Math.max(0, Math.min(page, totalPages - 1));

        SellListHolder holder = new SellListHolder(mode, page, items);
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        int from = page * PAGE_SIZE;
        int to = Math.min(from + PAGE_SIZE, items.size());
        for (int i = from; i < to; i++) {
            inv.setItem(i - from, buildShopItemIcon(items.get(i)));
        }

        fillNav(inv, page, totalPages, "&a" + label);
        player.openInventory(inv);
    }

    public static void reopenSellListMenu(Player player, ShopSell plugin, SellListHolder oldHolder, int newPage) {
        openSellListMenuWithResults(player, plugin, oldHolder.getMode(), newPage, oldHolder.getItems());
    }

    // ================= MENU REFUND =================

    /**
     * /sellrefund -- daftar penjualan dalam jendela refund, terbaru di atas. Tiap entri =
     * 1 transaksi jual; klik buat batalin (barang balik, uang ditarik lagi). Ikon pakai
     * salinan barang aslinya, jadi kalau ada enchant/nama custom kelihatan di tooltip.
     */
    public static void openRefundMenu(Player player, ShopSell plugin) {
        RefundManager refunds = plugin.getRefundManager();
        List<SellRecord> records = refunds.active(player.getUniqueId());
        if (records.size() > PAGE_SIZE) records = records.subList(0, PAGE_SIZE);

        List<UUID> ids = new ArrayList<>();
        for (SellRecord r : records) ids.add(r.id());

        Component title = LegacyComponentSerializer.legacyAmpersand().deserialize("&8&lRefund Penjualan");
        ShopRefundHolder holder = new ShopRefundHolder(ids);
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        long now = System.currentTimeMillis();
        long window = refunds.windowSeconds() * 1000L;
        for (int i = 0; i < records.size(); i++) {
            inv.setItem(i, buildRefundIcon(plugin, records.get(i), now, window));
        }
        if (records.isEmpty()) {
            inv.setItem(22, namedItem(Material.BARRIER, "&cGak ada penjualan yang bisa direfund", List.of(
                    "&7Refund cuma tersedia &f" + refunds.windowText() + " &7setelah jual."
            )));
        }

        fillBottomRow(inv);
        inv.setItem(45, namedItem(Material.BOOK, "&e&lCara Kerja Refund", List.of(
                DIVIDER,
                "&7Penjualan bisa dibatalin dalam &f" + refunds.windowText() + "&7.",
                "&7Barang asli (termasuk enchant) balik ke",
                "&7inventory, uang hasil jual ditarik lagi",
                "&7ditambah pajak &c" + refunds.trimTaxPercent() + "%&7.",
                "&7Saldo harus cukup & inventory harus muat.",
                DIVIDER
        )));
        inv.setItem(SLOT_BACK, namedItem(Material.BARRIER, "&c&lTutup", List.of("&7Tutup menu refund.")));

        player.openInventory(inv);
    }

    private static ItemStack buildRefundIcon(ShopSell plugin, SellRecord rec, long now, long window) {
        ItemStack stack = rec.stacks().get(0).clone();
        stack.setAmount(Math.max(1, Math.min(stack.getMaxStackSize(), rec.amount())));

        long left = rec.secondsLeft(now, window);
        RefundManager refunds = plugin.getRefundManager();
        double tax = refunds.taxAmount(rec);
        double total = refunds.totalCost(rec);
        List<String> lore = new ArrayList<>();
        lore.add(DIVIDER);
        lore.add("&7Jumlah &8: &f" + rec.amount() + "x");
        lore.add("&7Uang diterima &8: &a" + fmt(rec.price()) + " Money");
        lore.add("&7Pajak refund (&c" + refunds.trimTaxPercent() + "%&7) &8: &c" + fmt(tax) + " Money");
        lore.add("&7Sisa waktu refund &8: &e" + (left / 60) + ":" + String.format("%02d", left % 60));
        if (rec.hasSpecialItems()) {
            lore.add("&d\u2726 Termasuk item spesial (enchant/nama/lore/isi)");
        }
        lore.add(DIVIDER);
        lore.add("");
        lore.add("&a\u25B8 &fKlik &7\u2014 Refund (tarik &6" + fmt(total) + " Money&7)");

        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Messages.color("&f&l" + rec.itemName()));
            List<String> colored = new ArrayList<>();
            for (String line : lore) colored.add(Messages.color(line));
            meta.setLore(colored);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    public static void openEditMainMenu(Player player, ShopSell plugin) {
        String legacyTitle = Messages.color(plugin.getConfig().getString("shop.edit-main-title", "&8&l[EDIT] Sanz Market"));
        Component title = buildTitle(plugin, "edit_main", legacyTitle);
        ShopEditMainHolder holder = new ShopEditMainHolder();
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        List<ShopCategory> cats = plugin.getShopManager().getCategoryList();
        int[] slots = buildCategorySlots(cats.size());
        for (int i = 0; i < cats.size(); i++) {
            inv.setItem(slots[i], buildCategoryIcon(cats.get(i), true));
        }
        fillCategoryBorder(inv, slots);
        fillBottomRow(inv);
        inv.setItem(SLOT_ADD, namedItem(Material.LIME_DYE, "&a&l+ Buat Kategori Baru", List.of(
                DIVIDER,
                "&7Menambahkan kategori kosong baru",
                "&7ke dalam katalog toko.",
                "",
                "&a▸ &fKlik &7— Buat kategori (via chat)"
        )));
        inv.setItem(49, namedItem(Material.BARRIER, "&c&lKeluar dari Editor", List.of("&7Menutup mode pengelolaan toko.")));

        player.openInventory(inv);
    }

    public static void openEditCategoryMenu(Player player, ShopSell plugin, String categoryKey, int page) {
        ShopCategory cat = plugin.getShopManager().getCategory(categoryKey);
        if (cat == null) {
            player.sendMessage(plugin.getMessages().prefix() + "&cKategori tidak ditemukan. Silakan periksa kembali daftar kategori.");
            return;
        }
        String prefix = Messages.color(plugin.getConfig().getString("shop.edit-category-prefix", "&8&l[EDIT] &7» &r"));
        String legacyTitle = prefix + cat.getTitle();
        if (legacyTitle.length() > 32) legacyTitle = legacyTitle.substring(0, 32);
        Component title = buildTitle(plugin, categoryKey, legacyTitle);

        int totalPages = Math.max(1, (int) Math.ceil(cat.getItems().size() / (double) PAGE_SIZE));
        page = Math.max(0, Math.min(page, totalPages - 1));

        ShopEditCategoryHolder holder = new ShopEditCategoryHolder(categoryKey, page);
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        List<ShopItem> items = cat.getItems();
        int from = page * PAGE_SIZE;
        int to = Math.min(from + PAGE_SIZE, items.size());
        for (int i = from; i < to; i++) {
            inv.setItem(i - from, buildEditItemIcon(items.get(i)));
        }

        fillNav(inv, page, totalPages, "&e[EDIT] " + ChatColor.stripColor(cat.getTitle()));
        inv.setItem(SLOT_ADD, namedItem(Material.LIME_DYE, "&a&l+ Tambah Item ke Katalog", List.of(
                DIVIDER,
                "&7Menambahkan entri item baru",
                "&7ke dalam kategori ini.",
                "",
                "&a▸ &fKlik &7— Tambah item (via chat)"
        )));
        inv.setItem(SLOT_RENAME_CATEGORY, namedItem(Material.NAME_TAG, "&e&lKelola Informasi Kategori", List.of(
                DIVIDER,
                "&7Judul saat ini: &f" + cat.getTitle(),
                "&7Ikon saat ini: &f" + cat.getIcon().name(),
                "",
                "&e▸ &fKlik &7— Ganti judul kategori",
                "&e▸ &fShift + Klik &7— Ganti ikon (pakai item di tangan)"
        )));

        player.openInventory(inv);
    }

    public static void openEditItemMenu(Player player, ShopSell plugin, String categoryKey, int itemIndex, int returnPage) {
        ShopCategory cat = plugin.getShopManager().getCategory(categoryKey);
        if (cat == null || itemIndex < 0 || itemIndex >= cat.getItems().size()) {
            player.sendMessage(plugin.getMessages().prefix() + "&cItem tidak ditemukan atau sudah tidak tersedia.");
            return;
        }
        ShopItem item = cat.getItems().get(itemIndex);

        String title = Messages.color("&8&l[EDIT ITEM] &7» &r" + item.getDisplayName());
        if (title.length() > 32) title = title.substring(0, 32);

        ShopEditItemHolder holder = new ShopEditItemHolder(categoryKey, itemIndex, returnPage);
        Inventory inv = Bukkit.createInventory(holder, 27, title);
        holder.setInventory(inv);

        // filler
        ItemStack filler = namedItem(Material.BLACK_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        inv.setItem(4, buildEditItemIcon(item));
        inv.setItem(10, namedItem(Material.OAK_SIGN, "&e&lGanti Nama Tampilan", List.of(
                DIVIDER,
                "&7Nama saat ini:",
                "&f" + item.getDisplayName(),
                "",
                "&e▸ &fKlik &7— Ganti nama (via chat)"
        )));
        inv.setItem(11, namedItem(Material.IRON_PICKAXE, "&e&lGanti Jenis Material", List.of(
                DIVIDER,
                "&7Material saat ini:",
                "&f" + item.getMaterial().name(),
                "",
                "&e▸ &fKlik &7— Ganti material (via chat)",
                "&7Gunakan ID resmi Minecraft,",
                "&7contoh: &fDIAMOND_SWORD"
        )));
        inv.setItem(15, namedItem(Material.GOLD_NUGGET, "&6&lAtur Harga Beli", List.of(
                DIVIDER,
                "&7Harga saat ini: &6" + fmt(item.getBuyPrice()) + " Money",
                "",
                "&e▸ &fKlik &7— Ubah harga (via chat)",
                "&7Isi &c0 &7untuk menonaktifkan pembelian."
        )));
        inv.setItem(16, namedItem(Material.EMERALD, "&a&lAtur Harga Jual", List.of(
                DIVIDER,
                "&7Harga saat ini: &a" + fmt(item.getSellPrice()) + " Money",
                "",
                "&e▸ &fKlik &7— Ubah harga (via chat)",
                "&7Isi &c0 &7untuk menonaktifkan penjualan."
        )));
        inv.setItem(20, namedItem(Material.HOPPER, "&b&lAtur Jumlah per Transaksi", List.of(
                DIVIDER,
                "&7Jumlah saat ini: &f" + item.getAmount() + " item",
                "",
                "&e▸ &fKlik &7— Ubah jumlah (via chat)",
                "&7Contoh: isi 16 agar 1x transaksi",
                "&7setara dengan 16 item."
        )));
        inv.setItem(22, namedItem(Material.BARRIER, "&c&lHapus Item dari Katalog", List.of(
                DIVIDER,
                "&7Tindakan ini akan menghapus item",
                "&7secara permanen dari kategori ini.",
                "",
                "&c▸ &fKlik &7— Hapus sekarang"
        )));
        inv.setItem(24, namedItem(Material.ARROW, "&f&lKembali ke Daftar Item", List.of(
                "&7Kembali tanpa mengubah data lain."
        )));

        player.openInventory(inv);
    }

    // ================= ITEM BUILDERS =================

    private static ItemStack buildCategoryIcon(ShopCategory cat, boolean editMode) {
        List<String> lore = new ArrayList<>();
        lore.add(DIVIDER);
        lore.add("&7Total Item &8: &e" + cat.getItems().size());
        lore.add(DIVIDER);
        lore.add("");
        if (editMode) {
            lore.add("&e▸ &fKlik &7— Kelola kategori ini");
            lore.add("&b▸ &fShift + Klik Kiri &7— Pindah slot kategori ini");
            lore.add("&c▸ &fShift + Klik Kanan &7— Hapus kategori");
        } else {
            lore.add("&a▸ &fKlik &7— Jelajahi kategori ini");
        }
        return namedItem(cat.getIcon(), "&6&l" + cat.getTitle(), lore);
    }

    private static ItemStack buildShopItemIcon(ShopItem item) {
        List<String> lore = new ArrayList<>();
        lore.add(DIVIDER);
        if (item.isBuyable()) {
            lore.add("&7Harga Beli &8: &6" + fmt(item.getBuyPrice()) + " Money &8(&7" + item.getAmount() + "x&8)");
        } else {
            lore.add("&7Harga Beli &8: &8Tidak Tersedia");
        }
        if (item.isSellable()) {
            lore.add("&7Harga Jual &8: &a" + fmt(item.getSellPrice()) + " Money &8(&7" + item.getAmount() + "x&8)");
        } else {
            lore.add("&7Harga Jual &8: &8Tidak Diterima");
        }
        lore.add(DIVIDER);
        lore.add("");
        if (item.isBuyable()) {
            lore.add("&6▸ &fKlik Kiri &7— Beli " + item.getAmount() + " item");
            lore.add("&6▸ &fShift + Klik Kiri &7— Beli " + (item.getAmount() * 64) + " item");
        }
        if (item.isSellable()) {
            lore.add("&a▸ &fKlik Kanan &7— Jual " + item.getAmount() + " item");
            lore.add("&a▸ &fShift + Klik Kanan &7— Jual " + (item.getAmount() * 64) + " item");
        }
        ItemStack stack = namedItem(item.getMaterial(), "&f&l" + item.getDisplayName(), lore);
        stack.setAmount(Math.max(1, Math.min(64, item.getAmount())));
        return stack;
    }

    private static ItemStack buildEditItemIcon(ShopItem item) {
        List<String> lore = List.of(
                DIVIDER,
                "&7Material &8: &f" + item.getMaterial().name(),
                "&7Jumlah / Transaksi &8: &f" + item.getAmount(),
                "&7Harga Beli &8: &6" + fmt(item.getBuyPrice()) + " Money",
                "&7Harga Jual &8: &a" + fmt(item.getSellPrice()) + " Money",
                DIVIDER,
                "",
                "&e▸ &fKlik &7— Kelola item ini",
                "&b▸ &fShift + Klik Kiri &7— Pindah slot item ini",
                "&c▸ &fShift + Klik Kanan &7— Hapus item"
        );
        ItemStack stack = namedItem(item.getMaterial(), "&f&l" + item.getDisplayName(), lore);
        stack.setAmount(Math.max(1, Math.min(64, item.getAmount())));
        return stack;
    }

    private static void fillBottomRow(Inventory inv) {
        ItemStack filler = namedItem(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int i = PAGE_SIZE; i < 54; i++) inv.setItem(i, filler);
    }

    private static void fillNav(Inventory inv, int page, int totalPages, String centerLabel) {
        fillBottomRow(inv);

        if (page > 0) {
            inv.setItem(SLOT_PREV, namedItem(Material.ARROW, "&e&l« Halaman Sebelumnya", List.of("&7Menuju halaman &f" + page + " &7dari &f" + totalPages)));
        }
        if (page < totalPages - 1) {
            inv.setItem(SLOT_NEXT, namedItem(Material.ARROW, "&e&lHalaman Berikutnya »", List.of("&7Menuju halaman &f" + (page + 2) + " &7dari &f" + totalPages)));
        }
        inv.setItem(SLOT_BACK, namedItem(Material.OAK_DOOR, "&f&l" + centerLabel, List.of(
                "&7Halaman &f" + (page + 1) + " &7dari &f" + totalPages,
                "",
                "&a▸ &fKlik &7— Kembali ke menu utama"
        )));
    }

    // ================= MENU KONFIRMASI JUAL (/sell, /sell all) =================

    public static final int SLOT_SELL_CONFIRM = 11;
    public static final int SLOT_SELL_CANCEL = 15;
    private static final int SLOT_SELL_PREVIEW = 13;

    /**
     * GUI konfirmasi 1 layar (3 baris) sebelum benar-benar menjual: item/tombol preview di
     * tengah, tombol "Jual" (hijau) & "Kembali" (merah) di kiri-kanannya. Dipakai untuk
     * /sell (jual tangan) dan /sell all (jual semua) -- bedanya cuma isi preview & aksi
     * pas dikonfirmasi (lihat SellConfirmHolder.Action & GuiListener#handleSellConfirmClick).
     */
    public static void openSellConfirmMenu(Player player, ShopSell plugin, SellConfirmHolder.Action action) {
        ShopService service = plugin.getShopService();
        Component title = LegacyComponentSerializer.legacyAmpersand().deserialize(
                action == SellConfirmHolder.Action.ALL ? "&8&lKonfirmasi Jual Semua" : "&8&lKonfirmasi Jual");

        SellConfirmHolder holder = new SellConfirmHolder(action);
        Inventory inv = Bukkit.createInventory(holder, 27, title);
        holder.setInventory(inv);

        ItemStack filler = namedItem(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);

        ItemStack preview;
        boolean canSell;
        if (action == SellConfirmHolder.Action.ALL) {
            ShopService.SellAllPreview p = service.previewSellAll(player);
            canSell = p.materialCount() > 0;
            List<String> lore = new ArrayList<>(List.of(
                    DIVIDER,
                    "&7Jenis item &8: &f" + p.materialCount(),
                    "&7Total item &8: &f" + p.totalItems() + "x",
                    "&7Estimasi diterima &8: &a" + fmt(p.totalPrice()) + " Money"
            ));
            if (p.protectedCount() > 0) {
                lore.add("&d\u2726 " + p.protectedCount() + "x item dilindungi (enchant/nama/lore/isi) dilewati");
            }
            if (!canSell) lore.add("&c(Gak ada item yang bisa dijual di inventory kamu)");
            lore.add(DIVIDER);
            preview = namedItem(canSell ? Material.CHEST : Material.BARRIER,
                    canSell ? "&e&lJual Semua Item" : "&c&lGak Ada yang Bisa Dijual", lore);
        } else {
            ShopService.HandPreview p = service.previewHand(player);
            canSell = p.sellable();
            List<String> lore = new ArrayList<>();
            lore.add(DIVIDER);
            if (p.item() == null) {
                lore.add("&cItem di tangan kamu gak dijual di shop ini.");
            } else {
                lore.add("&7Jumlah &8: &f" + p.amount() + "x");
                lore.add("&7Estimasi diterima &8: &a" + fmt(p.totalPrice()) + " Money");
                if (p.protectedCount() > 0) {
                    lore.add("&d\u2726 " + p.protectedCount() + "x dilindungi (enchant/nama/lore/isi), gak ikut kejual");
                }
                if (!canSell) lore.add("&c(Stok yang boleh dijual gak cukup)");
            }
            lore.add(DIVIDER);
            preview = namedItem(canSell ? Material.GOLD_INGOT : Material.BARRIER,
                    "&f&l" + (p.itemName() != null ? p.itemName() : "Tangan Kosong"), lore);
        }
        inv.setItem(SLOT_SELL_PREVIEW, preview);

        inv.setItem(SLOT_SELL_CONFIRM, namedItem(
                canSell ? Material.LIME_STAINED_GLASS_PANE : Material.GRAY_STAINED_GLASS_PANE,
                canSell ? "&a&l\u2714 Jual" : "&7&l\u2714 Jual",
                canSell ? List.of("&7Klik untuk konfirmasi penjualan.") : List.of("&7Gak ada yang bisa dijual.")));
        inv.setItem(SLOT_SELL_CANCEL, namedItem(Material.RED_STAINED_GLASS_PANE, "&c&l\u2718 Kembali",
                List.of("&7Batal, tutup menu ini.")));

        player.openInventory(inv);
    }

    // ================= MENU KOTAK JUAL (/sell) =================

    /**
     * GUI: /sell -- kotak jual polos. 45 slot atas kosong buat player naro item yang mau
     * dijual, 9 slot bawah CUMA hiasan (glass pane) -- sengaja TANPA tombol kelipatan/
     * penghasilan apa pun. Penjualan beneran kejadian pas GUI ini ditutup (lihat
     * GuiListener#onClose), bukan lewat tombol konfirmasi.
     */
    public static void openSellBoxMenu(Player player, ShopSell plugin) {
        Component title = LegacyComponentSerializer.legacyAmpersand().deserialize("&8&lJual Item &7(taruh & tutup)");

        SellBoxHolder holder = new SellBoxHolder();
        Inventory inv = Bukkit.createInventory(holder, SellBoxHolder.SIZE, title);
        holder.setInventory(inv);

        ItemStack filler = namedItem(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int i = SellBoxHolder.INPUT_SIZE; i < SellBoxHolder.SIZE; i++) inv.setItem(i, filler);

        player.openInventory(inv);
    }

    private static ItemStack namedItem(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material == null ? Material.STONE : material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Messages.color(name));
            List<String> colored = new ArrayList<>();
            for (String line : lore) colored.add(Messages.color(line));
            meta.setLore(colored);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    public static String fmt(double v) {
        if (v == Math.floor(v)) return String.format("%,.0f", v);
        return String.format("%,.2f", v);
    }
}
