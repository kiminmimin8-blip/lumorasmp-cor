package xyz.sanz.shop.model;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.UUID;

/**
 * Satu transaksi jual yang masih bisa di-refund.
 *
 * `stacks` = salinan PERSIS item yang diambil dari inventory pas jual (meta/enchant ikut),
 * jadi refund balikin barang aslinya, bukan item polos baru.
 * `price` = uang yang BENERAN masuk ke player (udah dikali sell-multiplier), itu yang
 * ditarik lagi pas refund.
 */
public record SellRecord(
        UUID id,
        UUID player,
        long soldAtMillis,
        String itemName,
        Material material,
        int amount,
        double price,
        boolean hasSpecialItems,
        List<ItemStack> stacks
) {

    public boolean isExpired(long nowMillis, long windowMillis) {
        return nowMillis - soldAtMillis >= windowMillis;
    }

    /** Sisa waktu refund dalam detik (minimal 0). */
    public long secondsLeft(long nowMillis, long windowMillis) {
        return Math.max(0L, (windowMillis - (nowMillis - soldAtMillis) + 999L) / 1000L);
    }
}
