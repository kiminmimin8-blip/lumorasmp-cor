package xyz.sanz.shop;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import xyz.sanz.shop.model.ShopCategory;
import xyz.sanz.shop.model.ShopItem;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

/**
 * Pusat penyimpanan & manajemen data toko (kategori + item di dalamnya).
 * Sumber data: plugins/ShopSell/shops.yml (di-copy dari resource bawaan saat pertama kali jalan).
 * Semua perubahan lewat shop editor akan langsung dipanggil save() supaya persisten.
 */
public class ShopManager {

    private final ShopSell plugin;
    private final File file;
    private final Map<String, ShopCategory> categories = new LinkedHashMap<>();

    public ShopManager(ShopSell plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "shops.yml");
    }

    public void load() {
        if (!file.exists()) {
            plugin.saveResource("shops.yml", false);
        }

        categories.clear();
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection catsSec = cfg.getConfigurationSection("categories");
        if (catsSec == null) {
            plugin.getLogger().warning("shops.yml tidak punya section 'categories'. Toko kosong.");
            return;
        }

        for (String key : catsSec.getKeys(false)) {
            ConfigurationSection catSec = catsSec.getConfigurationSection(key);
            if (catSec == null) continue;

            String title = catSec.getString("title", key);
            Material icon = parseMaterial(catSec.getString("icon", "CHEST"), Material.CHEST);
            ShopCategory category = new ShopCategory(key, title, icon);

            List<?> rawItems = catSec.getMapList("items");
            for (Object rawObj : rawItems) {
                if (!(rawObj instanceof Map<?, ?> raw)) continue;
                try {
                    Material mat = parseMaterial(String.valueOf(raw.get("material")), Material.STONE);
                    Object nameObj = raw.get("name");
                    String name = nameObj != null ? String.valueOf(nameObj) : prettyName(mat);
                    int amount = raw.get("amount") != null ? toInt(raw.get("amount")) : 1;
                    double buy = raw.get("buy") != null ? toDouble(raw.get("buy")) : 0;
                    double sell = raw.get("sell") != null ? toDouble(raw.get("sell")) : 0;
                    category.getItems().add(new ShopItem(mat, name, amount, buy, sell));
                } catch (Exception ex) {
                    plugin.getLogger().log(Level.WARNING, "Gagal load 1 item di kategori '" + key + "': " + raw, ex);
                }
            }
            categories.put(key, category);
        }

        plugin.getLogger().info("Berhasil memuat " + categories.size() + " kategori shop (" + countAllItems() + " item).");
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (ShopCategory cat : categories.values()) {
            String base = "categories." + cat.getKey();
            cfg.set(base + ".title", cat.getTitle());
            cfg.set(base + ".icon", cat.getIcon().name());

            List<Map<String, Object>> itemMaps = new ArrayList<>();
            for (ShopItem item : cat.getItems()) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("material", item.getMaterial().name());
                m.put("name", item.getDisplayName());
                m.put("amount", item.getAmount());
                m.put("buy", item.getBuyPrice());
                m.put("sell", item.getSellPrice());
                itemMaps.add(m);
            }
            cfg.set(base + ".items", itemMaps);
        }

        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Gagal menyimpan shops.yml", e);
        }
    }

    // ---------- helpers ----------

    private int toInt(Object o) {
        if (o instanceof Number n) return n.intValue();
        return Integer.parseInt(String.valueOf(o).trim());
    }

    private double toDouble(Object o) {
        if (o instanceof Number n) return n.doubleValue();
        return Double.parseDouble(String.valueOf(o).trim());
    }

    private Material parseMaterial(String name, Material fallback) {
        if (name == null) return fallback;
        Material m = Material.matchMaterial(name.trim());
        return m != null ? m : fallback;
    }

    private String prettyName(Material m) {
        String[] parts = m.name().split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1).toLowerCase()).append(' ');
        }
        return sb.toString().trim();
    }

    public int countAllItems() {
        int total = 0;
        for (ShopCategory c : categories.values()) total += c.getItems().size();
        return total;
    }

    // ---------- akses & CRUD ----------

    public Map<String, ShopCategory> getCategories() {
        return categories;
    }

    public List<ShopCategory> getCategoryList() {
        return new ArrayList<>(categories.values());
    }

    public ShopCategory getCategory(String key) {
        return categories.get(key);
    }

    public boolean categoryExists(String key) {
        return categories.containsKey(key);
    }

    public ShopCategory createCategory(String key, String title, Material icon) {
        ShopCategory cat = new ShopCategory(key, title, icon);
        categories.put(key, cat);
        save();
        return cat;
    }

    public boolean deleteCategory(String key) {
        boolean removed = categories.remove(key) != null;
        if (removed) save();
        return removed;
    }

    public ShopItem addItem(String categoryKey, Material material, String name, int amount, double buy, double sell) {
        ShopCategory cat = categories.get(categoryKey);
        if (cat == null) return null;
        ShopItem item = new ShopItem(material, name, amount, buy, sell);
        cat.getItems().add(item);
        save();
        return item;
    }

    public boolean removeItem(String categoryKey, int index) {
        ShopCategory cat = categories.get(categoryKey);
        if (cat == null) return false;
        if (index < 0 || index >= cat.getItems().size()) return false;
        cat.getItems().remove(index);
        save();
        return true;
    }

    /**
     * Tuker posisi (slot) 2 kategori di menu utama. Urutan tampil kategori
     * ngikutin urutan insersi LinkedHashMap ini -- gak ada field "slot"
     * terpisah, jadi buat "geser slot" ya rebuild urutan map-nya.
     */
    public boolean swapCategoryOrder(String keyA, String keyB) {
        if (keyA.equals(keyB) || !categories.containsKey(keyA) || !categories.containsKey(keyB)) return false;

        List<String> order = new ArrayList<>(categories.keySet());
        int ia = order.indexOf(keyA);
        int ib = order.indexOf(keyB);
        java.util.Collections.swap(order, ia, ib);

        Map<String, ShopCategory> rebuilt = new LinkedHashMap<>();
        for (String k : order) rebuilt.put(k, categories.get(k));
        categories.clear();
        categories.putAll(rebuilt);

        save();
        return true;
    }

    /**
     * Tuker posisi (slot) 2 item dalam satu kategori yang sama. Beda halaman
     * gak masalah -- index di sini indeks ABSOLUT (bukan slot di halaman).
     */
    public boolean swapItemOrder(String categoryKey, int indexA, int indexB) {
        ShopCategory cat = categories.get(categoryKey);
        if (cat == null) return false;
        List<ShopItem> items = cat.getItems();
        if (indexA < 0 || indexA >= items.size() || indexB < 0 || indexB >= items.size() || indexA == indexB) {
            return false;
        }
        java.util.Collections.swap(items, indexA, indexB);
        save();
        return true;
    }

    /**
     * Satu record kecil hasil pencarian item lintas kategori, dipakai /selledit
     * buat nampilin ke mana aja material yang sama nyantol (bisa lebih dari 1
     * kategori, lihat catatan duplikat QUARTZ_BLOCK/SPONGE dkk di shops.yml).
     */
    public record ItemMatch(String categoryKey, String categoryTitle, ShopItem item) {
    }

    public List<ItemMatch> findItemAcrossCategories(String materialQuery) {
        List<ItemMatch> matches = new ArrayList<>();
        String q = materialQuery.toUpperCase(java.util.Locale.ROOT);
        for (ShopCategory cat : categories.values()) {
            for (ShopItem item : cat.getItems()) {
                if (item.getMaterial().name().equals(q)) {
                    matches.add(new ItemMatch(cat.getKey(), cat.getTitle(), item));
                }
            }
        }
        return matches;
    }

    /** Set harga jual 1 item spesifik (dicari lewat kategori supaya gak ambigu kalau material sama muncul di >1 kategori). */
    public boolean setItemSellPrice(String categoryKey, String materialQuery, double newSellPrice) {
        ShopCategory cat = categories.get(categoryKey);
        if (cat == null) return false;
        String q = materialQuery.toUpperCase(java.util.Locale.ROOT);
        for (ShopItem item : cat.getItems()) {
            if (item.getMaterial().name().equals(q)) {
                item.setSellPrice(newSellPrice);
                save();
                return true;
            }
        }
        return false;
    }
}
