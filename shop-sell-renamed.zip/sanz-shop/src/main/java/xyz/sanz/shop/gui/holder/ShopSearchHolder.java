package xyz.sanz.shop.gui.holder;

import xyz.sanz.shop.model.ShopItem;

import java.util.List;

/**
 * GUI: hasil pencarian item lintas SEMUA kategori (mode belanja: klik kiri
 * beli, klik kanan jual -- sama kayak ShopCategoryHolder, bedanya item-nya
 * campur dari kategori manapun).
 *
 * matchedItems dihitung SEKALI pas /shop search dipanggil, disimpan di sini
 * biar ganti halaman / klik item gak perlu nyari ulang dan hasilnya konsisten
 * selama GUI ini masih kebuka (gak berubah walau ada perubahan shop di tempat
 * lain di tengah player browsing hasil pencarian).
 */
public class ShopSearchHolder extends BaseHolder {

    private final String query;
    private final int page;
    private final List<ShopItem> matchedItems;

    public ShopSearchHolder(String query, int page, List<ShopItem> matchedItems) {
        this.query = query;
        this.page = page;
        this.matchedItems = matchedItems;
    }

    public String getQuery() {
        return query;
    }

    public int getPage() {
        return page;
    }

    public List<ShopItem> getMatchedItems() {
        return matchedItems;
    }
}
