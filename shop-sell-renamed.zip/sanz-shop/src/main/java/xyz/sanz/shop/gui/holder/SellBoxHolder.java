package xyz.sanz.shop.gui.holder;

/**
 * GUI: /sell -- "kotak jual". Player tinggal naro item yang mau dijual di 45 slot
 * bagian atas (baris 1-5), lalu tutup GUI-nya -- semua item yang ketaro otomatis
 * kejual (lihat GuiListener#onClose). 9 slot baris paling bawah CUMA HIASAN
 * (glass pane), sengaja TIDAK dikasih tombol kelipatan/penghasilan apa pun --
 * jadi GUI ini murni kotak taruh-jual, gak ada fungsi lain.
 */
public class SellBoxHolder extends BaseHolder {

    /** 6 baris x 9 = 54 slot total; 45 slot pertama (baris 1-5) = input, sisanya (baris 6) = hiasan. */
    public static final int SIZE = 54;
    public static final int INPUT_SIZE = 45;
}
