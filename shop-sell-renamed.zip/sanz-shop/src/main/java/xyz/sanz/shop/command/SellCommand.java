package xyz.sanz.shop.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import xyz.sanz.shop.ShopSell;
import xyz.sanz.shop.gui.MenuBuilder;
import xyz.sanz.shop.gui.holder.SellConfirmHolder;

import java.util.List;

/**
 * /sell -- command utama yang paling sering dicoba pemain duluan (kebiasaan dari
 * plugin shop lain), tapi sebelum ini ShopSell cuma punya /sellhand, /sellist, dkk --
 * jadi /sell selalu "Unknown command" tanpa ada log error apa pun (makanya di server
 * log gak ada bekasnya walau pemain jelas-jelas ngetik /sell).
 *
 *   /sell            -> buka "kotak jual" (GUI 54 slot) -- taruh item yang mau dijual di 45
 *                        slot atas, lalu tutup GUI-nya buat langsung kejual (lihat
 *                        MenuBuilder#openSellBoxMenu & GuiListener#onClose)
 *   /sell hand       -> jual item di tangan LANGSUNG, tanpa konfirmasi (buat yang udah yakin /
 *                        dipakai dari macro/hotkey -- perilaku sama kayak /sellhand)
 *   /sell all        -> buka GUI konfirmasi jual SEMUA item sellable di inventory sekaligus
 *   /sell list       -> sama kayak /sellist (buka GUI semua item yang bisa dijual)
 *
 * Dua yang langsung eksekusi (bare & "all") sengaja dikasih layar konfirmasi karena itu
 * yang paling rawan kepencet gak sengaja / salah paham "ini bakal jual apa sih" -- terutama
 * /sell all yang bisa nyapu banyak jenis item sekaligus dalam 1 klik.
 */
public class SellCommand implements CommandExecutor, TabCompleter {

    private final ShopSell plugin;

    public SellCommand(ShopSell plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }
        if (!player.hasPermission("sanzshop.use")) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return true;
        }

        if (args.length == 0) {
            MenuBuilder.openSellBoxMenu(player, plugin);
            return true;
        }

        if (args[0].equalsIgnoreCase("hand")) {
            SellHandCommand.sellHeldItem(player, plugin);
            return true;
        }

        if (args[0].equalsIgnoreCase("all")) {
            MenuBuilder.openSellConfirmMenu(player, plugin, SellConfirmHolder.Action.ALL);
            return true;
        }

        if (args[0].equalsIgnoreCase("list")) {
            MenuBuilder.openSellListMenu(player, plugin, "default", 0);
            return true;
        }

        player.sendMessage(plugin.getMessages().prefix()
                + "§cGunakan: §f/sell §7(konfirmasi jual tangan) §c| §f/sell all §7(jual semua) §c| §f/sell list");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("hand", "all", "list").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .toList();
        }
        return List.of();
    }
}
