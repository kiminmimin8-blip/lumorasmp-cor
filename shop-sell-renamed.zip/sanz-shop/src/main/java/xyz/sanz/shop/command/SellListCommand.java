package xyz.sanz.shop.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import xyz.sanz.shop.ShopSell;
import xyz.sanz.shop.gui.MenuBuilder;

import java.util.List;

/**
 * /sellist [top|murah] [halaman]  -> buka GUI browsing semua item bisa dijual,
 * flat lintas kategori. Klik kiri/kanan langsung beli/jual dari sini, sama
 * kayak /shop search. Halaman di GUI navigasinya lewat tombol panah, argumen
 * [halaman] cuma buat langsung lompat ke halaman tertentu pas buka.
 */
public class SellListCommand implements CommandExecutor, TabCompleter {

    private final ShopSell plugin;

    public SellListCommand(ShopSell plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini cuma bisa dipakai in-game.");
            return true;
        }

        String mode = "default";
        int pageArgIndex = 0;
        if (args.length > 0 && (args[0].equalsIgnoreCase("top") || args[0].equalsIgnoreCase("murah"))) {
            mode = args[0].equalsIgnoreCase("top") ? "top" : "murah";
            pageArgIndex = 1;
        }

        int page = 0;
        if (args.length > pageArgIndex) {
            try {
                page = Math.max(0, Integer.parseInt(args[pageArgIndex]) - 1);
            } catch (NumberFormatException ignored) {
                // biarin default halaman 1 kalau bukan angka
            }
        }

        MenuBuilder.openSellListMenu(player, plugin, mode, page);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) return List.of();
        return List.of("top", "murah").stream()
                .filter(s -> s.startsWith(args[0].toLowerCase()))
                .toList();
    }
}
