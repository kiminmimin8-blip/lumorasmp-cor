package xyz.sanz.shop.gui.holder;

/**
 * GUI konfirmasi sebelum eksekusi jual (dipakai /sell dan /sell all).
 *
 * PENTING: preview yang ditampilin pas GUI dibuka cuma buat ditonton -- begitu tombol
 * "Jual" diklik, jumlah & harga dihitung ULANG dari kondisi inventory TERKINI (persis
 * kayak /sellhand), bukan dari angka yang kebaca pas GUI pertama kali dibuka. Jadi kalau
 * player sempet mindahin/naro item di inventory-nya sendiri selagi GUI ini kebuka, gak
 * ada data basi yang ke-eksekusi.
 */
public class SellConfirmHolder extends BaseHolder {

    public enum Action { HAND, ALL }

    private final Action action;

    public SellConfirmHolder(Action action) {
        this.action = action;
    }

    public Action getAction() {
        return action;
    }
}
