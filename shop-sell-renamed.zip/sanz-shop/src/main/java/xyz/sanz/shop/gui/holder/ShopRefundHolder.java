package xyz.sanz.shop.gui.holder;

import java.util.List;
import java.util.UUID;

/**
 * GUI: daftar penjualan yang bisa di-refund (/sellrefund).
 *
 * recordIds[i] = id SellRecord yang ditampilin di slot i. Klik dicocokin lewat id (bukan
 * lewat posisi di list terkini), jadi kalau daftarnya udah berubah / entrinya kadaluarsa
 * pas GUI masih kebuka, klik lama gak bakal nge-refund entri yang salah.
 */
public class ShopRefundHolder extends BaseHolder {

    private final List<UUID> recordIds;

    public ShopRefundHolder(List<UUID> recordIds) {
        this.recordIds = recordIds;
    }

    public List<UUID> getRecordIds() {
        return recordIds;
    }
}
