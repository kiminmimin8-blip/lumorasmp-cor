package xyz.sanz.shop.service;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import xyz.sanz.shop.EconomyHook;
import xyz.sanz.shop.ShopSell;
import xyz.sanz.shop.model.SellRecord;
import xyz.sanz.shop.util.InventoryUtils;
import xyz.sanz.shop.util.Messages;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Riwayat jual jangka pendek buat fitur /sellrefund.
 *
 * - Tiap ShopService#sell yang sukses nyatet 1 SellRecord (barang asli + uang yang masuk).
 * - Record cuma hidup `sell-refund.window-seconds` detik (default 180 = 3 menit), setelah itu
 *   dibuang -- baik lewat pengecekan pas diakses maupun task pembersih berkala.
 * - Semua jalan di main thread (command, klik GUI, scheduler sync), jadi gak butuh lock, dan
 *   1 record gak mungkin ke-refund 2x: record dihapus SEBELUM barang dikasih balik.
 * - Riwayat yang masih aktif disimpen ke sell-history.yml pas plugin mati (restart/reload)
 *   dan dimuat lagi pas nyala, jadi restart di tengah jendela 3 menit gak ngilangin hak refund.
 */
public class RefundManager {

    /** Batas record per player -- disesuain sama 45 slot konten di GUI refund. */
    public static final int MAX_ENTRIES_PER_PLAYER = 45;

    public enum RefundResult {
        SUCCESS,
        NOT_FOUND,
        NOT_ENOUGH_MONEY,
        INVENTORY_FULL,
        NO_ECONOMY,
        ECONOMY_ERROR
    }

    private final ShopSell plugin;
    private final Map<UUID, List<SellRecord>> records = new HashMap<>();
    private BukkitTask cleanupTask;

    public RefundManager(ShopSell plugin) {
        this.plugin = plugin;
    }

    // ================= konfigurasi =================

    public boolean isEnabled() {
        return plugin.getConfig().getBoolean("sell-refund.enabled", true);
    }

    public int windowSeconds() {
        return Math.max(1, plugin.getConfig().getInt("sell-refund.window-seconds", 180));
    }

    private long windowMillis() {
        return windowSeconds() * 1000L;
    }

    /** Persen pajak refund, dipotong dari harga jual ASLI (bukan dari saldo pemain). Default 2%. */
    public double taxPercent() {
        return Math.max(0.0, plugin.getConfig().getDouble("sell-refund.tax-percent", 2.0));
    }

    /** Nominal pajak buat 1 record (persen dari `price` -- uang yang dulu diterima pas jual). */
    public double taxAmount(SellRecord rec) {
        return rec.price() * (taxPercent() / 100.0);
    }

    /**
     * Total yang ditarik dari saldo pemain buat refund = harga jual asli + pajak.
     * Jadi refund BUKAN uang gratis: pemain balik ke kondisi sebelum jual, dikurangi pajak
     * kecil sebagai biaya pembatalan (nyegah orang jual-refund-jual-refund buat cari celah).
     */
    public double totalCost(SellRecord rec) {
        return rec.price() + taxAmount(rec);
    }

    // ================= lifecycle =================

    public void start() {
        cleanupTask = plugin.getServer().getScheduler()
                .runTaskTimer(plugin, this::purgeExpired, 20L * 30, 20L * 30);
    }

    public void stop() {
        if (cleanupTask != null) {
            cleanupTask.cancel();
            cleanupTask = null;
        }
    }

    // ================= pencatatan =================

    public void record(Player player, String itemName, Material material, int amount, double price, List<ItemStack> stacks) {
        if (!isEnabled() || stacks.isEmpty()) return;

        boolean special = false;
        List<ItemStack> copies = new ArrayList<>();
        for (ItemStack s : stacks) {
            copies.add(s.clone());
            if (InventoryUtils.isValuable(s)) special = true;
        }

        SellRecord rec = new SellRecord(UUID.randomUUID(), player.getUniqueId(), System.currentTimeMillis(),
                itemName, material, amount, price, special, copies);

        List<SellRecord> list = records.computeIfAbsent(player.getUniqueId(), k -> new ArrayList<>());
        list.add(rec);
        while (list.size() > MAX_ENTRIES_PER_PLAYER) {
            list.remove(0); // buang yang paling lama
        }
    }

    /** Record yang masih dalam jendela refund, TERBARU di atas. */
    public List<SellRecord> active(UUID playerId) {
        List<SellRecord> list = records.get(playerId);
        if (list == null) return List.of();

        long now = System.currentTimeMillis();
        long window = windowMillis();
        list.removeIf(r -> r.isExpired(now, window));
        if (list.isEmpty()) {
            records.remove(playerId);
            return List.of();
        }
        List<SellRecord> out = new ArrayList<>(list);
        java.util.Collections.reverse(out);
        return out;
    }

    /** Cari 1 record aktif milik player (null kalau gak ada / udah kadaluarsa). */
    public SellRecord find(UUID playerId, UUID recordId) {
        for (SellRecord r : active(playerId)) {
            if (r.id().equals(recordId)) return r;
        }
        return null;
    }

    /** Teks jendela refund buat pesan, contoh "3 menit" (atau "90 detik" kalau bukan kelipatan menit). */
    public String windowText() {
        int s = windowSeconds();
        return s % 60 == 0 ? (s / 60) + " menit" : s + " detik";
    }

    /** Teks persen pajak tanpa .0 kalau bulat, misal "2" bukan "2.0" (tapi "2.5" tetap "2.5"). */
    public String trimTaxPercent() {
        double t = taxPercent();
        return t == Math.floor(t) ? String.valueOf((long) t) : String.valueOf(t);
    }

    /** Kirim pesan hasil refund ke player (rec = record yang dicoba di-refund, boleh null kalau gak ketemu). */
    public void report(Player player, RefundResult result, SellRecord rec) {
        Messages messages = plugin.getMessages();
        Map<String, String> ph = new HashMap<>();
        ph.put("%window%", windowText());
        if (rec != null) {
            ph.put("%amount%", String.valueOf(rec.amount()));
            ph.put("%item%", rec.itemName());
            ph.put("%price%", plugin.getShopService().formatMoney(rec.price()));
            ph.put("%tax%", plugin.getShopService().formatMoney(taxAmount(rec)));
            ph.put("%total%", plugin.getShopService().formatMoney(totalCost(rec)));
            ph.put("%taxpercent%", trimTaxPercent());
        }
        switch (result) {
            case SUCCESS -> {
                messages.send(player, "refund-success", ph);
                player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
                return;
            }
            case NOT_FOUND -> messages.send(player, "refund-not-found", ph);
            case NOT_ENOUGH_MONEY -> messages.send(player, "refund-not-enough-money", ph);
            case INVENTORY_FULL -> messages.send(player, "refund-inventory-full", ph);
            case NO_ECONOMY -> messages.send(player, "economy-missing", ph);
            case ECONOMY_ERROR -> messages.send(player, "economy-error", ph);
        }
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
    }

    public void purgeExpired() {
        long now = System.currentTimeMillis();
        long window = windowMillis();
        records.values().forEach(list -> list.removeIf(r -> r.isExpired(now, window)));
        records.values().removeIf(List::isEmpty);
    }

    // ================= refund =================

    public RefundResult refund(Player player, UUID recordId) {
        SellRecord rec = find(player.getUniqueId(), recordId);
        if (rec == null) return RefundResult.NOT_FOUND;

        if (!EconomyHook.isReady()) return RefundResult.NO_ECONOMY;
        Economy econ = EconomyHook.get();

        // uang hasil jual + pajak %-nya harus dikembalikan -- kalau udah kepake, refund ditolak
        double totalCost = totalCost(rec);
        if (econ.getBalance(player) < totalCost) return RefundResult.NOT_ENOUGH_MONEY;
        if (!InventoryUtils.canFit(player.getInventory(), rec.stacks())) return RefundResult.INVENTORY_FULL;

        EconomyResponse resp = econ.withdrawPlayer(player, totalCost);
        if (!resp.transactionSuccess()) return RefundResult.ECONOMY_ERROR;

        // hapus record DULU, baru kasih barang -- biar mustahil ke-refund dua kali
        List<SellRecord> list = records.get(player.getUniqueId());
        if (list != null) {
            final UUID id = rec.id();
            list.removeIf(r -> r.id().equals(id));
            if (list.isEmpty()) records.remove(player.getUniqueId());
        }
        InventoryUtils.giveOrDrop(player, rec.stacks());

        plugin.getLogger().info("[Refund] " + player.getName() + " refund " + rec.amount() + "x "
                + rec.material().name() + " (" + plugin.getShopService().formatMoney(totalCost)
                + " Money ditarik balik, termasuk pajak " + plugin.getShopService().formatMoney(taxAmount(rec)) + ")");
        return RefundResult.SUCCESS;
    }

    // ================= persistensi =================

    private File file() {
        return new File(plugin.getDataFolder(), "sell-history.yml");
    }

    /** Simpen record yang masih aktif ke disk (dipanggil pas onDisable). */
    public void save() {
        purgeExpired();
        File f = file();
        if (records.isEmpty()) {
            if (f.exists() && !f.delete()) {
                plugin.getLogger().warning("Gagal menghapus sell-history.yml lama.");
            }
            return;
        }

        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, List<SellRecord>> e : records.entrySet()) {
            for (SellRecord r : e.getValue()) {
                String base = "records." + e.getKey() + "." + r.id();
                yml.set(base + ".sold-at", r.soldAtMillis());
                yml.set(base + ".item-name", r.itemName());
                yml.set(base + ".material", r.material().name());
                yml.set(base + ".amount", r.amount());
                yml.set(base + ".price", r.price());
                yml.set(base + ".special", r.hasSpecialItems());
                yml.set(base + ".stacks", r.stacks());
            }
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(f);
        } catch (IOException ex) {
            plugin.getLogger().warning("Gagal menyimpan sell-history.yml: " + ex.getMessage());
        }
    }

    /** Muat record yang belum kadaluarsa dari disk (dipanggil pas onEnable). */
    public void load() {
        File f = file();
        if (!f.exists()) return;

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(f);
        ConfigurationSection root = yml.getConfigurationSection("records");
        if (root == null) return;

        long now = System.currentTimeMillis();
        long window = windowMillis();
        int loaded = 0;

        for (String playerKey : root.getKeys(false)) {
            UUID playerId;
            try {
                playerId = UUID.fromString(playerKey);
            } catch (IllegalArgumentException ex) {
                continue;
            }
            ConfigurationSection playerSec = root.getConfigurationSection(playerKey);
            if (playerSec == null) continue;

            for (String idKey : playerSec.getKeys(false)) {
                ConfigurationSection s = playerSec.getConfigurationSection(idKey);
                if (s == null) continue;
                try {
                    UUID id = UUID.fromString(idKey);
                    long soldAt = s.getLong("sold-at");
                    if (now - soldAt >= window) continue;

                    Material mat = Material.matchMaterial(s.getString("material", ""));
                    if (mat == null) continue;

                    List<ItemStack> stacks = new ArrayList<>();
                    List<?> raw = s.getList("stacks");
                    if (raw != null) {
                        for (Object o : raw) {
                            if (o instanceof ItemStack is) stacks.add(is);
                        }
                    }
                    if (stacks.isEmpty()) continue;

                    SellRecord rec = new SellRecord(id, playerId, soldAt,
                            s.getString("item-name", mat.name()), mat,
                            s.getInt("amount"), s.getDouble("price"), s.getBoolean("special"), stacks);
                    records.computeIfAbsent(playerId, k -> new ArrayList<>()).add(rec);
                    loaded++;
                } catch (Exception ex) {
                    plugin.getLogger().warning("Entry sell-history.yml '" + idKey + "' dilewati (rusak): " + ex.getMessage());
                }
            }
        }
        // urutkan lama -> baru per player (urutan file YAML gak dijamin)
        records.values().forEach(list -> list.sort(java.util.Comparator.comparingLong(SellRecord::soldAtMillis)));
        if (loaded > 0) {
            plugin.getLogger().info("Memuat " + loaded + " riwayat jual yang masih bisa di-refund.");
        }
    }
}
