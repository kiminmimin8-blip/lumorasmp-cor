package xyz.sanz.shop.util;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.BundleMeta;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Helper inventory buat jual-beli.
 *
 * PENTING: semua fungsi di sini cuma nyentuh SLOT PENYIMPANAN (hotbar + tas, 36 slot) lewat
 * getStorageContents(). Sebelumnya dipakai getContents(), padahal di PlayerInventory itu
 * ikut nyertain slot armor (helm/chestplate/legging/boots yang lagi dipakai) + offhand --
 * jadi jual DIAMOND_CHESTPLATE bisa ikut "nyabut" chestplate yang lagi dipakai.
 */
public final class InventoryUtils {

    private static final int STORAGE_SIZE = 36;

    private InventoryUtils() {}

    /**
     * Item "bagus" = item yang nilainya jauh di atas harga dasar material-nya, jadi
     * berbahaya kalau ke-sell sama kayak item polos:
     * enchant, nama custom, lore, attribute custom, enchanted book yang ada isinya,
     * shulker/chest/spawner yang nyimpen data block, bundle berisi, armor ber-trim.
     * Durability (damage) SENGAJA gak dihitung -- pickaxe yang udah kepake tetap item polos.
     */
    public static boolean isValuable(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return false;
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return false;

        if (meta.hasEnchants() || meta.hasDisplayName() || meta.hasLore() || meta.hasAttributeModifiers()) {
            return true;
        }
        if (meta instanceof EnchantmentStorageMeta esm && esm.hasStoredEnchants()) return true;
        if (meta instanceof BundleMeta bundle && bundle.hasItems()) return true;
        if (meta instanceof BlockStateMeta bsm && bsm.hasBlockState()) return true;
        if (meta instanceof ArmorMeta armor && armor.hasTrim()) return true;
        return false;
    }

    /** Apakah stack ini boleh dijual sebagai `material`? (material cocok + lolos proteksi kalau aktif). */
    private static boolean sellable(ItemStack stack, Material material, boolean protectValuable) {
        if (stack == null || stack.getType() != material) return false;
        return !(protectValuable && isValuable(stack));
    }

    /** Total jumlah material di slot penyimpanan, TANPA peduli item bagus atau bukan. */
    public static int countMaterial(Inventory inv, Material material) {
        int total = 0;
        for (ItemStack stack : inv.getStorageContents()) {
            if (stack != null && stack.getType() == material) {
                total += stack.getAmount();
            }
        }
        return total;
    }

    /** Jumlah material yang BOLEH dijual (kalau protectValuable aktif, item bagus gak dihitung). */
    public static int countSellable(Inventory inv, Material material, boolean protectValuable) {
        int total = 0;
        for (ItemStack stack : inv.getStorageContents()) {
            if (sellable(stack, material, protectValuable)) {
                total += stack.getAmount();
            }
        }
        return total;
    }

    /** Jumlah material yang DILINDUNGI (item bagus) -- dipakai buat ngasih tau player kenapa gak kejual. */
    public static int countProtected(Inventory inv, Material material) {
        int total = 0;
        for (ItemStack stack : inv.getStorageContents()) {
            if (stack != null && stack.getType() == material && isValuable(stack)) {
                total += stack.getAmount();
            }
        }
        return total;
    }

    /**
     * Ambil `amount` material dari slot penyimpanan (yang boleh dijual aja) dan balikin
     * salinan PERSIS stack yang diambil, biar bisa disimpen di riwayat refund dan dikembaliin
     * utuh (meta, enchant, dll ikut). Asumsikan udah dicek cukup lewat countSellable().
     */
    public static List<ItemStack> removeSellable(Inventory inv, Material material, int amount, boolean protectValuable) {
        List<ItemStack> removed = new ArrayList<>();
        int remaining = amount;
        ItemStack[] contents = inv.getStorageContents();
        for (int i = 0; i < contents.length && remaining > 0; i++) {
            ItemStack stack = contents[i];
            if (!sellable(stack, material, protectValuable)) continue;

            int take = Math.min(stack.getAmount(), remaining);
            remaining -= take;

            ItemStack taken = stack.clone();
            taken.setAmount(take);
            removed.add(taken);

            int newAmount = stack.getAmount() - take;
            // set eksplisit lewat setItem() supaya gak bergantung pada apakah getStorageContents()
            // mengembalikan referensi live atau salinan (beda-beda antar implementasi server).
            if (newAmount <= 0) {
                inv.setItem(i, null);
            } else {
                ItemStack left = stack.clone();
                left.setAmount(newAmount);
                inv.setItem(i, left);
            }
        }
        return removed;
    }

    /** Cek apakah inventory cukup ruang untuk menampung `amount` item polos material tertentu. */
    public static boolean hasSpaceFor(Inventory inv, Material material, int amount) {
        int maxStack = material.getMaxStackSize();
        int freeSlots = 0;
        int extraSpace = 0;
        for (ItemStack stack : inv.getStorageContents()) {
            if (stack == null || stack.getType() == Material.AIR) {
                freeSlots++;
            } else if (stack.getType() == material && stack.getAmount() < maxStack) {
                extraSpace += (maxStack - stack.getAmount());
            }
        }
        long capacity = (long) freeSlots * maxStack + extraSpace;
        return capacity >= amount;
    }

    /**
     * Cek apakah SEMUA `items` muat di slot penyimpanan inventory ini, tanpa beneran ngubah
     * inventory-nya: dicoba dulu di inventory tiruan (36 slot, isi salinan slot penyimpanan
     * asli), jadi aturan stacking (max stack per item, meta beda = gak bisa digabung) persis
     * sama kayak pas beneran di-add.
     */
    public static boolean canFit(Inventory inv, Collection<ItemStack> items) {
        Inventory sim = Bukkit.createInventory(null, STORAGE_SIZE);
        ItemStack[] storage = inv.getStorageContents();
        for (int i = 0; i < storage.length && i < STORAGE_SIZE; i++) {
            if (storage[i] != null) sim.setItem(i, storage[i].clone());
        }
        for (ItemStack item : items) {
            if (!sim.addItem(item.clone()).isEmpty()) return false;
        }
        return true;
    }

    /** Kasih item ke player; kalau inventory penuh sisanya di-drop di kaki player (gak ada yang ilang). */
    public static void giveOrDrop(Player player, Collection<ItemStack> items) {
        for (ItemStack item : items) {
            player.getInventory().addItem(item.clone()).values()
                    .forEach(leftover -> player.getWorld().dropItemNaturally(player.getLocation(), leftover));
        }
    }

    /**
     * Kasih `amount` item POLOS material ke inventory pemain, otomatis kepotong-potong per
     * max stack size. Sisa yang beneran gak muat (harusnya udah dicek lewat hasSpaceFor
     * sebelum manggil ini) di-drop di kaki pemain, drpd ilang gitu aja. Dipakai ShopService#buy.
     */
    public static void giveItems(Player player, Material material, int amount) {
        int remaining = amount;
        int maxStack = material.getMaxStackSize();
        while (remaining > 0) {
            int give = Math.min(maxStack, remaining);
            ItemStack stack = new ItemStack(material, give);
            player.getInventory().addItem(stack).values()
                    .forEach(leftover -> player.getWorld().dropItemNaturally(player.getLocation(), leftover));
            remaining -= give;
        }
    }
}
