package xyz.sanz.rp.model;

import java.util.UUID;

/**
 * Satu entri resource pack yang dikelola plugin ini. Key adalah identifier bebas
 * (dipakai lewat command), uuid adalah ID protokol Minecraft buat pack ini (persisten,
 * dipakai supaya bisa dicabut lagi secara spesifik lewat removeResourcePack(UUID)).
 */
public class ResourcePackEntry {

    private final String key;
    private final UUID uuid;
    private String url;
    private String sha1;
    private boolean required;
    private boolean enabled;
    private String prompt;

    public ResourcePackEntry(String key, UUID uuid, String url, String sha1,
                              boolean required, boolean enabled, String prompt) {
        this.key = key;
        this.uuid = uuid;
        this.url = url;
        this.sha1 = sha1 == null ? "" : sha1;
        this.required = required;
        this.enabled = enabled;
        this.prompt = prompt == null ? "" : prompt;
    }

    public String getKey() {
        return key;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSha1() {
        return sha1;
    }

    public void setSha1(String sha1) {
        this.sha1 = sha1 == null ? "" : sha1;
    }

    public boolean isRequired() {
        return required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getPrompt() {
        return prompt;
    }

    public void setPrompt(String prompt) {
        this.prompt = prompt == null ? "" : prompt;
    }
}
