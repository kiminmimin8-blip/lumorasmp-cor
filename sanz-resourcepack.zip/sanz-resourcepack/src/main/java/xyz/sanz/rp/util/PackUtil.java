package xyz.sanz.rp.util;

import java.util.HexFormat;

public final class PackUtil {

    private PackUtil() {}

    /**
     * Convert string hex SHA-1 (40 karakter) ke byte[20] sesuai yang diminta
     * Player#setResourcePack(). PENTING: Paper mewajibkan hash null ATAU persis
     * 20 byte -- array kosong/salah panjang akan lempar IllegalArgumentException.
     * Makanya method ini return null (bukan array kosong) kalau input gak valid.
     */
    public static byte[] hashFromHex(String hex) {
        if (hex == null) return null;
        String clean = hex.trim();
        if (clean.isEmpty()) return null;
        if (clean.length() != 40) return null;
        try {
            byte[] bytes = HexFormat.of().parseHex(clean);
            return bytes.length == 20 ? bytes : null;
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    public static boolean isValidSha1(String hex) {
        return hashFromHex(hex) != null;
    }
}
