package xyz.sanz.rp.util;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import xyz.sanz.rp.SanzResourcePack;

import java.util.Map;

public class Messages {

    private final SanzResourcePack plugin;

    public Messages(SanzResourcePack plugin) {
        this.plugin = plugin;
    }

    private String raw(String key) {
        String s = plugin.getConfig().getString("messages." + key, key);
        return s == null ? key : s;
    }

    public String prefix() {
        return color(raw("prefix"));
    }

    public String get(String key) {
        return color(prefix() + raw(key));
    }

    public String get(String key, Map<String, String> placeholders) {
        String msg = get(key);
        for (Map.Entry<String, String> e : placeholders.entrySet()) {
            msg = msg.replace(e.getKey(), e.getValue());
        }
        return msg;
    }

    public void send(CommandSender to, String key) {
        to.sendMessage(get(key));
    }

    public void send(CommandSender to, String key, Map<String, String> placeholders) {
        to.sendMessage(get(key, placeholders));
    }

    public static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}
