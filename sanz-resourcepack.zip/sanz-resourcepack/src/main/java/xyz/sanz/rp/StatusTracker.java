package xyz.sanz.rp;

import org.bukkit.event.player.PlayerResourcePackStatusEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Simpan status resource pack terakhir yang dilaporkan tiap pemain (accepted/declined/
 * loaded/gagal/dll), supaya admin bisa cek lewat /sanzpack status <pemain>.
 * Data ini cuma in-memory (reset tiap restart), gak perlu persisten ke disk.
 */
public class StatusTracker {

    private final Map<UUID, Map<UUID, PlayerResourcePackStatusEvent.Status>> data = new ConcurrentHashMap<>();

    public void record(UUID playerId, UUID packId, PlayerResourcePackStatusEvent.Status status) {
        data.computeIfAbsent(playerId, k -> new ConcurrentHashMap<>()).put(packId, status);
    }

    public Map<UUID, PlayerResourcePackStatusEvent.Status> getStatuses(UUID playerId) {
        return data.getOrDefault(playerId, Map.of());
    }

    public void clear(UUID playerId) {
        data.remove(playerId);
    }
}
