package xyz.sanz.rp;

import xyz.sanz.rp.command.SanzPackCommand;
import xyz.sanz.rp.listener.JoinListener;
import xyz.sanz.rp.listener.StatusListener;
import xyz.sanz.rp.util.Messages;
import org.bukkit.plugin.java.JavaPlugin;

public class SanzResourcePack extends JavaPlugin {

    private ResourcePackManager packManager;
    private StatusTracker statusTracker;
    private Messages messages;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.messages = new Messages(this);
        this.statusTracker = new StatusTracker();
        this.packManager = new ResourcePackManager(this);
        this.packManager.load();

        getServer().getPluginManager().registerEvents(new JoinListener(this), this);
        getServer().getPluginManager().registerEvents(new StatusListener(this), this);

        var cmd = getCommand("sanzpack");
        if (cmd != null) cmd.setExecutor(new SanzPackCommand(this));

        getLogger().info("SanzResourcePack aktif — " + packManager.getPacks().size() + " resource pack terdaftar.");
    }

    public ResourcePackManager getPackManager() {
        return packManager;
    }

    public StatusTracker getStatusTracker() {
        return statusTracker;
    }

    public Messages getMessages() {
        return messages;
    }
}
