package xyz.sanz.rp.command;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import xyz.sanz.rp.SanzResourcePack;
import xyz.sanz.rp.model.ResourcePackEntry;
import xyz.sanz.rp.util.Messages;
import xyz.sanz.rp.util.PackUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

public class SanzPackCommand implements CommandExecutor, TabCompleter {

    private final SanzResourcePack plugin;

    public SanzPackCommand(SanzResourcePack plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> handleList(sender);
            case "add" -> handleAdd(sender, args);
            case "remove", "delete" -> handleRemove(sender, args);
            case "required" -> handleRequired(sender, args);
            case "enabled" -> handleEnabled(sender, args);
            case "prompt" -> handlePrompt(sender, args);
            case "send" -> handleSend(sender, args);
            case "reload" -> handleReload(sender);
            case "status" -> handleStatus(sender, args);
            default -> sendHelp(sender);
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(Messages.color(plugin.getMessages().prefix() + "&eDaftar subcommand:"));
        sender.sendMessage(Messages.color("&7/sanzpack list &8- &7lihat semua resource pack terdaftar"));
        sender.sendMessage(Messages.color("&7/sanzpack add <key> <url> [sha1] &8- &7tambah pack baru"));
        sender.sendMessage(Messages.color("&7/sanzpack remove <key> &8- &7hapus pack (dicabut dari semua pemain)"));
        sender.sendMessage(Messages.color("&7/sanzpack required <key> <true|false> &8- &7atur wajib/opsional"));
        sender.sendMessage(Messages.color("&7/sanzpack enabled <key> <true|false> &8- &7nyalakan/matikan pack"));
        sender.sendMessage(Messages.color("&7/sanzpack prompt <key> <pesan...> &8- &7atur pesan popup"));
        sender.sendMessage(Messages.color("&7/sanzpack send <key> <pemain|all> &8- &7kirim ulang manual"));
        sender.sendMessage(Messages.color("&7/sanzpack status <pemain> &8- &7cek status pack pemain"));
        sender.sendMessage(Messages.color("&7/sanzpack reload &8- &7muat ulang config.yml"));
        sender.sendMessage(Messages.color("&7Alias: /rp, /resourcepack"));
    }

    private void handleList(CommandSender sender) {
        var packs = plugin.getPackManager().getPacks();
        if (packs.isEmpty()) {
            sender.sendMessage(Messages.color(plugin.getMessages().prefix() + "&7Belum ada resource pack terdaftar."));
            return;
        }
        sender.sendMessage(Messages.color(plugin.getMessages().prefix() + "&e" + packs.size() + " resource pack terdaftar:"));
        for (ResourcePackEntry e : packs.values()) {
            String status = (e.isEnabled() ? "&aaktif" : "&8nonaktif") + "&7, " + (e.isRequired() ? "&cwajib" : "&7opsional");
            sender.sendMessage(Messages.color("&f" + e.getKey() + " &8(" + status + "&8) &7- " + e.getUrl()));
        }
    }

    private void handleAdd(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(Messages.color("&cPakai: /sanzpack add <key> <url> [sha1]"));
            return;
        }
        String key = args[1].toLowerCase(Locale.ROOT);
        if (plugin.getPackManager().exists(key)) {
            sender.sendMessage(plugin.getMessages().get("pack-exists").replace("%key%", key));
            return;
        }
        String url = args[2];
        String sha1 = args.length > 3 ? args[3] : "";
        if (!sha1.isBlank() && !PackUtil.isValidSha1(sha1)) {
            sender.sendMessage(Messages.color("&cSHA-1 tidak valid (harus 40 karakter hex). Pack tetap ditambahkan tanpa hash."));
            sha1 = "";
        }
        ResourcePackEntry created = plugin.getPackManager().add(key, url, sha1, false, "");
        resendToOnline(created); // biar pemain yang udah online gak perlu rejoin dulu
        sender.sendMessage(plugin.getMessages().get("pack-added").replace("%key%", key));
    }

    private void handleRemove(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(Messages.color("&cPakai: /sanzpack remove <key>"));
            return;
        }
        String key = args[1].toLowerCase(Locale.ROOT);
        if (!plugin.getPackManager().exists(key)) {
            sender.sendMessage(plugin.getMessages().get("pack-not-found").replace("%key%", key));
            return;
        }
        plugin.getPackManager().remove(key);
        sender.sendMessage(plugin.getMessages().get("pack-removed").replace("%key%", key));
    }

    private void handleRequired(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(Messages.color("&cPakai: /sanzpack required <key> <true|false>"));
            return;
        }
        ResourcePackEntry e = plugin.getPackManager().get(args[1].toLowerCase(Locale.ROOT));
        if (e == null) {
            sender.sendMessage(plugin.getMessages().get("pack-not-found").replace("%key%", args[1]));
            return;
        }
        boolean value = Boolean.parseBoolean(args[2]);
        e.setRequired(value);
        plugin.getPackManager().save();
        if (e.isEnabled()) resendToOnline(e); // update force-flag ke pemain yang udah online juga
        sender.sendMessage(plugin.getMessages().get("required-updated")
                .replace("%key%", e.getKey()).replace("%value%", String.valueOf(value)));
    }

    private void handleEnabled(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(Messages.color("&cPakai: /sanzpack enabled <key> <true|false>"));
            return;
        }
        ResourcePackEntry e = plugin.getPackManager().get(args[1].toLowerCase(Locale.ROOT));
        if (e == null) {
            sender.sendMessage(plugin.getMessages().get("pack-not-found").replace("%key%", args[1]));
            return;
        }
        boolean value = Boolean.parseBoolean(args[2]);
        e.setEnabled(value);
        plugin.getPackManager().save();
        if (value) {
            resendToOnline(e); // langsung kirim ke pemain online, gak perlu nunggu rejoin
        } else {
            // langsung cabut dari semua pemain online yang lagi punya pack ini aktif
            for (Player online : Bukkit.getOnlinePlayers()) {
                plugin.getPackManager().removeFromPlayer(online, e);
            }
        }
        sender.sendMessage(plugin.getMessages().get("enabled-updated")
                .replace("%key%", e.getKey()).replace("%value%", String.valueOf(value)));
    }

    private void handlePrompt(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(Messages.color("&cPakai: /sanzpack prompt <key> <pesan...>"));
            return;
        }
        ResourcePackEntry e = plugin.getPackManager().get(args[1].toLowerCase(Locale.ROOT));
        if (e == null) {
            sender.sendMessage(plugin.getMessages().get("pack-not-found").replace("%key%", args[1]));
            return;
        }
        String prompt = String.join(" ", List.of(args).subList(2, args.length));
        e.setPrompt(prompt);
        plugin.getPackManager().save();
        if (e.isEnabled()) resendToOnline(e);
        sender.sendMessage(plugin.getMessages().get("prompt-updated").replace("%key%", e.getKey()));
    }

    private void resendToOnline(ResourcePackEntry e) {
        for (Player online : Bukkit.getOnlinePlayers()) {
            plugin.getPackManager().applyOne(online, e);
        }
    }

    private void handleSend(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(Messages.color("&cPakai: /sanzpack send <key> <pemain|all>"));
            return;
        }
        ResourcePackEntry e = plugin.getPackManager().get(args[1].toLowerCase(Locale.ROOT));
        if (e == null) {
            sender.sendMessage(plugin.getMessages().get("pack-not-found").replace("%key%", args[1]));
            return;
        }
        if (args[2].equalsIgnoreCase("all")) {
            int count = 0;
            for (Player online : Bukkit.getOnlinePlayers()) {
                plugin.getPackManager().applyOne(online, e);
                count++;
            }
            sender.sendMessage(plugin.getMessages().get("sent-to-all")
                    .replace("%key%", e.getKey()).replace("%count%", String.valueOf(count)));
        } else {
            Player target = Bukkit.getPlayerExact(args[2]);
            if (target == null) {
                sender.sendMessage(plugin.getMessages().get("player-not-found").replace("%player%", args[2]));
                return;
            }
            plugin.getPackManager().applyOne(target, e);
            sender.sendMessage(plugin.getMessages().get("sent-to-player")
                    .replace("%key%", e.getKey()).replace("%player%", target.getName()));
        }
    }

    private void handleReload(CommandSender sender) {
        plugin.reloadConfig();
        plugin.getPackManager().load();
        sender.sendMessage(plugin.getMessages().get("reloaded"));
    }

    private void handleStatus(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(Messages.color("&cPakai: /sanzpack status <pemain>"));
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(plugin.getMessages().get("player-not-found").replace("%player%", args[1]));
            return;
        }
        Map<UUID, PlayerResourcePackStatusEvent.Status> statuses = plugin.getStatusTracker().getStatuses(target.getUniqueId());
        sender.sendMessage(plugin.getMessages().get("status-header").replace("%player%", target.getName()));
        if (statuses.isEmpty()) {
            sender.sendMessage(plugin.getMessages().get("status-none"));
            return;
        }
        for (ResourcePackEntry e : plugin.getPackManager().getPacks().values()) {
            PlayerResourcePackStatusEvent.Status status = statuses.get(e.getUuid());
            String statusText = status == null ? "&7(belum ada respon)" : "&f" + status.name();
            sender.sendMessage(plugin.getMessages().get("status-line")
                    .replace("%key%", e.getKey()).replace("%status%", Messages.color(statusText)));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filterStart(List.of("list", "add", "remove", "required", "enabled", "prompt", "send", "reload", "status"), args[0]);
        }
        if (args.length == 2 && List.of("remove", "required", "enabled", "prompt", "send").contains(args[0].toLowerCase(Locale.ROOT))) {
            return filterStart(new ArrayList<>(plugin.getPackManager().getPacks().keySet()), args[1]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("status")) {
            return filterStart(Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList()), args[1]);
        }
        if (args.length == 3 && List.of("required", "enabled").contains(args[0].toLowerCase(Locale.ROOT))) {
            return filterStart(List.of("true", "false"), args[2]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("send")) {
            List<String> options = new ArrayList<>(List.of("all"));
            Bukkit.getOnlinePlayers().forEach(p -> options.add(p.getName()));
            return filterStart(options, args[2]);
        }
        return List.of();
    }

    private List<String> filterStart(List<String> options, String partial) {
        String p = partial.toLowerCase(Locale.ROOT);
        return options.stream().filter(s -> s.toLowerCase(Locale.ROOT).startsWith(p)).collect(Collectors.toList());
    }
}
