package xyz.sanz.rp.listener;

import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import xyz.sanz.rp.SanzResourcePack;

public class JoinListener implements Listener {

    private final SanzResourcePack plugin;

    public JoinListener(SanzResourcePack plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        var player = e.getPlayer();
        long delay = plugin.getConfig().getLong("settings.send-delay-ticks", 40);

        // Dikasih jeda supaya client selesai loading dunia dulu sebelum diminta download pack.
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                plugin.getPackManager().applyAll(player);
            }
        }, delay);
    }
}
