# SanzResourcePack

Plugin buat kelola resource pack server (Paper/Purpur 1.20.x) — kayak `server.properties`
tapi lebih fleksibel: bisa nampung **banyak pack sekaligus**, wajib/opsional **diatur
per-pack** lewat command in-game, dan bisa diubah tanpa restart server.

## Kenapa bukan `server.properties` aja?

`server.properties` cuma bisa 1 resource pack, wajib restart server buat ganti,
dan gak ada cara program-atic buat toggle wajib/opsional atau kirim ulang ke pemain
tertentu. Plugin ini isi celah itu — misalnya kalau ke depannya Sanz SMP punya:
- `sanz_market` (resource pack shop, opsional — kosmetik doang)
- `audes_pack` (custom block/furniture Audes, wajib — biar semua pemain lihat blok yang sama)

Dua-duanya bisa jalan bareng, masing-masing diatur required-nya sendiri.

## Requirement

- Paper/Purpur 1.20.x
- Resource pack harus di-hosting di URL yang bisa diakses publik (https, ASCII-only),
  misalnya GitHub Releases atau CDN.

## Command

Semua command butuh permission `sanzrp.admin` (default: op). Alias: `/rp`, `/resourcepack`.

| Command | Fungsi |
|---|---|
| `/sanzpack list` | Lihat semua pack terdaftar + statusnya |
| `/sanzpack add <key> <url> [sha1]` | Tambah pack baru (langsung dikirim ke pemain online juga) |
| `/sanzpack remove <key>` | Hapus pack (dicabut dari semua pemain online) |
| `/sanzpack required <key> <true\|false>` | Atur wajib/opsional |
| `/sanzpack enabled <key> <true\|false>` | Nyalakan/matikan pack tanpa hapus data |
| `/sanzpack prompt <key> <pesan...>` | Atur pesan popup konfirmasi resource pack |
| `/sanzpack send <key> <pemain\|all>` | Kirim ulang manual ke pemain tertentu/semua |
| `/sanzpack status <pemain>` | Cek status tiap pack buat satu pemain (accepted/declined/dll) |
| `/sanzpack reload` | Muat ulang `config.yml` dari disk |

Semua perubahan (add/remove/required/enabled/prompt) otomatis disimpan ke `config.yml`
**dan** langsung diterapkan ke pemain yang lagi online — gak perlu nunggu mereka rejoin.

## Cara pakai (contoh nyata: pasang resource pack shop)

1. Upload `sanz-market-rp.zip` ke GitHub Releases (atau hosting lain), catat URL langsung
   ke file zip-nya.
2. Hitung SHA-1 (opsional tapi disarankan, biar client bisa cache):
   ```bash
   sha1sum sanz-market-rp.zip
   ```
3. In-game (sebagai admin):
   ```
   /sanzpack add sanz_market https://url-ke/sanz-market-rp.zip <hasil-sha1sum>
   /sanzpack prompt sanz_market &6Resource pack kecil untuk tampilan Sanz Market yang lebih baik!
   ```
4. Selesai. Pack `sanz_market` otomatis dikirim ke semua pemain yang join (dengan delay
   default 40 tick / 2 detik biar dunia selesai loading dulu), dan langsung dikirim juga
   ke pemain yang lagi online saat itu.
5. Kalau suatu saat mau dijadiin wajib: `/sanzpack required sanz_market true`.

## Perilaku "wajib" (`required: true`)

- Client gak bisa nolak popup resource pack tanpa konsekuensi (`force=true` di protokol).
- Kalau `settings.kick-on-required-decline: true` (default) dan pemain tetap
  menolak/gagal download, pemain otomatis di-kick dengan pesan dari `settings.kick-message`.
- Kalau mau resource pack wajib tapi TANPA kick (cuma dipaksa popup-nya doang), set
  `kick-on-required-decline: false` di `config.yml`.

## Catatan teknis

- Tiap pack punya UUID sendiri (di-generate otomatis, disimpan di `config.yml`) — ini
  yang bikin plugin bisa kirim/cabut pack tertentu secara spesifik tanpa ganggu pack lain,
  memanfaatkan dukungan multi-resource-pack Minecraft 1.20.3+.
- Hash SHA-1 wajib persis 40 karakter hex kalau diisi; kalau salah format, plugin otomatis
  fallback ke "tanpa hash" (client selalu download ulang, gak bisa cache).

## Catatan build di sandbox ini

Kode ditulis manual karena sandbox pembuatan file ini gak ada akses internet buat fetch
Paper API dari Maven, jadi belum bisa dicompile-test beneran di sini. Yang sudah dicek:
- Semua kurung `{}` `()` di tiap file seimbang.
- Signature API (`Player#setResourcePack(UUID, String, byte[], Component, boolean)`,
  `removeResourcePack(UUID)`, `PlayerResourcePackStatusEvent#getID()`) sudah diverifikasi
  lewat dokumentasi resmi Paper, bukan sekadar diasumsikan dari memori.

Tetap wajib di-build & ditest di server beneran (lewat GitHub Actions yang udah disediakan)
sebelum dipasang ke Sanz SMP production.
