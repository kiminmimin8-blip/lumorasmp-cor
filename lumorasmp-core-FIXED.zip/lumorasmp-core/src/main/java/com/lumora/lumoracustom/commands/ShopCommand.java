package com.lumora.lumoracustom.commands;

import com.lumora.lumoracustom.gui.ShopListener;
import com.lumora.lumoracustom.util.ConfigFile;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ShopCommand implements CommandExecutor {

    private final ConfigFile configFile;

    public ShopCommand(ConfigFile configFile) {
        this.configFile = configFile;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
            return true;
        }
        ShopListener.openShop(configFile, player);
        return true;
    }
}
