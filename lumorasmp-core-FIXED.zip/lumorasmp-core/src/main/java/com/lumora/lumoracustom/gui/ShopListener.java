package com.lumora.lumoracustom.gui;

import com.lumora.lumoracustom.util.ConfigFile;
import com.lumora.lumoracustom.util.PlaceholderUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Shop: klik kiri = beli 1 stack, klik kanan = jual 1 stack (harus
 * punya itemnya di inventory).
 */
public class ShopListener implements Listener {

    private final ConfigFile configFile;

    public ShopListener(ConfigFile configFile) {
        this.configFile = configFile;
    }

    public static void openShop(ConfigFile configFile, Player player) {
        var cfg = configFile.get();
        String title = ChatColor.translateAlternateColorCodes('&',
                cfg.getString("gui-title", "&2&lServer Shop"));
        int rows = cfg.getInt("gui-rows", 3);

        ShopHolder holder = new ShopHolder();
        Inventory inv = Bukkit.createInventory(holder, rows * 9, title);
        holder.setInventory(inv);

        ConfigurationSection items = cfg.getConfigurationSection("items");
        if (items == null) {
            player.sendMessage(ChatColor.RED + "Shop belum dikonfigurasi. Hubungi admin.");
            return;
        }

        for (String key : items.getKeys(false)) {
            ConfigurationSection item = items.getConfigurationSection(key);
            if (item == null) continue;

            int slot = item.getInt("slot", 0);
            Material material = Material.matchMaterial(item.getString("material", "STONE"));
            if (material == null) material = Material.STONE;

            String name = ChatColor.translateAlternateColorCodes('&', item.getString("name", key));
            double buyPrice = item.getDouble("buy-price", 0);
            double sellPrice = item.getDouble("sell-price", 0);

            List<String> lore = new ArrayList<>();
            for (String line : item.getStringList("lore")) {
                line = line.replace("%buy-price%", String.valueOf(buyPrice))
                        .replace("%sell-price%", String.valueOf(sellPrice));
                lore.add(ChatColor.translateAlternateColorCodes('&', line));
            }

            ItemStack stack = new ItemStack(material);
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(name);
                meta.setLore(lore);
                stack.setItemMeta(meta);
            }
            inv.setItem(slot, stack);
        }

        player.openInventory(inv);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof ShopHolder)) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;

        var cfg = configFile.get();
        ConfigurationSection items = cfg.getConfigurationSection("items");
        if (items == null) return;

        int clickedSlot = event.getRawSlot();
        for (String key : items.getKeys(false)) {
            ConfigurationSection item = items.getConfigurationSection(key);
            if (item == null || item.getInt("slot", -1) != clickedSlot) continue;

            Material material = Material.matchMaterial(item.getString("material", "STONE"));
            if (material == null) return;

            if (event.getClick() == ClickType.LEFT) {
                buyItem(player, item, material);
            } else if (event.getClick() == ClickType.RIGHT) {
                sellItem(player, item, material);
            }
            return;
        }
    }

    private void buyItem(Player player, ConfigurationSection item, Material material) {
        double price = item.getDouble("buy-price", 0);
        String placeholder = configFile.get().getString("balance-placeholder", "%vault_eco_balance%");
        String deductTemplate = configFile.get().getString("deduct-command", "");

        double balance = PlaceholderUtil.getBalance(player, placeholder);
        if (balance < 0) {
            player.sendMessage(ChatColor.RED + "Gagal membaca saldo kamu.");
            return;
        }
        if (balance < price) {
            player.sendMessage(ChatColor.RED + "Saldo kamu gak cukup buat beli 1 stack.");
            return;
        }

        if (!deductTemplate.isBlank()) {
            String cmd = deductTemplate.replace("%player%", player.getName())
                    .replace("%amount%", String.valueOf((long) price));
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        }

        player.getInventory().addItem(new ItemStack(material, material.getMaxStackSize()));
        player.sendMessage(ChatColor.GREEN + "Berhasil beli 1 stack " + material.name() + "!");
    }

    private void sellItem(Player player, ConfigurationSection item, Material material) {
        double price = item.getDouble("sell-price", 0);
        int stackSize = material.getMaxStackSize();

        int count = 0;
        for (ItemStack stack : player.getInventory().getContents()) {
            if (stack != null && stack.getType() == material) {
                count += stack.getAmount();
            }
        }
        if (count < stackSize) {
            player.sendMessage(ChatColor.RED + "Kamu butuh minimal 1 stack " + material.name() + " buat dijual.");
            return;
        }

        player.getInventory().removeItem(new ItemStack(material, stackSize));

        String addTemplate = configFile.get().getString("add-command", "");
        if (!addTemplate.isBlank()) {
            String cmd = addTemplate.replace("%player%", player.getName())
                    .replace("%amount%", String.valueOf((long) price));
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        }

        player.sendMessage(ChatColor.GREEN + "Berhasil jual 1 stack " + material.name() + "!");
    }
}
