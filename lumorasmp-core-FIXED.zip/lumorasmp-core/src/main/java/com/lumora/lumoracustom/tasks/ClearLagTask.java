package com.lumora.lumoracustom.tasks;

import com.lumora.lumoracustom.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Bersihin item/entity numpuk (dropped item, arrow, exp orb) secara
 * berkala. Ada broadcast warning sebelum eksekusi.
 *
 * FIX FOLIA:
 * 1. Timer-nya dipindah dari Bukkit.getScheduler() (scheduler lama,
 *    gak thread-aware) ke Bukkit.getGlobalRegionScheduler() — di
 *    Folia ini jalan di global region thread, di Paper/Purpur biasa
 *    tetap otomatis jalan normal di main thread.
 * 2. entity.remove() gak boleh dipanggil langsung dari thread lain
 *    selain thread yang emang "punya" entity itu. Makanya tiap entity
 *    yang mau dihapus dijadwalin lewat entity.getScheduler().run(...)
 *    biar removal-nya dieksekusi di region thread yang benar.
 */
public class ClearLagTask {

    private final JavaPlugin plugin;
    private final ConfigFile configFile;

    public ClearLagTask(JavaPlugin plugin, ConfigFile configFile) {
        this.plugin = plugin;
        this.configFile = configFile;
    }

    public void start() {
        var cfg = configFile.get();
        if (!cfg.getBoolean("enabled", true)) return;

        long intervalTicks = cfg.getLong("interval-minutes", 5) * 60L * 20L;
        long warningTicks = cfg.getLong("warning-seconds-before", 30) * 20L;

        Bukkit.getGlobalRegionScheduler().runAtFixedRate(plugin, task -> {
            String warningMsg = ChatColor.translateAlternateColorCodes('&',
                    cfg.getString("warning-message", "&eClearlag dalam 30 detik!"));
            Bukkit.broadcastMessage(warningMsg);

            Bukkit.getGlobalRegionScheduler().runDelayed(plugin, delayedTask -> executeClear(), warningTicks);
        }, intervalTicks, intervalTicks);
    }

    public void executeClear() {
        var cfg = configFile.get();
        boolean clearItems = cfg.getBoolean("clear-dropped-items", true);
        boolean clearArrows = cfg.getBoolean("clear-arrows", true);
        boolean clearExp = cfg.getBoolean("clear-experience-orbs", true);

        int[] count = {0};
        for (var world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                EntityType type = entity.getType();
                boolean shouldRemove =
                        (clearItems && type == EntityType.DROPPED_ITEM) ||
                        (clearArrows && type == EntityType.ARROW) ||
                        (clearExp && type == EntityType.EXPERIENCE_ORB);

                if (shouldRemove) {
                    entity.getScheduler().run(plugin, removeTask -> entity.remove(), null);
                    count[0]++;
                }
            }
        }

        String clearedMsg = ChatColor.translateAlternateColorCodes('&',
                cfg.getString("cleared-message", "&aBersihin %count% entity.")
                        .replace("%count%", String.valueOf(count[0])));
        Bukkit.broadcastMessage(clearedMsg);
    }
}
