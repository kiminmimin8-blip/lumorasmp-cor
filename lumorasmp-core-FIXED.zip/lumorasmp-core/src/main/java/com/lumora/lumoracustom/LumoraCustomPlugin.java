package com.lumora.lumoracustom;

import com.lumora.lumoracustom.commands.ClearLagCommand;
import com.lumora.lumoracustom.commands.HomeCommand;
import com.lumora.lumoracustom.commands.MaintenanceCommand;
import com.lumora.lumoracustom.commands.MobRadiusCommand;
import com.lumora.lumoracustom.commands.RankShopCommand;
import com.lumora.lumoracustom.commands.RtpCommand;
import com.lumora.lumoracustom.commands.SpawnCommand;
import com.lumora.lumoracustom.commands.WorldCommand;
import com.lumora.lumoracustom.gui.RankShopListener;
import com.lumora.lumoracustom.listeners.JoinLeaveListener;
import com.lumora.lumoracustom.listeners.MaintenanceListener;
import com.lumora.lumoracustom.listeners.MobSpawnListener;
import com.lumora.lumoracustom.listeners.MotdListener;
import com.lumora.lumoracustom.managers.HomeManager;
import com.lumora.lumoracustom.managers.SpawnManager;
import com.lumora.lumoracustom.tasks.ClearLagTask;
import com.lumora.lumoracustom.util.ConfigFile;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * LumoraSMP-Core - plugin inti gabungan buat Lumora SMP.
 *
 * Struktur folder MODULAR (kayak EssentialsX) - tiap fitur punya folder
 * & config.yml sendiri di plugins/LumoraSMPCore/<fitur>/config.yml:
 *   spawn/, home/, rtp/, mobspawn/, rankshop/, joinmessages/, motd/,
 *   maintenance/, clearlag/, worlds/
 *
 * Modul yang udah jadi:
 *  1. Mob Spawn Radius Blocker
 *  2. RankShop (currency configurable)
 *  3. Spawn (/spawn, /setspawn)
 *  4. Home (/home, /sethome, /delhome, /homes)
 *  5. RTP (/rtp)
 *  6. Join/Leave message custom
 *  7. MOTD server list
 *  8. Maintenance mode (/maintenance)
 *  9. Clearlag otomatis + manual (/clearlag)
 *  10. Worlds — Multiverse-lite (/world, /worldadmin)
 *
 * Sengaja TIDAK termasuk: ItemsAdder/ModelEngine/dst (terlalu kompleks,
 * beda kelas produk), plugin premium/cracked, dan plugin yang udah
 * jalan bagus terpisah (Donut suite, GrimAC, dll).
 */
public final class LumoraCustomPlugin extends JavaPlugin {

    private static LumoraCustomPlugin instance;

    private SpawnManager spawnManager;
    private HomeManager homeManager;

    @Override
    public void onEnable() {
        instance = this;

        // ===== Init tiap modul, masing-masing bawa config.yml sendiri =====
        this.spawnManager = new SpawnManager(this);
        this.homeManager = new HomeManager(this);

        ConfigFile mobSpawnConfig = new ConfigFile(this, "mobspawn/config.yml");
        ConfigFile rankShopConfig = new ConfigFile(this, "rankshop/config.yml");
        ConfigFile joinMessagesConfig = new ConfigFile(this, "joinmessages/config.yml");
        ConfigFile motdConfig = new ConfigFile(this, "motd/config.yml");
        ConfigFile maintenanceConfig = new ConfigFile(this, "maintenance/config.yml");
        ConfigFile clearLagConfig = new ConfigFile(this, "clearlag/config.yml");
        ConfigFile worldsConfig = new ConfigFile(this, "worlds/config.yml");

        // ===== Daftarin listener =====
        getServer().getPluginManager().registerEvents(new MobSpawnListener(mobSpawnConfig), this);
        getServer().getPluginManager().registerEvents(new RankShopListener(rankShopConfig), this);
        getServer().getPluginManager().registerEvents(new JoinLeaveListener(joinMessagesConfig), this);
        getServer().getPluginManager().registerEvents(new MotdListener(motdConfig), this);
        getServer().getPluginManager().registerEvents(new MaintenanceListener(maintenanceConfig), this);

        // ===== Daftarin command =====
        if (getCommand("mobradius") != null) {
            getCommand("mobradius").setExecutor(new MobRadiusCommand(mobSpawnConfig));
        }
        if (getCommand("rankshop") != null) {
            getCommand("rankshop").setExecutor(new RankShopCommand(rankShopConfig));
        }

        SpawnCommand spawnCommand = new SpawnCommand(this);
        if (getCommand("spawn") != null) getCommand("spawn").setExecutor(spawnCommand);
        if (getCommand("setspawn") != null) getCommand("setspawn").setExecutor(spawnCommand);

        HomeCommand homeCommand = new HomeCommand(this);
        if (getCommand("home") != null) getCommand("home").setExecutor(homeCommand);
        if (getCommand("sethome") != null) getCommand("sethome").setExecutor(homeCommand);
        if (getCommand("delhome") != null) getCommand("delhome").setExecutor(homeCommand);
        if (getCommand("homes") != null) getCommand("homes").setExecutor(homeCommand);

        if (getCommand("rtp") != null) {
            getCommand("rtp").setExecutor(new RtpCommand(this));
        }
        if (getCommand("maintenance") != null) {
            getCommand("maintenance").setExecutor(new MaintenanceCommand(maintenanceConfig));
        }

        // ===== Clearlag: task berkala + command manual =====
        ClearLagTask clearLagTask = new ClearLagTask(this, clearLagConfig);
        clearLagTask.start();
        if (getCommand("clearlag") != null) {
            getCommand("clearlag").setExecutor(new ClearLagCommand(clearLagTask));
        }

        WorldCommand worldCommand = new WorldCommand(worldsConfig, this);
        if (getCommand("world") != null) getCommand("world").setExecutor(worldCommand);
        if (getCommand("worldadmin") != null) getCommand("worldadmin").setExecutor(worldCommand);

        boolean papiFound = getServer().getPluginManager().getPlugin("PlaceholderAPI") != null;
        if (!papiFound) {
            getLogger().warning("PlaceholderAPI tidak ditemukan! Fitur RankShop butuh PlaceholderAPI " +
                    "buat baca saldo player. Silakan install PlaceholderAPI.");
        }

        getLogger().info("LumoraSMP-Core aktif! Modul: spawn, home, rtp, mobspawn, rankshop, " +
                "joinmessages, motd, maintenance, clearlag, worlds.");
    }

    @Override
    public void onDisable() {
        getLogger().info("LumoraSMP-Core dimatikan.");
    }

    public static LumoraCustomPlugin getInstance() {
        return instance;
    }

    public SpawnManager getSpawnManager() {
        return spawnManager;
    }

    public HomeManager getHomeManager() {
        return homeManager;
    }
}
