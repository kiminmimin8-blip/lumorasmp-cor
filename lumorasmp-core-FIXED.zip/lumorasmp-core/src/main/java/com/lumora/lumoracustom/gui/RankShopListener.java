package com.lumora.lumoracustom.gui;

import com.lumora.lumoracustom.util.ConfigFile;
import com.lumora.lumoracustom.util.PlaceholderUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class RankShopListener implements Listener {

    private final ConfigFile configFile;

    public RankShopListener(ConfigFile configFile) {
        this.configFile = configFile;
    }

    /**
     * Buka & isi GUI RankShop buat player, berdasarkan rankshop.yml.
     */
    public static void openShop(ConfigFile configFile, Player player) {
        var cfg = configFile.get();
        String title = ChatColor.translateAlternateColorCodes('&',
                cfg.getString("gui-title", "&5&lRank Shop"));
        int rows = cfg.getInt("gui-rows", 3);

        RankShopHolder holder = new RankShopHolder();
        Inventory inv = Bukkit.createInventory(holder, rows * 9, title);
        holder.setInventory(inv);

        ConfigurationSection items = cfg.getConfigurationSection("items");
        if (items == null) {
            player.sendMessage(ChatColor.RED + "RankShop belum dikonfigurasi. Hubungi admin.");
            return;
        }

        for (String key : items.getKeys(false)) {
            ConfigurationSection item = items.getConfigurationSection(key);
            if (item == null) continue;

            int slot = item.getInt("slot", 0);
            Material material = Material.matchMaterial(item.getString("material", "STONE"));
            if (material == null) material = Material.STONE;

            String name = ChatColor.translateAlternateColorCodes('&', item.getString("name", key));
            List<String> loreRaw = item.getStringList("lore");
            List<String> lore = new ArrayList<>();
            for (String line : loreRaw) {
                lore.add(ChatColor.translateAlternateColorCodes('&', line));
            }

            ItemStack stack = new ItemStack(material);
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(name);
                meta.setLore(lore);
                stack.setItemMeta(meta);
            }

            inv.setItem(slot, stack);
        }

        player.openInventory(inv);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof RankShopHolder)) {
            return;
        }
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        int clickedSlot = event.getRawSlot();
        ConfigurationSection items = configFile.get().getConfigurationSection("items");
        if (items == null) return;

        Set<String> keys = items.getKeys(false);
        for (String key : keys) {
            ConfigurationSection item = items.getConfigurationSection(key);
            if (item == null) continue;

            if (item.getInt("slot", -1) == clickedSlot) {
                handlePurchase(player, item, key);
                return;
            }
        }
    }

    private void handlePurchase(Player player, ConfigurationSection item, String itemKey) {
        double price = item.getDouble("price", 0);
        String placeholder = configFile.get().getString("balance-placeholder", "%vault_eco_balance%");
        String deductTemplate = configFile.get().getString("deduct-command", "");

        double balance = PlaceholderUtil.getBalance(player, placeholder);

        if (balance < 0) {
            player.sendMessage(ChatColor.RED + "Gagal membaca saldo kamu. Hubungi admin " +
                    "(cek apakah PlaceholderAPI & currency plugin sudah terpasang).");
            return;
        }

        if (balance < price) {
            player.sendMessage(ChatColor.RED + "Saldo kamu tidak cukup! Butuh " +
                    ChatColor.YELLOW + (long) price + ChatColor.RED + ", saldo kamu " +
                    ChatColor.YELLOW + (long) balance + ChatColor.RED + ".");
            return;
        }

        // Potong saldo lewat command console (sesuai currency plugin di config)
        if (!deductTemplate.isBlank()) {
            String deductCmd = deductTemplate
                    .replace("%player%", player.getName())
                    .replace("%amount%", String.valueOf((long) price));
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), deductCmd);
        }

        // Jalankan command reward (misal grant rank via LuckPerms)
        List<String> commands = item.getStringList("commands");
        for (String cmd : commands) {
            String finalCmd = cmd.replace("%player%", player.getName());
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), finalCmd);
        }

        player.sendMessage(ChatColor.GREEN + "Berhasil membeli " + ChatColor.YELLOW + itemKey +
                ChatColor.GREEN + "!");
        player.closeInventory();
    }
}
