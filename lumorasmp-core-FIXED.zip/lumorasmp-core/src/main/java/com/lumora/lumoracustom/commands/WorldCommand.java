package com.lumora.lumoracustom.commands;

import com.lumora.lumoracustom.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Modul Worlds - versi ringan dari Multiverse-core.
 * Fitur: list world, teleport antar world, buat world baru, unload world.
 * TIDAK ada: portal, game rule per-world, custom world generator.
 *
 * CATATAN FOLIA: create/unload world WAJIB dijalanin di Global Region
 * Thread (bukan thread command biasa), makanya dibungkus
 * Bukkit.getGlobalRegionScheduler(). Di server non-Folia (Paper/Purpur
 * biasa), API ini tetap aman dipakai — otomatis jalan di main thread.
 */
public class WorldCommand implements CommandExecutor {

    private final ConfigFile configFile;
    private final JavaPlugin plugin;

    public WorldCommand(ConfigFile configFile, JavaPlugin plugin) {
        this.configFile = configFile;
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("worldadmin")) {
            return handleAdmin(sender, args);
        }
        return handleWorld(sender, args);
    }

    // /world [list|tp <nama>]
    private boolean handleWorld(CommandSender sender, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            List<String> names = Bukkit.getWorlds().stream().map(World::getName).collect(Collectors.toList());
            sender.sendMessage(ChatColor.GRAY + "World yang ke-load: " + ChatColor.WHITE + String.join(", ", names));
            return true;
        }

        if (args[0].equalsIgnoreCase("tp")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Command ini cuma bisa dipakai in-game.");
                return true;
            }
            if (args.length < 2) {
                player.sendMessage(ChatColor.RED + "Gunakan: /world tp <nama>");
                return true;
            }

            String worldName = args[1];
            String requiredPerm = configFile.get().getString("world-permissions." + worldName, null);
            if (requiredPerm != null && !player.hasPermission(requiredPerm)) {
                player.sendMessage(ChatColor.RED + "Kamu tidak punya izin ke world ini.");
                return true;
            }

            World world = Bukkit.getWorld(worldName);
            if (world == null) {
                player.sendMessage(ChatColor.RED + "World " + worldName + " gak ditemukan atau belum ke-load.");
                return true;
            }

            player.teleportAsync(world.getSpawnLocation());
            player.sendMessage(ChatColor.GREEN + "Teleport ke world " + ChatColor.YELLOW + worldName + "...");
            return true;
        }

        sender.sendMessage(ChatColor.RED + "Gunakan: /world <list|tp> [nama]");
        return true;
    }

    // /worldadmin <create|unload> <nama> [environment]
    private boolean handleAdmin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("lumora.world.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk command ini.");
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Gunakan: /worldadmin <create|unload> <nama> [NORMAL|NETHER|THE_END]");
            return true;
        }

        String action = args[0].toLowerCase();
        String worldName = args[1];

        if (action.equals("create")) {
            if (Bukkit.getWorld(worldName) != null) {
                sender.sendMessage(ChatColor.RED + "World " + worldName + " udah ada/ke-load.");
                return true;
            }
            World.Environment env = World.Environment.NORMAL;
            if (args.length >= 3) {
                try {
                    env = World.Environment.valueOf(args[2].toUpperCase());
                } catch (IllegalArgumentException e) {
                    sender.sendMessage(ChatColor.RED + "Environment tidak valid. Pakai NORMAL/NETHER/THE_END.");
                    return true;
                }
            }
            World.Environment finalEnv = env;
            sender.sendMessage(ChatColor.YELLOW + "Membuat world " + worldName + "... ini bisa makan waktu.");
            Bukkit.getGlobalRegionScheduler().execute(plugin, () -> {
                new WorldCreator(worldName).environment(finalEnv).createWorld();
                sender.sendMessage(ChatColor.GREEN + "World " + worldName + " berhasil dibuat!");
            });
            return true;
        }

        if (action.equals("unload")) {
            World world = Bukkit.getWorld(worldName);
            if (world == null) {
                sender.sendMessage(ChatColor.RED + "World " + worldName + " gak ke-load.");
                return true;
            }
            Bukkit.getGlobalRegionScheduler().execute(plugin, () -> {
                boolean success = Bukkit.unloadWorld(world, true);
                sender.sendMessage(success
                        ? ChatColor.GREEN + "World " + worldName + " berhasil di-unload."
                        : ChatColor.RED + "Gagal unload (mungkin masih ada player di dalamnya).");
            });
            return true;
        }

        sender.sendMessage(ChatColor.RED + "Gunakan: /worldadmin <create|unload> <nama> [environment]");
        return true;
    }
}
