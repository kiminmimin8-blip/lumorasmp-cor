package com.lumora.lumoracustom.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/**
 * Marker holder biar kita bisa pastiin klik yang masuk itu
 * emang dari GUI RankShop, bukan dari chest/inventory lain
 * yang kebetulan judulnya mirip.
 */
public class RankShopHolder implements InventoryHolder {

    private Inventory inventory;

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
