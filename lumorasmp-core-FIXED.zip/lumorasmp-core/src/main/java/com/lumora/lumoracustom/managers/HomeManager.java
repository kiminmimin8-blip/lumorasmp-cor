package com.lumora.lumoracustom.managers;

import com.lumora.lumoracustom.LumoraCustomPlugin;
import com.lumora.lumoracustom.util.ConfigFile;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Kelola home per player. Data disimpan di file terpisah (homes.yml)
 * biar gak numpuk di config.yml utama.
 *
 * Format:
 * homes:
 *   <uuid>:
 *     <namahome>:
 *       world: ...
 *       x/y/z/yaw/pitch: ...
 */
public class HomeManager {

    private final LumoraCustomPlugin plugin;
    private final File file;
    private final YamlConfiguration data;
    private final ConfigFile settings;

    public HomeManager(LumoraCustomPlugin plugin) {
        this.plugin = plugin;
        this.settings = new ConfigFile(plugin, "home/config.yml");
        this.file = new File(plugin.getDataFolder(), "home/homes.yml");
        if (!file.exists()) {
            try {
                plugin.getDataFolder().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("Gagal bikin homes.yml: " + e.getMessage());
            }
        }
        this.data = YamlConfiguration.loadConfiguration(file);
    }

    public void save() {
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal simpan homes.yml: " + e.getMessage());
        }
    }

    public List<String> getHomeNames(UUID uuid) {
        String path = "homes." + uuid;
        if (data.getConfigurationSection(path) == null) {
            return new ArrayList<>();
        }
        return new ArrayList<>(data.getConfigurationSection(path).getKeys(false));
    }

    public int getMaxHomes(Player player) {
        int max = settings.get().getInt("default-max-homes", 2);
        // cek permission lumora.homes.<angka>, ambil yang paling besar
        for (int i = 1; i <= 50; i++) {
            if (player.hasPermission("lumora.homes." + i) && i > max) {
                max = i;
            }
        }
        if (player.hasPermission("lumora.homes.unlimited")) {
            return Integer.MAX_VALUE;
        }
        return max;
    }

    public boolean hasHome(UUID uuid, String name) {
        return data.contains("homes." + uuid + "." + name.toLowerCase());
    }

    public Location getHome(UUID uuid, String name) {
        String path = "homes." + uuid + "." + name.toLowerCase();
        if (!data.contains(path)) return null;

        String worldName = data.getString(path + ".world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;

        double x = data.getDouble(path + ".x");
        double y = data.getDouble(path + ".y");
        double z = data.getDouble(path + ".z");
        float yaw = (float) data.getDouble(path + ".yaw");
        float pitch = (float) data.getDouble(path + ".pitch");
        return new Location(world, x, y, z, yaw, pitch);
    }

    public void setHome(UUID uuid, String name, Location location) {
        String path = "homes." + uuid + "." + name.toLowerCase();
        data.set(path + ".world", location.getWorld().getName());
        data.set(path + ".x", location.getX());
        data.set(path + ".y", location.getY());
        data.set(path + ".z", location.getZ());
        data.set(path + ".yaw", (double) location.getYaw());
        data.set(path + ".pitch", (double) location.getPitch());
        save();
    }

    public boolean deleteHome(UUID uuid, String name) {
        String path = "homes." + uuid + "." + name.toLowerCase();
        if (!data.contains(path)) return false;
        data.set(path, null);
        save();
        return true;
    }
}
