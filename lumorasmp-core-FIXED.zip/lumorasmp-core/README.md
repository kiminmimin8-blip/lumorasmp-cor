# LumoraSMP-Core

Plugin inti gabungan buat Lumora SMP (Folia 1.21.11).

## Struktur folder — MODULAR (gaya EssentialsX)
Tiap fitur punya FOLDER + `config.yml` sendiri di dalam
`plugins/LumoraSMPCore/`:

```
plugins/LumoraSMPCore/
├── spawn/
│   └── config.yml
├── home/
│   ├── config.yml       <- setting (max home dll)
│   └── homes.yml        <- data home tiap player
├── rtp/
│   └── config.yml
├── mobspawn/
│   └── config.yml
├── rankshop/
│   └── config.yml
├── joinmessages/
│   └── config.yml
├── motd/
│   └── config.yml
├── maintenance/
│   └── config.yml
├── clearlag/
│   └── config.yml
└── worlds/
    └── config.yml
```

## Modul yang udah jadi (10)
1. **Mob Spawn Radius Blocker** — blokir monster spawn dalam radius tertentu dari player.
2. **RankShop** — GUI beli rank pakai currency configurable (Money/Points/Shards via PlaceholderAPI).
3. **Spawn** — `/spawn`, `/setspawn`.
4. **Home** — `/home`, `/sethome`, `/delhome`, `/homes`.
5. **RTP** — `/rtp` teleport ke lokasi random yang aman, dengan cooldown.
6. **Join/Leave Message** — custom pesan join/leave/first-join.
7. **MOTD** — custom pesan server list ping.
8. **Maintenance Mode** — `/maintenance <on|off|status>`.
9. **Clearlag** — otomatis + `/clearlag` manual.
10. **Worlds (Multiverse-lite)** — `/world list`, `/world tp <nama>`,
    `/worldadmin create/unload <nama>`. Fitur lanjutan Multiverse asli
    (portal, game rule per-world, world generator custom) TIDAK
    termasuk — kalau butuh itu, tetap pakai Multiverse-core aslinya.

## ⚠️ Plugin lama yang jadi DOUBLE — matiin/uninstall salah satu
| Modul LumoraSMP-Core | Plugin lama |
|---|---|
| Mob Spawn Radius | PerfToggleMobSpawning |
| RTP | CoderRTP |
| Spawn | DonutSpawn |
| Home | DonutHomes |
| Clearlag | Clearlag.jar, ClearLagTimer.jar |
| Worlds | Multiverse-core (kalau cuma butuh list/tp doang) |

## Sengaja TIDAK digabung (dari plugins.zip yang dicek)
- **Premium/cracked**: MMOItems-Bypassed, MythicMobs-Bypassed, ItemsAdder,
  BankPlus, PyroFishingPro, GCore, MagicCosmetics, ModelEngine, CustomDrops.
- **Library, bukan fitur**: CMILib, PyroLib, LoneLibs, MythicLib, nightcore,
  SkQuery — dependency plugin lain, gak ada yang bisa "digabung".
- **Sistem besar / di luar scope**: Jobs, Shopkeepers (dipake referensi
  buat modul Shop yang nyusul), AureliumSkills, BetterTeams (udah ada
  DonutTeams), GSit (udah kepasang & jalan), LevelledMobs.
- **Sudah ada & jalan bagus**: semua Donut suite lain, GrimAC (anticheat).
- **Gak mungkin jadi plugin sama sekali**: Anti-DDoS (level jaringan).

## Cara compile
Butuh **Java 17+** dan **Maven**.
```bash
mvn clean package
```
Hasil `.jar` di `target/lumorasmp-core-1.0.0.jar`.

## Yang WAJIB dicek/disesuaikan dev sebelum production
1. Versi `paper-api` di `pom.xml` disesuaikan Folia 1.21.11.
2. `deduct-command`/`add-command` di `rankshop/config.yml` disesuaikan currency asli.
3. Nama rank di command LuckPerms harus sama persis `/lp listgroups`.
4. `ClearLagTask` — iterasi & remove entity lintas world masih pola
   sederhana, WAJIB direview buat Folia (idealnya per-region scheduler).
5. `WorldCommand` create world itu operasi berat/blocking — sebaiknya
   dev pindahin ke async-safe method biar gak nge-freeze server pas dipanggil.
6. Testing semua modul di server sebelum dipakai player asli.

## Progress dari list awal (9 fitur EcoCPvP + tambahan)
Sudah: RankShop, Mob Spawn Radius, RTP, Spawn, Home, Join/Leave, MOTD,
Maintenance, Clearlag, Worlds (10 modul).
Belum (nyusul bertahap): Shop, Leaderboard, Event, ArenaRegen/Reset, Duel, Billford.
(Config default buat Shop/Leaderboard/Event udah disiapin di folder
masing-masing, tinggal nyusul bagian Java-nya.)
