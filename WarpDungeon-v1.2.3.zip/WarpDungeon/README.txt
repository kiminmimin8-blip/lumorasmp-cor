WarpDungeon (dulu SanzDungeon) - plugin standalone (BUKAN bagian dari SanzCore, jar sendiri)
============================================================

CARA PAKAI:
1. Push folder ini ke repo GitHub baru (terpisah dari SanzCore), workflow di
   .github/workflows/build.yml otomatis compile tiap push ke branch main.
2. Ambil jar hasil build dari tab Actions -> artifact "SanzDungeon".
3. Taro SanzDungeon.jar + Vault.jar di folder plugins/ server.
4. Restart server. File data (dungeons.yml, shop.yml) otomatis dibuat di
   plugins/SanzDungeon/.

COMMAND:
  /dungeon              -> GUI teleport (semua player, free & premium)
  /dungeon shop         -> shop dungeon tempat kamu berdiri (semua player)
  /dungeon wand         -> [admin] ambil axe buat select region
  /dungeon save <id>    -> [admin] simpen region jadi world border dungeon itu
  /dungeon setspawn <id>-> [admin] set titik teleport masuk dungeon
  /dungeon create <id>  -> [admin] bikin dungeon baru
  /dungeon delete <id>  -> [admin] hapus dungeon
  /dungeon list         -> [admin] daftar semua dungeon + status
  /dungeon edit         -> [admin] GUI setting dungeon (nama, harga, premium, dll)
  /dungeon shopedit [id]-> [admin] GUI kategori+trade shop 1 dungeon (tanpa id
                            = dungeon tempat kamu berdiri)
  /dungeon shopreload   -> [admin] reload shop.yml dari disk tanpa restart

PERMISSION:
  dungeon.admin  -> akses semua command admin di atas (default: op)
  dungeon.bypass -> bypass proteksi region (default: op)
  dungeon.free   -> teleport gratis walau dungeon premium (default: op)

CATATAN PENTING:
- Ini JAR TERPISAH dari SanzCore. Kalau ternyata lebih enak digabung jadi satu
  modul di dalam SanzCore lagi, source-nya sama persis, tinggal pindahin
  folder src/main/java/com/sanz/dungeon ke dalam project SanzCore dan panggil
  bagian onEnable() di SanzDungeonPlugin.java dari onEnable() SanzCore.
- Currency "cash" & "shards" masih stub di DungeonCurrencyProvider.java,
  nunggu sistem multi-currency SanzCore beneran jadi baru disambungin.
- Shop editor pake slot inventory beneran (bukan command) - keterbatasan:
  drag-multi-slot ke slot input/output belum ditangani khusus, disaranin
  taro item satu-satu / pake klik biasa aja biar aman.
- Belum ada integrasi otomatis ke drop table MythicMobs - trade shop diisi
  manual lewat /dungeon shopedit.

UPDATE (fix border + shop) - 2026-08-20:
- Target server disamain ke Paper 1.21.11 (pom.xml).
- FIX: world border dungeon sebelumnya emang gak pernah beneran dipasang -
  region cuma dipakai buat proteksi block break/place/pvp/dll, gak pernah
  di-apply jadi WorldBorder asli. Sekarang tiap player masuk dungeon otomatis
  dikasih per-player WorldBorder (Bukkit.createWorldBorder()) sesuai ukuran
  region, dan direset balik pas keluar/quit/relog. Border ini murni visual
  (warning distance & damage 0), gak nahan/nge-damage - proteksi keluar-masuk
  dungeon tetep dari checkRegion() kayak sebelumnya.
- SHOP DIROMBAK TOTAL: trade sekarang nyimpen ItemStack UTUH (bukan cuma
  Material+jumlah), jadi enchant/nama custom/lore/custom-model-data ikut
  kesimpen persis. Slot input sekarang ADA 2 (item1 + item2), sama kayak GUI
  trade Shopkeeper villager admin yang lagi jalan sekarang.
- shop.yml default (dibuat sekali doang pas belum ada file-nya) diisi 8 trade
  yang samain persis (nama, lore, custom model data, tag mythicmobs:type di
  PDC) sama shopkeeper admin: Fragmen Relik Tanah / Inti Bara Nyala / Debu
  Abyssal Crawler -> Arrow/Door/Hay Bale/Golden Carrot/Wind Charge/Diamond/
  Kelenjar Racun Purba, plus 4 trade tambahan armor DIAMOND full-enchant
  (protection 4, unbreaking 3, mending; helm +respiration 3 +aqua affinity;
  boots +feather falling 4 +depth strider 3; leggings +swift sneak 3).
- Karena item drop MythicMobs punya NBT sendiri-sendiri, buat exact-match
  100% ke drop asli tinggal ambil barangnya di game (misal /mm item give)
  terus taro ke slot lewat /dungeon shopedit, klik SIMPAN - gak perlu edit
  kode lagi. Begitu juga kalau mau ganti hadiah/harga trade apa aja, semua
  bisa diedit langsung in-game dari GUI itu.

UPDATE 2 (GUI shop disamain PERSIS ke Shopkeeper) - 2026-08-22:
- FIX: /dungeon shop sebelumnya buka custom GUI grid biasa (klik icon =
  langsung kebeli) - makanya tampilannya beda sama GUI Shopkeeper walau
  fungsinya udah mirip. Sekarang dipakein Bukkit Merchant API ASLI
  (Bukkit.createMerchant + MerchantRecipe, dibuka lewat player.openMerchant),
  jadi window yang kebuka itu PERSIS window trading vanilla - sama kayak
  yang dipake Shopkeeper (list trade + panel item1+item2 -> panah -> hasil,
  drag item lalu klik slot hasil). Bukan tiruan/mirip-mirip lagi, beneran
  GUI bawaan game.
- Konsekuensinya: DungeonShopListener (yang dulu manual ngurusin ambil
  item & kasih hasil) UDAH GAK DIPAKE buat trade item - itu semua sekarang
  otomatis ditangani vanilla (server yang motong ingredient & ngasih hasil,
  gak ada logic custom lagi, jadi lebih ringan & gak mungkin ada bug urutan
  ambil-item-vs-kasih-hasil kayak sebelumnya).
- Trade mode MONEY (bukan ITEM) masih butuh sedikit trik, soalnya trading
  vanilla cuma bisa nuker item ke item, gak bisa langsung nambah saldo.
  Buat itu, hasil trade-nya berupa item "voucher" kertas, dan listener baru
  (DungeonShopVoucherListener) otomatis nangkep begitu voucher itu masuk
  inventory pemain, langsung ilangin vouchernya & nambahin saldo asli.
  Voucher gak akan pernah nyangkut lama di inventory pemain.
- ShopEditGUI (/dungeon shopedit, punya admin) TETEP custom GUI kayak
  sebelumnya - gak dipindah ke Merchant API, soalnya Merchant API gak
  ngedukung mode "edit ingredient/hasil sambil liat preview" yang dibutuhin
  admin. Cuma tampilan buat PLAYER yang belanja (/dungeon shop) yang diganti.

UPDATE 3 (shop dirombak jadi per-dungeon + kategori, full CRUD) - 2026-08-25:
- Shop SEBELUMNYA cuma 1 daftar trade GLOBAL buat semua dungeon. Sekarang
  PER-DUNGEON, dan 1 dungeon bisa punya BANYAK KATEGORI (misal "Armor",
  "Senjata", "Tukar Fragmen") - tiap kategori punya daftar trade sendiri.
- Command:
    /dungeon shop            -> shop dungeon TEMPAT KAMU BERDIRI SEKARANG.
                                 Kalau cuma 1 kategori, langsung ke window
                                 trading. Kalau lebih, muncul GUI pilih
                                 kategori dulu.
    /dungeon shopedit [id]   -> tanpa id = edit shop dungeon tempat kamu
                                 berdiri, atau kasih id manual buat edit
                                 dungeon lain dari mana aja.
    /dungeon shopreload      -> reload shop.yml dari disk tanpa restart
                                 server (buat kalau edit manual file-nya).
- ShopEditGUI sekarang 4 tingkat: daftar kategori -> detail kategori
  (rename/hapus/ganti icon/atur slot pilih) -> daftar trade dalam kategori
  itu -> detail 1 trade (persis kayak sebelumnya, + kontrol urutan/slot).
- FITUR BARU shopedit:
  - Kategori: buat baru (+ Kategori baru), RENAME (klik nametag, ketik di
    chat), HAPUS (klik TNT 2x buat konfirmasi, semua trade di dalamnya ikut
    kehapus), ganti ICON (taro item apa aja di slot icon + SIMPAN), atur
    SLOT tampil di GUI pemilihan kategori pemain (custom slot, -1 = auto).
  - Trade: RENAME & HAPUS udah ada dari sebelumnya, sekarang ditambah
    kontrol "urutan/slot" (+1/-1) buat ngatur posisi tampil trade itu di
    dalam window trading kategorinya.
  - /dungeon shopreload buat reload tanpa restart.
- Tiap dungeon yang belum pernah punya shop bakal otomatis di-seed 2
  kategori pas pertama kali /dungeon shop atau /dungeon shopedit dipake di
  situ: "Umum" (7 trade fragmen -> item biasa) dan "Armor" (4 trade armor
  diamond full-enchant). Semua itemnya masih PLACEHOLDER (nama/lore/model
  data mirip item MythicMobs tapi bukan clone byte-perfect) - dikasih lore
  merah "[CONTOH - ganti pake item MythicMobs asli]" biar keliatan mana yg
  masih perlu diganti. Tinggal /mm item give barang aslinya, taro ke slot
  input/output lewat shopedit, klik SIMPAN.

UPDATE 4 (/back dihapus, command & fitur dibatasi di dalam dungeon) - 2026-08-25:
- /back DIHAPUS TOTAL. DungeonBackManager.java & DungeonBackCommand.java
  ikut kehapus, command "back" gak ke-register lagi dari plugin ini. Kalau
  ada plugin lain (Essentials dll) yang punya /back sendiri, itu tetap
  DIBLOKIR selama player masih di dalam dungeon (masuk BLOCKED_COMMANDS).
- Command yang diblokir sekarang selama di dalam dungeon (BLOCKED_COMMANDS
  di DungeonProtectionListener): teleport/tp/tpa/tpaccept/tpahere,
  sethome/setwarp/warp, teamwarp/tw, tpauto, claim, trade, back.
- KHUSUS /team - cuma subcommand "/team sethome" & "/team setwarp" yang
  diblok, subcommand /team lainnya (invite/chat/dll) tetep bisa dipakai
  normal.
- Enderpearl: udah diblok dari sebelumnya (ProjectileLaunchEvent), sekarang
  aturannya diperketat - kalau shooter-nya BUKAN player (misal dispenser),
  tetep diblok juga selama posisinya di dalam dungeon (sebelumnya cuma
  ngeblok lemparan dari player).
- Elytra: udah diblok dari sebelumnya (EntityToggleGlideEvent, gliding
  dibatalin begitu masuk dungeon).
- Firework BARU diblok - baik make firework rocket di tangan (buat boost
  elytra) maupun firework yang di-launch dari sumber lain (dispenser dll)
  selama di dalam dungeon, dua-duanya dicegah.
- Mob spawn BARU dibatasin - CreatureSpawnEvent dicek metadata "MythicMobs"
  (metadata bawaan yang dipasang MythicMobs ke semua mob custom-nya). Kalau
  metadata itu gak ada DAN lokasinya di dalam region dungeon, spawn-nya
  dibatalin. Jadi mob vanilla/natural/spawner/egg biasa gak bisa muncul di
  dalam dungeon, cuma mob dari MythicMobs yang boleh.

UPDATE 5 (bug spawner MythicMobs + config.yml) - 2026-08-27:
- FIX BUG: mob dari MythicMobs gak keluar sama sekali dari spawner. Root
  cause: metadata "MythicMobs" itu dipasang MythicMobs SETELAH
  World.spawn(...) yang ngasilin CreatureSpawnEvent kelar - bukan pas
  event-nya masih berjalan. Kode lama ngecek metadata itu & langsung cancel
  DI DALAM event yang sama, jadi mob MythicMobs asli pun ikut kebatalin
  (belum sempet ke-tag). Fix: onCreatureSpawn sekarang GAK cancel langsung -
  ditunda 1 tick (pake entity.getScheduler().runDelayed, Folia-safe), baru
  dicek ulang metadata-nya; kalau di titik itu masih belum ke-tag, baru
  entity-nya di-remove().
- CONFIG.YML BARU - sebelumnya SEMUA setting (waktu dungeon, world border,
  proteksi mana yang nyala, daftar command yang diblokir, currency shop,
  pesan-pesan) ke-hardcode di kode Java, jadi harus compile ulang tiap mau
  ubah apa-apa. Sekarang semua itu ada di src/main/resources/config.yml,
  diedit dari panel langsung, terus tinggal /dungeon reload (gak perlu
  restart server). Yang bisa diatur dari config.yml:
    dungeon-time              - waktu yg diset pas masuk dungeon
    world-border.*            - warning-distance/time, damage-amount/buffer
    protection.block-break/place, allow-pvp, explosion-damage-block,
      block-enderpearl, block-elytra, block-firework, only-mythicmobs-spawn
    blocked-commands          - list command yg diblok di dalam dungeon
    blocked-team-subcommands  - subcommand /team yg diblok (sethome, setwarp)
    shop-currencies           - pilihan currency buat trade mode MONEY
    messages.*                - semua pesan ke player, pake kode warna &
- Command baru: /dungeon reload -> reload config.yml dari disk. Beda sama
  /dungeon shopreload yang reload shop.yml - dua-duanya independen, bisa
  dipake sendiri-sendiri.
- WarpDungeonConfig.java (kelas baru) yang baca/cache config.yml, dipass ke
  DungeonProtectionListener, DungeonCommand, dan ShopEditListener - jadi
  semua bagian yg tadinya hardcode sekarang narik dari 1 sumber yang sama.

UPDATE 6 (fitur besar v1.1.0: statistik, syarat masuk, HUD, proteksi tambahan) - 2026-09-21:
Semua fitur baru bisa diatur/dimatiin dari config.yml. Config.yml LAMA di server
gak perlu dihapus - key baru otomatis pake nilai default, tinggal /dungeon reload.

COMMAND BARU
  /dungeon stats [player]   -> statistik dungeon (total kill, mati, berapa kali masuk,
                               total waktu di dalam). Semua player.
  /dungeon top [kills|time|deaths|entries] -> leaderboard top 10. Semua player.
  /dungeon info [id]        -> [admin] detail 1 dungeon (region, ukuran, syarat, jumlah pemain)
  /dungeon tp <id>          -> [admin] teleport langsung, lewati syarat/tiket/hitung mundur
  /dungeon players [id]     -> [admin] siapa aja yang lagi di dalam dungeon
  /dungeon kick <player>    -> [admin] keluarin player dari dungeon (ke spawn world)
  /dungeon show [id]        -> [admin] gambar batas region pakai partikel putih 15 detik
                               (tanpa WorldEdit, cocok dari HP)

FITUR BARU
- SYARAT MASUK PER DUNGEON (diatur di /dungeon edit -> klik dungeon, baris bawah):
    Cooldown (jeda antar masuk per player), Maks pemain barengan, Level XP minimal,
    Permission khusus (misal rank.vip). Klik kiri/kanan buat +/-, shift buat lompat
    lebih besar. Admin/OP/dungeon.bypass tidak kena syarat ini.
  Icon di /dungeon nunjukin jumlah pemain di dalam, syarat (merah kalau belum
  kepenuhi), dan sisa cooldown.
- HITUNG MUNDUR TELEPORT (teleport.warmup-seconds, default 3 detik): batal kalau
  player gerak / kena damage. Tiket premium baru kepotong PAS teleport jalan,
  jadi kalau dibatalin gak ada yang kepotong. Set 0 buat matiin.
- TITLE + SUARA pas masuk/keluar, plus HUD ACTIONBAR selama di dalam (nama dungeon,
  waktu, kill, jumlah pemain). Ada ringkasan di chat pas keluar. Format & pesan
  bisa diedit di config.yml (hud.format, messages.*).
- STATISTIK & LEADERBOARD: kill mob, mati, jumlah masuk, total waktu. Disimpan di
  plugins/WarpDungeon/stats.yml, auto-save tiap 5 menit + pas server mati.
- HADIAH KILL (opsional): rewards.kill-commands di config.yml - command console yang
  jalan tiap player bunuh mob di dalam dungeon (%player% %dungeon% %mob%). Default kosong.
- ATURAN MATI: death.keep-inventory / death.keep-level (default mati) khusus mati
  di dalam dungeon. Mati di dalam dungeon juga sekarang langsung dihitung "keluar"
  pas respawn (border/waktu/HUD gak nyangkut lagi).
- PROTEKSI TAMBAHAN (semua bisa dimatiin di config.yml -> protection):
    block-bucket (ember air/lava), block-mob-griefing (enderman ngambil block dll),
    block-fire (api nyala/nyebar), block-decorations (item frame/painting/armor stand).
  Ledakan dari LUAR region juga gak bisa ngerusak block di dalam dungeon lagi, dan
  ledakan bed/respawn anchor ikut dicover.
- Wand sekarang nampilin ukuran seleksi begitu titik 1 & 2 udah diset.

PERBAIKAN
- Build error: "bad operand types for binary operator '+'" di DungeonShopGUI.java
  & ShopEditGUI.java (ChatColor + angka) - udah dibenerin.
- Daftar dungeon sekarang thread-safe (ConcurrentSkipListMap), biar gak ada
  ConcurrentModificationException di Folia pas admin edit sambil player gerak.

CATATAN
- Cooldown masuk disimpan di memori (reset kalau server restart). Statistik permanen.
- Tinggal /dungeon reload buat nerapin perubahan config.yml. Perubahan syarat per
  dungeon (cooldown dll) langsung aktif.
- Belum bisa dites compile-nya penuh dari sini (gak ada akses internet buat
  download Paper API) - kode udah dicek terhadap stub API, tapi kalau build GitHub
  Actions masih ada error, kirim lognya lagi.

UPDATE 7 (fix bug /back nembus dungeon) - v1.1.1:
- BUG: setelah keluar dungeon, player bisa /back (titik sebelum teleport) buat
  balik ke dalam dungeon TANPA bayar tiket / kena cooldown / syarat masuk. Cara
  yang sama juga bisa lewat /tpa ke orang yang lagi di dalam. Sebelumnya /back
  cuma diblok kalau player MASIH di dalam dungeon.
- FIX: sekarang semua teleport dari LUAR ke DALAM region dungeon otomatis
  dibatalin, kecuali yang lewat GUI /dungeon atau /dungeon tp. Teleport antar
  titik di dalam dungeon yang sama (skill boss MythicMobs dll) tetep jalan.
  OP/dungeon.bypass gak kena. Toggle: protection.block-outside-teleport di
  config.yml, pesannya messages.entry-blocked.

UPDATE 8 (v1.2.0: maintenance, kick AFK, milestone, leaderboard periodik, blok drop item):
- MODE MAINTENANCE: /dungeon close <id> [alasan] & /dungeon open <id>. Bisa juga
  lewat tombol pintu/barrier di /dungeon edit. Dungeon yang ditutup gak bisa
  dimasukin lewat /dungeon (icon nampilin "DITUTUP" + alasan), tapi player yang
  udah di dalam gak dikeluarin. OP/dungeon.bypass & /dungeon tp tetep bisa masuk.
- KICK AFK: gak gerak >1 block & gak ngebunuh mob selama afk.timeout-minutes
  (default 10 menit) -> dikeluarin ke spawn world. Ada peringatan afk.warn-seconds
  (default 30 detik) sebelumnya. OP/dungeon.bypass gak kena.
- MILESTONE KILL: hadiah otomatis pas TOTAL kill seumur hidup nyampe 100/500/1000
  (bisa ditambah/diganti di config.yml -> milestones.kills). Isi "commands" buat
  ngasih hadiah (command console, %player% %kills%), default cuma pesan.
- LEADERBOARD PERIODIK: kill "periode ini" dihitung terpisah dari total, direset
  tiap minggu (Senin 00:00) atau bulan (tanggal 1) sesuai leaderboard.reset.
  Juara top-size dapet hadiah dari leaderboard.rewards; yang offline hadiahnya
  disimpen & dikirim pas login berikutnya. Zona waktu: leaderboard.timezone
  (default Asia/Jakarta). Command:
    /dungeon top period   -> top kill periode berjalan
    /dungeon top last     -> juara periode sebelumnya
    /dungeon lbreset confirm -> [admin] paksa tutup periode sekarang (buat tes)
  Ganti mode weekly<->monthly gak bikin hadiah kebagi, cuma mulai periode baru.
- GAK BISA DROP ITEM di dalam dungeon (protection.block-item-drop). Drop pas
  mati tetep diatur death.keep-inventory. OP/dungeon.bypass gak kena.

UPDATE 9 (v1.2.1: fix status masuk-keluar kedip di tepi region + warna nama dungeon):
- BUG: berdiri/jalan/terbang pas di tepi region bikin status "masuk dungeon" dan
  "keluar dungeon" kedip-kedip puluhan kali (title "Keluar dungeon 00:00" nyepam,
  sesi/HUD/statistik masuk ke-reset tiap kedip). Penyebab: batas region dicek
  tanpa toleransi, dan di PlayerMoveEvent posisi yang dipakai masih posisi LAMA
  (telat 1 langkah).
- FIX: zona toleransi region.leave-margin (default 3 block, ke segala arah). Player
  baru dianggap keluar kalau udah lewat tepi region lebih dari itu. Deteksi juga
  sekarang pake posisi tujuan (e.getTo()). Kalau masih kedip, naikin angkanya.
- BUG: warna nama dungeon (&6, &a, dst) gak jalan di menu /dungeon dan menu edit -
  kodenya muncul mentah. FIX: nama & deskripsi dungeon sekarang di-translate di
  semua tempat (GUI, HUD, title, pesan). Ada dukungan hex juga: &#FF8800.
  Contoh nama: &6&lCrypt &7Lv.1     Contoh deskripsi: &aGampang | &cBoss di ujung
  Input chat nama/deskripsi sekarang ditangkap di prioritas paling awal (LOWEST),
  biar plugin chat lain gak sempet ngehapus kode & nya. Nama lama yang udah
  kesimpen tanpa warna harus diketik ulang.
- Catatan: template title di config.yml (messages.enter-title) awalnya "&6&l%dungeon%";
  kalau nama dungeon punya kode warna sendiri, warna itu yang menang.

UPDATE 10 (v1.2.2: region otomatis tinggi penuh):
- Sebelumnya region cuma kena di rentang Y dari 2 titik wand. Kalau lantai dungeon
  atau tempat player berdiri ada di luar rentang Y itu, player dianggap "keluar"
  padahal masih di dalam (ini juga penyebab status masuk-keluar kedip di video).
- Sekarang region.full-height: true (default) -> sekali set titik 1 & 2, region kena
  dari DASAR sampai ATAS world, Y titik wand gak dipakai. Berlaku juga buat region
  lama yang udah kesimpen, gak perlu di-set ulang. Set false kalau butuh dungeon
  yang numpuk atas-bawah. /dungeon info nampilin mode-nya, /dungeon show ngegambar
  tiang dari dasar sampai atas + kotak setinggi player.

UPDATE 11 (v1.2.3: mob spawn dinyalain lagi):
- BUG: mob MythicMobs gak mau spawn di dalam dungeon. Penyebab: filter
  "cuma mob MythicMobs yang boleh spawn" ngecek tag mob-nya, tapi tag itu gak
  kebaca dengan bener, jadi mob MythicMobs yang asli ikut kehapus.
- FIX: filternya sekarang MATI by default -> semua mob boleh spawn di dalam
  dungeon, termasuk mob random/vanilla. Key config-nya diganti jadi
  protection.remove-non-mythic-mobs (default false). Key lama
  only-mythicmobs-spawn di config.yml server udah gak dipakai sama sekali, jadi
  gak perlu diedit manual - langsung ngaruh pas jar diganti (atau /dungeon reload).
- Kalau mau ngatur lagi mob apa yang boleh spawn, pake fitur spawn bawaan
  MythicMobs / plugin lain, atau nyalain remove-non-mythic-mobs sendiri.
