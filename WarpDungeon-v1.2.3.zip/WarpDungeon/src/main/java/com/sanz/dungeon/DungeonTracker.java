package com.sanz.dungeon;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Nyatet siapa lagi di dalam dungeon mana, sejak kapan, dan udah berapa kill
 * di "sesi" itu. Dipakai buat: title masuk/keluar, HUD actionbar, kick AFK,
 * batas jumlah pemain, statistik, dan ringkasan pas keluar.
 * Dipanggil dari DungeonProtectionListener tiap player masuk/keluar region.
 */
public class DungeonTracker {

    public static class Session {
        public final String dungeonId;
        public final String playerName;
        public final long enterMillis = System.currentTimeMillis();
        public final AtomicInteger kills = new AtomicInteger();
        volatile ScheduledTask tick;

        // state deteksi AFK - cuma disentuh dari thread scheduler player-nya
        double anchorX, anchorY, anchorZ;
        boolean anchorSet = false;
        int lastKills = 0;
        long lastActive = System.currentTimeMillis();
        boolean afkWarned = false;

        Session(String dungeonId, String playerName) {
            this.dungeonId = dungeonId;
            this.playerName = playerName;
        }
    }

    private final Plugin plugin;
    private final DungeonManager manager;
    private final WarpDungeonConfig config;
    private final DungeonStats stats;
    private final Map<UUID, Session> sessions = new ConcurrentHashMap<>();

    public DungeonTracker(Plugin plugin, DungeonManager manager, WarpDungeonConfig config, DungeonStats stats) {
        this.plugin = plugin;
        this.manager = manager;
        this.config = config;
        this.stats = stats;
    }

    /** Titik keluar buat kick AFK & /dungeon kick: spawn world utama. */
    public static Location exitLocation() {
        return Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    // ---------- dipanggil pas masuk / keluar region ----------

    public void onEnter(Player p, Dungeon d) {
        Session s = new Session(d.getId(), p.getName());
        Session old = sessions.put(p.getUniqueId(), s);
        if (old != null) stopTick(old);

        stats.addEntry(p.getUniqueId(), p.getName());

        if (config.isTitlesEnabled()) {
            p.sendTitle(
                    config.msg("enter-title", "%dungeon%", d.getDisplayName()),
                    config.msg("enter-subtitle", "%dungeon%", d.getDisplayName()),
                    10, 50, 15);
        }
        playSound(p, config.getSoundEnter());
        startTick(p, s);
    }

    public void onLeave(Player p, String dungeonId) {
        finish(p, true);
    }

    /** Player logout pas masih di dalam dungeon - catat waktunya, tapi gak usah kirim pesan. */
    public void onQuit(Player p) {
        finish(p, false);
    }

    private void finish(Player p, boolean notify) {
        Session s = sessions.remove(p.getUniqueId());
        if (s == null) return;
        stopTick(s);

        long secs = Math.max(0L, (System.currentTimeMillis() - s.enterMillis) / 1000L);
        stats.addSeconds(p.getUniqueId(), p.getName(), secs);

        if (!notify) return;

        Dungeon d = manager.get(s.dungeonId);
        String name = d != null ? d.getDisplayName() : s.dungeonId;
        String time = formatDuration(secs);
        String kills = String.valueOf(s.kills.get());

        if (config.isTitlesEnabled()) {
            p.sendTitle(
                    config.msg("leave-title", "%dungeon%", name, "%time%", time, "%kills%", kills),
                    config.msg("leave-subtitle", "%dungeon%", name, "%time%", time, "%kills%", kills),
                    10, 40, 10);
        }
        p.sendMessage(config.msg("leave-summary", "%dungeon%", name, "%time%", time, "%kills%", kills));
        playSound(p, config.getSoundLeave());
    }

    /** Dipanggil pas plugin dimatikan - simpen waktu semua yang masih di dalam. */
    public void shutdown() {
        for (Map.Entry<UUID, Session> me : sessions.entrySet()) {
            Session s = me.getValue();
            long secs = Math.max(0L, (System.currentTimeMillis() - s.enterMillis) / 1000L);
            stats.addSeconds(me.getKey(), s.playerName, secs);
        }
        sessions.clear();
    }

    // ---------- kill & death ----------

    /** @return total kill seumur hidup player ini setelah ditambah (buat milestone). */
    public long addKill(Player killer) {
        Session s = sessions.get(killer.getUniqueId());
        if (s != null) s.kills.incrementAndGet();
        return stats.addKill(killer.getUniqueId(), killer.getName());
    }

    public void addDeath(Player p) {
        stats.addDeath(p.getUniqueId(), p.getName());
    }

    // ---------- query ----------

    public Session getSession(UUID id) {
        return sessions.get(id);
    }

    public int countInside(String dungeonId) {
        int n = 0;
        for (Session s : sessions.values()) {
            if (s.dungeonId.equals(dungeonId)) n++;
        }
        return n;
    }

    public List<String> namesInside(String dungeonId) {
        List<String> names = new ArrayList<>();
        for (Session s : sessions.values()) {
            if (s.dungeonId.equals(dungeonId)) names.add(s.playerName);
        }
        return names;
    }

    // ---------- task per-player: HUD + cek AFK (jalan tiap 1 detik) ----------

    private void startTick(Player p, Session s) {
        UUID id = p.getUniqueId();
        s.tick = p.getScheduler().runAtFixedRate(plugin, task -> {
            if (sessions.get(id) != s || !p.isOnline()) {
                task.cancel();
                return;
            }
            Dungeon d = manager.get(s.dungeonId);
            if (d == null) {
                task.cancel();
                return;
            }
            if (config.isHudEnabled()) sendHud(p, s, d);
            if (config.isAfkEnabled()) checkAfk(p, s);
        }, null, 20L, 20L);
    }

    private void stopTick(Session s) {
        ScheduledTask t = s.tick;
        if (t != null) t.cancel();
    }

    private void sendHud(Player p, Session s, Dungeon d) {
        long secs = (System.currentTimeMillis() - s.enterMillis) / 1000L;
        String line = config.getHudFormat()
                .replace("%dungeon%", d.getDisplayName())
                .replace("%time%", formatDuration(secs))
                .replace("%kills%", String.valueOf(s.kills.get()))
                .replace("%players%", String.valueOf(countInside(s.dungeonId)));
        p.sendActionBar(Colors.component(line));
    }

    /**
     * AFK = gak gerak lebih dari ~1 block dari titik terakhir "aktif" DAN gak
     * nambah kill. Lewat batas waktu -> peringatan dulu, lalu dikeluarin.
     */
    private void checkAfk(Player p, Session s) {
        if (p.isDead() || p.isOp() || p.hasPermission("dungeon.bypass")) {
            markActive(p, s);
            return;
        }

        Location loc = p.getLocation();
        boolean active = !s.anchorSet || s.kills.get() != s.lastKills;
        if (!active) {
            double dx = loc.getX() - s.anchorX;
            double dy = loc.getY() - s.anchorY;
            double dz = loc.getZ() - s.anchorZ;
            active = dx * dx + dy * dy + dz * dz > 1.0;
        }
        if (active) {
            markActive(p, s);
            return;
        }

        long idleMs = System.currentTimeMillis() - s.lastActive;
        long timeoutMs = config.getAfkTimeoutSeconds() * 1000L;

        if (idleMs >= timeoutMs) {
            markActive(p, s); // reset biar gak ke-trigger dobel selama teleport jalan
            p.sendMessage(config.msg("afk-kick"));
            p.teleportAsync(exitLocation());
            return;
        }

        long warnMs = config.getAfkWarnSeconds() * 1000L;
        if (!s.afkWarned && warnMs > 0 && idleMs >= timeoutMs - warnMs) {
            s.afkWarned = true;
            long left = (timeoutMs - idleMs + 999L) / 1000L;
            p.sendMessage(config.msg("afk-warning", "%seconds%", String.valueOf(left)));
        }
    }

    private void markActive(Player p, Session s) {
        Location loc = p.getLocation();
        s.anchorX = loc.getX();
        s.anchorY = loc.getY();
        s.anchorZ = loc.getZ();
        s.anchorSet = true;
        s.lastKills = s.kills.get();
        s.lastActive = System.currentTimeMillis();
        s.afkWarned = false;
    }

    // ---------- util ----------

    private void playSound(Player p, String key) {
        if (key == null || key.isBlank()) return;
        p.playSound(p.getLocation(), key, 1.0f, 1.0f);
    }

    /** 75 -> "01:15", 3725 -> "1:02:05" */
    public static String formatDuration(long totalSeconds) {
        long s = Math.max(0L, totalSeconds);
        long h = s / 3600L;
        long m = (s % 3600L) / 60L;
        long sec = s % 60L;
        if (h > 0) return String.format("%d:%02d:%02d", h, m, sec);
        return String.format("%02d:%02d", m, sec);
    }
}
