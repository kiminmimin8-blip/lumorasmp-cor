package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class DungeonEditListener implements Listener {

    private static final List<String> CURRENCIES = List.of("money", "cash", "shards");

    private final DungeonManager manager;
    private final DungeonEditGUI editGUI;
    private final DungeonEditSession session;

    // buat konfirmasi delete 2x klik
    private final Map<UUID, String> pendingDelete = new ConcurrentHashMap<>();

    public DungeonEditListener(DungeonManager manager, DungeonEditGUI editGUI, DungeonEditSession session) {
        this.manager = manager;
        this.editGUI = editGUI;
        this.session = session;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof DungeonEditHolder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;

        String action = holder.getAction(e.getRawSlot());
        if (action == null) return;

        if (holder.getMode() == DungeonEditHolder.Mode.LIST) {
            if (action.equals("create")) {
                p.closeInventory();
                session.await(p.getUniqueId(), null, DungeonEditSession.Field.CREATE_ID);
                p.sendMessage(ChatColor.YELLOW + "Ketik ID dungeon baru di chat (contoh: crypt1):");
                return;
            }
            if (action.startsWith("open:")) {
                String id = action.substring("open:".length());
                Dungeon d = manager.get(id);
                if (d != null) p.openInventory(editGUI.buildDetail(d));
                return;
            }
            return;
        }

        // mode DETAIL
        String dungeonId = holder.getDungeonId();
        Dungeon d = manager.get(dungeonId);
        if (d == null) { p.closeInventory(); return; }

        switch (action) {
            case "toggle_premium" -> {
                d.setPremium(!d.isPremium());
                manager.save();
                p.openInventory(editGUI.buildDetail(d));
            }
            case "cycle_currency" -> {
                int idx = CURRENCIES.indexOf(d.getCurrency().toLowerCase());
                String next = CURRENCIES.get((idx + 1) % CURRENCIES.size());
                d.setCurrency(next);
                manager.save();
                p.openInventory(editGUI.buildDetail(d));
            }
            case "price" -> {
                p.closeInventory();
                session.await(p.getUniqueId(), dungeonId, DungeonEditSession.Field.PRICE);
                p.sendMessage(ChatColor.YELLOW + "Ketik harga baru (angka) di chat:");
            }
            case "name" -> {
                p.closeInventory();
                session.await(p.getUniqueId(), dungeonId, DungeonEditSession.Field.NAME);
                p.sendMessage(ChatColor.YELLOW + "Ketik nama display baru di chat. Bisa pakai warna: kode & (contoh &6&lCrypt &7Lv.1) atau hex (contoh &#FF8800Crypt).");
            }
            case "description" -> {
                p.closeInventory();
                session.await(p.getUniqueId(), dungeonId, DungeonEditSession.Field.DESCRIPTION);
                p.sendMessage(ChatColor.YELLOW + "Ketik deskripsi di chat, pisahin tiap baris pakai ' | ' (contoh: baris1 | baris2):");
            }
            case "slot" -> {
                p.closeInventory();
                session.await(p.getUniqueId(), dungeonId, DungeonEditSession.Field.SLOT);
                p.sendMessage(ChatColor.YELLOW + "Ketik nomor slot GUI (0-53), atau ketik 'auto':");
            }
            case "cooldown" -> {
                int step = e.isShiftClick() ? 300 : 30;
                d.setCooldownSeconds(d.getCooldownSeconds() + (e.isRightClick() ? -step : step));
                manager.save();
                p.openInventory(editGUI.buildDetail(d));
            }
            case "max_players" -> {
                int step = e.isShiftClick() ? 10 : 1;
                d.setMaxPlayers(d.getMaxPlayers() + (e.isRightClick() ? -step : step));
                manager.save();
                p.openInventory(editGUI.buildDetail(d));
            }
            case "min_level" -> {
                int step = e.isShiftClick() ? 10 : 1;
                d.setMinLevel(d.getMinLevel() + (e.isRightClick() ? -step : step));
                manager.save();
                p.openInventory(editGUI.buildDetail(d));
            }
            case "permission" -> {
                p.closeInventory();
                session.await(p.getUniqueId(), dungeonId, DungeonEditSession.Field.PERMISSION);
                p.sendMessage(ChatColor.YELLOW + "Ketik node permission di chat (contoh: rank.vip), atau 'none' buat hapus:");
            }
            case "toggle_closed" -> {
                d.setClosed(!d.isClosed());
                manager.save();
                p.openInventory(editGUI.buildDetail(d));
            }
            case "display_item" -> {
                ItemStack cursor = e.getCursor();
                if (cursor == null || cursor.getType() == Material.AIR) {
                    p.sendMessage(ChatColor.RED + "Pegang item di cursor dulu buat jadiin icon.");
                    return;
                }
                d.setDisplayItem(cursor.getType());
                manager.save();
                p.openInventory(editGUI.buildDetail(d));
            }
            case "delete" -> {
                if (dungeonId.equals(pendingDelete.get(p.getUniqueId()))) {
                    manager.deleteDungeon(dungeonId);
                    pendingDelete.remove(p.getUniqueId());
                    p.sendMessage(ChatColor.RED + "Dungeon '" + dungeonId + "' dihapus.");
                    p.openInventory(editGUI.buildList());
                } else {
                    pendingDelete.put(p.getUniqueId(), dungeonId);
                    p.sendMessage(ChatColor.RED + "Klik lagi buat konfirmasi hapus '" + dungeonId + "'.");
                }
            }
            case "back" -> p.openInventory(editGUI.buildList());
        }
    }

    // LOWEST: kita harus dapet pesan MENTAH duluan sebelum plugin chat lain sempat
    // ngubah/ngehapus kode warna (&) dari input admin.
    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        DungeonEditSession.Pending pending = session.get(p.getUniqueId());
        if (pending == null) return;

        e.setCancelled(true);
        String msg = e.getMessage().trim();
        session.clear(p.getUniqueId());

        // handled di scheduler player-nya biar aman manggil Bukkit API dari chat thread
        p.getScheduler().run(
                org.bukkit.Bukkit.getPluginManager().getPlugin("WarpDungeon"),
                (task) -> applyInput(p, pending, msg),
                null
        );
    }

    private void applyInput(Player p, DungeonEditSession.Pending pending, String msg) {
        if (pending.field == DungeonEditSession.Field.CREATE_ID) {
            if (manager.exists(msg)) {
                p.sendMessage(ChatColor.RED + "Dungeon '" + msg + "' udah ada.");
                return;
            }
            manager.createDungeon(msg);
            p.sendMessage(ChatColor.GREEN + "Dungeon '" + msg + "' dibuat.");
            p.openInventory(editGUI.buildList());
            return;
        }

        Dungeon d = manager.get(pending.dungeonId);
        if (d == null) { p.sendMessage(ChatColor.RED + "Dungeon-nya udah gak ada."); return; }

        switch (pending.field) {
            case NAME -> d.setDisplayName(msg);
            case PRICE -> {
                try {
                    d.setPrice(Double.parseDouble(msg));
                } catch (NumberFormatException ex) {
                    p.sendMessage(ChatColor.RED + "Bukan angka yang valid.");
                    return;
                }
            }
            case PERMISSION -> d.setPermission(msg.equalsIgnoreCase("none") ? "" : msg);
            case DESCRIPTION -> d.setDescription(Arrays.asList(msg.split("\\s*\\|\\s*")));
            case SLOT -> {
                if (msg.equalsIgnoreCase("auto")) {
                    d.setGuiSlot(-1);
                } else {
                    try {
                        d.setGuiSlot(Integer.parseInt(msg));
                    } catch (NumberFormatException ex) {
                        p.sendMessage(ChatColor.RED + "Bukan angka yang valid.");
                        return;
                    }
                }
            }
            default -> { return; }
        }

        manager.save();
        p.sendMessage(ChatColor.GREEN + "Tersimpan.");
        p.openInventory(editGUI.buildDetail(d));
    }
}
