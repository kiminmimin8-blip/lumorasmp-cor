package com.sanz.dungeon;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class DungeonGUIListener implements Listener {

    private final DungeonManager manager;
    private final DungeonTeleporter teleporter;

    public DungeonGUIListener(DungeonManager manager, DungeonTeleporter teleporter) {
        this.manager = manager;
        this.teleporter = teleporter;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof DungeonGUIHolder holder)) return;
        e.setCancelled(true);

        if (!(e.getWhoClicked() instanceof Player p)) return;
        String dungeonId = holder.getDungeonId(e.getRawSlot());
        if (dungeonId == null) return;

        Dungeon d = manager.get(dungeonId);
        if (d == null) return;

        // semua pengecekan (permission, level, cooldown, kapasitas, tiket) +
        // hitung mundur + teleport diurus DungeonTeleporter.
        p.closeInventory();
        teleporter.enter(p, d);
    }
}
