package com.sanz.dungeon;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Statistik dungeon per player (total kill, mati, berapa kali masuk, total
 * waktu di dalam, kill periode berjalan) + data leaderboard periodik (juara
 * periode lalu, hadiah yang nunggu diambil player offline).
 * Disimpan ke stats.yml. Semua akses data dikunci biar aman dipanggil dari
 * banyak region thread Folia + task save async sekaligus.
 */
public class DungeonStats {

    public static final List<String> TYPES = List.of("kills", "time", "deaths", "entries", "period", "last");

    /** Data 1 player. Field public biar gampang dibaca, tapi yang dikasih keluar selalu salinan. */
    public static class Entry {
        public UUID id;
        public String name = "?";
        public long kills;
        public long deaths;
        public long entries;
        public long seconds;
        public long periodKills;

        Entry copy() {
            Entry e = new Entry();
            e.id = id;
            e.name = name;
            e.kills = kills;
            e.deaths = deaths;
            e.entries = entries;
            e.seconds = seconds;
            e.periodKills = periodKills;
            return e;
        }
    }

    /** Juara 1 periode leaderboard. */
    public static class Winner {
        public final UUID id;
        public final String name;
        public final long kills;
        public final int rank;

        public Winner(UUID id, String name, long kills, int rank) {
            this.id = id;
            this.name = name;
            this.kills = kills;
            this.rank = rank;
        }
    }

    private final Plugin plugin;
    private final File file;
    private final Object lock = new Object();
    private final Object fileLock = new Object();
    private final Map<UUID, Entry> data = new HashMap<>();
    private final Map<UUID, List<String>> pending = new HashMap<>();
    private List<Winner> lastWinners = new ArrayList<>();
    private String periodKey = "";
    private String lastPeriodKey = "";
    private volatile boolean dirty = false;

    public DungeonStats(Plugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "stats.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        synchronized (lock) {
            ConfigurationSection root = yml.getConfigurationSection("players");
            if (root != null) {
                for (String key : root.getKeys(false)) {
                    UUID id;
                    try {
                        id = UUID.fromString(key);
                    } catch (IllegalArgumentException ex) {
                        continue;
                    }
                    String base = "players." + key + ".";
                    Entry e = new Entry();
                    e.id = id;
                    e.name = yml.getString(base + "name", "?");
                    e.kills = yml.getLong(base + "kills", 0L);
                    e.deaths = yml.getLong(base + "deaths", 0L);
                    e.entries = yml.getLong(base + "entries", 0L);
                    e.seconds = yml.getLong(base + "seconds", 0L);
                    e.periodKills = yml.getLong(base + "periodKills", 0L);
                    data.put(id, e);
                }
            }

            periodKey = yml.getString("period.key", "");
            lastPeriodKey = yml.getString("period.lastKey", "");

            ConfigurationSection last = yml.getConfigurationSection("period.last");
            if (last != null) {
                for (String k : last.getKeys(false)) {
                    try {
                        UUID id = UUID.fromString(last.getString(k + ".uuid", ""));
                        String name = last.getString(k + ".name", "?");
                        long kills = last.getLong(k + ".kills", 0L);
                        int rank = last.getInt(k + ".rank", 0);
                        lastWinners.add(new Winner(id, name, kills, rank));
                    } catch (IllegalArgumentException ex) {
                        // entri rusak, lewati
                    }
                }
                lastWinners.sort(Comparator.comparingInt((Winner w) -> w.rank));
            }

            ConfigurationSection pend = yml.getConfigurationSection("pending");
            if (pend != null) {
                for (String k : pend.getKeys(false)) {
                    try {
                        UUID id = UUID.fromString(k);
                        List<String> lines = pend.getStringList(k);
                        if (!lines.isEmpty()) pending.put(id, new ArrayList<>(lines));
                    } catch (IllegalArgumentException ex) {
                        // entri rusak, lewati
                    }
                }
            }
        }
    }

    public void save() {
        if (!dirty) return;
        YamlConfiguration yml = new YamlConfiguration();
        synchronized (lock) {
            for (Map.Entry<UUID, Entry> me : data.entrySet()) {
                String base = "players." + me.getKey() + ".";
                Entry e = me.getValue();
                yml.set(base + "name", e.name);
                yml.set(base + "kills", e.kills);
                yml.set(base + "deaths", e.deaths);
                yml.set(base + "entries", e.entries);
                yml.set(base + "seconds", e.seconds);
                yml.set(base + "periodKills", e.periodKills);
            }
            yml.set("period.key", periodKey);
            yml.set("period.lastKey", lastPeriodKey);
            int i = 0;
            for (Winner w : lastWinners) {
                String base = "period.last." + i + ".";
                yml.set(base + "uuid", w.id.toString());
                yml.set(base + "name", w.name);
                yml.set(base + "kills", w.kills);
                yml.set(base + "rank", w.rank);
                i++;
            }
            for (Map.Entry<UUID, List<String>> pe : pending.entrySet()) {
                yml.set("pending." + pe.getKey(), new ArrayList<>(pe.getValue()));
            }
            dirty = false;
        }
        synchronized (fileLock) {
            try {
                if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
                yml.save(file);
            } catch (IOException ex) {
                dirty = true;
                plugin.getLogger().warning("Gagal save stats.yml: " + ex.getMessage());
            }
        }
    }

    // ---------- tulis ----------

    private Entry touch(UUID id, String name) {
        Entry e = data.get(id);
        if (e == null) {
            e = new Entry();
            e.id = id;
            data.put(id, e);
        }
        if (name != null) e.name = name;
        dirty = true;
        return e;
    }

    /** @return total kill seumur hidup SETELAH ditambah (dipakai buat milestone). */
    public long addKill(UUID id, String name) {
        synchronized (lock) {
            Entry e = touch(id, name);
            e.kills++;
            e.periodKills++;
            return e.kills;
        }
    }

    public void addDeath(UUID id, String name) {
        synchronized (lock) { touch(id, name).deaths++; }
    }

    public void addEntry(UUID id, String name) {
        synchronized (lock) { touch(id, name).entries++; }
    }

    public void addSeconds(UUID id, String name, long seconds) {
        if (seconds <= 0) return;
        synchronized (lock) { touch(id, name).seconds += seconds; }
    }

    // ---------- leaderboard periodik ----------

    public String getPeriodKey() {
        synchronized (lock) { return periodKey; }
    }

    public void setPeriodKey(String key) {
        synchronized (lock) {
            periodKey = key;
            dirty = true;
        }
    }

    /**
     * Tutup periode berjalan: ambil top N (kill periode > 0), simpen sebagai
     * "juara periode lalu", nolin kill periode semua player, lalu pindah ke
     * periode baru.
     */
    public List<Winner> rotatePeriod(String newKey, int topN) {
        synchronized (lock) {
            List<Entry> list = new ArrayList<>();
            for (Entry e : data.values()) {
                if (e.periodKills > 0) list.add(e.copy());
            }
            list.sort(Comparator.comparingLong((Entry e) -> e.periodKills).reversed());

            List<Winner> winners = new ArrayList<>();
            for (int i = 0; i < list.size() && i < topN; i++) {
                Entry e = list.get(i);
                winners.add(new Winner(e.id, e.name, e.periodKills, i + 1));
            }
            for (Entry e : data.values()) e.periodKills = 0L;

            lastWinners = winners;
            lastPeriodKey = periodKey;
            periodKey = newKey;
            dirty = true;
            return new ArrayList<>(winners);
        }
    }

    public List<Winner> getLastWinners() {
        synchronized (lock) { return new ArrayList<>(lastWinners); }
    }

    /** Hadiah buat player yang lagi offline pas periode ditutup - dikirim pas dia login. */
    public void addPending(UUID id, List<String> commandLines) {
        synchronized (lock) {
            pending.computeIfAbsent(id, k -> new ArrayList<>()).addAll(commandLines);
            dirty = true;
        }
    }

    public List<String> takePending(UUID id) {
        synchronized (lock) {
            List<String> lines = pending.remove(id);
            if (lines != null) dirty = true;
            return lines;
        }
    }

    // ---------- baca ----------

    public Entry get(UUID id) {
        synchronized (lock) {
            Entry e = data.get(id);
            return e == null ? null : e.copy();
        }
    }

    public Entry findByName(String name) {
        synchronized (lock) {
            for (Entry e : data.values()) {
                if (e.name.equalsIgnoreCase(name)) return e.copy();
            }
        }
        return null;
    }

    public static long value(Entry e, String type) {
        switch (type) {
            case "time": return e.seconds;
            case "deaths": return e.deaths;
            case "entries": return e.entries;
            case "period": return e.periodKills;
            default: return e.kills;
        }
    }

    /** Top N player buat 1 kategori (kills/time/deaths/entries/period). Yang nilainya 0 gak ikut. */
    public List<Entry> top(String type, int limit) {
        List<Entry> list = new ArrayList<>();
        synchronized (lock) {
            for (Entry e : data.values()) {
                if (value(e, type) > 0) list.add(e.copy());
            }
        }
        list.sort(Comparator.comparingLong((Entry e) -> value(e, type)).reversed());
        if (list.size() > limit) return new ArrayList<>(list.subList(0, limit));
        return list;
    }
}
