package com.sanz.dungeon;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.concurrent.TimeUnit;

public class SanzDungeonPlugin extends JavaPlugin {

    private DungeonManager dungeonManager;
    private DungeonShopManager shopManager;
    private WarpDungeonConfig warpConfig;
    private DungeonStats stats;
    private DungeonTracker tracker;

    @Override
    public void onEnable() {
        warpConfig = new WarpDungeonConfig(this);

        dungeonManager = new DungeonManager(this);
        DungeonCurrencyProvider currency = new DungeonCurrencyProvider(this);

        shopManager = new DungeonShopManager(this);

        stats = new DungeonStats(this);
        tracker = new DungeonTracker(this, dungeonManager, warpConfig, stats);
        DungeonRewards rewards = new DungeonRewards(this, warpConfig, stats);
        DungeonTeleporter teleporter = new DungeonTeleporter(this, dungeonManager, currency, tracker, warpConfig);
        DungeonRegionViewer regionViewer = new DungeonRegionViewer(this);

        DungeonWandListener wandListener = new DungeonWandListener(this, dungeonManager);
        DungeonProtectionListener protectionListener = new DungeonProtectionListener(this, dungeonManager, warpConfig, tracker);
        DungeonExtraListener extraListener = new DungeonExtraListener(this, dungeonManager, warpConfig, protectionListener, tracker, teleporter, rewards);
        DungeonMoveListener moveListener = new DungeonMoveListener(protectionListener);

        DungeonGUI dungeonGUI = new DungeonGUI(dungeonManager, tracker, teleporter);
        DungeonGUIListener guiListener = new DungeonGUIListener(dungeonManager, teleporter);

        DungeonEditSession editSession = new DungeonEditSession();
        DungeonEditGUI editGUI = new DungeonEditGUI(dungeonManager);
        DungeonEditListener editListener = new DungeonEditListener(dungeonManager, editGUI, editSession);

        DungeonShopGUI shopGUI = new DungeonShopGUI();
        DungeonShopVoucherListener shopVoucherListener = new DungeonShopVoucherListener(currency, this);
        DungeonShopCategorySelectListener categorySelectListener = new DungeonShopCategorySelectListener(shopManager, shopGUI);

        ShopEditSession shopEditSession = new ShopEditSession();
        ShopEditGUI shopEditGUI = new ShopEditGUI();
        ShopEditListener shopEditListener = new ShopEditListener(shopManager, shopEditGUI, shopEditSession, this, warpConfig);

        getServer().getPluginManager().registerEvents(wandListener, this);
        getServer().getPluginManager().registerEvents(protectionListener, this);
        getServer().getPluginManager().registerEvents(extraListener, this);
        getServer().getPluginManager().registerEvents(moveListener, this);
        getServer().getPluginManager().registerEvents(guiListener, this);
        getServer().getPluginManager().registerEvents(editListener, this);
        getServer().getPluginManager().registerEvents(shopVoucherListener, this);
        getServer().getPluginManager().registerEvents(categorySelectListener, this);
        getServer().getPluginManager().registerEvents(shopEditListener, this);

        DungeonCommand dungeonCommand = new DungeonCommand(dungeonManager, wandListener, dungeonGUI, editGUI, shopGUI,
                shopEditGUI, shopManager, warpConfig, teleporter, tracker, stats, regionViewer, rewards);
        getCommand("dungeon").setExecutor(dungeonCommand);
        getCommand("dungeon").setTabCompleter(dungeonCommand);
        // /back udah dihapus - dulu WarpDungeon punya /back sendiri (window 2 menit
        // buat balik ke dungeon), sekarang gak ada lagi, dan /back dari plugin lain
        // (misal Essentials) tetep diblokir selagi player di dalam dungeon
        // (lihat blocked-commands di config.yml).

        // simpen statistik tiap 5 menit di thread async (aman buat Folia), jadi
        // kalau server crash data yang hilang paling banyak 5 menit terakhir.
        getServer().getAsyncScheduler().runAtFixedRate(this, task -> stats.save(), 5L, 5L, TimeUnit.MINUTES);

        // cek pergantian periode leaderboard: 5 detik setelah start, lalu tiap 1 menit
        // (thread global Folia - aman buat dispatch command console hadiah)
        Bukkit.getGlobalRegionScheduler().runAtFixedRate(this, task -> rewards.checkPeriod(), 100L, 1200L);

        getLogger().info("WarpDungeon jalan. " + dungeonManager.getAll().size() + " dungeon, " + shopManager.countTotalReadyTrades() + " trade shop siap ke-load.");
    }

    @Override
    public void onDisable() {
        if (dungeonManager != null) dungeonManager.save();
        if (shopManager != null) shopManager.save();
        if (tracker != null) tracker.shutdown();
        if (stats != null) stats.save();
    }
}
