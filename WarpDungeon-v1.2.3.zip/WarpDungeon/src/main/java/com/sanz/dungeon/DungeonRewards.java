package com.sanz.dungeon;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.IsoFields;
import java.util.ArrayList;
import java.util.List;

/**
 * Hadiah otomatis:
 *  - milestone: total kill seumur hidup nyampe angka tertentu (100, 500, ...)
 *  - leaderboard periodik: kill "periode ini" direset tiap minggu/bulan, juara
 *    dapet hadiah. Juara yang lagi offline hadiahnya disimpen dan dikirim pas
 *    login. Semua command hadiah dijalanin console lewat scheduler global
 *    (aturan Folia).
 */
public class DungeonRewards {

    private final Plugin plugin;
    private final WarpDungeonConfig config;
    private final DungeonStats stats;

    public DungeonRewards(Plugin plugin, WarpDungeonConfig config, DungeonStats stats) {
        this.plugin = plugin;
        this.config = config;
        this.stats = stats;
    }

    // ---------- milestone ----------

    /** Dipanggil tiap player ngebunuh mob di dungeon. totalKills = total SETELAH ditambah. */
    public void onKill(Player killer, long totalKills) {
        if (!config.isMilestonesEnabled()) return;
        WarpDungeonConfig.Milestone m = config.getMilestones().get(totalKills);
        if (m == null) return;

        String name = killer.getName();
        String kills = String.valueOf(totalKills);

        if (!m.message.isBlank()) {
            String text = Colors.apply(m.message.replace("%player%", name).replace("%kills%", kills));
            killer.getScheduler().run(plugin, task -> killer.sendMessage(text), null);
        }

        List<String> lines = new ArrayList<>();
        for (String c : m.commands) {
            lines.add(c.replace("%player%", name).replace("%kills%", kills));
        }
        runLines(lines);
    }

    // ---------- leaderboard periodik ----------

    private ZoneId zone() {
        try {
            return ZoneId.of(config.getLeaderboardZone());
        } catch (Exception ex) {
            return ZoneId.systemDefault();
        }
    }

    /** Kunci periode sekarang, contoh "weekly:2026-W39" / "monthly:2026-09". Kosong kalau off. */
    public String currentPeriodKey() {
        String mode = config.getLeaderboardMode();
        if (mode.equals("off")) return "";
        LocalDate d = LocalDate.now(zone());
        if (mode.equals("monthly")) {
            return String.format("monthly:%d-%02d", d.getYear(), d.getMonthValue());
        }
        int week = d.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR);
        int weekYear = d.get(IsoFields.WEEK_BASED_YEAR);
        return String.format("weekly:%d-W%02d", weekYear, week);
    }

    private static String modeOf(String key) {
        int i = key.indexOf(':');
        return i > 0 ? key.substring(0, i) : "";
    }

    /** Dicek pas server nyala & tiap menit. Kalau periode udah ganti -> tutup periode lama + bagi hadiah. */
    public void checkPeriod() {
        String current = currentPeriodKey();
        if (current.isEmpty()) return;

        String stored = stats.getPeriodKey();
        if (stored.isEmpty()) {
            stats.setPeriodKey(current); // pertama kali - mulai hitung dari sekarang, tanpa hadiah
            return;
        }
        if (stored.equals(current)) return;

        if (!modeOf(stored).equals(modeOf(current))) {
            // admin ganti weekly<->monthly: mulai periode baru tanpa bagi hadiah
            stats.rotatePeriod(current, 0);
            stats.save();
            return;
        }
        rotateAndReward(current);
    }

    /** /dungeon lbreset confirm - paksa tutup periode sekarang. false kalau leaderboard off. */
    public boolean forceReset() {
        String current = currentPeriodKey();
        if (current.isEmpty()) return false;
        rotateAndReward(current);
        return true;
    }

    private void rotateAndReward(String newKey) {
        List<DungeonStats.Winner> winners = stats.rotatePeriod(newKey, config.getLeaderboardTopSize());
        stats.save(); // langsung simpen biar gak kebagi 2x kalau server crash

        for (DungeonStats.Winner w : winners) {
            List<String> cmds = config.getLeaderboardRewards().get(w.rank);
            if (cmds == null || cmds.isEmpty()) continue;

            List<String> lines = new ArrayList<>();
            for (String c : cmds) {
                lines.add(c.replace("%player%", w.name)
                        .replace("%rank%", String.valueOf(w.rank))
                        .replace("%kills%", String.valueOf(w.kills)));
            }

            Player online = Bukkit.getPlayer(w.id);
            if (online != null) {
                runLines(lines);
                online.sendMessage(config.msg("reward-delivered"));
            } else {
                stats.addPending(w.id, lines);
            }
        }
        stats.save();

        if (config.isLeaderboardBroadcast() && !winners.isEmpty()) {
            List<String> texts = new ArrayList<>();
            texts.add(config.msg("leaderboard-header"));
            for (DungeonStats.Winner w : winners) {
                texts.add(config.msg("leaderboard-line",
                        "%rank%", String.valueOf(w.rank),
                        "%player%", w.name,
                        "%kills%", String.valueOf(w.kills)));
            }
            for (Player p : Bukkit.getOnlinePlayers()) {
                for (String t : texts) p.sendMessage(t);
            }
        }
    }

    /** Dipanggil pas player login - kirim hadiah juara yang ketunda karena dia offline. */
    public void deliverPending(Player p) {
        List<String> lines = stats.takePending(p.getUniqueId());
        if (lines == null || lines.isEmpty()) return;
        stats.save();
        runLines(lines);
        p.sendMessage(config.msg("reward-delivered"));
    }

    // ---------- util ----------

    private void runLines(List<String> lines) {
        if (lines.isEmpty()) return;
        Bukkit.getGlobalRegionScheduler().run(plugin, task -> {
            for (String line : lines) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), line);
            }
        });
    }
}
