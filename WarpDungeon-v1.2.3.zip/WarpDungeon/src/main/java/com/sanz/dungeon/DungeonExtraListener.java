package com.sanz.dungeon;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Hanging;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.Plugin;

import java.util.List;

/**
 * Proteksi tambahan (ember, api, mob griefing, item frame, ledakan dari luar
 * region) + pencatatan kill/mati + rapiin state pas respawn.
 * Bypass sama kayak proteksi lain: OP atau permission dungeon.bypass.
 * Semua toggle-nya ada di config.yml bagian "protection".
 */
public class DungeonExtraListener implements Listener {

    private final Plugin plugin;
    private final DungeonManager manager;
    private final WarpDungeonConfig config;
    private final DungeonProtectionListener protection;
    private final DungeonTracker tracker;
    private final DungeonTeleporter teleporter;
    private final DungeonRewards rewards;

    public DungeonExtraListener(Plugin plugin, DungeonManager manager, WarpDungeonConfig config,
                                DungeonProtectionListener protection, DungeonTracker tracker,
                                DungeonTeleporter teleporter, DungeonRewards rewards) {
        this.plugin = plugin;
        this.manager = manager;
        this.config = config;
        this.protection = protection;
        this.tracker = tracker;
        this.teleporter = teleporter;
        this.rewards = rewards;
    }

    private boolean bypass(Player p) {
        return p.isOp() || p.hasPermission("dungeon.bypass");
    }

    private boolean inDungeon(Location loc) {
        return loc != null && manager.getDungeonAt(loc) != null;
    }

    // ---------- masuk dungeon HARUS lewat /dungeon ----------
    // Tanpa ini player bisa nembus tiket/cooldown/syarat lewat /back (balik ke
    // titik sebelum keluar dungeon), /tpa ke orang yang lagi di dalam, /home
    // lama, dll. Teleport dari luar ke dalam region diblok, KECUALI yang lewat
    // DungeonTeleporter (GUI /dungeon atau /dungeon tp). Teleport antar titik
    // di dalam dungeon yang sama (misal skill boss MythicMobs) tetep boleh.
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTeleportIntoDungeon(PlayerTeleportEvent e) {
        if (!config.isBlockOutsideTeleport()) return;
        Location to = e.getTo();
        if (to == null) return;
        Dungeon dest = manager.getDungeonAt(to);
        if (dest == null) return;

        Player p = e.getPlayer();
        if (bypass(p)) return;
        if (teleporter.hasEntryPermit(p.getUniqueId())) return;

        Dungeon origin = manager.getDungeonAt(e.getFrom());
        if (origin != null && origin.getId().equals(dest.getId())) return;

        e.setCancelled(true);
        p.sendMessage(config.msg("entry-blocked"));
    }

    // ---------- gak bisa buang item di dalam dungeon ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDropItem(PlayerDropItemEvent e) {
        if (!config.isBlockItemDrop()) return;
        Player p = e.getPlayer();
        if (bypass(p)) return;
        if (!inDungeon(p.getLocation())) return;

        e.setCancelled(true);
        // actionbar (bukan chat) biar gak spam kalau player nahan tombol Q
        p.sendActionBar(Colors.component(config.msg("drop-blocked")));
    }

    // ---------- hadiah juara yang ketunda karena player offline ----------

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        p.getScheduler().runDelayed(plugin, task -> rewards.deliverPending(p), null, 60L);
    }

    // ---------- ember ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        if (!config.isProtectBucket()) return;
        if (bypass(e.getPlayer())) return;
        if (inDungeon(e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (!config.isProtectBucket()) return;
        if (bypass(e.getPlayer())) return;
        if (inDungeon(e.getBlock().getLocation())) e.setCancelled(true);
    }

    // ---------- ledakan: block dungeon aman walau ledakannya dari luar region ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        if (!config.isProtectExplosion()) return;
        e.blockList().removeIf(b -> inDungeon(b.getLocation()));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        if (!config.isProtectExplosion()) return;
        e.blockList().removeIf(b -> inDungeon(b.getLocation()));
    }

    // ---------- mob griefing ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityChangeBlock(EntityChangeBlockEvent e) {
        if (!config.isProtectMobGriefing()) return;
        Entity who = e.getEntity();
        if (who instanceof FallingBlock) return;
        if (who instanceof Player p && bypass(p)) return;
        if (inDungeon(e.getBlock().getLocation())) e.setCancelled(true);
    }

    // ---------- api ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent e) {
        if (!config.isProtectFire()) return;
        Player p = e.getPlayer();
        if (p != null && bypass(p)) return;
        if (inDungeon(e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        if (!config.isProtectFire()) return;
        if (inDungeon(e.getBlock().getLocation())) e.setCancelled(true);
    }

    // ---------- item frame, painting, armor stand ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakByEntityEvent e) {
        if (!config.isProtectDecorations()) return;
        Entity remover = e.getRemover();
        if (remover instanceof Player p && bypass(p)) return;
        if (inDungeon(e.getEntity().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onArmorStandManipulate(PlayerArmorStandManipulateEvent e) {
        if (!config.isProtectDecorations()) return;
        if (bypass(e.getPlayer())) return;
        if (inDungeon(e.getRightClicked().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onItemFrameInteract(PlayerInteractEntityEvent e) {
        if (!config.isProtectDecorations()) return;
        if (!(e.getRightClicked() instanceof ItemFrame)) return;
        if (bypass(e.getPlayer())) return;
        if (inDungeon(e.getRightClicked().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDecorationHit(EntityDamageByEntityEvent e) {
        if (!config.isProtectDecorations()) return;
        Entity victim = e.getEntity();
        if (!(victim instanceof Hanging) && !(victim instanceof ArmorStand)) return;
        if (e.getDamager() instanceof Player p && bypass(p)) return;
        if (inDungeon(victim.getLocation())) e.setCancelled(true);
    }

    // ---------- kill mob (statistik + hadiah opsional) ----------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMobDeath(EntityDeathEvent e) {
        LivingEntity dead = e.getEntity();
        if (dead instanceof Player) return;
        Player killer = dead.getKiller();
        if (killer == null) return;

        Dungeon d = manager.getDungeonAt(dead.getLocation());
        if (d == null) return;

        long totalKills = tracker.addKill(killer);
        rewards.onKill(killer, totalKills);

        List<String> cmds = config.getKillCommands();
        if (cmds.isEmpty()) return;

        final String mobName = dead.getName();
        final String dungeonId = d.getId();
        final String killerName = killer.getName();
        // dispatch command console harus di thread global (aturan Folia)
        Bukkit.getGlobalRegionScheduler().run(plugin, task -> {
            for (String c : cmds) {
                String line = c.replace("%player%", killerName)
                        .replace("%dungeon%", dungeonId)
                        .replace("%mob%", mobName);
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), line);
            }
        });
    }

    // ---------- mati & respawn ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        if (!inDungeon(p.getLocation())) return;

        tracker.addDeath(p);

        if (config.isDeathKeepInventory()) {
            e.setKeepInventory(true);
            e.getDrops().clear();
        }
        if (config.isDeathKeepLevel()) {
            e.setKeepLevel(true);
            e.setDroppedExp(0);
        }
    }

    // Mati di dalam dungeon = otomatis keluar. Tanpa ini border/waktu/HUD
    // nyangkut sampai player gerak lagi setelah respawn.
    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        p.getScheduler().runDelayed(plugin, task -> protection.checkRegion(p), null, 5L);
    }
}
