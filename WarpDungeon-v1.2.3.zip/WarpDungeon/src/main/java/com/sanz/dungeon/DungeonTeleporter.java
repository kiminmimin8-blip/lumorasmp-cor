package com.sanz.dungeon;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Satu-satunya pintu masuk buat teleport player ke dungeon (dari GUI atau
 * /dungeon tp). Urutan: cek syarat (permission, level, cooldown, kapasitas,
 * uang) -> hitung mundur (kalau diaktifin) -> potong tiket -> teleport.
 * Tiket baru kepotong PAS teleport jalan, jadi kalau dibatalin gak rugi.
 */
public class DungeonTeleporter {

    private final Plugin plugin;
    private final DungeonManager manager;
    private final DungeonCurrencyProvider currency;
    private final DungeonTracker tracker;
    private final WarpDungeonConfig config;

    // "izin masuk" sekali pakai: teleport ke dalam dungeon yang lewat sini sah,
    // sisanya (/back, /tpa ke orang di dalam, dll) diblok DungeonExtraListener.
    private final Set<UUID> entryPermits = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Boolean> warming = new ConcurrentHashMap<>();
    private final Map<UUID, Map<String, Long>> cooldowns = new ConcurrentHashMap<>();

    public DungeonTeleporter(Plugin plugin, DungeonManager manager, DungeonCurrencyProvider currency,
                             DungeonTracker tracker, WarpDungeonConfig config) {
        this.plugin = plugin;
        this.manager = manager;
        this.currency = currency;
        this.tracker = tracker;
        this.config = config;
    }

    private boolean bypass(Player p) {
        return p.isOp() || p.hasPermission("dungeon.bypass");
    }

    public void enter(Player p, Dungeon d) {
        enter(p, d, false);
    }

    /**
     * @param force true = teleport admin (/dungeon tp): lewati semua syarat,
     *              tiket, dan hitung mundur.
     */
    public void enter(Player p, Dungeon d, boolean force) {
        if (!d.isRegionSet() || !d.isSpawnSet() || d.getSpawnLocation() == null) {
            p.sendMessage(config.msg("not-ready"));
            return;
        }
        if (warming.containsKey(p.getUniqueId())) {
            p.sendMessage(config.msg("warmup-already"));
            return;
        }

        boolean skipChecks = force || bypass(p);

        // mode maintenance: admin/bypass tetep boleh masuk buat ngecek
        if (d.isClosed() && !skipChecks) {
            String reason = d.getClosedReason().isBlank() ? config.msg("closed-default-reason") : d.getClosedReason();
            p.sendMessage(config.msg("dungeon-closed", "%reason%", reason));
            return;
        }

        if (!skipChecks) {
            String perm = d.getPermission();
            if (!perm.isBlank() && !p.hasPermission(perm)) {
                p.sendMessage(config.msg("need-permission"));
                return;
            }
            if (d.getMinLevel() > 0 && p.getLevel() < d.getMinLevel()) {
                p.sendMessage(config.msg("need-level", "%level%", String.valueOf(d.getMinLevel())));
                return;
            }
            long left = getCooldownLeft(p, d);
            if (left > 0) {
                p.sendMessage(config.msg("on-cooldown", "%time%", DungeonTracker.formatDuration(left)));
                return;
            }
            if (d.getMaxPlayers() > 0 && tracker.countInside(d.getId()) >= d.getMaxPlayers()) {
                p.sendMessage(config.msg("dungeon-full", "%max%", String.valueOf(d.getMaxPlayers())));
                return;
            }
        }

        boolean free = force || p.isOp() || p.hasPermission("dungeon.free") || !d.isPremium();
        if (!free && !currency.has(p, d.getCurrency(), d.getPrice())) {
            p.sendMessage(config.msg("not-enough-money", "%price%", currency.format(d.getCurrency(), d.getPrice())));
            return;
        }

        int warmup = skipChecks ? 0 : config.getWarmupSeconds();
        if (warmup <= 0) {
            complete(p, d, free, skipChecks);
        } else {
            startWarmup(p, d, free, warmup);
        }
    }

    // ---------- hitung mundur ----------

    private void startWarmup(Player p, Dungeon d, boolean free, int seconds) {
        UUID id = p.getUniqueId();
        warming.put(id, Boolean.TRUE);
        p.sendMessage(config.msg("warmup-start", "%dungeon%", d.getDisplayName(), "%seconds%", String.valueOf(seconds)));

        final int totalTicks = seconds * 20;
        final Location startLoc = p.getLocation().clone();
        final int[] elapsed = {0};
        final int[] lastShown = {-1};
        final double[] lastHealth = {p.getHealth()};

        p.getScheduler().runAtFixedRate(plugin, task -> {
            if (!p.isOnline()) {
                warming.remove(id);
                task.cancel();
                return;
            }
            elapsed[0] += 5;

            if (config.isWarmupCancelOnMove() && moved(startLoc, p.getLocation())) {
                warming.remove(id);
                task.cancel();
                p.sendMessage(config.msg("warmup-cancel-move"));
                return;
            }

            double hp = p.getHealth();
            if (config.isWarmupCancelOnDamage() && hp < lastHealth[0] - 0.01) {
                warming.remove(id);
                task.cancel();
                p.sendMessage(config.msg("warmup-cancel-damage"));
                return;
            }
            lastHealth[0] = hp;

            if (elapsed[0] >= totalTicks) {
                warming.remove(id);
                task.cancel();
                complete(p, d, free, false);
                return;
            }

            int left = (int) Math.ceil((totalTicks - elapsed[0]) / 20.0);
            if (left != lastShown[0]) {
                lastShown[0] = left;
                String text = config.msg("warmup-tick", "%seconds%", String.valueOf(left));
                p.sendActionBar(Colors.component(text));
            }
        }, () -> warming.remove(id), 5L, 5L);
    }

    private boolean moved(Location a, Location b) {
        if (a.getWorld() == null || b.getWorld() == null || !a.getWorld().equals(b.getWorld())) return true;
        return a.distanceSquared(b) > 0.36; // ~0.6 block
    }

    // ---------- eksekusi teleport ----------

    private void complete(Player p, Dungeon d, boolean free, boolean skipCooldown) {
        Location spawn = d.getSpawnLocation();
        if (spawn == null) {
            p.sendMessage(config.msg("not-ready"));
            return;
        }

        final boolean paid = !free;
        final String priceText = currency.format(d.getCurrency(), d.getPrice());

        if (paid) {
            if (!currency.has(p, d.getCurrency(), d.getPrice())) {
                p.sendMessage(config.msg("not-enough-money", "%price%", priceText));
                return;
            }
            if (!currency.withdraw(p, d.getCurrency(), d.getPrice())) {
                p.sendMessage(config.msg("charge-failed"));
                return;
            }
            p.sendMessage(config.msg("ticket-paid", "%price%", priceText));
        }

        p.closeInventory();
        entryPermits.add(p.getUniqueId());
        p.teleportAsync(spawn).thenAccept(success -> {
            entryPermits.remove(p.getUniqueId());
            if (success) {
                if (!skipCooldown) setCooldown(p, d);
                p.sendMessage(config.msg("teleported", "%dungeon%", d.getDisplayName()));
            } else {
                if (paid) currency.deposit(p, d.getCurrency(), d.getPrice());
                p.sendMessage(config.msg("teleport-failed"));
            }
        });
    }

    /** Dipanggil listener teleport: true kalau player ini lagi punya izin masuk sah (sekali pakai). */
    public boolean hasEntryPermit(UUID id) {
        return entryPermits.contains(id);
    }

    // ---------- cooldown ----------

    /** Sisa cooldown (detik) player ini buat dungeon itu. 0 = udah boleh masuk. */
    public long getCooldownLeft(Player p, Dungeon d) {
        if (d.getCooldownSeconds() <= 0) return 0L;
        Map<String, Long> m = cooldowns.get(p.getUniqueId());
        if (m == null) return 0L;
        Long until = m.get(d.getId());
        if (until == null) return 0L;
        long leftMillis = until - System.currentTimeMillis();
        if (leftMillis <= 0) return 0L;
        return (leftMillis + 999L) / 1000L;
    }

    private void setCooldown(Player p, Dungeon d) {
        if (d.getCooldownSeconds() <= 0) return;
        long until = System.currentTimeMillis() + d.getCooldownSeconds() * 1000L;
        cooldowns.computeIfAbsent(p.getUniqueId(), k -> new ConcurrentHashMap<>()).put(d.getId(), until);
    }
}
