package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ShopEditListener implements Listener {

    private final DungeonShopManager shopManager;
    private final ShopEditGUI editGUI;
    private final ShopEditSession session;
    private final Plugin plugin;
    private final WarpDungeonConfig config;

    // key = "trade:<dungeonId>:<categoryId>:<tradeId>" atau "category:<dungeonId>:<categoryId>"
    private final Map<UUID, String> pendingDelete = new ConcurrentHashMap<>();

    public ShopEditListener(DungeonShopManager shopManager, ShopEditGUI editGUI, ShopEditSession session, Plugin plugin, WarpDungeonConfig config) {
        this.shopManager = shopManager;
        this.editGUI = editGUI;
        this.session = session;
        this.plugin = plugin;
        this.config = config;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof ShopEditHolder holder)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;

        // klik di inventory player sendiri (bawah) dibiarin normal
        if (e.getClickedInventory() != null && !e.getClickedInventory().equals(e.getView().getTopInventory())) {
            return;
        }

        int slot = e.getRawSlot();

        boolean editableSlot =
                (holder.getMode() == ShopEditHolder.Mode.TRADE_DETAIL
                        && (slot == ShopEditHolder.INPUT_SLOT
                            || slot == ShopEditHolder.INPUT2_SLOT
                            || (slot == ShopEditHolder.OUTPUT_SLOT && !"noop".equals(holder.getAction(slot)))))
                || (holder.getMode() == ShopEditHolder.Mode.CATEGORY_DETAIL && slot == ShopEditHolder.ICON_SLOT);

        if (editableSlot) return; // biarin player taro/ambil item, gak di-cancel

        e.setCancelled(true);
        String action = holder.getAction(slot);
        if (action == null || action.equals("noop")) return;

        switch (holder.getMode()) {
            case CATEGORY_LIST -> handleCategoryListClick(p, holder, action);
            case CATEGORY_DETAIL -> handleCategoryDetailClick(p, holder, action);
            case TRADE_LIST -> handleTradeListClick(p, holder, action);
            case TRADE_DETAIL -> handleTradeDetailClick(p, holder, action);
        }
    }

    // ==========================================================
    // CATEGORY_LIST
    // ==========================================================

    private void handleCategoryListClick(Player p, ShopEditHolder holder, String action) {
        DungeonShop shop = shopManager.getOrCreate(holder.getDungeonId());

        if (action.equals("create_category")) {
            p.closeInventory();
            session.awaitCreateCategory(p.getUniqueId(), holder.getDungeonId());
            p.sendMessage(ChatColor.YELLOW + "Ketik nama kategori baru di chat:");
            return;
        }
        if (action.equals("reload")) {
            shopManager.reload();
            p.sendMessage(ChatColor.GREEN + "shop.yml di-reload dari disk.");
            p.closeInventory();
            return;
        }
        if (action.startsWith("open_category:")) {
            String catId = action.substring("open_category:".length());
            ShopCategory cat = shop.get(catId);
            if (cat != null) p.openInventory(editGUI.buildTradeList(holder.getDungeonId(), cat));
        }
    }

    // ==========================================================
    // CATEGORY_DETAIL
    // ==========================================================

    private void handleCategoryDetailClick(Player p, ShopEditHolder holder, String action) {
        DungeonShop shop = shopManager.getOrCreate(holder.getDungeonId());
        ShopCategory cat = shop.get(holder.getCategoryId());
        if (cat == null) { p.closeInventory(); return; }

        switch (action) {
            case "rename_category" -> {
                p.closeInventory();
                session.awaitRenameCategory(p.getUniqueId(), holder.getDungeonId(), cat.getId());
                p.sendMessage(ChatColor.YELLOW + "Ketik nama kategori baru di chat:");
            }
            case "save_category" -> {
                ItemStack icon = p.getOpenInventory().getTopInventory().getItem(ShopEditHolder.ICON_SLOT);
                cat.setIcon(clone(icon));
                shopManager.save();
                p.sendMessage(ChatColor.GREEN + "Icon & slot kategori tersimpan.");
                p.openInventory(editGUI.buildCategoryDetail(holder.getDungeonId(), cat));
            }
            case "delete_category" -> {
                String key = "category:" + holder.getDungeonId() + ":" + cat.getId();
                if (key.equals(pendingDelete.get(p.getUniqueId()))) {
                    shop.removeCategory(cat.getId());
                    shopManager.save();
                    pendingDelete.remove(p.getUniqueId());
                    p.sendMessage(ChatColor.RED + "Kategori '" + cat.getLabel() + "' dihapus (semua trade di dalamnya ikut kehapus).");
                    p.openInventory(editGUI.buildCategoryList(shop));
                } else {
                    pendingDelete.put(p.getUniqueId(), key);
                    p.sendMessage(ChatColor.RED + "Klik lagi buat konfirmasi hapus kategori ini (semua trade-nya ikut hilang).");
                }
            }
            case "open_trades" -> p.openInventory(editGUI.buildTradeList(holder.getDungeonId(), cat));
            case "back_to_categories" -> p.openInventory(editGUI.buildCategoryList(shop));
            default -> {
                if (action.startsWith("selectslot:")) {
                    int delta = Integer.parseInt(action.substring("selectslot:".length()));
                    int cur = cat.getSelectSlot();
                    cat.setSelectSlot(Math.max(-1, cur + delta));
                    p.openInventory(editGUI.buildCategoryDetail(holder.getDungeonId(), cat));
                }
            }
        }
    }

    // ==========================================================
    // TRADE_LIST
    // ==========================================================

    private void handleTradeListClick(Player p, ShopEditHolder holder, String action) {
        DungeonShop shop = shopManager.getOrCreate(holder.getDungeonId());
        ShopCategory cat = shop.get(holder.getCategoryId());
        if (cat == null) { p.closeInventory(); return; }

        if (action.equals("create_trade")) {
            ShopTrade t = cat.createTrade();
            shopManager.save();
            p.openInventory(editGUI.buildTradeDetail(holder.getDungeonId(), cat, t));
            return;
        }
        if (action.equals("edit_category")) {
            p.openInventory(editGUI.buildCategoryDetail(holder.getDungeonId(), cat));
            return;
        }
        if (action.equals("back_to_categories")) {
            p.openInventory(editGUI.buildCategoryList(shop));
            return;
        }
        if (action.startsWith("open_trade:")) {
            int tradeId = Integer.parseInt(action.substring("open_trade:".length()));
            ShopTrade t = cat.get(tradeId);
            if (t != null) p.openInventory(editGUI.buildTradeDetail(holder.getDungeonId(), cat, t));
        }
    }

    // ==========================================================
    // TRADE_DETAIL
    // ==========================================================

    private void handleTradeDetailClick(Player p, ShopEditHolder holder, String action) {
        DungeonShop shop = shopManager.getOrCreate(holder.getDungeonId());
        ShopCategory cat = shop.get(holder.getCategoryId());
        if (cat == null) { p.closeInventory(); return; }
        ShopTrade t = cat.get(holder.getTradeId());
        if (t == null) { p.closeInventory(); return; }

        switch (action) {
            case "toggle_mode" -> {
                t.setOutputType(t.getOutputType() == ShopTrade.OutputType.ITEM ? ShopTrade.OutputType.MONEY : ShopTrade.OutputType.ITEM);
                p.openInventory(editGUI.buildTradeDetail(holder.getDungeonId(), cat, t));
            }
            case "cycle_currency" -> {
                List<String> currencies = config.getShopCurrencies();
                int idx = currencies.indexOf(t.getOutputCurrency().toLowerCase());
                t.setOutputCurrency(currencies.get((idx + 1) % currencies.size()));
                p.openInventory(editGUI.buildTradeDetail(holder.getDungeonId(), cat, t));
            }
            case "rename_trade" -> {
                p.closeInventory();
                session.awaitRenameTrade(p.getUniqueId(), holder.getDungeonId(), cat.getId(), t.getId());
                p.sendMessage(ChatColor.YELLOW + "Ketik nama trade baru di chat:");
            }
            case "save_trade" -> {
                ItemStack input1 = p.getOpenInventory().getTopInventory().getItem(ShopEditHolder.INPUT_SLOT);
                t.setInput1(clone(input1));

                ItemStack input2 = p.getOpenInventory().getTopInventory().getItem(ShopEditHolder.INPUT2_SLOT);
                t.setInput2(clone(input2));

                if (t.getOutputType() == ShopTrade.OutputType.ITEM) {
                    ItemStack output = p.getOpenInventory().getTopInventory().getItem(ShopEditHolder.OUTPUT_SLOT);
                    t.setOutput(clone(output));
                }

                shopManager.save();
                if (t.isReady()) {
                    p.sendMessage(ChatColor.GREEN + "Trade tersimpan & langsung tampil di /dungeon shop.");
                } else {
                    p.sendMessage(ChatColor.YELLOW + "Tersimpan, tapi masih belum lengkap jadi belum tampil di /dungeon shop.");
                }
                p.openInventory(editGUI.buildTradeList(holder.getDungeonId(), cat));
            }
            case "delete_trade" -> {
                String key = "trade:" + holder.getDungeonId() + ":" + cat.getId() + ":" + t.getId();
                if (key.equals(pendingDelete.get(p.getUniqueId()))) {
                    cat.removeTrade(t.getId());
                    shopManager.save();
                    pendingDelete.remove(p.getUniqueId());
                    p.sendMessage(ChatColor.RED + "Trade dihapus.");
                    p.openInventory(editGUI.buildTradeList(holder.getDungeonId(), cat));
                } else {
                    pendingDelete.put(p.getUniqueId(), key);
                    p.sendMessage(ChatColor.RED + "Klik lagi buat konfirmasi hapus.");
                }
            }
            case "back_to_trades" -> p.openInventory(editGUI.buildTradeList(holder.getDungeonId(), cat));
            default -> {
                if (action.startsWith("money:")) {
                    double delta = Double.parseDouble(action.substring("money:".length()));
                    t.setOutputMoney(t.getOutputMoney() + delta);
                    p.openInventory(editGUI.buildTradeDetail(holder.getDungeonId(), cat, t));
                } else if (action.startsWith("slot:")) {
                    int delta = Integer.parseInt(action.substring("slot:".length()));
                    t.setSlot(t.getSlot() + delta);
                    p.openInventory(editGUI.buildTradeDetail(holder.getDungeonId(), cat, t));
                }
            }
        }
    }

    private ItemStack clone(ItemStack item) {
        return (item == null || item.getType() == Material.AIR) ? null : item.clone();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        ShopEditSession.Pending pending = session.get(p.getUniqueId());
        if (pending == null) return;

        e.setCancelled(true);
        String msg = e.getMessage().trim();
        session.clear(p.getUniqueId());

        p.getScheduler().run(plugin, (task) -> {
            DungeonShop shop = shopManager.getOrCreate(pending.dungeonId);

            switch (pending.type) {
                case CREATE_CATEGORY -> {
                    ShopCategory cat = shop.createCategory(msg);
                    shopManager.save();
                    p.sendMessage(ChatColor.GREEN + "Kategori '" + msg + "' dibuat.");
                    p.openInventory(editGUI.buildTradeList(pending.dungeonId, cat));
                }
                case RENAME_CATEGORY -> {
                    ShopCategory cat = shop.get(pending.categoryId);
                    if (cat == null) return;
                    cat.setLabel(msg);
                    shopManager.save();
                    p.sendMessage(ChatColor.GREEN + "Nama kategori diubah.");
                    p.openInventory(editGUI.buildCategoryDetail(pending.dungeonId, cat));
                }
                case RENAME_TRADE -> {
                    ShopCategory cat = shop.get(pending.categoryId);
                    if (cat == null) return;
                    ShopTrade t = cat.get(pending.tradeId);
                    if (t == null) return;
                    t.setLabel(msg);
                    shopManager.save();
                    p.sendMessage(ChatColor.GREEN + "Nama trade diubah.");
                    p.openInventory(editGUI.buildTradeDetail(pending.dungeonId, cat, t));
                }
            }
        }, null);
    }
}
