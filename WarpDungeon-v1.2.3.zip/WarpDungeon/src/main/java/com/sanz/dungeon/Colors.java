package com.sanz.dungeon;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Semua urusan warna teks di satu tempat:
 *  - kode warna biasa pakai &  (contoh: &6 emas, &a hijau, &l tebal, &r reset)
 *  - warna hex pakai &#RRGGBB   (contoh: &#FF8800)
 * Dipakai buat nama dungeon, deskripsi, pesan di config.yml, HUD, dll.
 */
public final class Colors {

    private static final Pattern HEX = Pattern.compile("&#([0-9a-fA-F]{6})");

    // serializer khusus actionbar: ngerti § biasa + format hex §x§R§R§G§G§B§B
    private static final LegacyComponentSerializer SECTION = LegacyComponentSerializer.builder()
            .character('\u00A7')
            .hexColors()
            .useUnusualXRepeatedCharacterHexFormat()
            .build();

    private Colors() {
    }

    /** "&6Halo &#FF8800dunia" -> string dengan kode § siap dipakai di chat/item/title. */
    public static String apply(String text) {
        if (text == null) return "";
        Matcher m = HEX.matcher(text);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            StringBuilder rep = new StringBuilder("\u00A7x");
            for (char c : m.group(1).toCharArray()) {
                rep.append('\u00A7').append(c);
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(rep.toString()));
        }
        m.appendTail(sb);
        return ChatColor.translateAlternateColorCodes('&', sb.toString());
    }

    /** Buat actionbar (sendActionBar butuh Component). Aman dipanggil dengan teks yang udah berwarna. */
    public static Component component(String text) {
        return SECTION.deserialize(apply(text));
    }
}
