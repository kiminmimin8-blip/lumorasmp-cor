package com.sanz.dungeon;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class DungeonWandListener implements Listener {

    private final DungeonManager manager;
    private final NamespacedKey wandKey;

    public DungeonWandListener(Plugin plugin, DungeonManager manager) {
        this.manager = manager;
        this.wandKey = new NamespacedKey(plugin, "dungeon_wand");
    }

    /** Item wand: golden axe dengan tag khusus, dikasih via /dungeon wand */
    public ItemStack createWand() {
        ItemStack item = new ItemStack(Material.GOLDEN_AXE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.GOLD + "Dungeon Wand");
        meta.setLore(java.util.List.of(
                ChatColor.GRAY + "Klik kiri = titik 1",
                ChatColor.GRAY + "Klik kanan = titik 2"
        ));
        meta.getPersistentDataContainer().set(wandKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isWand(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(wandKey, PersistentDataType.BYTE);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        ItemStack held = e.getItem();
        if (!isWand(held)) return;

        Block clicked = e.getClickedBlock();
        Location loc = clicked != null ? clicked.getLocation() : e.getPlayer().getLocation();
        Player p = e.getPlayer();

        if (e.getAction() == Action.LEFT_CLICK_BLOCK || e.getAction() == Action.LEFT_CLICK_AIR) {
            manager.setPoint1(p, loc);
            p.sendMessage(ChatColor.GREEN + "Titik 1 diset: " + fmt(loc));
            sizeHint(p);
            e.setCancelled(true);
        } else if (e.getAction() == Action.RIGHT_CLICK_BLOCK || e.getAction() == Action.RIGHT_CLICK_AIR) {
            manager.setPoint2(p, loc);
            p.sendMessage(ChatColor.GREEN + "Titik 2 diset: " + fmt(loc));
            sizeHint(p);
            e.setCancelled(true);
        }
    }

    /** Kalau titik 1 & 2 udah dua-duanya diset, kasih tau ukuran seleksinya. */
    private void sizeHint(Player p) {
        Location a = manager.getPoint1(p);
        Location b = manager.getPoint2(p);
        if (a == null || b == null || a.getWorld() == null || !a.getWorld().equals(b.getWorld())) return;
        long sx = Math.abs(a.getBlockX() - b.getBlockX()) + 1L;
        long sy = Math.abs(a.getBlockY() - b.getBlockY()) + 1L;
        long sz = Math.abs(a.getBlockZ() - b.getBlockZ()) + 1L;
        if (Dungeon.isFullHeight()) {
            p.sendMessage(ChatColor.GRAY + "Ukuran seleksi: " + sx + " x " + sz
                    + " block, tinggi otomatis penuh (Y titik gak dihitung). Lanjut /dungeon save <id>");
        } else {
            p.sendMessage(ChatColor.GRAY + "Ukuran seleksi: " + sx + " x " + sy + " x " + sz
                    + " (" + (sx * sy * sz) + " block). Lanjut /dungeon save <id>");
        }
    }

    private String fmt(Location l) {
        return l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ();
    }
}
